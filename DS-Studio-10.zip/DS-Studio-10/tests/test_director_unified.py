"""Testy „jednej grupy”: legacy (smart_instruments, autolevels, role_swap, scenarios, character) = aliasy pól reżysera,
strażnik brzmienia (Drive perkusji / zanik / klaps dopełnia werbel), odporność egzaminu producenckiego i suwak Gęstość↔BPM.

Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_director_unified -v
Testy @needs_host wymagają zbudowanego hosta (`make`) albo DS_PLUGIN_DIR z DubstepKit.clap.
"""
import copy
import json
import os
import random
import statistics
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import core  # noqa: E402
from dubstep_studio import director as DIR  # noqa: E402


def _host_ok():
    try:
        core.meta()
        return True
    except Exception:
        return False


needs_host = unittest.skipUnless(_host_ok(), "brak zbudowanego hosta/wtyczek CLAP")
INST = ["kick", "snare", "hat", "clap", "sub", "wobble", "screech"]


def _gen(**kw):
    from dubstep_studio import generator as G
    kw.setdefault("bars", 32)
    kw.setdefault("seed", 5)
    kw.setdefault("exam", "off")
    return G.generate(kw.pop("style", "Brostep"), **kw)


def _tracks_json(p):
    return json.dumps([(t["name"], t["type"], t["params"], t["notes"], round(float(t.get("gain", 0)), 4)) for t in p["tracks"]], sort_keys=True, default=str)


class AbsorbLegacy(unittest.TestCase):
    def test_off_without_flags_stays_off(self):
        d = DIR.absorb_legacy(None)
        self.assertFalse(d["on"])

    def test_smart_flag_turns_director_on_with_pick_and_windows_only(self):
        d = DIR.absorb_legacy(None, smart_instruments=True)
        self.assertTrue(d["on"] and d["pick_instruments"] and d["windows"])
        self.assertFalse(d["roles"] or d["autolevel"] or d["scenario"])
        self.assertFalse(d["mood_scale"])                      # legacy nigdy nie nadpisywał wybranej skali

    def test_all_flags_and_legacy_strength(self):
        d = DIR.absorb_legacy(None, True, True, True, True, "dark")
        self.assertTrue(all(d[k] for k in ("on", "pick_instruments", "windows", "roles", "autolevel", "scenario")))
        self.assertAlmostEqual(d["scenario_strength"], 0.55)
        self.assertEqual(d["mood"], -1.0)

    def test_flags_only_add_when_director_is_on(self):
        d = DIR.absorb_legacy(dict(on=True, roles=False, scenario=False), role_swap=True)
        self.assertTrue(d["roles"])
        self.assertFalse(d["scenario"])                         # nie dołączone, bo flaga scenarios nie była ustawiona

    def test_character_does_not_override_nonzero_mood(self):
        d = DIR.absorb_legacy(dict(on=True, mood=0.4), character="dark")
        self.assertAlmostEqual(d["mood"], 0.4)
        self.assertEqual(DIR.absorb_legacy(None, character="balanced")["mood"], 0.0)

    def test_does_not_mutate_input(self):
        src = dict(on=False)
        before = copy.deepcopy(src)
        DIR.absorb_legacy(src, True, True, True, True)
        self.assertEqual(src, before)

    def test_mood_char_roundtrip(self):
        for ch, m in DIR.LEGACY_CHAR_MOOD.items():
            self.assertEqual(DIR.mood_to_char(m), ch)
        self.assertEqual(DIR.mood_to_char(0.3), "optimistic")


class OneImplementation(unittest.TestCase):
    @needs_host
    def test_legacy_kwargs_equal_equivalent_director_dict(self):
        a = _gen(smart_instruments=True, autolevels=True, instruments=INST)
        b = _gen(director=dict(on=True, pick_instruments=True, windows=True, roles=False, autolevel=True, scenario=False,
                                mood_scale=False, scenario_strength=0.55), instruments=INST)
        self.assertEqual(_tracks_json(a), _tracks_json(b))

    @needs_host
    def test_pick_via_legacy_flag_equals_pick_via_director(self):
        a = _gen(smart_instruments=True)
        b = _gen(director=dict(on=True, pick_instruments=True, windows=True, roles=False, autolevel=False, scenario=False,
                                mood_scale=False, scenario_strength=0.55))
        self.assertEqual([t["type"] for t in a["tracks"]], [t["type"] for t in b["tracks"]])

    @needs_host
    def test_project_flags_come_from_director(self):
        p = _gen(role_swap=True, scenarios=True, autolevels=True)
        self.assertTrue(p["role_swap"] and p["scenarios"] and p["autolevels"])
        q = _gen()
        self.assertFalse(q["role_swap"] or q["scenarios"] or q["autolevels"])

    @needs_host
    def test_manual_list_is_used_when_pick_is_off(self):
        p = _gen(instruments=["kick", "snare", "hat", "sub"], director=dict(on=True, pick_instruments=False))
        self.assertEqual({t["type"] for t in p["tracks"]} & {"kick", "snare", "hat", "sub"}, {"kick", "snare", "hat", "sub"})

    @needs_host
    def test_pick_instruments_include_and_skip_and_determinism(self):
        from dubstep_studio import generator as G
        avail = list(core.meta().plugins and G.default_instruments("Brostep")) + ["speak", "clap", "pad"]
        a = DIR.pick_instruments("Brostep", 0.6, 0.5, 0.6, random.Random(3), avail, skip=("pad",), include=["speak"])
        b = DIR.pick_instruments("Brostep", 0.6, 0.5, 0.6, random.Random(3), avail, skip=("pad",), include=["speak"])
        self.assertEqual(a, b)
        self.assertIn("speak", a)
        self.assertNotIn("pad", a)
        self.assertEqual(len(a), len(set(a)))

    @needs_host
    def test_clarity_does_not_increase_instrument_count(self):
        from dubstep_studio import generator as G
        avail = G.default_instruments("Brostep") + ["clap", "pad", "rim", "tom", "shaker", "strings", "choir"]
        lo = statistics.mean(len(DIR.pick_instruments("Brostep", 0.6, 0.5, 0.8, random.Random(s), avail, clarity=0.0)) for s in range(60))
        hi = statistics.mean(len(DIR.pick_instruments("Brostep", 0.6, 0.5, 0.8, random.Random(s), avail, clarity=1.0)) for s in range(60))
        self.assertLessEqual(hi, lo + 1e-9)


class SoundGuard(unittest.TestCase):
    def test_window_never_exceeds_safe_drive(self):
        rng = random.Random(1)
        for tt, cap in DIR.SAFE_DRIVE.items():
            for _ in range(200):
                v = DIR.window("Drive", (None, "r", 0.0, 1.0), 1.0, 0.5, rng, tt=tt)
                self.assertLessEqual(v, cap + 1e-9, (tt, v))

    @needs_host
    def test_clap_drive_and_decay_safe_in_every_path(self):
        m = core.meta()
        for kw in (dict(smart_instruments=True), dict(director=dict(on=True)), dict(smart_instruments=True, invert=True),
                   dict(director=dict(on=True), invert=True, simplify=True, simplify_strength=1.0)):
            for seed in (1, 2, 3):
                p = _gen(seed=seed, instruments=INST, bpm=170, **kw)
                beat_ms = 60000.0 / p["bpm"]
                for t in p["tracks"]:
                    if t["type"] == "clap":
                        self.assertLessEqual(m.frac2eng("clap", "Drive", t["params"]["Drive"]), DIR.SAFE_DRIVE["clap"] + 1e-6, kw)
                        self.assertLessEqual(m.frac2eng("clap", "Noise Decay", t["params"]["Noise Decay"]), 0.65 * beat_ms * 1.002, kw)

    @needs_host
    def test_clap_is_brighter_than_snare(self):
        m = core.meta()
        p = _gen(instruments=INST, director=dict(on=True))
        sn = next(t for t in p["tracks"] if t["type"] == "snare")
        cl = next(t for t in p["tracks"] if t["type"] == "clap")
        self.assertGreaterEqual(m.frac2eng("clap", "Noise Highpass", cl["params"]["Noise Highpass"]),
                                1.2 * m.frac2eng("snare", "Noise Highpass", sn["params"]["Noise Highpass"]) * 0.999)

    @needs_host
    def test_guard_respects_locks(self):
        p = _gen(instruments=INST, director=dict(on=True))
        cl = next(t for t in p["tracks"] if t["type"] == "clap")
        cl["params"]["Drive"] = 0.9
        cl["locked_params"] = ["Drive"]
        DIR.guard_params(p)
        self.assertAlmostEqual(cl["params"]["Drive"], 0.9)
        cl["locked_params"] = []
        cl["lock_sound"] = True
        DIR.guard_params(p)
        self.assertAlmostEqual(cl["params"]["Drive"], 0.9)
        cl["lock_sound"] = False
        DIR.guard_params(p)
        self.assertLessEqual(cl["params"]["Drive"], DIR.SAFE_DRIVE["clap"] + 1e-6)

    @needs_host
    def test_guard_caps_drive_automation(self):
        p = _gen(instruments=INST, director=dict(on=True))
        cl = next(t for t in p["tracks"] if t["type"] == "clap")
        cl.setdefault("auto", {})["Drive"] = [[0.0, 0.1], [16.0, 0.95]]
        DIR.guard_params(p)
        self.assertTrue(all(pt[1] <= DIR.SAFE_DRIVE["clap"] + 1e-6 for pt in cl["auto"]["Drive"]))

    @needs_host
    def test_reviewer_adds_no_unknown_params(self):
        m = core.meta()
        for style in ("Brostep", "Techno", "Melodic"):
            p = _gen(style=style, seed=3)
            for t in p["tracks"]:
                for name in t["params"]:
                    self.assertTrue(m.has(t["type"], name), (style, t["type"], name))


class Determinism(unittest.TestCase):
    @needs_host
    def test_same_seed_same_project(self):
        a, b = _gen(seed=9, smart_instruments=True), _gen(seed=9, smart_instruments=True)
        strip = lambda p: json.dumps({k: v for k, v in p.items() if k != "created"}, sort_keys=True, default=str)
        self.assertEqual(strip(a), strip(b))


class ExamRobust(unittest.TestCase):
    @needs_host
    def test_exam_runs_on_tuple_notes_and_keeps_types(self):
        from dubstep_studio import producer_exam as PE
        p = _gen(style="Deep", seed=2, bars=64)
        kinds = {type(n) for t in p["tracks"] for n in t["notes"]}
        rep = PE.run(p, cfg="fix", rng=random.Random(1))
        self.assertIn("score", rep)
        self.assertTrue({type(n) for t in p["tracks"] for n in t["notes"]} <= kinds | {list, tuple})
        self.assertNotIn("exam_error", p)

    @needs_host
    def test_generate_reports_exam_without_hidden_error(self):
        p = _gen(style="Brostep", seed=4, exam="fix")
        self.assertIn("exam_report", p)
        self.assertEqual([k for k in p if k.endswith("_error")], [])

    @needs_host
    def test_each_fix_applies_at_most_once(self):
        from dubstep_studio import producer_exam as PE
        p = _gen(style="Brostep", seed=3, bars=96)
        rep = PE.run(p, cfg="fix")
        seen = {}
        for f in rep["fixes"]:
            if f["action"].startswith("spuszczenie do tła"):
                seen[(f["action"], f["track"])] = seen.get((f["action"], f["track"]), 0) + 1
        self.assertTrue(all(v == 1 for v in seen.values()), seen)


class TempoLink(unittest.TestCase):
    def test_multiplier_is_one_at_nominal_tempo(self):
        from dubstep_studio import tempo_link as TL
        for link in (-1.0, 0.0, 0.5, 1.0):
            self.assertAlmostEqual(TL.density_mul(140, 140, link), 1.0)

    def test_balance_compensates_and_amplify_pairs(self):
        from dubstep_studio import tempo_link as TL
        self.assertLess(TL.density_mul(170, 140, 1.0), 1.0)
        self.assertGreater(TL.density_mul(100, 140, 1.0), 1.0)
        self.assertGreater(TL.density_mul(170, 140, -1.0), 1.0)
        self.assertEqual(TL.density_mul(170, 140, 0.0), 1.0)

    @needs_host
    def test_events_per_second_spread_shrinks_with_balance(self):
        def eps(link, bpm):
            tot = []
            for seed in (1, 2, 3):
                p = _gen(style="Brostep", seed=seed, bars=48, bpm=bpm, tempo_link=link)
                n = sum(len(t["notes"]) for t in p["tracks"])
                tot.append(n / (p["bars"] * 4 * 60.0 / bpm))
            return statistics.mean(tot)
        spread0 = eps(0.0, 170) / eps(0.0, 120)
        spread1 = eps(1.0, 170) / eps(1.0, 120)
        self.assertLess(abs(spread1 - 1.0), abs(spread0 - 1.0))

    @needs_host
    def test_velocity_shaping_is_independent_of_tempo_link(self):
        a = _gen(style="Techno", seed=3, bpm=150, tempo_link=1.0)
        b = _gen(style="Techno", seed=3, bpm=150, tempo_link=-1.0)
        ka = [n[3] for t in a["tracks"] if t["type"] == "kick" for n in t["notes"]][:32]
        kb = [n[3] for t in b["tracks"] if t["type"] == "kick" for n in t["notes"]][:32]
        self.assertEqual(ka, kb)


if __name__ == "__main__":
    unittest.main()
