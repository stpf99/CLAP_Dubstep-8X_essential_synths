"""test_gui_resp.py — responsywność GUI (resp.py): zawijanie wierszy FlowLayout, przewijanie zakładek zamiast ucinania.

PyQt6 jest wymagana (GUI Studia i tak jej używa); gdy niedostępna w środowisku testowym —
test jest pomijany, nie failuje (zasada opcjonalnych zależności projektu).
"""
from __future__ import annotations

import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")   # testy nie otwierają okien

try:
    from PyQt6 import QtWidgets as W
    HAVE_QT = True
except Exception:                       # ImportError lub brak libEGL w środowisku CI
    HAVE_QT = False


@unittest.skipUnless(HAVE_QT, "PyQt6 niedostępna w tym środowisku")
class TestFlowLayout(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = W.QApplication.instance() or W.QApplication([])

    def _flow_row(self, n=6):
        host = W.QWidget()
        from dubstep_studio.resp import flow
        lay = flow(host)
        host._keep = [W.QPushButton(f"Przycisk {i + 1}") for i in range(n)]   # referencje: PyQt nie zwalnia widgetów pod layoutem
        for b in host._keep:
            lay.addWidget(b)
        host.ensurePolished()
        lay._host = host          # layout jest dzieckiem hosta — utrzymaj przy życiu na czas testu
        return lay

    def test_zawija_przy_waskiej_szerokosci(self):
        lay = self._flow_row(6)
        h_wide = lay.heightForWidth(900)
        h_narrow = lay.heightForWidth(160)
        self.assertGreater(h_narrow, h_wide)          # węziej → więcej linii → wyżej
        self.assertGreaterEqual(h_wide, 20)            # w szerokim mieści się w jednej linii

    def test_wysokosc_funkcja_szerokosci(self):
        lay = self._flow_row(4)
        self.assertTrue(lay.hasHeightForWidth())
        self.assertGreaterEqual(lay.heightForWidth(300), lay.heightForWidth(600))

    def test_tolerancja_boxlayout_api(self):
        """Stare wywołania addWidget(w, stretch)/addStretch nie wywalają flow."""
        lay = self._flow_row(2)
        extra = W.QPushButton("x")
        lay.addWidget(extra, 1)          # stretch ignorowany
        lay.addStretch(1)
        self.assertEqual(lay.count(), 3)

    def test_minimum_nie_miesci_sie_w_jednej_linii(self):
        lay = self._flow_row(6)
        self.assertGreater(lay.minimumSize().width(), 60)   # największy pojedynczy element


@unittest.skipUnless(HAVE_QT, "PyQt6 niedostępna w tym środowisku")
class TestPaged(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = W.QApplication.instance() or W.QApplication([])

    def test_przewija_zamiast_ucinac(self):
        from dubstep_studio.resp import paged
        page = W.QWidget()
        v = W.QVBoxLayout(page)
        for i in range(40):
            v.addWidget(W.QLabel(f"wiersz {i}"))
        sa = paged(page)
        self.assertIs(sa.widget(), page)
        self.assertTrue(sa.widgetResizable())
        # scroll area wymaga mała wysokości niezależnie od zawartości — to pozwala zwężać okno
        self.assertLess(sa.minimumSizeHint().height(), 150)
        self.assertGreater(page.sizeHint().height(), 300)


@unittest.skipUnless(HAVE_QT, "PyQt6 niedostępna w tym środowisku")
class TestMainWindowResp(unittest.TestCase):
    """Pełne okno: zakładki w paged(), okno zwężalne, brak wyjątków przy zmianie rozmiaru."""

    @classmethod
    def setUpClass(cls):
        import tempfile
        cls.home = tempfile.mkdtemp(prefix="ds_resp_")
        os.environ["HOME"] = cls.home
        cls.app = W.QApplication.instance() or W.QApplication([])
        import sys
        proj = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if proj not in sys.path:
            sys.path.insert(0, proj)
        from dubstep_studio.gui import MainWindow
        cls.mw = MainWindow()
        cls.mw.show()

    def test_okno_zwężalne_do_minimum(self):
        for wpx, hpx in ((1920, 1000), (1180, 820), (900, 640), (720, 480)):
            self.mw.resize(wpx, hpx)
            for _ in range(4):
                self.app.processEvents()
            self.assertEqual((self.mw.width(), self.mw.height()), (wpx, hpx))

    def test_wszystkie_zakładki_dzialaja_przy_ciasnym_oknie(self):
        self.mw.resize(720, 480)
        for i in range(self.mw.tabs.count()):
            self.mw.tabs.setCurrentIndex(i)
            for _ in range(2):
                self.app.processEvents()

    def test_wiersz_presetow_zawija_sie(self):
        self.mw.tabs.setCurrentIndex(0)
        self.mw.resize(1920, 1000)
        for _ in range(4):
            self.app.processEvents()
        from dubstep_studio.resp import FlowLayout
        flows = [l for l in self.mw.tabs.widget(0).widget().findChildren(FlowLayout)]
        self.assertTrue(flows, "zakładka Generator nie ma żadnego wiersza flow")
        sa = self.mw.tabs.widget(0)
        vw = sa.viewport().width()
        h_wide = min(f.heightForWidth(vw) for f in flows)
        self.mw.resize(720, 480)
        for _ in range(4):
            self.app.processEvents()
        vw2 = sa.viewport().width()
        h_narrow = max(f.heightForWidth(vw2) for f in flows)
        self.assertGreater(h_narrow, h_wide)           # ciasno → wiersze zawinięte (wyżej)


if __name__ == "__main__":
    unittest.main()
