"""tests/test_section_smooth.py — wygładzenie sekcji sąsiedztwem (spójność bez kaskady).

Sprawdza dokładnie to, na czym zależało w review:
  • środkowa sekcja liczona ZAWSZE z sąsiednich, ale ze SNAPSHOTU (Jakobi, nie
    Gauss–Seidel — brak sprzężenia zwrotnego i „chronicznego zagmatwania"),
  • złożenie wypukłe: wyniki nigdy nie wychodzą poza [min, max] oryginałów,
  • klamry, determinizm, nietknięte pola kategorialne, raport, integracja z generate().

Uruchomienie:  python3 -m unittest tests.test_section_smooth -v
"""
import copy
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import section_smooth as SS  # noqa: E402


def _proj(vals):
    """vals: lista (e0, e1) → projekt z sekcjami dict (po 8 taktów każda)."""
    return {"seed": 1, "bars": 8 * len(vals),
            "sections": [{"name": f"s{i}", "type": "drop" if i % 2 else "intro",
                          "start": i * 8, "bars": 8, "e0": e0, "e1": e1}
                         for i, (e0, e1) in enumerate(vals)]}


try:                                                           # integracja wymaga meta wtyczek (host)
    from dubstep_studio import core  # noqa: E402
    core.meta()
    HOST = True
except Exception:
    HOST = False


class TestSectionSmooth(unittest.TestCase):

    def test_zero_strength_noop(self):
        p = _proj([(0.2, 0.9), (0.9, 1.1), (0.4, 0.6)])
        before = copy.deepcopy(p["sections"])
        rep = SS.smooth_sections(p, strength=0.0)
        self.assertEqual(p["sections"], before)
        self.assertEqual(rep["sections"], 3)

    def test_middle_from_neighbors_snapshot_not_cascade(self):
        """s=1: środkowa = średnia ORYGINALNYCH sąsiadów; krawędzie = jedyny sąsiad.

        Dyskryminator Jakobi vs kaskady: lewy sąsiad ostatniej sekcji ma e0=0.9
        (oryginał), ale po wygładzeniu kaskadowym byłby już przesunięty na 0.0.
        """
        p = _proj([(0.1, 0.2), (0.9, 0.9), (0.1, 1.1)])
        SS.smooth_sections(p, strength=1.0, passes=1, keys=("e0",))
        s0, s1, s2 = p["sections"]
        self.assertAlmostEqual(s1["e0"], 0.1, places=3)        # (0.1 + 0.1) / 2 — sąsiedzi ze snapshotu
        self.assertAlmostEqual(s0["e0"], 0.9, places=3)        # prawy sąsiad (oryginał 0.9)
        self.assertAlmostEqual(s2["e0"], 0.9, places=3)        # lewy sąsiad (ORYGINAŁ 0.9, nie wygładzony 0.1!)

    def test_no_drift_beyond_original_range(self):
        """Wypukłość: po dowolnej sile i liczbie przebiegów wyniki w [min, max] oryginałów."""
        vals = [(0.1, 0.2), (0.5, 0.55), (0.95, 0.9), (0.3, 0.75), (0.7, 0.35), (0.85, 0.6)]
        e0 = [v[0] for v in vals]
        e1 = [v[1] for v in vals]
        p = _proj(vals)
        SS.smooth_sections(p, strength=1.0, passes=4)
        for got, orig in (( [s["e0"] for s in p["sections"]], e0),
                          ( [s["e1"] for s in p["sections"]], e1)):
            self.assertGreaterEqual(min(got), min(orig) - 1e-9)
            self.assertLessEqual(max(got), max(orig) + 1e-9)

    def test_clamped_to_window(self):
        p = _proj([(1.15, 1.19), (1.2, 1.2), (1.18, 1.2)])
        SS.smooth_sections(p, strength=1.0)
        for s in p["sections"]:
            self.assertLessEqual(s["e0"], SS.HI + 1e-9)
            self.assertLessEqual(s["e1"], SS.HI + 1e-9)
            self.assertGreaterEqual(s["e0"], SS.LO - 1e-9)

    def test_categorical_fields_untouched(self):
        p = _proj([(0.2, 0.9), (0.9, 1.1), (0.4, 0.6)])
        before = copy.deepcopy(p["sections"])
        SS.smooth_sections(p, strength=1.0, passes=2)
        for a, b in zip(before, p["sections"]):
            for k in ("name", "type", "start", "bars"):
                self.assertEqual(a[k], b[k])

    def test_missing_key_uses_default(self):
        p = _proj([(0.2, 0.5), (0.8, 0.6), (0.3, 1.1)])
        del p["sections"][1]["e1"]                              # snapshot: brak → DEFAULT_VALUE (0.7)
        SS.smooth_sections(p, strength=1.0, keys=("e1",))
        self.assertIn("e1", p["sections"][1])                   # wynik ≠ default → klucz dopisany
        self.assertAlmostEqual(p["sections"][1]["e1"], (0.5 + 1.1) / 2, places=3)

    def test_single_section_noop(self):
        p = _proj([(0.3, 0.8)])
        before = copy.deepcopy(p["sections"])
        SS.smooth_sections(p, strength=1.0)
        self.assertEqual(p["sections"], before)

    def test_deterministic(self):
        a = _proj([(0.2, 0.9), (0.9, 1.1), (0.4, 0.6)])
        b = _proj([(0.2, 0.9), (0.9, 1.1), (0.4, 0.6)])
        SS.smooth_sections(a, strength=0.6, passes=2)
        SS.smooth_sections(b, strength=0.6, passes=2)
        self.assertEqual(a["sections"], b["sections"])

    def test_non_dict_sections_skipped(self):
        p = _proj([(0.2, 0.9), (0.9, 1.1)])
        p["sections"].append(["break", 8])
        rep = SS.smooth_sections(p, strength=0.8)
        self.assertEqual(rep["sections"], 2)
        self.assertEqual(p["sections"][2], ["break", 8])

    def test_report_saved_in_project(self):
        p = _proj([(0.2, 0.9), (0.9, 1.1), (0.4, 0.6)])
        rep = SS.smooth_sections(p, strength=0.5)
        self.assertEqual(p["section_smooth_report"], rep)
        self.assertIn("e0", rep["keys"])
        self.assertIn("e1", rep["keys"])


@unittest.skipUnless(HOST, "brak meta wtyczek (host) — pomijam integrację")
class TestGeneratorIntegration(unittest.TestCase):

    def test_generate_applies_section_smooth(self):
        from dubstep_studio import generator as G
        p = G.generate("Brostep", bars=32, seed=7, section_smooth=0.8, section_smooth_passes=2)
        self.assertTrue(p["sections"])
        self.assertIn("section_smooth_report", p)
        self.assertEqual(p["section_smooth_report"]["strength"], 0.8)
        self.assertEqual(p["section_smooth_report"]["passes"], 2)


if __name__ == "__main__":
    unittest.main()
