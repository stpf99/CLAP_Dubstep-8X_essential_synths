"""tests/test_optional_integrations.py — testy nowych modułów opcjonalnych.

Pokrycie (wszystko działa bez zależności — odpowiednie testy są pomijane przy braku):
  • optimizer.py      — score_project / diversity_score / pętla optimize (optuna + random),
                        refine_track_sound (z hostem), zapis/odczyt tune
  • constraint_solver — rejestry, kolizje kick/sub, voice-leading, voicingi CSP, wzory CSP,
                        apply_constraints w trybie recenzenta (musicality solver=True)
  • markov_gen        — trening z syntetycznego MIDI (mido), generowanie wzorów, apply_markov
  • groove            — statystyki z MIDI, hooki structure_vel, set/clear
  • sound_match       — MFCC (numpy/librosa), dystans; match_track z hostem (mało prób)
  • listen            — analyze_audio: LUFS/pyloudnorm, silniki tempo/chroma, fallback czystym numpy

Uruchomienie:  python3 -m unittest tests.test_optional_integrations -v
"""
import math
import random
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from dubstep_studio import core, generator as G, musicality_reviewer as MR  # noqa: E402
from dubstep_studio import constraint_solver as CS  # noqa: E402
from dubstep_studio import optimizer as OPT  # noqa: E402
from dubstep_studio import listen as LS  # noqa: E402

try:
    import mido
    HAS_MIDO = True
except ImportError:
    mido = None
    HAS_MIDO = False
try:
    import pyloudnorm  # noqa: F401
    HAS_PYLN = True
except ImportError:
    HAS_PYLN = False
try:
    import librosa  # noqa: F401
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False
try:
    import optuna  # noqa: F401
    HAS_OPTUNA = True
except ImportError:
    HAS_OPTUNA = False

needs_mido = unittest.skipUnless(HAS_MIDO, "brak mido")
needs_pyln = unittest.skipUnless(HAS_PYLN, "brak pyloudnorm")
needs_librosa = unittest.skipUnless(HAS_LIBROSA, "brak librosa")


def _host_ok():
    try:
        core.meta()
        return True
    except Exception:
        return False


HOST = _host_ok()
needs_host = unittest.skipUnless(HOST, "brak zbudowanego hosta (uruchom `make`)")


def _synth_proj(seed=1, energy=0.6, density=0.6):
    p = core.new_project(bars=8, seed=seed, style="Brostep", energy=energy, density=density,
                         key=2, scale="minor")
    p["sections"] = [dict(name="intro1", type="intro", k=1, start=0, bars=4, e0=0.3, e1=0.4),
                     dict(name="drop1", type="drop", k=1, start=4, bars=4, e0=1.0, e1=1.0)]
    p["chords"] = [[2, 3], [2, 3]]
    p["tracks"] = [
        dict(name="kick", type="kick", notes=[[0.0, 0.1, 36, 110], [2.0, 0.1, 36, 112],
                                               [4.0, 0.1, 36, 108], [6.0, 0.1, 36, 111]],
             params={"Decay": 0.5, "Noise": 0.2}, gain=1.0, mute=False, solo=False),
        dict(name="sub", type="sub", notes=[[0.0, 1.0, 31, 96], [2.0, 1.0, 38, 92],
                                            [4.0, 1.0, 31, 96], [6.0, 1.0, 43, 92]],
             params={"Glide": 0.4}, gain=0.9, mute=False, solo=False),
        dict(name="pad", type="pad", notes=[[0.0, 4.0, 50, 80], [0.0, 4.0, 57, 80],
                                            [4.0, 4.0, 62, 80], [4.0, 4.0, 69, 80]],
             params={}, gain=0.5, mute=False, solo=False),
    ]
    return p


# ================================================================ optimizer
class TestOptimizer(unittest.TestCase):

    def test_score_project_zakres_i_determinizm(self):
        p = _synth_proj()
        s1, d1 = OPT.score_project(p, detail=True)
        s2, _ = OPT.score_project(p, detail=True)
        self.assertTrue(0.0 <= s1 <= 1.0)
        self.assertEqual(s1, s2)
        for k in ("range", "scale", "params", "gains", "caps", "scenario", "duplicates", "velocities"):
            self.assertIn(k, d1)
            self.assertTrue(0.0 <= d1[k] <= 1.0)

    def test_score_rossz_projekt_nizszy(self):
        good = _synth_proj()
        bad = _synth_proj()
        for t in bad["tracks"]:
            for n in t["notes"]:
                n[2] = 120                      # poza rejestrem prawie wszystkiego
        self.assertLess(OPT.score_project(bad), OPT.score_project(good))

    def test_diversity_zakres(self):
        p = _synth_proj()
        d = OPT.diversity_score(p)
        self.assertTrue(0.0 <= d <= 1.0)
        empty = core.new_project(bars=8)
        self.assertTrue(0.0 <= OPT.diversity_score(empty) <= 1.0)

    def _stub_make(self):
        def make(knobs):
            e = knobs.get("energy", 0.5)
            d = knobs.get("density", 0.5)
            p = _synth_proj(energy=e, density=d)
            # przewidywalny „generator”: źle dobrane suwaki psują nuty/gainy
            if e > 0.8:
                for t in p["tracks"]:
                    t["gain"] = 0.1
            if d > 0.8:
                for t in p["tracks"]:
                    for n in t["notes"]:
                        n[2] = 5
            return p
        return make

    def test_optimize_random_backend(self):
        # wymuszamy fallback bez optuna: własny make + odcięcie optuna w module
        saved, OPT.optuna = OPT.optuna, None
        try:
            res = OPT.optimize(trials=8, seed=11, base=dict(bars=8), make=self._stub_make())
        finally:
            OPT.optuna = saved
        self.assertEqual(res["backend"], "random")
        self.assertEqual(res["trials"], 8)
        self.assertTrue(res["best"]["values"][0] > 0.0)
        for k in ("energy", "density", "swing", "variety"):
            self.assertIn(k, res["tune"])
        self.assertLessEqual(res["tune"]["energy"], 0.8 + 1e-9)   # optimum nie w strefie kar

    def test_optimize_optuna_multi(self):
        if not HAS_OPTUNA:
            self.skipTest("brak optuna")
        res = OPT.optimize(trials=8, seed=12, base=dict(bars=8),
                           objectives=("musicality", "diversity"), make=self._stub_make())
        self.assertEqual(res["backend"], "optuna")
        self.assertEqual(len(res["best"]["values"]), 2)
        self.assertTrue(res["front"])
        for r in res["front"]:
            self.assertEqual(len(r["values"]), 2)

    def test_tune_roundtrip(self):
        p = _synth_proj()
        s = OPT.score_project(p)
        res = {"backend": "random", "trials": 5,
               "best": {"params": {"energy": 0.5}, "values": [round(s, 3)]},
               "front": [], "tune": dict(energy=0.5)}
        with tempfile.TemporaryDirectory() as td:
            f = str(Path(td) / "tune.json")
            OPT.save_tune(f, res)
            d = OPT.load_tune(f)
            self.assertEqual(d["generate"], {"energy": 0.5})
            self.assertEqual(d["backend"], "random")

    @needs_host
    def test_optimize_prawdziwy_generator(self):
        if not HAS_OPTUNA:
            self.skipTest("brak optuna")
        res = OPT.optimize("Brostep", trials=4, seed=21, base=dict(bars=8))
        self.assertEqual(res["backend"], "optuna")
        self.assertEqual(res["trials"], 4)
        self.assertIn("energy", res["tune"])

    @needs_host
    def test_refine_track_sound(self):
        p = G.generate("Brostep", bars=8, seed=33, energy=0.6, density=0.5)
        tr = next(t for t in p["tracks"] if t["type"] in ("sub", "wobble", "reese"))
        before = dict(tr["params"])
        out = OPT.refine_track_sound(p, tr["name"], trials=6, seed=5)
        self.assertIsNotNone(out)
        self.assertEqual(out["track"], tr["name"])
        self.assertTrue(0.0 <= out["score"] <= 1.0)
        self.assertTrue(set(out["params"]))
        for v in out["params"].values():
            self.assertTrue(0.0 <= v <= 1.0)
        self.assertEqual(tr["params"], before)      # projekt niezmieniony (wynik jest propozycją)


# ================================================================ constraint_solver
class TestConstraintSolver(unittest.TestCase):

    def test_solve_register(self):
        tr = dict(name="sub", type="sub", notes=[[0.0, 1.0, 100, 90], [1.0, 1.0, 5, 90]], params={})
        n = CS.solve_register(tr, 26, 43)
        self.assertEqual(n, 2)
        for note in tr["notes"]:
            self.assertTrue(26 <= note[2] <= 43)
            self.assertIn(note[2] % 12, (100 % 12, 5 % 12))
        self.assertEqual(CS.solve_register(tr, 26, 43), 0)

    def test_solve_kick_sub_przesuwa_kolizje(self):
        p = _synth_proj()
        kicks = [n[0] for t in p["tracks"] if t["type"] == "kick" for n in t["notes"]]
        moved = CS.solve_kick_sub(p)
        self.assertGreater(moved, 0)
        subs = [n[0] for t in p["tracks"] if t["type"] == "sub" for n in t["notes"]]
        for s_on in subs:
            self.assertFalse(any(abs(s_on - k) <= 0.13 for k in kicks),
                             msg=f"kolizja {s_on} pozostała")
        # nuty nadal w obrębie projektu
        for t in p["tracks"]:
            for n in t["notes"]:
                self.assertGreaterEqual(n[0], 0.0)

    def test_voice_lead_pair_optymalny(self):
        best = CS.voice_lead_pair([60, 72], [74, 61])
        self.assertEqual(best, [61, 74])           # minimalny ruch: |60-61|+|72-74| = 3
        self.assertIsNone(CS.voice_lead_pair([60], [61]))
        self.assertIsNone(CS.voice_lead_pair([60, 72], [60, 72]))   # już optymalnie

    def test_voice_lead_track_zachowuje_multizbior(self):
        tr = dict(name="stab", type="stab", params={},
                  notes=[[0.0, 1.0, 60, 90], [0.0, 1.0, 64, 90],
                         [4.0, 1.0, 65, 90], [4.0, 1.0, 72, 90]])
        CS.voice_lead_track(tr)
        self.assertEqual(sorted([n[2] for n in tr["notes"] if n[0] < 0.1]), [60, 64])
        self.assertEqual(sorted([n[2] for n in tr["notes"] if n[0] > 3.9]), [65, 72])

    def test_solve_chord_voicing_backends(self):
        for backend in ("greedy", "python-constraint", "ortools", "auto"):
            sol = CS.solve_chord_voicing([2, 5, 9], 48, 76, prev=[52, 55, 59], backend=backend)
            if sol is None and backend in ("ortools",) and not CS._cpsat:
                continue                          # ortools nieinstalowane → greedy path zwraca wynik
            self.assertIsNotNone(sol, msg=f"backend {backend}")
            self.assertEqual(len(sol), 3)
            self.assertEqual(sorted(s % 12 for s in sol), [2, 5, 9])
            for s in sol:
                self.assertTrue(48 <= s <= 76)
            self.assertEqual(len(set(sol)), 3)    # all-different

    def test_solve_pattern_warunki(self):
        for backend in ("greedy", "ortools"):
            steps = CS.solve_pattern(density=0.5, must=(0,), forbid=(3, 7), max_run=4, backend=backend)
            if steps is None and backend == "ortools" and not CS._cpsat:
                continue
            self.assertIsNotNone(steps, msg=backend)
            self.assertIn(0, steps)
            self.assertNotIn(3, steps)
            self.assertNotIn(7, steps)
            self.assertEqual(len(steps), round(0.5 * 16))
            # brak serii > 4 kolejnych kroków ani > 4 pauz
            row = [1 if i in steps else 0 for i in range(16)]
            run = 0
            for x in row + [0]:
                if x:
                    run += 1
                    self.assertLessEqual(run, 4)
                else:
                    run = 0
            run = 0
            for x in row + [1]:
                if not x:
                    run += 1
                    self.assertLessEqual(run, 4)
                else:
                    run = 0
        self.assertIsNone(CS.solve_pattern(must=(2,), forbid=(2,)))

    def test_available_backend(self):
        self.assertIn(CS.available_backend("auto"), CS.BACKENDS)

    def test_apply_constraints_orchestrator(self):
        p = _synth_proj()
        stats = CS.apply_constraints(p, intensity=1.0, rng=random.Random(4))
        self.assertIn("backend", stats)
        for key in ("register", "collisions", "voice"):
            self.assertIn(key, stats)
        for t in p["tracks"]:
            if t["type"] in MR.UNPITCHED:
                continue
            lo, hi = MR._note_range_for(t["type"])
            for n in t["notes"]:
                self.assertTrue(lo <= n[2] <= hi)

    def test_recenzent_tryb_solver(self):
        p = _synth_proj()
        cfg = dict(mode="symbolic", intensity=1.0, solver=True)
        MR.apply_symbolic(p, cfg=cfg, rng=random.Random(1))
        self.assertEqual(p["musicality"]["last"], "symbolic")
        self.assertIn("solver", p["musicality"])   # przebieg solvera odnotowany
        # bez solvera: brak klucza (zachowanie domyślne niezmienione)
        p2 = _synth_proj()
        MR.apply_symbolic(p2, cfg=dict(mode="symbolic", intensity=0.6), rng=random.Random(1))
        self.assertNotIn("solver", p2["musicality"])


# ================================================================ markov_gen
def _write_corpus_midi(path: Path):
    """Syntetyczny korpus: perkusja GM (kanał 9) + bas, z mikro-timingiem i wariacją velocity.

    Zdarzenia są wypisywane w kolejności absolutnych ticków (delta-time liczone
    jako różnica do poprzedniego zdarzenia w tej samej ścieżce)."""
    mid = mido.MidiFile(ticks_per_beat=480)
    tpb = 480
    drums = mido.MidiTrack(); mid.tracks.append(drums)
    bass = mido.MidiTrack(); mid.tracks.append(bass)
    ev_drums = []          # (tick, typ, note, vel)
    ev_bass = []
    for bar in range(4):
        for step in (0, 4, 8, 12):                 # four-on-the-floor (kick 36)
            tick = int((bar * 4 + step * 0.25) * tpb) + (8 if step == 8 else 0)  # drobny offset człowieka
            ev_drums.append((tick, "on", 36, 100 + 10 * (step == 0)))
            ev_drums.append((tick + 20, "off", 36, 0))
        for step in (2, 6, 10, 14):                 # snare backbeat (38)
            tick = int((bar * 4 + step * 0.25) * tpb)
            ev_drums.append((tick, "on", 38, 95))
            ev_drums.append((tick + 60, "off", 38, 0))
        for i, k in enumerate([38, 45, 41, 43] * 2):   # bas: ósemki
            tick = int((bar * 4 + i * 0.5) * tpb)
            ev_bass.append((tick, "on", k, 88))
            ev_bass.append((tick + 120, "off", k, 0))

    def _emit(track, events):
        last = 0
        for tick, typ, note, vel in sorted(events):
            track.append(mido.Message("note_on" if typ == "on" else "note_off",
                                      channel=9 if track is drums else 0,
                                      note=note, velocity=vel, time=tick - last))
            last = tick
    _emit(drums, ev_drums)
    _emit(bass, ev_bass)
    mid.save(str(path))
    return path


class TestMarkov(unittest.TestCase):

    @needs_mido
    def test_trenuj_generuj_zapisz(self):
        from dubstep_studio import markov_gen as MG
        with tempfile.TemporaryDirectory() as td:
            f = _write_corpus_midi(Path(td) / "corpus.mid")
            model = MG.MarkovModel.train([f])
            self.assertIn("kick", model.perc)
            self.assertIn("snare", model.perc)
            self.assertTrue(model.pitch)          # linia basu wyuczona jako rola tonalna
            rng = random.Random(3)
            rows = MG.pattern_steps(model, "kick", 4, rng)
            self.assertEqual(len(rows), 4)
            for row in rows:
                self.assertEqual(len(row), 16)
                self.assertTrue(all(x in (0, 1) for x in row))
            notes = MG.generate_pattern(model, "kick", 4, random.Random(3))
            self.assertTrue(notes)
            for n in notes:
                self.assertTrue(0.0 <= n[0] <= 16.0)
                self.assertTrue(1 <= n[3] <= 127)
            out = Path(td) / "model.json"
            model.save(str(out))
            m2 = MG.MarkovModel.load(str(out))
            self.assertEqual(m2.perc.keys(), model.perc.keys())
            self.assertIn("kick", m2.roles())

    @needs_mido
    def test_apply_markov_podmienia_role(self):
        from dubstep_studio import markov_gen as MG
        with tempfile.TemporaryDirectory() as td:
            f = _write_corpus_midi(Path(td) / "corpus.mid")
            model = MG.MarkovModel.train([f])
            p = _synth_proj()
            before = [list(n) for n in p["tracks"][0]["notes"]]
            MG.apply_markov(p, model, rng=random.Random(2))
            after = p["tracks"][0]["notes"]
            self.assertNotEqual(before, after)     # kick podmieniony wzorem z korpusu
            self.assertTrue(all(1 <= n[3] <= 127 for n in after))
            # lock_notes nietykalne
            p2 = _synth_proj()
            p2["tracks"][0]["lock_notes"] = True
            MG.apply_markov(p2, model, rng=random.Random(2))
            self.assertEqual(p2["tracks"][0]["notes"], _synth_proj()["tracks"][0]["notes"])


# ================================================================ groove
class TestGroove(unittest.TestCase):

    @needs_mido
    def test_trenuj_hooki_zapis(self):
        from dubstep_studio import groove as GRV
        with tempfile.TemporaryDirectory() as td:
            f = _write_corpus_midi(Path(td) / "corpus.mid")
            stats = GRV.GrooveStats.train([f])
            self.assertIn("kick", stats.roles)
            d = stats.roles["kick"]
            self.assertEqual(len(d["vel"]), 16)
            self.assertEqual(len(d["off"]), 16)
            out = Path(td) / "groove.json"
            stats.save(str(out))
            self.assertIn("kick", GRV.GrooveStats.load(str(out)).roles)
            # hooki
            rng = random.Random(2)
            j = GRV.vel_jitter("kick", 0, rng, 9)
            self.assertIsInstance(j, float)
            a = GRV.vel_accent("kick", 0)
            self.assertTrue(0.6 <= a <= 1.4)
            self.assertEqual(GRV.vel_accent("brak-takiej-roli", 0), 1.0)
            off = GRV.micro_timing("kick", 8, rng)
            self.assertTrue(-0.06 <= off <= 0.06)
            # bez korpusu: stabilne defaulty
            GRV.set_groove(None)
            self.assertEqual(GRV.micro_timing("kick", 8, rng), 0.0)
            self.assertEqual(GRV.vel_accent("kick", 8), 1.0)
            # aktywny groove nie psuje zakresu velocity
            GRV.set_groove(stats)
            v = G.structure_vel(112, "drop", role="kick", rng=random.Random(1))
            self.assertTrue(1 <= v <= 127)


# ================================================================ sound_match + listen
class TestSoundMatch(unittest.TestCase):

    def test_mfcc_numpy_i_dystans(self):
        from dubstep_studio import sound_match as SM
        sr = 48000
        t = np.arange(sr * 2) / sr
        x = (0.5 * np.sin(2 * np.pi * 220 * t) + 0.25 * np.sin(2 * np.pi * 440 * t)).astype(np.float32)
        a = SM.mfcc_vector(x, sr)
        self.assertEqual(len(a[0]), 13)
        self.assertGreater(a[1], 100.0)
        self.assertEqual(SM.feature_distance(a, a), 0.0)
        y = (0.5 * np.sin(2 * np.pi * 110 * t) + 0.02 * np.random.RandomState(1).randn(len(t)).astype(np.float32)).astype(np.float32)
        b = SM.mfcc_vector(y, sr)
        self.assertGreater(SM.feature_distance(a, b), SM.feature_distance(a, a))

    @needs_librosa
    def test_mfcc_librosa(self):
        from dubstep_studio import sound_match as SM
        sr = 48000
        t = np.arange(sr) / sr
        x = np.sin(2 * np.pi * 330 * t).astype(np.float32) * 0.5
        m, c = SM.mfcc_vector(x, sr)
        self.assertEqual(len(m), 13)
        self.assertGreater(c, 200.0)

    @needs_host
    def test_match_track(self):
        from dubstep_studio import sound_match as SM
        sr = core.SR
        t = np.arange(sr * 2) / sr
        # „wzorzec”: ton + szum — ma charakter, ale nie identyczny jak start
        target = (0.4 * np.sin(2 * np.pi * 150 * t) + 0.05 * np.random.RandomState(7).randn(len(t))).astype(np.float32)
        res = SM.match_track("wobble", target, trials=4, seed=9, bars=4)
        self.assertEqual(res["type"], "wobble")
        self.assertIn(res["backend"], ("cma", "optuna", "random"))
        self.assertTrue(res["params"])
        for v in res["params"].values():
            self.assertTrue(0.0 <= v <= 1.0)
        self.assertGreaterEqual(res["similarity"], 0.0)


class TestListenAudio(unittest.TestCase):

    def _signal(self, dur=6.0, sr=44100, amp=0.5):
        t = np.arange(int(sr * dur)) / sr
        x = (amp * np.sin(2 * np.pi * 110 * t) + 0.3 * amp * np.sin(2 * np.pi * 220 * t)).astype(np.float32)
        env = ((np.sin(2 * np.pi * 2 * t) + 1) * 0.5).astype(np.float32)   # puls 120 BPM
        x *= 0.2 + 0.8 * env
        return np.stack([x, x], axis=1).astype(np.float32)

    def test_cisza(self):
        F = LS.analyze_audio(np.zeros((44100 * 5, 2), np.float32))
        self.assertTrue(F.get("silent"))

    def test_cechy_i_silniki(self):
        F = LS.analyze_audio(self._signal())
        self.assertFalse(F.get("silent", True))
        self.assertIn(F.get("tempo_engine"), ("numpy", "librosa", "aubio"))
        self.assertIn(F.get("chroma_engine"), ("numpy", "librosa"))
        self.assertTrue(40 <= F["bpm"] <= 400)
        self.assertTrue(0 <= F["tempo_conf"] <= 1)
        self.assertTrue(0 <= F["onsets_beat"] <= 16)
        self.assertTrue(0 <= F["width"] <= 1)
        self.assertTrue(math.isfinite(F["rms_db"]))
        if HAS_LIBROSA:
            self.assertIsNotNone(F.get("mfcc"))
            self.assertEqual(len(F["mfcc"]), 13)
        if HAS_PYLN:
            self.assertIsNotNone(F.get("lufs"))
            self.assertTrue(-70 < F["lufs"] < 0)

    def test_fallback_czysty_numpy(self):
        """Wyłączenie librosa/pyloudnorm (symulacja braku) nie wywraca analizy."""
        saved_lr, saved_ln = LS.librosa, LS._pyln
        LS.librosa, LS._pyln = None, None
        try:
            F = LS.analyze_audio(self._signal())
            self.assertFalse(F.get("silent", True))
            self.assertEqual(F.get("tempo_engine"), "numpy")
            self.assertEqual(F.get("chroma_engine"), "numpy")
            self.assertIsNone(F.get("lufs"))
            self.assertTrue(40 <= F["bpm"] <= 400)
        finally:
            LS.librosa, LS._pyln = saved_lr, saved_ln

    @needs_pyln
    def test_lufs_rosnie_z_glosnoscia(self):
        F = LS.analyze_audio(self._signal(amp=0.9))
        F2 = LS.analyze_audio(self._signal(amp=0.05))
        self.assertGreater(F["lufs"], F2["lufs"])     # głośniejszy sygnał = wyższe LUFS

    @needs_host
    def test_autolevel_lufs(self):
        p = G.generate("Brostep", bars=8, seed=77, energy=0.6, density=0.5, autolevels=True)
        rep = core.autolevel(p)
        self.assertTrue(rep)
        for name, (old, new, meas) in rep.items():
            self.assertTrue(0.05 <= new <= core.GAIN_MAX_AUTO + 1e-6, msg=f"{name}: gain {new}")


if __name__ == "__main__":
    unittest.main()
