"""perceptual_norms.py — zakresy norm percepcji słuchowej dla egzaminu producenckiego i sprzężenia gęstości z BPM.

Kod nie ma „ucha słuchacza”, więc zamiast zgadywać porównuje to, co wygenerował, z ZAKRESAMI NORM — jak egzaminator
z listą kryteriów. Każda norma ma dwa progi:

  komfort  — wewnątrz: pełne zaliczenie (100 pkt),
  twardy   — poza komfortem, ale w twardym limicie: ostrzeżenie (liniowo 100 → 55 pkt),
             poza twardym limitem: niezaliczone (55 → 0 pkt).

Wartości są ORIENTACYJNE (heurystyki oparte na ogólnie znanych zjawiskach, nie wyniki badań na Twoich słuchaczach)
i można je nadpisać w pliku `perceptual_norms.json` (obok ds-studio albo $DS_NORMS) — wystarczy podać zmienione klucze.
Podstawy zjawiskowe (ogólnie):

  * zlewanie się zdarzeń: poniżej ~100 ms między dźwiękami (≳10 zd./s) kolejne uderzenia przestają być słyszane
    jako osobne podpodziały rytmu, a powyżej ~16–20 zd./s zlewają się w szorstkość/brzęczenie (London, Repp);
  * tempo: pulsacja najwyraźniejsza ok. 100–130 BPM (preferowany okres ~0,5–0,6 s), użyteczny zakres ~60–200 BPM;
  * strumienie słuchowe: jedna melodia dobrze śledzona do ok. 6–8 zd./s; pojemność uwagi ~4±1 „strumienie” (Cowan),
    stąd limity liczby jednocześnie słyszalnych partii i wejść na takt;
  * maskowanie i pasma krytyczne: w niskim rejestrze pasmo krytyczne jest szerokie (~100 Hz), więc małe interwały
    poniżej ok. C2–G2 brzmią błotniście (reguła „low interval limit” z orkiestracji);
  * pole uwagi/pamięć robocza: akord/frazę trzeba „zmieścić” w ok. 2–8 s (rytm harmoniczny), a motyw powtarzać
    (zapamiętywalność) z wariacją (nuda vs chaos).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

# ----------------------------------------------------------------------------- role (klasy percepcyjne)
ROLE_OF = {
    "kick": "kick",
    "snare": "backbeat", "clap": "backbeat",
    "hat": "hat", "openhat": "hat", "shaker": "hat", "ride": "hat",
    "rim": "perc", "tom": "perc", "cowbell": "perc", "conga": "perc",
    "crash": "accent",
    "sub": "bass", "wobble": "bass", "reese": "bass", "growl": "bass", "neuro": "bass", "fmbass": "bass",
    "hollow": "bass", "acid": "bass", "bass808": "bass", "upright": "bass",
    "screech": "lead", "supersaw": "lead", "pluck": "lead", "stab": "lead", "vox": "lead", "speak": "lead",
    "theremin": "lead", "panflute": "lead", "piano": "lead", "epiano": "lead", "harpsichord": "lead",
    "flute": "lead", "brass": "lead", "hoover": "lead",
    "handpan": "mallet", "tongue": "mallet", "vibes": "mallet", "marimba": "mallet", "bell": "mallet",
    "pad": "pad", "strings": "pad", "choir": "pad", "cello": "pad", "organ": "pad", "drone": "pad",
    "riser": "fx", "boom": "fx", "zap": "fx", "glitch": "fx",
}
ROLE_PL = {
    "kick": "stopa", "backbeat": "werbel/klaps", "hat": "hat/shaker", "perc": "perkusjonalia", "accent": "akcenty (crash)",
    "bass": "bas", "lead": "lead/melodia", "mallet": "melodyczne perkusyjne", "pad": "pad/tło", "fx": "FX",
}
PERC_ROLES = ("kick", "backbeat", "hat", "perc", "accent")          # perkusyjne: build ma prawo do rolek
MELODIC_ROLES = ("bass", "lead", "mallet", "pad")
FOREGROUND_ROLES = ("lead", "mallet")                                 # partie „na pierwszym planie”


def role_of(ttype: str) -> str:
    return ROLE_OF.get(str(ttype), "lead")


# ----------------------------------------------------------------------------- normy (komfort, twardy)
# Zdarzenia/s na ścieżkę: p90 po taktach, w których ścieżka gra (fille/rolki w ≤10 % taktów są dozwolone).
RATE_NORMS = {
    "kick": (5.0, 8.0),
    "backbeat": (4.0, 7.0),
    "hat": (10.5, 14.0),
    "perc": (5.0, 8.0),
    "accent": (1.5, 3.5),
    "bass": (6.5, 10.0),
    "lead": (7.0, 11.0),
    "mallet": (7.0, 11.0),
    "pad": (1.6, 3.2),
    "fx": (8.0, 14.0),
}
BUILD_RATE_LEEWAY = 1.6              # w buildzie perkusja ma prawo do rolek (mnożnik limitów perkusyjnych)

# Każda norma: (komfort_lo, komfort_hi, twardy_lo, twardy_hi); None = bez limitu z tej strony.
NORMS = {
    # --- Gęstość względem BPM
    "bpm": (70, 180, 60, 200),
    "total_rate_drop": (8.0, 34.0, 4.0, 46.0),                  # suma zdarzeń/s wszystkich torów (bez FX) w dropie
    "tempo_drift": (0.80, 1.25, 0.60, 1.60),                    # (zd./s przy tym BPM) / (zd./s przy tempie projektowym stylu)
    # --- Klarowność
    "low_collisions_per_100bars": (None, 2.0, None, 8.0),       # naruszenia „low interval limit” na 100 taktów
    "bass_stack_share": (None, 0.20, None, 0.50),               # udział ćwierćnut dropu z ≥3 basami naraz
    "foreground_overlap": (None, 0.15, None, 0.35),             # udział ćwierćnut dropu z ≥3 leadami naraz
    "missing_duck": (None, 0.0, None, 1.0),                     # basy bez sidechainu od stopy (gdy stopa jest)
    # --- Klimat muzyczny
    "scale_conformity": (0.92, None, 0.80, None),               # udział nut melodycznych w skali utworu
    "harmonic_rhythm_s": (1.5, 8.0, 0.9, 12.0),                 # mediana czasu trwania akordu [s]
    "motif_repetition": (0.25, 0.85, 0.10, 0.97),               # udział taktów powtarzających któryś z 8 poprzednich
    "register_fit": (0.85, None, 0.65, None),                   # udział nut roli (bas/lead/pad) w jej rejestrze ±12 półtonów
    # --- Wyważenie wejść i intensyfikacji
    "entrances_per_bar": (None, 2.0, None, 3.0),                # max nowych strumieni w jednym takcie (intro/build)
    "build_slope": (1.15, None, 1.0, None),                     # intensywność końca buildu / początku buildu
    "drop_break_contrast": (1.3, None, 1.1, None),              # intensywność dropu / przerwy (cicha przerwa nie jest wadą)
    "event_share_top": (None, 0.45, None, 0.65),                # udział najbardziej „gadatliwego” toru (bez hat/shaker) w zdarzeniach
}
# Liczba jednocześnie słyszalnych STRUMIENI (perkusja = 1, każdy bas/lead/pad osobno) wg typu sekcji
STREAMS = {
    "intro": (1, 5, 1, 7),
    "build": (1, 6, 1, 8),                  # build samą perkusją + FX (1 strumień) to idiom gatunku, nie wada
    "drop": (3, 8, 2, 10),
    "break": (1, 5, 1, 7),
    "outro": (1, 5, 1, 7),
}
# Sekcje, w których oceniamy tempo zdarzeń torów perkusyjnych bez wyjątku (build ma rolki)
GRADED_SECTIONS = ("intro", "drop", "break", "outro", "build")

# Poziomy siatki: zdarzeń na ćwierćnutę → etykieta
GRID_LEVELS = [(1.0, "1/4"), (2.0, "1/8"), (3.0, "1/8T"), (4.0, "1/16"), (6.0, "1/16T"), (8.0, "1/32")]

# Waga kryteriów w ocenie końcowej
CRITERIA = {
    "tempo": ("Gęstość względem BPM", 0.30),
    "clarity": ("Klarowność", 0.25),
    "vibe": ("Klimat muzyczny", 0.20),
    "arrangement": ("Wyważenie wejść i intensyfikacji", 0.25),
}
GRADES = [(88, "ZDANY Z WYRÓŻNIENIEM"), (72, "ZDANY"), (55, "WARUNKOWO"), (0, "NIEZDANY")]


# ----------------------------------------------------------------------------- nadpisania użytkownika
def _path() -> Path:
    if os.environ.get("DS_NORMS"):
        return Path(os.environ["DS_NORMS"])
    app = Path(__file__).resolve().parent.parent / "perceptual_norms.json"
    return app if app.exists() else Path.home() / "DubstepStudio" / "perceptual_norms.json"


def _apply_overrides() -> None:
    """Nadpisuje RATE_NORMS / NORMS / STREAMS wartościami z JSON (tylko znane klucze, tylko poprawne liczby)."""
    try:
        p = _path()
        if not p.exists():
            return
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return
    if not isinstance(d, dict):
        return
    for k, v in (d.get("rate") or {}).items():
        if k in RATE_NORMS and isinstance(v, (list, tuple)) and len(v) == 2:
            try:
                RATE_NORMS[k] = (float(v[0]), float(v[1]))
            except (TypeError, ValueError):
                pass
    for k, v in (d.get("norms") or {}).items():
        if k in NORMS and isinstance(v, (list, tuple)) and len(v) == 4:
            try:
                NORMS[k] = tuple(None if x is None else float(x) for x in v)
            except (TypeError, ValueError):
                pass
    for k, v in (d.get("streams") or {}).items():
        if k in STREAMS and isinstance(v, (list, tuple)) and len(v) == 4:
            try:
                STREAMS[k] = tuple(int(x) for x in v)
            except (TypeError, ValueError):
                pass


_apply_overrides()


# ----------------------------------------------------------------------------- ocena wartości względem normy
def judge(value: float, comfort_lo=None, comfort_hi=None, hard_lo=None, hard_hi=None) -> tuple[str, float]:
    """-> (status 'ok'|'warn'|'fail', punkty 0..100). Brak progu (None) = brak limitu z tej strony."""
    v = float(value)
    pen = 0.0                                              # 0 = w komforcie; 1 = na twardym limicie; 2 = dwa razy dalej
    if comfort_hi is not None and v > comfort_hi:
        span = (hard_hi - comfort_hi) if hard_hi is not None and hard_hi > comfort_hi else max(1e-9, abs(comfort_hi) * 0.25)
        pen = max(pen, (v - comfort_hi) / span)
    if comfort_lo is not None and v < comfort_lo:
        span = (comfort_lo - hard_lo) if hard_lo is not None and hard_lo < comfort_lo else max(1e-9, abs(comfort_lo) * 0.25)
        pen = max(pen, (comfort_lo - v) / span)
    if pen <= 0.0:
        return "ok", 100.0
    score = 100.0 - 45.0 * pen if pen <= 1.0 else max(0.0, 55.0 - 55.0 * min(1.0, pen - 1.0))
    return ("warn" if score >= 55.0 else "fail"), round(score, 1)


def judge_norm(key: str, value: float) -> tuple[str, float]:
    return judge(value, *NORMS[key])


def grade_for(score: float) -> str:
    for lo, name in GRADES:
        if score >= lo:
            return name
    return GRADES[-1][1]


# ----------------------------------------------------------------------------- siatka dozwolona przez BPM
def grid_label(events_per_beat: float) -> str:
    best = GRID_LEVELS[0][1]
    for epb, lab in GRID_LEVELS:
        if events_per_beat + 1e-9 >= epb:
            best = lab
    return best


def grid_ceiling(role: str, bpm: float, level: str = "comfort") -> dict:
    """Najdrobniejsza stale używana siatka dla roli przy danym BPM (z limitu zdarzeń/s)."""
    lim = RATE_NORMS.get(role, RATE_NORMS["lead"])
    hz = lim[0] if level == "comfort" else lim[1]
    epb = hz * 60.0 / max(1.0, float(bpm))
    return {"hz": round(hz, 2), "per_beat": round(epb, 2), "label": grid_label(epb)}


def grid_table(bpm: float) -> dict:
    """Role → dozwolona przez BPM siatka (to „tor” rytmiczny, który BPM nadaje perkusji, basowi i melodii)."""
    return {r: grid_ceiling(r, bpm) for r in ("kick", "backbeat", "hat", "perc", "bass", "lead", "mallet", "pad")}
