"""producer_exam.py — „egzamin w szkole producentów”: raport vs normy percepcji + korekta sterowana raportem.

Generator nie ma ucha słuchacza. Zamiast zgadywać, wykonuje cztery kroki jak egzaminator z listą kryteriów:

  1. POMIAR    — z nut, sekcji i linków liczy wskaźniki (zdarzenia/s na tor, kolizje w basie, liczba strumieni,
                 wejścia partii, łuk intensywności…); opcjonalnie także z miksu audio (pasma, crest, dynamika).
  2. RAPORT    — każdy wskaźnik porównuje z ZAKRESEM NORMY (perceptual_norms.py): ok / ostrzeżenie / niezaliczone,
                 punkty 0–100, cztery kryteria: Gęstość względem BPM · Klarowność · Klimat muzyczny ·
                 Wyważenie wejść i intensyfikacji → ocena końcowa (zdany z wyróżnieniem / zdany / warunkowo / niezdany).
  3. KOREKTA   — tylko to, co raport uznał za wykroczenie poza komfort i co da się naprawić bez łamania gatunku:
                 przerzedzenie torów powyżej tempa zdarzeń komfortowego dla BPM (fille/rolki zostają), rozsunięcie
                 kolizji w niskim rejestrze, rozłożenie wejść partii w introsie/buildzie, ściszenie nadmiaru
                 równoległych basów/leadów, wzmocnienie kontrastu przerwa↔drop i narastania buildu.
  4. POWTÓRNY POMIAR — raport końcowy zawiera wynik PRZED i PO oraz listę zastosowanych korekt.

Bez losowości zależnej od czasu: ten sam projekt → ten sam raport i te same korekty (seed z projektu).
Pliki ścieżek zablokowane (`lock_notes`) nie są ruszane. Nuty perkusyjnego rdzenia (stopa/werbel na mocnych
miejscach) nie są usuwane w taktach, które mieszczą się w normie.
"""
from __future__ import annotations

import math
import random
from typing import Any

import numpy as np

from . import perceptual_norms as PN
from . import tempo_link as TL

VERSION = 1
DEFAULT_CFG = {"mode": "fix", "max_passes": 3, "audio": False}
MODES = ("off", "report", "fix")

# głos „słyszalny” = nuta z velocity ≥ AUDIBLE_VEL; nadmiarowe warstwy są spychane do tła (velocity ≤ BACKGROUND_VEL)
AUDIBLE_VEL = 72
BACKGROUND_VEL = 66

# priorytet zachowania toru przy korektach (większy = ważniejszy)
_PRIO = {"kick": 100, "backbeat": 90, "bass": 80, "hat": 70, "lead": 60, "perc": 55, "accent": 50, "mallet": 45, "pad": 40, "fx": 10}

# interwał minimalny (półtony) dla dwóch RÓŻNYCH wysokości w niskim rejestrze, wg niższej z nut („low interval limit”)
def _lil_min(lower_key: int) -> int:
    if lower_key <= 35:
        return 12
    if lower_key <= 42:
        return 7
    if lower_key <= 48:
        return 4
    if lower_key <= 54:
        return 3
    return 0


def _order_index(ttype: str) -> int:
    try:
        from . import generator as G
        return G.ORDER.index(ttype)
    except Exception:
        return 999


def _f(x: float, nd: int = 1) -> str:
    return f"{x:.{nd}f}".replace(".", ",")


def _n(x) -> str:
    """Liczba normy: do 2 miejsc, bez zer na końcu (0,35 · 1,5 · 8 · 34)."""
    if x is None:
        return "—"
    t = f"{float(x):.2f}".rstrip("0").rstrip(".")
    return t.replace(".", ",")


def _with(n, key=None, vel=None):
    """Kopia nuty z podmienioną wysokością/velocity; zachowuje typ (lista lub krotka) i dodatkowe pola."""
    l = list(n)
    if key is not None:
        l[2] = int(key)
    if vel is not None:
        l[3] = int(vel)
    return tuple(l) if isinstance(n, tuple) else l


def _cfg(raw) -> dict:
    c = dict(DEFAULT_CFG)
    if isinstance(raw, dict):
        c.update({k: v for k, v in raw.items() if k in c})
    elif isinstance(raw, str) and raw in MODES:
        c["mode"] = raw
    elif raw is True:
        c["mode"] = "fix"
    elif raw in (False, None):
        c["mode"] = "off"
    c["mode"] = c["mode"] if c["mode"] in MODES else "fix"
    c["max_passes"] = max(1, min(5, int(c.get("max_passes") or 3)))
    return c


# ============================================================================= model pomiarowy
class Model:
    """Tablice numpy z nut projektu: liczby zdarzeń, obłożenie taktów/ćwierćnut, intensywność (velocity²)."""

    def __init__(self, proj: dict):
        self.p = proj
        self.bpm = float(proj.get("bpm") or 140.0)
        self.spb = 60.0 / self.bpm
        self.bar_s = 4.0 * self.spb
        self.bars = int(proj.get("bars") or 0) or max([s["start"] + s["bars"] for s in proj.get("sections") or [dict(start=0, bars=0)]])
        self.nb = self.bars * 4
        self.secs = [s for s in (proj.get("sections") or []) if int(s.get("bars", 0)) > 0]
        self.tr: list[dict] = []
        ranks: dict[str, list] = {}
        for t in proj.get("tracks") or []:
            if t.get("mute") or not t.get("notes"):
                continue
            ranks.setdefault(PN.role_of(t["type"]), []).append(t)
        for role, lst in ranks.items():
            lst.sort(key=lambda t: _order_index(t["type"]))
        for t in proj.get("tracks") or []:
            if t.get("mute") or not t.get("notes"):
                continue
            role = PN.role_of(t["type"])
            a = np.asarray([n[:4] for n in t["notes"]], dtype=float).reshape(-1, 4)
            ok = (a[:, 0] >= 0) & (a[:, 0] < self.nb)
            a = a[ok]
            if not len(a):
                continue
            bi = (a[:, 0] // 4).astype(int)
            cnt = np.bincount(bi, minlength=self.bars)[: self.bars].astype(float)
            vint = np.bincount(bi, weights=(a[:, 3] / 127.0) ** 2, minlength=self.bars)[: self.bars]
            end = a[:, 0] + np.maximum(a[:, 1], 0.05)
            sb = bi
            eb = np.minimum(self.bars - 1, ((end - 1e-6) // 4).astype(int))
            d = np.zeros(self.bars + 1)
            np.add.at(d, sb, 1)
            np.add.at(d, eb + 1, -1)
            occ_bar = np.cumsum(d)[: self.bars] > 0
            b0 = np.minimum(self.nb - 1, a[:, 0].astype(int))
            b1 = np.minimum(self.nb - 1, np.maximum(b0, np.ceil(end - 1e-6).astype(int) - 1))
            d2 = np.zeros(self.nb + 1)
            np.add.at(d2, b0, 1)
            np.add.at(d2, b1 + 1, -1)
            occ_beat = np.cumsum(d2)[: self.nb] > 0
            loud = a[:, 3] >= AUDIBLE_VEL
            d3 = np.zeros(self.nb + 1)
            np.add.at(d3, b0[loud], 1)
            np.add.at(d3, b1[loud] + 1, -1)
            occ_loud = np.cumsum(d3)[: self.nb] > 0
            rank = next((k for k, x in enumerate(ranks.get(role, [])) if x is t), 0)
            self.tr.append(dict(t=t, i=len(self.tr), name=t["name"], type=t["type"], role=role, a=a, cnt=cnt, vint=vint,
                                occ_bar=occ_bar, occ_beat=occ_beat, occ_loud=occ_loud, rank=rank, locked=bool(t.get("lock_notes"))))
        for r in self.tr:
            r["prio"] = _PRIO.get(r["role"], 50) - 4 * r["rank"]
        self.total_events = sum(float(r["cnt"].sum()) for r in self.tr if r["role"] != "fx") or 1.0

    # -- pomocnicze
    def sec_range(self, s: dict) -> tuple[int, int]:
        return int(s["start"]), min(self.bars, int(s["start"]) + int(s["bars"]))

    def sec_type(self, s: dict) -> str:
        return str(s.get("type") or str(s.get("name", "")).rstrip("0123456789"))

    def intensity(self, b0: int, b1: int, include_fx: bool = False) -> float:
        """Intensywność (suma velocity² na sekundę) w taktach [b0, b1)."""
        if b1 <= b0:
            return 0.0
        tot = sum(float(r["vint"][b0:b1].sum()) for r in self.tr if include_fx or r["role"] != "fx")
        return tot / ((b1 - b0) * self.bar_s)


# ============================================================================= wiersze raportu
def _norm_text(norm, unit: str = "") -> str:
    clo, chi, hlo, hhi = norm
    u = (" " + unit) if unit else ""
    if clo is None and chi is not None:
        return f"≤ {_n(chi)}{u} (twardy limit {_n(hhi)}{u})" if hhi is not None else f"≤ {_n(chi)}{u}"
    if chi is None and clo is not None:
        return f"≥ {_n(clo)}{u} (twardy limit {_n(hlo)}{u})" if hlo is not None else f"≥ {_n(clo)}{u}"
    return f"{_n(clo)}–{_n(chi)}{u} (twardo {_n(hlo)}–{_n(hhi)}{u})"


def _row(crit: str, rid: str, label: str, value: float, norm, unit: str = "", where: str = "", hint: str = "",
         fixable: bool = False, detail: Any = None, info_only: bool = False) -> dict:
    status, score = PN.judge(value, *norm)
    if info_only:
        status, score = "info", 100.0
    return dict(crit=crit, id=rid, label=label, where=where, value=round(float(value), 3), unit=unit,
                norm=_norm_text(norm, unit), status=status, score=score, hint=hint, fixable=fixable, detail=detail)


# ============================================================================= pomiary
def _measure_rates(m: Model) -> list[dict]:
    rows = []
    worst: dict[str, dict] = {}
    for r in m.tr:
        comfort, hard = PN.RATE_NORMS.get(r["role"], PN.RATE_NORMS["lead"])
        for s in m.secs:
            st = m.sec_type(s)
            if st not in PN.GRADED_SECTIONS or (st == "build" and r["role"] in PN.PERC_ROLES):
                continue                                           # rolki w buildzie są celowe (fuzja w „rolkę”)
            b0, b1 = m.sec_range(s)
            c = r["cnt"][b0:b1]
            act = c[c > 0]
            if len(act) < 3:
                continue
            p90 = float(np.percentile(act / m.bar_s, 90))
            lee = 1.0
            ch, hh = comfort * lee, hard * lee
            status, score = PN.judge(p90, None, ch, None, hh)
            key = r["name"]
            cur = worst.get(key)
            if cur is None or score < cur["score"] or (score == cur["score"] and p90 / ch > cur["value"] / cur["ch"]):
                worst[key] = dict(r=r, s=s, st=st, value=p90, ch=ch, hh=hh, score=score)
    for key, w in worst.items():
        r = w["r"]
        norm = (None, w["ch"], None, w["hh"])
        epb = w["value"] * 60.0 / m.bpm
        hint = (f"przy {_f(m.bpm, 0)} BPM to ok. {_f(epb, 1)} zd./ćwierćnutę (siatka {PN.grid_label(epb)}); "
                f"dla roli „{PN.ROLE_PL[r['role']]}” komfortowo najwyżej {PN.grid_ceiling(r['role'], m.bpm)['label']} stale")
        rows.append(_row("tempo", f"rate:{key}", f"Tempo zdarzeń: {key} ({PN.ROLE_PL[r['role']]})", w["value"], norm, "zd./s",
                         where=w["s"].get("name", w["st"]), hint=hint, fixable=not r["locked"], detail=dict(track=key, sec=w["s"].get("name"))))
    return rows


def _measure_tempo_totals(m: Model) -> list[dict]:
    rows = [_row("tempo", "bpm", "Tempo utworu", m.bpm, PN.NORMS["bpm"], "BPM",
                 hint="pulsacja najwyraźniejsza ok. 100–130 BPM; poniżej 70 i powyżej 180 maleje czytelność metrum")]
    drops = [s for s in m.secs if m.sec_type(s) == "drop"]
    if drops:
        tot = sum(sum(float(r["cnt"][slice(*m.sec_range(s))].sum()) for r in m.tr if r["role"] != "fx") for s in drops)
        dur = sum((m.sec_range(s)[1] - m.sec_range(s)[0]) * m.bar_s for s in drops)
        if dur > 0:
            rows.append(_row("tempo", "total_rate", "Łączna gęstość dropu", tot / dur, PN.NORMS["total_rate_drop"], "zd./s",
                             hint="suma uderzeń wszystkich torów (bez FX) na sekundę; za dużo = kłębowisko, za mało = pustka"))
    tl = m.p.get("tempo_link")
    if isinstance(tl, dict) and tl.get("drift") is not None:
        link = float(tl.get("link", 0.0))
        row = _row("tempo", "drift", f"Dryf intensywności względem tempa stylu ({_f(tl.get('ref_bpm', 0), 0)} BPM)",
                   float(tl["drift"]), PN.NORMS["tempo_drift"], "×",
                   hint=f"suwak Gęstość↔BPM: {tl.get('mode')}; 1,00 = tyle zdarzeń/s, ile zakładał styl",
                   info_only=link < -0.05)
        rows.append(row)
    return rows


def _lil_collisions(m: Model) -> tuple[int, list]:
    """Liczy kolizje w niskim rejestrze: dwie różne wysokości z RÓŻNYCH torów, zbyt blisko jak na niski rejestr."""
    bars_low: dict[int, list] = {}
    for ri, r in enumerate(m.tr):
        if r["role"] not in PN.MELODIC_ROLES:
            continue
        a = r["a"]
        sel = np.where((a[:, 2] < 55) & (a[:, 1] >= 0.4))[0]
        for i in sel:
            beat, dur, key = float(a[i, 0]), float(a[i, 1]), int(a[i, 2])
            for b in range(int(beat // 4), int(min(m.bars - 1, (beat + dur - 1e-6) // 4)) + 1):
                bars_low.setdefault(b, []).append((ri, int(i), beat, beat + dur, key))
    hits, seen = [], set()
    for b, lst in bars_low.items():
        n = len(lst)
        for x in range(n):
            ra, ia, s1, e1, k1 = lst[x]
            for y in range(x + 1, n):
                rb, ib, s2, e2, k2 = lst[y]
                if ra == rb or abs(k1 - k2) == 0 or abs(k1 - k2) >= 12:
                    continue
                if min(e1, e2) - max(s1, s2) < 0.25:
                    continue
                need = _lil_min(min(k1, k2))
                if abs(k1 - k2) < need:
                    key = (ra, ia, rb, ib)
                    if key not in seen:
                        seen.add(key)
                        hits.append(key)
    return len(hits), hits


def _stack_share(m: Model, roles: tuple, min_voices: int, sec_type: str = "drop") -> tuple[float, list]:
    """Udział ćwierćnut w sekcjach `sec_type`, w których GŁOŚNO (velocity ≥ AUDIBLE_VEL) gra ≥ min_voices torów z podanych ról;
    + lista (beat, [indeksy torów])."""
    tot = 0
    over = []
    for s in m.secs:
        if m.sec_type(s) != sec_type:
            continue
        b0, b1 = m.sec_range(s)
        for beat in range(b0 * 4, b1 * 4):
            tot += 1
            who = [i for i, r in enumerate(m.tr) if r["role"] in roles and r["occ_loud"][beat]]
            if len(who) >= min_voices:
                over.append((beat, who))
    return (len(over) / tot if tot else 0.0), over


def _measure_clarity(m: Model) -> list[dict]:
    rows = []
    n, hits = _lil_collisions(m)
    per100 = n * 100.0 / max(1, m.bars)
    rows.append(_row("clarity", "low_collisions", "Kolizje w niskim rejestrze", per100, PN.NORMS["low_collisions_per_100bars"], "/100 taktów",
                     hint="dwie różne wysokości z różnych torów poniżej ok. G2 zbyt blisko siebie (pasmo krytyczne ~100 Hz) = błoto; "
                          "korekta przenosi słabszy głos oktawę wyżej",
                     fixable=n > 0, detail=hits))
    if any(r["role"] == "bass" for r in m.tr):
        sh, over = _stack_share(m, ("bass",), 3)
        rows.append(_row("clarity", "bass_stack", "Równoległe basy (≥3 naraz) w dropie", sh, PN.NORMS["bass_stack_share"], "udział",
                         hint="trzy głośne basy naraz maskują się nawzajem; korekta spycha najsłabsze do tła (velocity ≤ 66)", fixable=sh > 0, detail=over))
    fg = [r for r in m.tr if r["role"] in PN.FOREGROUND_ROLES]
    if len(fg) >= 3:
        sh, over = _stack_share(m, PN.FOREGROUND_ROLES, 3)
        rows.append(_row("clarity", "foreground", "Równoległe leady (≥3 naraz) w dropie", sh, PN.NORMS["foreground_overlap"], "udział",
                         hint="uwaga słuchacza obsłuży 1–2 linie pierwszoplanowe; korekta spycha najsłabsze do tła (velocity ≤ 66)", fixable=sh > 0, detail=over))
    names = {r["name"] for r in m.tr}
    if any(r["type"] == "kick" for r in m.tr):
        try:
            from . import generator as G
            heavy = [r for r in m.tr if G.DUCK.get(r["type"], 0.0) >= 0.7 and r["role"] == "bass"]
        except Exception:
            heavy = []
        linked = {l.get("dst") for l in (m.p.get("links") or []) if l.get("src") == "kick"}
        missing = [r["name"] for r in heavy if r["name"] not in linked and r["name"] in names]
        rows.append(_row("clarity", "missing_duck", "Basy bez sidechainu od stopy", float(len(missing)), PN.NORMS["missing_duck"], "szt.",
                         where=", ".join(missing), hint="stopa i bas dzielą pasmo sub; bez ducking stopa i bas się maskują"))
    return rows


def _measure_vibe(m: Model) -> list[dict]:
    rows = []
    p = m.p
    try:
        from . import core
        sc = core.SCALES.get(p.get("scale"))
    except Exception:
        sc = None
    if sc is not None and p.get("key") is not None:
        pcs = {(int(p["key"]) + iv) % 12 for iv in sc}
        inn = tot = 0
        for r in m.tr:
            if r["role"] not in ("bass", "lead", "mallet", "pad"):
                continue
            keys = r["a"][:, 2].astype(int) % 12
            inn += int(np.isin(keys, list(pcs)).sum())
            tot += len(keys)
        if tot:
            rows.append(_row("vibe", "scale", "Zgodność ze skalą utworu", inn / tot, PN.NORMS["scale_conformity"], "udział",
                             hint="nuty melodyczne spoza skali (poza celowymi chromatykami) rozmywają klimat"))
    ch = p.get("chords") or []
    if ch:
        runs, cur = [], 1
        for i in range(1, len(ch)):
            if ch[i] == ch[i - 1]:
                cur += 1
            else:
                runs.append(cur)
                cur = 1
        runs.append(cur)
        med = float(np.median(runs)) * m.bar_s
        static = len(runs) == 1
        norm = PN.NORMS["harmonic_rhythm_s"]
        fam = (p.get("climate") or {}).get("family")
        if fam == "space":                                          # ambient/space: dłuższe akordy są stylem
            norm = (norm[0], norm[1] * 2.0, norm[2], norm[3] * 2.0)
        rows.append(_row("vibe", "harm_rhythm", "Rytm harmoniczny (czas akordu)", med, norm, "s",
                         hint=("jeden akord przez cały utwór (styl modalny/minimalistyczny) — nie oceniam" if static else
                               "akord krócej niż ~1,5 s nie zdąży zabrzmieć jako harmonia, dłużej niż ~8 s słuchacz traci poczucie ruchu"),
                         info_only=static))
    sigs_total = rep_total = 0
    for r in m.tr:
        if r["role"] not in ("lead", "bass", "mallet") or r["type"] in ("sub", "drone"):
            continue
        a = r["a"]
        bi = (a[:, 0] // 4).astype(int)
        by: dict[int, list] = {}
        for x, b in zip(a, bi):
            by.setdefault(int(b), []).append((int(round((x[0] - 4 * b) * 4)), int(x[2])))
        hist: list = []
        for s in m.secs:
            if m.sec_type(s) != "drop":
                continue
            for b in range(*m.sec_range(s)):
                sig = tuple(sorted(by.get(b, [])))
                if len(sig) < 2:
                    continue
                prev = [h for h in hist[-8:]]
                sigs_total += 1
                if sig in prev:
                    rep_total += 1
                hist.append(sig)
    if sigs_total >= 8:
        rows.append(_row("vibe", "motif", "Powtarzalność motywów w dropach", rep_total / sigs_total, PN.NORMS["motif_repetition"], "udział",
                         hint="motyw musi wracać, żeby zapadł w pamięć, ale nie w każdym takcie; poza normą = chaos albo monotonia"))
    reg = {"bass": (28 - 12, 72), "lead": (58 - 12, 86 + 12), "mallet": (58 - 12, 86 + 12), "pad": (45 - 12, 67 + 12)}
    inn = tot = 0
    for r in m.tr:
        if r["role"] in reg:
            lo, hi = reg[r["role"]]
            keys = r["a"][:, 2]
            inn += int(((keys >= lo) & (keys <= hi)).sum())
            tot += len(keys)
    if tot:
        rows.append(_row("vibe", "register", "Rejestr partii (bas/lead/pad)", inn / tot, PN.NORMS["register_fit"], "udział",
                         hint="partie poza swoim rejestrem wchodzą w pasma innych ról (maskowanie) albo giną"))
    return rows


def _measure_arrangement(m: Model) -> list[dict]:
    rows = []
    by_type: dict[str, list] = {}
    for s in m.secs:
        st = m.sec_type(s)
        if st not in PN.STREAMS:
            continue
        b0, b1 = m.sec_range(s)
        for b in range(b0, b1):
            n = sum(1 for r in m.tr if r["role"] in PN.MELODIC_ROLES and r["occ_bar"][b])
            n += 1 if any(r["role"] in PN.PERC_ROLES and r["occ_bar"][b] for r in m.tr) else 0
            by_type.setdefault(st, []).append(n)
    for st, vals in by_type.items():
        lo, hi, hlo, hhi = PN.STREAMS[st]
        rows.append(_row("arrangement", f"streams:{st}", f"Strumienie naraz — {st}", float(np.mean(vals)), (lo, hi, hlo, hhi), "szt.",
                         hint="perkusja liczy się jako jeden strumień, każdy bas/lead/pad osobno; pojemność uwagi ~4±1",
                         fixable=float(np.mean(vals)) > hi, detail=st))
    worst_enter, worst_bar = 0, None
    for s in m.secs:
        if m.sec_type(s) not in ("intro", "build"):
            continue
        b0, b1 = m.sec_range(s)
        for b in range(max(1, b0), b1):
            ent = []
            drum = False
            for i, r in enumerate(m.tr):
                if r["role"] == "fx" or not r["occ_bar"][b] or r["occ_bar"][b - 1]:
                    continue
                if r["role"] in PN.PERC_ROLES:
                    if not drum:
                        drum = True
                        ent.append(i)
                else:
                    ent.append(i)
            if len(ent) > worst_enter:
                worst_enter, worst_bar = len(ent), (b, ent, s.get("name"))
    if m.secs:
        rows.append(_row("arrangement", "entrances", "Wejścia nowych strumieni w jednym takcie (intro/build)", float(worst_enter),
                         PN.NORMS["entrances_per_bar"], "szt.", where=(f"takt {worst_bar[0] + 1}, {worst_bar[2]}" if worst_bar else ""),
                         hint="nowe partie powinny wchodzić po 1–2 na takt, żeby ucho zdążyło je „zaklasyfikować”",
                         fixable=worst_enter > 2, detail=worst_bar))
    slopes = []
    for s in m.secs:
        if m.sec_type(s) == "build":
            b0, b1 = m.sec_range(s)
            if b1 - b0 >= 4:
                mid = (b0 + b1) // 2
                early, late = m.intensity(b0, mid), m.intensity(mid, b1)
                if early > 0:
                    slopes.append(late / early)
    if slopes:
        rows.append(_row("arrangement", "build_slope", "Narastanie buildu (koniec / początek)", float(np.mean(slopes)), PN.NORMS["build_slope"], "×",
                         hint="build bez narastania nie buduje napięcia przed dropem", fixable=float(np.mean(slopes)) < 1.15))
    di = [m.intensity(*m.sec_range(s)) for s in m.secs if m.sec_type(s) == "drop"]
    bi_ = [m.intensity(*m.sec_range(s)) for s in m.secs if m.sec_type(s) == "break"]
    if di and bi_ and np.mean(bi_) > 0:
        ratio = float(np.mean(di) / np.mean(bi_))
        rows.append(_row("arrangement", "contrast", "Kontrast drop ↔ przerwa (intensywność)", ratio, PN.NORMS["drop_break_contrast"], "×",
                         hint="drop uderza dopiero na tle ciszy/oddechu; zbyt mały kontrast spłaszcza łuk utworu", fixable=ratio < 1.3))
    ev = []
    for r in m.tr:
        if r["role"] not in ("fx", "hat"):
            ev.append((float(r["cnt"].sum()) / m.total_events, r["name"]))
    if ev:
        top = max(ev)
        rows.append(_row("arrangement", "event_share", "Dominacja jednego toru w zdarzeniach", top[0], PN.NORMS["event_share_top"], "udział",
                         where=top[1], hint="jeden tor pochłaniający prawie wszystkie uderzenia zabiera pole pozostałym"))
    return rows


# ============================================================================= pomiar audio (opcjonalny)
def measure_audio(proj: dict, max_sec: float = 20.0) -> tuple[list[dict], dict]:
    """Render miksu w pamięci + listen.analyze_audio → wiersze o pasmach, crest, dynamice, głośności i szerokości."""
    from . import core, listen as L
    from . import musicality_reviewer as MR
    mix = core.render_mix(proj, workers=1)
    if mix is None or len(mix) < 4096:
        return [], {}
    sr = core.SR
    n = int(max_sec * sr)
    if len(mix) > n:
        s0 = (len(mix) - n) // 2
        mix = mix[s0: s0 + n]
    F = L.analyze_audio(mix, rate=sr)
    if F.get("silent"):
        return [], F
    rows = []
    fam = (proj.get("climate") or {}).get("family") or "default"
    target = MR.BAND_TARGETS.get(fam, MR.BAND_TARGETS["default"])
    bands = F.get("bands") or {}
    tot = sum(float(v) for v in bands.values()) or 1.0
    cur = {k: float(v) / tot for k, v in bands.items()}
    dev = sum(abs(cur.get(k, 0.0) - target.get(k, 0.0)) for k in target) / 2.0
    worst = max(target, key=lambda k: abs(cur.get(k, 0.0) - target.get(k, 0.0)))
    rows.append(_row("clarity", "audio_bands", f"Bilans pasm vs cel rodziny „{fam}”", dev, (None, 0.25, None, 0.50), "rozjazd",
                     where=f"najbardziej: {worst} ({_f(cur.get(worst, 0) * 100, 0)}% vs {_f(target[worst] * 100, 0)}%)",
                     hint="0 = widmo dokładnie jak cel gatunku; to udział energii „w złym paśmie”"))
    rows.append(_row("clarity", "audio_width", "Szerokość stereo (side/(mid+side))", float(F.get("width", 0.0)), (0.05, 0.45, 0.0, 0.70), "",
                     hint="mono-sumowalność i przestrzeń: prawie mono = płasko, bardzo szeroko = problemy po zsumowaniu"))
    rows.append(_row("vibe", "audio_crest", "Crest factor miksu", float(F.get("crest_db", 0.0)), (7.0, 16.0, 5.0, 20.0), "dB",
                     hint="różnica szczyt–RMS: mało = zmiażdżony miks, dużo = bardzo cichy w stosunku do szczytów"))
    rows.append(_row("vibe", "audio_dyn", "Zakres dynamiki krótkoterminowej", float(F.get("dyn_db", 0.0)), (4.0, 14.0, 2.0, 20.0), "dB",
                     hint="różnica P95–P10 głośności w oknach 0,4 s; muzyka klubowa ok. 4–14 dB"))
    rows.append(_row("vibe", "audio_rms", "Poziom RMS miksu", float(F.get("rms_db", -60.0)), (-22.0, -9.0, -30.0, -5.0), "dBFS",
                     hint="orientacyjnie; docelowa głośność i tak ustawia mastering"))
    rows.append(_row("tempo", "audio_onsets", "Zdarzenia na sekundę (z nagrania)", float(F.get("onsets_s", 0.0)), (1.5, 14.0, 0.8, 20.0), "zd./s",
                     hint="to samo co tempo zdarzeń, ale zmierzone w gotowym dźwięku"))
    return rows, F


# ============================================================================= ocena
def _score(rows: list[dict]) -> dict:
    crit = {}
    for cid, (label, w) in PN.CRITERIA.items():
        sc = [r["score"] for r in rows if r["crit"] == cid and r["status"] != "info"]
        if sc:
            val = 0.65 * (sum(sc) / len(sc)) + 0.35 * min(sc)
        else:
            val = None
        crit[cid] = dict(label=label, weight=w, score=None if val is None else round(val, 1), n=len(sc),
                         warn=sum(1 for r in rows if r["crit"] == cid and r["status"] == "warn"),
                         fail=sum(1 for r in rows if r["crit"] == cid and r["status"] == "fail"))
    have = [(c["weight"], c["score"]) for c in crit.values() if c["score"] is not None]
    wsum = sum(w for w, _ in have) or 1.0
    total = sum(w * s for w, s in have) / wsum if have else 0.0
    return dict(criteria=crit, score=round(total, 1), grade=PN.grade_for(total))


def evaluate(proj: dict, audio: bool = False) -> dict:
    """Pomiar + raport (bez zmiany projektu)."""
    m = Model(proj)
    rows: list[dict] = []
    if not m.tr:
        return dict(version=VERSION, empty=True, score=0.0, grade=PN.GRADES[-1][1], criteria={}, findings=[], bpm=m.bpm)
    rows += _measure_tempo_totals(m)
    rows += _measure_rates(m)
    rows += _measure_clarity(m)
    rows += _measure_vibe(m)
    rows += _measure_arrangement(m)
    audio_feats = {}
    if audio:
        try:
            ar, audio_feats = measure_audio(proj)
            rows += ar
        except Exception as e:                                     # render może się nie udać (brak wtyczek) — raport bez audio
            audio_feats = {"error": str(e)}
    sc = _score(rows)
    rep = dict(version=VERSION, bpm=m.bpm, style=proj.get("style"), name=proj.get("name"), bars=m.bars,
               seconds=round(m.bars * m.bar_s, 1), tempo_link=proj.get("tempo_link"),
               grid=PN.grid_table(m.bpm), findings=rows, audio=bool(audio) and not audio_feats.get("error"), **sc)
    return rep


# ============================================================================= korekty (sterowane raportem)
def _imp(beat: float, vel: float, rng: random.Random) -> float:
    """Ważność nuty przy przerzedzaniu: pozycja w takcie (mocna > ósemka > szesnastka > reszta), velocity, minimalny los."""
    fr = beat - math.floor(beat)
    if fr < 0.06:
        pos = 3.0
    elif abs(fr - 0.5) < 0.1:
        pos = 2.0
    elif abs(fr * 4 - round(fr * 4)) < 0.05:
        pos = 1.0
    else:
        pos = 0.5
    return pos + 0.5 * (vel / 127.0) + 0.001 * rng.random()


def _fix_rates(proj: dict, m: Model, rng: random.Random, log: list) -> int:
    """Przerzedza tory, których p90 tempa zdarzeń przekracza komfort dla BPM. Fille (≤10 % najgęstszych taktów) zostają."""
    changed = 0
    for r in m.tr:
        if r["locked"] or r["role"] == "fx":
            continue
        comfort, _ = PN.RATE_NORMS.get(r["role"], PN.RATE_NORMS["lead"])
        t = r["t"]
        notes = t["notes"]
        by_bar: dict[int, list[int]] = {}
        for i, n in enumerate(notes):
            by_bar.setdefault(int(n[0] // 4), []).append(i)
        drop_idx: set[int] = set()
        for s in m.secs:
            st = m.sec_type(s)
            if st not in PN.GRADED_SECTIONS or (st == "build" and r["role"] in PN.PERC_ROLES):
                continue                                           # rolki w buildzie są celowe
            lee = 1.0
            cap = max(1, int(math.floor(comfort * lee * m.bar_s)))
            b0, b1 = m.sec_range(s)
            active = [(b, len(by_bar.get(b, []))) for b in range(b0, b1) if by_bar.get(b)]
            if len(active) < 3:
                continue
            p90 = float(np.percentile([c / m.bar_s for _, c in active], 90))
            if p90 <= comfort * lee:
                continue
            ranked = sorted(active, key=lambda x: -x[1])
            exempt = {b for b, _ in ranked[: int(0.10 * (len(active) - 1))]}      # fille; p90 po korekcie ≤ komfort
            removed_here = 0
            for b, c in active:
                if b in exempt or c <= cap:
                    continue
                idx = by_bar[b]
                scored = sorted(idx, key=lambda i: _imp(notes[i][0], notes[i][3], rng))
                for i in scored[: c - cap]:
                    drop_idx.add(i)
                    removed_here += 1
            if removed_here:
                log.append(dict(action="przerzedzenie", track=r["name"], section=s.get("name"), notes=removed_here,
                                reason=f"p90 {_f(p90)} zd./s > komfort {_f(comfort * lee)} zd./s przy {_f(m.bpm, 0)} BPM"))
        if drop_idx:
            t["notes"] = [n for i, n in enumerate(notes) if i not in drop_idx]
            changed += len(drop_idx)
    return changed


def _fix_lil(proj: dict, m: Model, hits: list, rng: random.Random, log: list) -> int:
    """Kolizje w niskim rejestrze: słabszy głos o oktawę wyżej (a gdy się nie mieści — nuta znika)."""
    moves: dict[tuple, str] = {}
    for ra, ia, rb, ib in hits:
        A, B = m.tr[ra], m.tr[rb]
        ka, kb = int(A["a"][ia, 2]), int(B["a"][ib, 2])
        if A["prio"] != B["prio"]:
            lo_, hi_ = (A, ia, ka), (B, ib, kb)
            weak = lo_ if A["prio"] < B["prio"] else hi_
        else:
            weak = (A, ia, ka) if ka > kb else (B, ib, kb)
        r, i, k = weak
        if r["locked"]:
            strong = (B, ib, kb) if weak[0] is A else (A, ia, ka)
            if strong[0]["locked"]:
                continue
            weak = strong
            r, i, k = weak
        moves[(r["i"], i)] = "up"
    changed = 0
    per_track: dict[int, set] = {}
    for (ri, i), _ in moves.items():
        per_track.setdefault(ri, set()).add(i)
    for ri, idxs in per_track.items():
        r = m.tr[ri]
        t = r["t"]
        a = r["a"]
        # a ma te same indeksy co t["notes"] tylko gdy nie odfiltrowano nut spoza zakresu — mapujemy po (beat, key)
        look = {(round(float(a[i, 0]), 4), int(a[i, 2])): i for i in idxs}
        new, n_up, n_del = [], 0, 0
        for n in t["notes"]:
            kk = (round(float(n[0]), 4), int(n[2]))
            if kk in look:
                if int(n[2]) + 12 <= 84:
                    new.append(_with(n, key=int(n[2]) + 12))
                    n_up += 1
                else:
                    n_del += 1
                continue
            new.append(n)
        if n_up or n_del:
            t["notes"] = new
            changed += n_up + n_del
            log.append(dict(action="rozsunięcie kolizji w basie", track=r["name"], section="—", notes=n_up + n_del,
                            reason=f"{n_up} nut o oktawę wyżej, {n_del} usuniętych (low interval limit)"))
    return changed


def _attenuate_over(proj: dict, m: Model, over: list, roles: tuple, max_voices: int, rng: random.Random,
                    log: list, what: str) -> int:
    """Gdy na ćwierćnucie głośno gra więcej niż max_voices torów z roli — najsłabsze trafiają do tła (velocity ≤ BACKGROUND_VEL)
    na wszystkich nutach, które w tej ćwierćnucie brzmią. Zbieżne w jednym przebiegu (mierzona wielkość liczy tylko głośne nuty)."""
    per_track: dict[int, set] = {}
    for beat, who in over:
        who = sorted(who, key=lambda i: -m.tr[i]["prio"])
        for i in who[max_voices:]:
            if not m.tr[i]["locked"]:
                per_track.setdefault(i, set()).add(beat)
    changed = 0
    for i, beats in per_track.items():
        r = m.tr[i]
        n_ch = 0
        new = []
        for n in r["t"]["notes"]:
            if n[3] > BACKGROUND_VEL:
                b0 = int(n[0])
                b1 = max(b0 + 1, int(math.ceil(n[0] + max(float(n[1]), 0.05) - 1e-6)))
                if any(b in beats for b in range(b0, b1)):
                    n = _with(n, vel=BACKGROUND_VEL)
                    n_ch += 1
            new.append(n)
        if n_ch:
            r["t"]["notes"] = new
            changed += n_ch
            log.append(dict(action=f"spuszczenie do tła ({what})", track=r["name"], section="drop", notes=n_ch,
                            reason=f"velocity ≤ {BACKGROUND_VEL} w {len(beats)} ćwierćnutach, gdzie głośno grało więcej niż {max_voices}"))
    return changed


def _fix_entrances(proj: dict, m: Model, rng: random.Random, log: list) -> int:
    """Rozsuwa wejścia: najsłabsze nadmiarowe strumienie wchodzą 1–2 takty później (przez ciszę ich pierwszych taktów)."""
    changed = 0
    limit = int(PN.NORMS["entrances_per_bar"][1])
    for s in m.secs:
        if m.sec_type(s) not in ("intro", "build"):
            continue
        b0, b1 = m.sec_range(s)
        for b in range(max(1, b0), b1):
            ent = []
            drum = False
            for i, r in enumerate(m.tr):
                if r["role"] == "fx" or not r["occ_bar"][b] or r["occ_bar"][b - 1]:
                    continue
                if r["role"] in PN.PERC_ROLES:
                    if drum:
                        continue
                    drum = True
                ent.append(i)
            if len(ent) <= limit:
                continue
            cand = [i for i in sorted(ent, key=lambda i: m.tr[i]["prio"]) if m.tr[i]["role"] not in PN.PERC_ROLES
                    and not (m.tr[i]["role"] == "bass" and m.tr[i]["rank"] == 0) and not m.tr[i]["locked"]]
            for k, i in enumerate(cand[: len(ent) - limit]):
                delay = 1 + k
                if b + delay >= b1 - 1:
                    continue
                r = m.tr[i]
                lo, hi = b * 4, (b + delay) * 4
                keep = [n for n in r["t"]["notes"] if not (lo <= n[0] < hi)]
                rem = len(r["t"]["notes"]) - len(keep)
                if rem:
                    r["t"]["notes"] = keep
                    changed += rem
                    log.append(dict(action="rozsunięcie wejścia", track=r["name"], section=s.get("name"), notes=rem,
                                    reason=f"w takcie {b + 1} wchodziło {len(ent)} strumieni; ten wchodzi {delay} takt(y) później"))
    return changed


def _fix_contrast(proj: dict, m: Model, rng: random.Random, log: list) -> int:
    """Przerwy: ściszenie leadów/perkusjonaliów i przerzedzenie hatów, żeby drop uderzał mocniej na tle oddechu."""
    changed = 0
    for s in m.secs:
        if m.sec_type(s) != "break":
            continue
        b0, b1 = m.sec_range(s)
        for r in m.tr:
            if r["locked"] or r["role"] not in ("lead", "mallet", "perc", "hat", "pad"):
                continue
            t = r["t"]
            lo, hi = b0 * 4, b1 * 4
            n_ch = 0
            new = []
            for n in t["notes"]:
                if lo <= n[0] < hi:
                    nv = max(1, int(round(n[3] * 0.8)))
                    if nv != n[3]:
                        n = _with(n, vel=nv)
                        n_ch += 1
                new.append(n)
            t["notes"] = new
            if r["role"] == "hat":
                idx = [i for i, n in enumerate(t["notes"]) if lo <= n[0] < hi]
                scored = sorted(idx, key=lambda i: _imp(t["notes"][i][0], t["notes"][i][3], rng))
                kill = set(scored[: int(0.3 * len(scored))])
                if kill:
                    t["notes"] = [n for i, n in enumerate(t["notes"]) if i not in kill]
                    n_ch += len(kill)
            if n_ch:
                changed += n_ch
                log.append(dict(action="kontrast przerwy", track=r["name"], section=s.get("name"), notes=n_ch,
                                reason="drop ↔ przerwa poniżej normy: ściszenie (×0,8) i przerzedzenie hatu"))
    return changed


def _fix_build_slope(proj: dict, m: Model, rng: random.Random, log: list) -> int:
    """Build: rampa velocity 0,82 → 1,10 (poza FX), żeby intensywność realnie narastała."""
    changed = 0
    for s in m.secs:
        if m.sec_type(s) != "build":
            continue
        b0, b1 = m.sec_range(s)
        if b1 - b0 < 4:
            continue
        lo, hi = b0 * 4, b1 * 4
        sec_ch = 0
        for r in m.tr:
            if r["locked"] or r["role"] in ("fx", "kick", "backbeat"):       # pulsu stopy/werbla nie ruszamy (niezależność od reszty)
                continue
            n_ch = 0
            new = []
            for n in r["t"]["notes"]:
                if lo <= n[0] < hi:
                    p = (n[0] - lo) / (hi - lo)
                    nv = max(1, min(127, int(round(n[3] * (0.82 + 0.28 * p)))))
                    if nv != n[3]:
                        n = _with(n, vel=nv)
                        n_ch += 1
                new.append(n)
            if n_ch:
                r["t"]["notes"] = new
                sec_ch += n_ch
        if sec_ch:
            changed += sec_ch
            log.append(dict(action="rampa narastania buildu", track="(wszystkie)", section=s.get("name"), notes=sec_ch,
                            reason="intensywność końca buildu nie przewyższała początku o normę"))
    return changed


def _apply_fixes(proj: dict, rows: list[dict], rng: random.Random, log: list, done: dict | None = None) -> int:
    """Stosuje korekty wskazane przez raport. `done` zlicza użycia: każda korekta najwyżej raz (LIL — dwa razy),
    żeby przebiegi nie kumulowały np. ściszeń."""
    done = done if done is not None else {}
    def ok_to(name, limit=1):
        if done.get(name, 0) >= limit:
            return False
        done[name] = done.get(name, 0) + 1
        return True
    m = Model(proj)
    by_id = {r["id"]: r for r in rows}
    changed = 0
    if any(r["fixable"] and r["status"] != "ok" and r["id"].startswith("rate:") for r in rows) and ok_to("rates"):
        changed += _fix_rates(proj, m, rng, log)
        m = Model(proj)
    r = by_id.get("low_collisions")
    if r and r["fixable"] and r["status"] != "ok" and ok_to("lil", 2):
        n, hits = _lil_collisions(m)
        changed += _fix_lil(proj, m, hits, rng, log)
        m = Model(proj)
    r = by_id.get("bass_stack")
    if r and r["fixable"] and r["status"] != "ok" and ok_to("bass_stack"):
        _, over = _stack_share(m, ("bass",), 3)
        changed += _attenuate_over(proj, m, over, ("bass",), 2, rng, log, "basy")
    r = by_id.get("foreground")
    if r and r["fixable"] and r["status"] != "ok" and ok_to("foreground"):
        _, over = _stack_share(m, PN.FOREGROUND_ROLES, 3)
        changed += _attenuate_over(proj, m, over, PN.FOREGROUND_ROLES, 2, rng, log, "leady")
    ent = by_id.get("entrances")
    stre = [x for x in rows if x["id"] in ("streams:intro", "streams:build") and x["status"] != "ok"]
    if ((ent and ent["status"] != "ok") or stre) and ok_to("entrances"):
        m = Model(proj)
        changed += _fix_entrances(proj, m, rng, log)
    r = by_id.get("contrast")
    if r and r["fixable"] and r["status"] != "ok" and ok_to("contrast"):
        m = Model(proj)
        changed += _fix_contrast(proj, m, rng, log)
    r = by_id.get("build_slope")
    if r and r["fixable"] and r["status"] != "ok" and ok_to("build_slope"):
        m = Model(proj)
        changed += _fix_build_slope(proj, m, rng, log)
    return changed


# ============================================================================= wejście główne
def run(proj: dict, cfg=None, rng: random.Random | None = None, audio: bool | None = None) -> dict:
    """Egzamin: raport PRZED → (gdy tryb „fix”) korekty sterowane raportem → raport PO. Zapis w proj['exam_report']."""
    c = _cfg(cfg if cfg is not None else proj.get("exam"))
    if c["mode"] == "off":
        return {}
    use_audio = bool(c["audio"] if audio is None else audio)
    rng = rng or random.Random(f"exam:{proj.get('seed', 0)}")
    first = evaluate(proj, audio=False)
    rep, log, done = first, [], {}
    passes = 0
    if c["mode"] == "fix" and not first.get("empty"):
        for passes in range(1, c["max_passes"] + 1):
            todo = [r for r in rep["findings"] if r["status"] in ("warn", "fail") and r["fixable"]]
            if not todo:
                passes -= 1
                break
            changed = _apply_fixes(proj, rep["findings"], rng, log, done)
            rep = evaluate(proj, audio=False)
            if not changed:
                break
    if use_audio and not rep.get("empty"):
        rep = evaluate(proj, audio=True)
    rep = dict(rep)
    rep["mode"] = c["mode"]
    rep["passes"] = passes
    rep["fixes"] = log
    rep["before"] = dict(score=first.get("score"), grade=first.get("grade"),
                         criteria={k: v.get("score") for k, v in (first.get("criteria") or {}).items()})
    for r in rep["findings"]:
        r.pop("detail", None)                         # szczegóły techniczne nie mają trafiać do JSON projektu
    proj["exam_report"] = rep
    proj["exam"] = {"mode": c["mode"], "max_passes": c["max_passes"], "audio": use_audio}
    return rep


# ============================================================================= raport tekstowy
_ICON = {"ok": "✓", "warn": "!", "fail": "✗", "info": "i"}


def format_report(rep: dict, verbose: bool = False) -> str:
    if not rep:
        return "Egzamin producencki wyłączony."
    if rep.get("empty"):
        return "Egzamin producencki: brak nut do oceny."
    L = []
    nm = rep.get("name") or rep.get("style") or "utwór"
    L.append(f"EGZAMIN PRODUCENCKI — {nm} · {_f(rep['bpm'], 0)} BPM · {rep.get('bars')} taktów (~{_f(rep.get('seconds', 0), 0)} s)")
    bef = rep.get("before") or {}
    line = f"Wynik: {_f(rep['score'], 0)}/100 — {rep['grade']}"
    if bef.get("score") is not None and rep.get("fixes"):
        line += f"   (przed korektą: {_f(bef['score'], 0)}/100 — {bef.get('grade')})"
    L.append(line)
    crit = rep.get("criteria") or {}
    parts = []
    for cid, c in crit.items():
        if c.get("score") is not None:
            b = (bef.get("criteria") or {}).get(cid)
            tail = f" ← {_f(b, 0)}" if (b is not None and rep.get("fixes") and abs(b - c["score"]) >= 1) else ""
            parts.append(f"{c['label']} {_f(c['score'], 0)}{tail}")
    L.append("Kryteria: " + " · ".join(parts))
    tl = rep.get("tempo_link")
    if isinstance(tl, dict):
        L.append(f"Gęstość↔BPM: {tl.get('link', 0):+.2f}".replace(".", ",") + f" w skali −1…+1 ({tl.get('mode')}); tempo projektowe stylu {_f(tl.get('ref_bpm', 0), 0)} BPM, "
                 f"mnożnik gęstości ×{_f(tl.get('mul', 1), 2)}, dryf zd./s ×{_f(tl.get('drift', 1), 2)}")
    g = rep.get("grid") or {}
    if g:
        L.append("Siatka dozwolona przez BPM (najdrobniejsza stale komfortowa): " + " · ".join(
            f"{PN.ROLE_PL[r]} {v['label']} (≤{_f(v['hz'], 1)} zd./s)" for r, v in g.items() if r in PN.ROLE_PL))
    rows = rep.get("findings") or []
    bad = [r for r in rows if r["status"] in ("warn", "fail")]
    L.append("")
    if bad:
        L.append("Uwagi (poza normą po korekcie):" if rep.get("fixes") else "Uwagi (poza normą):")
        for r in sorted(bad, key=lambda r: r["score"]):
            where = f" [{r['where']}]" if r.get("where") else ""
            L.append(f" {_ICON[r['status']]} {r['label']}{where}: {_f(r['value'], 2)} {r['unit']} — norma {r['norm']}")
            if r.get("hint"):
                L.append(f"     {r['hint']}")
    else:
        L.append("Wszystkie wskaźniki mieszczą się w normach percepcji.")
    ok = [r for r in rows if r["status"] == "ok"]
    if verbose and ok:
        L.append("")
        L.append("W normie:")
        for r in ok:
            where = f" [{r['where']}]" if r.get("where") else ""
            L.append(f" ✓ {r['label']}{where}: {_f(r['value'], 2)} {r['unit']}")
    elif ok:
        L.append(f"\nW normie: {len(ok)} wskaźników (pełna lista: verbose).")
    fx = rep.get("fixes") or []
    if fx:
        L.append("")
        L.append(f"Korekty ({rep.get('passes', 1)} przebieg/i):")
        for f_ in fx[:40]:
            L.append(f" • {f_['action']}: {f_['track']} · {f_['section']} — {f_['notes']} nut ({f_['reason']})")
        if len(fx) > 40:
            L.append(f" … i {len(fx) - 40} kolejnych")
    return "\n".join(L)
