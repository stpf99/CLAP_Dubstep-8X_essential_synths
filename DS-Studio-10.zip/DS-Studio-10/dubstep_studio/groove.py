"""groove.py — mikro-timing i velocity z korpusu (np. Groove MIDI Dataset) → structure_vel.

Groove MIDI Dataset (Magenta, dane — nie pip; pobierz osobno i wskaż katalog plików .mid)
to nagrania perkusji z „ludzkim” mikro-timingiem i dynamiką. Ten moduł uczy z niego
statystyki per rola DS i podmienia ludzkie rozrzuty w generator.structure_vel:

  • velocity per pozycja w takcie (16-tki): akcenty tam, gdzie gra człowiek;
  • mikro-timing: odchyłki onsetów od siatki (w ułamkach 16-tki → w bitach);
  • globalny rozrzut velocity per rola (dla ról spoza 16-tk).

Całkowicie OPCJONALNE (mido jak w midi_import.py). Bez korpusu / bez mido
structure_vel działa po staremu — rdzeń Studia bez zmian.

Włączenie:
  • kod: groove.set_groove(groove.learn(glob("…/groove/*.mid")))
  • env:  DS_GROOVE_JSON=/ścieżka/groove.json  (leniwie ładowane przy pierwszym użyciu)
  • CLI:  python3 -m dubstep_studio groove --dir "…/groove" --out ~/.ds_groove.json
         (potem ustaw DS_GROOVE_JSON albo użyj set_groove przy starcie)
"""
from __future__ import annotations

import collections
import json
import os
import random
import statistics
from pathlib import Path

try:  # opcjonalnie, jak mido w midi_import.py
    import mido
except ImportError:  # pragma: no cover
    mido = None

ENV_JSON = "DS_GROOVE_JSON"
MAX_OFF_BEATS = 0.06          # bezpieczna górna belka mikro-timinu (w bitach)

_stats = None                 # globalny GrooveStats | None
_loaded = False


# ---------------------------------------------------------------------------
# Nauka statystyk z korpusu
# ---------------------------------------------------------------------------
class GrooveStats:
    VERSION = 1

    def __init__(self, roles: dict, files: int = 0, notes: int = 0):
        # roles[ds_type] = {"vel": [[mean, std] × 16], "off": [[mean, std] × 16],
        #                  "vel_all": [mean, std], "n": count}
        self.roles = roles
        self.files = files
        self.notes = notes

    @classmethod
    def train(cls, paths, max_files: int = 4096) -> "GrooveStats":
        """Uczy statystyki z plików MIDI (perkusja GM; role DS przez midi_import.GM_DRUM)."""
        if mido is None:
            raise RuntimeError("Brak biblioteki mido — zainstaluj: pip install mido")
        from . import midi_import as MI
        roles: dict[str, dict] = {}
        n_files = n_notes = 0
        for p in list(paths)[:max_files]:
            try:
                mid = mido.MidiFile(str(p))
                tpb = mid.ticks_per_beat or 480
            except Exception:
                continue
            n_files += 1
            for tr in mid.tracks:
                abs_tick = 0
                notes_on = {}
                for msg in tr:
                    abs_tick += msg.time
                    if msg.type == "note_on" and msg.velocity > 0:
                        notes_on[(getattr(msg, "channel", 0), msg.note)] = (abs_tick, msg.velocity)
                    elif msg.type in ("note_off", "note_on"):
                        key = (getattr(msg, "channel", 0), getattr(msg, "note", 0))
                        if key in notes_on:
                            st, vel = notes_on.pop(key)
                            role = MI.GM_DRUM.get(key[1])
                            if role is None:
                                continue
                            d = roles.setdefault(role, {"v": [[] for _ in range(16)],
                                                         "o": [[] for _ in range(16)], "all": []})
                            on_beat = st / tpb
                            step = on_beat / 0.25
                            pos = int(round(step)) % 16
                            off = step - round(step)          # w ułamkach 16-tki
                            d["v"][pos].append(vel)
                            d["o"][pos].append(off)
                            d["all"].append(vel)
                            n_notes += 1
        out = {}
        for role, d in roles.items():
            v = [[round(statistics.mean(xs), 1) if xs else 0.0,
                  round(statistics.pstdev(xs), 1) if len(xs) > 1 else 0.0] for xs in d["v"]]
            o = [[round(statistics.mean(xs), 4) if xs else 0.0,
                  round(statistics.pstdev(xs), 3) if len(xs) > 1 else 0.0] for xs in d["o"]]
            out[role] = {"vel": v, "off": o,
                         "vel_all": [round(statistics.mean(d["all"]), 1) if d["all"] else 96.0,
                                     round(statistics.pstdev(d["all"]), 1) if len(d["all"]) > 1 else 0.0],
                         "n": len(d["all"])}
        return cls(out, n_files, n_notes)

    # -- serializacja ------------------------------------------------------
    def save(self, path: str) -> str:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"version": self.VERSION, "files": self.files, "notes": self.notes,
                       "roles": self.roles}, f)
        return path

    @classmethod
    def load(cls, path: str) -> "GrooveStats":
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return cls(d.get("roles") or {}, int(d.get("files") or 0), int(d.get("notes") or 0))

    def summary(self) -> str:
        top = ", ".join(f"{r}:{v['n']}" for r, v in sorted(self.roles.items())[:8])
        return f"groove: {self.files} plików, {self.notes} nut; role [{top}…]"


# ---------------------------------------------------------------------------
# Globalny stan (+ leniwe załadowanie z env)
# ---------------------------------------------------------------------------
def set_groove(stats: GrooveStats | None) -> None:
    """Włącza/wyłącza humanizację z korpusu (None = wyłącz)."""
    global _stats, _loaded
    _stats = stats
    _loaded = True


def get_groove() -> GrooveStats | None:
    """Aktywne statystyki groove; leniwie ładuje z DS_GROOVE_JSON przy pierwszym wołaniu."""
    global _stats, _loaded
    if not _loaded:
        _loaded = True
        p = os.environ.get(ENV_JSON)
        if p and Path(p).exists():
            try:
                _stats = GrooveStats.load(p)
            except Exception:
                _stats = None
    return _stats


def clear_groove() -> None:
    set_groove(None)


# ---------------------------------------------------------------------------
# Hooki używane przez generator.structure_vel / Writer.add
# ---------------------------------------------------------------------------
def vel_jitter(role: str, step: int, rng: random.Random, default_spread: int) -> float:
    """Rozrzut velocity dla nuty (rola, pozycja 0..15): z korpusu albo domyślny.

    Wywoływane przez structure_vel — zamiast randint(±spread)."""
    g = get_groove()
    d = g.roles.get(role) if g else None
    if not d:
        return float(rng.randint(-default_spread, default_spread))
    pos = step % 16
    mean, std = d["vel"][pos]
    if not mean and not std:
        mean, std = d["vel_all"]
    return float(rng.gauss(0.0, max(1.0, std * 0.7)))


def vel_accent(role: str, step: int) -> float:
    """Mnożnik akcentu per pozycja (średnia pozycji / średnia roli); 1.0 bez korpusu."""
    g = get_groove()
    d = g.roles.get(role) if g else None
    if not d:
        return 1.0
    pos = step % 16
    mean, _std = d["vel"][pos]
    all_mean = d["vel_all"][0] or 1.0
    if not mean:
        return 1.0
    return max(0.6, min(1.4, mean / all_mean))


def micro_timing(role: str, step: int, rng: random.Random) -> float:
    """Odchyłka onsetu w bitach (ludzki timing); 0.0 bez korpusu. Zawsze w ±MAX_OFF_BEATS."""
    g = get_groove()
    d = g.roles.get(role) if g else None
    if not d:
        return 0.0
    pos = step % 16
    mean, std = d["off"][pos]
    if not mean and not std:
        return 0.0
    off16 = rng.gauss(mean, max(0.0, std * 0.8))
    return max(-MAX_OFF_BEATS, min(MAX_OFF_BEATS, off16 * 0.25))   # 16-tka → bity
