"""resp.py — responsywne elementy GUI (dopasowanie do dostępnego obszaru).

Zamiast sztywnych, jednoliniowych wierszy i twardych rozmiarów:

- **FlowLayout** (`flow`) — wiersz kontrolek, który sam zawija się do dostępnej
  szerokości (jak tekst w akapicie): przy wąskim oknie kontrolki przechodzą
  do kolejnych linii, przy szerokim układają się w jednej.
- **paged(page)** — opakowanie zakładki w `QScrollArea(widgetResizable)`:
  gdy okno jest WIĘKSZE niż naturalny rozmiar strony, strona się rozciąga
  (zachowuje dawne rozciągliwe elementy: drzewa, tabele, osi czasu);
  gdy okno jest MNIEJSZE — pojawia się przewijanie zamiast ucinania treści.
  Dzięki temu okno można dowolnie zwężać/zmniejszać (małe ekrany, pół okna,
  obok siebie kilka narzędzi) bez utraty dostępu do kontrolek.
- **fill(widget)** — kontrolka rośnie w pionie razem z oknem (zamiast stałej
  wysokości / limitu).

Moduł nie zależy od żadnych bibliotek spoza PyQt6 (które GUI i tak wymaga).
"""
from __future__ import annotations

from PyQt6 import QtWidgets as W
from PyQt6.QtCore import QPoint, QRect, QSize, Qt


# ------------------------------------------------------------------ FlowLayout
class FlowLayout(W.QLayout):
    """Wiersz, który zawija elementy do dostępnej szerokości.

    Klasyczna implementacja układu „płynącego” (jak oficjalny przykład Qt):
    elementy układają się od lewej, a gdy następny nie mieści się w wierszu —
    przechodzi do nowej linii. Wysokość layoutu jest funkcją szerokości
    (`hasHeightForWidth`), więc rodzic (QVBoxLayout/formularz) potrafi
    zarezerwować właściwie dużo miejsca w pionie.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        if parent is not None:
            self.setContentsMargins(0, 0, 0, 0)
        self.setSpacing(6)
        self.itemList = []

    def __del__(self):
        item = self.takeAt(0)
        while item:
            item = self.takeAt(0)

    # ---- API QLayout
    def addItem(self, item):
        self.itemList.append(item)

    def addWidget(self, w, stretch=0, alignment=None):
        # tolerancja na stare wywołania QBoxLayout.addWidget(w, stretch) — stretch w flow nie ma znaczenia
        super().addWidget(w)

    def addStretch(self, stretch=0):
        # zgodność z QBoxLayout.addStretch — w flow wiersz i tak zawija, odcinek nic nie wnosi
        return None

    def count(self):
        return len(self.itemList)

    def itemAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList[index]
        return None

    def takeAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList.pop(index)
        return None

    def clear(self):
        while self.takeAt(0) is not None:
            pass

    def expandingDirections(self):
        # layout NIE rozciąga się sam — zajmuje tyle, ile wysokości wymaga zawijanie
        return Qt.Orientation(0)   # brak kierunku rozciągania (Qt.Orientations(0))

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._doLayout(QRect(0, 0, width, 0), testOnly=True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._doLayout(rect, testOnly=False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self.itemList:
            size = size.expandedTo(item.minimumSize())
        m = self.contentsMargins()
        size += QSize(m.left() + m.right(), m.top() + m.bottom())
        return size

    # ---- rozmieszczanie
    def _doLayout(self, rect, testOnly):
        m = self.contentsMargins()
        rect = rect.adjusted(+m.left(), +m.top(), -m.right(), -m.bottom())
        x, y = rect.x(), rect.y()
        line_height = 0
        sp = self.spacing()
        for item in self.itemList:
            hint = item.sizeHint()
            next_x = x + hint.width() + sp
            if next_x - sp > rect.right() and line_height > 0:
                x = rect.x()
                y += line_height + sp
                line_height = 0
                next_x = x + hint.width() + sp
            if not testOnly:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - rect.y()


# ------------------------------------------------------------------ pomocnicze
def flow(parent=None, spacing=6):
    """FlowLayout na widgecie (`flow(w)` instaluje layout) albo do `addLayout`.

    Typowe użycie — zamiast::

        r = W.QHBoxLayout()
        for x in (...): r.addWidget(x)

    pisze się::

        r = flow()
        for x in (...): r.addWidget(x)   # wiersz sam zawija się przy wąskim oknie
    """
    lay = FlowLayout()
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(spacing)
    if parent is not None:
        parent.setLayout(lay)
    return lay


def paged(page):
    """Zakładka dopasowana do obszaru: rozciąga się, a przy braku miejsca przewija.

    `page` musi mieć własny layout (najczęściej QWidget z QVBoxLayout/QFormLayout).
    Zwracany jest QScrollArea — dodawany do QTabWidget; sam obiekt strony
    pozostaje nietknięty (referencje `self.xxx` działają jak dotąd).
    """
    sa = W.QScrollArea()
    sa.setWidget(page)
    sa.setWidgetResizable(True)
    sa.setFrameShape(W.QFrame.Shape.NoFrame)
    sa.setLineWidth(0)
    sa.setSizeAdjustPolicy(W.QAbstractScrollArea.SizeAdjustPolicy.AdjustIgnored)
    return sa


def fill(widget, h_min=None):
    """Kontrolka rośnie w pionie razem z oknem (pionowa polityka Expanding)."""
    p = widget.sizePolicy()
    p.setVerticalPolicy(W.QSizePolicy.Policy.Expanding)
    widget.setSizePolicy(p)
    if h_min is not None:
        widget.setMinimumHeight(int(h_min))
    return widget
