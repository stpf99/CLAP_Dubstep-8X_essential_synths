"""simplify_experiment.py — uproszczenie projektu (siła 0…100%).

Po generacji (lub przyciskiem „Zastosuj na projekcie”) przerzedza nuty, ścisza
drugorzędne tory, ściąga parametry do środka i wygładza łuki energii sekcji.
Deterministyczne (seed z projektu). Szanuje lock_notes / lock_sound / lock_gain.

Siła (0…1):
  0%   — nic
  ~25% — lekkie przerzedzenie hat/perc/lead (słabe velocity)
  ~50% — + ściszenie nadmiarowych warstw, params → środek
  ~75% — + mocne przerzedzenie, gain drugorzędnych w dół
  100% — maksymalnie: zostaje rdzeń (kick, backbeat, główny bas), reszta mocno zredukowana

Ranga w pipeline: 95 (tuż przed invert=100, po sanitize nie — wywoływane przed sanitize).
"""
from __future__ import annotations

import math
import random
from typing import Any

VERSION = 1

# priorytet zachowania (większy = trudniej usunąć / ściszyć)
_PRIO = {
    "kick": 100, "backbeat": 90, "bass": 80, "hat": 55, "lead": 50,
    "perc": 45, "accent": 40, "mallet": 48, "pad": 35, "fx": 20,
}

_SKIP_PARAMS = {
    "Waveform", "LFO Shape", "LFO Division", "Unison Voices", "Noise Bursts",
    "Key Track", "Retrigger", "Choke", "Mode", "Algorithm",
}


def _role(ttype: str) -> str:
    try:
        from . import perceptual_norms as PN
        return PN.role_of(ttype)
    except Exception:
        return "lead"


def _imp(beat: float, vel: float, rng: random.Random) -> float:
    """Ważność nuty: mocna ćwierćnuta > ósemka > reszta + velocity + minimalny los."""
    fr = beat - math.floor(beat)
    if fr < 0.06:
        pos = 3.0
    elif abs(fr - 0.5) < 0.1:
        pos = 2.0
    elif abs(fr * 4 - round(fr * 4)) < 0.05:
        pos = 1.0
    else:
        pos = 0.5
    return pos + 0.5 * (vel / 127.0) + 0.001 * rng.random()


def _thin_track(notes: list, keep_frac: float, role: str, rng: random.Random) -> tuple[list, int]:
    """Zostaw ~keep_frac nut (najważniejsze). Kick/backbeat: zawsze chroni siatkę 1/4."""
    if not notes or keep_frac >= 0.999:
        return notes, 0
    keep_frac = max(0.05, min(1.0, keep_frac))
    scored = sorted(range(len(notes)), key=lambda i: -_imp(float(notes[i][0]), float(notes[i][3]), rng))
    n_keep = max(1, int(math.ceil(len(notes) * keep_frac)))

    protect: set[int] = set()
    if role in ("kick", "backbeat"):
        for i, n in enumerate(notes):
            fr = float(n[0]) - math.floor(float(n[0]))
            if fr < 0.08 or abs(fr - 0.5) < 0.08:
                protect.add(i)

    chosen = set(protect)
    for i in scored:
        if len(chosen) >= n_keep:
            break
        chosen.add(i)

    new = [list(notes[i]) for i in sorted(chosen)]
    removed = len(notes) - len(new)
    return new, removed


def _pull_params(tr: dict, strength: float) -> int:
    """Przyciągnij parametry 0..1 do 0.5 (neutral). strength 0..1."""
    if tr.get("lock_sound") or strength <= 0:
        return 0
    locked = set(tr.get("locked_params") or [])
    params = tr.get("params") or {}
    n_ch = 0
    for name, val in list(params.items()):
        if name in locked or name in _SKIP_PARAMS:
            continue
        try:
            v = float(val)
        except (TypeError, ValueError):
            continue
        if 0.0 <= v <= 1.0:
            nv = round(v + (0.5 - v) * strength, 4)
            if abs(nv - v) > 1e-5:
                params[name] = nv
                n_ch += 1
    return n_ch


def _soften_gain(tr: dict, role: str, strength: float) -> bool:
    """Drugorzędne tory: gain w dół proporcjonalnie do (1 − prio/100) × strength."""
    if tr.get("lock_gain") or strength <= 0:
        return False
    prio = _PRIO.get(role, 50)
    if prio >= 90:
        return False
    g = float(tr.get("gain", 0.7))
    factor = 1.0 - 0.55 * strength * (1.0 - prio / 100.0)
    ng = max(0.12, min(1.35, g * factor))
    if abs(ng - g) < 1e-4:
        return False
    tr["gain"] = round(ng, 3)
    return True


def _smooth_section_energy(sections: list, strength: float) -> int:
    """Wygładź e0/e1 w stronę średniej (mniej dramatycznego łuku)."""
    if not sections or strength <= 0:
        return 0
    n_ch = 0
    for s in sections:
        e0 = float(s.get("e0", 0.7))
        e1 = float(s.get("e1", 0.7))
        mid = 0.5 * (e0 + e1)
        target = 0.65  # spokojniejsze centrum
        ne0 = e0 + (target - e0) * strength * 0.5 + (mid - e0) * strength * 0.3
        ne1 = e1 + (target - e1) * strength * 0.5 + (mid - e1) * strength * 0.3
        ne0 = round(max(0.05, min(1.2, ne0)), 3)
        ne1 = round(max(0.05, min(1.2, ne1)), 3)
        if abs(ne0 - e0) > 1e-4 or abs(ne1 - e1) > 1e-4:
            s["e0"], s["e1"] = ne0, ne1
            n_ch += 1
    return n_ch


def apply(proj: dict, rng: random.Random | None = None, strength: float = 0.5) -> dict:
    """Uprość projekt in-place. strength 0..1 (0 = nic, 1 = maksymalne uproszczenie).

    Zapisuje proj['simplify_report'] i proj['simplify_strength'].
    """
    strength = max(0.0, min(1.0, float(strength)))
    if strength <= 0.0:
        rep = {"version": VERSION, "strength": 0.0, "applied": [], "dims": {}}
        proj["simplify_report"] = rep
        return rep

    rng = rng or random.Random(f"simplify:{proj.get('seed', 0)}")
    applied: list[str] = []
    dims: dict[str, Any] = {}

    sections = [s for s in (proj.get("sections") or []) if int(s.get("bars", 0)) > 0]

    # --- energia sekcji (od ~30%)
    if strength >= 0.3:
        n = _smooth_section_energy(sections, strength)
        dims["section_energy"] = n
        if n:
            applied.append(f"energia sekcji ({n})")

    removed_notes = 0
    pulled_params = 0
    softened_gains = 0

    for tr in proj.get("tracks") or []:
        if tr.get("mute"):
            continue
        role = _role(tr.get("type", ""))
        prio = _PRIO.get(role, 50)

        # keep_frac: przy strength=1 i prio=20 → ~0.15; prio=100 → ~0.85
        # strength=0 → 1.0
        keep = 1.0 - strength * (0.15 + 0.70 * (1.0 - prio / 100.0))
        keep = max(0.08, min(1.0, keep))

        notes = tr.get("notes") or []
        if notes and not tr.get("lock_notes") and strength >= 0.15:
            new, rem = _thin_track(notes, keep, role, rng)
            if rem:
                tr["notes"] = new
                removed_notes += rem

        if strength >= 0.4:
            pulled_params += _pull_params(tr, strength * 0.85)

        if strength >= 0.35:
            if _soften_gain(tr, role, strength):
                softened_gains += 1

    dims.update(notes_removed=removed_notes, params=pulled_params, gains=softened_gains)
    if removed_notes:
        applied.append(f"przerzedzenie −{removed_notes} nut")
    if pulled_params:
        applied.append(f"parametry → środek ×{pulled_params}")
    if softened_gains:
        applied.append(f"gain drugorzędnych ×{softened_gains}")

    rep = {
        "version": VERSION,
        "strength": strength,
        "applied": applied,
        "dims": dims,
    }
    proj["simplify_report"] = rep
    proj["simplify_strength"] = strength
    proj["simplify_experiment"] = True
    return rep


def format_report(rep: dict) -> str:
    if not rep:
        return "Uproszczenie wyłączone."
    L = [f"UPROSZCZENIE (siła {rep.get('strength', 0):.0%})"]
    ap = rep.get("applied") or []
    if ap:
        L.append("Zastosowano: " + ", ".join(ap))
    else:
        L.append("Nic nie zmieniono.")
    d = rep.get("dims") or {}
    if d:
        L.append("Wymiary: " + " · ".join(f"{k}={v}" for k, v in d.items() if v))
    return "\n".join(L)
