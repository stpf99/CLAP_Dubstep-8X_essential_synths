"""optimizer.py — zamknięta pętla optymalizacji nad wewnętrznym recenzentem (optuna, opcjonalnie).

Zamiast „losuj → analizuj → poprawiaj” (generator + musicality_reviewer jako korekta po fakcie),
optymalizator traktuje recenzenta jak funkcję celu i DOBIERA parametry generowania
(energia, gęstość, swing, variety, mood reżysera, siły niuansów/uniq — te, które dziś
sterują oknami smart_param_window / randomize_sound) tak, by wynik był od razu muzykalny.

Tryby:
  single  — jedna funkcja celu: score_project (symboliczna ocena muzykalności 0..1),
            opcjonalnie domieszka audio (render w pamięci + listen.analyze_audio).
  multi   — optuna z NSGA-II: (muzykalność, różnorodność) — front Pareto,
            „różnorodność” = entropia wzorów nut (zob. diversity_score).

Backend: optuna (jeśli zainstalowane), w przeciwnym razie prosty random search
z tym samym API — rdzeń Studia działa bez żadnej nowej zależności.

Wynik to słownik kwargs generate() („tune”), zapisywalny do JSON:
  python3 -m dubstep_studio optimize --style Brostep --trials 40 --out tune.json
  python3 -m dubstep_studio gen --tune tune.json

Nic tu nie modyfikuje projektu użytkownika — zwraca propozycję.
"""
from __future__ import annotations

import math
import random
from typing import Any, Callable

import numpy as np

try:  # opcjonalnie, jak mido w midi_import.py
    import optuna
except ImportError:  # pragma: no cover
    optuna = None


# ---------------------------------------------------------------------------
# Parametry wyszukiwania (poziom generate) — każdy to jeden suwak „jak człowiek w GUI”
# ---------------------------------------------------------------------------
KNOBS: dict[str, tuple[float, float]] = {
    "energy": (0.30, 0.95),
    "density": (0.25, 0.90),
    "swing": (0.0, 0.15),
    "variety": (0.0, 1.0),
    "mood": (-1.0, 1.0),            # tylko gdy włączony reżyser (director.on)
    "niuanse_strength": (0.0, 0.8),  # tylko gdy niuanse włączone
    "uniq_strength": (0.1, 1.0),     # tylko gdy uniq włączone
}

DEFAULT_WEIGHTS: dict[str, float] = {
    "range": 0.22, "scale": 0.18, "params": 0.18, "gains": 0.10,
    "caps": 0.10, "scenario": 0.10, "duplicates": 0.07, "velocities": 0.05,
}


# ---------------------------------------------------------------------------
# Ocena symboliczna (szybka, bez renderu) — te same normy co musicality_reviewer
# ---------------------------------------------------------------------------
def _reviewer():
    from . import musicality_reviewer as MR
    return MR


def _spec_param_names(proj: dict, tr: dict) -> set:
    """Nazwy parametrów ustawionych przez specyfikację typu/stylu — recenzent ich nie ocenia."""
    try:
        return _reviewer()._spec_param_names(proj, tr)
    except Exception:
        return set()


def _note_range_for(tt: str) -> tuple[int, int]:
    MR = _reviewer()
    return MR._note_range_for(tt)


def score_project(proj: dict, weights: dict | None = None, detail: bool = False):
    """Symboliczna ocena muzykalności projektu 0..1 (im wyżej, tym mniej do korekty).

    Składa te same normy, które musicality_reviewer.apply_symbolic po fakcie poprawia:
    zakresy rejestrów, przynależność do skali, okna parametrów, gainy względem TARGET_REL,
    czapy gęstości/energii wg klimatu, normy scenariusza (generator.analyze_scenario),
    duplikaty nut i odcięte velocity. Zwraca (score, breakdown) gdy detail=True.
    """
    from . import core
    w = dict(DEFAULT_WEIGHTS)
    if weights:
        for k, v in weights.items():
            if k in w:
                w[k] = float(v)
    MR = _reviewer()
    tot_w = sum(w.values()) or 1.0
    parts: dict[str, float] = {}

    # --- zakresy rejestrów + przynależność do skali + duplikaty + velocity
    scale_iv = core.SCALES.get(proj.get("scale") or "minor", (0, 2, 3, 5, 7, 8, 10))
    root = int(proj.get("key") or 0) % 12
    in_scale = { (root + iv) % 12 for iv in scale_iv }
    n_range = n_scale = n_notes = 0
    dup = 0
    vel_edge = 0
    for tr in proj.get("tracks") or []:
        tt = tr.get("type") or ""
        notes = tr.get("notes") or []
        if tt in MR.UNPITCHED or not notes:
            continue
        lo, hi = _note_range_for(tt)
        seen: set[tuple] = set()
        for n in notes:
            k = int(n[2]) % 128
            n_notes += 1
            if lo <= k <= hi:
                n_range += 1
            if k % 12 in in_scale:
                n_scale += 1
            key2 = (round(float(n[0]), 4), k)
            if key2 in seen:
                dup += 1
            seen.add(key2)
            v = int(n[3])
            if v <= 1 or v >= 127:
                vel_edge += 1
    parts["range"] = n_range / n_notes if n_notes else 1.0
    parts["scale"] = n_scale / n_notes if n_notes else 1.0
    parts["duplicates"] = 1.0 - min(1.0, dup / max(8, n_notes * 0.25))
    parts["velocities"] = 1.0 - min(1.0, vel_edge / max(8, n_notes * 0.25))

    # --- okna parametrów (tylko parametry, które wtyczka ma; pomijamy specyfikacje)
    from . import core as _core
    try:
        m = _core.meta()
    except Exception:
        m = None
    n_par = n_win = 0
    for tr in proj.get("tracks") or []:
        tt = tr.get("type") or ""
        if not tt or tr.get("lock_sound"):
            continue
        spec_names = _spec_param_names(proj, tr)
        params = tr.get("params") or {}
        for pname, (plo, phi) in MR.PARAM_WINDOWS.items():
            if pname in spec_names or pname not in params:
                continue
            if m is not None and not m.has(tt, pname):
                continue
            try:
                v = float(params[pname])
            except (TypeError, ValueError):
                continue
            n_par += 1
            if plo <= v <= phi:
                n_win += 1
    parts["params"] = n_win / n_par if n_par else 1.0

    # --- gainy względem TARGET_REL
    gsum = 0.0
    g_n = 0
    for tr in proj.get("tracks") or []:
        if tr.get("mute"):
            continue
        tgt = core.TARGET_REL.get(tr.get("type") or "", core.DEFAULT_GAIN.get(tr.get("type") or "", 0.7))
        try:
            cur = float(tr.get("gain", tgt))
        except (TypeError, ValueError):
            continue
        gsum += min(1.0, abs(cur - tgt) / max(0.35, tgt * 0.9))
        g_n += 1
    parts["gains"] = 1.0 - (gsum / g_n) if g_n else 1.0

    # --- czapy gęstości/energii wg klimatu (te same wartości co _density_energy_caps)
    fam = MR._climate_family(proj)
    dens_cap = {"dark": 0.62, "space": 0.55, "organic": 0.58, "bright": 0.72, "acid": 0.70, "hard": 0.85}.get(fam, 0.70)
    ener_cap = {"dark": 0.65, "space": 0.55, "organic": 0.60, "bright": 0.75, "acid": 0.78, "hard": 0.92}.get(fam, 0.75)
    d0 = float(proj.get("density") or 0.5)
    e0 = float(proj.get("energy") or 0.5)
    parts["caps"] = 1.0 - min(1.0, max(0.0, d0 - dens_cap) + max(0.0, e0 - ener_cap))

    # --- normy scenariusza (analyze_scenario — to samo, co generator sprawdza po generacji)
    try:
        from . import generator as G
        issues = G.analyze_scenario(proj.get("sections") or [], proj.get("character") or "balanced", e0, d0)
    except Exception:
        issues = []
    parts["scenario"] = 1.0 - min(1.0, 0.22 * len(issues))

    score = sum(w[k] * parts.get(k, 1.0) for k in w) / tot_w
    if detail:
        return max(0.0, min(1.0, score)), parts
    return max(0.0, min(1.0, score))


def diversity_score(proj: dict) -> float:
    """Różnorodność wzorów 0..1 (symbolicznie, deterministycznie): entropia pozycji nut per tor
    + zróżnicowanie typów sekcji. Wysoko = wzory nie są jednym powtarzającym się clichem."""
    ent = []
    for tr in proj.get("tracks") or []:
        notes = tr.get("notes") or []
        if not notes:
            continue
        bars_f = [float(n[0]) for n in notes]
        span = max(bars_f) - min(bars_f) if len(bars_f) > 1 else 1.0
        if span <= 0:
            continue
        # pozycje wewnątrz taktu skwantowane do 16-tk + oktawa względna
        pos = [((f % 4.0) * 4.0) + 0.0 for f in bars_f]
        cnt: dict[float, int] = {}
        for p in pos:
            cnt[p] = cnt.get(p, 0) + 1
        h = -sum((c / len(pos)) * math.log(c / len(pos) + 1e-12) for c in cnt.values())
        ent.append(min(1.0, h / math.log(16.0)))
    sec = [s.get("type") for s in proj.get("sections") or []]
    sec_var = len(set(sec)) / 5.0 if sec else 0.35
    e = float(np.mean(ent)) if ent else 0.35
    return max(0.0, min(1.0, 0.7 * e + 0.3 * min(1.0, sec_var)))


def audio_score(proj: dict, max_sec: float = 12.0) -> float | None:
    """Ocena audio (opcjonalna): render miksu w pamięci + listen.analyze_audio.

    Punktuje: zgodność bilansu pasm z celem klimatu (BAND_TARGETS), LUFS w sensownym oknie
    (cel −14), crest/dynamikę. Zwraca None, gdy render/analiza niedostępne (np. brak hosta).
    """
    from . import core
    MR = _reviewer()
    try:
        mix = core.render_mix(proj, workers=1)
    except Exception:
        return None
    if mix is None or len(mix) < 1024:
        return None
    sr = core.SR
    max_n = int(max_sec * sr)
    if len(mix) > max_n:
        st = max(0, (len(mix) - max_n) // 2)
        mix = mix[st:st + max_n]
    try:
        from . import listen as L
        F = L.analyze_audio(mix, rate=sr)
    except Exception:
        return None
    if not F or F.get("silent"):
        return None

    fam = MR._climate_family(proj)
    tgt = MR.BAND_TARGETS.get(fam, MR.BAND_TARGETS["default"])
    bands = F.get("bands") or {}
    tot = sum(float(v) for v in bands.values()) or 1.0
    cur = {k: float(v) / tot for k, v in bands.items()}
    band = 1.0 - min(1.0, sum(abs(cur.get(k, 0.0) - float(t)) for k, t in tgt.items()) / 0.9)

    lufs = F.get("lufs")
    if isinstance(lufs, (int, float)):
        lu = 1.0 - min(1.0, abs(float(lufs) + 14.0) / 9.0)
    else:
        lu = 0.5
    crest = F.get("crest_db") or 12.0
    crest_s = 1.0 - min(1.0, abs(float(crest) - 12.0) / 14.0)
    dyn = F.get("dyn_db") or 0.0
    dyn_s = min(1.0, float(dyn) / 6.0)
    return max(0.0, min(1.0, 0.5 * band + 0.2 * lu + 0.15 * crest_s + 0.15 * dyn_s))


# ---------------------------------------------------------------------------
# Pętla optymalizacji
# ---------------------------------------------------------------------------
def _knob_space(base: dict) -> dict[str, tuple[float, float]]:
    """Które suwaki uczestniczą: te zawsze + te wynikające z flag w base (kwargs generate)."""
    sp = {k: v for k, v in KNOBS.items() if k in ("energy", "density", "swing", "variety")}
    if isinstance(base.get("director"), dict) or base.get("director") is True:
        sp["mood"] = KNOBS["mood"]
    if base.get("niuanse"):
        sp["niuanse_strength"] = KNOBS["niuanse_strength"]
    if base.get("uniq"):
        sp["uniq_strength"] = KNOBS["uniq_strength"]
    return sp


def _make_generate(base: dict, seed: int) -> Callable[..., Any]:
    from . import generator as G
    fixed = dict(base or {})
    fixed.pop("seed", None)

    def call(knobs: dict) -> Any:
        kw = dict(fixed)
        kw.update(knobs)
        return G.generate(seed=seed, **kw)
    return call


def _sample_random(rng: random.Random, space: dict) -> dict:
    return {k: rng.uniform(lo, hi) for k, (lo, hi) in space.items()}


def _score_call(make: Callable, knobs: dict, audio: bool, alpha: float):
    proj = make(knobs)
    s, _parts = score_project(proj, detail=True)
    if audio:
        a = audio_score(proj)
        if a is not None:
            s = (1.0 - alpha) * s + alpha * a
    return proj, s


def optimize(style: str = "Brostep", trials: int = 40, seed: int | None = None,
            base: dict | None = None, objectives: tuple[str, ...] = ("musicality",),
            audio: bool = False, audio_alpha: float = 0.25,
            n_startup: int = 10, on_trial: Callable[[dict], None] | None = None,
            make: Callable[[dict], Any] | None = None) -> dict:
    """Dobiera parametry generate() maksymalizujące ocenę recenzenta.

    objectives=("musicality",) — jeden cel; ("musicality","diversity") — Pareto (NSGA-II).

    base: pozostałe kwargs generate() (bars, instruments, director, niuanse, uniq, …).
    make: własny konstruktor projektu knobs→proj (domyślnie generator.generate(**base, **knobs))
          — użyte też w testach, żeby pętla działała bez hosta.
    Zwraca: {"backend", "trials", "best": {"params","values","score"}, "front": [...], "tune": kwargs}
    — `tune` nadaje się do gen --tune / generate(**tune).
    """
    from . import generator as G
    if make is None:
        if style not in G.STYLES:
            raise ValueError(f"Nieznany styl: {style}")
        base = dict(base or {})
        base.setdefault("style", style)
    else:
        base = dict(base or {})
    space = _knob_space(base)
    seed = int(seed if seed is not None else random.randrange(1000000))
    trials = max(4, int(trials))
    multi = "diversity" in objectives and len(objectives) > 1
    make = make or _make_generate(base, seed)
    rng = random.Random(seed)

    def evaluate(knobs: dict) -> tuple[Any, list[float]]:
        proj, s = _score_call(make, knobs, audio, audio_alpha)
        vals = [s, diversity_score(proj)] if multi else [s]
        return proj, vals

    records: list[dict] = []

    def rec(knobs: dict, vals: list[float], proj: Any) -> dict:
        r = {"params": {k: round(float(v), 4) for k, v in knobs.items()},
             "values": [round(float(v), 4) for v in vals]}
        records.append(r)
        if on_trial:
            try:
                on_trial({**r, "n": len(records)})
            except Exception:
                pass
        return r

    backend = "random"
    if optuna is not None:
        backend = "optuna"
        try:
            optuna.logging.set_verbosity(optuna.logging.WARNING)
            sampler = (optuna.samplers.NSGAIISampler(seed=seed) if multi
                       else optuna.samplers.TPESampler(seed=seed, n_startup_trials=min(n_startup, max(4, trials // 3))))
            study = optuna.create_study(directions=["maximize"] * (2 if multi else 1), sampler=sampler)

            def objective(trial):
                knobs = {k: trial.suggest_float(k, lo, hi) for k, (lo, hi) in space.items()}
                _proj, vals = evaluate(knobs)
                rec(knobs, vals, _proj)
                return vals
            study.optimize(objective, n_trials=trials)
        except Exception:
            backend = "random"
            records.clear()

    if backend == "random":
        for _ in range(trials):
            knobs = _sample_random(rng, space)
            _proj, vals = evaluate(knobs)
            rec(knobs, vals, _proj)

    if not records:
        raise RuntimeError("Optymalizacja nie wykonała ani jednej próby.")

    def dominates(a: list[float], b: list[float]) -> bool:
        return all(x >= y for x, y in zip(a, b)) and any(x > y for x, y in zip(a, b))

    front = [r for r in records if not any(dominates(o["values"], r["values"]) for o in records)]
    # wybór „kolana”: muzykalność ważona + mniejsza nagroda za różnorodność
    best = max(front or records, key=lambda r: r["values"][0] + (0.35 * r["values"][1] if multi and len(r["values"]) > 1 else 0.0))
    tune = dict(base)
    tune.pop("style", None)
    if tune.get("instruments") is None:      # None = „generate dobierze” — nie wypychamy do JSON
        tune.pop("instruments", None)
    tune.update(best["params"])
    return {
        "backend": backend,
        "trials": len(records),
        "best": best,
        "front": sorted(front, key=lambda r: -r["values"][0]),
        "tune": tune,
    }


# ---------------------------------------------------------------------------
# Dogrywka brzmienia jednego toru (randomize_sound pod ocenę recenzenta)
# ---------------------------------------------------------------------------
def refine_track_sound(proj: dict, track_name: str, trials: int = 30, audio: bool = False,
                       seed: int | None = None, alpha: float = 0.35) -> dict | None:
    """Optymalizuje parametry brzmienia JEDNEGO toru (te, które ustala randomize_sound)
    pod ocenę recenzenta. Tor i projekt NIE są modyfikowane — zwraca {"params": {...}, "score"}.

    `params` są w jednostkach ułamkowych 0..1 (tak jak tr["params"]), gotowe do update().
    Backend: optuna, albo random search bez zależności.
    """
    from . import core
    from . import generator as G
    tr = core.find_track(proj, track_name)
    if tr is None or tr.get("lock_sound"):
        return None
    tt = tr.get("type") or ""
    spec = {p[0]: p for p in G.SOUND.get(tt, [])}
    for p in G.style_sound(proj, tr):
        spec[p[0]] = p
    m = core.meta()
    rng = random.Random(seed if seed is not None else proj.get("seed", 0))
    # tylko parametry ciągłe, nie zablokowane, obecne we wtyczce
    locked = set(tr.get("locked_params") or [])
    keys, los, his = [], [], []
    for name, sp in spec.items():
        if name in locked or sp[1] != "r" or not m.has(tt, name):
            continue
        keys.append(name)
        los.append(float(sp[2]))
        his.append(float(sp[3]))
    if not keys:
        return None

    import copy as _copy
    base_proj = _copy.deepcopy(proj)
    base_tr = next(t for t in base_proj["tracks"] if t.get("name") == track_name)

    def apply_and_score(vec: list[float]) -> float:
        base_tr.setdefault("params", {})
        for k, v, lo, hi in zip(keys, vec, los, his):
            base_tr["params"][k] = m.eng2frac(tt, k, max(lo, min(hi, v)))
        s, _ = score_project(base_proj, detail=True)
        if audio:
            a = audio_score(base_proj)
            if a is not None:
                s = (1.0 - alpha) * s + alpha * a
        return s

    best_v, best_s = None, -1.0
    if optuna is not None:
        try:
            optuna.logging.set_verbosity(optuna.logging.WARNING)
            study = optuna.create_study(direction="maximize",
                                        sampler=optuna.samplers.TPESampler(seed=rng.randrange(1 << 30)))

            def obj(trial):
                vec = [trial.suggest_float(k, lo, hi) for k, lo, hi in zip(keys, los, his)]
                return apply_and_score(vec)
            study.optimize(obj, n_trials=max(4, trials))
            bp = study.best_params
            best_v = [bp[k] for k in keys]
            best_s = float(study.best_value)
        except Exception:
            best_v = None
    if best_v is None:  # fallback random
        for _ in range(max(4, trials)):
            vec = [rng.uniform(lo, hi) for lo, hi in zip(los, his)]
            s = apply_and_score(vec)
            if s > best_s:
                best_s, best_v = s, vec
    params = {}
    for k, v, lo, hi in zip(keys, best_v, los, his):
        params[k] = m.eng2frac(tt, k, max(lo, min(hi, v)))
    return {"track": track_name, "type": tt, "params": params, "score": round(float(best_s), 4)}


# ---------------------------------------------------------------------------
# Zapis/odczyt „tune” (kwargs generate do powtórki)
# ---------------------------------------------------------------------------
def save_tune(path: str, result: dict, extra: dict | None = None) -> str:
    import json
    import datetime
    data = {"version": 1, "created": datetime.datetime.now().isoformat(timespec="seconds"),
            "backend": result.get("backend"), "trials": result.get("trials"),
            "best": result.get("best"), "front": result.get("front", [])[:12],
            "generate": result.get("tune", {})}
    if extra:
        data.update(extra)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return path


def load_tune(path: str) -> dict:
    import json
    with open(path, encoding="utf-8") as f:
        return json.load(f)
