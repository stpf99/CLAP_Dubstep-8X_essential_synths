"""markov_gen.py — modele Markowa / n-gramy per rola, uczone z korpusu MIDI (mido, opcjonalnie).

Zamiast czysto ważonego losowania wzorów perkusji i linii basu, można wyuczyć z korpusu
MIDI (własnego zestawu plików) łańcuchy per rola:

  perkusja (kick/snare/hat/…): łańcuch 2. rzędu po 16 krokach siatki takatu
      P(uderzenie w kroku t | kroki t-2, t-1) + średnia velocity per pozycja;
  linie (bas/lead/…): n-gram (interwał półtonowy, ioi w 16-tkach) — chodzi po łańcuchu,
      wysokość względem mediany korpusu, ioi z łańcucha.

Przy 8 ścieżkach i małych zbiorach danych zwykle daje więcej niż transformer
(por. uwagi w przeglądzie: Magenta nieutrzymywana — nie używamy; miditok/transformer
dopiero przy dużym własnym korpusie).

Użycie:
  python3 -m dubstep_studio markov train --files katalog/*.mid --out model.json
  python3 -m dubstep_studio gen --style Brostep --markov model.json
albo z kodu:  generate(..., markov=dict(on=True, model=MarkovModel.load(path)))

Zależność: tylko mido (opcjonalna, jak w midi_import.py). Bez niej trening zwraca
wyraźny błąd; apply_markov nie robi nic.
"""
from __future__ import annotations

import collections
import json
import math
import random
import statistics
from pathlib import Path

try:  # opcjonalnie, jak mido w midi_import.py
    import mido
except ImportError:  # pragma: no cover
    mido = None

from . import core
from . import musicality_reviewer as MR

PERC_ROLES = ("kick", "snare", "hat", "openhat", "clap", "rim", "tom", "crash",
              "ride", "cowbell", "conga", "shaker")


# ---------------------------------------------------------------------------
# Parsing MIDI → role → nuty (w bitach; klucze GM/tonalne)
# ---------------------------------------------------------------------------
def _note_events(mid) -> list[dict]:
    """Zbiera zdarzenia nut z pliku mido (już otwartego): per track + typy DS."""
    from . import midi_import as MI
    tpb = mid.ticks_per_beat or 480
    out = []
    for i, tr in enumerate(mid.tracks):
        name = (getattr(tr, "name", "") or f"Track {i}").strip()
        abs_tick = 0
        notes_on = {}
        events = []
        is_drum = False
        for msg in tr:
            abs_tick += msg.time
            if msg.type == "note_on" and msg.velocity > 0:
                notes_on[(getattr(msg, "channel", 0), msg.note)] = (abs_tick, msg.velocity)
                if getattr(msg, "channel", 0) == 9:
                    is_drum = True
            elif msg.type in ("note_off", "note_on"):
                key = (getattr(msg, "channel", 0), getattr(msg, "note", 0))
                if key in notes_on:
                    st, vel = notes_on.pop(key)
                    events.append((st, abs_tick, key[1], vel, key[0]))
        for (ch, note), (st, vel) in notes_on.items():
            events.append((st, abs_tick, note, vel, ch))
            if ch == 9:
                is_drum = True
        if not events:
            continue
        # typ DS: kanał perkusyjny → rola PER NUTA (GM_DRUM; stopa i werbel w jednej ścieżce
        # trafiają do osobnych ról); nazwa → NAME_HINTS; inaczej skala wysokości
        if is_drum:
            for e in events:
                if e[4] == 9:
                    out.append({"role": MI.GM_DRUM.get(e[2], "conga"),
                                "on_beat": e[0] / tpb, "dur_beat": max(0.05, (e[1] - e[0]) / tpb),
                                "key": int(e[2]), "vel": int(e[3])})
            continue
        tt = MI._guess_type_from_name(name) or MI._pitch_to_type(statistics.mean([e[2] for e in events]), False) or "epiano"
        for st, en, note, vel, _ch in events:
            out.append({"role": tt, "on_beat": st / tpb, "dur_beat": max(0.05, (en - st) / tpb),
                        "key": int(note), "vel": int(vel)})
    return out


def _quant16(on_beat: float) -> int:
    """Pozycja na siatce 16-tk wewnątrz taktu (0..15) + indeks taktu."""
    step = on_beat / 0.25
    return int(round(step))


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
class MarkovModel:
    """Łańcuchy per rola. Struktura (serializowalna do JSON):

    perc:  {role: {"chain": {"s_{t-2}s_{t-1}": [n0, n1]},        # liczby: brak/obecność w kroku t
                   "vel": [16 × (mean,)], "key": mediana GM}}
    pitch: {role: {"chain": {"i:ioi": {"i2:ioi2": count}},
                   "vel": (mean, std), "key": mediana, "iois": {…}}}
    """

    VERSION = 1

    def __init__(self, perc: dict | None = None, pitch: dict | None = None,
                 bars: int = 0, files: int = 0):
        self.perc = perc or {}
        self.pitch = pitch or {}
        self.bars = bars
        self.files = files

    # -- trening -----------------------------------------------------------
    @classmethod
    def train(cls, paths, roles: list[str] | None = None, max_files: int = 512) -> "MarkovModel":
        if mido is None:
            raise RuntimeError("Brak biblioteki mido — zainstaluj: pip install mido")
        perc: dict[str, dict] = {}
        pitch: dict[str, dict] = {}
        n_files = 0
        n_bars = 0
        for p in list(paths)[:max_files]:
            p = Path(p)
            if not p.exists():
                continue
            try:
                mid = mido.MidiFile(str(p))
                events = _note_events(mid)
            except Exception:
                continue
            n_files += 1
            by_role: dict[str, list] = collections.defaultdict(list)
            for e in events:
                by_role[e["role"]].append(e)
            for role, evs in by_role.items():
                if roles and role not in roles:
                    continue
                evs.sort(key=lambda e: e["on_beat"])
                if role in PERC_ROLES:
                    _train_perc(perc.setdefault(role, {}), evs)
                    n_bars = max(n_bars, int(evs[-1]["on_beat"] // 4) + 1)
                elif role in MR.NOTE_RANGES:
                    _train_pitch(pitch.setdefault(role, {}), evs)
        return cls(perc, pitch, n_bars, n_files)

    # -- serializacja ------------------------------------------------------
    def save(self, path: str) -> str:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"version": self.VERSION, "bars": self.bars, "files": self.files,
                       "perc": self.perc, "pitch": self.pitch}, f, indent=1)
        return path

    @classmethod
    def load(cls, path: str) -> "MarkovModel":
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return cls(d.get("perc") or {}, d.get("pitch") or {}, int(d.get("bars") or 0), int(d.get("files") or 0))

    def roles(self) -> list[str]:
        return sorted(set(self.perc) | set(self.pitch))

    def summary(self) -> str:
        ps = ", ".join(f"{r}: {sum(map(sum, (v for v in self.perc[r]['chain'].values())))}" for r in sorted(self.perc))
        return (f"markov: {self.files} plików, {self.bars} taktów; perkusja [{ps}]; "
                f"linie [{', '.join(sorted(self.pitch))}]")


def _train_perc(dst: dict, evs: list) -> None:
    chain = dst.setdefault("chain", {})
    vsum = dst.setdefault("vel", [[0, 0] for _ in range(16)])
    keys = []
    dst.setdefault("vel_std", 10)
    # sekwencja barów z obecnością per krok
    bars: dict[int, list[bool]] = {}
    for e in evs:
        st = _quant16(e["on_beat"])
        pos = st % 16
        bars.setdefault(st // 16, [False] * 16)[pos] = True
        vsum[pos][0] += e["vel"]
        vsum[pos][1] += 1
        keys.append(e["key"])
    seq = [bars[b] for b in sorted(bars)]
    for bar in seq:
        s2, s1 = bar[-2], bar[-1]          # wrap z końca poprzedniego (tu: wewnątrz taktu)
        for t in range(16):
            key = f"{int(bool(s2))}{int(bool(s1))}"
            arr = chain.setdefault(key, [0, 0])
            arr[int(bar[t])] += 1
            s2, s1 = s1, bar[t]
    dst["vel"] = [[round(a / max(1, b), 1), b] for a, b in vsum]
    dst["key"] = int(statistics.median(keys)) if keys else 36
    vels = [e["vel"] for e in evs]
    try:
        dst["vel_std"] = round(statistics.pstdev(vels), 1) if len(vels) > 1 else 10.0
    except Exception:
        dst["vel_std"] = 10.0


def _train_pitch(dst: dict, evs: list) -> None:
    if len(evs) < 3:
        return
    chain = dst.setdefault("chain", {})
    keys = dst.setdefault("keys", [])
    iois = dst.setdefault("iois", {})
    prev_tok = None
    last_on = None
    last_key = None
    for e in evs:
        keys.append(e["key"])
        if last_on is not None:
            ioi = max(1, min(32, int(round((e["on_beat"] - last_on) / 0.25))))
        else:
            ioi = 4
        if last_key is not None:
            interval = max(-24, min(24, int(e["key"]) - int(last_key)))
            tok = f"{interval}:{ioi}"
            if prev_tok is not None:
                chain.setdefault(prev_tok, collections.Counter())[tok] += 1
            prev_tok = tok
        else:
            prev_tok = None
        last_on, last_key = e["on_beat"], e["key"]
    dst["key"] = int(statistics.median(keys)) if keys else 40
    vels = [e["vel"] for e in evs]
    dst["vel"] = (round(statistics.mean(vels), 1), round(statistics.pstdev(vels), 1) if len(vels) > 1 else 8.0)


# ---------------------------------------------------------------------------
# Generowanie wzorów
# ---------------------------------------------------------------------------
def pattern_steps(model: MarkovModel, role: str, bars: int, rng: random.Random,
                  density: float = 1.0) -> list[list[int]]:
    """Perkusja: bars × 16 obecności wg łańcucha 2. rzędu. density < 1 przycina, > 1 dodaje."""
    r = model.perc.get(role)
    if not r or not r.get("chain"):
        return []
    chain = r["chain"]
    out = []
    s2 = s1 = 0
    for _bar in range(max(1, bars)):
        row = []
        for _t in range(16):
            arr = chain.get(f"{s2}{s1}") or chain.get("00") or [1, 1]
            n0, n1 = arr[0], arr[1]
            p = n1 / max(1, n0 + n1)
            p *= density if density < 1 else min(0.98, 0.55 + 0.45 * density)
            hit = rng.random() < p
            row.append(1 if hit else 0)
            s2, s1 = s1, row[-1]
        out.append(row)
    return out


def generate_pattern(model: MarkovModel, role: str, bars: int, rng: random.Random,
                     density: float = 1.0) -> list[list]:
    """Wzór roli w formacie tr['notes'] = [[on, dur, key, vel], …] (on w bitach)."""
    notes: list[list] = []
    if role in model.perc:
        r = model.perc[role]
        key = int(r.get("key") or 36)
        vstd = float(r.get("vel_std") or 10.0)
        for b, row in enumerate(pattern_steps(model, role, bars, rng, density)):
            for t, hit in enumerate(row):
                if not hit:
                    continue
                mean = r["vel"][t][0] if t < len(r.get("vel") or []) else 96
                v = max(1, min(127, int(round(mean + rng.gauss(0, vstd * 0.6)))))
                notes.append([round(b * 4 + t * 0.25, 4), 0.1, key, v])
        return notes
    if role in model.pitch:
        r = model.pitch[role]
        chain = r["chain"]
        if not chain:
            return []
        base = int(r.get("key") or 40)
        vmean, vstd = r.get("vel") or (96, 8.0)
        cur = base
        on = 0.0
        tok = rng.choice(sorted(chain.keys()))
        while on < bars * 4 - 0.01:               # do końca ostatniego taktu
            interval_s, ioi_s = tok.split(":")
            interval, ioi = int(interval_s), float(ioi_s)
            cur = max(0, min(127, cur + interval))
            v = max(1, min(127, int(round(vmean + rng.gauss(0, vstd * 0.6)))))
            notes.append([round(on, 4), round(max(0.05, ioi * 0.25 * 0.9), 4), int(cur), v])
            on += ioi * 0.25
            nxt = chain.get(tok) or {}
            if nxt:
                toks = list(nxt.items())
                rng.shuffle(toks)
                total = sum(c for _, c in toks) or 1
                x = rng.random() * total
                acc = 0.0
                for t2, c in toks:
                    acc += c
                    if acc >= x:
                        tok = t2
                        break
        # rejestr roli (oktawami, jak solve_register)
        lo, hi = MR._note_range_for(role)
        for n in notes:
            k = int(n[2])
            while k < lo:
                k += 12
            while k > hi:
                k -= 12
            n[2] = k
        notes.sort(key=lambda n: n[0])
        return notes
    return []


# ---------------------------------------------------------------------------
# Aplikacja do projektu
# ---------------------------------------------------------------------------
def apply_markov(proj: dict, model: MarkovModel, roles: list[str] | None = None,
                 rng: random.Random | None = None, density: float = 1.0,
                 keep_sections: bool = True) -> dict:
    """Podmienia wzory wybranych ról wzorami z modelu (in-place). Harmonia/sekcje/gainy zostają.

    Pomija tory zablokowane (lock_notes) i tory z routingiem notes_from (same nie grają).
    """
    rng = rng or random.Random(proj.get("seed") or 0)
    roles = set(roles) if roles else set(model.roles())
    bars = max(1, int(proj.get("bars") or 32))
    for tr in proj.get("tracks") or []:
        tt = tr.get("type") or ""
        if tt not in roles or tt not in (set(model.perc) | set(model.pitch)):
            continue
        if tr.get("lock_notes") or tr.get("notes_from"):
            continue
        pat = generate_pattern(model, tt, bars, rng, density=density)
        if pat:
            tr["notes"] = pat
            tr["markov"] = {"files": model.files, "bars": model.bars}
    if keep_sections:
        pass  # sekcje zostają bez zmian (jawnie: nic nie ruszamy)
    return proj
