"""constraint_solver.py — twarde ograniczenia zamiast cyklu „wygeneruj → wykryj → popraw”.

Zamiast poprawiać odstępstwa po fakcie (octave-fold w musicality_reviewer._clamp_notes),
rozwiązuje nuty tak, by od początku spełniały warunki:

  solve_register     — zakres rejestru per instrument: wybiera oktawę najbliższą pierwotnej
                       wysokości (klasa wysokości zachowana) — zamiast fold + losowe mieszanie.
  solve_kick_sub     — brak kolizji onsetów kick/sub w siatce 16-tk: przesunięcie nuty
                       basu na wolny sąsiedni slot zamiast nakładki.
  voice_lead_pair    — voice-leading akordów: optymalna permutacja kolejnej grupy nut
                       (minimalny sumaryczny ruch półtonów, ten sam zbiór klas wysokości).
  solve_chord_voicing— dobranie oktaw akordu (CSP): jeden parametr w oktawie na klasę
                       wysokości, all-different, w rejestrze, najbliżej poprzedniej voicingu.
  solve_pattern      — wzór perkusji jako CSP (downbeat obecny, odstępy, max gęstość) —
                       pojedyncze rozwiązanie spełniające warunki, do użycia per takt.

Backendi (wybór automatyczny wg dostępności, wszystkie OPCJONALNE):
  ortools  CP-SAT  (import ortools) — najszybszy, do dużych instancji
  python-constraint (import constraint) — czysty Python, do małych instancji
  greedy/domknięcie w numpy — zawsze dostępny, deterministyczny

Rdzeń Studia działa bez żadnej z tych zależności (jak mido w midi_import.py).
Wpięcie: musicality_reviewer.apply_symbolic(cfg["solver"]=True) → apply_constraints().
"""
from __future__ import annotations

import itertools
import random

try:  # opcjonalnie, jak mido w midi_import.py
    import constraint as _pyconstraint
except ImportError:  # pragma: no cover
    _pyconstraint = None

try:  # opcjonalnie
    from ortools.sat.python import cp_model as _cpsat  # type: ignore
except ImportError:  # pragma: no cover
    _cpsat = None

BACKENDS = ("ortools", "python-constraint", "greedy")


def available_backend(pref: str = "auto") -> str:
    """Najlepszy dostępny backend: ortools → python-constraint → greedy."""
    order = ["ortools", "python-constraint", "greedy"]
    if pref in order[:-1]:
        order = [pref] + [b for b in order if b != pref]
    for b in order:
        if b == "ortools" and _cpsat is not None:
            return b
        if b == "python-constraint" and _pyconstraint is not None:
            return b
        if b == "greedy":
            return b
    return "greedy"


# ---------------------------------------------------------------------------
# 1) Rejestr — nuta do zakresu najbliższą oktawą (klasa wysokości zachowana)
# ---------------------------------------------------------------------------
def solve_register(tr: dict, lo: int, hi: int) -> int:
    """Przenosi nuty do [lo,hi] najbliższą oktawą; zwraca liczbę zmienionych.

    Deterministycznie minimalizuje |nowa − stara| (w odróżnieniu od octave-fold,
    który przy rozjazdach potrafi wypchać nutę na skraj okna)."""
    if tr.get("lock_notes") or not tr.get("notes"):
        return 0
    changed = 0
    for i, n in enumerate(tr["notes"]):
        k = int(n[2])
        if lo <= k <= hi:
            continue
        # kandydaci: wszystkie oktawy klasy wysokości mieszczące się w [lo,hi]
        base = k % 12
        cands = [base + 12 * o for o in range(0, 128, 1) if lo <= base + 12 * o <= hi]
        if not cands:  # zakres nie zawiera tej klasy wysokości — najbliższa legalna nuta
            cands = [max(lo, min(hi, k))]
        k2 = min(cands, key=lambda c: abs(c - k))
        if k2 != k:
            notes = tr["notes"]
            notes[i] = [n[0], n[1], k2, n[3], *n[4:]]
            changed += 1
    return changed


# ---------------------------------------------------------------------------
# 2) Kolizje kick/sub na siatce 16-tk
# ---------------------------------------------------------------------------
SUB_TYPES = ("sub", "bass808")
_TOL = 1e-3


def solve_kick_sub(proj: dict, tol_beats: float = 0.13, shift: float = 0.25) -> int:
    """Usuwa coincidentne onsety kick ↔ sub (tolerancja w bitach): nuta basu przesuwa się
    na najbliższy wolny slot siatki 16-tk (± shift), a gdy zajęty — zostaje (ducking audio
    załatwia resztę). Zwraca liczbę przesuniętych nut."""
    kicks = []
    for tr in proj.get("tracks") or []:
        if (tr.get("type") or "") == "kick" and not tr.get("mute"):
            kicks += [round(float(n[0]), 4) for n in (tr.get("notes") or [])]
    if not kicks:
        return 0
    moved = 0
    for tr in proj.get("tracks") or []:
        if (tr.get("type") or "") not in SUB_TYPES or tr.get("lock_notes"):
            continue
        notes = tr.get("notes") or []
        occupied = {round(float(n[0]), 4) for n in notes}
        out = []
        for n in notes:
            on = float(n[0])
            clash = any(abs(on - k) <= tol_beats + _TOL for k in kicks)
            if not clash:
                out.append(n)
                continue
            # najbliższy wolny slot w siatce 16-tk (±1..2 sloty), nie wcześniej niż 0
            cands = [round(on + d * shift, 4) for d in (1, -1, 2, -2, 3)]
            cands = [c for c in cands if c >= 0.0 and c not in occupied and
                     not any(abs(c - k) <= tol_beats + _TOL for k in kicks)]
            if not cands:
                out.append(n)
                continue
            on2 = min(cands, key=lambda c: abs(c - on))
            occupied.add(on2)
            out.append([on2, n[1], n[2], n[3], *n[4:]])
            moved += 1
        if moved:
            tr["notes"] = out
    return moved


# ---------------------------------------------------------------------------
# 3) Voice-leading — optymalna permutacja między grupami nut
# ---------------------------------------------------------------------------
def _groups_by_onset(notes: list) -> list[list]:
    """Grupy nut o (prawie) tej samej pozycji — kolejne akordy/simultané."""
    gs: list[list] = []
    for n in sorted(notes, key=lambda x: float(x[0])):
        if gs and abs(float(n[0]) - float(gs[-1][0][0])) < 0.06:
            gs[-1].append(n)
        else:
            gs.append([n])
    return gs


def voice_lead_pair(prev: list[int], cur: list[int]) -> list[int] | None:
    """Permutacja `cur` minimalizująca sumę |Δ| względem prev (równe długości).

    Zachowuje multiset nut (= ten sam akord), więc harmonia się nie zmienia —
    zmienia się tylko rozłożenie głosów. None, gdy brak poprawy (jest już optymalnie)."""
    if len(prev) != len(cur) or len(cur) < 2 or len(set(cur)) < len(cur):
        return None
    best, best_cost = None, None
    for perm in itertools.permutations(cur):
        cost = sum(abs(a - b) for a, b in zip(prev, perm))
        if best_cost is None or cost < best_cost:
            best, best_cost = list(perm), cost
    if best == cur:
        return None
    return best


def voice_lead_track(tr: dict) -> int:
    """Voice-leading jednej ścieżki (kolejne grupy simultané) — permutacje w miejscu.
    Zwraca liczbę zmienionych nut."""
    if tr.get("lock_notes") or not tr.get("notes"):
        return 0
    gs = _groups_by_onset(tr["notes"])
    changed = 0
    for i in range(1, len(gs)):
        prev_keys = [int(n[2]) for n in gs[i - 1]]
        cur_keys = [int(n[2]) for n in gs[i]]
        if len(prev_keys) != len(cur_keys):
            continue
        best = voice_lead_pair(prev_keys, cur_keys)
        if best is None:
            continue
        for n, k in zip(gs[i], best):
            if int(n[2]) != k:
                n[2] = k
                changed += 1
    return changed


# ---------------------------------------------------------------------------
# 4) Voicing akordu jako CSP (backendi: ortools / python-constraint / greedy)
# ---------------------------------------------------------------------------
def solve_chord_voicing(pcs: list[int], lo: int, hi: int, prev: list[int] | None = None,
                         backend: str = "auto") -> list[int] | None:
    """Dobiera po jednej nucie na klasę wysokości `pcs` (każda w innej oktawie? nie —
    każda w dowolnej oktawie, ale all-different), w rejestrze [lo,hi], minimalizując
    odległość od `prev` (voicing wcześniej). Brak prev → środek rejestru.

    To jest „jedno rozwiązanie spełniające warunki” zamiast generowania i poprawiania.
    Zwraca None, gdy nie da się spełnić (za wąski rejestr itp.)."""
    backend = available_backend(backend)
    doms = []
    for pc in pcs:
        opts = [pc + 12 * o for o in range(128) if lo <= pc + 12 * o <= hi]
        if not opts:
            return None
        doms.append(opts)
    if len(doms) > 6:
        backend = "greedy"  # małe instancje wystarczą; CSP dla >6 głosów nieopłacalne tutaj

    ref = list(prev) if prev else [int((lo + hi) / 2)] * len(pcs)
    if len(ref) != len(doms):
        ref = [ref[min(i, len(ref) - 1)] for i in range(len(doms))]
    if backend == "ortools":
        res = _voicing_cpsat(doms, ref)
        if res is not None:
            return res
        backend = "python-constraint"
    if backend == "python-constraint":
        res = _voicing_pyconstraint(doms, ref)
        if res is not None:
            return res
    return _voicing_greedy(doms, ref)


def _voicing_cost(sol: list[int], ref: list[int]) -> float:
    return sum(abs(a - b) for a, b in zip(sol, ref))


def _voicing_cpsat(doms, ref):
    try:
        m = _cpsat.CpModel()
        xs = []
        for i, opts in enumerate(doms):
            xs.append(m.NewIntVarFromDomain(_cpsat.Domain.FromValues(opts), f"x{i}"))
        m.AddAllDifferent(xs)
        obj = m.NewIntVar(0, 10 ** 6, "obj")
        m.Add(obj == sum(abs(x - int(r)) for x, r in zip(xs, ref)))
        m.Minimize(obj)
        s = _cpsat.CpSolver()
        s.parameters.max_time_in_seconds = 2.0
        if s.Solve(m) in (s.OPTIMAL, s.FEASIBLE):
            return [int(s.Value(x)) for x in xs]
    except Exception:
        return None
    return None


def _voicing_pyconstraint(doms, ref):
    try:
        p = _pyconstraint.Problem()
        names = [f"v{i}" for i in range(len(doms))]
        for n, opts in zip(names, doms):
            p.addVariable(n, opts)
        p.addConstraint(_pyconstraint.AllDifferentConstraint(), names)
        sols = p.getSolution()  # pierwsze — sortujemy domeny wg bliskości ref
        if sols is None:
            return None
        # python-constraint nie optymalizuje: greedy poprawka na sprzeżeniu sąsiadów
        base = [sols[n] for n in names]
        return _voicing_greedy(doms, ref, start=base)
    except Exception:
        return None


def _voicing_greedy(doms, ref, start=None):
    """Kolejne przypisanie (permutacja niemutowalna) + lokalna poprawa zamianami
    par — deterministycznie, zawsze w domenie i all-different."""
    sol = list(start) if start else []
    used: set[int] = set()
    for i, opts in enumerate(doms):
        if i < len(sol) and sol[i] in opts and sol[i] not in used:
            used.add(sol[i])
            continue
        cand = sorted(opts, key=lambda o: abs(o - ref[i]))
        pick = next((o for o in cand if o not in used), None)
        if pick is None:
            return None
        sol.append(pick) if len(sol) == i else sol.__setitem__(i, pick)
        used.add(pick)
    if len(sol) != len(doms):
        return None
    # lokalna poprawka: zamiany par obniżające koszt
    improved = True
    guard = 0
    while improved and guard < 32:
        improved = False
        guard += 1
        for i in range(len(sol)):
            for j in range(i + 1, len(sol)):
                if sol[i] in doms[j] and sol[j] in doms[i]:
                    cur = abs(sol[i] - ref[i]) + abs(sol[j] - ref[j])
                    alt = abs(sol[j] - ref[i]) + abs(sol[i] - ref[j])
                    if alt < cur:
                        sol[i], sol[j] = sol[j], sol[i]
                        improved = True
    return sol


# ---------------------------------------------------------------------------
# 5) Wzór perkusji jako CSP — jedno rozwiązanie spełniające warunki
# ---------------------------------------------------------------------------
def solve_pattern(present: list[int] = None, size: int = 16, density: float = 0.5,
                  must: tuple[int, ...] = (0,), forbid: tuple[int, ...] = (),
                  max_run: int = 4, backend: str = "auto") -> list[int] | None:
    """Wybiera podzbiór kroków siatki 16-tk spełniający twarde warunki:

      * kroki z `must` zawsze, kroki z `forbid` nigdy;
      * liczba kroków = round(density*size) (gęstość dokłędna);
      * brak serii > max_run kolejnych kroków ani > max_run kolejnych pauz
        (równe rozmieszczenie — nie „wszystko z lewej”).

    Backend ortools/CP-SAT modeluje to wprost; greedy buduje rozmieszczenie
    najbliższe równomiernemu. Zwraca posortowaną listę kroków albo None."""
    backend = available_backend(backend)
    must = [s % size for s in must]
    forbid = set(s % size for s in forbid)
    if set(must) & forbid:
        return None
    k = max(len(must), min(size - len(forbid), round(density * size)))
    if k <= 0:
        return []
    if k > size - len(forbid):
        return None
    if backend == "ortools":
        try:
            m = _cpsat.CpModel()
            xs = [m.NewBoolVar(f"s{i}") for i in range(size)]
            m.Add(sum(xs) == k)
            for s in must:
                m.Add(xs[s] == 1)
            for s in forbid:
                m.Add(xs[s] == 0)
            for r in range(0, size - max_run):
                m.Add(sum(xs[r:r + max_run + 1]) <= max_run)     # max_run kolejnych nut
                m.Add(sum(xs[r:r + max_run + 1]) >= 1)           # max_run kolejnych pauz
            # premia za równomierność: odległości między kolejnymi krokami ~ size/k
            ideal = size / k
            s = _cpsat.CpSolver()
            s.parameters.max_time_in_seconds = 2.0
            if s.Solve(m) in (s.OPTIMAL, s.FEASIBLE):
                return [i for i in range(size) if s.Value(xs[i])]
        except Exception:
            pass
    # greedy: rozmieszczenie równomierne + must + localne poprawki
    steps = sorted(set(must))
    need = k - len(steps)
    if need > 0:
        ideal_pos = [round(i * size / k) for i in range(k)]
        for p in ideal_pos:
            if need <= 0:
                break
            if p not in steps and p not in forbid:
                steps.append(p)
                need -= 1
        c = 0
        while need > 0 and c < size * 4:
            p = c % size
            if p not in steps and p not in forbid:
                steps.append(p)
                need -= 1
            c += 1
    steps = sorted(set(steps))
    if len(steps) != k:
        return None
    return steps


# ---------------------------------------------------------------------------
# Orchestrator — wpięcie w musicality_reviewer.apply_symbolic (cfg["solver"]=True)
# ---------------------------------------------------------------------------
CHORD_TYPES = ("pad", "strings", "choir", "organ", "epiano", "stab", "piano", "harpsichord")


def apply_constraints(proj: dict, intensity: float = 1.0, rng: random.Random | None = None,
                      profile_ranges: dict | None = None, backend: str = "auto") -> dict:
    """Jeden przebieg twardych ograniczeń na projekcie (in-place):

    1) rejestr per tor (zamiast octave-fold),
    2) kolizje kick/sub,
    3) voice-leading torów akordowych,
    4) voicingi z proj["chords"] dla torów akordowych bez własnych simultané
       (opcjonalnie, gdy tor ma mało nut — patrz intensity).

    Zwraca statystyki {backend, register, collisions, voice}."""
    from . import musicality_reviewer as MR
    rng = rng or random.Random()
    bk = available_backend(backend)
    stats = {"backend": bk, "register": 0, "collisions": 0, "voice": 0}

    # 1) rejestr
    for tr in proj.get("tracks") or []:
        tt = tr.get("type") or ""
        if not tt or tt in MR.UNPITCHED:
            continue
        lo, hi = MR._note_range_for(tt, profile_ranges)
        stats["register"] += solve_register(tr, lo, hi)

    # 2) kolizje kick/sub
    stats["collisions"] = solve_kick_sub(proj)

    # 3) voice-leading torów akordowych
    for tr in proj.get("tracks") or []:
        if (tr.get("type") or "") in CHORD_TYPES:
            stats["voice"] += voice_lead_track(tr)

    # 4) voicingi z progresji (intensywniejszy wariant: tory akordowe z mało nutami)
    chords = proj.get("chords") or []
    if chords and intensity >= 0.5:
        root = int(proj.get("key") or 0) % 12
        for tr in proj.get("tracks") or []:
            tt = tr.get("type") or ""
            if tt not in ("pad", "strings", "choir") or tr.get("lock_notes"):
                continue
            lo, hi = MR._note_range_for(tt, profile_ranges)
            prev = None
            # co takt: [root, trzecia] — voicing 3 głosów (root, tercja, kwinta skali)
            scale_iv = _scale_of(proj)
            pos = {}
            for n in sorted(tr.get("notes") or [], key=lambda x: float(x[0])):
                bar = int(float(n[0]) // 4)
                pos.setdefault(bar, []).append(n)
            for bar in sorted(pos):
                c = chords[bar % len(chords)] if bar < len(chords) else chords[-1]
                pcs = [int((root + int(c[0])) % 12), int((root + int(c[0]) + int(c[1])) % 12)]
                fifth = int((root + int(c[0]) + scale_iv[4] if len(scale_iv) > 4 else 7) % 12)
                pcs.append(fifth)
                sol = solve_chord_voicing(pcs, lo, hi, prev=prev, backend=bk)
                if sol is None:
                    prev = None
                    continue
                # nanies na nuty tego taktu (kolejność rosnąco)
                for n, k in zip(pos[bar], sol):
                    n[2] = int(k)
                    stats["voice"] += 1
                prev = sol
    return stats


def _scale_of(proj: dict) -> tuple:
    from . import core
    return core.SCALES.get(proj.get("scale") or "minor", (0, 2, 3, 5, 7, 8, 10))
