"""tempo_link.py — nadrzędny suwak „Gęstość ↔ BPM”.

PROBLEM (zmierzony na generatorze): `density` było prawdopodobieństwem na krok siatki 1/16, więc liczba zdarzeń na
SEKUNDĘ rosła liniowo z BPM przy tej samej „gęstości” (Brostep 120→170 BPM: 18→25 zd./s, ×1,41 = 170/120), a
`build_climate()` dostawał bpm i go nie używał. Ten sam suwak dawał więc wolny utwór pusty, a szybki — kłębowisko,
mimo że gatunki są projektowane pod własne tempo (Drumstep ~174, EDM ~128, Brostep ~140).

MODEL. Punktem odniesienia jest tempo projektowe stylu (`STYLES[styl]["bpm"]`); przy nim nic się nie zmienia.
Gęstość skuteczna = gęstość × mul, gdzie  mul = (bpm / bpm_ref) ^ wykładnik(link):

   link = +1  RÓWNOWAGA        wykładnik −1     → zd./s ≈ stałe niezależnie od tempa (wolniej = więcej nut na takt)
   link =  0  WG TAKTU         wykładnik  0     → jak dawniej (zd./s rosną proporcjonalnie do BPM)
   link = −1  INTENSYWNOŚĆ     wykładnik +0,6   → szybciej = gęściej (zd./s rosną szybciej niż BPM)

czyli zdarzenia na sekundę ∝ (bpm/ref)^(1 − link) dla link ≥ 0. Suwak pozwala jednym użytkownikom dobrać „intensywność
parującą się z BPM”, innym — równowagę w wybranym stopniu. Dla pewności mul jest ograniczony do [0,55 … 1,60].

To samo tempo dyktuje też „tor” rytmiczny: `perceptual_norms.grid_table(bpm)` mówi, jaka najdrobniejsza siatka jest
jeszcze komfortowa dla stopy/hatu/basu/melodii przy danym BPM (np. 16-tki w hacie do ~158 BPM, ale ciągłe 16-tki w
melodii tylko do ~105 BPM) — patrz producer_exam.py (strażnik tempa zdarzeń).
"""
from __future__ import annotations

DEFAULT_LINK = 0.5                       # nowy domyślny stopień równowagi (przy tempie projektowym i tak bez zmian)
REF_FALLBACK = 140.0
MUL_MIN, MUL_MAX = 0.55, 1.60
AMPLIFY_EXP = 0.6                        # siła strony „intensywność za BPM”
DENS_MIN, DENS_MAX = 0.12, 1.0


def clamp_link(link) -> float:
    try:
        return max(-1.0, min(1.0, float(link)))
    except (TypeError, ValueError):
        return DEFAULT_LINK


def nominal_bpm(style) -> float:
    """Tempo projektowe stylu (także hybrydy). Brak danych → 140."""
    try:
        from . import generator as G
        v = float(G.STYLES[style].get("bpm") or 0)
        if v > 0:
            return v
    except Exception:
        pass
    return REF_FALLBACK


def exponent(link: float) -> float:
    link = clamp_link(link)
    return -link if link >= 0 else -link * AMPLIFY_EXP


def density_mul(bpm: float, ref_bpm: float, link: float) -> float:
    """Mnożnik gęstości dla tempa `bpm` względem `ref_bpm`. Przy bpm == ref zawsze 1.0."""
    try:
        ratio = float(bpm) / float(ref_bpm)
    except (TypeError, ValueError, ZeroDivisionError):
        return 1.0
    if ratio <= 0:
        return 1.0
    return max(MUL_MIN, min(MUL_MAX, ratio ** exponent(link)))


def effective_density(density: float, mul: float) -> float:
    return max(DENS_MIN, min(DENS_MAX, float(density) * float(mul)))


def mode_label(link: float) -> str:
    link = clamp_link(link)
    if link >= 0.85:
        return "równowaga (zd./s stałe względem tempa)"
    if link >= 0.2:
        return "równowaga częściowa"
    if link > -0.2:
        return "wg taktu (jak dawniej)"
    if link > -0.85:
        return "intensywność częściowo za BPM"
    return "intensywność za BPM"


def describe(style, bpm, link) -> dict:
    """Opis sprzężenia zapisywany w projekcie (proj['tempo_link']); Ctx czyta stąd `mul`."""
    link = clamp_link(link)
    ref = nominal_bpm(style)
    bpm = float(bpm or ref)
    mul = density_mul(bpm, ref, link)
    ratio = bpm / ref if ref else 1.0
    return {
        "link": round(link, 3),
        "bpm": round(bpm, 2),
        "ref_bpm": round(ref, 2),
        "ratio": round(ratio, 4),
        "mul": round(mul, 4),
        "drift": round(ratio * mul, 4),          # (zd./s przy tym BPM) / (zd./s przy tempie projektowym)
        "mode": mode_label(link),
    }


def mul_of(proj) -> float:
    """Mnożnik z projektu (stare projekty bez klucza = 1.0, czyli dawne zachowanie bit-w-bit)."""
    tl = proj.get("tempo_link") if isinstance(proj, dict) else None
    try:
        return float(tl.get("mul", 1.0)) if isinstance(tl, dict) else 1.0
    except (TypeError, ValueError):
        return 1.0
