"""section_smooth.py — spójność sekcji: wygładzenie „środkowa zawsze z sąsiednich".

Motywacja (review): po wstrzyknięciu już pełnego zapisu partii (import MIDI, gotowa
sekcja z presetu/boardu) parametry sekcji — przede wszystkim energia e0/e1 — nie niosą
żadnej informacji z sąsiedztwa: e1 sekcji i-tej i e0 sekcji (i+1)-tej są niezależne, więc
na granicy sekcji energia potrafi skoczyć (rampa `core.signal("energy")` czyta e0/e1
bezpośrednio). Naiwne kaskadowe przenoszenie wag „od poprzedniej do następnej" rodzi
chroniczne zagmatwanie (dryf kompozycji: każda sekcja dziedziczy po już przesuniętej).

Rozwiązanie: KAŻDA sekcja liczona jest ze SNAPSHOTU oryginalnych wartości (schemat
Jakobiego, nie Gaussa–Seidla) i bierze sąsiadów po OBU stronach — „środkowa zawsze
z sąsiednich"; skrajne sekcje mają tylko jednego sąsiada (efekt jednostronny).
To złożenie wypukłe, więc wyniki nigdy nie wychodzą poza [min, max] oryginałów —
niezależnie od siły i liczby przebiegów dryf nie może narastać.

Integracja: czysta funkcja (bez RNG, bez zależności zewnętrznych). Wpięcia:
  • generator.generate(section_smooth=0..1, section_smooth_passes=1..8) — po
    apply_climate_to_sections, przed nutami;
  • CLI: gen --section-smooth 0.6 --section-smooth-passes 2;
  • GUI: „Wygładzenie sekcji" (checkbox + siła + przebiegi + Zastosuj na bieżącym projekcie);
  • bezpośrednio: smooth_sections(proj, ...) → raport w proj["section_smooth_report"].
Pola kategorialne sekcji (type/name/start/bars/k) pozostają nietknięte.
"""
from __future__ import annotations

VERSION = 1
DEFAULT_VALUE = 0.7       # brak klucza → zgodnie z idiomem simplify_experiment
LO, HI = 0.05, 1.2        # ten sam zakres klamrowania co simplify_experiment

_MAX_PASSES = 8


def smooth_sections(proj: dict, strength: float = 0.5, passes: int = 1,
                    keys=("e0", "e1"), lo: float = LO, hi: float = HI) -> dict:
    """Wygładź sekwencję sekcji sąsiedztwem (snapshot, bez kaskady).

    Dla każdego klucza k z keys (wartości ciągłe, np. e0/e1):
      - sekcja środkowa: v' = (1-s)·v + s·(v_poprz + v_nast) / 2
      - sekcja skrajna:  v' = (1-s)·v + s·v_jedynego_sąsiada
    Wszystkie wartości sąsiadów pochodzą z ORYGINALNEGO snapshotu bieżącego przebiegu
    (Jakobi): kolejność sekcji nie ma znaczenia i nie ma sprzężenia zwrotnego.
    passes > 1 powtarza cykl na wyniku poprzedniego (szerszy kernel sąsiedztwa;
    nadal złożenie wypukłe — brak dryfu poza [min, max] oryginałów pierwszego przebiegu).

    strength 0..1 (0 = bez zmian), passes 1..8, klamra [lo, hi] (domyślnie 0.05–1.2).
    Sekcje bez słownika (np. [typ, takty]) oraz z bars<=0 są pomijane.
    Zwraca raport i zapisuje go w proj["section_smooth_report"].
    """
    strength = max(0.0, min(1.0, float(strength)))
    passes = max(1, min(_MAX_PASSES, int(passes)))
    lo, hi = float(lo), float(hi)
    secs = [s for s in (proj.get("sections") or [])
            if isinstance(s, dict) and int(s.get("bars") or 0) > 0]
    rep = {"version": VERSION, "strength": round(strength, 3), "passes": passes,
           "sections": len(secs), "keys": {}}
    if not secs or strength <= 0.0:
        proj["section_smooth_report"] = rep
        return rep
    for key in keys:
        orig = [float(s.get(key, DEFAULT_VALUE)) for s in secs]
        cur = list(orig)
        for _ in range(passes):
            nxt = []
            for i, v in enumerate(cur):
                if len(cur) == 1:
                    nb = v                                   # jedyna sekcja — brak sąsiadów
                elif i == 0:
                    nb = cur[1]
                elif i == len(cur) - 1:
                    nb = cur[i - 1]
                else:
                    nb = 0.5 * (cur[i - 1] + cur[i + 1])
                nxt.append(max(lo, min(hi, v + (nb - v) * strength)))
            cur = nxt
        n_ch, max_d = 0, 0.0
        for s, nv in zip(secs, cur):
            ov = float(s.get(key, DEFAULT_VALUE))
            if abs(nv - ov) > 1e-4:
                s[key] = round(nv, 3)
                n_ch += 1
                max_d = max(max_d, abs(nv - ov))
        rep["keys"][key] = {"changed": n_ch, "max_delta": round(max_d, 4)}
    proj["section_smooth_report"] = rep
    return rep
