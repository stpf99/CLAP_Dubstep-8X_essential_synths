"""invert_experiment.py — eksperyment „odwróć każde wystąpienie na przeciwwagę”.

Po ostatnim etapie generacji (po egzaminie, po user_rules.finalize) opcjonalnie
zamienia to, co da się sensownie odwrócić, na lustrzane przeciwieństwo — żeby
posłuchać, co z tego wyjdzie. Deterministyczne (seed z projektu).

Odwracane wymiary (każdy z własną rangą — wyższa = ważniejsza / wcześniej
w łańcuchu, niższe nie nadpisują zablokowanych):

  R100  lock_notes / lock_sound / lock_gain — NIGDY nie ruszamy
  R90   nuty melodyczne: inwersja wysokości wokół środka toru
  R85   nuty: inwersja velocity (cicho↔głośno)
  R80   nuty: odwrócenie w czasie w obrębie każdej sekcji
  R70   sekcje: e0↔e1 (łuk energii)
  R60   gain toru: odbicie względem 0.75 (środek użytecznego zakresu)
  R50   parametry ciągłe 0..1: x → 1−x (poza zablokowanymi i dyskretnymi)
  R40   swing → −swing (jeśli był niezerowy)

Perkusyjny rdzeń (kick/snare na mocnych beatach) zostaje nietknięty w czasie
i wysokości — odwracamy tylko velocity i ewentualne fille poza siatką 1/4.
FX (riser/boom/zap) — tylko velocity i gain, bez odwracania czasu (zachowują
kierunek narastania).

Wynik: proj['invert_report'] = {applied: [...], skipped: [...], dims: {...}}.
"""
from __future__ import annotations

import math
import random
from typing import Any

VERSION = 1

# role → czy wolno odwracać wysokość / czas
_PITCH_OK = {"bass", "lead", "mallet", "pad"}
_TIME_OK = {"bass", "lead", "mallet", "pad", "hat", "perc", "backbeat"}
_CORE_DRUM = {"kick", "backbeat"}  # wysokość + siatka 1/4 chronione

# parametry dyskretne / enum — nie odwracamy (1−x nie ma sensu)
_SKIP_PARAMS = {
    "Waveform", "LFO Shape", "LFO Division", "Unison Voices", "Noise Bursts",
    "Key Track", "Retrigger", "Choke", "Mode", "Algorithm",
}

# ranga aplikacji post-gen (wyższa = później / ma ostatnie słowo)
# — dokumentacja kolejności w generator.generate(); invert ma rangę 10 (ostatni eksperyment)
APPLICATION_RANKS = {
    "structure_affinity": 40,
    "critical_correct": 50,
    "musicality_reviewer": 60,
    "producer_exam": 70,
    "user_rules.finalize": 80,
    "simplify_experiment": 95,
    "invert_experiment": 100,   # eksperyment: ostatnie słowo
    "sanitize_notes": 105,
}


def _role(ttype: str) -> str:
    try:
        from . import perceptual_norms as PN
        return PN.role_of(ttype)
    except Exception:
        return "lead"


def _sec_type(s: dict) -> str:
    return str(s.get("type") or str(s.get("name", "")).rstrip("0123456789"))


def _clamp_key(k: int) -> int:
    return max(0, min(127, int(round(k))))


def _clamp_vel(v: int) -> int:
    return max(1, min(127, int(round(v))))


def _invert_pitches(notes: list, rng: random.Random) -> int:
    """Inwersja wysokości wokół środka (min+max)/2 toru."""
    if not notes:
        return 0
    keys = [int(n[2]) for n in notes]
    mid = (min(keys) + max(keys)) / 2.0
    n_ch = 0
    for n in notes:
        nk = _clamp_key(2 * mid - int(n[2]))
        if nk != int(n[2]):
            n[2] = nk
            n_ch += 1
    return n_ch


def _invert_velocities(notes: list) -> int:
    n_ch = 0
    for n in notes:
        nv = _clamp_vel(128 - int(n[3]))
        if nv != int(n[3]):
            n[3] = nv
            n_ch += 1
    return n_ch


def _invert_time_in_sections(notes: list, sections: list) -> int:
    """Odwróć onsets w obrębie każdej sekcji (lustrzane odbicie czasu)."""
    if not notes or not sections:
        return 0
    n_ch = 0
    by_sec: list[tuple[float, float, list]] = []
    for s in sections:
        b0 = int(s.get("start", 0)) * 4.0
        b1 = b0 + int(s.get("bars", 0)) * 4.0
        if b1 <= b0:
            continue
        sel = [n for n in notes if b0 - 1e-9 <= float(n[0]) < b1 - 1e-9]
        by_sec.append((b0, b1, sel))
    for b0, b1, sel in by_sec:
        if len(sel) < 2:
            continue
        for n in sel:
            on, dur = float(n[0]), float(n[1])
            # lustro: koniec nuty → początek okna
            new_on = round(b0 + b1 - (on + dur), 4)
            if new_on < b0:
                new_on = b0
            if abs(new_on - on) > 1e-6:
                n[0] = new_on
                n_ch += 1
    notes.sort(key=lambda n: (n[0], n[2]))
    return n_ch


def _protect_core_drums(notes: list, role: str) -> list:
    """Zwraca kopię nut; dla kick/backbeat chroni pozycje blisko siatki 1/4."""
    if role not in _CORE_DRUM:
        return [list(n) for n in notes]
    out = []
    for n in notes:
        on = float(n[0])
        fr = on - math.floor(on)
        # mocne beaty (0 i 0.5 w obrębie ćwierćnuty) — zostają
        if fr < 0.08 or abs(fr - 0.5) < 0.08:
            out.append(list(n))
        else:
            out.append(list(n))  # fille też kopiujemy; czas odwracamy tylko poza core
    return out


def _invert_section_energy(sections: list) -> int:
    n_ch = 0
    for s in sections:
        e0, e1 = float(s.get("e0", 0.7)), float(s.get("e1", 0.7))
        if abs(e0 - e1) < 1e-6:
            # płaskie — odwróć względem 0.85 (typowe centrum)
            ne = round(max(0.05, min(1.3, 1.7 - e0)), 3)
            if abs(ne - e0) > 1e-6:
                s["e0"] = s["e1"] = ne
                n_ch += 1
        else:
            s["e0"], s["e1"] = e1, e0
            n_ch += 1
    return n_ch


def _invert_gain(tr: dict) -> bool:
    if tr.get("lock_gain"):
        return False
    g = float(tr.get("gain", 0.75))
    # odbicie względem 0.75 w zakresie ~0.15..1.35
    ng = max(0.15, min(1.35, 1.5 - g))
    if abs(ng - g) < 1e-4:
        return False
    tr["gain"] = round(ng, 3)
    return True


def _invert_params(tr: dict) -> int:
    if tr.get("lock_sound"):
        return 0
    locked = set(tr.get("locked_params") or [])
    params = tr.get("params") or {}
    n_ch = 0
    for name, val in list(params.items()):
        if name in locked or name in _SKIP_PARAMS:
            continue
        try:
            v = float(val)
        except (TypeError, ValueError):
            continue
        # tylko wartości wyglądające na ułamek 0..1
        if 0.0 <= v <= 1.0:
            nv = round(1.0 - v, 4)
            if abs(nv - v) > 1e-6:
                params[name] = nv
                n_ch += 1
        # wartości w typowych zakresach silnika (np. Cutoff 0..1 już złapane;
        # większe liczby typu Decay ms — pomijamy)
    return n_ch


def apply(proj: dict, rng: random.Random | None = None, strength: float = 1.0) -> dict:
    """Odwróć projekt in-place. strength 0..1 (1 = pełne odwrócenie).

    Zwraca raport; zapisuje też w proj['invert_report'] i proj['invert_experiment']=True.
    """
    strength = max(0.0, min(1.0, float(strength)))
    if strength <= 0.0:
        rep = {"version": VERSION, "applied": [], "skipped": ["strength=0"], "dims": {}}
        proj["invert_report"] = rep
        return rep

    rng = rng or random.Random(f"invert:{proj.get('seed', 0)}")
    applied: list[str] = []
    skipped: list[str] = []
    dims: dict[str, Any] = {}

    sections = [s for s in (proj.get("sections") or []) if int(s.get("bars", 0)) > 0]

    # --- R70 sekcje energia
    if sections and strength >= 0.5:
        n = _invert_section_energy(sections)
        dims["section_energy"] = n
        if n:
            applied.append(f"energia sekcji ({n})")
    else:
        skipped.append("section_energy")

    # --- tory
    pitch_n = vel_n = time_n = gain_n = param_n = 0
    for tr in proj.get("tracks") or []:
        if tr.get("mute"):
            continue
        role = _role(tr.get("type", ""))
        notes = tr.get("notes") or []

        # R100 locki
        if tr.get("lock_notes"):
            skipped.append(f"notes:{tr.get('name')} (lock_notes)")
        elif notes and strength > 0.0:
            work = [list(n) for n in notes]

            # R90 pitch
            if role in _PITCH_OK and strength >= 0.4:
                pitch_n += _invert_pitches(work, rng)

            # R85 velocity (zawsze, także perkusja)
            if strength >= 0.3:
                vel_n += _invert_velocities(work)

            # R80 time — nie dla core kick na siatce i nie dla FX
            if role in _TIME_OK and role not in ("kick",) and strength >= 0.6:
                # kick: pomijamy całe odwrócenie czasu; backbeat/hat OK
                time_n += _invert_time_in_sections(work, sections)

            tr["notes"] = work

        # R60 gain
        if strength >= 0.5 and _invert_gain(tr):
            gain_n += 1

        # R50 params
        if strength >= 0.7:
            param_n += _invert_params(tr)

    dims.update(pitch=pitch_n, velocity=vel_n, time=time_n, gain=gain_n, params=param_n)
    if pitch_n:
        applied.append(f"wysokości ×{pitch_n}")
    if vel_n:
        applied.append(f"velocity ×{vel_n}")
    if time_n:
        applied.append(f"czas w sekcjach ×{time_n}")
    if gain_n:
        applied.append(f"gain ×{gain_n}")
    if param_n:
        applied.append(f"parametry ×{param_n}")

    # --- R40 swing
    sw = float(proj.get("swing") or 0.0)
    if abs(sw) > 1e-6 and strength >= 0.5:
        proj["swing"] = round(-sw, 4)
        applied.append(f"swing {sw:+.2f}→{-sw:+.2f}")
        dims["swing"] = -sw
    else:
        skipped.append("swing")

    rep = {
        "version": VERSION,
        "strength": strength,
        "applied": applied,
        "skipped": skipped[:40],
        "dims": dims,
        "ranks": APPLICATION_RANKS,
    }
    proj["invert_report"] = rep
    proj["invert_experiment"] = True
    proj["invert_strength"] = strength
    return rep


def format_report(rep: dict) -> str:
    if not rep:
        return "Eksperyment odwrócenia wyłączony."
    L = [f"EKSPERYMENT ODWROĆENIA (siła {rep.get('strength', 1):.0%})"]
    ap = rep.get("applied") or []
    if ap:
        L.append("Zastosowano: " + ", ".join(ap))
    else:
        L.append("Nic nie odwrócono.")
    d = rep.get("dims") or {}
    if d:
        L.append("Wymiary: " + " · ".join(f"{k}={v}" for k, v in d.items() if v))
    return "\n".join(L)
