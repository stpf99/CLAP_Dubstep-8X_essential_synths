// generowane przez userinst.py — własne banki modalne (nie edytuj ręcznie)
