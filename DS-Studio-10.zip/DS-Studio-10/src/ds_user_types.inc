// generowane przez userinst.py — instrumenty użytkownika (nie edytuj ręcznie)
