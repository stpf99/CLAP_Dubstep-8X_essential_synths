#!/usr/bin/env python3
"""check_install.py — sprawdza strukturę pakietu dubstep_studio po rozpakowaniu/scalaniu plików.

Wykrywa: (1) importy względne wychodzące poza pakiet (np. `from ..rcore` w pliku leżącym w korzeniu pakietu zamiast w vid/),
(2) importy względne wskazujące na nieistniejący moduł (brakujący plik), (3) podejrzanie zduplikowane pliki (ta sama treść w korzeniu i w vid/),
(4) plik rcore.py bez klas Param/Plugin/Registry (nadpisany inną treścią), (5) próbny import wszystkich modułów (poza GUI, jeśli brak PyQt6).
Użycie: python3 check_install.py   (z katalogu dskit)"""
import ast
import hashlib
import importlib
import pkgutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "dubstep_studio"
problems = []


def resolve(py: Path, node: ast.ImportFrom):
    """-> (plik_docelowy_lub_None, komunikat_błędu_lub_None) dla importu względnego."""
    rel = py.relative_to(PKG.parent)
    pkg_parts = list(rel.parts[:-1])                       # pakiet pliku, np. ['dubstep_studio','vid']
    up = node.level - 1
    if up > len(pkg_parts) - 1:
        return None, "import względny wychodzi poza główny pakiet (plik leży o poziom za wysoko?)"
    base = ROOT.joinpath(*pkg_parts[: len(pkg_parts) - up])
    if node.module:
        tgt = base.joinpath(*node.module.split("."))
        if not (tgt.with_suffix(".py").exists() or (tgt / "__init__.py").exists()):
            return None, f"brak modułu {'.' * node.level}{node.module} (oczekiwany plik: {tgt.relative_to(ROOT)}.py)"
    else:
        for al in node.names:
            t = base / al.name
            if al.name != "*" and not (t.with_suffix(".py").exists() or (t / "__init__.py").exists()):
                # może to nazwa z __init__.py — pomiń, jeśli init istnieje
                if not (base / "__init__.py").exists():
                    return None, f"brak modułu {al.name} w {base.relative_to(ROOT)}"
    return None, None


for py in sorted(PKG.rglob("*.py")):
    try:
        tree = ast.parse(py.read_text(encoding="utf-8"))
    except SyntaxError as e:
        problems.append(f"{py.relative_to(ROOT)}: błąd składni: {e}"); continue
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.level:
            _, err = resolve(py, node)
            if err:
                problems.append(f"{py.relative_to(ROOT)}:{node.lineno}: {err}")

# duplikaty: ten sam plik w korzeniu i w vid/
vid = PKG / "vid"
if vid.exists():
    for f in sorted(vid.glob("*.py")):
        r = PKG / f.name
        if r.exists() and r.name != "__init__.py":
            same = hashlib.md5(r.read_bytes()).hexdigest() == hashlib.md5(f.read_bytes()).hexdigest()
            problems.append(f"dubel: dubstep_studio/{f.name} istnieje też w vid/ ({'identyczny' if same else 'inna wersja'}) — plik z korzenia pakietu prawdopodobnie wklejony za wysoko")

rc = PKG / "rcore.py"
if rc.exists():
    txt = rc.read_text(encoding="utf-8")
    for need in ("class Param", "class Plugin", "class Registry"):
        if need not in txt:
            problems.append(f"rcore.py nie zawiera „{need}” — plik został nadpisany inną treścią (np. host.py)")

sys.path.insert(0, str(ROOT))
import dubstep_studio  # noqa: E402
mods = ["dubstep_studio." + m.name for m in pkgutil.iter_modules(dubstep_studio.__path__)]
try:
    import dubstep_studio.vid as _v
    mods += ["dubstep_studio.vid." + m.name for m in pkgutil.iter_modules(_v.__path__)]
except Exception as e:
    problems.append(f"import dubstep_studio.vid: {e!r}")
for m in mods:
    try:
        importlib.import_module(m)
    except ModuleNotFoundError as e:
        if e.name and e.name.startswith("PyQt6"):
            continue
        problems.append(f"import {m}: {e!r}")
    except Exception as e:
        problems.append(f"import {m}: {e!r}")

if problems:
    print("PROBLEMY:")
    for p in problems:
        print(" -", p)
    sys.exit(1)
print(f"OK: struktura pakietu poprawna, zaimportowano {len(mods)} modułów.")
