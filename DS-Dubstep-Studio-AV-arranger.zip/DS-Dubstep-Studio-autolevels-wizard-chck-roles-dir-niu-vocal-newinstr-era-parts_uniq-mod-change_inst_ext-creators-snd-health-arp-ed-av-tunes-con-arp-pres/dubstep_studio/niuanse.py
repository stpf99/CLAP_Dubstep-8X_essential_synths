"""niuanse.py — zbiór reguł artykulacji / wariacji partii nut stosowanych PO generacji wzorów.

Siła s ∈ [−1, +1]:
  s < 0  — uproszczenie, spłaszczenie, mniej ruchu
  s ≈ 0  — lekkie, subtelne niuanse
  s > 0  — bogatsze wariacje (skale, arp, duo, zaniki, sekwencje)

Spektakularność (spectacle 0…1 lub nazwa trybu):
  monotone / plain / balanced / vivid / anthem
  wpływa na wielokrotność instancji instrumentów i intensywność reguł.
"""
from __future__ import annotations

import math
import random

# typy podatne na reguły melodyczne / harmoniczne
MELODIC_T = frozenset({
    "piano", "strings", "acid",
    "wobble", "reese", "neuro", "fmbass", "hollow", "growl",
    "screech", "supersaw", "pluck", "stab", "theremin", "panflute",
    "vox", "handpan", "tongue", "pad", "zap",
})
ARP_T = frozenset({"pluck", "stab", "supersaw", "handpan", "tongue", "panflute", "theremin", "screech", "piano", "acid"})
BASS_T = frozenset({"wobble", "reese", "neuro", "fmbass", "hollow", "growl", "sub", "acid"})
LEAD_T = frozenset({"screech", "supersaw", "pluck", "stab", "theremin", "panflute", "vox", "handpan", "tongue", "zap", "piano"})
PAD_T = frozenset({"pad", "reese", "hollow", "strings"})
DRUM_T = frozenset({"kick", "snare", "clap", "hat", "rim", "shaker", "tom", "crash", "ride"})

# spektakularność: nazwa → wartość 0…1 + mnożniki głosów (typ → docelowa liczba instancji przy pełnej sile)
SPECTACLE_MODES = {
    "monotone": 0.0,   # proste, powtarzalne, mało warstw
    "plain": 0.25,
    "balanced": 0.45,
    "vivid": 0.7,
    "anthem": 1.0,     # warstwy, duety, spatial, kilka leadów/basów
}
SPECTACLE_LABELS = {
    "monotone": "Monotonny (prosty)",
    "plain": "Prosty",
    "balanced": "Zbalansowany",
    "vivid": "Barwny / vivid",
    "anthem": "Anthem (spektakularny)",
}

# przy anthem: które typy mnożyć (min, max instancji przy spectacle=1)
VOICE_BOOST = {
    "supersaw": (1, 3), "pluck": (1, 3), "stab": (1, 2), "pad": (1, 2),
    "screech": (1, 2), "wobble": (1, 2), "reese": (1, 2), "neuro": (1, 2),
    "piano": (1, 2), "strings": (1, 2), "acid": (1, 2),
    "hat": (1, 2), "clap": (0, 1), "shaker": (0, 1),
}


def spectacle_value(mode_or_float):
    if isinstance(mode_or_float, (int, float)):
        return max(0.0, min(1.0, float(mode_or_float)))
    return SPECTACLE_MODES.get(str(mode_or_float).strip().lower(), 0.45)


def expand_spectacle_voices(inst_list, spectacle, rng):
    """Dokłada / usuwa instancje typów wg spektakularności (nie dotyka skipów — caller filtruje)."""
    sp = spectacle_value(spectacle)
    out = list(inst_list)
    if sp < 0.15:
        # monotone: max 1 na typ (poza kick/snare/hat)
        seen, slim = set(), []
        for t in out:
            if t in ("kick", "snare", "hat") or t not in seen:
                slim.append(t); seen.add(t)
        return slim
    # boost
    for t, (lo, hi) in VOICE_BOOST.items():
        if t not in out:
            continue
        target = lo + int(round((hi - lo) * sp))
        if sp > 0.75 and t in LEAD_T and rng.random() < 0.35 * sp:
            target = min(hi + 1, target + 1)
        have = out.count(t)
        if have < target:
            out += [t] * (target - have)
        elif have > target and sp < 0.5:
            # przy niższej spektakularności nie ściągamy poniżej 1 jeśli był
            while out.count(t) > max(1, target):
                out.remove(t)
    return out


def _scale_pcs(proj):
    from .core import SCALES
    key = int(proj.get("key", 0))
    sc = SCALES.get(proj.get("scale", "minor"), [0, 2, 3, 5, 7, 8, 10])
    return sorted((key + d) % 12 for d in sc)


def _snap(k, pcs):
    """Najbliższy dźwięk skali. Przesunięcie liczone po najkrótszej drodze po okręgu klas wysokości,
    więc na granicy oktawy (np. B -> C) nota idzie o 1 półton, a nie o 11 w przeciwną stronę."""
    pc = k % 12
    best = min(pcs, key=lambda p: min((pc - p) % 12, (p - pc) % 12))
    return k + ((best - pc + 6) % 12 - 6)


def _region_mask(notes, frac0, frac1):
    """Zwraca indeksy nut w zakresie względnym czasu [frac0, frac1] partii."""
    if not notes:
        return []
    t0 = min(n[0] for n in notes)
    t1 = max(n[0] + n[1] for n in notes)
    span = max(0.25, t1 - t0)
    out = []
    for i, n in enumerate(notes):
        f = (n[0] - t0) / span
        if frac0 <= f <= frac1:
            out.append(i)
    return out


def _vel(n, mul):
    return [n[0], n[1], n[2], max(1, min(127, int(round(n[3] * mul))))]


# ------------------------------------------------------------------ reguły (każda: (waga_bazowa, fn(tr, proj, s, rng, pcs) -> notes|None))
def _r_scale_shift_region(tr, proj, s, rng, pcs):
    """Podniesienie/obniżenie skali na fragmencie (początek / środek / koniec)."""
    notes = tr["notes"]
    if len(notes) < 3 or tr["type"] not in MELODIC_T:
        return None
    region = rng.choice([(0.0, 0.35), (0.3, 0.7), (0.6, 1.0)])
    idx = _region_mask(notes, *region)
    if len(idx) < 2:
        return None
    steps = int(round(1 + abs(s) * 2))
    direction = 1 if s >= 0 else -1
    if rng.random() < 0.5:
        direction = -direction
    out = [list(n) for n in notes]
    for i in idx:
        k = out[i][2]
        for _ in range(steps):
            k = k + direction
            k = _snap(k, pcs)
        out[i][2] = k
    return out


def _r_velocity_swell(tr, proj, s, rng, pcs):
    """Częściowy zanik / wzmocnienie velocity (fade in/out lub swell w środku)."""
    notes = tr["notes"]
    if len(notes) < 3:
        return None
    mode = rng.choice(["fade_in", "fade_out", "swell", "dip"])
    if s < 0:
        mode = rng.choice(["fade_out", "dip"])
    t0 = min(n[0] for n in notes)
    t1 = max(n[0] + n[1] for n in notes)
    span = max(0.25, t1 - t0)
    amt = 0.25 + 0.55 * abs(s)
    out = []
    for n in notes:
        f = (n[0] - t0) / span
        if mode == "fade_in":
            mul = (1 - amt) + amt * f
        elif mode == "fade_out":
            mul = 1 - amt * f
        elif mode == "swell":
            mul = 1 - amt + 2 * amt * (1 - abs(2 * f - 1))
        else:
            mul = 1 - amt * (1 - abs(2 * f - 1))
        out.append(_vel(n, mul))
    return out


def _r_arp_trigger(tr, proj, s, rng, pcs):
    """Arp-like: rozbicie dłuższych nut na krótsze stopnie skali (trigger)."""
    notes = tr["notes"]
    if tr["type"] not in ARP_T and tr["type"] not in LEAD_T:
        return None
    if len(notes) < 1 or abs(s) < 0.15:
        return None
    step = 0.25 if abs(s) > 0.55 else 0.5  # 1/16 lub 1/8 w beatach
    dens = 0.35 + 0.55 * max(0, s)
    out = []
    for on, dur, k, v in notes:
        if dur < step * 1.5 or rng.random() > dens:
            out.append([on, dur, k, v])
            continue
        nsteps = max(2, int(dur / step))
        pattern = rng.choice([
            [0, 2, 4, 2], [0, 2, 4, 7], [0, 4, 2, 0], [0, 2, 3, 5],
            [0, -2, 0, 2], [0, 7, 4, 2],
        ])
        for i in range(nsteps):
            deg = pattern[i % len(pattern)]
            kk = _snap(k + deg, pcs)
            out.append([on + i * step, min(step * 0.9, dur - i * step), kk,
                        max(1, min(127, int(v * (0.85 + 0.15 * rng.random()))))])
    return out if out else None


def _r_monotone_seq(tr, proj, s, rng, pcs):
    """Sekwencja monofoniczna: jedna wysokość / mały motyw powtarzany (przy s<0 silniej)."""
    notes = tr["notes"]
    if tr["type"] not in MELODIC_T or len(notes) < 4:
        return None
    if s > 0.2 and rng.random() < 0.5:
        return None
    root = _snap(notes[0][2], pcs)
    motif_len = rng.choice([2, 3, 4])
    motif = [root]
    for i in range(1, motif_len):
        motif.append(_snap(root + rng.choice([0, 0, 2, 3, 5, 7] if s >= 0 else [0, 0, 0, 2]), pcs))
    out = []
    for i, (on, dur, k, v) in enumerate(notes):
        out.append([on, dur, motif[i % len(motif)], v])
    return out


def _r_duo_interval(tr, proj, s, rng, pcs):
    """Trigger duo: dokłada równoległy interwał (trzecja/kwinta/oktawa) na części nut."""
    notes = tr["notes"]
    if tr["type"] not in (LEAD_T | ARP_T) or len(notes) < 2 or s < 0.1:
        return None
    interval = rng.choice([3, 4, 5, 7, 12] if s > 0.4 else [3, 5, 12])
    dens = 0.3 + 0.5 * s
    out = [list(n) for n in notes]
    extras = []
    for on, dur, k, v in notes:
        if rng.random() > dens:
            continue
        extras.append([on, dur * rng.uniform(0.7, 1.0), _snap(k + interval, pcs),
                       max(1, int(v * 0.75))])
    out.extend(extras)
    out.sort(key=lambda n: (n[0], n[2]))
    return out


def _r_octave_jump(tr, proj, s, rng, pcs):
    """Skoki oktawowe na akcentach (początek frazy / mocniejsze velocity)."""
    notes = tr["notes"]
    if tr["type"] not in MELODIC_T or len(notes) < 3:
        return None
    thresh = 80 - int(20 * max(0, s))
    out = []
    for on, dur, k, v in notes:
        if v >= thresh and rng.random() < 0.25 + 0.4 * abs(s):
            k = k + (12 if s >= 0 else -12)
        out.append([on, dur, k, v])
    return out


def _r_stutter(tr, proj, s, rng, pcs):
    """Jąkanie / stutter na końcu nuty (krótkie powtórzenia)."""
    notes = tr["notes"]
    if tr["type"] in DRUM_T or len(notes) < 2 or s < 0.2:
        return None
    dens = 0.15 + 0.35 * s
    out = []
    for on, dur, k, v in notes:
        out.append([on, dur, k, v])
        if dur > 0.4 and rng.random() < dens:
            st = 0.125
            for j in range(rng.randint(1, 3)):
                out.append([on + dur - st * (j + 1) * 0.5, st * 0.8, k, max(1, int(v * 0.7))])
    out.sort(key=lambda n: (n[0], n[2]))
    return out


def _r_drum_ghost(tr, proj, s, rng, pcs):
    """Ghost notes na perkusji (ciche wstawki między uderzeniami)."""
    notes = tr["notes"]
    if tr["type"] not in ("snare", "hat", "rim", "clap") or len(notes) < 2:
        return None
    dens = 0.2 + 0.4 * max(0, s)
    if s < 0:
        dens *= 0.4
    out = [list(n) for n in notes]
    notes_s = sorted(notes, key=lambda n: n[0])
    for a, b in zip(notes_s, notes_s[1:]):
        gap = b[0] - (a[0] + a[1])
        if gap > 0.2 and rng.random() < dens:
            out.append([a[0] + a[1] + gap * 0.4, min(0.15, gap * 0.3), a[2],
                        max(1, int(a[3] * 0.35))])
    out.sort(key=lambda n: (n[0], n[2]))
    return out


def _r_humanize(tr, proj, s, rng, pcs):
    """Lekka humanizacja czasu i velocity."""
    notes = tr["notes"]
    if not notes:
        return None
    amt = 0.02 + 0.04 * abs(s)
    out = []
    for on, dur, k, v in notes:
        on2 = max(0.0, on + rng.uniform(-amt, amt))
        v2 = max(1, min(127, int(v + rng.randint(-8, 8) * (0.5 + abs(s)))))
        out.append([on2, dur, k, v2])
    out.sort(key=lambda n: (n[0], n[2]))
    return out


def _r_thin_or_fill(tr, proj, s, rng, pcs):
    """s<0: przerzedź; s>0: zagęść proste powtórzenia."""
    notes = tr["notes"]
    if len(notes) < 3:
        return None
    if s < -0.15:
        keep = 1.0 + s * 0.55  # s=-1 → ~0.45
        out = [list(n) for n in notes if rng.random() < keep]
        return out if len(out) >= 2 else None
    if s > 0.25 and tr["type"] in ARP_T:
        out = [list(n) for n in notes]
        for on, dur, k, v in notes:
            if rng.random() < 0.25 * s:
                out.append([on + 0.25, min(0.2, dur), _snap(k + rng.choice([0, 2, 4]), pcs),
                            max(1, int(v * 0.8))])
        out.sort(key=lambda n: (n[0], n[2]))
        return out
    return None


RULES = [
    ("scale_region", 1.0, _r_scale_shift_region),
    ("vel_swell", 0.9, _r_velocity_swell),
    ("arp_trigger", 0.85, _r_arp_trigger),
    ("monotone_seq", 0.7, _r_monotone_seq),
    ("duo_interval", 0.75, _r_duo_interval),
    ("octave_jump", 0.65, _r_octave_jump),
    ("stutter", 0.55, _r_stutter),
    ("drum_ghost", 0.6, _r_drum_ghost),
    ("humanize", 0.5, _r_humanize),
    ("thin_fill", 0.8, _r_thin_or_fill),
]


def apply_to_track(tr, proj, strength, rng, spectacle=0.45):
    """Aplikuje 1–N reguł do ścieżki. Szanuje lock_notes. Zwraca listę nazw reguł."""
    if tr.get("lock_notes") or not tr.get("notes"):
        return []
    s = max(-1.0, min(1.0, float(strength)))
    sp = spectacle_value(spectacle)
    # liczba reguł rośnie z |s| i spektakularnością
    n_rules = 1 + int(round(abs(s) * 2.5 + sp * 1.5))
    n_rules = max(1, min(len(RULES), n_rules))
    pcs = _scale_pcs(proj)
    # wagi: przy s<0 faworyzuj monotone/thin; przy s>0 arp/duo/swell
    weights = []
    for name, base, _fn in RULES:
        w = base
        if s < 0 and name in ("monotone_seq", "thin_fill", "vel_swell"):
            w *= 1.6
        if s > 0 and name in ("arp_trigger", "duo_interval", "octave_jump", "stutter"):
            w *= 1.4 + 0.6 * s
        if sp > 0.7 and name in ("duo_interval", "arp_trigger", "octave_jump"):
            w *= 1.3
        if sp < 0.2 and name in ("duo_interval", "stutter", "arp_trigger"):
            w *= 0.35
        weights.append(max(0.05, w))
    chosen = []
    pool = list(range(len(RULES)))
    wpool = list(weights)
    applied = []
    for _ in range(n_rules):
        if not pool:
            break
        i = rng.choices(range(len(pool)), wpool)[0]
        ri = pool.pop(i); wpool.pop(i)
        name, _b, fn = RULES[ri]
        new_notes = fn(tr, proj, s, rng, pcs)
        if new_notes is not None:
            tr["notes"] = new_notes
            applied.append(name)
    return applied


def apply_all(proj, strength, rng=None, spectacle=0.45):
    """Przechodzi wszystkie ścieżki. -> raport {track: [reguły]}."""
    rng = rng or random.Random(proj.get("seed", 0) + 42)
    s = float(strength)
    sp = spectacle_value(spectacle)
    # lekka korekta siły spektakularnością (anthem wzmacnia dodatnie niuanse)
    if s > 0:
        s = min(1.0, s * (0.85 + 0.3 * sp))
    report = {}
    for tr in proj.get("tracks") or []:
        applied = apply_to_track(tr, proj, s, random.Random(rng.random()), sp)
        if applied:
            report[tr["name"]] = applied
    proj["niuanse_report"] = report
    proj["niuanse_strength"] = s
    proj["spectacle"] = sp
    return report
