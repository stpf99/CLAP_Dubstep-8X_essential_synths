"""board_gui.py — pole szachowe stylów: lewa oś = BAZA (szkielet: rytm, struktura, tempo), górna oś = MUTACJA (to, co jest wszczepiane).
Klik w komórkę: poziom 0→1→2→3→0 (siła), prawy klik czyści; klik w nazwę stylu = czysty styl (przekątna). Wiele komórek = styl multihybrydowy."""
from __future__ import annotations

import random

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import generator as G, styles as S

ORDER = S.ORDER


class BoardWidget(W.QWidget):
    changed = QtCore.pyqtSignal()
    CELL, LEFT, TOP = 24, 150, 130

    def __init__(self):
        super().__init__()
        self.cells = {}                       # (r, c) -> poziom 1..3
        self.hover = None
        self.setMouseTracking(True)
        n = len(ORDER)
        self.setFixedSize(self.LEFT + n * self.CELL + 4, self.TOP + n * self.CELL + 4)
        self.group_ends = set()
        i = 0
        for _, ss in S.GROUPS:
            i += len(ss); self.group_ends.add(i)

    def _pos(self, e):
        x, y = e.position().x() - self.LEFT, e.position().y() - self.TOP
        n = len(ORDER)
        c, r = int(x // self.CELL) if x >= 0 else -1, int(y // self.CELL) if y >= 0 else -1
        return (r if 0 <= r < n else None), (c if 0 <= c < n else None)

    def mousePressEvent(self, e):
        r, c = self._pos(e)
        if e.button() == Qt.MouseButton.RightButton:
            if r is not None and c is not None:
                self.cells.pop((r, c), None)
        elif r is not None and c is not None:
            self._cycle((r, c))
        elif r is not None:                                  # nazwa stylu po lewej / u góry = czysty styl
            self._cycle((r, r))
        elif c is not None:
            self._cycle((c, c))
        self.update(); self.changed.emit()

    def _cycle(self, k):
        v = (self.cells.get(k, 0) + 1) % 4
        if v:
            self.cells[k] = v
        else:
            self.cells.pop(k, None)

    def mouseMoveEvent(self, e):
        r, c = self._pos(e)
        h = (r, c) if (r is not None or c is not None) else None
        if h != self.hover:
            self.hover = h; self.update()
        if r is not None and c is not None:
            lv = self.cells.get((r, c), 0)
            tip = f"Baza: {ORDER[r]}  ×  Mutacja: {ORDER[c]}" if r != c else f"Czysty {ORDER[r]}"
            QtWidgets_tip(self, e, tip + (f" — poziom {lv}" if lv else " — kliknij, aby dodać"))

    def leaveEvent(self, e):
        self.hover = None; self.update()

    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QtGui.QColor("#0f1115"))
        n, cs = len(ORDER), self.CELL
        f = p.font(); f.setPointSize(8); p.setFont(f)
        hr, hc = self.hover if self.hover else (None, None)
        for r in range(n):
            for c in range(n):
                x, y = self.LEFT + c * cs, self.TOP + r * cs
                rect = QtCore.QRectF(x, y, cs, cs)
                p.fillRect(rect, QtGui.QColor("#1d2027" if (r + c) % 2 == 0 else "#262a33"))   # szachownica
                if r == hr or c == hc:
                    p.fillRect(rect, QtGui.QColor(255, 255, 255, 18))
                lv = self.cells.get((r, c), 0)
                if lv:
                    a = (0, 95, 165, 240)[lv]
                    cr, cc = QtGui.QColor(S.STYLE_COL[ORDER[r]]), QtGui.QColor(S.STYLE_COL[ORDER[c]])
                    cr.setAlpha(a); cc.setAlpha(a)
                    inner = rect.adjusted(2, 2, -2, -2)
                    if r == c:
                        p.fillRect(inner, cr)
                    else:                                               # trójkąt górny-lewy = baza, dolny-prawy = mutacja
                        p.setPen(Qt.PenStyle.NoPen)
                        p.setBrush(cr); p.drawPolygon(QtGui.QPolygonF([inner.topLeft(), inner.topRight(), inner.bottomLeft()]))
                        p.setBrush(cc); p.drawPolygon(QtGui.QPolygonF([inner.topRight(), inner.bottomRight(), inner.bottomLeft()]))
                    p.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 1.5 if lv == 3 else 0.8)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawRect(inner)
                    p.setPen(QtGui.QColor("#ffffff")); p.drawText(rect, Qt.AlignmentFlag.AlignCenter, str(lv))
        # linie grup
        p.setPen(QtGui.QPen(QtGui.QColor("#6b7280"), 1.5))
        for g in self.group_ends:
            x = self.LEFT + g * cs; y = self.TOP + g * cs
            p.drawLine(int(x), self.TOP - 6, int(x), self.TOP + n * cs); p.drawLine(self.LEFT - 6, int(y), self.LEFT + n * cs, int(y))
        # etykiety: lewa oś (baza) i górna (mutacja, obrócona)
        used_r = {r for (r, c) in self.cells}; used_c = {c for (r, c) in self.cells}
        for i, name in enumerate(ORDER):
            col = QtGui.QColor(S.STYLE_COL[name])
            ly = self.TOP + i * cs
            p.fillRect(QtCore.QRectF(self.LEFT - 12, ly + 6, 8, 12), col)
            p.setPen(QtGui.QColor("#ffffff" if (i in used_r or i == hr) else "#9ca3af"))
            p.drawText(QtCore.QRectF(2, ly, self.LEFT - 16, cs), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, name)
            lx = self.LEFT + i * cs
            p.fillRect(QtCore.QRectF(lx + 6, self.TOP - 12, 12, 8), col)
            p.save(); p.translate(lx + cs / 2 + 4, self.TOP - 16); p.rotate(-90)
            p.setPen(QtGui.QColor("#ffffff" if (i in used_c or i == hc) else "#9ca3af"))
            p.drawText(QtCore.QRectF(0, -cs / 2, self.TOP - 18, cs), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, name)
            p.restore()
        p.setPen(QtGui.QColor("#e5e7eb"))
        p.drawText(QtCore.QRectF(2, 4, self.LEFT - 10, 20), Qt.AlignmentFlag.AlignRight, "BAZA ↓")
        p.drawText(QtCore.QRectF(self.LEFT, 2, 200, 16), Qt.AlignmentFlag.AlignLeft, "MUTACJA →")


def QtWidgets_tip(widget, e, text):
    QtWidgets_QToolTip.showText(e.globalPosition().toPoint(), text, widget)


QtWidgets_QToolTip = W.QToolTip


class BoardTab(W.QWidget):
    changed = QtCore.pyqtSignal()

    def __init__(self, main):
        super().__init__()
        self.main = main
        h = W.QHBoxLayout(self)
        self.board = BoardWidget(); self.board.changed.connect(self._update)
        sa = W.QScrollArea(); sa.setWidget(self.board); h.addWidget(sa, 1)
        box = W.QWidget(); side = W.QVBoxLayout(box)
        side.addWidget(W.QLabel("<b>Pole szachowe stylów</b><br>Lewa oś = <b>baza</b> (rytm, struktura, tempo).<br>Górna oś = <b>mutacja</b> (to, co wszczepiasz).<br>"
                                "Klik w komórkę: siła 1→2→3→wył., prawy klik czyści, klik w nazwę stylu = czysty styl.<br>"
                                "Zaznacz wiele komórek = styl multihybrydowy."))
        self.recipe = W.QLabel("Receptura: —"); self.recipe.setWordWrap(True); self.recipe.setTextFormat(Qt.TextFormat.RichText)
        side.addWidget(self.recipe)
        self.strength = W.QSlider(Qt.Orientation.Horizontal); self.strength.setRange(0, 100); self.strength.setValue(40)
        self.s_lbl = W.QLabel("Siła mutacji: 40 %"); self.strength.valueChanged.connect(self._update)
        side.addWidget(self.s_lbl); side.addWidget(self.strength)
        for txt, fn in (("Zastosuj do Generatora", self.apply_gen), ("Użyj w Live (strumień)", self.use_live), ("Losuj hybrydę", self.randomize), ("Wyczyść", self.clear)):
            b = W.QPushButton(txt); b.clicked.connect(fn); side.addWidget(b)
        self.msg = W.QLabel(""); self.msg.setWordWrap(True); side.addWidget(self.msg); side.addStretch(1)
        box.setFixedWidth(300); h.addWidget(box)
        self._update()

    # --- stan
    def cells_list(self):
        return [[ORDER[r], ORDER[c], lv] for (r, c), lv in sorted(self.board.cells.items())]

    def get_strength(self):
        return self.strength.value() / 100.0

    def set_cells(self, cells):
        self.board.cells = {}
        for b, m, lv in cells:
            if b in ORDER and m in ORDER:
                self.board.cells[(ORDER.index(b), ORDER.index(m))] = max(1, min(3, int(lv)))
        self.board.update(); self._update()

    def set_strength(self, f):
        self.strength.setValue(int(round(float(f) * 100)))

    def name(self):
        return S.board_name([tuple(x) for x in self.cells_list()], self.get_strength())

    def _update(self):
        self.s_lbl.setText(f"Siła mutacji: {self.strength.value()} %")
        w = S.board_weights([tuple(x) for x in self.cells_list()], self.get_strength())
        if not w:
            self.recipe.setText("Receptura: — (zaznacz komórki)")
        else:
            tot = sum(w.values())
            rows = "".join(f"<span style='color:{S.STYLE_COL[n]}'>■</span> {n} <b>{100 * v / tot:.0f}%</b><br>" for n, v in sorted(w.items(), key=lambda kv: -kv[1]))
            self.recipe.setText("Receptura:<br>" + rows)
        self.changed.emit()

    # --- akcje
    def apply_gen(self):
        n = self.name()
        if not n:
            self.msg.setText("Zaznacz co najmniej jedną komórkę."); return
        self.main.use_style(n); self.main.tabs.setCurrentIndex(0)
        self.msg.setText(f"W Generatorze: {n}")

    def use_live(self):
        if not self.board.cells:
            self.msg.setText("Zaznacz co najmniej jedną komórkę."); return
        self.main.live.use_board.setChecked(True); self.msg.setText("Live używa pola szachowego (zakładka Live → Tryb auto → Mutacje).")

    def randomize(self):
        rng = random.Random(); base = rng.randrange(len(ORDER)); self.board.cells = {(base, base): 3}
        for m in rng.sample([i for i in range(len(ORDER)) if i != base], rng.randint(1, 3)):
            self.board.cells[(base, m)] = rng.randint(1, 3)
        self.board.update(); self._update()

    def clear(self):
        self.board.cells = {}; self.board.update(); self._update()
