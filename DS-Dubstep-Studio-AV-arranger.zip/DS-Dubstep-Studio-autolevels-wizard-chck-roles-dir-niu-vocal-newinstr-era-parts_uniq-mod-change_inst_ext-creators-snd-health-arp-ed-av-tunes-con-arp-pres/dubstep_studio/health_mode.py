"""health_mode.py — tryb zdrowotny / regeneracja / trening (offline).

Nadrzędnie kształtuje generację (sekcje, gęstość, BPM w czasie, stereo „hemisync”,
dobór instrumentów) pod sesję: odpoczynek umysłu, redukcja stresu, trening
percepcji, lekki ruch. Nie zastępuje stylu — nakłada reguły na dowolny gatunek.
"""
from __future__ import annotations

import math
import random

MODES = (
    "mind_rest",       # odpoczynek umysłu / hemisync-ish
    "stress_relief",   # redukcja stresu
    "mind_train",      # trening umysłu / percepcja
    "body_train",      # trening ciała / rytm
    "perception",      # wzmocnienie percepcji odsłuchowej
)

MODE_LABELS = {
    "mind_rest": "Odpoczynek umysłu (hemi-sync)",
    "stress_relief": "Redukcja stresu / wyciszenie",
    "mind_train": "Trening umysłu (uwaga / sekwencje)",
    "body_train": "Trening ciała (ruch / puls)",
    "perception": "Percepcja odsłuchowa (tony / BPM)",
}

# profile: jak agresywnie upraszczać i jak prowadzić łuk sesji
PROFILES = {
    "mind_rest": dict(
        density_mul=0.35, energy_mul=0.4, spectacle="monotone",
        era="minimal_70s", uniq_strength=0.25, niuanse_strength=0.15,
        max_tracks=6, prefer_roles=("pad", "bass", "lead"),
        avoid_types=("growl", "neuro", "screech", "zap", "boom", "speak"),
        bpm_curve="slow_arch",     # start wolno → lekko w górę → wolno
        bpm_span=0.08,             # ±% wokół bazowego BPM
        section_bias="gentle",     # długie intro/outro, miękkie buildy
        hemisync=True, beat_hz=(4.0, 8.0),  # różnica L/R ~ fale theta/alpha
        swing_mul=0.3,
    ),
    "stress_relief": dict(
        density_mul=0.4, energy_mul=0.35, spectacle="plain",
        era="analog_80s", uniq_strength=0.3, niuanse_strength=0.1,
        max_tracks=7, prefer_roles=("pad", "bass"),
        avoid_types=("growl", "neuro", "screech", "stab", "zap", "boom"),
        bpm_curve="descend", bpm_span=0.06,
        section_bias="soft_fade", hemisync=True, beat_hz=(3.0, 6.0),
        swing_mul=0.4,
    ),
    "mind_train": dict(
        density_mul=0.65, energy_mul=0.55, spectacle="balanced",
        era="digital_90s", uniq_strength=0.55, niuanse_strength=0.45,
        max_tracks=10, prefer_roles=("lead", "pad", "bass"),
        avoid_types=("speak",),
        bpm_curve="steps", bpm_span=0.12,
        section_bias="varied", hemisync=False, beat_hz=(6.0, 12.0),
        swing_mul=0.7, sequence_focus=True,
    ),
    "body_train": dict(
        density_mul=0.75, energy_mul=0.8, spectacle="vivid",
        era="rave_00s", uniq_strength=0.4, niuanse_strength=0.25,
        max_tracks=12, prefer_roles=("drums", "bass", "lead"),
        avoid_types=("theremin", "handpan"),
        bpm_curve="pulse_up", bpm_span=0.1,
        section_bias="drive", hemisync=False, beat_hz=(8.0, 12.0),
        swing_mul=0.5, strong_kick=True,
    ),
    "perception": dict(
        density_mul=0.55, energy_mul=0.5, spectacle="balanced",
        era="modern_10s", uniq_strength=0.6, niuanse_strength=0.55,
        max_tracks=9, prefer_roles=("lead", "pad", "drums"),
        avoid_types=("speak", "growl"),
        bpm_curve="wander", bpm_span=0.15,
        section_bias="contrast", hemisync=True, beat_hz=(5.0, 14.0),
        swing_mul=0.6, tone_variety=True,
    ),
}


def normalize_cfg(cfg):
    if not cfg or not cfg.get("on"):
        return {"on": False}
    mode = cfg.get("mode") or "mind_rest"
    if mode not in PROFILES:
        mode = "mind_rest"
    intensity = max(0.0, min(1.0, float(cfg.get("intensity", 0.6))))
    return {"on": True, "mode": mode, "intensity": intensity}


def profile(cfg):
    c = normalize_cfg(cfg)
    if not c["on"]:
        return None
    return PROFILES[c["mode"]]


def apply_to_generate_kwargs(kw, cfg, rng=None):
    """Modyfikuje argumenty generate() (density, energy, spectacle, era, niuanse…)."""
    c = normalize_cfg(cfg)
    if not c["on"]:
        return kw
    rng = rng or random.Random()
    p = PROFILES[c["mode"]]
    t = c["intensity"]
    kw = dict(kw)
    dens = float(kw.get("density") or 0.6)
    eng = float(kw.get("energy") or 0.7)
    kw["density"] = max(0.12, min(1.0, dens * (p["density_mul"] + (1 - p["density_mul"]) * (1 - t) * 0.5)))
    kw["energy"] = max(0.12, min(1.0, eng * (p["energy_mul"] + (1 - p["energy_mul"]) * (1 - t) * 0.5)))
    if not kw.get("spectacle") or kw.get("spectacle") == "balanced":
        kw["spectacle"] = p["spectacle"]
    if not kw.get("era") or kw.get("era") in ("auto", ""):
        kw["era"] = p["era"]
    # niuanse / uniq
    if p.get("niuanse_strength", 0) > 0:
        kw["niuanse"] = True
        base = float(kw.get("niuanse_strength") or 0)
        kw["niuanse_strength"] = max(base, p["niuanse_strength"] * t)
    if p.get("uniq_strength", 0) > 0:
        kw["uniq"] = True
        kw["uniq_strength"] = max(float(kw.get("uniq_strength") or 0), p["uniq_strength"] * t)
    if "swing" in kw and kw["swing"] is not None:
        kw["swing"] = float(kw["swing"]) * p.get("swing_mul", 1.0)
    kw["_health"] = c
    return kw


def ensure_section_energy(proj):
    """Uzupełnia brakujące e0/e1 na sekcjach (wymagane przez core.signal energy)."""
    e_map = {
        "intro": (0.3, 0.4), "build": (0.5, 0.9), "drop": (1.0, 1.0),
        "break": (0.35, 0.35), "outro": (0.3, 0.1),
    }
    for s in proj.get("sections") or []:
        if "e0" not in s or "e1" not in s:
            e0, e1 = e_map.get(s.get("type"), (0.4, 0.5))
            s.setdefault("e0", e0)
            s.setdefault("e1", e1)


def reshape_sections(proj, cfg, rng=None):

    """Przebudowuje sekcje pod łuk sesji zdrowotnej (delikatny start/koniec itd.)."""
    c = normalize_cfg(cfg)
    if not c["on"] or not proj.get("sections"):
        return
    rng = rng or random.Random(proj.get("seed", 0) + 33)
    p = PROFILES[c["mode"]]
    bias = p.get("section_bias") or "gentle"
    secs = list(proj["sections"])
    total = sum(s.get("bars", 4) for s in secs) or proj.get("bars") or 64
    if bias == "gentle":
        # 25% intro-like, 50% middle soft, 25% outro
        parts = [("intro", 0.28), ("break", 0.22), ("drop", 0.22), ("outro", 0.28)]
    elif bias == "soft_fade":
        parts = [("intro", 0.2), ("break", 0.35), ("drop", 0.15), ("outro", 0.3)]
    elif bias == "varied":
        parts = [("intro", 0.15), ("build", 0.2), ("drop", 0.25), ("break", 0.15), ("drop", 0.15), ("outro", 0.1)]
    elif bias == "drive":
        parts = [("intro", 0.1), ("build", 0.2), ("drop", 0.35), ("break", 0.1), ("drop", 0.2), ("outro", 0.05)]
    elif bias == "contrast":
        parts = [("intro", 0.12), ("drop", 0.2), ("break", 0.2), ("build", 0.15), ("drop", 0.2), ("outro", 0.13)]
    else:
        return
    e_map = {
        "intro": (0.25, 0.35), "build": (0.45, 0.75), "drop": (0.7, 0.75),
        "break": (0.3, 0.3), "outro": (0.3, 0.15),
    }
    # health: niższa energia w rest modes
    mode = c.get("mode") or ""
    scale = 0.55 if mode in ("mind_rest", "stress_relief") else 0.75 if mode == "perception" else 0.9
    new, pos = [], 0
    for i, (typ, frac) in enumerate(parts):
        b = max(4, int(round(total * frac / 4) * 4))
        if i == len(parts) - 1:
            b = max(4, total - pos)
        e0, e1 = e_map.get(typ, (0.4, 0.5))
        new.append({
            "name": f"{typ}{i+1}", "type": typ, "start": pos, "bars": b,
            "e0": round(e0 * scale, 3), "e1": round(e1 * scale, 3),
        })
        pos += b
    proj["sections"] = new
    proj["bars"] = pos
    # dopełnij chords
    ch = proj.get("chords") or []
    while len(ch) < pos:
        ch.append(ch[-1] if ch else [0, 3])
    proj["chords"] = ch[:pos]


def filter_tracks(proj, cfg, rng=None):
    """Ogranicza liczbę torów, usuwa agresywne typy, ewentualnie zostawia preferowane role."""
    from . import instrument_replace as IR

    c = normalize_cfg(cfg)
    if not c["on"]:
        return
    p = PROFILES[c["mode"]]
    avoid = set(p.get("avoid_types") or [])
    max_t = int(p.get("max_tracks") or 8)
    tracks = [tr for tr in proj.get("tracks") or [] if tr.get("type") not in avoid]
    # preferuj role
    prefer = p.get("prefer_roles") or ()
    def score(tr):
        role = IR.TYPE_TO_ROLE.get(tr["type"], "")
        return (0 if role in prefer else 1, tr["type"])
    tracks = sorted(tracks, key=score)
    if len(tracks) > max_t:
        # zachowaj locked
        locked = [tr for tr in tracks if tr.get("lock_notes") or tr.get("lock_sound")]
        free = [tr for tr in tracks if tr not in locked]
        tracks = locked + free[: max(0, max_t - len(locked))]
    proj["tracks"] = tracks


def apply_hemisync(proj, cfg, rng=None):
    """Stereo pochodne: druga instancja pad/lead z lekkim detune i przesunięciem Fine (≈ różnica częstotliwości)."""
    from . import core, generator as G

    c = normalize_cfg(cfg)
    if not c["on"]:
        return []
    p = PROFILES[c["mode"]]
    if not p.get("hemisync"):
        return []
    rng = rng or random.Random(proj.get("seed", 0) + 44)
    lo_hz, hi_hz = p.get("beat_hz") or (4.0, 8.0)
    target_beat = lo_hz + (hi_hz - lo_hz) * c["intensity"]
    # przy ~440Hz, fine ~ centach; uproszczenie: Fine ± mała wartość + pan L/R
    events = []
    carriers = [tr for tr in proj.get("tracks") or []
                if tr["type"] in ("pad", "strings", "hollow", "reese", "supersaw", "pluck", "piano")
                and not tr.get("lock_sound")]
    if not carriers:
        return []
    src = carriers[0]
    # oznacz źródło
    src.setdefault("params", {})
    src["params"]["Fine"] = float(src["params"].get("Fine", 0.5))
    src["pan"] = -0.55
    src["health_hemi"] = "L"
    # klon
    try:
        right = core.new_track(G.unique_name(proj, src["type"]), src["type"])
    except Exception:
        return []
    right["plugin"] = src.get("plugin")
    right["params"] = dict(src.get("params") or {})
    # różnica Fine (0..1 w param) — symboliczna; host interpretuje
    delta = 0.02 + 0.04 * (target_beat / 12.0)
    right["params"]["Fine"] = min(1.0, float(right["params"].get("Fine", 0.5)) + delta)
    right["pan"] = 0.55
    right["notes"] = [list(n) for n in (src.get("notes") or [])]
    right["health_hemi"] = "R"
    right["gain"] = float(src.get("gain", 0.7)) * 0.95
    proj["tracks"].append(right)
    events.append({"left": src["name"], "right": right["name"], "beat_hz_target": round(target_beat, 2)})
    try:
        proj["tracks"] = G._order_tracks(proj["tracks"])
    except Exception:
        pass
    return events


def apply_bpm_automation(proj, cfg):
    """Zapisuje krzywą BPM sesji do proj['health_bpm'] (lista {bar, bpm}) — host/Live może czytać."""
    c = normalize_cfg(cfg)
    if not c["on"]:
        return
    p = PROFILES[c["mode"]]
    base = float(proj.get("bpm") or 120)
    span = float(p.get("bpm_span") or 0.08) * c["intensity"]
    curve = p.get("bpm_curve") or "slow_arch"
    bars = int(proj.get("bars") or 32)
    pts = []
    for b in range(bars):
        x = b / max(1, bars - 1)
        if curve == "slow_arch":
            # wolno → lekko wyżej w środku → wolno
            y = math.sin(math.pi * x)
        elif curve == "descend":
            y = 1.0 - x
        elif curve == "steps":
            y = int(x * 4) / 3.0
        elif curve == "pulse_up":
            y = x * 0.7 + 0.3 * (0.5 + 0.5 * math.sin(x * math.pi * 4))
        elif curve == "wander":
            y = 0.5 + 0.5 * math.sin(x * math.pi * 2.3) * math.cos(x * math.pi * 0.7)
        else:
            y = 0.5
        bpm = base * (1.0 - span + 2 * span * max(0.0, min(1.0, y)))
        pts.append({"bar": b, "bpm": round(bpm, 2)})
    proj["health_bpm"] = pts
    proj["health_mode"] = c


def apply_perception_notes(proj, cfg, rng=None):
    """Dla perception / mind_train: urozmaica rejestry i gęstość sekwencji na leadach."""
    c = normalize_cfg(cfg)
    if not c["on"]:
        return
    p = PROFILES[c["mode"]]
    if not (p.get("tone_variety") or p.get("sequence_focus")):
        return
    rng = rng or random.Random(proj.get("seed", 0) + 51)
    for tr in proj.get("tracks") or []:
        if tr.get("lock_notes") or not tr.get("notes"):
            continue
        if tr["type"] not in ("pluck", "piano", "stab", "supersaw", "screech", "theremin", "panflute", "hat"):
            continue
        notes = tr["notes"]
        if p.get("tone_variety"):
            for n in notes:
                if rng.random() < 0.25 * c["intensity"]:
                    n[2] = max(24, min(96, n[2] + rng.choice([-12, -7, -5, 5, 7, 12])))
        if p.get("sequence_focus") and len(notes) > 4:
            # co kilka nut — dłuższa przerwa (oddech sekwencji)
            for i, n in enumerate(notes):
                if i % 5 == 4:
                    n[1] = min(n[1], 0.15)


def apply_all(proj, cfg, rng=None):
    """Pełna warstwa health po generacji nut (sekcje mogą być wcześniej)."""
    c = normalize_cfg(cfg)
    proj["health_mode"] = c
    if not c["on"]:
        return {}
    rng = rng or random.Random(int(proj.get("seed", 0)) + 33)
    reshape_sections(proj, c, rng)
    ensure_section_energy(proj)
    filter_tracks(proj, c, rng)
    hemi = apply_hemisync(proj, c, rng)
    apply_bpm_automation(proj, c)
    apply_perception_notes(proj, c, rng)
    return {"mode": c["mode"], "intensity": c["intensity"], "hemisync": hemi,
            "bpm_points": len(proj.get("health_bpm") or [])}
