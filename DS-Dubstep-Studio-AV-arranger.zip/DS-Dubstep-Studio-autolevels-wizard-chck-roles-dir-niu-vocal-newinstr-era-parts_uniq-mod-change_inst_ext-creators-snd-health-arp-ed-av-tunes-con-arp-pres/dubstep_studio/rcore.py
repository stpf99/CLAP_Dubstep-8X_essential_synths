"""rcore.py — WSPÓLNY rdzeń renderu audio i wideo.

Audio: wtyczki CLAP hostowane przez `dsrender` (core.py). Wideo: wtyczki Pythona (pakiet vid/). Obie strony mówią tym samym językiem:
  Param     — opis parametru (zakres, domyślna, typ) — jak parametry CLAP; wartości w GUI/presetach/linkach to ułamki 0..1
  Plugin    — klasa z listą Param; kind: audio | room | performer | brush | fx | overlay | camera
  Registry  — rejestr wtyczek danego świata (wideo: VREG); audio_descriptors() opisuje wtyczki CLAP w tym samym formacie
  Link      — powiązanie sygnał → parametr (kick → siła błysku), jak linki audio (core.build_automation)
  Job       — neutralny opis zadania renderu (wtyczka + parametry + zdarzenia + obwiednie) — to, co dsrender czyta z pliku .job
Dzięki temu GUI, presety, CLI (`plugins`) i zapis projektu traktują wtyczki audio i wideo jednolicie."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field


@dataclass
class Param:
    name: str
    lo: float = 0.0
    hi: float = 1.0
    default: float = 0.5
    kind: str = "lin"                    # lin | int | choice | bool
    choices: tuple = ()
    desc: str = ""

    def clamp(self, v):
        if self.kind == "choice":
            return v if v in self.choices else self.default
        if self.kind == "bool":
            return bool(v)
        v = max(self.lo, min(self.hi, float(v)))
        return int(round(v)) if self.kind == "int" else v

    def frac(self, v):
        if self.kind == "choice":
            return self.choices.index(v) / max(1, len(self.choices) - 1) if v in self.choices else 0.0
        if self.kind == "bool":
            return 1.0 if v else 0.0
        return 0.0 if self.hi == self.lo else (float(v) - self.lo) / (self.hi - self.lo)

    def from_frac(self, f):
        f = max(0.0, min(1.0, float(f)))
        if self.kind == "choice":
            return self.choices[min(len(self.choices) - 1, int(f * len(self.choices)))]
        if self.kind == "bool":
            return f >= 0.5
        v = self.lo + f * (self.hi - self.lo)
        return int(round(v)) if self.kind == "int" else v


class Plugin:
    """Bazowa wtyczka. Podklasy ustawiają id, kind, title, PARAMS i implementują render (wideo) — patrz vid/."""
    id = ""
    kind = ""
    title = ""
    desc = ""
    PARAMS: list = []

    def __init__(self, **params):
        self.p = {pm.name: pm.default for pm in self.PARAMS}
        self.set(**params)

    @classmethod
    def specs(cls):
        return {pm.name: pm for pm in cls.PARAMS}

    def set(self, **kw):
        sp = self.specs()
        for k, v in kw.items():
            if k in sp:
                self.p[k] = sp[k].clamp(v)
        return self

    def randomize(self, rng=None, lo=0.0, hi=1.0, keep=()):
        """Losuje parametry w oknie ułamków [lo, hi] (nie zawsze min…max — jak okna brzmienia w reżyserze audio)."""
        rng = rng or random.Random()
        for pm in self.PARAMS:
            if pm.name not in keep:
                self.p[pm.name] = pm.from_frac(rng.uniform(lo, hi))
        return self


class Registry:
    def __init__(self, world):
        self.world = world
        self._d = {}

    def register(self, cls):
        self._d[cls.id] = cls
        return cls

    def get(self, pid):
        return self._d[pid]

    def __contains__(self, pid):
        return pid in self._d

    def list(self, kind=None):
        return [c for c in self._d.values() if kind is None or c.kind == kind]

    def make(self, pid, **params):
        return self._d[pid](**params)

    def describe(self, kind=None):
        return [dict(id=c.id, kind=c.kind, title=c.title, desc=c.desc, world=self.world,
                     params=[dict(name=p.name, lo=p.lo, hi=p.hi, default=p.default, type=p.kind, choices=list(p.choices)) for p in c.PARAMS])
                for c in self.list(kind)]


@dataclass
class Link:
    """src (sygnał) → param warstwy dst, amount −1…1 (ułamek zakresu parametru)."""
    src: str
    dst: str
    param: str
    amount: float = 0.5

    def to_dict(self):
        return dict(src=self.src, dst=self.dst, param=self.param, amount=self.amount)


def apply_links(links, sig_value, layer_params, specs_of):
    """Stosuje linki do słowników parametrów warstw (kopie): value = base_frac + amount * sygnał (0..1), z przycięciem do zakresu.
    layer_params: {layer_id: {param: value}}, sig_value(name)->float, specs_of(layer_id)->{param: Param}."""
    out = {k: dict(v) for k, v in layer_params.items()}
    for L in links:
        dst = out.get(L["dst"])
        if dst is None:
            continue
        sp = specs_of(L["dst"]).get(L["param"])
        if sp is None or sp.kind in ("choice", "bool"):
            continue
        s = sig_value(L["src"])
        dst[L["param"]] = sp.from_frac(sp.frac(dst.get(L["param"], sp.default)) + float(L.get("amount", 0.5)) * s)
    return out


@dataclass
class Job:
    """Neutralny opis zadania renderu (audio: plik .job dla dsrender; wideo: warstwa + zakres klatek)."""
    plugin: str
    params: dict = field(default_factory=dict)
    events: list = field(default_factory=list)       # [(start_beat, dur_beats, key, vel)]
    lanes: dict = field(default_factory=dict)        # {param: [(beat, frac)]}
    span: tuple = (0.0, 0.0)


def audio_descriptors():
    """Wtyczki CLAP (audio) w tym samym formacie opisu co wtyczki wideo (do list/GUI/CLI)."""
    from . import core
    out = []
    try:
        m = core.meta()
    except Exception:
        return out
    for t in core.TYPES:
        pid = core.PLUGIN_ID.get(t)
        pl = m.plugins.get(pid)
        if pl is None:
            continue
        params = [dict(name=n, lo=p["lo"], hi=p["hi"], default=p["def"], type=p["kind"], choices=list(p.get("texts") or []), unit=p.get("unit", ""))
                  for n, p in pl["params"].items()]
        out.append(dict(id=t, kind="audio", title=pl.get("name", t), desc="CLAP", world="audio", params=params))
    return out


def bpm_to_spf(bpm, fps):
    """Klatek na takt (4 ćwierćnuty)."""
    return fps * 240.0 / bpm


def smooth_step(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def lerp(a, b, t):
    return a + (b - a) * t


def hsv(h, s=1.0, v=1.0):
    """h 0..1 → (r,g,b) 0..1."""
    h = (h % 1.0) * 6.0
    i = int(h); f = h - i
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    return [(v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q)][i % 6]
