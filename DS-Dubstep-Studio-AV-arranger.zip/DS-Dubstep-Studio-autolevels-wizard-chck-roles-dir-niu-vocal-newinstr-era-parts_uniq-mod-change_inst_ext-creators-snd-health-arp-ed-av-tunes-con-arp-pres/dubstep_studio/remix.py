"""remix.py — auto-remix: ścieżki (instrumenty) z różnych projektów z biblioteki, sekcja po sekcji,
z przeharmonizowaniem melodycznych ścieżek do progresji projektu-matki (master)."""
from __future__ import annotations

import copy
import math
import random
import time

from .core import MELODIC, TYPES, find_track, first_of_type, key_name, load_project, new_project, new_track, sanitize_notes, track_of
from .generator import DUCK, duck_link


def _wrap(d):
    d = d % 12
    return d - 12 if d > 5 else d


def _fit_register(tname, key):
    if tname == "sub":
        while key < 24: key += 12
        while key > 35: key -= 12
    return key


def _sections_by_type(proj):
    out = {}
    for s in proj["sections"]:
        out.setdefault(s["type"], []).append(s)
    return out


def _pick_section(src_by_type, stype, k):
    c = src_by_type.get(stype)
    if c:
        return c[(k - 1) % len(c)]
    return None


def _slice_notes(src, tr, cs, cb, ms, harmony, key_delta, master):
    """Notatki ścieżki źródłowej z okna cs (sekcja źródłowa) -> sekcja master ms (zapętlone/przycięte)."""
    tname = tr["type"]
    a, b = cs["start"] * 4, (cs["start"] + cb) * 4
    base = [n for n in tr["notes"] if a - 1e-6 <= n[0] < b - 1e-6]
    out, mb = [], ms["bars"]
    reps = math.ceil(mb / cb)
    for rep in range(reps):
        for on, dur, key, vel in base:
            loc = on - a                                    # beat w oknie źródła
            bar_in = int(loc // 4)
            t_loc = rep * cb * 4 + loc                      # beat w sekcji master
            if t_loc >= mb * 4 - 1e-6:
                continue
            dur2 = min(dur, mb * 4 - t_loc)
            k2 = key
            if tname in MELODIC:
                mbar = ms["start"] + int(t_loc // 4)
                sbar = cs["start"] + bar_in
                if harmony and sbar < len(src["chords"]):
                    k2 += _wrap(master["chords"][mbar][0] - src["chords"][sbar][0])
                else:
                    k2 += _wrap(master["key"] - src["key"])
                k2 += key_delta
                k2 = _fit_register(tname, k2)
            out.append([round(ms["start"] * 4 + t_loc, 4), round(dur2, 4), k2, vel])
    return out


def _slice_auto(src, tr, cs, cb, ms):
    a, b = cs["start"] * 4, (cs["start"] + cb) * 4
    res = {}
    for name, pts in tr["auto"].items():
        pts = sorted(pts)
        before = [p for p in pts if p[0] <= a + 1e-6]
        inside = [p for p in pts if a + 1e-6 < p[0] < b - 1e-6]
        start_val = before[-1][1] if before else (inside[0][1] if inside else None)
        if start_val is None:
            continue
        seq = [[0.0, start_val]] + [[p[0] - a, p[1]] for p in inside]
        lane = []
        for rep in range(math.ceil(ms["bars"] / cb)):
            for t, v in seq:
                tt = rep * cb * 4 + t
                if tt < ms["bars"] * 4:
                    lane.append([ms["start"] * 4 + tt, v])
        res[name] = lane
    return res


def track_names(projects):
    """Unia nazw ścieżek we wskazanych projektach (kolejność wg TYPES)."""
    seen = {}
    for p in projects:
        for t in p["tracks"]:
            seen.setdefault(t["name"], t["type"])
    return sorted(seen, key=lambda n: (TYPES.index(seen[n]), n))


def remix(assign: dict, master, bpm=None, key=None, harmony=True, name=None, seed=0):
    """assign: {nazwa_ścieżki: projekt-źródło (dict) | None}, master: projekt (dict) — struktura, harmonia, linki, domyślne tempo."""
    key_delta = _wrap(key - master["key"]) if key is not None else 0
    p = new_project(name=name or f"Remix-{int(time.time()) % 100000}", bpm=bpm or master["bpm"], style=master["style"],
                    key=(master["key"] + key_delta) % 12, scale=master["scale"], seed=seed, swing=master["swing"],
                    energy=master["energy"], density=master["density"], bars=master["bars"])
    p["sections"] = copy.deepcopy(master["sections"])
    p["chords"] = [[(r + key_delta) % 12, th] for r, th in master["chords"]]
    master_t = copy.deepcopy(master)
    master_t["chords"] = p["chords"]
    parents = set()
    for tname, src in assign.items():
        if src is None:
            continue
        st = find_track(src, tname)
        if st is None:
            continue
        parents.add(src.get("id", src["name"]))
        tr = new_track(tname, st["type"])
        tr["params"] = copy.deepcopy(st["params"]); tr["gain"] = st["gain"]
        for k in ("text", "text_mode", "text_theme"):      # DS Speak: tekst wędruje ze ścieżką
            if k in st:
                tr[k] = st[k]
        by_type = _sections_by_type(src)
        for ms in p["sections"]:
            cs = _pick_section(by_type, ms["type"], ms["k"])
            if cs is None:
                continue
            tr["notes"] += _slice_notes(src, st, cs, cs["bars"], ms, harmony, key_delta, master_t)
            for nme, lane in _slice_auto(src, st, cs, cs["bars"], ms).items():
                tr["auto"].setdefault(nme, []).extend(lane)
        tr["notes"].sort()
        p["tracks"].append(tr)
    p["tracks"].sort(key=lambda t: (TYPES.index(t["type"]), t["name"]))
    names = {t["name"] for t in p["tracks"]}
    for t in p["tracks"]:                              # routing (nuty pre / wejście audio) wędruje, jeśli źródło jest w remiksie
        st = find_track(assign[t["name"]], t["name"]) if assign.get(t["name"]) else None
        if not st:
            continue
        for k in ("notes_from", "notes_transpose", "input_from", "input_mix", "input_hide_source"):
            if k in st:
                t[k] = st[k]
        for k in ("notes_from", "input_from"):
            if t.get(k) not in names:
                t[k] = None
    p["links"] = [copy.deepcopy(l) for l in master["links"] if l["dst"] in names]
    have = {(l["src"], l["dst"], l["param"]) for l in p["links"]}
    if first_of_type(p, "kick"):                      # ducking także dla instrumentów spoza mastera
        for t in p["tracks"]:
            if t["type"] in DUCK and ("kick", t["name"], "Level") not in have:
                p["links"].append(duck_link(t, p["style"]))
    p["parents"] = sorted(parents)
    sanitize_notes(p)
    return p


def auto_assign(entries: list, rng: random.Random, master_bias=0.35):
    """entries: lista projektów (dict). Zwraca (master, {nazwa_ścieżki: projekt|None})."""
    master = rng.choice(entries)
    mnames = {t["name"] for t in master["tracks"]}
    assign = {}
    for n in track_names(entries):
        pool = [e for e in entries if (t := find_track(e, n)) and t["notes"]]
        if not pool:
            continue
        if n not in mnames and rng.random() < 0.4:      # instrument spoza mastera: dołącz z p=0.6
            assign[n] = None
            continue
        mt = find_track(master, n)
        assign[n] = master if (mt and mt["notes"] and rng.random() < master_bias) else rng.choice(pool)
    return master, assign
