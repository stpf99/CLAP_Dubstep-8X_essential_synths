"""eco.py — tryb ECO: dwa osobne, lekkie kroki zamiast generowania i nadawania naraz.

  preroll  — renderuje aranżacje OFFLINE do plików (mp3/flac/wav) przy niskim priorytecie, po jednej, ze stałym małym zużyciem RAM.
  air      — nadaje gotowe pliki do Icecast2 i/lub odtwarzacza (bez generatora, bez renderu, bez wtyczek) — tylko dekodowanie i wysyłka.

Pliki: <dir>/NNNNNN-<styl>-<bpm>bpm.<fmt>; numer rośnie (licznik w .counter), więc `air` gra w kolejności tworzenia."""
from __future__ import annotations

import fcntl
import os
import random
import re
import shutil
import subprocess
import time
import wave
from pathlib import Path

from . import core, generator as G, live as L

SR = core.SR
EXT = (".mp3", ".flac", ".wav")


def preroll_dir() -> Path:
    d = Path(os.environ.get("DS_PREROLL") or Path.home() / "DubstepStudio" / "preroll"); d.mkdir(parents=True, exist_ok=True)
    return d


def files(d) -> list:
    return sorted(p for p in Path(d).iterdir() if p.is_file() and p.suffix.lower() in EXT and re.match(r"\d+-", p.name))


def _next_no(d) -> int:
    """Kolejny numer pliku. Odczyt-zwiększenie-zapis odbywa się pod flock (osobny plik blokady) i zapis jest atomowy,
    więc równoległe procesy (cron + ręczne uruchomienie, GUI) nigdy nie dostaną tego samego numeru."""
    d = Path(d); c = d / ".counter"
    with open(d / ".counter.lock", "a+") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)                 # zwalniany przy zamknięciu pliku
        try:
            n = int(c.read_text().strip())
        except (OSError, ValueError):
            n = max([int(re.match(r"(\d+)-", p.name).group(1)) for p in files(d)] or [0])
        n += 1
        tmp = Path(str(c) + ".tmp"); tmp.write_text(str(n)); os.replace(tmp, c)
        return n


def _encode(path: Path, mix, fmt: str, title: str):
    """Zapis do .part i podmiana — `air` nigdy nie widzi niedokończonego pliku."""
    part = Path(str(path) + ".part")
    try:
        if fmt == "wav":
            core.write_wav(part, mix); os.replace(part, path); return
        codec = ["-f", "mp3", "-c:a", "libmp3lame", "-b:a", "192k"] if fmt == "mp3" else ["-f", "flac", "-c:a", "flac"]
        p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "-", "-metadata", f"title={title}"] + codec + [str(part)],
                             stdin=subprocess.PIPE)
        broken = False
        try:
            for a in range(0, len(mix), 1 << 18):
                p.stdin.write(mix[a: a + (1 << 18)].astype("<f4").tobytes())
        except BrokenPipeError:
            broken = True                              # ffmpeg padł w trakcie — komunikat o przyczynie poniżej
        finally:
            try:
                p.stdin.close()
            except OSError:
                broken = True
            p.wait()
        if broken or p.returncode != 0:
            raise RuntimeError("ffmpeg nie zakodował pliku (zainstaluj ffmpeg z libmp3lame albo użyj --format wav)")
        os.replace(part, path)
    except BaseException:
        part.unlink(missing_ok=True)                   # żadnych osieroconych .part na dysku/SD
        raise


def _single_instance(d):
    """Wyłączna, nieblokująca blokada katalogu preroll. -> uchwyt pliku (trzymać do końca) albo None, gdy zajęta."""
    f = open(Path(d) / ".preroll.lock", "a+")
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close(); return None
    return f


def preroll(cfg, base, outdir, count=None, fill=None, minutes=None, keep=None, fmt=None, log=print, stop=lambda: False):
    """Renderuje aranżacje planerem Live (te same style/mutacje/pory dnia) do plików. -> liczba nowych plików.
    Jedna instancja na katalog: drugi preroll (np. z crona, gdy poprzedni jeszcze renderuje) kończy od razu z wynikiem 0."""
    d = Path(outdir); d.mkdir(parents=True, exist_ok=True)
    lock = _single_instance(d)
    if lock is None:
        log("[preroll] w tym katalogu już działa inny preroll — pomijam ten przebieg"); return 0
    try:
        for part in d.glob("*.part"):                  # resztki po przerwanym zapisie (mamy blokadę, więc nie są niczyje)
            part.unlink(missing_ok=True)
        return _preroll_run(cfg, base, outdir, count=count, fill=fill, minutes=minutes, keep=keep, fmt=fmt, log=log, stop=stop)
    finally:
        lock.close()


def _preroll_run(cfg, base, outdir, count=None, fill=None, minutes=None, keep=None, fmt=None, log=print, stop=lambda: False):
    fmt = fmt or ("mp3" if shutil.which("ffmpeg") else "wav")
    if fmt != "wav" and not shutil.which("ffmpeg"):
        raise RuntimeError("Brak ffmpeg — użyj --format wav.")
    try:
        os.nice(19)                                    # render w tle: nie przeszkadza `air` ani reszcie systemu (dzieci dsrender dziedziczą)
    except OSError:
        pass
    core.cleanup_stale_work(); d = Path(outdir); d.mkdir(parents=True, exist_ok=True)
    want = count if count else (max(0, fill - len(files(d))) if fill else 6)
    done = 0; secs = 0.0; avail = core.available_types()
    while done < want and not stop() and not (minutes and secs >= minutes * 60):
        t0 = time.time(); rng = random.Random()
        plan = L.plan_next(cfg, base, rng, avail); kw = plan["kw"]; kw["seed"] = rng.randrange(1000000)
        no = _next_no(d); kw["name"] = f"Eco-{no:06d}-{G.short_name(kw['style'])}"
        proj = G.generate(**kw); mix = core.render_mix(proj)
        n = min(len(mix), int(round(proj["bars"] * 4 * 60.0 / proj["bpm"] * SR)) + int(1.5 * SR))      # takty + krótki ogon z wygaszeniem
        mix = mix[:n]; f = min(n, int(SR)); mix[n - f:] *= (1.0 - __import__("numpy").linspace(0, 1, f, dtype="float32"))[:, None]
        safe = re.sub(r"[^A-Za-z0-9]+", "-", G.short_name(kw["style"])).strip("-")
        out = d / f"{no:06d}-{safe}-{int(proj['bpm'])}bpm.{fmt}"
        _encode(out, mix, fmt, f"{kw['style']} {int(proj['bpm'])} BPM {core.key_name(proj)} [DS Eco {no}]")
        done += 1; secs += n / SR; del mix, proj
        log(f"[preroll] {done}/{want if not minutes else '∞'} {out.name}  {n / SR:.0f} s  {out.stat().st_size / 1e6:.1f} MB  render {time.time() - t0:.0f} s  (RAM procesu: {core.rss_mb()} MB)")
        if keep:
            for old in files(d)[: max(0, len(files(d)) - keep)]:
                old.unlink(missing_ok=True)
    return done


def _pcm_chunks(path: Path):
    """Surowe PCM s16le 48 kHz stereo z pliku. WAV własny czytany bez ffmpeg; reszta dekodowana przez ffmpeg."""
    if path.suffix.lower() == ".wav":
        try:
            with wave.open(str(path), "rb") as w:
                if (w.getnchannels(), w.getsampwidth(), w.getframerate()) == (2, 2, SR):
                    while True:
                        b = w.readframes(L.CHUNK)
                        if not b:
                            return
                        yield b
        except wave.Error:
            pass
    p = subprocess.Popen(["ffmpeg", "-loglevel", "quiet", "-i", str(path), "-f", "s16le", "-ar", str(SR), "-ac", "2", "-"], stdout=subprocess.PIPE)
    try:
        while True:
            b = p.stdout.read(L.CHUNK * 4)
            if not b:
                return
            yield b
    finally:
        p.kill(); p.wait()


def air(ice_cfg, local_on, d, shuffle=False, once=False, consume=False, log=print, stop=lambda: False):
    """Nadaje pliki z katalogu do Icecast i/lub odtwarzacza. Katalog jest skanowany przy każdym przebiegu — nowe pliki z `preroll` wchodzą na antenę."""
    out = L.Output(); out.configure(ice_cfg, local_on)
    if not out.start() and out.use_local():
        raise RuntimeError("Brak odtwarzacza (aplay/pw-cat/paplay/mpv/ffplay) — zainstaluj albo wyłącz odsłuch lokalny.")
    last_msg = 0.0
    try:
        while not stop():
            fl = files(d)
            if shuffle:
                random.shuffle(fl)
            if not fl:
                if once:
                    break
                if time.time() - last_msg > 30:
                    log(f"[air] pusto w {d} — czekam na pliki (uruchom preroll)"); last_msg = time.time()
                out.fill_silence(); time.sleep(0.2); continue
            for f in fl:
                if stop() or not f.exists():
                    continue
                if out.ice_on():
                    out.ice.set_title(re.sub(r"^\d+-", "", f.stem).replace("-", " "))
                log(f"[air] {f.name}  (RAM procesu: {core.rss_mb()} MB)")
                for b in _pcm_chunks(f):
                    if stop():
                        break
                    out.write(b)
                if consume and not stop():
                    f.unlink(missing_ok=True)
            if once:
                break
    finally:
        out.stop()
