"""uniq.py — NIEPOWTARZALNOŚĆ SEGMENTÓW (intro / build / break / outro, opcjonalnie drop).

Stosowane PO generacji wzorów (po niuansach). Trzy warstwy:

 1. RECEPTURY segmentu — każdy segment dostaje 1–3 receptury z puli swojego typu (np. intro: stopniowe wejścia warstw w losowej kolejności,
    bezbębnowe otwarcie, zapowiedź motywu dropa; build: inny wzór rolki werbla, „stop” tuż przed dropem, kaskada tomów, wspinaczka melodii;
    break: sam pad, bicie serca, echo ostatnich nut dropa, rzadkie arpeggio; outro: wychodzenie warstw, echo ogona, twarde cięcie…).
    Receptury rotują: kolejny segment TEGO SAMEGO typu bierze najrzadziej użytą recepturę, więc build2 ≠ build1, break2 ≠ break1.
 2. MIKRO-WARIACJE wewnątrz segmentu — takty, które powtarzają któryś z 3 poprzednich, dostają drobną mutację (ghost note, wyrzucona nuta,
    flam, akcent, oktawa, nuta przejściowa); koniec frazy (co 4 takty) zawsze dostaje jakiś znacznik.
 3. KONTROLA PODOBIEŃSTWA — Jaccard zbiorów (ścieżka, pozycja, dźwięk) między segmentami tego samego typu; powyżej progu dokładane są
    kolejne receptury, aż segmenty się rozjadą.

Siła s ∈ [0,1]: liczba receptur (1…3), prawdopodobieństwo mikro-wariacji, próg podobieństwa. Szanuje lock_notes.
"""
from __future__ import annotations

import math
import random

from .niuanse import BASS_T, DRUM_T, LEAD_T, _scale_pcs, _snap

TYPES = ("intro", "build", "break", "outro")
DK = {"kick": 36, "snare": 38, "clap": 39, "rim": 37, "hat": 42, "crash": 49, "shaker": 70}
TOM_KEYS = (50, 48, 47, 45, 43, 41)
SUSTAINED_T = frozenset({"sub", "reese", "pad", "supersaw", "strings", "hollow"})
FX_T = frozenset({"riser", "boom", "zap", "vox", "speak"})
ARP_POOL = ("pluck", "piano", "handpan", "tongue", "panflute", "stab", "acid", "theremin", "supersaw")
KEEP_IN_GAP = frozenset({"riser", "zap", "pad", "strings", "vox", "speak"})


# ------------------------------------------------------------------ narzędzia
def _n(beat, dur, key, vel):
    return [round(float(beat), 4), round(max(0.03, float(dur)), 4), int(max(0, min(127, key))), int(max(1, min(127, round(vel))))]


def _dn(bar, step, key, vel):
    return _n(bar * 4 + step * 0.25, 0.1, key, vel)


def _in(tr, b0, b1):
    return [n for n in tr["notes"] if b0 <= n[0] < b1]


def _put(tr, b0, b1, new, keys=None):
    """Zastępuje nuty w [b0,b1) (opcjonalnie tylko o podanych dźwiękach) nowymi."""
    keep = [n for n in tr["notes"] if not (b0 <= n[0] < b1 and (keys is None or n[2] in keys))]
    tr["notes"] = sorted(keep + list(new), key=lambda n: (n[0], n[2]))


def _reg(pc, lo):
    return lo + ((pc - lo) % 12)


class S:
    def __init__(self, sec):
        self.sec, self.name, self.type = sec, sec["name"], sec["type"]
        self.start, self.L = int(sec["start"]), int(sec["bars"])
        self.b0, self.b1 = self.start * 4.0, (self.start + self.L) * 4.0


class U:
    def __init__(self, proj, s, rng):
        self.proj, self.s, self.rng = proj, s, rng
        self.secs = [S(x) for x in proj["sections"]]
        self.pcs = _scale_pcs(proj)
        self.count = {t: {} for t in TYPES}
        self.orders, self.rolls = [], []

    def tracks(self, *types):
        return [t for t in self.proj["tracks"] if not t.get("lock_notes") and (not types or t["type"] in types)]

    def next_drop(self, S_):
        return next((x for x in self.secs if x.type == "drop" and x.start >= S_.start + S_.L), None)

    def prev_sec(self, S_):
        i = self.secs.index(S_)
        return self.secs[i - 1] if i > 0 else None


# ================================================================== RECEPTURY — wspólne
def _shape(name, rng):
    return {
        "lin": lambda x: x,
        "ease_in": lambda x: x * x,
        "ease_out": lambda x: math.sqrt(x),
        "steps": lambda x: min(1.0, int(x * 4) / 3.0),
        "wave": lambda x, w=rng.choice([1.5, 2.5]), ph=rng.random(): 0.55 * x + 0.45 * (0.5 + 0.5 * math.sin(6.2832 * (x * w + ph))),
    }[name]


def r_vel_curve(u, S_, rng):
    """Krzywa głośności całego segmentu: różny kształt narastania (intro/break) lub zanikania (outro)."""
    name = rng.choice(["lin", "ease_in", "ease_out", "steps", "wave"])
    f = _shape(name, rng)
    lo = rng.uniform(0.40, 0.70)
    span = S_.b1 - S_.b0
    for tr in u.tracks():
        if tr["type"] in FX_T:
            continue
        for n in tr["notes"]:
            if S_.b0 <= n[0] < S_.b1:
                x = (n[0] - S_.b0) / span
                if S_.type == "outro":
                    x = 1.0 - x
                elif S_.type == "break" and name in ("lin", "wave"):
                    x = math.sin(math.pi * x)                     # łuk: cisza → szczyt → cisza
                n[3] = max(1, min(127, int(round(n[3] * (lo + (1 - lo) * f(max(0.0, min(1.0, x))))))))
    return f"krzywa głośności „{name}” (min ×{lo:.2f})"


def r_octave_walk(u, S_, rng):
    """Pad/smyki: co takt inna oktawa (schodki, ping-pong albo wzór 0-12-0-0)."""
    trs = [t for t in u.tracks("pad", "strings", "hollow") if _in(t, S_.b0, S_.b1)]
    if not trs or S_.L < 4:
        return None
    pat = rng.choice([[0, 12], [0, 0, 12, 12], [0, 12, 12, 0], [0, 0, 0, 12]])
    for tr in trs:
        for n in tr["notes"]:
            if S_.b0 <= n[0] < S_.b1 and pat[int((n[0] - S_.b0) // 4) % len(pat)] and n[2] + 12 <= 96:
                n[2] += 12
    return f"pad: wzór oktaw {pat}"


def r_fill_last_bar(u, S_, rng):
    """Inny przejściowy fill w ostatnim takcie (tomy / rolka hatów / werbel / kick)."""
    opts = []
    if u.tracks("tom"):
        opts.append("tom")
    if u.tracks("hat"):
        opts.append("hat")
    if u.tracks("snare"):
        opts.append("snare")
    if u.tracks("kick"):
        opts.append("kick")
    if not opts or S_.L < 2:
        return None
    kind, bar = rng.choice(opts), S_.start + S_.L - 1
    tr = u.tracks(kind)[0]
    b0, b1 = bar * 4.0, bar * 4.0 + 4.0
    if kind == "tom":
        seq = list(TOM_KEYS); rng.shuffle(seq) if rng.random() < 0.3 else None
        steps = rng.choice([(8, 10, 12, 13, 14, 15), (10, 11, 12, 13, 14, 15), (12, 13, 14, 15)])
        _put(tr, b0 + 2.0, b1, [_dn(bar, s_, seq[i % 6], 78 + 3 * i) for i, s_ in enumerate(steps)])
    elif kind == "hat":
        sp = rng.choice([0.5, 1.0])
        st = [12 + k * sp for k in range(int(4 / sp))]
        _put(tr, b0 + 3.0, b1, [_dn(bar, s_, 42, 48 + int(55 * k / len(st))) for k, s_ in enumerate(st)])
    elif kind == "snare":
        steps = rng.choice([(13, 14, 15), (12, 14, 15), (14, 15), (11, 13, 15)])
        _put(tr, b0 + 2.5, b1, [_dn(bar, s_, 38, 80 + 8 * i) for i, s_ in enumerate(steps)])
    else:
        steps = rng.choice([(14,), (13, 15), (10, 14), (11, 14, 15)])
        _put(tr, b0 + 2.5, b1, [_dn(bar, s_, 36, 100 - 4 * i) for i, s_ in enumerate(steps)])
    return f"fill w ostatnim takcie: {kind}"


def r_motif_teaser(u, S_, rng):
    """Zapowiedź motywu następnego dropa (przerzedzona, cichsza, czasem oktawę wyżej/niżej) w ostatnich 2 taktach segmentu."""
    nxt = u.next_drop(S_)
    if not nxt or S_.L < 4:
        return None
    cands = []
    for tr in u.tracks():
        if tr["type"] in LEAD_T or tr["type"] in ARP_POOL:
            notes = _in(tr, nxt.b0, nxt.b0 + 8.0)
            if len(notes) >= 2:
                cands.append((tr, notes))
    if not cands:
        return None
    tr, notes = rng.choice(cands)
    shift = rng.choice([-12, 0, 0, 12])
    off = (S_.b1 - 8.0) - nxt.b0
    new = []
    for i, n in enumerate(notes):
        if i and rng.random() < 0.4:
            continue
        k = n[2] + shift
        k = n[2] if not 24 <= k <= 100 else k
        new.append(_n(n[0] + off, n[1], k, n[3] * 0.6))
    _put(tr, S_.b1 - 8.0, S_.b1, new)
    return f"zapowiedź motywu dropa na {tr['name']} ({len(new)} nut, oktawa {shift:+d})"


# ================================================================== INTRO
def r_stagger_in(u, S_, rng):
    """Warstwy wchodzą po kolei w losowej kolejności (kolejność różna dla każdego intro/outro)."""
    trs = [t for t in u.tracks() if t["type"] not in ("riser", "boom", "zap", "crash") and _in(t, S_.b0, S_.b1)]
    if len(trs) < 3 or S_.L < 4:
        return None
    for _ in range(5):
        rng.shuffle(trs)
        order = [t["name"] for t in trs]
        if order not in u.orders:
            break
    u.orders.append(order)
    step = 2 if S_.L >= 8 else 1
    span = max(1, int(S_.L * 0.75))
    out = []
    for i, t in enumerate(trs):
        e = 0 if i == 0 else min(S_.L - 1, int(round(span * i / (len(trs) - 1) / step)) * step)
        if e:
            _put(t, S_.b0, S_.b0 + e * 4.0, [])
        out.append(f"{t['name']}@{e}")
    return "wejścia warstw: " + ", ".join(out)


def r_drumless_open(u, S_, rng):
    """Pierwsza część segmentu bez kick/snare/clap/tom — tylko to, co lekkie."""
    if S_.L < 4:
        return None
    bars = max(2, int(round(S_.L * rng.uniform(0.3, 0.6) / 2.0)) * 2)
    trs = u.tracks("kick", "snare", "clap", "tom")
    if not trs:
        return None
    for t in trs:
        _put(t, S_.b0, S_.b0 + bars * 4.0, [])
    return f"{bars} taktów bez kick/snare"


# ================================================================== BUILD
def r_snare_roll(u, S_, rng):
    """Inny wzór rolki werbla w każdym buildzie."""
    trs = u.tracks("snare")
    if not trs or S_.L < 2:
        return None
    pats = ["accel", "triplet", "straight16", "offbeat", "backbeat_roll", "stutter"]
    fresh = [p for p in pats if p not in u.rolls] or pats
    pat = rng.choice(fresh)
    u.rolls.append(pat)

    def steps_for(i, L):
        p = (i + 0.5) / L

        def run(sp, a=0.0):
            out, x = [], a
            while x < 16 - 1e-6:
                out.append(x); x += sp
            return out
        if pat == "accel":
            return run(4 if p < .25 else 2 if p < .5 else 1 if p < .75 else .5)
        if pat == "triplet":
            return run(8 / 3 if p < .5 else 4 / 3 if p < .8 else 2 / 3)
        if pat == "straight16":
            return [0, 8] if p < .25 else [0, 4, 8, 12] if p < .5 else run(1)
        if pat == "offbeat":
            return [2, 6, 10, 14] if p < .5 else run(1) if p < .85 else run(.5)
        if pat == "backbeat_roll":
            return [8] if p < .6 else run(1) if p < .85 else run(.5)
        return [8] if p < .4 else ([8, 9, 10, 11, 12, 13, 14, 15] if p > .7 else []) + [12, 13, 14, 15]          # stutter

    for tr in trs:
        new = []
        for i in range(S_.L):
            for s_ in sorted(set(steps_for(i, S_.L))):
                prog = (i + s_ / 16.0) / S_.L
                new.append(_dn(S_.start + i, s_, 38, 50 + 75 * prog + rng.randint(-3, 3)))
        _put(tr, S_.b0, S_.b1, new)
    return f"rolka werbla: {pat}"


def r_gap_before_drop(u, S_, rng):
    """Mikro-cisza tuż przed dropem: bębny/basy/leady milkną na ostatnie 2–8 kroków."""
    if not u.next_drop(S_) or S_.L < 2:
        return None
    g = rng.choice([2, 3, 4, 6, 8])
    gs = S_.b1 - g * 0.25
    for tr in u.tracks():
        if tr["type"] in KEEP_IN_GAP:
            continue
        keep = []
        for n in tr["notes"]:
            if n[0] >= gs and n[0] < S_.b1:
                continue
            if n[0] < gs < n[0] + n[1] and tr["type"] not in SUSTAINED_T:
                n = [n[0], max(0.05, gs - n[0] - 0.01), n[2], n[3]]
            keep.append(n)
        tr["notes"] = keep
    return f"cisza {g} kroków przed dropem"


def r_kick_pattern(u, S_, rng):
    trs = u.tracks("kick")
    if not trs or S_.L < 4:
        return None
    mode = rng.choice(["out", "heart", "quarters", "accel"])
    for tr in trs:
        new = []
        half = S_.L // 2
        if mode == "heart":
            new = [_dn(S_.start + i, s_, 36, 96 - 8 * j) for i in range(half, S_.L) for j, s_ in enumerate((0, 10))]
        elif mode == "quarters":
            new = [_dn(S_.start + i, s_, 36, 100 + 4 * j) for i in range(max(half, S_.L - 2), S_.L) for j, s_ in enumerate((0, 4, 8, 12))]
        elif mode == "accel":
            for i in range(half, S_.L):
                p = (i - half) / max(1, S_.L - half)
                st = (0,) if p < .34 else (0, 8) if p < .67 else (0, 4, 8, 12)
                new += [_dn(S_.start + i, s_, 36, 98 + int(14 * p)) for s_ in st]
        _put(tr, S_.b0, S_.b1, new)
    return f"kick w buildzie: {mode}"


def r_tom_cascade(u, S_, rng):
    trs = u.tracks("tom")
    if not trs or S_.L < 2:
        return None
    shape = rng.choice(["desc", "asc", "zigzag"])
    keys = list(TOM_KEYS)
    seq = keys if shape == "desc" else keys[::-1] if shape == "asc" else [keys[i] for i in (0, 3, 1, 4, 2, 5)]
    bars = 2 if S_.L >= 8 and rng.random() < 0.5 else 1
    new = []
    for bi in range(bars):
        bar = S_.start + S_.L - bars + bi
        for j, s_ in enumerate((0, 2, 4, 6, 8, 10, 12, 14) if bars == 2 else (4, 6, 8, 10, 12, 14)):
            new.append(_dn(bar, s_, seq[(bi * 8 + j) % 6], 70 + 6 * (bi * 8 + j) // (1 if bars == 1 else 2)))
    for tr in trs:
        _put(tr, S_.b1 - bars * 4.0, S_.b1, new)
    return f"kaskada tomów: {shape}, {bars} takt(y)"


def r_pitch_climb(u, S_, rng):
    """Wspinaczka melodyczna w ostatnich 2 taktach buildu (bieg po skali / tryl / skoki oktawowe)."""
    trs = [t for t in u.tracks() if t["type"] in ("pluck", "stab", "screech", "supersaw", "panflute", "theremin", "piano", "handpan", "tongue")]
    if not trs or S_.L < 4:
        return None
    tr = rng.choice(trs)
    shape = rng.choice(["run", "trill", "octaves"])
    B = u.proj["chords"][S_.start + S_.L - 2][0]
    base = _reg(B, 60)
    new = []
    for j in range(16):
        bar, s_ = S_.start + S_.L - 2 + j // 8, (j % 8) * 2
        prog = j / 15.0
        if shape == "run":
            k = _snap(base + int(round(prog * 14)), u.pcs)
        elif shape == "trill":
            k = _snap(base + 7 + (2 if j % 2 else 0) + int(prog * 5), u.pcs)
        else:
            k = base + 12 * (j // 4 % 3) + (0 if j % 2 == 0 else 7)
        new.append(_n(bar * 4 + s_ * 0.25, 0.4, k, 60 + 55 * prog))
    _put(tr, S_.b1 - 8.0, S_.b1, new)
    return f"wspinaczka {shape} na {tr['name']}"


def r_hat_swell(u, S_, rng):
    trs = u.tracks("hat")
    if not trs or S_.L < 4:
        return None
    mode = rng.choice(["ramp", "triplet", "open_beat"])
    for tr in trs:
        new = []
        for i in range(S_.L):
            p = (i + 0.5) / S_.L
            if mode == "ramp":
                sp = 2 if p < .4 else 1 if p < .75 else .5
            elif mode == "triplet":
                sp = 4 / 3 if p > .3 else 2
            else:
                sp = 4 if p < .5 else 2
            x = 0.0
            while x < 16 - 1e-6:
                new.append(_dn(S_.start + i, x, 42, 42 + 62 * (i + x / 16) / S_.L + (14 if mode == "open_beat" and x % 4 == 0 else 0)))
                x += sp
        _put(tr, S_.b0, S_.b1, new)
    return f"hat w buildzie: {mode}"


# ================================================================== BREAK
def r_pad_only(u, S_, rng):
    if S_.L < 4:
        return None
    trs = u.tracks("kick", "snare", "clap", "tom", "hat", "rim", "shaker")
    if not trs:
        return None
    end = S_.b1 if rng.random() < 0.5 else S_.b0 + (S_.L // 2) * 4.0
    for t in trs:
        _put(t, S_.b0, end, [])
    return f"break bez perkusji do taktu {int((end - S_.b0) // 4)}"


def r_heartbeat(u, S_, rng):
    k = u.tracks("kick") or u.tracks("tom")
    if not k or S_.L < 4:
        return None
    for t in u.tracks("snare", "clap", "hat", "rim", "shaker"):
        _put(t, S_.b0, S_.b1, [])
    pat = rng.choice([(0,), (0, 3), (0, 6), (0, 10)])
    for t in k:
        key = 36 if t["type"] == "kick" else 41
        _put(t, S_.b0, S_.b1, [_dn(S_.start + i, s_, key, 72 - 10 * j) for i in range(S_.L) for j, s_ in enumerate(pat)])
    return f"bicie serca: kroki {pat}"


def r_echo_tail(u, S_, rng):
    """Echo ostatnich nut poprzedniego segmentu na początku breaku (rozpad, kropkowane)."""
    prv = u.prev_sec(S_)
    if not prv:
        return None
    cands = []
    for tr in u.tracks():
        if tr["type"] in LEAD_T or tr["type"] in ARP_POOL:
            last = _in(tr, prv.b1 - 4.0, prv.b1)
            if last:
                cands.append((tr, last[-1]))
    if not cands:
        return None
    tr, n0 = rng.choice(cands)
    sp = rng.choice([0.75, 1.0, 1.5])
    new = [_n(S_.b0 + k * sp, n0[1] * 1.2, n0[2], n0[3] * (0.68 ** k)) for k in range(5) if S_.b0 + k * sp < S_.b1]
    _put(tr, S_.b0, S_.b0 + 6.0, new)
    return f"echo ostatniej nuty dropa na {tr['name']} (co {sp} ćwierćnuty)"


def r_sparse_arp(u, S_, rng):
    trs = [t for t in u.tracks() if t["type"] in ARP_POOL]
    if not trs or S_.L < 4:
        return None
    tr = rng.choice(trs)
    pat = rng.choice(["up", "updown", "broken", "dotted"])
    new = []
    for i in range(S_.L):
        bar = S_.start + i
        r, th = u.proj["chords"][bar]
        base = _reg(r, 55)
        tones = [0, th, 7, 12]
        seq = {"up": tones, "updown": [0, th, 7, 12, 7, th], "broken": [0, 7, th, 7], "dotted": [0, th, 7, th, 12]}[pat]
        steps = [0, 3, 6, 9, 12] if pat == "dotted" else list(range(0, 16, 2 if pat != "broken" else 4))
        for j, s_ in enumerate(steps):
            new.append(_n(bar * 4 + s_ * 0.25, 0.35, base + seq[j % len(seq)], (70 if j == 0 else 52) + rng.randint(-5, 5)))
    _put(tr, S_.b0, S_.b1, new)
    return f"rzadkie arpeggio „{pat}” na {tr['name']}"


def r_silent_bar(u, S_, rng):
    if S_.L < 8:
        return None
    bar = S_.start + rng.randint(2, S_.L - 3)
    for tr in u.tracks():
        if tr["type"] in ("pad", "strings", "riser"):
            continue
        _put(tr, bar * 4.0, bar * 4.0 + 4.0, [])
    return f"całkowita cisza w takcie {bar - S_.start + 1}"


# ================================================================== OUTRO
def r_stagger_out(u, S_, rng):
    trs = [t for t in u.tracks() if t["type"] not in ("riser", "boom", "zap", "crash") and _in(t, S_.b0, S_.b1)]
    if len(trs) < 3 or S_.L < 4:
        return None
    for _ in range(5):
        rng.shuffle(trs)
        order = [t["name"] for t in trs]
        if order not in u.orders and order[::-1] not in u.orders:
            break
    u.orders.append(order)
    out = []
    for i, t in enumerate(trs):
        ex = S_.L if i == len(trs) - 1 else max(1, int(round(S_.L * (0.25 + 0.7 * i / (len(trs) - 1)))))
        if ex < S_.L:
            _put(t, S_.b0 + ex * 4.0, S_.b1, [])
        out.append(f"{t['name']}@{ex}")
    return "wyjścia warstw: " + ", ".join(out)


def r_tail_echo(u, S_, rng):
    trs = [t for t in u.tracks() if (t["type"] in LEAD_T or t["type"] in ARP_POOL) and _in(t, S_.b0, S_.b1)]
    if not trs:
        return None
    tr = rng.choice(trs)
    last = _in(tr, S_.b0, S_.b1)[-1]
    sp = rng.choice([0.75, 1.0, 1.5])
    new = [_n(last[0] + k * sp, last[1] * 1.2, last[2], last[3] * (0.62 ** k)) for k in range(1, 6) if last[0] + k * sp < S_.b1]
    if not new:
        return None
    _put(tr, last[0] + 0.01, S_.b1, new)
    return f"echo ogona na {tr['name']}"


def r_hard_stop(u, S_, rng):
    if S_.L < 2:
        return None
    g = rng.choice([4, 8, 12])
    cut = S_.b1 - 4.0 + g * 0.25
    for tr in u.tracks():
        keep = []
        for n in tr["notes"]:
            if n[0] >= cut and n[0] < S_.b1:
                continue
            if n[0] < cut < n[0] + n[1]:
                n = [n[0], max(0.05, cut - n[0] - 0.01), n[2], n[3]]
            keep.append(n)
        tr["notes"] = keep
    cr = u.tracks("crash")
    if cr:
        _put(cr[0], cut - 0.001, cut + 0.01, [_n(cut - 0.25 if g > 4 else cut, 0.1, 49, 100)])
    return f"twarde cięcie po {g} krokach ostatniego taktu"


def r_thin_decay(u, S_, rng):
    trs = [t for t in u.tracks() if t["type"] not in FX_T and _in(t, S_.b0, S_.b1)]
    if len(trs) < 3 or S_.L < 6:
        return None
    rng.shuffle(trs)
    bar = 1
    names = []
    for t in trs[:-1]:
        bar += rng.choice([1, 2])
        if bar >= S_.L:
            break
        _put(t, S_.b0 + bar * 4.0, S_.b1, [])
        names.append(f"{t['name']}@{bar}")
    return "przerzedzanie: " + ", ".join(names)


POOLS = {
    "intro": [r_stagger_in, r_drumless_open, r_vel_curve, r_motif_teaser, r_fill_last_bar, r_octave_walk],
    "build": [r_snare_roll, r_gap_before_drop, r_kick_pattern, r_tom_cascade, r_pitch_climb, r_hat_swell],
    "break": [r_pad_only, r_heartbeat, r_echo_tail, r_sparse_arp, r_silent_bar, r_vel_curve, r_octave_walk, r_motif_teaser],
    "outro": [r_stagger_out, r_tail_echo, r_hard_stop, r_vel_curve, r_thin_decay, r_octave_walk],
}


def _apply_recipes(u, S_, rng, n, log):
    cnt = u.count[S_.type]
    order = sorted(POOLS[S_.type], key=lambda f: (cnt.get(f.__name__, 0), rng.random()))
    done = 0
    for f in order:
        if done >= n:
            break
        desc = f(u, S_, rng)
        if desc:
            cnt[f.__name__] = cnt.get(f.__name__, 0) + 1
            log.append(desc)
            done += 1
    return done


# ================================================================== MIKRO-WARIACJE
def _kinds(tt):
    if tt in ("kick",):
        return ["flam", "accent"]
    if tt in ("snare", "clap"):
        return ["ghost", "accent", "flam"]
    if tt in ("hat", "shaker", "rim"):
        return ["ghost", "drop", "accent", "flam"]
    if tt in SUSTAINED_T:
        return ["accent"]
    if tt in LEAD_T or tt in ARP_POOL:
        return ["accent", "drop", "octave", "passing"]
    if tt in BASS_T:
        return ["accent", "drop"]
    return []


def _mutate_bar(notes, bar, kind, tt, rng, pcs):
    """notes — nuty jednego taktu (listy); zwraca nową listę."""
    notes = [list(n) for n in notes]
    b0 = bar * 4.0
    if kind == "ghost" and notes:
        used = {int(round((n[0] - b0) * 4)) for n in notes}
        free = [s_ for s_ in range(1, 16, 2) if s_ not in used]
        key = max(set(n[2] for n in notes), key=[n[2] for n in notes].count)
        for s_ in rng.sample(free, min(len(free), rng.choice([1, 2]))):
            notes.append(_n(b0 + s_ * 0.25, 0.1, key, rng.randint(30, 50)))
    elif kind == "drop" and len(notes) >= 3:
        cand = [i for i, n in enumerate(notes) if i and (n[0] - b0) > 0.01]
        if cand:
            notes.pop(rng.choice(cand))
    elif kind == "accent" and len(notes) >= 2:
        a, b = rng.sample(range(len(notes)), 2)
        notes[a][3] = min(127, int(notes[a][3] * 1.18) + 1); notes[b][3] = max(1, int(notes[b][3] * 0.82))
    elif kind == "flam":
        cand = [i for i, n in enumerate(notes) if (n[0] - b0) > 0.3]
        if cand:
            i = rng.choice(cand); notes[i][0] = round(notes[i][0] + rng.choice([-0.125, 0.125]), 4)
    elif kind == "octave" and notes:
        n = rng.choice(notes)
        n[2] = n[2] + 12 if n[2] + 12 <= 96 else n[2] - 12 if n[2] - 12 >= 24 else n[2]
    elif kind == "passing":
        cand = [i for i, n in enumerate(notes) if n[1] >= 0.4]
        if cand:
            i = rng.choice(cand); n = notes[i]
            new = _n(n[0] + n[1] * 0.55, n[1] * 0.35, _snap(n[2] + 2, pcs), n[3] * 0.75)
            n[1] = round(n[1] * 0.5, 4)
            notes.append(new)
    return sorted(notes, key=lambda n: (n[0], n[2]))


def micro(u, S_, s, rng, kinds_filter=None):
    """Wariacje wewnątrz segmentu. Zwraca liczbę zmutowanych taktów."""
    changed = 0
    p_rep = min(0.95, 0.30 + 0.60 * s)
    p_end = min(0.95, 0.25 + 0.55 * s)
    for tr in u.tracks():
        kinds = _kinds(tr["type"])
        if kinds_filter:
            kinds = [k for k in kinds if k in kinds_filter]
        if not kinds or not _in(tr, S_.b0, S_.b1):
            continue
        recent = []
        for i in range(S_.L):
            bar = S_.start + i
            b0 = bar * 4.0
            cur = _in(tr, b0, b0 + 4.0)
            shape = tuple((int(round((n[0] - b0) * 4)), n[2]) for n in cur)
            mut = False
            if cur and shape in recent and rng.random() < p_rep:
                mut = True
            elif cur and i % 4 == 3 and rng.random() < p_end:
                mut = True
            if mut:
                new = _mutate_bar(cur, bar, rng.choice(kinds), tr["type"], rng, u.pcs)
                _put(tr, b0, b0 + 4.0, new)
                changed += 1
                cur = new
                shape = tuple((int(round((n[0] - b0) * 4)), n[2]) for n in cur)
            recent.append(shape)
            recent = recent[-3:]
    return changed


# ================================================================== PODOBIEŃSTWO
def _sig(u, S_, limit_bars):
    w = limit_bars * 16
    out = set()
    for tr in u.proj["tracks"]:
        for n in tr["notes"]:
            if S_.b0 <= n[0] < S_.b1:
                rel = int(round((n[0] - S_.b0) * 4))
                if rel < w:
                    out.add((tr["name"], rel, n[2]))
    return out


def similarity(u, A, B):
    m = min(A.L, B.L)
    a, b = _sig(u, A, m), _sig(u, B, m)
    return len(a & b) / len(a | b) if (a | b) else 0.0


# ================================================================== API
def apply(proj, strength=0.6, rng=None, include_drops=False):
    """Niepowtarzalność segmentów. Zwraca raport (zapisany też w proj['uniq_report'])."""
    s = max(0.0, min(1.0, float(strength)))
    rng = rng or random.Random(int(proj.get("seed", 0)) + 55)
    proj["uniq"], proj["uniq_strength"] = s > 0.0, s
    if s <= 0.0 or not proj.get("sections"):
        proj["uniq_report"] = {}
        return {}
    u = U(proj, s, rng)
    n_rec = 1 + (s > 0.35) + (s > 0.7)
    rep = {"sections": {}, "similarity": {}}
    for S_ in u.secs:
        if S_.type not in TYPES or S_.L < 2:
            continue
        r = random.Random(f"{proj.get('seed', 0)}-uniq-{S_.name}")
        log = []
        _apply_recipes(u, S_, r, n_rec, log)
        k = micro(u, S_, s, r)
        if k:
            log.append(f"mikro-wariacje w {k} taktach")
        rep["sections"][S_.name] = log
    # kontrola podobieństwa segmentów tego samego typu
    thr = 0.85 - 0.30 * s
    for typ in TYPES:
        grp = [x for x in u.secs if x.type == typ and x.L >= 2]
        for j in range(1, len(grp)):
            r = random.Random(f"{proj.get('seed', 0)}-uniq2-{grp[j].name}")
            worst = max(similarity(u, grp[j], grp[i]) for i in range(j))
            tries = 0
            while worst > thr and tries < 4:
                log = rep["sections"].setdefault(grp[j].name, [])
                if not _apply_recipes(u, grp[j], r, 1, log):
                    break
                micro(u, grp[j], min(1.0, s + 0.3), r)
                log.append(f"(korekta podobieństwa {worst:.2f} > {thr:.2f})")
                worst = max(similarity(u, grp[j], grp[i]) for i in range(j))
                tries += 1
            rep["similarity"][f"{grp[j].name}"] = round(worst, 3)
    if include_drops:
        for S_ in u.secs:
            if S_.type == "drop" and S_.L >= 4:
                k = micro(u, S_, s * 0.6, random.Random(f"{proj.get('seed', 0)}-uniqd-{S_.name}"), kinds_filter={"ghost", "accent", "flam", "passing"})
                if k:
                    rep["sections"].setdefault(S_.name, []).append(f"mikro-wariacje w {k} taktach (drop)")
    proj["uniq_report"] = rep
    return rep


def apply_track(proj, tr, strength=0.6, rng=None):
    """Same mikro-wariacje dla jednej ścieżki (po „losuj wzór nut” — receptury cross-trackowe zostają, bo działają na innych ścieżkach)."""
    s = max(0.0, min(1.0, float(strength)))
    if s <= 0 or tr.get("lock_notes"):
        return 0
    u = U(proj, s, rng or random.Random(int(proj.get("seed", 0)) + 56))
    only = [t for t in u.proj["tracks"] if t is not tr]
    saved = u.proj["tracks"]
    u.proj = dict(proj, tracks=[tr])
    n = 0
    for S_ in u.secs:
        if S_.type in TYPES and S_.L >= 2:
            n += micro(u, S_, s, random.Random(f"{proj.get('seed', 0)}-uniqt-{tr['name']}-{S_.name}"))
    del only, saved
    return n
