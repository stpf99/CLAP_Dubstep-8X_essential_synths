"""geometry_editor.py — model figur geometrycznych → sekwencje / intensywność.

Każda figura zajmuje prostokątny bbox w przestrzeni (bar × „pas” 0..1).
Wypełnienie bez części wspólnych: przy nakładaniu wygrywa figura o wyższym z-index
albo odejmowane są przecięcia (partition).

Na ścieżkę: dwa kanały
  - contour  — skosowanie przebiegu nut (pitch / gęstość w czasie)
  - intensity — wzmocnienie velocity / drive-like skala + wpływ na resztę osc (param)

Kształty: rect, square, ellipse, circle, triangle, trapezoid (+ rot 0/90/180/270 lub dowolny kąt).
"""
from __future__ import annotations

import math
import random
import uuid
from copy import deepcopy

SHAPE_KINDS = (
    "rect", "square", "ellipse", "circle",
    "triangle", "triangle_r", "trapezoid", "trapezoid_r",
)
SHAPE_LABELS = {
    "rect": "Prostokąt", "square": "Kwadrat", "ellipse": "Elipsa", "circle": "Koło",
    "triangle": "Trójkąt", "triangle_r": "Trójkąt (odwrócony)",
    "trapezoid": "Trapez", "trapezoid_r": "Trapez (odwrócony)",
}
CHANNELS = ("contour", "intensity")
CHANNEL_LABELS = {"contour": "Kontur nut (skos)", "intensity": "Intensywność dźwięku"}


def new_shape(kind="rect", x=0.0, y=0.0, w=0.25, h=0.3, rot=0.0, channel="contour", track=None):
    return {
        "id": uuid.uuid4().hex[:10],
        "kind": kind if kind in SHAPE_KINDS else "rect",
        "x": float(x),          # 0..1 wzdłuż taków utworu
        "y": float(y),          # 0..1 pas pionowy
        "w": max(0.02, float(w)),
        "h": max(0.02, float(h)),
        "rot": float(rot) % 360,  # stopnie
        "channel": channel if channel in CHANNELS else "contour",
        "track": track,         # nazwa toru albo None = global
        "z": 0,
        "fill_mode": "generator",  # generator | manual | clear
        "strength": 1.0,
    }


def default_document(bars=64):
    return {
        "bars": int(bars),
        "shapes": [],
        "version": 1,
    }


# ------------------------------------------------------------------ geometria
def _rot_pt(px, py, cx, cy, deg):
    a = math.radians(deg)
    cos, sin = math.cos(a), math.sin(a)
    dx, dy = px - cx, py - cy
    return cx + dx * cos - dy * sin, cy + dx * sin + dy * cos


def point_in_shape(px, py, sh):
    """px,py w 0..1 (norm. czas × pas). Uwzględnia rotację wokół środka bbox."""
    x, y, w, h = sh["x"], sh["y"], sh["w"], sh["h"]
    cx, cy = x + w / 2, y + h / 2
    # odwrotna rotacja punktu
    lx, ly = _rot_pt(px, py, cx, cy, -sh.get("rot", 0))
    # lokalnie w [0,1]² figury
    if w <= 0 or h <= 0:
        return False
    u = (lx - x) / w
    v = (ly - y) / h
    if u < 0 or u > 1 or v < 0 or v > 1:
        return False
    kind = sh.get("kind") or "rect"
    if kind in ("rect", "square"):
        return True
    if kind in ("ellipse", "circle"):
        return ((u - 0.5) * 2) ** 2 + ((v - 0.5) * 2) ** 2 <= 1.0
    if kind == "triangle":
        # dolna baza, wierzchołek góra-środek
        return v >= 2 * abs(u - 0.5)
    if kind == "triangle_r":
        return v <= 1 - 2 * abs(u - 0.5)
    if kind == "trapezoid":
        # górna krawędź węższa (30%)
        half = 0.5 - 0.2 * (1 - v)
        return abs(u - 0.5) <= half
    if kind == "trapezoid_r":
        half = 0.5 - 0.2 * v
        return abs(u - 0.5) <= half
    return True


def sample_shape_mask(sh, nx=64, ny=32):
    """Siatka bool czy punkt należy do figury (do partycji)."""
    mask = []
    for j in range(ny):
        row = []
        for i in range(nx):
            px = (i + 0.5) / nx
            py = (j + 0.5) / ny
            row.append(point_in_shape(px, py, sh))
        mask.append(row)
    return mask


def partition_shapes(shapes, nx=64, ny=32):
    """Przypisanie każdej komórki siatki do najwyższego z-index figury (bez części wspólnych)."""
    ordered = sorted(shapes, key=lambda s: s.get("z", 0))
    owner = [[None] * nx for _ in range(ny)]
    for sh in ordered:
        for j in range(ny):
            for i in range(nx):
                px = (i + 0.5) / nx
                py = (j + 0.5) / ny
                if point_in_shape(px, py, sh):
                    owner[j][i] = sh["id"]
    return owner


def shape_field(sh, px, py):
    """Wartość pola 0..1 wewnątrz figury (środek ~1, brzeg ~0) do skosu/intensywności."""
    if not point_in_shape(px, py, sh):
        return 0.0
    x, y, w, h = sh["x"], sh["y"], sh["w"], sh["h"]
    cx, cy = x + w / 2, y + h / 2
    lx, ly = _rot_pt(px, py, cx, cy, -sh.get("rot", 0))
    u = (lx - x) / max(1e-6, w)
    v = (ly - y) / max(1e-6, h)
    # odległość od środka w normie zależnej od kształtu
    kind = sh.get("kind") or "rect"
    if kind in ("ellipse", "circle"):
        d = math.hypot((u - 0.5) * 2, (v - 0.5) * 2)
        return max(0.0, 1.0 - d)
    if "triangle" in kind:
        d = abs(u - 0.5) * 2 + abs(v - 0.5)
        return max(0.0, 1.0 - d)
    # rect-like: gradient wzdłuż dłuższego boku (skos)
    return max(0.0, 1.0 - 2 * max(abs(u - 0.5), abs(v - 0.5)))


# ------------------------------------------------------------------ aplikacja na projekt
def _bar_frac(proj, beat):
    bars = max(1, int(proj.get("bars") or 1))
    return max(0.0, min(0.999, (beat / 4.0) / bars))


INTENSITY_PARAMS = (("Cutoff", 0.2, 0.95, 0.45), ("Drive", 0.05, 0.8, 0.30), ("Resonance", 0.1, 0.7, 0.20))


def intensity_at(shapes, px):
    """Pole intensywności w punkcie czasu px (0..1) — maksimum po figurach; None gdy żadna figura nie obejmuje punktu."""
    best = None
    for sh in shapes:
        cy = sh["y"] + sh["h"] / 2
        if point_in_shape(px, cy, sh):
            v = shape_field(sh, px, cy) * float(sh.get("strength", 1.0))
            best = v if best is None else max(best, v)
    return best


def _apply_intensity(proj, tr, shapes):
    notes = tr.get("notes") or []
    bars = max(1, int(proj.get("bars") or 1))
    vals = []
    # velocity liczone od wartości sprzed pierwszego zastosowania (geo_vel0) — ponowne „Zastosuj” nie kumuluje skali
    if not tr.get("geo_vel0"):
        tr["geo_vel0"] = [[round(n[0], 4), n[2], n[3]] for n in notes]
    base_v = {(b, k): v for b, k, v in tr["geo_vel0"]}
    for n in notes:
        v0 = base_v.get((round(n[0], 4), n[2]), n[3])
        f = intensity_at(shapes, _bar_frac(proj, n[0]))
        if f is not None:
            n[3] = int(max(1, min(127, v0 * (0.6 + 0.8 * f))))
            vals.append(f)
        else:
            n[3] = v0
    # automatyzacja parametrów: wartość bazowa + (pole − 0.5)·zasięg, co takt, tylko w obrębie figur
    params, locked = tr.setdefault("params", {}), (tr.get("locked_params") or {})
    meta_ok = None
    try:
        from . import core
        meta_ok = core.meta().plugins[tr["plugin"]]["params"]
    except Exception:
        pass
    touched = False
    for pname, lo, hi, rng_ in INTENSITY_PARAMS:
        if pname in locked or (meta_ok is not None and pname not in meta_ok):
            continue
        base = float(params.get(pname, 0.5))
        pts = [p for p in tr.setdefault("auto", {}).get(pname, [])]
        new, last = [], None
        for b in range(bars):
            f = intensity_at(shapes, (b + 0.5) / bars)
            if f is None:
                continue
            v = max(lo, min(hi, base + (f - 0.5) * rng_))
            if last is None or abs(v - last) > 0.01:
                new.append([b * 4.0, round(v, 4)]); last = v
        if new:
            # po ostatnim punkcie figury wróć do wartości bazowej
            new.append([min(bars * 4.0, new[-1][0] + 4.0), round(base, 4)])
            lo_b, hi_b = new[0][0], new[-1][0]
            pts = [p for p in pts if not (lo_b <= p[0] <= hi_b)]
            tr["auto"][pname] = sorted(pts + new)
            touched = True
    if not vals and not touched:
        return None
    return round(sum(vals) / len(vals), 3) if vals else 0.0



def apply_to_project(proj, doc, rng=None):
    """Modyfikuje nuty i parametry wg figur (partition + dwa kanały).

    contour: przesunięcie pitch / przerzedzenie
    intensity: velocity + delikatny bias Cutoff/Drive na torze w oknie czasowym
    """
    rng = rng or random.Random(int(proj.get("seed", 0)) + 61)
    shapes = list(doc.get("shapes") or [])
    if not shapes or not proj.get("tracks"):
        proj["geometry_doc"] = doc
        return {"applied": 0}

    owner = partition_shapes(shapes)
    ny, nx = len(owner), len(owner[0]) if owner else (0, 0)
    by_id = {s["id"]: s for s in shapes}
    report = []

    for tr in proj["tracks"]:
        if tr.get("lock_notes") and tr.get("lock_sound"):
            continue
        name = tr["name"]
        notes = tr.get("notes") or []
        # contour
        if not tr.get("lock_notes"):
            new_notes = []
            for n in notes:
                beat, dur, key, vel = n[0], n[1], n[2], n[3]
                px = _bar_frac(proj, beat)
                # y z velocity jako pas (albo środek)
                py = 0.35 + 0.3 * (1.0 - vel / 127.0)
                i = min(nx - 1, int(px * nx)) if nx else 0
                j = min(ny - 1, int(py * ny)) if ny else 0
                oid = owner[j][i] if ny and nx else None
                sh = by_id.get(oid) if oid else None
                if sh and sh.get("channel") == "contour" and (sh.get("track") in (None, "", name)):
                    field = shape_field(sh, px, py) * float(sh.get("strength", 1))
                    # skos pitch
                    key = int(max(24, min(96, key + round((field - 0.5) * 12))))
                    # gęstość: niski field → czasem drop
                    if field < 0.2 and rng.random() < 0.4:
                        continue
                    vel = int(max(1, min(127, vel * (0.7 + 0.6 * field))))
                new_notes.append([beat, dur, key, vel])
            tr["notes"] = new_notes

        # intensity — przebieg w czasie: pole figur (środek ~1, brzeg ~0) → velocity nut oraz automatyzacja
        # Cutoff/Drive/Resonance (kroki co 1 takt). Figura jest oceniana na SWOJEJ wysokości środka — wcześniej
        # na stałym y=0.5, więc figura narysowana poza środkiem pasa (np. z „Auto” dla ścieżek) nic nie zmieniała.
        if not tr.get("lock_sound"):
            inten_shapes = [s for s in shapes
                            if s.get("channel") == "intensity" and s.get("track") in (None, "", name)]
            if inten_shapes:
                rep = _apply_intensity(proj, tr, inten_shapes)
                if rep is not None:
                    report.append({"track": name, "intensity": rep})

    # generator fill: puste figury contour bez nut w obszarze — dorysuj proste sekwencje
    for sh in shapes:
        if sh.get("fill_mode") != "generator" or sh.get("channel") != "contour":
            continue
        tname = sh.get("track")
        if not tname:
            continue
        tr = next((t for t in proj["tracks"] if t["name"] == tname), None)
        if not tr or tr.get("lock_notes"):
            continue
        _fill_shape_notes(proj, tr, sh, rng)

    proj["geometry_doc"] = doc
    return {"applied": len(shapes), "intensity": report}


def _fill_shape_notes(proj, tr, sh, rng):
    """Wypełnia figurę prostą sekwencją (jeśli mało nut w bbox)."""
    bars = max(1, int(proj.get("bars") or 1))
    b0 = sh["x"] * bars
    b1 = (sh["x"] + sh["w"]) * bars
    beat0, beat1 = b0 * 4, b1 * 4
    existing = [n for n in (tr.get("notes") or []) if beat0 <= n[0] < beat1]
    if len(existing) >= 4:
        return
    # prosta sekwencja w obrębie figury
    root = 48
    if proj.get("chords"):
        bi = int(min(len(proj["chords"]) - 1, max(0, b0)))
        root = 48 + int(proj["chords"][bi][0])
    step = 0.5
    t = beat0
    notes = list(tr.get("notes") or [])
    while t < beat1:
        px = _bar_frac(proj, t)
        py = sh["y"] + sh["h"] * 0.5
        if point_in_shape(px, py, sh):
            field = shape_field(sh, px, py)
            k = root + int(round(field * 7))
            notes.append([round(t, 4), 0.35, k, int(50 + 60 * field)])
        t += step
    tr["notes"] = sorted(notes, key=lambda n: (n[0], n[2]))


def auto_layout_tracks(proj, doc=None):
    """Dla każdego toru: 2 figury (contour + intensity) bez nachodzenia w poziomie."""
    doc = doc or default_document(proj.get("bars") or 64)
    doc["bars"] = int(proj.get("bars") or doc.get("bars") or 64)
    tracks = [t["name"] for t in proj.get("tracks") or []]
    n = max(1, len(tracks))
    shapes = []
    for i, name in enumerate(tracks):
        y0 = i / n
        h = 0.9 / n
        # contour lewa/środek, intensity prawa — bez części wspólnych
        shapes.append(new_shape("ellipse", x=0.05, y=y0 + 0.05 * h, w=0.42, h=h * 0.9,
                                rot=0, channel="contour", track=name))
        shapes.append(new_shape("rect", x=0.52, y=y0 + 0.05 * h, w=0.43, h=h * 0.9,
                                rot=0, channel="intensity", track=name))
    for i, sh in enumerate(shapes):
        sh["z"] = i
    doc["shapes"] = shapes
    return doc
