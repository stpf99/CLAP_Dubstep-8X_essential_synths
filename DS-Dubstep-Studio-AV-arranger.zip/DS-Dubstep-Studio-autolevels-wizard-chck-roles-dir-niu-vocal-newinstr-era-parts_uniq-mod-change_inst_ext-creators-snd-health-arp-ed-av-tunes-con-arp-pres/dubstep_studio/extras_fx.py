"""extras_fx.py — predefiniowane stałe efekty FX z istniejących pluginów + ustalone parametry.

Nie są to nowe CLAP — to „przepisy”: typ wtyczki + snapshot parametrów (0..1) + wzór nut.
Używane przez kreator scenariusza, generację i kartę barw.
"""
from __future__ import annotations

import random

# nazwa → {type, params: {name: frac 0..1}, notes_pattern, gain, desc}
# params w frakcjach CLAP (jak tr["params"]); nieznane nazwy host pominie

def _p(**kw):
    return kw

EXTRAS = {
    # --- kliknięcia / UI / biuro ---
    "fx_calc_click": dict(
        type="rim", gain=0.55, desc="Kliknięcie kalkulatora / przycisku",
        params=_p(**{"Decay": 0.15, "Noise": 0.35, "Tune": 0.55, "Level": 0.7}),
        pattern="ticks",  # krótkie 1/16
    ),
    "fx_mouse_click": dict(
        type="rim", gain=0.45, desc="Klik myszy",
        params=_p(**{"Decay": 0.12, "Noise": 0.5, "Tune": 0.4, "Level": 0.55}),
        pattern="sparse_ticks",
    ),
    "fx_keyboard_type": dict(
        type="hat", gain=0.4, desc="Stukanie w klawiaturę",
        params=_p(**{"Decay": 0.2, "Noise": 0.7, "Cutoff": 0.65, "Level": 0.5}),
        pattern="typewriter",
    ),
    "fx_pen_tap": dict(
        type="rim", gain=0.5, desc="Pukanie długopisem",
        params=_p(**{"Decay": 0.25, "Noise": 0.25, "Tune": 0.35, "Level": 0.6}),
        pattern="sparse_ticks",
    ),
    # --- powierzchnie / opony / kamienie ---
    "fx_tire_pebbles": dict(
        type="shaker", gain=0.65, desc="Szum opon na kamykach",
        params=_p(**{"Decay": 0.55, "Noise": 0.9, "Cutoff": 0.45, "Level": 0.7}),
        pattern="gravel",
    ),
    "fx_gravel_walk": dict(
        type="shaker", gain=0.55, desc="Chodzenie po żwirze",
        params=_p(**{"Decay": 0.4, "Noise": 0.85, "Cutoff": 0.4, "Level": 0.6}),
        pattern="steps",
    ),
    "fx_sand_drag": dict(
        type="shaker", gain=0.5, desc="Przeciąganie po piasku",
        params=_p(**{"Decay": 0.7, "Noise": 0.8, "Cutoff": 0.3, "Level": 0.55}),
        pattern="long_noise",
    ),
    "fx_metal_scrape": dict(
        type="crash", gain=0.45, desc="Skrobanie metalu",
        params=_p(**{"Decay": 0.75, "Noise": 0.7, "Cutoff": 0.55, "Level": 0.5}),
        pattern="scrape",
    ),
    # --- drzwi / room ---
    "fx_door_creak": dict(
        type="theremin", gain=0.4, desc="Skrzypienie drzwi",
        params=_p(**{"Glide": 0.85, "LFO > Pitch": 0.25, "Cutoff": 0.35, "Level": 0.45}),
        pattern="creak",
    ),
    "fx_door_slam": dict(
        type="boom", gain=0.75, desc="Trzask drzwi",
        params=_p(**{"Decay": 0.45, "Noise": 0.5, "Drive": 0.4, "Level": 0.85}),
        pattern="hit",
    ),
    "fx_room_tone": dict(
        type="pad", gain=0.25, desc="Szum pomieszczenia",
        params=_p(**{"Attack": 0.7, "Release": 0.8, "Cutoff": 0.25, "Noise": 0.4, "Level": 0.3}),
        pattern="drone",
    ),
    # --- elektronika / glitch ---
    "fx_static": dict(
        type="zap", gain=0.4, desc="Trzaski / static",
        params=_p(**{"Decay": 0.2, "Noise": 0.9, "FM Amount": 0.3, "Level": 0.5}),
        pattern="glitch",
    ),
    "fx_modem": dict(
        type="screech", gain=0.45, desc="Modem / data burst",
        params=_p(**{"Cutoff": 0.7, "FM Amount": 0.6, "Resonance": 0.5, "Decay": 0.35, "Level": 0.55}),
        pattern="modem",
    ),
    "fx_glitch_stab": dict(
        type="stab", gain=0.55, desc="Glitch stab",
        params=_p(**{"Decay": 0.2, "Cutoff": 0.8, "Drive": 0.4, "Level": 0.65}),
        pattern="stabs",
    ),
    "fx_laser": dict(
        type="zap", gain=0.6, desc="Laser / sci-fi zap",
        params=_p(**{"Pitch Env Amt": 0.8, "Decay": 0.3, "FM Amount": 0.5, "Level": 0.7}),
        pattern="hit",
    ),
    # --- woda / natura (przybliżenia) ---
    "fx_rain": dict(
        type="shaker", gain=0.45, desc="Deszcz (gęsty szum)",
        params=_p(**{"Decay": 0.3, "Noise": 0.95, "Cutoff": 0.5, "Level": 0.5}),
        pattern="rain",
    ),
    "fx_wind": dict(
        type="pad", gain=0.35, desc="Wiatr",
        params=_p(**{"Attack": 0.6, "Cutoff": 0.3, "LFO > Cutoff": 0.4, "Noise": 0.5, "Level": 0.4}),
        pattern="drone",
    ),
    "fx_bird_blip": dict(
        type="pluck", gain=0.4, desc="Ćwierkanie / blip",
        params=_p(**{"Decay": 0.25, "Cutoff": 0.75, "Level": 0.5}),
        pattern="birds",
    ),
    # --- impact / cinematic ---
    "fx_sub_hit": dict(
        type="boom", gain=0.9, desc="Sub impact",
        params=_p(**{"Decay": 0.7, "Pitch Env Amt": 0.6, "Noise": 0.3, "Level": 0.95}),
        pattern="hit",
    ),
    "fx_riser_short": dict(
        type="riser", gain=0.6, desc="Krótki riser",
        params=_p(**{"Attack": 0.3, "Cutoff": 0.6, "Noise": 0.5, "Level": 0.65}),
        pattern="riser_bar",
    ),
    "fx_riser_long": dict(
        type="riser", gain=0.7, desc="Długi riser",
        params=_p(**{"Attack": 0.5, "Cutoff": 0.7, "Noise": 0.55, "Level": 0.7}),
        pattern="riser_long",
    ),
    "fx_cymbal_swell": dict(
        type="crash", gain=0.55, desc="Narastający talerz",
        params=_p(**{"Decay": 0.85, "Noise": 0.6, "Level": 0.6}),
        pattern="swell",
    ),
    # --- vocal-ish ---
    "fx_breath": dict(
        type="vox", gain=0.35, desc="Oddech",
        params=_p(**{"Attack": 0.4, "Decay": 0.5, "Formant Mix": 0.3, "Level": 0.4}),
        pattern="breath",
    ),
    "fx_whisper_pad": dict(
        type="pad", gain=0.4, desc="Szept / air pad",
        params=_p(**{"Attack": 0.55, "Noise": 0.45, "Cutoff": 0.4, "Level": 0.45}),
        pattern="drone",
    ),
    # --- clock / mechanical ---
    "fx_clock_tick": dict(
        type="rim", gain=0.5, desc="Tik zegara",
        params=_p(**{"Decay": 0.1, "Tune": 0.6, "Noise": 0.2, "Level": 0.55}),
        pattern="clock",
    ),
    "fx_gears": dict(
        type="hat", gain=0.45, desc="Zębatki / mechanizm",
        params=_p(**{"Decay": 0.25, "Noise": 0.55, "Cutoff": 0.55, "Level": 0.5}),
        pattern="gears",
    ),
    "fx_coin": dict(
        type="rim", gain=0.55, desc="Moneta / metaliczny ping",
        params=_p(**{"Decay": 0.35, "Tune": 0.75, "Noise": 0.4, "Level": 0.6}),
        pattern="sparse_ticks",
    ),
    # --- bass drops / whoosh ---
    "fx_whoosh": dict(
        type="riser", gain=0.55, desc="Whoosh przejście",
        params=_p(**{"Attack": 0.25, "Decay": 0.4, "Noise": 0.7, "Cutoff": 0.5, "Level": 0.6}),
        pattern="whoosh",
    ),
    "fx_tape_stop": dict(
        type="screech", gain=0.5, desc="Tape stop (przybliżenie)",
        params=_p(**{"Glide": 0.9, "Cutoff": 0.45, "Drive": 0.35, "Level": 0.55}),
        pattern="tape_stop",
    ),
    "fx_vinyl_crackle": dict(
        type="shaker", gain=0.3, desc="Trzaski winyla",
        params=_p(**{"Decay": 0.15, "Noise": 0.95, "Cutoff": 0.55, "Level": 0.35}),
        pattern="crackle",
    ),
}

EXTRAS_GROUPS = {
    "UI / biuro": ["fx_calc_click", "fx_mouse_click", "fx_keyboard_type", "fx_pen_tap", "fx_clock_tick", "fx_coin"],
    "Powierzchnie": ["fx_tire_pebbles", "fx_gravel_walk", "fx_sand_drag", "fx_metal_scrape"],
    "Room / drzwi": ["fx_door_creak", "fx_door_slam", "fx_room_tone"],
    "Glitch / tech": ["fx_static", "fx_modem", "fx_glitch_stab", "fx_laser", "fx_gears"],
    "Natura": ["fx_rain", "fx_wind", "fx_bird_blip"],
    "Cinematic": ["fx_sub_hit", "fx_riser_short", "fx_riser_long", "fx_cymbal_swell", "fx_whoosh", "fx_tape_stop"],
    "Vocal air": ["fx_breath", "fx_whisper_pad"],
    "Vinyl": ["fx_vinyl_crackle"],
}


def list_extras(group=None):
    if group and group in EXTRAS_GROUPS:
        return list(EXTRAS_GROUPS[group])
    return list(EXTRAS.keys())


def get_extra(name):
    return EXTRAS.get(name)


def _pattern_notes(pattern, start_beat, bars, rng):
    """Proste wzorce nut [on, dur, key, vel] w zakresie bars taktów od start_beat."""
    notes = []
    end = start_beat + bars * 4.0
    if pattern == "ticks":
        t = start_beat
        while t < end:
            if rng.random() < 0.7:
                notes.append([t, 0.08, 60 + rng.randint(-2, 2), rng.randint(60, 100)])
            t += 0.25
    elif pattern == "sparse_ticks":
        t = start_beat
        while t < end:
            if rng.random() < 0.25:
                notes.append([t, 0.1, 62, rng.randint(50, 90)])
            t += 0.5
    elif pattern == "typewriter":
        t = start_beat
        while t < end:
            burst = rng.randint(2, 6)
            for _ in range(burst):
                if t >= end:
                    break
                notes.append([t, 0.06, 64 + rng.randint(-4, 4), rng.randint(40, 85)])
                t += rng.choice([0.125, 0.125, 0.25])
            t += rng.uniform(0.3, 1.2)
    elif pattern == "gravel":
        t = start_beat
        while t < end:
            notes.append([t, rng.uniform(0.15, 0.4), 55, rng.randint(40, 80)])
            t += rng.uniform(0.2, 0.6)
    elif pattern == "steps":
        t = start_beat
        while t < end:
            notes.append([t, 0.2, 50, rng.randint(55, 90)])
            t += rng.uniform(0.45, 0.7)
    elif pattern == "long_noise":
        t = start_beat
        while t < end:
            notes.append([t, min(2.0, end - t), 48, rng.randint(35, 60)])
            t += 2.0
    elif pattern == "scrape":
        t = start_beat + rng.uniform(0, 1)
        while t < end:
            notes.append([t, rng.uniform(0.5, 1.5), 40, rng.randint(40, 70)])
            t += rng.uniform(1.5, 3.0)
    elif pattern == "creak":
        t = start_beat + rng.uniform(0, 2)
        notes.append([t, rng.uniform(1.0, 2.5), 45 + rng.randint(0, 12), 55])
    elif pattern == "hit":
        notes.append([start_beat, 0.5, 36, 110])
    elif pattern == "drone":
        notes.append([start_beat, bars * 4.0, 48, 50])
    elif pattern == "glitch":
        t = start_beat
        while t < end:
            if rng.random() < 0.35:
                notes.append([t, rng.choice([0.05, 0.08, 0.15]), 70 + rng.randint(-8, 8), rng.randint(50, 100)])
            t += 0.125
    elif pattern == "modem":
        t = start_beat
        for _ in range(rng.randint(4, 12)):
            if t >= end:
                break
            notes.append([t, 0.12, 60 + rng.randint(0, 24), rng.randint(70, 110)])
            t += 0.15
    elif pattern == "stabs":
        for i in range(bars):
            if rng.random() < 0.5:
                notes.append([start_beat + i * 4 + rng.choice([0, 2]), 0.25, 64, 90])
    elif pattern == "rain":
        t = start_beat
        while t < end:
            notes.append([t, 0.08, 70 + rng.randint(-5, 5), rng.randint(25, 55)])
            t += rng.uniform(0.05, 0.15)
    elif pattern == "birds":
        t = start_beat + rng.uniform(0, 2)
        while t < end:
            notes.append([t, 0.15, 72 + rng.randint(0, 12), rng.randint(50, 80)])
            t += rng.uniform(1.5, 4.0)
    elif pattern == "riser_bar":
        notes.append([start_beat + max(0, bars - 1) * 4, 4.0, 60, 80])
    elif pattern == "riser_long":
        notes.append([start_beat, bars * 4.0, 55, 75])
    elif pattern == "swell":
        notes.append([start_beat, bars * 4.0, 50, 70])
    elif pattern == "breath":
        t = start_beat
        while t < end:
            notes.append([t, 1.0, 55, 40])
            t += rng.uniform(2.0, 4.0)
    elif pattern == "clock":
        t = start_beat
        while t < end:
            notes.append([t, 0.08, 68, 75])
            t += 1.0
    elif pattern == "gears":
        t = start_beat
        while t < end:
            notes.append([t, 0.1, 60 + (int(t * 4) % 5), 60])
            t += 0.25
    elif pattern == "whoosh":
        notes.append([start_beat + (bars * 4 - 2), 2.0, 55, 80])
    elif pattern == "tape_stop":
        notes.append([start_beat + bars * 4 - 2, 2.0, 60, 90])
    elif pattern == "crackle":
        t = start_beat
        while t < end:
            if rng.random() < 0.4:
                notes.append([t, 0.04, 75, rng.randint(20, 45)])
            t += 0.1
    else:
        notes.append([start_beat, 0.5, 60, 80])
    return notes


# Przepisy w EXTRAS używały nazw parametrów, których te wtyczki nie mają (np. shaker nie ma „Decay”/„Cutoff”,
# pad/zap nie mają „Noise”) — host po cichu je pomijał i FX grał na domyślnych. Mapowanie na istniejące nazwy;
# None = brak odpowiednika w tej wtyczce (parametr pomijany jawnie).
PARAM_ALIASES = {
    "shaker": {"Decay": "Noise Decay", "Cutoff": "Noise Lowpass"},
    "riser": {"Decay": "Release"},
    "pad": {"Noise": None},
    "zap": {"Noise": None},
}


def fix_params(ttype, params):
    """Zwraca params z poprawionymi nazwami (aliasy) i bez parametrów nieistniejących w wtyczce ttype."""
    ali = PARAM_ALIASES.get(ttype, {})
    out = {}
    for k, v in (params or {}).items():
        k2 = ali.get(k, k)
        if k2 is not None:
            out[k2] = v
    try:
        from . import core
        valid = core.meta().plugins[core.PLUGIN_ID[ttype]]["params"]
        out = {k: v for k, v in out.items() if k in valid}
    except Exception:
        pass
    return out


def spawn_extra(proj, name, start_bar=0, bars=4, rng=None, track_name=None):
    """Dodaje tor FX z przepisu EXTRAS. Zwraca track lub None."""
    from . import core, generator as G

    spec = EXTRAS.get(name)
    if not spec:
        return None
    rng = rng or random.Random(proj.get("seed", 0))
    ttype = spec["type"]
    try:
        avail = set(core.available_types())
    except Exception:
        avail = set(core.TYPES)
    if ttype not in avail and ttype not in core.TYPES:
        return None
    tr = core.new_track(track_name or G.unique_name(proj, ttype), ttype)
    tr["plugin"] = core.PLUGIN_ID.get(ttype, tr.get("plugin"))
    tr["params"] = fix_params(ttype, spec.get("params"))
    tr["gain"] = float(spec.get("gain", 0.6))
    tr["extra_id"] = name
    tr["notes"] = _pattern_notes(spec.get("pattern") or "hit", start_bar * 4.0, bars, rng)
    proj.setdefault("tracks", []).append(tr)
    try:
        proj["tracks"] = G._order_tracks(proj["tracks"])
    except Exception:
        pass
    return tr


# wagi extras względem charakteru stylu (STYLE_CLASS / nazwa stylu)
# wyższa waga = częściej w auto i podpowiedziach kreatora
STYLE_EXTRA_WEIGHTS = {
    # spokojne / ambient
    "soft": {
        "fx_room_tone": 1.2, "fx_wind": 1.0, "fx_rain": 0.9, "fx_whisper_pad": 1.1,
        "fx_breath": 0.8, "fx_vinyl_crackle": 0.7, "fx_bird_blip": 0.6,
        "fx_door_creak": 0.4, "fx_calc_click": 0.2,
    },
    "chill": {
        "fx_vinyl_crackle": 1.0, "fx_room_tone": 0.9, "fx_rain": 0.8, "fx_whoosh": 0.5,
        "fx_cymbal_swell": 0.6, "fx_whisper_pad": 0.7, "fx_clock_tick": 0.4,
    },
    # club / house / techno
    "club": {
        "fx_riser_short": 1.2, "fx_riser_long": 1.0, "fx_whoosh": 0.9, "fx_cymbal_swell": 0.8,
        "fx_sub_hit": 0.7, "fx_glitch_stab": 0.5, "fx_laser": 0.4,
    },
    # bass / dubstep / neuro
    "bass": {
        "fx_sub_hit": 1.3, "fx_riser_long": 1.1, "fx_riser_short": 1.0, "fx_laser": 0.8,
        "fx_glitch_stab": 0.9, "fx_static": 0.6, "fx_tape_stop": 0.7, "fx_whoosh": 0.8,
    },
    # glitch / experimental
    "glitch": {
        "fx_static": 1.2, "fx_modem": 1.1, "fx_glitch_stab": 1.0, "fx_laser": 0.9,
        "fx_gears": 0.7, "fx_calc_click": 0.6, "fx_keyboard_type": 0.5, "fx_tape_stop": 0.8,
    },
    # cinematic / soundtrack
    "cinematic": {
        "fx_sub_hit": 1.1, "fx_riser_long": 1.2, "fx_whoosh": 1.0, "fx_cymbal_swell": 0.9,
        "fx_door_slam": 0.6, "fx_wind": 0.7, "fx_metal_scrape": 0.5, "fx_room_tone": 0.6,
    },
    # office / foley
    "foley": {
        "fx_calc_click": 1.2, "fx_mouse_click": 1.1, "fx_keyboard_type": 1.0, "fx_pen_tap": 0.9,
        "fx_clock_tick": 0.8, "fx_coin": 0.7, "fx_tire_pebbles": 0.8, "fx_gravel_walk": 0.7,
        "fx_door_creak": 0.6, "fx_door_slam": 0.5,
    },
}

def style_bucket(style_name, style_class=None):
    """Mapuje styl generatora → kubełek wag extras."""
    n = (style_name or "").lower()
    if style_class is None:
        try:
            from . import styles as ST
            style_class = ST.STYLE_CLASS.get(style_name.split("%")[0].split("+")[0].strip(), 2.5)
        except Exception:
            style_class = 2.5
    if any(k in n for k in ("berlin", "space", "ambient", "minimal classical", "deep")):
        return "soft"
    if any(k in n for k in ("liquid", "chill", "jazz", "romantic")):
        return "chill"
    if any(k in n for k in ("house", "trance", "techno", "electro", "edm")):
        return "club"
    if any(k in n for k in ("brostep", "riddim", "tearout", "dubstep", "neuro", "drumstep", "trap", "dnb")):
        return "bass"
    if any(k in n for k in ("experimental", "raw", "glitch")):
        return "glitch"
    if any(k in n for k in ("baroque", "cinematic")):
        return "cinematic"
    if style_class < 1.2:
        return "soft"
    if style_class < 2.2:
        return "chill"
    if style_class < 3.5:
        return "club"
    return "bass"


def weighted_extras_for_style(style_name, n=3, rng=None, style_class=None):
    """Losuje n extras z wagami charakteru stylu."""
    rng = rng or random.Random()
    bucket = style_bucket(style_name, style_class)
    weights = dict(STYLE_EXTRA_WEIGHTS.get(bucket, {}))
    # domyślna mała waga dla reszty
    for k in EXTRAS:
        if not EXTRAS[k].get("adhoc"):              # extras ad hoc (Aranżer) nie wchodzą do losowań wbudowanych
            weights.setdefault(k, 0.15)
    weights = {k: w for k, w in weights.items() if k in EXTRAS and not EXTRAS[k].get("adhoc")}
    # foley lekko zawsze
    for k, w in STYLE_EXTRA_WEIGHTS.get("foley", {}).items():
        weights[k] = max(weights.get(k, 0), w * 0.25)
    keys = list(weights.keys())
    ws = [max(0.01, weights[k]) for k in keys]
    out = []
    pool_k, pool_w = list(keys), list(ws)
    for _ in range(min(n, len(pool_k))):
        total = sum(pool_w)
        r = rng.uniform(0, total); acc = 0.0
        for i, (k, w) in enumerate(zip(pool_k, pool_w)):
            acc += w
            if r <= acc:
                out.append(k)
                pool_k.pop(i); pool_w.pop(i)
                break
    return out, bucket


def ranked_extras_for_style(style_name, style_class=None, limit=12):
    """Posortowana lista (name, weight, desc) do GUI multi-select."""
    bucket = style_bucket(style_name, style_class)
    weights = dict(STYLE_EXTRA_WEIGHTS.get(bucket, {}))
    for k in EXTRAS:
        weights.setdefault(k, 0.12)
    ranked = sorted(weights.items(), key=lambda x: -x[1])
    out = []
    for name, w in ranked[:limit]:
        spec = EXTRAS.get(name) or {}
        out.append((name, w, spec.get("desc", ""), bucket))
    return out
