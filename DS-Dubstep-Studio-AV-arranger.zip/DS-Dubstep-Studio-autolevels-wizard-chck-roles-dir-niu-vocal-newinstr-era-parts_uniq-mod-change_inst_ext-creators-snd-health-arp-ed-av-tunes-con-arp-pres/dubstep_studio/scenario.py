"""scenario.py — scenariusze układu w czasie: MUTACJE struktury stylu + analizator normy + pętla korekt aż do „zaliczenia".

Wejście: bazowa lista sekcji [[typ, takty], ...] (z szablonu stylu), docelowa liczba taktów, agresja A (0..1), optymizm o (0..1), siła mutacji s (0..1).
Mutacje (losowe, ważone stylem/nastrojem): pominięcie lub skrócenie intro (cold open), pominięcie / podwojenie / zmiana długości buildu, dodatkowy mini-break
przed ostatnim dropem, podział dropu mini-breakiem, pominięcie lub wydłużenie outro, „teaser" (krótki drop na początku).
Analizator (reguły grupowane, każdą grupę można wyłączyć): proporcje (suma taktów, udział dropów, długości 4/8/16…), sekwencja (brak dubli, brak 3 dropów pod rząd,
każdy drop po build/break/intro, outro, jest drop) oraz energia (kontrast drop–break). Odstępstwo => korekta zachowująca sumę taktów; do 8 przebiegów."""
from __future__ import annotations

RULES = ("proporcje", "sekwencja", "energia")
DEFAULT_RULES = dict.fromkeys(RULES, True)
MAXLEN = {"build": 16, "break": 32, "intro": 32}


def r4(x):
    return max(4, int(round(x / 4.0)) * 4)


def energies(typ, A, o):
    """Bazowe (e0, e1) sekcji; generate() skaluje je energią projektu."""
    return {"intro": (0.25 + 0.10 * o, 0.35 + 0.10 * A), "build": (0.40 + 0.12 * o, min(1.0, 0.85 + 0.12 * A)), "drop": (1.0, 1.0),
            "break": (0.28 + 0.22 * o, 0.28 + 0.22 * o), "outro": (0.30, 0.10)}[typ]


# ------------------------------------------------------------------ mutacje
def mutate(secs, bars, A, o, s, rng, flags, log):
    secs = [list(x) for x in secs]
    room = lambda extra=1: len(secs) + extra <= max(5, bars / 7)        # krótkie projekty nie dostają dodatkowych sekcji
    p = lambda x: min(0.95, x * s)
    amb = flags.get("ambient")
    if secs and secs[0][0] == "intro" and not amb:
        r = rng.random()
        if r < p(0.30 * (0.5 + A)):
            if rng.random() < 0.4:
                log.append("intro pominięte (cold open)"); secs.pop(0)
            else:
                secs[0][1] = r4(secs[0][1] * rng.choice([0.5, 0.5, 0.75])); log.append(f"intro skrócone do {secs[0][1]} t.")
        elif r < p(0.30 * (0.5 + A)) + p(0.25 * (1.2 - A)):
            secs[0][1] = r4(secs[0][1] * 1.5); log.append(f"intro wydłużone do {secs[0][1]} t.")
    out = []
    for i, (n, b) in enumerate(secs):
        if n == "build":
            q = rng.random(); skip = p(0.20 * (0.4 + A)); dbl = p(0.14)
            if q < skip and out:
                log.append("build pominięty (drop od razu)"); continue
            if q < skip + dbl and b >= 8 and room(3):
                h = r4(b / 2); out += [["build", h], ["break", 4], ["build", h]]; log.append("build podwojony (przedzielony mini-breakiem)"); continue
            nb = rng.choice([4, 8]) if A > 0.65 else rng.choice([8, 16]) if A < 0.4 else rng.choice([4, 8, 16])
            if nb != b and rng.random() < p(0.5):
                log.append(f"build {b}→{nb} t."); b = nb
            out.append(["build", b]); continue
        out.append([n, b])
    secs = out
    drops = [i for i, x in enumerate(secs) if x[0] == "drop"]
    if len(drops) >= 2 and room() and rng.random() < p(0.22 + 0.15 * o):
        i = drops[-1]; secs.insert(i, ["break", 4 if A > 0.6 else 8]); log.append("dodatkowy mini-break przed ostatnim dropem")
    drops = [i for i, x in enumerate(secs) if x[0] == "drop" and x[1] >= 24]
    if drops and room(2) and rng.random() < p(0.20):
        i = rng.choice(drops); h = r4(secs[i][1] / 2); secs[i:i + 1] = [["drop", h], ["break", 4], ["drop", secs[i][1] - h]]; log.append("drop rozdzielony mini-breakiem")
    if secs and secs[-1][0] == "outro" and not amb:
        r = rng.random()
        if r < p(0.14 * (0.5 + A)):
            secs.pop(); flags["allow_cut"] = True; log.append("outro pominięte (twarde cięcie)")
        elif r < p(0.14 * (0.5 + A)) + p(0.25 * (1.2 - A)):
            secs[-1][1] = r4(secs[-1][1] * 1.5); log.append(f"outro wydłużone do {secs[-1][1]} t.")
    if secs and room() and rng.random() < p(0.10 * (0.5 + A)) and not amb and any(x[0] == "drop" for x in secs) and secs[0][0] == "intro":
        secs.insert(0, ["drop", 4]); log.append("teaser: krótki drop na początku")
    return secs


# ------------------------------------------------------------------ analizator
def analyze(secs, bars, rules, flags):
    v = []; tot = sum(b for _, b in secs); amb = flags.get("ambient")
    if rules.get("proporcje", True):
        if tot != bars:
            v.append(("proporcje", "total"))
        share = sum(b for n, b in secs if n == "drop") / max(1, tot); lo, hi = (0.20, 0.60) if amb else (0.30, 0.62 if bars <= 144 else 0.74)
        if share < lo:
            v.append(("proporcje", "drop_low"))
        elif share > hi:
            v.append(("proporcje", "drop_high"))
        for n, b in secs:
            if b % 4 or b < 4:
                v.append(("proporcje", "len4")); break
        for n, b in secs:
            if b > MAXLEN.get(n, 10 ** 9):
                v.append(("proporcje", "too_long")); break
    if rules.get("sekwencja", True):
        if not any(n == "drop" for n, _ in secs):
            v.append(("sekwencja", "no_drop"))
        for i in range(1, len(secs)):
            if secs[i][0] == secs[i - 1][0] and secs[i][0] != "drop":
                v.append(("sekwencja", "dup")); break
        run = 0
        for n, _ in secs:
            run = run + 1 if n == "drop" else 0
            if run >= 3:
                v.append(("sekwencja", "drops_run")); break
        for i in range(1, len(secs)):
            if secs[i][0] == "drop" and secs[i - 1][0] not in ("build", "break", "intro"):
                v.append(("sekwencja", "no_lead_in")); break
        if secs and secs[-1][0] != "outro" and not flags.get("allow_cut") and not amb:
            v.append(("sekwencja", "no_outro"))
    return v


def _donate(secs, need, avoid=None):
    """Zabiera `need` taktów od najdłuższej sekcji, z której da się zabrać (zostawia >= 4); -> True gdy się udało."""
    order = sorted(range(len(secs)), key=lambda i: -secs[i][1])
    for i in order:
        if i != avoid and secs[i][1] - need >= 4:
            secs[i][1] -= need; return True
    return False


def _fix(secs, code, bars):
    if code == "total":
        diff = bars - sum(b for _, b in secs); idx = [i for i, x in enumerate(secs) if x[0] == "drop"] or [max(range(len(secs)), key=lambda i: secs[i][1])]
        k = 0
        while diff and k < 400:
            st = 4 if diff > 0 else -4; i = idx[k % len(idx)]
            if secs[i][1] + st >= 4:
                secs[i][1] += st; diff -= st
            k += 1
    elif code == "drop_low":
        ds = [i for i, x in enumerate(secs) if x[0] == "drop"]
        if ds:
            i = min(ds, key=lambda j: secs[j][1])
            for j in sorted((j for j in range(len(secs)) if secs[j][0] != "drop" and secs[j][1] > 4), key=lambda j: -secs[j][1]):
                secs[j][1] -= 4; secs[i][1] += 4; break
    elif code == "drop_high":
        ds = sorted((i for i, x in enumerate(secs) if x[0] == "drop"), key=lambda j: -secs[j][1])
        bk = [i for i, x in enumerate(secs) if x[0] == "break"]
        if ds and secs[ds[0]][1] >= 8:
            rec = [i for i, x in enumerate(secs) if x[0] in ("outro", "intro") or (x[0] == "break" and x[1] < MAXLEN["break"])]
            secs[ds[0]][1] -= 4
            if rec:
                j = min(rec, key=lambda i: secs[i][1]); secs[j][1] += 4
            else:
                secs.insert(ds[0] + 1, ["break", 4])
    elif code == "len4":
        for x in secs:
            x[1] = r4(x[1])
    elif code == "too_long":
        extra = 0
        for x in secs:
            m = MAXLEN.get(x[0])
            if m and x[1] > m:
                extra += x[1] - m; x[1] = m
        ds = [x for x in secs if x[0] == "drop"]
        if ds and extra:
            ds[-1][1] += extra
    elif code == "dup":
        i = 1
        while i < len(secs):
            if secs[i][0] == secs[i - 1][0] and secs[i][0] != "drop":
                secs[i - 1][1] += secs[i][1]; secs.pop(i)
            else:
                i += 1
    elif code == "drops_run":
        run, i = 0, 0
        while i < len(secs):
            run = run + 1 if secs[i][0] == "drop" else 0
            if run >= 3:
                if secs[i - 1][1] >= 12:
                    secs[i - 1][1] -= 4; secs.insert(i, ["break", 4])
                break
            i += 1
    elif code == "no_lead_in":
        for i in range(1, len(secs)):
            if secs[i][0] == "drop" and secs[i - 1][0] not in ("build", "break", "intro"):
                if secs[i][1] >= 12:
                    secs[i][1] -= 4; secs.insert(i, ["build", 4])
                elif secs[i - 1][1] >= 8:
                    secs[i - 1][1] -= 4; secs.insert(i, ["build", 4])
                break
    elif code == "no_outro":
        if secs and secs[-1][1] >= 16:
            secs[-1][1] -= 8; secs.append(["outro", 8])
    elif code == "no_drop":
        cand = [i for i, x in enumerate(secs) if x[0] not in ("intro", "outro")] or [len(secs) // 2]
        secs[max(cand, key=lambda i: secs[i][1])][0] = "drop"


def correct(secs, bars, rules, flags, log, max_pass=8):
    """Pętla: analiza → korekty → analiza, aż norma zaliczona. -> (sekcje, liczba przebiegów, pozostałe odstępstwa)."""
    secs = [list(x) for x in secs]
    for ps in range(1, max_pass + 1):
        v = analyze(secs, bars, rules, flags)
        if not v:
            return secs, ps - 1, []
        for g, code in v:
            before = [tuple(x) for x in secs]
            _fix(secs, code, bars)
            if [tuple(x) for x in secs] != before:
                log.append(f"korekta [{g}/{code}] (przebieg {ps})")
        _fix(secs, "total", bars)
    return secs, max_pass, analyze(secs, bars, rules, flags)


def build(base, bars, A, o, strength, rng, rules=None, flags=None):
    """-> (sekcje [[typ, takty, e0, e1], ...], raport). base = [[typ, takty], ...] już dopasowane do `bars`."""
    rules = {**DEFAULT_RULES, **(rules or {})}; flags = dict(flags or {}); log = []
    secs = mutate(base, bars, A, o, strength, rng, flags, log) if strength > 0 else [list(x) for x in base]
    secs, passes, rest = correct(secs, bars, rules, flags, log)
    en = {n: energies(n, A, o) for n in ("intro", "build", "drop", "break", "outro")}
    if rules.get("energia", True):                                   # kontrast drop–break musi być wyraźny, inaczej obniżamy break
        c = en["drop"][0] - en["break"][0]
        if c < 0.35:
            en["break"] = (max(0.2, en["drop"][0] - 0.45),) * 2; log.append(f"korekta [energia] kontrast drop–break {c:.2f} → 0.45")
    out = [[n, b, round(en[n][0], 3), round(en[n][1], 3)] for n, b in secs]
    return out, dict(passes=passes, log=log, remaining=[f"{g}/{c}" for g, c in rest], sections=[f"{n}{b}" for n, b, *_ in out])
