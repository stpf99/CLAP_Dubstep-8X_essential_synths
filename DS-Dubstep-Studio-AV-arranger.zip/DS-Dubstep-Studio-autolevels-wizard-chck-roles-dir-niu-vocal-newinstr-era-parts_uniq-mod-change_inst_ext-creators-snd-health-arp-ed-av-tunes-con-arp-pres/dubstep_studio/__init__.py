"""DS Dubstep Studio."""
import os as _os

if not _os.environ.get("DS_NO_MALLOPT"):
    try:        # glibc: duże bufory audio (~20 MB) zawsze przez mmap i zwracane systemowi po zwolnieniu — bez tego RSS rośnie przez fragmentację sterty
        import ctypes as _ct
        _libc = _ct.CDLL("libc.so.6")
        _libc.mallopt(-3, 1 << 20)     # M_MMAP_THRESHOLD = 1 MB (wyłącza dynamiczne podnoszenie progu)
        _libc.mallopt(-8, 2)           # M_ARENA_MAX = 2 (mniej arenek na wątek renderu)
    except Exception:
        pass
