"""scenario_creator.py — interaktywny / auto kreator scenariusza utworu.

Krok po kroku uzupełnia projekt: sekcje → role/instrumenty → extras FX → barwy → nuty.
Tryb auto korzysta z zasobów: styles, extras_fx, timbre_bank, instrument_replace, generator.
"""
from __future__ import annotations

import random
from copy import deepcopy

STEPS = (
    "sections",      # układ intro/build/drop/…
    "palette",       # instrumenty / role
    "timbres",       # barwy pochodne
    "extras",        # FX z extras_fx
    "generate_notes",# GEN na torach
    "polish",        # uniq / niuanse opcjonalnie
)

SECTION_PRESETS = {
    "classic_drop": [("intro", 8), ("build", 8), ("drop", 16), ("break", 8), ("drop", 16), ("outro", 8)],
    "short_radio": [("intro", 4), ("drop", 16), ("outro", 4)],
    "long_journey": [("intro", 16), ("build", 16), ("drop", 16), ("break", 16), ("build", 8), ("drop", 16), ("outro", 16)],
    "no_intro": [("build", 8), ("drop", 16), ("break", 8), ("drop", 16), ("outro", 8)],
    "ambient_flow": [("intro", 16), ("break", 16), ("drop", 8), ("outro", 16)],
}

STEP_LABELS = {
    "sections": "1. Sekcje (scenariusz czasowy)",
    "palette": "2. Paleta instrumentów",
    "timbres": "3. Barwy pochodne",
    "extras": "4. Extras FX",
    "generate_notes": "5. Generacja nut",
    "polish": "6. Polish (uniq / niuanse)",
}


def sections_from_preset(name, bars, rng=None):
    tpl = SECTION_PRESETS.get(name) or SECTION_PRESETS["classic_drop"]
    total = sum(b for _, b in tpl) or 1
    scale = bars / total
    sec, pos = [], 0
    counts = {}
    for typ, b in tpl:
        counts[typ] = counts.get(typ, 0) + 1
        nb = max(4, int(round(b * scale / 4) * 4))
        e0e1 = {"intro": (0.3, 0.4), "build": (0.5, 0.9), "drop": (1.0, 1.0),
                "break": (0.35, 0.35), "outro": (0.3, 0.1)}.get(typ, (0.4, 0.5))
        sec.append({"name": f"{typ}{counts[typ]}", "type": typ, "start": pos, "bars": nb,
                    "e0": e0e1[0], "e1": e0e1[1]})
        pos += nb
    return sec, pos


def new_session(style="Brostep", bars=64, seed=None):

    return {
        "style": style,
        "bars": int(bars),
        "seed": int(seed if seed is not None else random.randrange(10**6)),
        "step_i": 0,
        "choices": {},
        "proj": None,
        "log": [],
    }


def _log(session, msg):
    session.setdefault("log", []).append(msg)


def step_name(session):
    i = session.get("step_i", 0)
    return STEPS[i] if i < len(STEPS) else "done"


def auto_choice(step, session, rng):
    """Propozycja automatu dla kroku."""
    from . import extras_fx as FX
    from . import timbre_bank as TB
    from . import generator as G

    style = session.get("style") or "Brostep"
    if step == "sections":
        # preferuj szablon stylu, inaczej classic_drop
        tpl = G.STYLES.get(style, G.STYLES["Brostep"]).get("template")
        if tpl:
            total = sum(b for _, b in tpl) or 1
            scale = session["bars"] / total
            sec, pos = [], 0
            counts = {}
            for name, b in tpl:
                counts[name] = counts.get(name, 0) + 1
                nb = max(4, int(round(b * scale / 4) * 4))
                e0e1 = {"intro": (0.3, 0.4), "build": (0.5, 0.9), "drop": (1.0, 1.0),
                        "break": (0.35, 0.35), "outro": (0.3, 0.1)}.get(name, (0.4, 0.5))
                sec.append({"name": f"{name}{counts[name]}", "type": name, "start": pos, "bars": nb,
                            "e0": e0e1[0], "e1": e0e1[1]})
                pos += nb
            session["bars"] = pos
            return {"sections": sec, "preset": "style_template"}
        sec, pos = sections_from_preset("classic_drop", session["bars"], rng)
        session["bars"] = pos
        return {"sections": sec, "preset": "classic_drop"}
    if step == "palette":
        core_i = list(G.STYLES.get(style, {}).get("core") or G.CORE8)
        ex = list(G.STYLES.get(style, {}).get("extras") or [])
        pick = core_i + rng.sample(ex, min(len(ex), rng.randint(2, min(5, len(ex) or 1)))) if ex else core_i
        return {"instruments": pick}
    if step == "timbres":
        tags = ["bass", "lead", "pad"]
        picks = []
        for tag in tags:
            opts = TB.list_timbres(tag)
            if opts:
                picks.append(rng.choice(opts))
        return {"timbres": picks}
    if step == "extras":
        picks, bucket = FX.weighted_extras_for_style(style, n=rng.randint(1, 3), rng=rng)
        return {"extras": picks, "extras_bucket": bucket}
    if step == "generate_notes":
        return {"do_notes": True}
    if step == "polish":
        return {"uniq": True, "uniq_strength": 0.5, "niuanse": rng.random() < 0.5, "niuanse_strength": 0.3}
    return {}


def apply_step(session, choice=None, auto=False, rng=None):
    """Wykonuje bieżący krok. choice=None i auto=True → auto_choice."""
    from . import core, generator as G
    from . import extras_fx as FX
    from . import timbre_bank as TB
    from . import uniq as UNIQ
    from . import niuanse as NIU

    rng = rng or random.Random(session.get("seed", 0) + session.get("step_i", 0) * 17)
    step = step_name(session)
    if step == "done":
        return session

    if choice is None and auto:
        choice = auto_choice(step, session, rng)
    choice = choice or {}
    session.setdefault("choices", {})[step] = choice

    if step == "sections":
        secs = choice.get("sections") or auto_choice(step, session, rng)["sections"]
        proj = core.new_project(
            style=session["style"],
            bpm=G.STYLES.get(session["style"], {}).get("bpm", 140),
            key=rng.randrange(12),
            scale="minor",
            bars=session["bars"],
            seed=session["seed"],
        ) if hasattr(core, "new_project") else {
            "style": session["style"], "bpm": 140, "key": 0, "scale": "minor",
            "bars": session["bars"], "seed": session["seed"], "tracks": [], "sections": [],
            "chords": [], "links": [], "swing": 0.0, "energy": 0.7, "density": 0.6,
        }
        # build minimal proj
        if not proj.get("sections"):
            proj["sections"] = secs
            proj["bars"] = sum(s["bars"] for s in secs)
            # proste akordy
            prog = [0, 3, 5, 4]
            proj["chords"] = [[prog[i % 4], 3] for i in range(proj["bars"])]
        session["proj"] = proj
        _log(session, f"Sekcje: {' → '.join(s['type']+str(s['bars']) for s in secs)}")

    elif step == "palette":
        proj = session["proj"]
        inst = choice.get("instruments") or []
        for t in inst:
            if any(tr["type"] == t for tr in proj.get("tracks") or []):
                continue
            try:
                tr = core.new_track(G.unique_name(proj, t), t)
                tr["plugin"] = core.PLUGIN_ID.get(t, tr.get("plugin"))
                proj["tracks"].append(tr)
            except Exception:
                pass
        _log(session, f"Paleta: {', '.join(inst)}")

    elif step == "timbres":
        proj = session["proj"]
        for tid in choice.get("timbres") or []:
            # nałóż na istniejący tor tego base lub spawn
            spec = TB.TIMBRES.get(tid)
            if not spec:
                continue
            base = spec["base"]
            found = next((tr for tr in proj.get("tracks") or [] if tr["type"] == base and not tr.get("timbre_id")), None)
            if found:
                TB.apply_timbre_to_track(found, tid, rng)
            else:
                TB.spawn_timbre(proj, tid, rng)
        _log(session, f"Barwy: {', '.join(choice.get('timbres') or [])}")

    elif step == "extras":
        proj = session["proj"]
        secs = proj.get("sections") or []
        for i, name in enumerate(choice.get("extras") or []):
            sec = secs[min(i, len(secs) - 1)] if secs else {"start": 0, "bars": 4}
            FX.spawn_extra(proj, name, start_bar=int(sec.get("start", 0)), bars=min(4, int(sec.get("bars", 4))), rng=rng)
        _log(session, f"Extras: {', '.join(choice.get('extras') or [])}")

    elif step == "generate_notes":
        proj = session["proj"]
        style = proj.get("style") or session["style"]
        cfg = G.STYLES.get(style) or G.STYLES["Brostep"]
        # uzupełnij Ctx-like bars data
        if not proj.get("sections"):
            proj["sections"] = [{"name": "drop1", "type": "drop", "start": 0, "bars": proj.get("bars", 32)}]
        try:
            c = G.Ctx(proj, cfg)
            for tr in proj.get("tracks") or []:
                if tr.get("lock_notes") or tr.get("extra_id"):
                    continue
                if not tr.get("notes"):
                    if tr["type"] in G.GEN:
                        G.GEN[tr["type"]](c, tr)
                        G.mutate_track(proj, cfg, tr, random.Random(f"{session['seed']}-sc-{tr['name']}"))
                if not tr.get("params") and not tr.get("timbre_id"):
                    G.randomize_sound(proj, tr, random.Random(f"{session['seed']}-scs-{tr['name']}"))
        except Exception as e:
            _log(session, f"generate_notes warn: {e}")
        _log(session, "Wygenerowano nuty na torach bez extras.")

    elif step == "polish":
        proj = session["proj"]
        if choice.get("uniq"):
            UNIQ.apply(proj, strength=float(choice.get("uniq_strength") or 0.5), rng=rng)
        if choice.get("niuanse"):
            NIU.apply_all(proj, float(choice.get("niuanse_strength") or 0.3), rng)
        _log(session, "Polish zastosowany.")

    session["step_i"] = session.get("step_i", 0) + 1
    return session


def run_auto(style="Brostep", bars=64, seed=None, rng=None):
    """Pełny przebieg auto → gotowy proj."""
    session = new_session(style, bars, seed)
    rng = rng or random.Random(session["seed"])
    while step_name(session) != "done":
        apply_step(session, choice=None, auto=True, rng=rng)
    return session
