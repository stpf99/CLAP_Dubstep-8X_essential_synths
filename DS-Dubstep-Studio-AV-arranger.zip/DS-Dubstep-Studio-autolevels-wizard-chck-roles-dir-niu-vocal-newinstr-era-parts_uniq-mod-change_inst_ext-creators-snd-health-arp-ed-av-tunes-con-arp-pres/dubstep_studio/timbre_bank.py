"""timbre_bank.py — barwy pochodne (nie osobne pluginy): zakresy parametrów + opcjonalnie stereo dual.

Barwa = baza (typ CLAP) + ustalone / losowane w oknie parametry + ADSR hint + flaga stereo (2 instancje).
Mutacje: mieszanie 2–3 barw lub jitter w oknie.
"""
from __future__ import annotations

import copy
import random

# id → {base, params_lo/hi lub params fixed, adsr, stereo, desc, tags}
TIMBRES = {
    # lead derivatives
    "lead_glass": dict(base="pluck", desc="Szklany pluck", tags=["lead", "bright"],
                       params={"Cutoff": (0.7, 0.95), "Decay": (0.15, 0.35), "Resonance": (0.2, 0.45), "Drive": (0.0, 0.15)},
                       adsr=(0.01, 0.2, 0.1, 0.25), stereo=False),
    "lead_nasal": dict(base="screech", desc="Nosowy lead FM", tags=["lead"],
                       params={"FM Amount": (0.4, 0.7), "Cutoff": (0.45, 0.65), "Resonance": (0.3, 0.55)},
                       adsr=(0.02, 0.3, 0.5, 0.3), stereo=False),
    "lead_supersaw_wide": dict(base="supersaw", desc="Szeroki supersaw (stereo dual)", tags=["lead", "stereo"],
                               params={"Unison Detune": (0.4, 0.7), "Cutoff": (0.5, 0.75), "Attack": (0.05, 0.2)},
                               adsr=(0.08, 0.4, 0.7, 0.5), stereo=True, stereo_detune=0.03),
    "lead_soft_key": dict(base="piano", desc="Miękkie klawisze", tags=["lead", "keys"],
                          params={"Attack": (0.0, 0.08), "Decay": (0.4, 0.7), "Cutoff": (0.4, 0.65)},
                          adsr=(0.02, 0.5, 0.3, 0.4), stereo=False),
    "lead_theremin_airy": dict(base="theremin", desc="Powietrzny theremin", tags=["lead"],
                               params={"Glide": (0.5, 0.85), "LFO > Pitch": (0.15, 0.4), "Cutoff": (0.4, 0.6)},
                               adsr=(0.1, 0.3, 0.8, 0.4), stereo=False),
    # bass
    "bass_deep_sub": dict(base="sub", desc="Głęboki sub", tags=["bass"],
                          params={"Cutoff": (0.15, 0.35), "Drive": (0.05, 0.25), "Glide": (0.1, 0.4)},
                          adsr=(0.01, 0.3, 0.9, 0.3), stereo=False),
    "bass_wobble_dark": dict(base="wobble", desc="Ciemny wobble", tags=["bass", "dub"],
                             params={"Cutoff": (0.2, 0.4), "Drive": (0.4, 0.7), "Resonance": (0.3, 0.55)},
                             adsr=(0.02, 0.4, 0.85, 0.25), stereo=False),
    "bass_reese_wide": dict(base="reese", desc="Reese stereo", tags=["bass", "stereo"],
                            params={"Unison Detune": (0.35, 0.6), "Cutoff": (0.3, 0.5), "Drive": (0.3, 0.55)},
                            adsr=(0.05, 0.5, 0.9, 0.4), stereo=True, stereo_detune=0.02),
    "bass_acid_squelch": dict(base="acid", desc="Acid squelch", tags=["bass", "acid"],
                              params={"Resonance": (0.65, 0.95), "Cutoff": (0.2, 0.55), "Drive": (0.35, 0.65), "Glide": (0.2, 0.5)},
                              adsr=(0.01, 0.2, 0.5, 0.15), stereo=False),
    "bass_growl_vowel": dict(base="growl", desc="Growl samogłoskowy", tags=["bass"],
                             params={"Formant Mix": (0.6, 0.95), "FM Amount": (0.3, 0.6), "Drive": (0.4, 0.7)},
                             adsr=(0.02, 0.35, 0.8, 0.25), stereo=False),
    # pad / strings
    "pad_warm": dict(base="pad", desc="Ciepły pad", tags=["pad"],
                     params={"Attack": (0.4, 0.7), "Release": (0.5, 0.85), "Cutoff": (0.3, 0.5)},
                     adsr=(0.5, 0.6, 0.85, 0.7), stereo=True, stereo_detune=0.015),
    "pad_strings_lush": dict(base="strings", desc="Bujne smyczki", tags=["pad", "stereo"],
                             params={"Attack": (0.35, 0.6), "Release": (0.6, 0.9), "Unison Detune": (0.3, 0.55)},
                             adsr=(0.4, 0.7, 0.9, 0.8), stereo=True, stereo_detune=0.025),
    "pad_hollow_space": dict(base="hollow", desc="Przestrzenny hollow", tags=["pad", "bass"],
                             params={"Cutoff": (0.35, 0.55), "Attack": (0.2, 0.45), "Release": (0.4, 0.7)},
                             adsr=(0.25, 0.5, 0.8, 0.5), stereo=False),
    # keys / stab
    "stab_tight": dict(base="stab", desc="Ciasny stab", tags=["lead"],
                       params={"Decay": (0.12, 0.28), "Cutoff": (0.55, 0.8), "Drive": (0.15, 0.4)},
                       adsr=(0.01, 0.15, 0.2, 0.2), stereo=False),
    "keys_bell": dict(base="pluck", desc="Dzwonkowe klawisze", tags=["lead", "keys"],
                      params={"Decay": (0.3, 0.55), "Cutoff": (0.65, 0.9), "Attack": (0.0, 0.05)},
                      adsr=(0.01, 0.4, 0.15, 0.45), stereo=True, stereo_detune=0.01),
    # vox
    "vox_choirish": dict(base="vox", desc="Chóralny vox", tags=["vocal", "pad"],
                         params={"Formant Mix": (0.5, 0.85), "Unison Detune": (0.2, 0.45), "Attack": (0.15, 0.35)},
                         adsr=(0.2, 0.5, 0.75, 0.5), stereo=True, stereo_detune=0.02),
    # fx-ish instrument colors
    "fx_bright_zap": dict(base="zap", desc="Jasny zap", tags=["fx"],
                          params={"Decay": (0.15, 0.35), "FM Amount": (0.3, 0.6), "Cutoff": (0.6, 0.9)},
                          adsr=(0.01, 0.2, 0.1, 0.2), stereo=False),
}

# mutacje: id → lista baz do krzyżowania okien parametrów
MUTATION_PAIRS = [
    ("lead_glass", "keys_bell"),
    ("bass_wobble_dark", "bass_acid_squelch"),
    ("pad_warm", "pad_strings_lush"),
    ("lead_supersaw_wide", "pad_warm"),
    ("bass_reese_wide", "bass_deep_sub"),
]


def list_timbres(tag=None, include_adhoc=False):
    """Barwy wbudowane (domyślnie bez ad hoc — te dodaje Aranżer w trakcie pracy i nie mogą zmieniać losowań)."""
    return [k for k, v in TIMBRES.items()
            if (include_adhoc or not v.get("adhoc")) and (not tag or tag in (v.get("tags") or []))]


def sample_params(spec, rng):
    out = {}
    for name, val in (spec.get("params") or {}).items():
        if isinstance(val, (list, tuple)) and len(val) == 2:
            out[name] = rng.uniform(float(val[0]), float(val[1]))
        else:
            out[name] = float(val)
    return out


def mutate_specs(a_id, b_id, rng, mix=None):
    """Miesza okna dwóch barw (wspólne klucze)."""
    a, b = TIMBRES.get(a_id), TIMBRES.get(b_id)
    if not a or not b:
        return None
    mix = rng.uniform(0.3, 0.7) if mix is None else mix
    params = {}
    keys = set(a.get("params") or {}) | set(b.get("params") or {})
    for k in keys:
        va, vb = (a.get("params") or {}).get(k), (b.get("params") or {}).get(k)
        def mid(v):
            if isinstance(v, (list, tuple)):
                return (float(v[0]) + float(v[1])) / 2
            return float(v) if v is not None else None
        ma, mb = mid(va), mid(vb)
        if ma is None and mb is None:
            continue
        if ma is None:
            params[k] = mb
        elif mb is None:
            params[k] = ma
        else:
            params[k] = ma * (1 - mix) + mb * mix
    return dict(
        base=a["base"] if mix < 0.5 else b["base"],
        desc=f"mut:{a_id}+{b_id}",
        tags=list(set((a.get("tags") or []) + (b.get("tags") or []))),
        params={k: (max(0, v - 0.08), min(1, v + 0.08)) for k, v in params.items()},
        adsr=a.get("adsr") if mix < 0.5 else b.get("adsr"),
        stereo=bool(a.get("stereo") or b.get("stereo")),
        stereo_detune=max(a.get("stereo_detune") or 0, b.get("stereo_detune") or 0) or 0.02,
    )


def apply_timbre_to_track(tr, timbre_id, rng=None, custom_spec=None):
    """Ustawia params (i meta) na istniejącym torze. Nie zmienia nut."""
    rng = rng or random.Random()
    spec = custom_spec or TIMBRES.get(timbre_id)
    if not spec:
        return False
    if tr.get("lock_sound"):
        return False
    # jeśli base inny niż type — tylko params gdy zbieżne sensownie; nie wymuszamy zmiany typu tutaj
    params = sample_params(spec, rng)
    tr.setdefault("params", {}).update(params)
    tr["timbre_id"] = timbre_id if not custom_spec else spec.get("desc", "custom")
    if spec.get("adsr"):
        a, d, s, r = spec["adsr"]
        try:
            from . import core as _core
            _valid = _core.meta().plugins[tr["plugin"]]["params"]
        except Exception:
            _valid = None
        for name, val in (("Attack", a), ("Decay", d), ("Release", r)):
            if _valid is not None and name not in _valid:
                continue                       # wtyczka nie ma tego parametru (np. panflute: Decay) — host i tak by go pominął
            if name not in tr["params"]:
                tr["params"][name] = float(val)
    return True


def spawn_timbre(proj, timbre_id, rng=None, force_type=None):
    """Dodaje tor(y) z barwy; stereo=True → dwie instancje z lekkim detune/pan."""
    from . import core, generator as G

    rng = rng or random.Random(proj.get("seed", 0))
    spec = TIMBRES.get(timbre_id)
    if not spec:
        return []
    base = force_type or spec["base"]
    created = []

    def one(suffix="", pan=0.0, det=0.0):
        tr = core.new_track(G.unique_name(proj, base), base)
        tr["plugin"] = core.PLUGIN_ID.get(base, tr.get("plugin"))
        apply_timbre_to_track(tr, timbre_id, rng, spec)
        if det and "Unison Detune" in tr["params"]:
            tr["params"]["Unison Detune"] = min(1.0, tr["params"]["Unison Detune"] + det)
        if det:
            # rozstrojenie L/R ≈ det·600 centów. „Fine” mają tylko niektóre wtyczki (supersaw/pad/pluck/stab… nie) —
            # tam zapis „Fine” był po cichu pomijany przez host i para stereo nie była rozstrojona; wtedy przez „Tune”.
            try:
                from . import core as _core
                valid = _core.meta().plugins[tr["plugin"]]["params"]
            except Exception:
                valid = {"Fine": 1}
            cents = det * 600.0
            if "Fine" in valid:
                tr.setdefault("params", {})["Fine"] = max(0.0, min(1.0, tr["params"].get("Fine", 0.5) + cents / 200.0))
            elif "Tune" in valid:
                tr.setdefault("params", {})["Tune"] = max(0.0, min(1.0, tr["params"].get("Tune", 0.5) + (cents / 100.0) / 72.0))
        tr["pan"] = pan
        tr["timbre_id"] = timbre_id
        proj.setdefault("tracks", []).append(tr)
        created.append(tr)
        return tr

    if spec.get("stereo"):
        d = float(spec.get("stereo_detune") or 0.02)
        one("L", pan=-0.6, det=-d)
        one("R", pan=0.6, det=d)
    else:
        one()
    try:
        proj["tracks"] = G._order_tracks(proj["tracks"])
    except Exception:
        pass
    return created
