"""templates.py — szablony wideo i automatyczna reżyseria pokazu z danych projektu.

projvideo (pv) to słownik JSON, odpowiednik „stanu wtyczek” projektu audio:
  {version, template, size:[w,h], fps, render_scale, palette, meta:{title,style,bpm,key,focus_track}, layers:[{id,plugin,params}],
   links:[{src,dst,param,amount}], cues:[{section:k, mods:{layer_id:{param:wartość}}}]}
build_projvideo(proj, szablon, ...) bierze szablon (szkielet warstw) i dopasowuje go do projektu: dobiera wykonawców do istniejących
ścieżek (kick/snare/bas/lead…), wybiera ścieżkę „focus” do teledysku 1-track, rozpisuje cue na każdą sekcję (intro/build/drop/break/outro).
Para projaudio.json + projvideo.json to pełny, przenośny opis AV utworu (patrz export_package w host.py)."""
from __future__ import annotations

import copy
import json
from pathlib import Path

from .. import core
from .plugins import PALETTES
from .registry import VREG
from .signals import GROUPS

L = lambda lid, plugin, **params: {"id": lid, "plugin": plugin, "params": params}      # noqa: E731

TEMPLATES = {
    "kraftwerk_robots": dict(
        title="Roboty na scenie (koncert-maszyna)", palette="kraftwerk", desc="Siatka neonowa, rząd robotów grających swoje partie, wiązki, scanlines — hołd dla estetyki „człowiek-maszyna”",
        layers=[L("room", "room_grid", density=0.5, speed=0.35, pulse=0.6, color="c"), L("beams", "brush_beams", count=5, intensity=0.35, src="kick", color="b"),
                L("robots", "perf_robot", _auto="robots"), L("parts", "brush_particles", amount=0.35, src="kick", color="hot"),
                L("cam", "cam_drift", amount=0.25, speed=0.15), L("bloom", "fx_bloom", amount=0.35, threshold=0.55), L("scan", "fx_scanlines", amount=0.4, vignette=0.4),
                L("spec", "ov_spectrum", bars=32, opacity=0.4, height=0.14), L("title", "ov_title", corner="bl", scale=1.0), L("fade", "fx_fade", fade_in=1.5, fade_out=3.0)],
        links=[("kick", "room", "pulse", 0.3), ("energy", "beams", "intensity", 0.4), ("energy", "scan", "amount", 0.2), ("kick", "bloom", "amount", 0.25)]),
    "single_track_mv": dict(
        title="Teledysk 1-track", palette="neon", desc="Void + obracający się wireframe + neonowy ślad nut jednej ścieżki (wybierz focus albo auto)",
        layers=[L("room", "room_void", pulse=0.6, glow=0.4, src="energy", color="a"), L("wire", "perf_wire", scale=1.1, spin=0.4, src="focus", color="c"),
                L("trail", "brush_trail", src="focus", width=3, length=0.7, color="b"), L("scope", "brush_scope", y=0.5, height=0.2, glow=0.5, color="c"),
                L("cam", "cam_punch", amount=0.35, shake=0.1, base=1.04, src="kick"), L("glitch", "fx_glitch", amount=0.2, src="snare"), L("bloom", "fx_bloom", amount=0.5),
                L("wave", "ov_wave", y=0.92, height=0.1, opacity=0.6), L("title", "ov_title", corner="tl", scale=0.9), L("fade", "fx_fade", fade_in=1.0, fade_out=3.0)],
        links=[("energy", "trail", "width", 0.3), ("snare", "glitch", "amount", 0.4), ("focus", "wire", "scale", 0.25)]),
    "live_show": dict(
        title="Live show (auto)", palette="neon", desc="Scena z reflektorami, wiązki, cząstki, strobo na kick — automatyczny pokaz z całego projektu",
        layers=[L("room", "room_stage", spots=5, fog=0.4, intensity=0.6), L("beams", "brush_beams", count=6, intensity=0.55, src="kick", sweep=0.6),
                L("robots", "perf_robot", _auto="robots"), L("parts", "brush_particles", amount=0.5, src="kick", color="hot"),
                L("cam", "cam_punch", amount=0.4, shake=0.12, base=1.03, src="kick"), L("strobe", "fx_strobe", amount=0.3, threshold=0.6, src="kick"),
                L("bloom", "fx_bloom", amount=0.45), L("wave", "ov_wave", y=0.93, height=0.09, opacity=0.7), L("spec", "ov_spectrum", bars=48, opacity=0.35, height=0.16),
                L("title", "ov_title", corner="tl", scale=0.9, live=True), L("fade", "fx_fade", fade_in=0.8, fade_out=2.5)],
        links=[("kick", "strobe", "amount", 0.5), ("kick", "parts", "amount", 0.4), ("energy", "room", "ambient", 0.4), ("energy", "beams", "intensity", 0.3)]),
    "led_wall": dict(
        title="Ściana LED + orb", palette="acid", desc="Ściana pikseli reagująca na widmo i pulsująca kula",
        layers=[L("room", "room_ledwall", cols=32, gap=0.3, base=0.1), L("orb", "perf_orb", scale=0.9, rings=0.6, src="kick", color="b"),
                L("cam", "cam_drift", amount=0.15, speed=0.2), L("bloom", "fx_bloom", amount=0.6, threshold=0.4), L("title", "ov_title", corner="br", scale=0.9), L("fade", "fx_fade")],
        links=[("kick", "orb", "scale", 0.3)]),
    "tunnel_trip": dict(
        title="Tunel", palette="sunset", desc="Tunel ramek + bryła + lustro/glitch na dropach",
        layers=[L("room", "room_tunnel", count=14, speed=0.55, sway=0.4, src="kick"), L("wire", "perf_wire", shape="octa", scale=0.9, spin=0.6, src="bass", color="hot"),
                L("mirror", "fx_mirror", mode="lr", mix=0.0), L("glitch", "fx_glitch", amount=0.15, src="snare"), L("bloom", "fx_bloom", amount=0.5),
                L("cam", "cam_punch", amount=0.3, shake=0.2, base=1.02, src="kick"), L("title", "ov_title", corner="bl", scale=0.8), L("fade", "fx_fade")],
        links=[("energy", "room", "speed", 0.3)]),
}

# reżyseria: modyfikacje parametrów na typ sekcji (wartości bezwzględne, nakładane na te warstwy, które istnieją w szablonie)
SECTION_MODS = {
    "intro": {"strobe": {"amount": 0.0}, "glitch": {"amount": 0.05}, "beams": {"intensity": 0.2}, "parts": {"amount": 0.15}, "cam": {"amount": 0.15}, "bloom": {"amount": 0.3}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.3}},
    "build": {"strobe": {"amount": 0.2}, "glitch": {"amount": 0.2}, "beams": {"intensity": 0.55, "sweep": 0.85}, "parts": {"amount": 0.35}, "cam": {"amount": 0.35}, "bloom": {"amount": 0.5}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.6}},
    "drop": {"strobe": {"amount": 0.55}, "glitch": {"amount": 0.4}, "beams": {"intensity": 0.8, "sweep": 0.6}, "parts": {"amount": 0.8}, "cam": {"amount": 0.7}, "bloom": {"amount": 0.7}, "mirror": {"mix": 0.6}, "robots": {"glow": 0.9}},
    "break": {"strobe": {"amount": 0.0}, "glitch": {"amount": 0.0}, "beams": {"intensity": 0.25, "sweep": 0.2}, "parts": {"amount": 0.1}, "cam": {"amount": 0.12}, "bloom": {"amount": 0.35}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.35}},
    "outro": {"strobe": {"amount": 0.0}, "glitch": {"amount": 0.03}, "beams": {"intensity": 0.15}, "parts": {"amount": 0.1}, "cam": {"amount": 0.1}, "bloom": {"amount": 0.3}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.25}},
}


def list_templates():
    return [dict(id=k, title=v["title"], desc=v["desc"], palette=v["palette"], layers=[l["plugin"] for l in v["layers"]]) for k, v in TEMPLATES.items()]


def list_palettes():
    return list(PALETTES)


def _track_counts(proj):
    n = {}
    for t in proj.get("tracks") or []:
        if not t.get("mute") and t.get("notes"):
            n[t["type"]] = n.get(t["type"], 0) + len(t["notes"])
    return n


def pick_focus(proj):
    """Ścieżka do teledysku 1-track: najbardziej „melodyczna” (lead > bas > pad) z największą liczbą nut."""
    best, bs = None, -1
    for t in proj.get("tracks") or []:
        if t.get("mute") or not t.get("notes"):
            continue
        ty = t["type"]; w = 3.0 if ty in GROUPS["lead"] or ty in GROUPS["vocal"] else 2.0 if ty in GROUPS["bass"] else 1.0 if ty in GROUPS["pad"] else 0.2
        sc = w * (len(t["notes"]) ** 0.5)
        if sc > bs:
            best, bs = t["name"], sc
    return best


def _robot_roster(proj, n):
    """Do n robotów przypisuje źródła z istniejących ścieżek (kolejność ważności: kick, snare, bas, lead, perc, pad, vocal)."""
    cnt = _track_counts(proj); have = {g for g, types in GROUPS.items() if any(cnt.get(t) for t in types)}
    order = [g for g in ("kick", "bass", "snare", "lead", "perc", "pad", "vocal", "clap", "tom") if g in have] or ["energy"]
    return [order[k % len(order)] for k in range(n)]


def _spread(n):
    return [0.5] if n == 1 else [0.14 + 0.72 * k / (n - 1) for k in range(n)]


def build_projvideo(proj, template="kraftwerk_robots", size=(1280, 720), fps=30, palette=None, robots=None, focus_track=None, render_scale=1.0, auto_cues=True):
    tpl = TEMPLATES.get(template) or TEMPLATES["live_show"]
    key = core.key_name(proj) if proj.get("tracks") is not None else ""
    pv = dict(version=1, template=template, size=[int(size[0]), int(size[1])], fps=int(fps), render_scale=float(render_scale), palette=palette or tpl["palette"],
              meta=dict(title=str(proj.get("name", "")), style=str(proj.get("style", "")), bpm=int(round(float(proj.get("bpm") or 0))), key=key, focus_track=focus_track or pick_focus(proj)),
              layers=[], links=[], cues=[])
    if pv["palette"] not in PALETTES:
        pv["palette"] = "kraftwerk"
    for l in tpl["layers"]:
        params = dict(l["params"]); auto = params.pop("_auto", None)
        if auto == "robots":
            nr = int(robots or (5 if int(size[0]) >= 1000 else 4)); roster = _robot_roster(proj, nr); xs = _spread(nr)
            for k in range(nr):
                pv["layers"].append(dict(id=f"robot{k + 1}", plugin="perf_robot", params=dict(params, x=xs[k], src=roster[k], scale=0.85 if nr <= 4 else 0.7, color=("a", "c", "a", "c", "a")[k % 5], accent=("b", "hot")[k % 2],
                                                                                           y=0.8 + 0.02 * (k % 2))))
        else:
            pv["layers"].append(dict(id=l["id"], plugin=l["plugin"], params=params))
    ids = {l["id"] for l in pv["layers"]}
    robots_ids = [l["id"] for l in pv["layers"] if l["plugin"] == "perf_robot"]
    for src, dst, prm, amt in tpl["links"]:
        pv["links"].append(dict(src=src, dst=dst, param=prm, amount=amt)) if dst in ids else None
    for rid in robots_ids:                                                           # każdy robot lekko świeci od własnego źródła
        r = next(l for l in pv["layers"] if l["id"] == rid)
        pv["links"].append(dict(src=r["params"]["src"], dst=rid, param="glow", amount=0.3))
    if auto_cues:
        pv["cues"] = auto_cues_for(proj, pv)
    return pv


def auto_cues_for(proj, pv):
    """Cue na każdą sekcję: SECTION_MODS wg typu; „robots” rozwija się na wszystkich wykonawców; tylko parametry, które istnieją w warstwie."""
    layer = {l["id"]: l for l in pv["layers"]}; out = []
    for k, s in enumerate(proj.get("sections") or []):
        mods = {}
        for lid, m in SECTION_MODS.get(s.get("type"), SECTION_MODS["drop"]).items():
            targets = [l["id"] for l in pv["layers"] if l["plugin"] == "perf_robot"] if lid == "robots" else [lid]
            for tid in targets:
                if tid not in layer:
                    continue
                specs = VREG.get(layer[tid]["plugin"]).specs()
                mm = {pn: v for pn, v in m.items() if pn in specs and specs[pn].kind not in ("choice", "bool")}
                if mm:
                    mods[tid] = mm
        out.append(dict(section=k, name=s.get("name") or s.get("type"), mods=mods))
    return out


def validate(pv):
    """Naprawia/odrzuca nieznane wtyczki i parametry (pv z pliku mógł powstać w innej wersji)."""
    pv = copy.deepcopy(pv); pv.setdefault("palette", "kraftwerk"); pv.setdefault("meta", {}); pv.setdefault("links", []); pv.setdefault("cues", []); pv.setdefault("fps", 30)
    pv.setdefault("size", [1280, 720]); pv["layers"] = [l for l in pv.get("layers", []) if l.get("plugin") in VREG]
    for l in pv["layers"]:
        specs = VREG.get(l["plugin"]).specs(); l["params"] = {k: specs[k].clamp(v) for k, v in (l.get("params") or {}).items() if k in specs}
    return pv


def save_projvideo(pv, path):
    Path(path).write_text(json.dumps(pv, ensure_ascii=False, indent=1), encoding="utf-8")
    return str(path)


def load_projvideo(path):
    return validate(json.loads(Path(path).read_text(encoding="utf-8")))
