"""signals.py — sygnały sterujące wideo, liczone z danych projektu (eventy MIDI, sekcje, BPM) i — opcjonalnie — z cech miksu audio.

Źródła (te same nazwy co LINK_SOURCES audio + grupy instrumentów):
  kick snare hat clap tom crash        — akcenty z nut ścieżki danego typu (obwiednia z wygasaniem)
  perc bass lead pad vocal             — grupy instrumentów (obwiednia: nuta trzymana, potem wygasanie)
  focus                                — ścieżka wskazana w meta.focus_track (teledysk 1-track)
  t:<nazwa ścieżki>                    — dowolna ścieżka projektu
  energy build bar_phase beat_phase    — sekcje / metrum
  rms low mid high                     — z miksu (gdy jest `feat`), inaczej wyprowadzone z eventów
Wszystko w rozdzielczości klatek wideo (fps)."""
from __future__ import annotations

import math

import numpy as np

from .. import core

GROUPS = {
    "kick": ("kick",), "snare": ("snare",), "hat": ("hat",), "clap": ("clap",), "tom": ("tom",), "crash": ("crash",),
    "perc": ("hat", "shaker", "rim", "clap"),
    "bass": ("sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow", "acid"),
    "lead": ("screech", "supersaw", "pluck", "stab", "theremin", "panflute", "handpan", "tongue", "piano"),
    "pad": ("pad", "strings"),
    "vocal": ("vox", "speak"),
    "fx": ("riser", "boom", "zap"),
}
RELEASE = {"kick": 0.16, "snare": 0.14, "hat": 0.06, "clap": 0.12, "tom": 0.2, "crash": 0.6, "perc": 0.08, "bass": 0.12, "lead": 0.18, "pad": 0.5, "vocal": 0.2, "fx": 0.3}
SOURCES = ("kick", "snare", "hat", "clap", "tom", "crash", "perc", "bass", "lead", "pad", "vocal", "fx", "focus", "energy", "build", "bar_phase", "beat_phase", "rms", "low", "mid", "high")


def _follow(x, dt, rel):
    out = np.empty_like(x); k = math.exp(-dt / max(rel, 1e-3)); v = 0.0
    for i in range(len(x)):
        v = x[i] if x[i] > v * k else v * k
        out[i] = v
    return out


def audio_features(mix, fps, sr=None, nb=32):
    """mix: float32 (n,2) → cechy na klatkę: rms, low/mid/high (0..1), spec (F, nb), mono (zdecymowany) do falownika."""
    sr = sr or core.SR
    x = np.asarray(mix, np.float32)
    mono = x.mean(axis=1) if x.ndim == 2 else x
    F = int(len(mono) / sr * fps) + 1
    hop = sr / fps; N = 2048
    win = np.hanning(N).astype(np.float32)
    edges = np.unique(np.geomspace(2, N // 2 - 1, nb + 1).astype(int))
    freqs = np.fft.rfftfreq(N, 1.0 / sr)
    spec = np.zeros((F, len(edges) - 1), np.float32); rms = np.zeros(F, np.float32)
    pad = np.concatenate([np.zeros(N // 2, np.float32), mono, np.zeros(N, np.float32)])
    B = 256
    for b0 in range(0, F, B):
        idx = (np.arange(b0, min(F, b0 + B)) * hop).astype(np.int64)
        seg = np.stack([pad[i: i + N] for i in idx]) * win
        mag = np.abs(np.fft.rfft(seg, axis=1)) / (N / 4)
        for j in range(len(edges) - 1):
            spec[b0: b0 + len(idx), j] = mag[:, edges[j]: max(edges[j] + 1, edges[j + 1])].mean(axis=1)
        rms[b0: b0 + len(idx)] = np.sqrt((seg ** 2).mean(axis=1) / 0.375 + 1e-12)
    spec = np.log1p(spec * 30.0); spec /= max(1e-6, np.percentile(spec, 99.0)); spec = np.clip(spec, 0, 1)
    rms = np.clip(rms / max(1e-6, np.percentile(rms, 99.0)), 0, 1)
    nbands = spec.shape[1]; a, b = max(1, nbands // 5), max(2, nbands * 3 // 5)
    low, mid, high = spec[:, :a].mean(1), spec[:, a:b].mean(1), spec[:, b:].mean(1)
    dec = 4
    return dict(rms=rms, low=np.clip(low, 0, 1), mid=np.clip(mid, 0, 1), high=np.clip(high, 0, 1), spec=spec, mono=mono[::dec].copy(), mono_sr=sr // dec, fps=fps)


class Signals:
    def __init__(self, proj, fps, feat=None, n=None):
        self.proj, self.fps, self.feat = proj, int(fps), feat
        self.bpm = float(proj.get("bpm") or 140); self.spb = 60.0 / self.bpm
        total = float(proj.get("bars") or 1) * 4 * self.spb
        if n is None:
            n = int(math.ceil(total * self.fps)) + 1
            if feat is not None:
                n = max(n, len(feat["rms"]))
        self.n = int(n); self.dt = 1.0 / self.fps
        self.t = np.arange(self.n, dtype=np.float64) * self.dt
        secs = proj.get("sections") or [{"type": "drop", "start": 0, "bars": max(1, int(proj.get("bars") or 1)), "e0": 0.6, "e1": 0.6}]
        self.sections = secs
        self.sec = np.zeros(self.n, np.int32); self.energy = np.full(self.n, 0.4, np.float32); self.build = np.zeros(self.n, np.float32)
        bar = 4 * self.spb
        for k, s in enumerate(secs):
            a = int(round(s["start"] * bar * self.fps)); b = int(round((s["start"] + s["bars"]) * bar * self.fps))
            e0 = float(s.get("e0", 0.5)); e1 = float(s.get("e1", e0))
            a2, b2 = max(0, a), min(self.n, max(a + 1, b))
            self.sec[a2:] = k
            if b2 > a2:
                self.energy[a2:b2] = np.linspace(e0, e1, b2 - a2, endpoint=False)
                if s.get("type") == "build":
                    self.build[a2:b2] = np.linspace(0, 1, b2 - a2, endpoint=False)
        self.energy[int(round(secs[-1]["start"] * bar * self.fps)) + max(1, int(round(secs[-1]["bars"] * bar * self.fps))):] = float(secs[-1].get("e1", 0.2))
        self.bar_phase = ((self.t / bar) % 1.0).astype(np.float32); self.beat_phase = ((self.t / self.spb) % 1.0).astype(np.float32)
        self._cache = {}
        self._tracks = proj.get("tracks") or []
        self.focus_name = None
        self._pitch = {}
        self.s = {"energy": self.energy, "build": self.build, "bar_phase": self.bar_phase, "beat_phase": self.beat_phase}
        if feat is not None:
            for k in ("rms", "low", "mid", "high"):
                a = np.asarray(feat[k], np.float32)
                self.s[k] = np.pad(a, (0, max(0, self.n - len(a))), mode="edge")[: self.n]

    # ---- ścieżki
    def _events(self, tracks):
        ev = []
        for tr in tracks:
            if tr.get("mute"):
                continue
            for on, dur, key, vel in tr.get("notes") or []:
                ev.append((float(on) * self.spb, max(0.03, float(dur) * self.spb), int(key), float(vel) / 127.0))
        return ev

    def _env_from(self, ev, rel):
        x = np.zeros(self.n, np.float32)
        for t0, d, _k, v in ev:
            a = int(t0 * self.fps); b = int((t0 + min(d, 4.0)) * self.fps)
            if 0 <= a < self.n:
                x[a: min(self.n, max(a + 1, b))] = np.maximum(x[a: min(self.n, max(a + 1, b))], v)
        return _follow(x, self.dt, rel)

    def _pitch_from(self, ev):
        """pitch 0..1 (względem zakresu nut ścieżki) i bramka — dla pędzla śladu."""
        pt = np.zeros(self.n, np.float32); gate = np.zeros(self.n, np.float32)
        if not ev:
            return pt, gate
        keys = [e[2] for e in ev]; lo, hi = min(keys), max(keys)
        for t0, d, k, v in sorted(ev):
            a = int(t0 * self.fps); b = int((t0 + d) * self.fps)
            if 0 <= a < self.n:
                bb = min(self.n, max(a + 1, b)); pt[a:bb] = (k - lo) / max(1, hi - lo); gate[a:bb] = v
        return pt, gate

    def set_focus(self, name):
        self.focus_name = name; self._cache.pop("focus", None); self._pitch.pop("focus", None)

    def _tracks_for(self, name):
        if name == "focus":
            return [t for t in self._tracks if t.get("name") == self.focus_name] or [t for t in self._tracks if t.get("type") in GROUPS["lead"] + GROUPS["bass"]][:1]
        if name.startswith("t:"):
            return [t for t in self._tracks if t.get("name") == name[2:]]
        types = GROUPS.get(name)
        return [t for t in self._tracks if types and t.get("type") in types]

    def arr(self, name):
        if name in self.s:
            return self.s[name]
        if name in self._cache:
            return self._cache[name]
        trs = self._tracks_for(name)
        ev = self._events(trs)
        a = self._env_from(ev, RELEASE.get(name, 0.2)) if ev else np.zeros(self.n, np.float32)
        if not ev and name in ("rms", "low", "mid", "high"):
            a = self._derived(name)
        self._cache[name] = a
        return a

    def _derived(self, name):                # bez miksu: przybliżenie z eventów
        k, b, h, e = self.arr("kick"), self.arr("bass"), self.arr("perc"), self.energy
        return {"rms": np.clip(0.35 * e + 0.35 * k + 0.2 * b + 0.1 * h, 0, 1), "low": np.clip(0.6 * k + 0.6 * b, 0, 1), "mid": np.clip(0.5 * self.arr("lead") + 0.4 * self.arr("snare") + 0.2 * e, 0, 1),
                "high": np.clip(0.7 * h + 0.3 * self.arr("snare"), 0, 1)}[name]

    def pitch(self, name, i):
        """(pitch 0..1, gate 0..1) dla grupy/ścieżki w klatce i."""
        if name not in self._pitch:
            self._pitch[name] = self._pitch_from(self._events(self._tracks_for(name)))
        pt, g = self._pitch[name]
        i = min(max(0, int(i)), self.n - 1)
        return float(pt[i]), float(g[i])

    def value(self, name, i):
        i = min(max(0, int(i)), self.n - 1)
        if name == "section_flash":
            k = int(self.sec[i]); a = self.sections[k]["start"] * 4 * self.spb
            return float(max(0.0, 1.0 - (self.t[i] - a) / 0.5))
        return float(self.arr(name)[i])

    def section(self, i):
        return self.sections[int(self.sec[min(max(0, int(i)), self.n - 1)])]

    # ---- widmo i fala (z miksu albo syntetyczne z eventów)
    def spec(self, i, nb=32):
        i = min(max(0, int(i)), self.n - 1)
        if self.feat is not None:
            row = self.feat["spec"][min(i, len(self.feat["spec"]) - 1)]
            return np.interp(np.linspace(0, len(row) - 1, nb), np.arange(len(row)), row)
        x = np.linspace(0, 1, nb); k, b, l, h = (float(self.arr(s)[i]) for s in ("kick", "bass", "lead", "perc"))
        tt = self.t[i]
        base = k * np.exp(-x * 9) + b * np.exp(-((x - 0.15) ** 2) * 60) + l * np.exp(-((x - 0.5) ** 2) * 14) + h * np.exp(-((1 - x) ** 2) * 30)
        wob = 0.12 * (0.5 + 0.5 * np.sin(tt * 7 + x * 13)) * float(self.energy[i])
        return np.clip(base * 0.9 + wob, 0, 1)

    def wave(self, i, m=256):
        i = min(max(0, int(i)), self.n - 1)
        if self.feat is not None:
            mono, sr = self.feat["mono"], self.feat["mono_sr"]
            c = int(i / self.fps * sr); half = int(sr * 0.012)
            seg = mono[max(0, c - half): c + half]
            if len(seg) > 8:
                return np.interp(np.linspace(0, len(seg) - 1, m), np.arange(len(seg)), seg) * 2.0
        tt = self.t[i]; x = np.linspace(0, 1, m)
        a = 0.4 * float(self.arr("bass")[i]) + 0.3 * float(self.arr("lead")[i]) + 0.2 * float(self.arr("kick")[i])
        return a * (np.sin(2 * np.pi * (3 * x + tt * 2)) + 0.4 * np.sin(2 * np.pi * (9 * x - tt * 5)))
