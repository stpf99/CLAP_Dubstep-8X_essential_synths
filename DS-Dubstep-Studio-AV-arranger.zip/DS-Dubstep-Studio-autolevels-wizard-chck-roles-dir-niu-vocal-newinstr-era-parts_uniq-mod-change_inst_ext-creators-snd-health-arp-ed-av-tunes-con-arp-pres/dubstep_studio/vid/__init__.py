"""vid — host renderu wideo + wtyczki (room / performer / brush / camera / fx / overlay)."""
from .registry import VREG, list_plugins, make_plugin
from . import plugins as _plugins  # noqa: F401 — rejestracja
from . import host
from . import templates

__all__ = [
    "VREG", "list_plugins", "make_plugin",
    "host", "templates",
]
