from ..rcore import Registry

VREG = Registry("video")

def list_plugins(kind=None):
    return VREG.describe(kind)

def make_plugin(pid, **params):
    return VREG.make(pid, **params)
