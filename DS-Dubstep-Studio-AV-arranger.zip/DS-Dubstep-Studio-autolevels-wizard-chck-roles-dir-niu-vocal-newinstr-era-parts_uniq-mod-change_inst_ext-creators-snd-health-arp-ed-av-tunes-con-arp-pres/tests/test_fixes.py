"""Testy regresji dla poprawek 1–9 (przegląd kodu wg założeń projektu).

Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_fixes -v

Testy oznaczone @needs_host wymagają zbudowanego hosta (`make` → build/dsrender + wtyczki .clap),
bo generator pobiera metadane parametrów z wtyczek. Test GUI wymaga dodatkowo PyQt6 (działa w trybie offscreen).
Bez hosta / PyQt6 odpowiednie testy są pomijane, a reszta (czysta logika) i tak się wykonuje.
"""
import fcntl
import json
import multiprocessing as mp
import os
import random
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import core  # noqa: E402


def _host_ok():
    try:
        core.meta()
        return True
    except Exception:
        return False


HOST = _host_ok()
needs_host = unittest.skipUnless(HOST, "brak zbudowanego hosta (uruchom `make`)")


def _gen(style="Brostep", **kw):
    from dubstep_studio import generator as G
    return G.generate(style, bars=kw.pop("bars", 64), **kw)


# ---------------------------------------------------------------- 1. podsłuch extras/barw (GUI)
class TestGuiPreview(unittest.TestCase):
    @needs_host
    def test_preview_extra_and_timbre_play_a_wav(self):
        try:
            from PyQt6 import QtWidgets  # noqa: F401
        except Exception:
            self.skipTest("brak PyQt6")
        code = r'''
import os, sys, wave
os.environ["QT_QPA_PLATFORM"] = "offscreen"
sys.path.insert(0, %r)
from PyQt6 import QtWidgets
app = QtWidgets.QApplication([])
from dubstep_studio import gui, extras_fx as FX, timbre_bank as TB
w = gui.MainWindow(); played = []
class P:
    def play(self, path): played.append(str(path)); return True
    def stop(self): pass
    def elapsed(self): return None
w.player = P()
w._preview_extra_or_timbre(extra=next(iter(FX.EXTRAS)))
ok1 = bool(played) and w.status.text().startswith("Podsłuch:") and "błąd" not in w.status.text()
played.clear()
w._preview_extra_or_timbre(timbre=next(iter(TB.TIMBRES)))
ok2 = bool(played) and "błąd" not in w.status.text()
with wave.open(played[0]) as f: ok3 = f.getnchannels() == 2 and f.getnframes() > 48000
print("RESULT", ok1, ok2, ok3)
''' % str(ROOT)
        env = dict(os.environ, HOME=tempfile.mkdtemp(), DS_TMP=tempfile.mkdtemp())
        r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env, timeout=240)
        self.assertIn("RESULT True True True", r.stdout, r.stdout[-400:] + r.stderr[-400:])


# ---------------------------------------------------------------- 2. klucze MIDI w zakresie 0..127
class TestMidiRange(unittest.TestCase):
    def test_snap_never_jumps_across_the_octave(self):
        from dubstep_studio import niuanse as N
        for key in range(12):
            for sc in ("minor", "major", "phrygian", "dorian"):
                pcs = N._scale_pcs({"key": key, "scale": sc})
                for k in range(0, 128):
                    s = N._snap(k, pcs)
                    self.assertIn(s % 12, pcs)
                    self.assertLessEqual(abs(s - k), 3, (key, sc, k, s))

    def test_niuanse_keeps_notes_in_range(self):
        from dubstep_studio import niuanse as N
        bad = 0
        for seed in range(250):
            for strength in (-1.0, -0.5, 0.6, 1.0):
                notes = [[i * 0.5, 0.4, 24 + (i * 5) % 30, 90] for i in range(24)]      # rejestr basowy 24..53
                proj = {"key": 0, "scale": "minor", "tracks": [{"name": "a", "type": "acid", "notes": notes}]}
                N.apply_all(proj, strength, rng=random.Random(seed))
                if any(not (0 <= n[2] <= 127) for n in proj["tracks"][0]["notes"]):
                    bad += 1
        self.assertEqual(bad, 0)

    def test_fold_key_and_sanitize(self):
        for k in range(-500, 700):
            f = core.fold_key(k)
            self.assertTrue(0 <= f <= 127)
            self.assertEqual((f - k) % 12, 0)                      # klasa wysokości zachowana
        proj = {"tracks": [{"notes": [[0, 1, -12, 200], [1, 1, 60, 0], [2, 1, 60, 80]]}]}
        self.assertEqual(core.sanitize_notes(proj), 2)
        self.assertEqual(proj["tracks"][0]["notes"], [[0, 1, 0, 127], [1, 1, 60, 1], [2, 1, 60, 80]])

    def test_write_midi_survives_out_of_range_notes(self):
        proj = {"bars": 2, "bpm": 120, "tracks": [{"name": "x", "type": "acid", "notes": [[0.0, 1.0, -12, 200], [1.0, 1.0, 300, 0]]}]}
        path = Path(tempfile.mkdtemp()) / "t.mid"
        core.write_midi(proj, path)
        self.assertGreater(path.stat().st_size, 30)

    @needs_host
    def test_generate_output_is_always_valid_midi(self):
        for style in ("Baroque", "Brostep", "Techno"):
            for seed in range(8):
                p = _gen(style, seed=seed, niuanse=True, niuanse_strength=-0.8, role_swap=True, smart_instruments=True)
                self.assertTrue(all(0 <= n[2] <= 127 and 1 <= n[3] <= 127 for t in p["tracks"] for n in t["notes"]))
                core.write_midi(p, Path(tempfile.mkdtemp()) / "x.mid")


# ---------------------------------------------------------------- 3. determinizm seeda (hash() nazw)
class TestSeedDeterminism(unittest.TestCase):
    @needs_host
    def test_same_seed_same_notes_regardless_of_pythonhashseed(self):
        code = ("import sys, json, hashlib; sys.path.insert(0, %r)\n"
                "from dubstep_studio import generator as G\n"
                "out=[]\n"
                "for st in ('Techno','Brostep','Trance'):\n"
                "    for sd in (1,2,3):\n"
                "        p=G.generate(st,bars=64,seed=sd,arp={'enabled':True,'structural_inject':True})\n"
                "        out.append(hashlib.md5(json.dumps(p,sort_keys=True,default=str).encode()).hexdigest())\n"
                "print('H', ''.join(out))\n") % str(ROOT)
        res = set()
        for hs in ("1", "2", "3"):
            env = dict(os.environ, PYTHONHASHSEED=hs, DS_TMP=tempfile.mkdtemp())
            r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env, timeout=240)
            self.assertEqual(r.returncode, 0, r.stderr[-400:])
            res.add(r.stdout.strip().splitlines()[-1])
        self.assertEqual(len(res), 1, "ten sam seed daje inny projekt przy innym PYTHONHASHSEED")


# ---------------------------------------------------------------- 4 + 6. live: plan_next i scalanie opcji
class TestLivePlanning(unittest.TestCase):
    @needs_host
    def test_plan_next_with_a_single_available_extra(self):
        from dubstep_studio import live as L, config as CF
        cfgf = Path(tempfile.mkdtemp()) / "config.txt"
        cfgf.write_text("[live]\nmode = random\nlock = style\n[generator]\nstyle = Riddim\n")
        conf = CF.load(cfgf)
        cfg = CF.to_live_cfg(conf, L.DEFAULT_CFG); base = CF.to_base(conf)
        for seed in range(120):
            L.plan_next(cfg, base, random.Random(seed), set(core.CORE8) | {"clap"})     # nie może rzucić ValueError

    def test_complexity_bundle_never_lowers_generator_strength(self):
        from dubstep_studio import live as L
        bundle = dict(niuanse=True, niuanse_strength=0.2, uniq=True, uniq_strength=0.1, uniq_drops=False,
                      spectacle="balanced", era="auto", mood=0.0)
        r = L._gen_extras_from_base({"niuanse": True, "niuanse_strength": 0.9, "uniq": True, "uniq_strength": 0.9, "uniq_drops": True}, bundle=bundle)
        self.assertEqual((r["niuanse_strength"], r["uniq_strength"], r["uniq_drops"]), (0.9, 0.9, True))
        r = L._gen_extras_from_base({}, bundle=bundle)                                   # Generator wyłączony → rządzi pakiet
        self.assertEqual((r["niuanse"], r["niuanse_strength"], r["uniq"], r["uniq_strength"]), (True, 0.2, True, 0.1))
        r = L._gen_extras_from_base({"niuanse": True, "niuanse_strength": 0.7, "uniq": True, "uniq_strength": 0.5},
                                    bundle=dict(bundle, niuanse=False, uniq=False))      # pakiet wyłączony → zostaje Generator
        self.assertEqual((r["niuanse"], r["niuanse_strength"], r["uniq"], r["uniq_strength"]), (True, 0.7, True, 0.5))

    def test_autolevels_default_matches_config_default(self):
        from dubstep_studio import live as L
        self.assertFalse(L._gen_extras_from_base({})["autolevels"])
        self.assertTrue(L._gen_extras_from_base({"autolevels": True})["autolevels"])


# ---------------------------------------------------------------- 5. reżyser a blokady
class TestDirectorLocks(unittest.TestCase):
    @needs_host
    def test_apply_roles_leaves_locked_tracks_alone(self):
        from dubstep_studio import director as DIR
        ins = ["kick", "snare", "hat", "sub", "wobble", "growl", "screech", "supersaw", "reese"]
        events = 0
        for seed in range(1, 16):
            p = _gen("Brostep", seed=seed, instruments=ins)
            locked = [t for t in p["tracks"] if t["type"] in DIR.BASS_T][:1] + [t for t in p["tracks"] if t["type"] in DIR.LEAD_T][:1]
            for t in locked:
                t["lock_notes"] = True; t["lock_sound"] = True
            snap = {t["name"]: json.dumps([t["notes"], t["auto"], t["params"]], sort_keys=True) for t in locked}
            events += len(DIR.apply_roles(p, DIR.normalize(dict(on=True, roles=True, role_amount=1.0)), random.Random(seed), 0.6, 0.5))
            for t in locked:
                self.assertEqual(json.dumps([t["notes"], t["auto"], t["params"]], sort_keys=True), snap[t["name"]], t["name"])
        self.assertGreater(events, 0, "zamiany ról wciąż powinny działać na ścieżkach niezablokowanych")


# ---------------------------------------------------------------- 7. eco: licznik, .part, jedna instancja
def _count_worker(d):
    from dubstep_studio import eco
    return [eco._next_no(d) for _ in range(150)]


class TestEco(unittest.TestCase):
    def test_counter_is_unique_across_processes(self):
        d = tempfile.mkdtemp()
        with mp.Pool(6) as pool:
            flat = [x for r in pool.map(_count_worker, [d] * 6) for x in r]
        self.assertEqual(len(set(flat)), len(flat))

    def test_encode_leaves_no_part_file_when_ffmpeg_dies(self):
        import numpy as np
        from dubstep_studio import eco
        real = subprocess.Popen

        class Dead:
            def __init__(s, *a, **k):
                s._p = real(["sh", "-c", "exit 3"], stdin=subprocess.PIPE); s.stdin = s._p.stdin

            def wait(s):
                return s._p.wait()

            @property
            def returncode(s):
                return s._p.returncode
        out = Path(tempfile.mkdtemp()) / "000001-X-140bpm.mp3"
        subprocess.Popen = Dead
        try:
            with self.assertRaises(RuntimeError):
                eco._encode(out, np.zeros((1 << 20, 2), dtype="float32"), "mp3", "t")
        finally:
            subprocess.Popen = real
        self.assertFalse(Path(str(out) + ".part").exists())
        self.assertFalse(out.exists())

    @needs_host
    def test_preroll_is_single_instance_and_sweeps_part_files(self):
        from dubstep_studio import eco
        d = Path(tempfile.mkdtemp()); (d / "000001-X-140bpm.wav").write_bytes(b"x"); (d / "000002-X.mp3.part").write_bytes(b"junk")
        held = open(d / ".preroll.lock", "a+"); fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
        logs = []
        self.assertEqual(eco.preroll({}, {}, d, fill=1, log=logs.append), 0)
        self.assertTrue(any("już działa" in m for m in logs))
        self.assertTrue((d / "000002-X.mp3.part").exists())          # cudza blokada → nic nie ruszamy
        held.close()
        self.assertEqual(eco.preroll({}, {}, d, fill=1, log=logs.append), 0)   # fill=1 i plik już jest → 0 do zrobienia
        self.assertFalse((d / "000002-X.mp3.part").exists())


# ---------------------------------------------------------------- 8. sprzątanie /tmp tylko własnych katalogów
class TestCleanupStaleWork(unittest.TestCase):
    def test_only_own_work_dirs_are_removed(self):
        tmp = tempfile.mkdtemp(); old = time.time() - 3600
        keep = ["dsrender-build", "dsr_cache_backup", "dsr_xyz", f"dsr{os.getpid()}_ab12cd34"]
        drop = ["dsr99999999_ab12cd34", "dsr_ab12cd34"]
        for n in keep + drop:
            os.makedirs(os.path.join(tmp, n)); os.utime(os.path.join(tmp, n), (old, old))
        os.makedirs(os.path.join(tmp, "dsr_zz99yy88"))                      # stary format, ale świeży
        os.symlink("/tmp", os.path.join(tmp, "dsr_ln00ln00"))               # dowiązanie symboliczne
        prev = os.environ.get("DS_TMP"); os.environ["DS_TMP"] = tmp
        try:
            n = core.cleanup_stale_work()
        finally:
            if prev is None:
                os.environ.pop("DS_TMP", None)
            else:
                os.environ["DS_TMP"] = prev
        self.assertEqual(n, len(drop))
        self.assertEqual(set(os.listdir(tmp)), set(keep) | {"dsr_zz99yy88", "dsr_ln00ln00"})


# ---------------------------------------------------------------- 9. cache stemów nie rośnie bez ograniczeń
class TestStemCache(unittest.TestCase):
    @needs_host
    def test_cache_holds_only_current_stems_and_still_skips_unchanged(self):
        p = _gen("Brostep", bars=16, seed=3, instruments=["kick", "snare", "hat", "sub", "wobble", "pad"])
        cache = {}
        core.render_stems(p, None, cache); n0 = len(cache)
        for i in range(4):
            t = [t for t in p["tracks"] if t["type"] == "wobble"][0]; t["params"]["Cutoff"] = 0.2 + 0.1 * i
            core.render_stems(p, None, cache)
        self.assertEqual(len(cache), n0, "stare wersje stemów zostały w cache")
        calls = []; real = subprocess.run
        subprocess.run = lambda *a, **k: (calls.append(1), real(*a, **k))[1]
        try:
            core.render_stems(p, None, cache)
        finally:
            subprocess.run = real
        self.assertEqual(calls, [], "niezmieniony projekt nie powinien renderować niczego od nowa")


if __name__ == "__main__":
    unittest.main(verbosity=2)
