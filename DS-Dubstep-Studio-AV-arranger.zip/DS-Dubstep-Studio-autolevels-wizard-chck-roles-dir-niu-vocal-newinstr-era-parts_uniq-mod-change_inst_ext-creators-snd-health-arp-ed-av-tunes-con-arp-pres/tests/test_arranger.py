"""Testy Aranżera (barwy / extras / kreator / ad hoc / WYSIWYG) oraz dwóch poprawek, które odkrył:
 - extras_fx: 15 przepisów używało nazw parametrów, których wtyczki nie mają (host po cichu je pomijał),
 - geometry_editor: intensywność oceniana na stałym y=0.5 (figura poza środkiem pasa nic nie zmieniała),
   a efekt był jedną liczbą na tor, nie przebiegiem w czasie.

Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_arranger -v
Testy @needs_host wymagają zbudowanego hosta (`make`); test GUI dodatkowo PyQt6 (tryb offscreen).
"""
import copy
import json
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("DS_ADHOC_BANK", str(Path(tempfile.gettempdir()) / "ds_adhoc_bank_tests.json"))

from dubstep_studio import core  # noqa: E402


def _host_ok():
    try:
        core.meta()
        return True
    except Exception:
        return False


HOST = _host_ok()
needs_host = unittest.skipUnless(HOST, "brak zbudowanego hosta (uruchom `make`)")

ARR = dict(on=True, amount=0.9, adhoc_amount=0.5)
KW = dict(style="Brostep", bars=48, seed=11, director=dict(on=True, mood=-0.2))


def _gen(**kw):
    from dubstep_studio import generator as G
    a = dict(KW); a.update(kw)
    return G.generate(**a)


def _strip(p):
    return json.dumps({k: v for k, v in p.items() if k != "created"}, sort_keys=True, default=str)


class ExtrasParams(unittest.TestCase):
    @needs_host
    def test_all_recipes_resolve_to_existing_params(self):
        from dubstep_studio import extras_fx as FX
        m = core.meta()
        for name, spec in FX.EXTRAS.items():
            valid = m.plugins[core.PLUGIN_ID[spec["type"]]]["params"]
            fixed = FX.fix_params(spec["type"], spec["params"])
            self.assertTrue(fixed, name)
            self.assertTrue(set(fixed) <= set(valid), name)

    @needs_host
    def test_aliases_target_real_params(self):
        from dubstep_studio import extras_fx as FX
        m = core.meta()
        for t, ali in FX.PARAM_ALIASES.items():
            for src, dst in ali.items():
                if dst is not None:
                    self.assertIn(dst, m.plugins[core.PLUGIN_ID[t]]["params"], f"{t}:{src}->{dst}")

    @needs_host
    def test_spawn_extra_uses_fixed_params(self):
        from dubstep_studio import extras_fx as FX
        p = _gen()
        tr = FX.spawn_extra(p, "fx_tire_pebbles", 0, 4, random.Random(1))
        self.assertIn("Noise Decay", tr["params"])
        self.assertNotIn("Decay", tr["params"])


class Wysiwyg(unittest.TestCase):
    @needs_host
    def test_auto_layout_now_changes_every_track(self):
        from dubstep_studio import geometry_editor as GE
        p = _gen()
        rep = GE.apply_to_project(p, GE.auto_layout_tracks(p))
        with_notes = [t for t in p["tracks"] if t["notes"]]
        self.assertEqual(len(rep["intensity"]), len(with_notes))      # przed poprawką: 0

    @needs_host
    def test_reapply_is_idempotent(self):
        from dubstep_studio import geometry_editor as GE
        p = _gen(arranger=ARR)
        v = [[n[3] for n in t["notes"]] for t in p["tracks"]]
        a = copy.deepcopy([t["auto"] for t in p["tracks"]])
        for _ in range(3):
            GE.apply_to_project(p, p["geometry_doc"])
        self.assertEqual(v, [[n[3] for n in t["notes"]] for t in p["tracks"]])
        self.assertEqual(a, [t["auto"] for t in p["tracks"]])

    @needs_host
    def test_build_ramps_up_and_drop_peaks_early(self):
        p = _gen(arranger=dict(on=True, amount=0.0, adhoc_amount=0.0, use_extras=False, use_timbres=False, use_creator=False))
        tr = next(t for t in p["tracks"] if t["type"] in ("wobble", "reese", "growl", "neuro", "fmbass") and t["auto"].get("Cutoff"))
        pts = sorted(tr["auto"]["Cutoff"])
        val = lambda bar: max([v for b, v in pts if b <= bar * 4] or [pts[0][1]])
        builds = [s for s in p["sections"] if s["type"] == "build"]
        s = builds[0]
        self.assertGreater(val(s["start"] + s["bars"] - 1), val(s["start"]) + 0.05)


class ArrangerBehavior(unittest.TestCase):
    @needs_host
    def test_off_changes_nothing(self):
        base = _strip(_gen())
        self.assertEqual(base, _strip(_gen(arranger=None)))
        self.assertEqual(base, _strip(_gen(arranger=dict(on=False))))

    @needs_host
    def test_deterministic_and_independent_of_adhoc_registry(self):
        first = _strip(_gen(arranger=ARR))
        for _ in range(2):                              # rejestry ad hoc rosną między przebiegami
            self.assertEqual(first, _strip(_gen(arranger=ARR)))

    @needs_host
    def test_uses_resources_and_creates_new(self):
        p = _gen(arranger=dict(on=True, amount=1.0, adhoc_amount=1.0))
        r = p["arranger_report"]
        self.assertTrue(r["extras"] or r["timbres"])
        self.assertTrue(any(x["adhoc"] for x in r["timbres"] + r["extras"] + r["layers"]))
        self.assertTrue(p["adhoc"]["timbres"] or p["adhoc"]["extras"])
        self.assertGreater(len(p["geometry_doc"]["shapes"]), 0)
        self.assertTrue(r["creator"].get("extras") is not None)

    @needs_host
    def test_extras_placed_by_structure(self):
        from dubstep_studio import extras_fx as FX
        for seed in range(8):
            p = _gen(seed=seed, arranger=ARR)
            secs = p["sections"]
            for x in p["arranger_report"]["extras"]:
                cat, spec = x["category"], FX.EXTRAS.get(x["id"]) or {}
                for bar in x["at"]:
                    st = next(s for s in secs if s["start"] <= bar < s["start"] + s["bars"])
                    allowed = {"riser": ("build",), "impact": ("drop",), "texture": ("intro", "break", "outro"), "foley": ("break", "intro")}[cat]
                    self.assertIn(st["type"], allowed, (seed, x))

    @needs_host
    def test_locks_are_respected(self):
        from dubstep_studio import generator as G
        p = G.generate(**dict(KW, arranger=None))
        for t in p["tracks"]:
            t["lock_sound"] = True
        before = {t["name"]: dict(t["params"]) for t in p["tracks"]}
        from dubstep_studio import arranger as AR
        AR.apply(p, dict(on=True, amount=1.0, adhoc_amount=1.0, wysiwyg=False, use_extras=False), random.Random(3))
        orig = [t for t in p["tracks"] if t["name"] in before and not t.get("layer_of")]    # spawn porządkuje tory — po nazwach
        self.assertEqual(len(orig), len(before))
        for t in orig:
            self.assertEqual(before[t["name"]], t["params"], t["name"])
            self.assertFalse(t.get("timbre_id"), t["name"])

    @needs_host
    def test_fuzz_no_exceptions_ranges_and_valid_params(self):
        from dubstep_studio import generator as G
        m = core.meta()
        rng = random.Random(2026)
        styles = list(G.STYLES)
        for i in range(60):
            opts = dict(on=True, amount=rng.random(), adhoc_amount=rng.random(), wysiwyg=rng.random() < 0.8,
                        wysiwyg_strength=rng.random(), layers=rng.random() < 0.7, use_creator=rng.random() < 0.7,
                        contour=rng.random() < 0.3, max_extra_tracks=rng.randint(0, 6))
            p = G.generate(style=rng.choice(styles), bars=rng.choice([32, 48, 64]), seed=rng.randrange(10**6),
                           director=dict(on=rng.random() < 0.6, mood=rng.uniform(-1, 1)), arranger=opts)
            for t in p["tracks"]:
                valid = m.plugins[t["plugin"]]["params"]
                self.assertTrue(set(t["params"]) <= set(valid), (i, t["name"], set(t["params"]) - set(valid)))
                for n in t["notes"]:
                    self.assertTrue(0 <= n[2] <= 127 and 1 <= n[3] <= 127, (i, t["name"], n))
                    self.assertTrue(0 <= n[0] <= p["bars"] * 4 + 1e-6, (i, t["name"], n))
                for pts in t["auto"].values():
                    self.assertTrue(all(0.0 <= v <= 1.0 for _, v in pts), (i, t["name"]))
            self.assertLessEqual(len([t for t in p["tracks"] if t.get("extra_id")]), max(opts["max_extra_tracks"], 0) + 0)

    @needs_host
    def test_render_is_finite_and_new_tracks_audible(self):
        import numpy as np
        p = _gen(bars=24, arranger=dict(on=True, amount=1.0, adhoc_amount=0.5))
        st = core.render_stems(p)
        new = [t["name"] for t in p["tracks"] if t.get("extra_id") or t.get("layer_of")]
        self.assertTrue(new)
        for name, x in st.items():
            self.assertTrue(np.isfinite(x).all(), name)
        self.assertTrue(any(float(np.abs(st[n]).max()) > 1e-4 for n in new))


class BankAndWiring(unittest.TestCase):
    @needs_host
    def test_persist_and_restore(self):
        from dubstep_studio import arranger as AR, timbre_bank as TB, extras_fx as FX
        old = os.environ["DS_ADHOC_BANK"]
        with tempfile.TemporaryDirectory() as d:
            os.environ["DS_ADHOC_BANK"] = str(Path(d) / "bank.json")
            try:
                p = _gen(arranger=dict(on=True, amount=1.0, adhoc_amount=1.0, persist=True))
                self.assertTrue((Path(d) / "bank.json").exists())
                ids = list(p["adhoc"]["timbres"]) + list(p["adhoc"]["extras"])
                for i in ids:
                    TB.TIMBRES.pop(i, None); FX.EXTRAS.pop(i, None)
                self.assertEqual(AR.restore(p), len(ids))
                for i in ids:
                    self.assertTrue(i in TB.TIMBRES or i in FX.EXTRAS)
                for i in ids:
                    TB.TIMBRES.pop(i, None); FX.EXTRAS.pop(i, None)
                self.assertGreaterEqual(AR.load_bank(), len(ids))
            finally:
                os.environ["DS_ADHOC_BANK"] = old

    def test_registry_is_trimmed(self):
        from dubstep_studio import arranger as AR, timbre_bank as TB
        n0 = len([k for k, v in TB.TIMBRES.items() if v.get("adhoc")])
        for i in range(AR.MAX_ADHOC_REGISTRY + 30):
            AR._register("timbres", f"adhoc_t_{i}", dict(base="pad", params={}, tags=[], desc=""))
        self.assertLessEqual(len([k for k, v in TB.TIMBRES.items() if v.get("adhoc")]), AR.MAX_ADHOC_REGISTRY)
        for k in [k for k, v in TB.TIMBRES.items() if v.get("adhoc") and k.startswith("adhoc_t_")]:
            TB.TIMBRES.pop(k)
        self.assertGreaterEqual(n0, 0)

    def test_builtin_draws_ignore_adhoc(self):
        from dubstep_studio import arranger as AR, timbre_bank as TB, extras_fx as FX
        AR._register("timbres", "adhoc_x_1", dict(base="pad", params={}, tags=["pad", "bass", "lead"], desc=""))
        AR._register("extras", "fx_adhoc_x_1", dict(type="rim", params={}, pattern="ticks", gain=0.5, desc=""))
        try:
            self.assertNotIn("adhoc_x_1", TB.list_timbres("pad"))
            self.assertIn("adhoc_x_1", TB.list_timbres("pad", include_adhoc=True))
            for s in range(30):
                self.assertNotIn("fx_adhoc_x_1", FX.weighted_extras_for_style("Brostep", 6, random.Random(s))[0])
        finally:
            TB.TIMBRES.pop("adhoc_x_1", None); FX.EXTRAS.pop("fx_adhoc_x_1", None)

    def test_live_base_flag_reaches_generate_kwargs(self):
        from dubstep_studio import live as L
        out = L._gen_extras_from_base(dict(arranger=dict(on=True, amount=0.3)))
        self.assertEqual(out["arranger"]["amount"], 0.3)
        self.assertIsNone(L._gen_extras_from_base({}).get("arranger"))

    def test_config_roundtrip(self):
        from dubstep_studio import config as C
        txt = (ROOT / "config.txt").read_text(encoding="utf-8")
        self.assertIn("arranger = no", txt)
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "c.txt"
            f.write_text(txt.replace("arranger = no", "arranger = yes").replace("arranger_adhoc = 0.4", "arranger_adhoc = 0.9"), encoding="utf-8")
            b = C.to_base(C.load(str(f)))
            self.assertTrue(b["arranger"]["on"])
            self.assertAlmostEqual(b["arranger"]["adhoc_amount"], 0.9)
            f.write_text(txt, encoding="utf-8")
            self.assertIsNone(C.to_base(C.load(str(f)))["arranger"])


class GuiSmoke(unittest.TestCase):
    @needs_host
    def test_gui_generate_syncs_wysiwyg_tab(self):
        try:
            from PyQt6 import QtWidgets as W
        except Exception:
            self.skipTest("brak PyQt6")
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        app = W.QApplication.instance() or W.QApplication([])
        from dubstep_studio import gui
        win = gui.MainWindow()
        self.assertIsNone(win.arranger_cfg())
        win.arr_on.setChecked(True); win.rndseed.setChecked(False); win.seed.setValue(21)
        self.assertTrue(win.arranger_cfg()["on"])
        win.generate()
        self.assertTrue(win.proj.get("arranger_report"))
        self.assertEqual(len(win._geo_doc["shapes"]), len(win.proj["geometry_doc"]["shapes"]))


if __name__ == "__main__":
    unittest.main()
