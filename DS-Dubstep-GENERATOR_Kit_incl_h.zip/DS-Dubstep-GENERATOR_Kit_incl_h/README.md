# DS Dubstep Kit

Generator losowych aranżacji dubstep (8 ścieżek) + offline host CLAP (`dsrender`) + GUI PyQt6 + eksport MIDI/WAV/MP3 + autoremix.

Style: **Brostep**, **Riddim**, **Tearout**, **Melodic**, **Deep**.

## Struktura

```
DS-Dubstep-Kit/
├── run_gui.py          ← uruchom GUI
├── cli.py              ← interfejs wiersza poleceń
├── Makefile            ← buduje dsrender
├── dsrender.cpp        ← minimalny offline host CLAP
├── requirements.txt
├── ds/
│   ├── __init__.py
│   ├── core.py         ← model projektu, render, biblioteka
│   ├── generator.py    ← losowa aranżacja + sound design
│   └── gui.py          ← PyQt6 GUI
└── build/              ← tu ląduje dsrender i wtyczki .clap
```

## Wymagania

- Python ≥ 3.10 + `numpy` + `PyQt6`
- g++ (C++17)
- nagłówki [CLAP](https://github.com/free-audio/clap) (`clap/clap.h`)
- wtyczki CLAP: `DubstepKit.clap` lub `DS-*.clap` (zbuduj je osobno albo ustaw `DS_PLUGIN_DIR`)
- opcjonalnie: `ffmpeg` lub `lame` (eksport MP3)

```bash
pip install -r requirements.txt

# nagłówki CLAP (przykład)
git clone --depth 1 https://github.com/free-audio/clap.git /tmp/clap
export CLAP_INC=/tmp/clap/include
```

## Budowa

```bash
cd DS-Dubstep-Kit
make                    # → build/dsrender
# albo z własną ścieżką do nagłówków:
make CLAP_INC=/ścieżka/do/clap/include
```

Wtyczki CLAP umieść w `build/`, `~/.clap/` albo w katalogu z `DS_PLUGIN_DIR`.

## GUI (PyQt6)

```bash
python run_gui.py
# albo:
python -c "from ds import run_gui; run_gui()"
```

| Zakładka       | Funkcje |
|----------------|---------|
| **Generuj**    | styl, BPM, tonacja, energy/density, seed → GENERUJ TRACK |
| **Ścieżki**    | mixer (mute/solo/gain) + pokrętła parametrów 8 syntezatorów, przelosuj nuty/sound |
| **Linki**      | przekazywanie sygnałów między ścieżkami (kick→Level, energy→Cutoff …) |
| **Biblioteka** | lista tracków (MIDI+MP3+projekt), wczytaj / odtwórz / usuń |
| **Remix**      | autoremix: wybierz projekty, wskaż źródło każdej ścieżki → nowy track w bibliotece |

Dolny pasek: **Render → biblioteka** oraz **Eksport…** (WAV/MP3/MIDI/projekt).

## Użycie (CLI)

```bash
# generuj aranżację (tylko JSON podsumowania)
python cli.py generate --style Brostep --bars 64 --seed 42

# zapisz projekt
python cli.py generate --style Riddim --bars 96 -o moj_track.dsproj

# generuj + od razu renderuj do biblioteki (~/DubstepStudio/library/)
python cli.py generate --style Tearout --library

# lista utworów w bibliotece
python cli.py library

# renderuj istniejący projekt
python cli.py render moj_track.dsproj --mp3 --midi --stems
```

## Użycie jako pakiet

```python
from ds import generate, save_to_library, render_stems, mix_stems, write_wav

proj = generate(style="Melodic", bars=80, seed=123)
print(proj["name"], proj["bpm"], proj["bars"])

# pełny zapis (render + mp3 + midi)
save_to_library(proj)

# albo ręcznie:
stems = render_stems(proj)
mix = mix_stems(proj, stems)
write_wav("out.wav", mix)
```

## Zmienne środowiskowe

| Zmienna         | Znaczenie                                      |
|-----------------|------------------------------------------------|
| `DS_PLUGIN_DIR` | katalog z plikami `.clap`                      |
| `DS_LIBRARY`    | katalog biblioteki (domyślnie `~/DubstepStudio/library`) |

## Uwagi

- Relative import w `generator.py` (`from .core import …`) jest poprawny — uruchamiaj przez `cli.py` / `run_gui.py` lub `python -m ds.generator`.
- Bez zbudowanego `dsrender` i wtyczek CLAP funkcje `render_stems` / `save_to_library` rzucą wyjątek; sama generacja nut działa.
- To kod eksperymentalny.
