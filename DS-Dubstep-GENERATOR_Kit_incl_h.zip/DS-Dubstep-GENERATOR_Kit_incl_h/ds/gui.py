"""gui.py — PyQt6 GUI dla DS Dubstep Kit.

Zakładki:
  Generuj   — styl, BPM, tonacja, seed, generacja
  Ścieżki   — 8 tracków: mute/solo/gain + parametry syntezatorów
  Linki     — przekazywanie sygnałów (kick→Level, energy→Cutoff …)
  Biblioteka — lista wygenerowanych tracków (MIDI+MP3+projekt)
  Remix     — autoremix: wybór tracków i źródła każdej ścieżki
"""
from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QUrl
from PyQt6.QtGui import QFont, QAction, QColor, QPalette
from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QSpinBox, QDoubleSpinBox, QSlider,
    QTabWidget, QGroupBox, QScrollArea, QTableWidget, QTableWidgetItem,
    QHeaderView, QFileDialog, QMessageBox, QCheckBox, QLineEdit, QProgressBar,
    QSplitter, QFrame, QFormLayout, QListWidget, QListWidgetItem, QAbstractItemView,
    QSizePolicy, QStatusBar, QToolBar,
)

from .core import (
    TRACKS, MELODIC, SCALES, NOTE_NAMES, LINK_SOURCES, PLUGIN_ID,
    meta, new_project, track_of, key_name, section_at_bar,
    render_stems, mix_stems, write_wav, export_mp3, write_midi,
    save_project, load_project, save_to_library, list_library, delete_library_entry,
    lib_dir, DEFAULT_GAIN,
)
from .generator import STYLES, generate, reroll_track, randomize_sound, default_links


# ── kolory / styl ────────────────────────────────────────────────────────────
DARK = """
QMainWindow, QWidget { background: #1a1a22; color: #e0e0e8; font-size: 13px; }
QTabWidget::pane { border: 1px solid #333; background: #1e1e28; }
QTabBar::tab { background: #2a2a35; color: #aaa; padding: 8px 18px; margin-right: 2px; border-top-left-radius: 6px; border-top-right-radius: 6px; }
QTabBar::tab:selected { background: #3a3a4a; color: #fff; }
QGroupBox { border: 1px solid #3a3a4a; border-radius: 6px; margin-top: 12px; padding-top: 14px; font-weight: bold; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 6px; color: #8af; }
QPushButton { background: #3a3a55; color: #eee; border: none; border-radius: 5px; padding: 7px 14px; }
QPushButton:hover { background: #4a4a70; }
QPushButton:pressed { background: #2a2a40; }
QPushButton:disabled { background: #2a2a30; color: #666; }
QPushButton#generate { background: #4a2a8a; font-size: 15px; font-weight: bold; padding: 12px; }
QPushButton#generate:hover { background: #5a3aaa; }
QPushButton#danger { background: #6a2a2a; }
QPushButton#danger:hover { background: #8a3a3a; }
QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit {
    background: #2a2a35; color: #eee; border: 1px solid #444; border-radius: 4px; padding: 4px 8px;
}
QSlider::groove:horizontal { height: 6px; background: #333; border-radius: 3px; }
QSlider::handle:horizontal { width: 14px; margin: -5px 0; background: #8af; border-radius: 7px; }
QTableWidget { background: #1e1e28; gridline-color: #333; border: 1px solid #333; }
QHeaderView::section { background: #2a2a35; color: #aaa; padding: 6px; border: none; }
QProgressBar { border: 1px solid #444; border-radius: 4px; text-align: center; background: #222; }
QProgressBar::chunk { background: #5a3aaa; border-radius: 3px; }
QCheckBox { spacing: 6px; }
QStatusBar { background: #15151c; color: #888; }
QScrollArea { border: none; }
QListWidget { background: #1e1e28; border: 1px solid #333; }
QToolBar { background: #1a1a22; border: none; spacing: 6px; }
"""


# ── worker wątki ──────────────────────────────────────────────────────────────
class GenerateWorker(QThread):
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, kwargs):
        super().__init__()
        self.kwargs = kwargs

    def run(self):
        try:
            proj = generate(**self.kwargs)
            self.finished.emit(proj)
        except Exception as e:
            self.error.emit(f"{e}\n{traceback.format_exc()}")


class RenderWorker(QThread):
    progress = pyqtSignal(float)
    finished = pyqtSignal(object)  # Path katalogu biblioteki lub None
    error = pyqtSignal(str)

    def __init__(self, proj, to_library=True, with_stems=False, out_dir=None):
        super().__init__()
        self.proj = proj
        self.to_library = to_library
        self.with_stems = with_stems
        self.out_dir = out_dir

    def run(self):
        try:
            def prog(p):
                self.progress.emit(p)
            if self.to_library:
                d = save_to_library(self.proj, progress=prog, with_stems=self.with_stems)
                self.finished.emit(d)
            else:
                stems = render_stems(self.proj, progress=prog)
                mix = mix_stems(self.proj, stems)
                out = Path(self.out_dir or ".")
                out.mkdir(parents=True, exist_ok=True)
                wav = out / "track.wav"
                write_wav(wav, mix)
                export_mp3(wav, out / "track.mp3")
                write_midi(self.proj, out / "track.mid")
                save_project(self.proj, out / "project.dsproj")
                self.finished.emit(out)
        except Exception as e:
            self.error.emit(f"{e}\n{traceback.format_exc()}")


class RemixWorker(QThread):
    progress = pyqtSignal(float)
    finished = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, base_proj, stem_sources, name="remix"):
        """stem_sources: {track_name: project_dict} — skąd brać każdą ścieżkę."""
        super().__init__()
        self.base = base_proj
        self.sources = stem_sources
        self.name = name

    def run(self):
        try:
            # Złóż projekt: nuty + parametry z wybranych źródeł, reszta z base
            remix = json.loads(json.dumps(self.base))  # deep copy
            remix["name"] = self.name
            remix["parents"] = []
            for tname, src_proj in self.sources.items():
                src_t = track_of(src_proj, tname)
                dst_t = track_of(remix, tname)
                dst_t["notes"] = list(src_t["notes"])
                dst_t["params"] = dict(src_t["params"])
                dst_t["auto"] = {k: list(v) for k, v in src_t.get("auto", {}).items()}
                dst_t["gain"] = src_t.get("gain", dst_t["gain"])
                pid = src_proj.get("id") or src_proj.get("name", "?")
                if pid not in remix["parents"]:
                    remix["parents"].append(pid)

            def prog(p):
                self.progress.emit(p)
            d = save_to_library(remix, progress=prog)
            self.finished.emit(d)
        except Exception as e:
            self.error.emit(f"{e}\n{traceback.format_exc()}")


# ── helpery UI ────────────────────────────────────────────────────────────────
def hline():
    f = QFrame()
    f.setFrameShape(QFrame.Shape.HLine)
    f.setStyleSheet("color: #333;")
    return f


class ParamSlider(QWidget):
    """Slider 0..1 + etykieta wartości w jednostkach silnika."""
    changed = pyqtSignal(str, float)  # name, frac

    def __init__(self, track, name, frac, parent=None):
        super().__init__(parent)
        self.track = track
        self.name = name
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 2, 0, 2)
        self.lbl = QLabel(name)
        self.lbl.setMinimumWidth(130)
        self.lbl.setStyleSheet("color: #bbb; font-weight: normal;")
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 1000)
        self.slider.setValue(int(frac * 1000))
        self.val = QLabel()
        self.val.setMinimumWidth(70)
        self.val.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self.lbl)
        lay.addWidget(self.slider, 1)
        lay.addWidget(self.val)
        self.slider.valueChanged.connect(self._on)
        self._update_label(frac)

    def _on(self, v):
        f = v / 1000.0
        self._update_label(f)
        self.changed.emit(self.name, f)

    def _update_label(self, f):
        try:
            m = meta()
            self.val.setText(m.fmt(self.track, self.name, f))
        except Exception:
            self.val.setText(f"{f:.3f}")

    def set_frac(self, f):
        self.slider.blockSignals(True)
        self.slider.setValue(int(f * 1000))
        self.slider.blockSignals(False)
        self._update_label(f)


# ── główne okno ───────────────────────────────────────────────────────────────
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DS Dubstep Kit")
        self.resize(1100, 720)
        self.proj = None
        self._workers = []
        self._player = None
        self._audio = None

        self.setStyleSheet(DARK)
        self._build_ui()
        self.statusBar().showMessage("Gotowy — wygeneruj track lub wczytaj z biblioteki")

    # ── budowa UI ──
    def _build_ui(self):
        tb = QToolBar()
        tb.setMovable(False)
        self.addToolBar(tb)
        act_new = QAction("Nowy", self)
        act_new.triggered.connect(self._on_new)
        act_open = QAction("Otwórz…", self)
        act_open.triggered.connect(self._on_open)
        act_save = QAction("Zapisz…", self)
        act_save.triggered.connect(self._on_save)
        tb.addAction(act_new)
        tb.addAction(act_open)
        tb.addAction(act_save)
        tb.addSeparator()

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs)

        self.tabs.addTab(self._tab_generate(), "Generuj")
        self.tabs.addTab(self._tab_tracks(), "Ścieżki")
        self.tabs.addTab(self._tab_links(), "Linki")
        self.tabs.addTab(self._tab_library(), "Biblioteka")
        self.tabs.addTab(self._tab_remix(), "Remix")

        # pasek postępu + render
        bot = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFixedHeight(18)
        self.btn_render = QPushButton("Render → biblioteka")
        self.btn_render.clicked.connect(self._on_render)
        self.btn_export = QPushButton("Eksport…")
        self.btn_export.clicked.connect(self._on_export)
        bot.addWidget(self.progress, 1)
        bot.addWidget(self.btn_render)
        bot.addWidget(self.btn_export)
        root.addLayout(bot)

    # ── zakładka Generuj ──
    def _tab_generate(self):
        w = QWidget()
        lay = QVBoxLayout(w)

        form_box = QGroupBox("Parametry generacji")
        form = QFormLayout(form_box)

        self.cmb_style = QComboBox()
        self.cmb_style.addItems(list(STYLES.keys()))
        form.addRow("Styl", self.cmb_style)

        self.spin_bpm = QSpinBox()
        self.spin_bpm.setRange(60, 200)
        self.spin_bpm.setValue(140)
        form.addRow("BPM", self.spin_bpm)

        key_row = QHBoxLayout()
        self.cmb_key = QComboBox()
        self.cmb_key.addItems(NOTE_NAMES)
        self.cmb_key.setCurrentIndex(5)  # F / default z generatora często losowy
        self.cmb_scale = QComboBox()
        self.cmb_scale.addItems(list(SCALES.keys()))
        key_row.addWidget(self.cmb_key)
        key_row.addWidget(self.cmb_scale)
        form.addRow("Tonacja", key_row)

        self.spin_bars = QSpinBox()
        self.spin_bars.setRange(16, 256)
        self.spin_bars.setSingleStep(8)
        self.spin_bars.setValue(144)
        form.addRow("Takty", self.spin_bars)

        self.sld_energy = QSlider(Qt.Orientation.Horizontal)
        self.sld_energy.setRange(0, 100)
        self.sld_energy.setValue(70)
        self.lbl_energy = QLabel("0.70")
        er = QHBoxLayout()
        er.addWidget(self.sld_energy)
        er.addWidget(self.lbl_energy)
        self.sld_energy.valueChanged.connect(lambda v: self.lbl_energy.setText(f"{v/100:.2f}"))
        form.addRow("Energy", er)

        self.sld_density = QSlider(Qt.Orientation.Horizontal)
        self.sld_density.setRange(0, 100)
        self.sld_density.setValue(60)
        self.lbl_density = QLabel("0.60")
        dr = QHBoxLayout()
        dr.addWidget(self.sld_density)
        dr.addWidget(self.lbl_density)
        self.sld_density.valueChanged.connect(lambda v: self.lbl_density.setText(f"{v/100:.2f}"))
        form.addRow("Density", dr)

        self.spin_seed = QSpinBox()
        self.spin_seed.setRange(0, 999999)
        self.spin_seed.setSpecialValueText("losowy")
        self.spin_seed.setValue(0)
        form.addRow("Seed", self.spin_seed)

        self.edit_name = QLineEdit()
        self.edit_name.setPlaceholderText("auto (Styl-seed)")
        form.addRow("Nazwa", self.edit_name)

        lay.addWidget(form_box)

        self.btn_gen = QPushButton("GENERUJ TRACK")
        self.btn_gen.setObjectName("generate")
        self.btn_gen.clicked.connect(self._on_generate)
        lay.addWidget(self.btn_gen)

        # info o projekcie
        self.info_box = QGroupBox("Aktualny projekt")
        self.info_lbl = QLabel("— brak —")
        self.info_lbl.setWordWrap(True)
        self.info_lbl.setStyleSheet("font-weight: normal; color: #ccc;")
        il = QVBoxLayout(self.info_box)
        il.addWidget(self.info_lbl)
        lay.addWidget(self.info_box)
        lay.addStretch()
        return w

    # ── zakładka Ścieżki ──
    def _tab_tracks(self):
        w = QWidget()
        lay = QVBoxLayout(w)

        top = QHBoxLayout()
        self.cmb_track = QComboBox()
        self.cmb_track.addItems(TRACKS)
        self.cmb_track.currentTextChanged.connect(self._refresh_track_params)
        top.addWidget(QLabel("Ścieżka:"))
        top.addWidget(self.cmb_track)
        self.btn_reroll = QPushButton("Przelosuj nuty")
        self.btn_reroll.clicked.connect(self._on_reroll)
        self.btn_reroll_snd = QPushButton("Przelosuj sound")
        self.btn_reroll_snd.clicked.connect(lambda: self._on_reroll(sound=True))
        top.addWidget(self.btn_reroll)
        top.addWidget(self.btn_reroll_snd)
        top.addStretch()
        lay.addLayout(top)

        # mixer row
        mix_box = QGroupBox("Mixer")
        mix_lay = QHBoxLayout(mix_box)
        self.track_checks = {}
        self.track_gains = {}
        for t in TRACKS:
            col = QVBoxLayout()
            col.addWidget(QLabel(t.capitalize()), alignment=Qt.AlignmentFlag.AlignCenter)
            mute = QCheckBox("M")
            solo = QCheckBox("S")
            gain = QSlider(Qt.Orientation.Vertical)
            gain.setRange(0, 150)
            gain.setValue(int(DEFAULT_GAIN.get(t, 1.0) * 100))
            gain.setFixedHeight(80)
            self.track_checks[t] = (mute, solo)
            self.track_gains[t] = gain
            mute.stateChanged.connect(lambda _s, n=t: self._on_mixer_change(n))
            solo.stateChanged.connect(lambda _s, n=t: self._on_mixer_change(n))
            gain.valueChanged.connect(lambda _v, n=t: self._on_mixer_change(n))
            col.addWidget(mute, alignment=Qt.AlignmentFlag.AlignCenter)
            col.addWidget(solo, alignment=Qt.AlignmentFlag.AlignCenter)
            col.addWidget(gain, alignment=Qt.AlignmentFlag.AlignCenter)
            mix_lay.addLayout(col)
        lay.addWidget(mix_box)

        # parametry wybranej ścieżki
        self.params_box = QGroupBox("Parametry syntezatora")
        self.params_scroll = QScrollArea()
        self.params_scroll.setWidgetResizable(True)
        self.params_inner = QWidget()
        self.params_lay = QVBoxLayout(self.params_inner)
        self.params_scroll.setWidget(self.params_inner)
        pl = QVBoxLayout(self.params_box)
        pl.addWidget(self.params_scroll)
        lay.addWidget(self.params_box, 1)
        return w

    # ── zakładka Linki ──
    def _tab_links(self):
        w = QWidget()
        lay = QVBoxLayout(w)

        self.links_table = QTableWidget(0, 5)
        self.links_table.setHorizontalHeaderLabels(["Źródło", "Cel", "Parametr", "Amount", "Release"])
        self.links_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.links_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        lay.addWidget(self.links_table)

        row = QHBoxLayout()
        self.link_src = QComboBox()
        self.link_src.addItems(LINK_SOURCES)
        self.link_dst = QComboBox()
        self.link_dst.addItems(TRACKS)
        self.link_param = QLineEdit()
        self.link_param.setPlaceholderText("np. Level, Cutoff, Drive")
        self.link_amount = QDoubleSpinBox()
        self.link_amount.setRange(-1.0, 1.0)
        self.link_amount.setSingleStep(0.05)
        self.link_amount.setValue(0.3)
        self.link_rel = QDoubleSpinBox()
        self.link_rel.setRange(0.05, 4.0)
        self.link_rel.setValue(0.5)
        self.link_rel.setSingleStep(0.1)
        for lbl, wdg in [("Src", self.link_src), ("Dst", self.link_dst),
                         ("Param", self.link_param), ("Amt", self.link_amount), ("Rel", self.link_rel)]:
            row.addWidget(QLabel(lbl))
            row.addWidget(wdg)
        btn_add = QPushButton("Dodaj")
        btn_add.clicked.connect(self._on_add_link)
        btn_del = QPushButton("Usuń zaznaczone")
        btn_del.setObjectName("danger")
        btn_del.clicked.connect(self._on_del_link)
        btn_def = QPushButton("Domyślne linki stylu")
        btn_def.clicked.connect(self._on_default_links)
        row.addWidget(btn_add)
        row.addWidget(btn_del)
        row.addWidget(btn_def)
        lay.addLayout(row)
        return w

    # ── zakładka Biblioteka ──
    def _tab_library(self):
        w = QWidget()
        lay = QVBoxLayout(w)

        top = QHBoxLayout()
        btn_ref = QPushButton("Odśwież")
        btn_ref.clicked.connect(self._refresh_library)
        btn_load = QPushButton("Wczytaj")
        btn_load.clicked.connect(self._on_lib_load)
        btn_play = QPushButton("▶ Odtwórz")
        btn_play.clicked.connect(self._on_lib_play)
        btn_del = QPushButton("Usuń")
        btn_del.setObjectName("danger")
        btn_del.clicked.connect(self._on_lib_delete)
        top.addWidget(btn_ref)
        top.addWidget(btn_load)
        top.addWidget(btn_play)
        top.addWidget(btn_del)
        top.addStretch()
        self.lbl_lib_path = QLabel(str(lib_dir()))
        self.lbl_lib_path.setStyleSheet("color: #666; font-size: 11px;")
        top.addWidget(self.lbl_lib_path)
        lay.addLayout(top)

        self.lib_table = QTableWidget(0, 7)
        self.lib_table.setHorizontalHeaderLabels(
            ["Utworzono", "Nazwa", "Styl", "BPM", "Tonacja", "Takty", "Audio"]
        )
        self.lib_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.lib_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.lib_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.lib_table.doubleClicked.connect(self._on_lib_load)
        lay.addWidget(self.lib_table)
        return w

    # ── zakładka Remix ──
    def _tab_remix(self):
        w = QWidget()
        lay = QVBoxLayout(w)

        info = QLabel(
            "Wybierz projekty-źródła z biblioteki, potem dla każdej ścieżki wskaż, "
            "z którego projektu ma pochodzić. Base = struktura sekcji/BPM/tonacja z pierwszego źródła."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #aaa; font-weight: normal;")
        lay.addWidget(info)

        split = QSplitter(Qt.Orientation.Horizontal)

        # lewa: lista projektów do wyboru
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.addWidget(QLabel("Projekty źródłowe (zaznacz 2+)"))
        self.remix_list = QListWidget()
        self.remix_list.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
        ll.addWidget(self.remix_list)
        btn_rref = QPushButton("Odśwież listę")
        btn_rref.clicked.connect(self._refresh_remix_list)
        ll.addWidget(btn_rref)
        split.addWidget(left)

        # prawa: mapowanie ścieżka → źródło
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.addWidget(QLabel("Źródło dla każdej ścieżki"))
        self.remix_map = {}
        grid = QGridLayout()
        for i, t in enumerate(TRACKS):
            grid.addWidget(QLabel(t.capitalize()), i, 0)
            cmb = QComboBox()
            self.remix_map[t] = cmb
            grid.addWidget(cmb, i, 1)
        rl.addLayout(grid)
        self.remix_name = QLineEdit("remix")
        rl.addWidget(QLabel("Nazwa remixu"))
        rl.addWidget(self.remix_name)
        self.btn_remix = QPushButton("Wykonaj remix → biblioteka")
        self.btn_remix.setObjectName("generate")
        self.btn_remix.clicked.connect(self._on_remix)
        rl.addWidget(self.btn_remix)
        rl.addStretch()
        split.addWidget(right)

        split.setSizes([400, 400])
        lay.addWidget(split)

        self.remix_list.itemSelectionChanged.connect(self._on_remix_sel)
        return w

    # ── logika: generacja ──
    def _on_generate(self):
        kwargs = dict(
            style=self.cmb_style.currentText(),
            bpm=self.spin_bpm.value(),
            key=self.cmb_key.currentIndex(),
            scale=self.cmb_scale.currentText(),
            bars=self.spin_bars.value(),
            energy=self.sld_energy.value() / 100.0,
            density=self.sld_density.value() / 100.0,
            seed=self.spin_seed.value() or None,
            name=self.edit_name.text().strip() or None,
        )
        self.btn_gen.setEnabled(False)
        self.statusBar().showMessage("Generuję…")
        w = GenerateWorker(kwargs)
        w.finished.connect(self._on_gen_done)
        w.error.connect(self._on_worker_error)
        w.finished.connect(lambda _: self.btn_gen.setEnabled(True))
        w.error.connect(lambda _: self.btn_gen.setEnabled(True))
        self._workers.append(w)
        w.start()

    def _on_gen_done(self, proj):
        self.proj = proj
        self._sync_ui_from_proj()
        self.statusBar().showMessage(
            f"Wygenerowano: {proj['name']}  |  {proj['bars']} taków  |  seed={proj['seed']}"
        )
        self.tabs.setCurrentIndex(1)

    # ── logika: projekt ↔ UI ──
    def _sync_ui_from_proj(self):
        if not self.proj:
            self.info_lbl.setText("— brak —")
            return
        p = self.proj
        secs = ", ".join(f"{s['name']}({s['bars']})" for s in p["sections"])
        note_counts = {t["name"]: len(t["notes"]) for t in p["tracks"]}
        self.info_lbl.setText(
            f"<b>{p['name']}</b><br>"
            f"Styl: {p['style']}  ·  BPM: {p['bpm']}  ·  {key_name(p)}  ·  "
            f"{p['bars']} taków  ·  seed={p['seed']}<br>"
            f"Energy={p['energy']}  Density={p['density']}  Swing={p['swing']}<br>"
            f"Sekcje: {secs}<br>"
            f"Nuty: {note_counts}"
        )
        # mixer
        for t in p["tracks"]:
            mute, solo = self.track_checks[t["name"]]
            mute.blockSignals(True)
            solo.blockSignals(True)
            mute.setChecked(t.get("mute", False))
            solo.setChecked(t.get("solo", False))
            mute.blockSignals(False)
            solo.blockSignals(False)
            g = self.track_gains[t["name"]]
            g.blockSignals(True)
            g.setValue(int(t.get("gain", 1.0) * 100))
            g.blockSignals(False)
        self._refresh_track_params()
        self._refresh_links_table()

    def _refresh_track_params(self):
        # wyczyść
        while self.params_lay.count():
            item = self.params_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if not self.proj:
            return
        tname = self.cmb_track.currentText()
        t = track_of(self.proj, tname)
        try:
            m = meta()
            pm = m.plugins[PLUGIN_ID[tname]]["params"]
            names = sorted(pm.keys())
        except Exception:
            names = sorted(t.get("params", {}).keys())
            pm = {}

        if not names and not t.get("params"):
            self.params_lay.addWidget(QLabel("(brak parametrów — załaduj wtyczki CLAP)"))
            self.params_lay.addStretch()
            return

        # pokaż parametry które są w projekcie lub w pluginie
        shown = set(t.get("params", {}).keys()) | set(names)
        for name in sorted(shown):
            frac = t["params"].get(name)
            if frac is None:
                try:
                    frac = meta().def_frac(tname, name)
                except Exception:
                    frac = 0.5
            sld = ParamSlider(tname, name, frac)
            sld.changed.connect(self._on_param_change)
            self.params_lay.addWidget(sld)
        self.params_lay.addStretch()

    def _on_param_change(self, name, frac):
        if not self.proj:
            return
        tname = self.cmb_track.currentText()
        track_of(self.proj, tname)["params"][name] = frac

    def _on_mixer_change(self, tname):
        if not self.proj:
            return
        t = track_of(self.proj, tname)
        mute, solo = self.track_checks[tname]
        t["mute"] = mute.isChecked()
        t["solo"] = solo.isChecked()
        t["gain"] = self.track_gains[tname].value() / 100.0

    def _on_reroll(self, sound=False):
        if not self.proj:
            return
        tname = self.cmb_track.currentText()
        try:
            reroll_track(self.proj, tname, sound=sound)
            self._sync_ui_from_proj()
            self.statusBar().showMessage(f"Przelosowano: {tname}" + (" + sound" if sound else ""))
        except Exception as e:
            QMessageBox.warning(self, "Błąd", str(e))

    # ── linki ──
    def _refresh_links_table(self):
        self.links_table.setRowCount(0)
        if not self.proj:
            return
        for L in self.proj.get("links", []):
            r = self.links_table.rowCount()
            self.links_table.insertRow(r)
            self.links_table.setItem(r, 0, QTableWidgetItem(L["src"]))
            self.links_table.setItem(r, 1, QTableWidgetItem(L["dst"]))
            self.links_table.setItem(r, 2, QTableWidgetItem(L["param"]))
            self.links_table.setItem(r, 3, QTableWidgetItem(f"{L['amount']:.2f}"))
            self.links_table.setItem(r, 4, QTableWidgetItem(f"{L.get('rel', 0.5):.2f}"))

    def _on_add_link(self):
        if not self.proj:
            return
        param = self.link_param.text().strip()
        if not param:
            QMessageBox.information(self, "Link", "Podaj nazwę parametru.")
            return
        L = {
            "src": self.link_src.currentText(),
            "dst": self.link_dst.currentText(),
            "param": param,
            "amount": self.link_amount.value(),
            "rel": self.link_rel.value(),
        }
        self.proj.setdefault("links", []).append(L)
        self._refresh_links_table()

    def _on_del_link(self):
        if not self.proj:
            return
        rows = sorted({i.row() for i in self.links_table.selectedIndexes()}, reverse=True)
        links = self.proj.get("links", [])
        for r in rows:
            if 0 <= r < len(links):
                links.pop(r)
        self._refresh_links_table()

    def _on_default_links(self):
        if not self.proj:
            return
        self.proj["links"] = default_links(self.proj["style"])
        self._refresh_links_table()
        self.statusBar().showMessage("Przywrócono domyślne linki stylu")

    # ── render / eksport ──
    def _on_render(self):
        if not self.proj:
            QMessageBox.information(self, "Render", "Najpierw wygeneruj lub wczytaj projekt.")
            return
        self.btn_render.setEnabled(False)
        self.progress.setValue(0)
        self.statusBar().showMessage("Renderuję do biblioteki…")
        w = RenderWorker(self.proj, to_library=True)
        w.progress.connect(lambda p: self.progress.setValue(int(p * 100)))
        w.finished.connect(self._on_render_done)
        w.error.connect(self._on_worker_error)
        w.finished.connect(lambda _: self.btn_render.setEnabled(True))
        w.error.connect(lambda _: self.btn_render.setEnabled(True))
        self._workers.append(w)
        w.start()

    def _on_render_done(self, path):
        self.progress.setValue(100)
        self.statusBar().showMessage(f"Zapisano: {path}")
        self._refresh_library()
        self._refresh_remix_list()
        QMessageBox.information(self, "Gotowe", f"Zapisano do biblioteki:\n{path}")

    def _on_export(self):
        if not self.proj:
            return
        d = QFileDialog.getExistingDirectory(self, "Katalog eksportu")
        if not d:
            return
        self.btn_export.setEnabled(False)
        self.progress.setValue(0)
        w = RenderWorker(self.proj, to_library=False, out_dir=d)
        w.progress.connect(lambda p: self.progress.setValue(int(p * 100)))
        w.finished.connect(lambda p: (
            self.progress.setValue(100),
            self.btn_export.setEnabled(True),
            self.statusBar().showMessage(f"Eksport: {p}"),
            QMessageBox.information(self, "Eksport", f"Zapisano w:\n{p}"),
        ))
        w.error.connect(self._on_worker_error)
        w.error.connect(lambda _: self.btn_export.setEnabled(True))
        self._workers.append(w)
        w.start()

    # ── biblioteka ──
    def _refresh_library(self):
        self.lib_table.setRowCount(0)
        try:
            entries = list_library()
        except Exception as e:
            self.statusBar().showMessage(f"Biblioteka: {e}")
            return
        self._lib_entries = entries
        for e in entries:
            r = self.lib_table.rowCount()
            self.lib_table.insertRow(r)
            audio = e["audio"].name if e["audio"] else "—"
            vals = [e["created"], e["name"], e["style"], str(e["bpm"]),
                    e["key"], str(e["bars"]), audio]
            for c, v in enumerate(vals):
                self.lib_table.setItem(r, c, QTableWidgetItem(v))

    def _selected_lib_entry(self):
        rows = self.lib_table.selectionModel().selectedRows()
        if not rows or not hasattr(self, "_lib_entries"):
            return None
        return self._lib_entries[rows[0].row()]

    def _on_lib_load(self):
        e = self._selected_lib_entry()
        if not e:
            return
        try:
            self.proj = load_project(e["path"])
            self._sync_ui_from_proj()
            self.statusBar().showMessage(f"Wczytano: {e['name']}")
            self.tabs.setCurrentIndex(1)
        except Exception as ex:
            QMessageBox.warning(self, "Błąd", str(ex))

    def _on_lib_play(self):
        e = self._selected_lib_entry()
        if not e or not e["audio"]:
            QMessageBox.information(self, "Odtwarzanie", "Brak pliku audio.")
            return
        try:
            if self._player is None:
                self._player = QMediaPlayer()
                self._audio = QAudioOutput()
                self._player.setAudioOutput(self._audio)
                self._audio.setVolume(0.8)
            self._player.setSource(QUrl.fromLocalFile(str(e["audio"])))
            self._player.play()
            self.statusBar().showMessage(f"▶ {e['name']}")
        except Exception as ex:
            QMessageBox.warning(self, "Odtwarzanie", f"Nie można odtworzyć:\n{ex}")

    def _on_lib_delete(self):
        e = self._selected_lib_entry()
        if not e:
            return
        if QMessageBox.question(self, "Usuń", f"Usunąć „{e['name']}”?") != QMessageBox.StandardButton.Yes:
            return
        delete_library_entry(e["path"])
        self._refresh_library()
        self._refresh_remix_list()

    # ── remix ──
    def _refresh_remix_list(self):
        self.remix_list.clear()
        self._remix_entries = []
        try:
            entries = list_library()
        except Exception:
            return
        self._remix_entries = entries
        for e in entries:
            item = QListWidgetItem(f"{e['name']}  ({e['style']}, {e['bpm']} bpm, {e['created']})")
            item.setData(Qt.ItemDataRole.UserRole, e)
            self.remix_list.addItem(item)

    def _on_remix_sel(self):
        selected = self.remix_list.selectedItems()
        names = []
        self._remix_projs = {}
        for it in selected:
            e = it.data(Qt.ItemDataRole.UserRole)
            try:
                p = load_project(e["path"])
                label = e["name"]
                self._remix_projs[label] = p
                names.append(label)
            except Exception:
                pass
        for t, cmb in self.remix_map.items():
            cmb.clear()
            cmb.addItems(names)

    def _on_remix(self):
        if not getattr(self, "_remix_projs", None) or len(self._remix_projs) < 1:
            QMessageBox.information(self, "Remix", "Zaznacz co najmniej jeden projekt źródłowy.")
            return
        # base = pierwszy zaznaczony
        first_label = next(iter(self._remix_projs))
        base = self._remix_projs[first_label]
        sources = {}
        for t, cmb in self.remix_map.items():
            label = cmb.currentText()
            if label and label in self._remix_projs:
                sources[t] = self._remix_projs[label]
            else:
                sources[t] = base
        name = self.remix_name.text().strip() or "remix"
        self.btn_remix.setEnabled(False)
        self.progress.setValue(0)
        self.statusBar().showMessage("Remixuję…")
        w = RemixWorker(base, sources, name=name)
        w.progress.connect(lambda p: self.progress.setValue(int(p * 100)))
        w.finished.connect(self._on_render_done)
        w.error.connect(self._on_worker_error)
        w.finished.connect(lambda _: self.btn_remix.setEnabled(True))
        w.error.connect(lambda _: self.btn_remix.setEnabled(True))
        self._workers.append(w)
        w.start()

    # ── pliki ──
    def _on_new(self):
        self.proj = None
        self._sync_ui_from_proj()
        self.statusBar().showMessage("Nowy projekt")

    def _on_open(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Otwórz projekt", str(lib_dir()), "DS Project (*.dsproj);;All (*)"
        )
        if not path:
            return
        try:
            self.proj = load_project(path)
            self._sync_ui_from_proj()
            self.statusBar().showMessage(f"Wczytano: {path}")
        except Exception as e:
            QMessageBox.warning(self, "Błąd", str(e))

    def _on_save(self):
        if not self.proj:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Zapisz projekt", f"{self.proj['name']}.dsproj", "DS Project (*.dsproj)"
        )
        if not path:
            return
        save_project(self.proj, path)
        self.statusBar().showMessage(f"Zapisano: {path}")

    def _on_worker_error(self, msg):
        self.statusBar().showMessage("Błąd")
        QMessageBox.critical(self, "Błąd", msg)

    def showEvent(self, ev):
        super().showEvent(ev)
        self._refresh_library()
        self._refresh_remix_list()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("DS Dubstep Kit")
    app.setStyle("Fusion")
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
