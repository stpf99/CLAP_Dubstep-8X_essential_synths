"""DS Dubstep Kit — generator aranżacji dubstep + host CLAP (dsrender)."""

from .core import (
    TRACKS,
    MELODIC,
    SCALES,
    meta,
    new_project,
    track_of,
    key_name,
    render_stems,
    mix_stems,
    write_wav,
    export_mp3,
    write_midi,
    save_project,
    load_project,
    save_to_library,
    list_library,
    delete_library_entry,
    lib_dir,
)
from .generator import generate, reroll_track, STYLES

__all__ = [
    "TRACKS",
    "MELODIC",
    "SCALES",
    "STYLES",
    "meta",
    "new_project",
    "track_of",
    "key_name",
    "generate",
    "reroll_track",
    "render_stems",
    "mix_stems",
    "write_wav",
    "export_mp3",
    "write_midi",
    "save_project",
    "load_project",
    "save_to_library",
    "list_library",
    "delete_library_entry",
    "lib_dir",
    "run_gui",
]

__version__ = "0.1.0"


def run_gui():
    """Uruchom interfejs PyQt6."""
    from .gui import main
    main()
