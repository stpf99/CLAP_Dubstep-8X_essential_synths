"""core.py — model projektu, hostowanie wtyczek CLAP (przez dsrender), automatyzacja z linków,
render/mix, eksport MIDI/MP3 i biblioteka."""
from __future__ import annotations

import concurrent.futures as cf
import datetime
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np

APP_DIR = Path(__file__).resolve().parent.parent
TRACKS = ["kick", "snare", "hat", "sub", "wobble", "reese", "growl", "screech"]
MELODIC = ["sub", "wobble", "reese", "growl", "screech"]
PLUGIN_ID = {t: f"stpf99.dubstep.{t}" for t in TRACKS}
DEFAULT_GAIN = dict(kick=1.0, snare=0.9, hat=0.65, sub=1.0, wobble=0.9, reese=0.7, growl=0.8, screech=0.7)
SR = 48000
RES = 0.125  # rozdzielczość automatyzacji (beaty) = 1/32 nuty
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
SCALES = {"minor": [0, 2, 3, 5, 7, 8, 10], "phrygian": [0, 1, 3, 5, 7, 8, 10], "harmonic minor": [0, 2, 3, 5, 7, 8, 11]}
LINK_SOURCES = ["kick", "snare", "hat", "energy", "build", "bar_phase", "bass_note"]


# ------------------------------------------------------------------ meta wtyczek
def _num(txt):
    m = re.match(r"\s*(-?\d+(?:\.\d+)?)\s*(.*)$", txt)
    return (float(m.group(1)), m.group(2).strip()) if m else (None, "")


class Meta:
    """Odkrywa pliki .clap, wywołuje `dsrender --dump`, wylicza typy parametrów."""

    def __init__(self):
        self.render = self._find_render()
        self.plugins = {}
        for f in self._clap_files():
            try:
                out = subprocess.run([self.render, "--dump", str(f)], capture_output=True, text=True, timeout=30)
                for pl in json.loads(out.stdout):
                    if pl["id"] in self.plugins:
                        continue
                    pl["file"] = str(f)
                    pl["params"] = {p["name"]: self._mk(p) for p in pl["params"]}
                    self.plugins[pl["id"]] = pl
            except Exception:
                continue
        missing = [t for t in TRACKS if PLUGIN_ID[t] not in self.plugins]
        if missing:
            raise RuntimeError(f"Brak wtyczek CLAP: {missing}. Zbuduj je (make) lub ustaw DS_PLUGIN_DIR.")

    @staticmethod
    def _find_render():
        for c in [APP_DIR / "build" / "dsrender", shutil.which("dsrender")]:
            if c and Path(c).exists():
                return str(c)
        raise RuntimeError("Nie znaleziono build/dsrender — uruchom `make` w katalogu projektu.")

    @staticmethod
    def _clap_files():
        dirs = [Path(os.environ["DS_PLUGIN_DIR"])] if os.environ.get("DS_PLUGIN_DIR") else []
        dirs += [APP_DIR / "build", Path.home() / ".clap"]
        out = []
        for d in dirs:
            if (d / "DubstepKit.clap").exists():
                out.append(d / "DubstepKit.clap")
            out += sorted(d.glob("DS-*.clap"))
        return out

    @staticmethod
    def _mk(p):
        lo_t, unit = _num(p["tmin"]); hi_t, unit2 = _num(p["tmax"])
        unit = unit2 or unit
        if p["stepped"]:
            kind, lo, hi = "int", p["min"], p["max"]
        elif p["min"] == 0 and p["max"] == 1 and unit:
            kind, lo, hi = "log", lo_t, hi_t
        else:
            kind, lo, hi = "lin", p["min"], p["max"]
        p.update(kind=kind, lo=lo, hi=hi, unit=unit)
        return p

    def has(self, track, name):
        return name in self.plugins[PLUGIN_ID[track]]["params"]

    def param(self, track, name):
        return self.plugins[PLUGIN_ID[track]]["params"][name]

    # eng <-> frac(0..1 zakresu CLAP) <-> clap
    def eng2frac(self, track, name, e):
        p = self.param(track, name)
        if p["kind"] == "log":
            c = math.log(max(p["lo"], min(p["hi"], e)) / p["lo"]) / math.log(p["hi"] / p["lo"])
        else:
            c = max(p["min"], min(p["max"], e))
        return (c - p["min"]) / (p["max"] - p["min"])

    def frac2clap(self, track, name, f):
        p = self.param(track, name)
        v = p["min"] + max(0.0, min(1.0, f)) * (p["max"] - p["min"])
        return round(v) if p["stepped"] else v

    def frac2eng(self, track, name, f):
        p = self.param(track, name)
        if p["kind"] == "log":
            return p["lo"] * (p["hi"] / p["lo"]) ** f
        v = p["min"] + f * (p["max"] - p["min"])
        return round(v) if p["kind"] == "int" else v

    def def_frac(self, track, name):
        p = self.param(track, name)
        return (p["def"] - p["min"]) / (p["max"] - p["min"])

    def fmt(self, track, name, f):
        p = self.param(track, name)
        e = self.frac2eng(track, name, f)
        if p["texts"]:
            return p["texts"][int(round(e - p["min"]))]
        if p["kind"] == "int":
            return str(int(e))
        s = f"{e:.2f}" if abs(e) < 10 else (f"{e:.1f}" if abs(e) < 1000 else f"{e:.0f}")
        return f"{s} {p['unit']}".strip()


_META = None


def meta() -> Meta:
    global _META
    if _META is None:
        _META = Meta()
    return _META


# ------------------------------------------------------------------ projekt
def new_track(name):
    return {"name": name, "plugin": PLUGIN_ID[name], "params": {}, "notes": [], "auto": {},
            "gain": DEFAULT_GAIN[name], "mute": False, "solo": False}


def new_project(**kw):
    p = {"version": 1, "name": "untitled", "bpm": 140, "style": "Brostep", "key": 5, "scale": "minor",
         "bars": 0, "seed": 0, "swing": 0.0, "energy": 0.7, "density": 0.6, "sections": [], "chords": [],
         "tracks": [new_track(t) for t in TRACKS], "links": [], "parents": [], "created": ""}
    p.update(kw)
    return p


def track_of(proj, name):
    return next(t for t in proj["tracks"] if t["name"] == name)


def key_name(proj):
    return f"{NOTE_NAMES[proj['key'] % 12]} {proj['scale']}"


def section_at_bar(proj, bar):
    for s in proj["sections"]:
        if s["start"] <= bar < s["start"] + s["bars"]:
            return s
    return proj["sections"][-1]


# ------------------------------------------------------------------ sygnały i automatyzacja z linków
def _hits(proj, tname, n):
    h = np.zeros(n)
    for on, dur, key, vel in track_of(proj, tname)["notes"]:
        i = int(round(on / RES))
        if 0 <= i < n:
            h[i] = max(h[i], vel / 127.0)
    return h


def _follow(h, rel):
    out = np.zeros_like(h); k = math.exp(-RES / max(rel, 1e-3)); v = 0.0
    for i, x in enumerate(h):
        v = max(x, v * k)
        out[i] = v
    return out


def signal(proj, src, n, rel=0.5):
    if src in ("kick", "snare", "hat"):
        return _follow(_hits(proj, src, n), rel)
    t = np.arange(n) * RES
    if src == "bar_phase":
        return (t / 4.0) % 1.0
    out = np.zeros(n)
    if src in ("energy", "build"):
        for s in proj["sections"]:
            a, b = int(s["start"] * 4 / RES), int((s["start"] + s["bars"]) * 4 / RES)
            if src == "energy":
                ramp = np.linspace(s["e0"], s["e1"], b - a, endpoint=False)
            else:
                ramp = np.linspace(0, 1, b - a, endpoint=False) if s["type"] == "build" else np.zeros(b - a)
            b2 = min(b, n)
            out[a:b2] = ramp[: b2 - a]
        return out
    if src == "bass_note":
        cur, notes, j = 0.5, sorted(track_of(proj, "sub")["notes"]), 0
        for i in range(n):
            while j < len(notes) and notes[j][0] <= i * RES + 1e-6:
                cur = min(1.0, max(0.0, (notes[j][2] - 24) / 12.0)); j += 1
            out[i] = cur
        return out
    return out


def build_automation(proj, m: Meta):
    """-> {track_index: {param_name: [(beat, frac), ...]}} (kolejne wartości stałe)."""
    n = int(proj["bars"] * 4 / RES) + 1
    lanes = {}
    for i, t in enumerate(proj["tracks"]):
        pm = m.plugins[t["plugin"]]["params"]
        lanes[i] = {}
        for name, pts in t["auto"].items():
            if name in pm:
                lanes[i][name] = [(b, f) for b, f in sorted(pts)]
    # kontrybucje linków
    contrib = {}
    for L in proj["links"]:
        if L["dst"] not in [t["name"] for t in proj["tracks"]]:
            continue
        if not m.has(L["dst"], L["param"]) or m.param(L["dst"], L["param"])["kind"] == "int":
            continue
        sig = signal(proj, L["src"], n, L.get("rel", 0.5)) * L["amount"]
        contrib.setdefault((L["dst"], L["param"]), np.zeros(n))
        contrib[(L["dst"], L["param"])] += sig
    for (dst, name), arr in contrib.items():
        i = next(k for k, t in enumerate(proj["tracks"]) if t["name"] == dst)
        t = proj["tracks"][i]
        base = np.full(n, t["params"].get(name, m.def_frac(dst, name)))
        if name in lanes[i]:  # jawna automatyzacja jako baza (krokowa)
            pts, k, cur = lanes[i][name], 0, base[0]
            for j in range(n):
                while k < len(pts) and pts[k][0] <= j * RES + 1e-6:
                    cur = pts[k][1]; k += 1
                base[j] = cur
        val = np.clip(base + arr, 0.0, 1.0)
        out, last = [], None
        for j in range(n):
            if last is None or abs(val[j] - last) > 0.003:
                out.append((j * RES, float(val[j]))); last = val[j]
        lanes[i][name] = out
    return lanes


# ------------------------------------------------------------------ render
def _write_job(path, outp, proj, t, lanes, m):
    pl = m.plugins[t["plugin"]]; pm = pl["params"]; bpm = proj["bpm"]
    sec = lambda b: b * 60.0 / bpm
    L = [f"sr {SR}", f"bpm {bpm}", f"len {sec(proj['bars'] * 4):.4f}", "tail 3.0", f"plugin {pl['file']} {pl['id']}", f"out {outp}"]
    for name, f in t["params"].items():
        if name in pm:
            L.append(f"p {pm[name]['id']} {m.frac2clap(t['name'], name, f):.8g}")
    for name, pts in lanes.items():
        for b, f in pts:
            L.append(f"a {sec(b):.5f} {pm[name]['id']} {m.frac2clap(t['name'], name, f):.8g}")
    for on, dur, key, vel in t["notes"]:
        L.append(f"n {sec(on):.5f} {max(0.001, sec(dur)):.5f} {int(key)} {vel / 127.0:.4f}")
    Path(path).write_text("\n".join(L) + "\n")


def render_stems(proj, progress=None):
    """-> {track_name: np.ndarray (n,2) float32}"""
    m = meta(); lanes = build_automation(proj, m)
    work = Path(tempfile.mkdtemp(prefix="dsr_")); res = {}
    try:
        def one(i):
            t = proj["tracks"][i]
            job, outp = work / f"{t['name']}.job", work / f"{t['name']}.f32"
            _write_job(job, outp, proj, t, lanes[i], m)
            r = subprocess.run([m.render, str(job)], capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"dsrender {t['name']}: {r.stderr[-300:]}")
            return t["name"], np.fromfile(outp, dtype="<f4").reshape(-1, 2)
        with cf.ThreadPoolExecutor(max_workers=min(8, os.cpu_count() or 4)) as ex:
            for k, (name, arr) in enumerate(ex.map(one, range(len(proj["tracks"])))):
                res[name] = arr
                if progress:
                    progress((k + 1) / len(proj["tracks"]))
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return res


def mix_stems(proj, stems):
    solo = any(t["solo"] for t in proj["tracks"])
    n = max(len(a) for a in stems.values())
    x = np.zeros((n, 2), dtype=np.float32)
    for t in proj["tracks"]:
        if t["mute"] or (solo and not t["solo"]):
            continue
        a = stems[t["name"]]; x[: len(a)] += a * t["gain"]
    pk = float(np.percentile(np.abs(x), 99.9)) or 1.0
    x = x * (0.8 / pk)
    return (np.tanh(x * 1.1) / np.tanh(1.1) * 0.95).astype(np.float32)


def write_wav(path, arr):
    pcm = (np.clip(arr, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())


def export_mp3(wav_path, mp3_path):
    ff = shutil.which("ffmpeg")
    if ff:
        r = subprocess.run([ff, "-y", "-loglevel", "error", "-i", str(wav_path), "-b:a", "256k", str(mp3_path)])
        return r.returncode == 0
    lame = shutil.which("lame")
    if lame:
        return subprocess.run([lame, "--quiet", "-b", "256", str(wav_path), str(mp3_path)]).returncode == 0
    return False


# ------------------------------------------------------------------ MIDI
def _vlq(n):
    out = [n & 0x7F]; n >>= 7
    while n:
        out.append((n & 0x7F) | 0x80); n >>= 7
    return bytes(reversed(out))


def write_midi(proj, path, ppq=480):
    import struct
    chunks = []
    total = int(proj["bars"] * 4 * ppq)
    for ch, t in enumerate(proj["tracks"]):
        ev = []
        for on, dur, key, vel in t["notes"]:
            a = int(round(on * ppq)); b = max(a + 1, int(round((on + dur) * ppq)))
            ev.append((a, 1, bytes([0x90 | ch, int(key), int(vel)]))); ev.append((b, 0, bytes([0x80 | ch, int(key), 0])))
        ev.sort(key=lambda e: (e[0], e[1]))
        nm = ("DS " + t["name"].capitalize()).encode()
        d = _vlq(0) + b"\xff\x03" + _vlq(len(nm)) + nm
        if ch == 0:
            d += _vlq(0) + b"\xff\x51\x03" + struct.pack(">I", int(60000000 / proj["bpm"]))[1:]
            d += _vlq(0) + b"\xff\x58\x04\x04\x02\x18\x08"
        cur = 0
        for tick, _, b in ev:
            d += _vlq(tick - cur) + b; cur = tick
        d += _vlq(max(0, total - cur)) + b"\xff\x2f\x00"
        chunks.append(b"MTrk" + struct.pack(">I", len(d)) + d)
    Path(path).write_bytes(b"MThd" + struct.pack(">IHHH", 6, 1, len(chunks), ppq) + b"".join(chunks))


# ------------------------------------------------------------------ biblioteka
def lib_dir() -> Path:
    d = Path(os.environ.get("DS_LIBRARY", Path.home() / "DubstepStudio" / "library"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_project(proj, path):
    Path(path).write_text(json.dumps(proj, separators=(",", ":")))


def load_project(path):
    p = Path(path)
    if p.is_dir():
        p = p / "project.dsproj"
    return json.loads(p.read_text())


def save_to_library(proj, stems=None, progress=None, with_stems=False):
    """Renderuje (jeśli trzeba) i zapisuje: project.dsproj + track.mid + track.mp3 (lub .wav) [+ stems/]."""
    stems = stems or render_stems(proj, progress)
    mix = mix_stems(proj, stems)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    proj["created"] = stamp
    slug = re.sub(r"[^A-Za-z0-9]+", "-", proj["name"]).strip("-") or "track"
    d = lib_dir() / f"{stamp}_{slug}"
    d.mkdir(parents=True, exist_ok=True)
    proj["id"] = d.name
    save_project(proj, d / "project.dsproj")
    write_midi(proj, d / "track.mid")
    wav_p = d / "track.wav"; write_wav(wav_p, mix)
    if export_mp3(wav_p, d / "track.mp3"):
        wav_p.unlink()
    if with_stems:
        (d / "stems").mkdir(exist_ok=True)
        for n, a in stems.items():
            write_wav(d / "stems" / f"{n}.wav", np.clip(a, -1, 1))
    return d


def list_library():
    out = []
    for d in sorted(lib_dir().iterdir(), reverse=True):
        f = d / "project.dsproj"
        if f.exists():
            try:
                p = json.loads(f.read_text())
                audio = next((d / x for x in ("track.mp3", "track.wav") if (d / x).exists()), None)
                out.append({"path": d, "name": p["name"], "style": p["style"], "bpm": p["bpm"], "key": key_name(p),
                            "bars": p["bars"], "seed": p["seed"], "created": p.get("created", ""),
                            "audio": audio, "parents": p.get("parents", [])})
            except Exception:
                pass
    return out


def delete_library_entry(path):
    shutil.rmtree(path, ignore_errors=True)
