"""generator.py — losowa aranżacja dubstepu (8 ścieżek) + losowy sound design + domyślne linki między ścieżkami."""
from __future__ import annotations

import random
import time

from .core import MELODIC, SCALES, TRACKS, meta, new_project, track_of

T = lambda *a: list(a)

STYLES = {
    "Brostep": dict(bpm=140, kick=[[0, 10], [0, 7, 10], [0, 6, 10, 14], [0, 10, 13]], hat="16", wob="brostep", growl="brostep",
                    wob_div=[8, 9, 5, 10], growl_div=[8, 9, 10], reese="late", lead="accent", chord_len=1, swing=0.0,
                    template=[("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]),
    "Riddim": dict(bpm=140, kick=[[0], [0, 10]], hat="8", wob="riddim", growl="riddim", wob_div=[5, 9, 9, 8], growl_div=[8, 9],
                   reese="none", lead="rare", chord_len=2, swing=0.0,
                   template=[("intro", 8), ("build", 4), ("drop", 32), ("break", 8), ("build", 4), ("drop", 32), ("drop", 16), ("outro", 8)]),
    "Tearout": dict(bpm=150, kick=[[0, 6, 10], [0, 3, 6, 10, 13], [0, 7, 10, 14]], hat="16", wob="tearout", growl="tearout",
                    wob_div=[10, 11, 12], growl_div=[10, 11], reese="all", lead="accent", chord_len=1, swing=0.0,
                    template=[("intro", 8), ("build", 8), ("drop", 24), ("break", 8), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 8)]),
    "Melodic": dict(bpm=140, kick=[[0, 10]], hat="8", wob="melodic", growl="melodic", wob_div=[3, 4, 5], growl_div=[5, 8],
                    reese="all", lead="melodic", chord_len=2, swing=0.05,
                    template=[("intro", 16), ("build", 8), ("drop", 24), ("break", 24), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]),
    "Deep": dict(bpm=140, kick=[[0, 10], [0, 10, 14]], hat="off", wob="deep", growl="deep", wob_div=[2, 3, 4], growl_div=[5],
                 reese="all", lead="none", chord_len=2, swing=0.08,
                 template=[("intro", 16), ("drop", 32), ("break", 8), ("drop", 32), ("outro", 16)]),
}

WOB = {
    "brostep": [[(0, "r", 8)], [(0, "r", 4), (4, "o", 4)], [(0, "r", 6), (6, "t", 2)], [(0, "r", 3), (3, "r", 1), (4, "o", 4)], [(0, "r", 2), (2, "o", 2), (4, "r", 4)]],
    "riddim": [[(0, "r", 3), (4, "r", 3), (8, "r", 3)], [(0, "r", 6), (8, "r", 6)], [(0, "r", 2), (2, "r", 2), (4, "r", 4), (10, "r", 6)],
               [(0, "r", 3), (3, "o", 1), (4, "r", 3), (8, "f", 2), (10, "r", 3)]],
    "tearout": [[(0, "r", 2), (2, "o", 2), (4, "r", 2), (6, "t", 2), (8, "r", 2), (10, "f", 2), (12, "r", 4)], [(0, "r", 4), (4, "o", 4), (8, "r", 4), (12, "b", 4)]],
    "melodic": [[(0, "r", 16)], [(0, "r", 8), (8, "f", 8)], [(0, "r", 12), (12, "o", 4)]],
    "deep": [[(0, "r", 16)], [(0, "r", 12)], [(0, "r", 8), (8, "r", 6)]],
}
GROWL = {
    "brostep": [[(8, "r", 2), (10, "o", 2), (12, "r", 1), (13, "t", 1), (14, "o", 2)], [(8, "r", 3), (11, "t", 1), (12, "f", 2), (14, "r", 2)],
                [(8, "o", 2), (10, "r", 2), (12, "f", 2), (14, "t", 2)]],
    "riddim": [[(12, "r", 1), (13, "o", 1), (14, "r", 2)]],
    "tearout": [[(8, "r", 1), (9, "r", 1), (10, "o", 1), (11, "r", 1), (12, "t", 1), (13, "r", 1), (14, "o", 2)],
                [(8, "r", 2), (10, "o", 1), (11, "o", 1), (12, "f", 2), (14, "r", 1), (15, "t", 1)]],
    "melodic": [[(8, "r", 4), (12, "t", 4)]],
    "deep": [],
}
LEAD_RHYTHM = [[(0, 6), (6, 2), (8, 6), (14, 2)], [(0, 4), (4, 4), (8, 4), (12, 4)], [(0, 2), (2, 2), (4, 4), (8, 8)], [(0, 3), (3, 3), (6, 2), (8, 8)]]
PROGS = [[0, 5, 2, 6], [0, 6, 5, 6], [0, 3, 6, 5], [0, 0, 5, 6], [0, 2, 5, 6], [0, 4, 5, 3]]

# --- sound design: (parametr, 'r', lo, hi) | (parametr, 'c', [wybór])   (wartości w jednostkach silnika)
SOUND = {
    "kick": [("Decay", "r", 180, 380), ("Tune", "r", -3, 3), ("Pitch Env Amt", "r", 24, 44), ("Pitch Env Decay", "r", 18, 45),
             ("Noise", "r", 0.05, 0.3), ("Noise Decay", "r", 2, 8), ("Drive", "r", 0.15, 0.6)],
    "snare": [("Tune", "r", -4, 4), ("Decay", "r", 90, 200), ("Pitch Env Amt", "r", 6, 14), ("Noise", "r", 0.6, 1.0), ("Noise Decay", "r", 120, 260),
              ("Noise Highpass", "r", 800, 2500), ("Noise Bursts", "c", [1, 1, 2, 3]), ("Drive", "r", 0.2, 0.6), ("Cutoff", "r", 8000, 16000)],
    "hat": [("Decay", "r", 25, 90), ("Noise", "r", 0.3, 0.7), ("Noise Decay", "r", 25, 70), ("Noise Highpass", "r", 5000, 9000),
            ("Cutoff", "r", 5000, 9000), ("Drive", "r", 0.0, 0.2)],
    "sub": [("Waveform", "c", [0, 0, 1]), ("Glide", "r", 20, 90), ("Drive", "r", 0.05, 0.3), ("Cutoff", "r", 500, 1400), ("Sub Osc", "r", 0.0, 0.3)],
    "wobble": [("Waveform", "c", [2, 2, 3]), ("Wave Morph", "r", 0, 0.5), ("Unison Voices", "c", [1, 2, 3]), ("Unison Detune", "r", 8, 25),
               ("Cutoff", "r", 300, 900), ("Resonance", "r", 0.3, 0.65), ("LFO Shape", "c", [0, 0, 1, 2, 3]), ("LFO > Cutoff", "r", 2.5, 4.5),
               ("Drive", "r", 0.3, 0.6), ("Sub Osc", "r", 0.2, 0.4), ("Glide", "r", 10, 50)],
    "reese": [("Unison Voices", "c", [2, 3, 4, 5]), ("Unison Detune", "r", 14, 40), ("Cutoff", "r", 1200, 3500), ("Resonance", "r", 0.1, 0.35),
              ("LFO Rate", "r", 0.1, 0.5), ("LFO > Cutoff", "r", 1.0, 2.5), ("Drive", "r", 0.35, 0.7), ("Glide", "r", 40, 120),
              ("Sub Osc", "r", 0.2, 0.4), ("LFO Shape", "c", [0, 1])],
    "growl": [("Wave Morph", "r", 0.1, 0.6), ("FM Amount", "r", 0.3, 0.7), ("FM Ratio", "c", [1, 1.5, 2, 3, 3.01, 4, 5]), ("Formant Mix", "r", 0.6, 1.0),
              ("Vowel A-E-I-O-U", "r", 0, 3), ("LFO > Vowel", "r", 1, 3), ("Cutoff", "r", 3000, 9000), ("Resonance", "r", 0.2, 0.5),
              ("LFO Shape", "c", [1, 0, 2]), ("LFO > FM", "r", 0.1, 0.5), ("Drive", "r", 0.5, 0.85), ("Glide", "r", 15, 60)],
    "screech": [("Unison Voices", "c", [3, 5, 7]), ("Unison Detune", "r", 15, 40), ("FM Amount", "r", 0.35, 0.7), ("FM Ratio", "c", [2, 3.01, 3.5, 5, 7.01]),
                ("Cutoff", "r", 5000, 12000), ("Filter Env Amt", "r", 1, 3), ("Pitch Env Amt", "r", 3, 8), ("Pitch Env Decay", "r", 40, 120),
                ("Glide", "r", 50, 140), ("LFO > Pitch", "r", 0.1, 0.4), ("LFO Rate", "r", 4.5, 6.5), ("Drive", "r", 0.3, 0.6)],
}
SOUND_STYLE = {
    "Tearout": {"hat": [("Decay", "r", 20, 50)], "kick": [("Decay", "r", 140, 260)], "growl": [("Drive", "r", 0.7, 0.95)]},
    "Riddim": {"sub": [("Glide", "r", 0, 20)], "wobble": [("Glide", "r", 0, 12), ("Drive", "r", 0.45, 0.75)]},
    "Deep": {"sub": [("Sub Osc", "r", 0.0, 0.1)], "hat": [("Noise", "r", 0.15, 0.4)], "reese": [("Cutoff", "r", 800, 2000)]},
    "Melodic": {"screech": [("Cutoff", "r", 4000, 9000), ("Drive", "r", 0.15, 0.4)], "wobble": [("Drive", "r", 0.15, 0.4)]},
}


def randomize_sound(proj, tname, rng, only_new=True):
    try:
        m = meta()
    except RuntimeError:
        return  # brak dsrender/wtyczek — pomijamy sound design (nuty i tak powstają)
    style = proj["style"]
    spec = {p[0]: p for p in SOUND[tname]}
    for p in SOUND_STYLE.get(style, {}).get(tname, []):
        spec[p[0]] = p
    t = track_of(proj, tname)
    for name, p in spec.items():
        if not m.has(tname, name):
            continue
        # format: ("Name", "r", lo, hi)  albo  ("Name", "c", [choices])
        kind = p[1]
        if kind == "r":
            e = rng.uniform(p[2], p[3])
        else:
            e = rng.choice(p[2])
        t["params"][name] = m.eng2frac(tname, name, e)
    if tname in ("wobble", "growl"):
        div = STYLES[style]["wob_div" if tname == "wobble" else "growl_div"][0]
        t["params"]["LFO Division"] = m.eng2frac(tname, "LFO Division", div)


def default_links(style):
    L = lambda s, d, p, a, r=0.5: {"src": s, "dst": d, "param": p, "amount": a, "rel": r}
    duck = {"Deep": 0.35, "Melodic": 0.45}.get(style, 0.55)
    links = [L("kick", "sub", "Level", -duck, 0.5), L("kick", "wobble", "Level", -duck * 0.9, 0.5),
             L("kick", "reese", "Level", -duck * 0.9, 0.5), L("kick", "growl", "Level", -duck * 0.7, 0.45),
             L("kick", "screech", "Level", -duck * 0.5, 0.4),
             L("energy", "reese", "Cutoff", 0.20), L("energy", "growl", "Drive", 0.15), L("energy", "hat", "Level", 0.12),
             L("build", "screech", "Cutoff", 0.35), L("build", "snare", "Drive", 0.25),
             L("snare", "screech", "FM Amount", 0.15, 0.3), L("bass_note", "growl", "Vowel A-E-I-O-U", 0.30),
             L("bar_phase", "reese", "Cutoff", 0.08)]
    if style == "Tearout":
        links.append(L("snare", "growl", "Drive", 0.10, 0.3))
    return links


# ------------------------------------------------------------------ pomocnicze
def fit_template(template, bars, rng):
    tot = sum(b for _, b in template)
    out = [[n, max(4, round(b * bars / tot / 4) * 4)] for n, b in template]
    diff = bars - sum(b for _, b in out)
    big = [i for i, (n, _) in enumerate(out) if n == "drop"] or [0]
    k = 0
    while diff:
        step = 4 if diff > 0 else -4
        i = big[k % len(big)]
        if out[i][1] + step >= 4:
            out[i][1] += step; diff -= step
        k += 1
        if k > 200:
            break
    return out


def reg(pc, lo):
    return lo + ((pc - lo) % 12)


class Ctx:
    def __init__(self, proj, cfg):
        self.p, self.cfg = proj, cfg
        self.B = []
        for s in proj["sections"]:
            for i in range(s["bars"]):
                self.B.append({"sec": s, "i": i, "L": s["bars"], "type": s["type"], "k": s["k"], "e": s["e0"] + (s["e1"] - s["e0"]) * i / s["bars"],
                               "root": proj["chords"][s["start"] + i][0], "third": proj["chords"][s["start"] + i][1]})

    def rng(self, tname, salt=0):
        return random.Random(f"{self.p['seed']}-{tname}-{salt}")


def tok(b):
    th = b["third"]
    return {"r": 0, "o": 12, "f": 7, "t": th, "b": 10, "p": th + 12, "u": 14}


class Writer:
    def __init__(self, proj, tname):
        self.t = track_of(proj, tname); self.name = tname; self.sw = proj["swing"]; self.t["notes"] = []

    def add(self, bar, step, key, ln, vel, drum=False):
        beat = bar * 4 + step * 0.25
        if step % 2 == 1 and self.name not in ("sub", "reese"):
            beat += self.sw * 0.1
        dur = 0.1 if drum else max(0.05, ln * 0.25 - 0.03)
        self.t["notes"].append([round(beat, 4), round(dur, 4), int(key), max(1, min(127, int(vel)))])


# ------------------------------------------------------------------ generatory ścieżek
def gen_kick(c):
    w, r, cfg = Writer(c.p, "kick"), c.rng("kick"), c.cfg
    pools, pick = cfg["kick"], {}
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            pat = pick.setdefault(B["sec"]["name"], r.choice(pools))
            steps = list(pat)
            if i % 4 == 3 and r.random() < c.p["density"] * 0.7:
                steps.append(r.choice([13, 14, 15]))
            if i % 8 == 7:
                steps = [0, 6, 10, 12]
        elif (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            steps = pools[0][:2]
        elif t == "build" and i >= L // 2:
            steps = [0]
        else:
            continue
        for s in sorted(set(steps)):
            w.add(b, s, 36, 0, (118 if s == 0 else 104) + r.randint(-5, 5), drum=True)


def gen_snare(c):
    w, r = Writer(c.p, "snare"), c.rng("snare")
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            w.add(b, 8, 38, 0, 118 + r.randint(-4, 4), drum=True)
            if c.cfg["wob"] == "tearout" and i % 8 == 7:
                for s in (12, 13, 14, 15):
                    w.add(b, s, 38, 0, 80 + s * 2, drum=True)
            elif i % 8 == 7 and r.random() < c.p["density"]:
                w.add(b, 14, 38, 0, 92, drum=True)
        elif t == "build":
            p = (i + 0.5) / L
            steps = [0, 8] if p < 0.25 else [0, 4, 8, 12] if p < 0.5 else list(range(0, 16, 2)) if p < 0.75 else list(range(16))
            if i == L - 1:
                steps = [s for s in steps if s < 12]
            for s in steps:
                w.add(b, s, 38, 0, min(127, 55 + int(65 * (i + s / 16) / L)) + r.randint(-3, 3), drum=True)


def gen_hat(c):
    w, r, mode = Writer(c.p, "hat"), c.rng("hat"), c.cfg["hat"]
    d = c.p["density"]
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            if mode == "16":
                for s in range(16):
                    if s % 2 == 1 and r.random() > 0.55 + 0.45 * d:
                        continue
                    w.add(b, s, 42, 0, (95 if s % 4 == 2 else 70 if s % 2 == 0 else 52) + r.randint(-5, 5), drum=True)
            elif mode == "8":
                for s in range(0, 16, 2):
                    w.add(b, s, 42, 0, (95 if s % 4 == 2 else 68) + r.randint(-4, 4), drum=True)
            else:
                for s in (2, 6, 10, 14):
                    w.add(b, s, 42, 0, 78 + r.randint(-4, 4), drum=True)
        elif t in ("intro", "outro"):
            fade = 1.0 if t == "intro" else 1 - i / L
            for s in range(0, 16, 2):
                w.add(b, s, 42, 0, int((78 if s % 4 == 2 else 58) * fade) + 10, drum=True)
        elif t == "build" and i >= 2:
            for s in range(0, 16, 2):
                w.add(b, s, 42, 0, 55 + int(40 * i / L), drum=True)
        elif t == "break" and mode == "off":
            for s in (2, 10):
                w.add(b, s, 42, 0, 50, drum=True)


def _phrase_pick(c, tname, library, b, phrase=4):
    r = c.rng(tname, b // phrase)
    return r.choice(library) if library else []


def gen_wobble(c):
    w = Writer(c.p, "wobble"); style = c.cfg["wob"]; r = c.rng("wobble"); lib = WOB[style]
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        pat = _phrase_pick(c, "wobble", lib, b, 4 if style != "riddim" else 2)
        if style == "brostep" and B["k"] > 1 and B["i"] % 2:
            pat = _phrase_pick(c, "wobble", lib, b + 100, 4)
        for s, tkn, ln in pat:
            w.add(b, s, base + k[tkn], ln, 108 + r.randint(-4, 4))
    # zmiany podziału LFO (stepped) per sekcja drop
    ro, auto = c.rng("wob_div"), track_of(c.p, "wobble")["auto"]
    try:
        m = meta()
    except RuntimeError:
        return
    pts = []
    for s in c.p["sections"]:
        if s["type"] != "drop":
            continue
        for off in range(0, s["bars"], 8):
            if off == 0 or ro.random() < 0.5:
                pts.append([(s["start"] + off) * 4, m.eng2frac("wobble", "LFO Division", ro.choice(c.cfg["wob_div"]))])
    auto["LFO Division"] = pts


def gen_sub(c):
    w, r = Writer(c.p, "sub"), c.rng("sub")
    riddim = c.cfg["wob"] == "riddim"
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        base = reg(B["root"], 24)
        if t == "drop":
            if riddim:
                continue
            ln = 16 if not (i % 8 == 7 and r.random() < c.p["density"]) else 14
            w.add(b, 0, base, ln, 110 + r.randint(-4, 4))
        elif (t == "intro" and i >= L // 2) or t == "break" or (t == "outro" and i < L * 3 // 4):
            w.add(b, 0, base, 16, 96)
    if riddim:  # sub powiela rytm wobble o oktawę niżej
        for on, dur, key, vel in track_of(c.p, "wobble")["notes"]:
            w.t["notes"].append([on, dur, key - 12, vel])


def gen_reese(c):
    w, r, mode = Writer(c.p, "reese"), c.rng("reese"), c.cfg["reese"]
    for b, B in enumerate(c.B):
        t, i, L, k = B["type"], B["i"], B["L"], B["k"]
        base = reg(B["root"], 24) + 24
        if t == "drop" and mode != "none" and (mode == "all" or k >= 2 and i >= L // 2 or k >= 3):
            w.add(b, 0, base, 16, 100 + r.randint(-4, 4))
        elif t in ("intro", "break") and mode != "none" and b % 2 == 0:
            w.add(b, 0, base, 32, 70)
        elif t == "outro" and i < L * 3 // 4 and b % 2 == 0 and mode != "none":
            w.add(b, 0, base, 32, max(30, 70 - i * 4))


def gen_growl(c):
    w, r, style = Writer(c.p, "growl"), c.rng("growl"), c.cfg["growl"]
    lib = GROWL[style]
    if not lib:
        return
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        if style == "brostep" and B["k"] == 1 and B["i"] < 8:
            continue
        if style == "riddim" and B["i"] % 4 != 3:
            continue
        if style == "melodic" and B["i"] % 2 == 0:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        pat = _phrase_pick(c, "growl", lib, b, 2)
        for s, tkn, ln in pat:
            w.add(b, s, base + k[tkn], ln, 104 + r.randint(-5, 5))
    ro, auto = c.rng("growl_div"), track_of(c.p, "growl")["auto"]
    try:
        m = meta()
    except RuntimeError:
        return
    pts = []
    for s in c.p["sections"]:
        if s["type"] == "drop":
            for off in range(0, s["bars"], 8):
                pts.append([(s["start"] + off) * 4, m.eng2frac("growl", "LFO Division", ro.choice(c.cfg["growl_div"]))])
    auto["LFO Division"] = pts


def gen_screech(c):
    w, r, mode = Writer(c.p, "screech"), c.rng("screech"), c.cfg["lead"]
    walk = 2
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        th = B["third"]; base = reg(B["root"], 72)
        if t == "build":
            w.add(b, 0, 53 + int(24 * (i + 0.5) / L), 16, 70 + int(50 * i / L))
        elif t == "break" and mode != "none" and i >= 4:
            tones = [0, th, 7, 12, th + 12, 14]
            for s, ln in r.choice(LEAD_RHYTHM):
                walk = max(0, min(len(tones) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
                w.add(b, s, base + tones[walk], ln, 100 + r.randint(-5, 5))
        elif t == "drop":
            if mode == "melodic" and i >= 4:
                tones = [0, th, 7, 12, th + 12]
                for s, ln in r.choice(LEAD_RHYTHM):
                    walk = max(0, min(len(tones) - 1, walk + r.choice([-1, 0, 1, 2])))
                    w.add(b, s, base + tones[walk], ln, 96 + r.randint(-4, 4))
            elif mode == "accent" and (i % 4 == 3 or (B["k"] >= 3)):
                w.add(b, 8, base, 8, 98)
                if B["k"] >= 3:
                    w.add(b, 0, base + 12, 2, 92); w.add(b, 2, base + 7, 2, 92); w.add(b, 4, base, 4, 92)
            elif mode == "rare" and i % 8 == 7:
                w.add(b, 8, base, 8, 98)


GEN = {"kick": gen_kick, "snare": gen_snare, "hat": gen_hat, "wobble": gen_wobble, "sub": gen_sub,
       "reese": gen_reese, "growl": gen_growl, "screech": gen_screech}
ORDER = ["kick", "snare", "hat", "wobble", "sub", "reese", "growl", "screech"]


def generate(style="Brostep", bpm=None, key=None, scale="minor", bars=144, energy=0.7, swing=None, density=0.6, seed=None, name=None):
    cfg = STYLES[style]
    seed = int(seed if seed is not None else time.time() * 1000) % 1000000
    rng = random.Random(seed)
    key = rng.randrange(12) if key is None else key
    swing = cfg["swing"] if swing is None else swing
    proj = new_project(name=name or f"{style}-{seed}", bpm=bpm or cfg["bpm"], style=style, key=key, scale=scale, seed=seed,
                       swing=swing, energy=energy, density=density)
    # sekcje
    es = 0.6 + 0.4 * energy
    start, ord_ = 0, {}
    for sname, n in fit_template(cfg["template"], bars, rng):
        ord_[sname] = ord_.get(sname, 0) + 1
        e0, e1 = {"intro": (0.3, 0.4), "build": (0.5, 0.95), "drop": (1.0, 1.0), "break": (0.35, 0.35), "outro": (0.3, 0.1)}[sname]
        proj["sections"].append({"name": f"{sname}{ord_[sname]}", "type": sname, "k": ord_[sname], "start": start, "bars": n,
                                 "e0": round(e0 * es, 3), "e1": round(e1 * es, 3)})
        start += n
    proj["bars"] = start
    # harmonia
    sc = SCALES[scale]; prog = rng.choice(PROGS)
    for b in range(proj["bars"]):
        d = prog[(b // cfg["chord_len"]) % len(prog)]
        proj["chords"].append([(key + sc[d]) % 12, (sc[(d + 2) % 7] - sc[d]) % 12])
    c = Ctx(proj, cfg)
    for t in ORDER:
        randomize_sound(proj, t, random.Random(f"{seed}-snd-{t}"))
        GEN[t](c)
    proj["links"] = default_links(style)
    return proj


def reroll_track(proj, tname, new_seed=None, sound=False):
    """Przelosowuje wzór jednej ścieżki (harmonia/sekcje zostają)."""
    cfg = STYLES[proj["style"]]
    proj["seed"] = int(new_seed if new_seed is not None else random.randrange(1000000))
    c = Ctx(proj, cfg)
    GEN[tname](c)
    if sound:
        randomize_sound(proj, tname, random.Random(proj["seed"] + 1))
    if tname == "wobble" and cfg["wob"] == "riddim":
        GEN["sub"](c)
    return proj


# ------------------------------------------------------------------ uruchomienie bezpośrednie
if __name__ == "__main__":
    import json
    import sys

    style = sys.argv[1] if len(sys.argv) > 1 else "Brostep"
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else None
    bars = int(sys.argv[3]) if len(sys.argv) > 3 else 64

    proj = generate(style=style, bars=bars, seed=seed)
    summary = {
        "name": proj["name"],
        "style": proj["style"],
        "bpm": proj["bpm"],
        "key": f"{['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'][proj['key'] % 12]} {proj['scale']}",
        "bars": proj["bars"],
        "seed": proj["seed"],
        "sections": [s["name"] for s in proj["sections"]],
        "tracks": {t["name"]: len(t["notes"]) for t in proj["tracks"]},
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))
