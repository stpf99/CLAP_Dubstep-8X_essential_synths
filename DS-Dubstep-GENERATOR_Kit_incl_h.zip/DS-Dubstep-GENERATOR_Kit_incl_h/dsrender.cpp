// dsrender.cpp — minimalny offline host CLAP dla DS Dubstep Studio
//   dsrender --dump  plik.clap            -> JSON z listą wtyczek i parametrów (stdout)
//   dsrender job.txt                      -> renderuje jedną ścieżkę do surowego f32 (stereo, interleaved)
// Format joba (tekst, linie):
//   sr 48000 | bpm 140 | len <sek> | tail <sek> | plugin <plik.clap> <plugin_id> | out <plik.f32>
//   p <param_id> <wartosc_clap>                 (wartość początkowa, t=0)
//   a <czas_s> <param_id> <wartosc_clap>        (automatyzacja)
//   n <czas_s> <dlugosc_s> <klawisz> <vel 0..1> (nuta)
#include <clap/clap.h>
#include <dlfcn.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

static const void* h_ext(const clap_host_t*, const char*) { return nullptr; }
static void h_noop(const clap_host_t*) {}
static clap_host_t HOST = {CLAP_VERSION_INIT, nullptr, "dsrender", "stpf99", "", "1.0", h_ext, h_noop, h_noop, h_noop};

union EvU { clap_event_header_t h; clap_event_note_t n; clap_event_param_value_t p; };
struct EvList { std::vector<EvU> v; };
static uint32_t ev_size(const clap_input_events_t* l) { return (uint32_t)((EvList*)l->ctx)->v.size(); }
static const clap_event_header_t* ev_get(const clap_input_events_t* l, uint32_t i) { return &((EvList*)l->ctx)->v[i].h; }
static bool out_push(const clap_output_events_t*, const clap_event_header_t*) { return true; }

struct Lib { void* h = nullptr; const clap_plugin_entry_t* e = nullptr; const clap_plugin_factory_t* f = nullptr; };
static bool openLib(const char* path, Lib& L) {
  L.h = dlopen(path, RTLD_NOW);
  if (!L.h) { fprintf(stderr, "dlopen: %s\n", dlerror()); return false; }
  L.e = (const clap_plugin_entry_t*)dlsym(L.h, "clap_entry");
  if (!L.e || !L.e->init(path)) return false;
  L.f = (const clap_plugin_factory_t*)L.e->get_factory(CLAP_PLUGIN_FACTORY_ID);
  return L.f != nullptr;
}

static int dump(const char* path) {
  Lib L; if (!openLib(path, L)) return 1;
  printf("[");
  for (uint32_t k = 0; k < L.f->get_plugin_count(L.f); k++) {
    auto* d = L.f->get_plugin_descriptor(L.f, k);
    auto* p = L.f->create_plugin(L.f, &HOST, d->id);
    if (!p || !p->init(p)) return 1;
    auto* pr = (const clap_plugin_params_t*)p->get_extension(p, CLAP_EXT_PARAMS);
    printf("%s{\"id\":\"%s\",\"name\":\"%s\",\"desc\":\"%s\",\"params\":[", k ? "," : "", d->id, d->name, d->description);
    for (uint32_t i = 0; i < pr->count(p); i++) {
      clap_param_info_t in; pr->get_info(p, i, &in);
      char tmin[64], tmax[64], tdef[64];
      pr->value_to_text(p, in.id, in.min_value, tmin, 64);
      pr->value_to_text(p, in.id, in.max_value, tmax, 64);
      pr->value_to_text(p, in.id, in.default_value, tdef, 64);
      bool stepped = in.flags & CLAP_PARAM_IS_STEPPED;
      printf("%s{\"id\":%u,\"name\":\"%s\",\"module\":\"%s\",\"min\":%.9g,\"max\":%.9g,\"def\":%.9g,\"stepped\":%s,"
             "\"tmin\":\"%s\",\"tmax\":\"%s\",\"tdef\":\"%s\",\"texts\":[",
             i ? "," : "", in.id, in.name, in.module, in.min_value, in.max_value, in.default_value,
             stepped ? "true" : "false", tmin, tmax, tdef);
      if (stepped) for (int v = (int)in.min_value; v <= (int)in.max_value; v++) {
        char t[64]; pr->value_to_text(p, in.id, v, t, 64); printf("%s\"%s\"", v > (int)in.min_value ? "," : "", t);
      }
      printf("]}");
    }
    printf("]}");
    p->destroy(p);
  }
  printf("]\n");
  return 0;
}

struct Ev { uint64_t t; int pri; uint32_t id; int key; double val; };  // pri: 0 param, 1 off, 2 on

int main(int argc, char** argv) {
  if (argc >= 3 && !strcmp(argv[1], "--dump")) return dump(argv[2]);
  if (argc < 2) { fprintf(stderr, "usage: dsrender --dump x.clap | job.txt\n"); return 2; }
  FILE* jf = fopen(argv[1], "r"); if (!jf) { perror("job"); return 2; }
  double sr = 48000, bpm = 140, len = 0, tail = 3;
  char clap[2048] = "", pid[256] = "", outp[2048] = "", line[4096];
  std::vector<Ev> evs;
  while (fgets(line, sizeof line, jf)) {
    char c0 = line[0]; double a, b, c, d; unsigned id; int key;
    if (!strncmp(line, "sr ", 3)) sr = atof(line + 3);
    else if (!strncmp(line, "bpm ", 4)) bpm = atof(line + 4);
    else if (!strncmp(line, "len ", 4)) len = atof(line + 4);
    else if (!strncmp(line, "tail ", 5)) tail = atof(line + 5);
    else if (!strncmp(line, "plugin ", 7)) sscanf(line + 7, "%2047s %255s", clap, pid);
    else if (!strncmp(line, "out ", 4)) { sscanf(line + 4, "%2047s", outp); }
    else if (c0 == 'p' && line[1] == ' ') { if (sscanf(line + 2, "%u %lf", &id, &a) == 2) evs.push_back({0, 0, id, 0, a}); }
    else if (c0 == 'a' && line[1] == ' ') { if (sscanf(line + 2, "%lf %u %lf", &a, &id, &b) == 3) evs.push_back({(uint64_t)std::llround(a * sr), 0, id, 0, b}); }
    else if (c0 == 'n' && line[1] == ' ') {
      if (sscanf(line + 2, "%lf %lf %d %lf", &a, &b, &key, &c) == 4) {
        uint64_t on = (uint64_t)std::llround(a * sr), off = (uint64_t)std::llround((a + b) * sr);
        evs.push_back({on, 2, 0, key, c}); evs.push_back({std::max(off, on + 1), 1, 0, key, 0});
      }
    }
    (void)d;
  }
  fclose(jf);
  Lib L; if (!openLib(clap, L)) return 3;
  const clap_plugin_t* p = L.f->create_plugin(L.f, &HOST, pid);
  if (!p || !p->init(p)) { fprintf(stderr, "no plugin %s\n", pid); return 3; }
  p->activate(p, sr, 32, 512); p->start_processing(p);
  std::stable_sort(evs.begin(), evs.end(), [](const Ev& x, const Ev& y) { return x.t != y.t ? x.t < y.t : x.pri < y.pri; });
  uint64_t total = (uint64_t)std::llround((len + tail) * sr);
  FILE* of = fopen(outp, "wb"); if (!of) { perror("out"); return 4; }
  const uint32_t B = 512; std::vector<float> L_(B), R_(B), inter(B * 2);
  size_t ei = 0; EvList el; el.v.reserve(4096);
  for (uint64_t pos = 0; pos < total; pos += B) {
    uint32_t n = (uint32_t)std::min<uint64_t>(B, total - pos);
    el.v.clear();
    while (ei < evs.size() && evs[ei].t < pos + n) {
      const Ev& e = evs[ei++]; EvU u; std::memset(&u, 0, sizeof u);
      uint32_t t = e.t > pos ? (uint32_t)(e.t - pos) : 0;
      if (e.pri == 0) {
        u.p.header = {sizeof(clap_event_param_value_t), t, CLAP_CORE_EVENT_SPACE_ID, CLAP_EVENT_PARAM_VALUE, 0};
        u.p.param_id = e.id; u.p.note_id = -1; u.p.port_index = -1; u.p.channel = -1; u.p.key = -1; u.p.value = e.val;
      } else {
        u.n.header = {sizeof(clap_event_note_t), t, CLAP_CORE_EVENT_SPACE_ID,
                      (uint16_t)(e.pri == 2 ? CLAP_EVENT_NOTE_ON : CLAP_EVENT_NOTE_OFF), 0};
        u.n.note_id = -1; u.n.port_index = 0; u.n.channel = 0; u.n.key = (int16_t)e.key; u.n.velocity = e.val;
      }
      el.v.push_back(u);
    }
    clap_input_events_t in{&el, ev_size, ev_get}; clap_output_events_t out{nullptr, out_push};
    float* ch[2] = {L_.data(), R_.data()};
    clap_audio_buffer_t ab{}; ab.data32 = ch; ab.channel_count = 2;
    clap_event_transport_t tr{}; tr.header.size = sizeof tr; tr.flags = CLAP_TRANSPORT_HAS_TEMPO; tr.tempo = bpm;
    clap_process_t pc{}; pc.frames_count = n; pc.transport = &tr; pc.audio_outputs = &ab; pc.audio_outputs_count = 1;
    pc.in_events = &in; pc.out_events = &out;
    p->process(p, &pc);
    for (uint32_t i = 0; i < n; i++) { inter[2 * i] = L_[i]; inter[2 * i + 1] = R_[i]; }
    fwrite(inter.data(), sizeof(float), n * 2, of);
  }
  fclose(of);
  p->stop_processing(p); p->deactivate(p); p->destroy(p); L.e->deinit();
  return 0;
}
