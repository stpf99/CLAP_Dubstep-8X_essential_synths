#!/usr/bin/env python3
"""cli.py — prosty interfejs wiersza poleceń DS Dubstep Kit.

Przykłady:
  python cli.py generate --style Brostep --bars 64 --seed 42
  python cli.py generate --style Riddim --out track.dsproj
  python cli.py library
  python cli.py render project.dsproj --mp3
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Umożliwia uruchomienie bez instalacji pakietu (z katalogu głównego projektu)
sys.path.insert(0, str(Path(__file__).resolve().parent))

from ds.generator import STYLES, generate
from ds.core import (
    key_name,
    load_project,
    save_project,
    save_to_library,
    list_library,
    delete_library_entry,
    render_stems,
    mix_stems,
    write_wav,
    export_mp3,
    write_midi,
)


def cmd_generate(args):
    proj = generate(
        style=args.style,
        bpm=args.bpm,
        key=args.key,
        scale=args.scale,
        bars=args.bars,
        energy=args.energy,
        density=args.density,
        swing=args.swing,
        seed=args.seed,
        name=args.name,
    )
    print(f"Wygenerowano: {proj['name']}")
    print(f"  styl={proj['style']}  bpm={proj['bpm']}  tonacja={key_name(proj)}")
    print(f"  takty={proj['bars']}  seed={proj['seed']}  energy={proj['energy']}")

    out = Path(args.out) if args.out else None
    if args.library:
        d = save_to_library(proj, with_stems=args.stems)
        print(f"  zapisano do biblioteki: {d}")
    elif out:
        if out.suffix.lower() in (".dsproj", ".json"):
            save_project(proj, out)
        else:
            save_project(proj, out.with_suffix(".dsproj"))
            out = out.with_suffix(".dsproj")
        print(f"  zapisano projekt: {out}")
    else:
        # domyślnie wypisz skrót JSON na stdout
        summary = {
            "name": proj["name"],
            "style": proj["style"],
            "bpm": proj["bpm"],
            "key": key_name(proj),
            "bars": proj["bars"],
            "seed": proj["seed"],
            "sections": [s["name"] for s in proj["sections"]],
        }
        print(json.dumps(summary, indent=2, ensure_ascii=False))


def cmd_library(args):
    entries = list_library()
    if not entries:
        print("Biblioteka pusta.")
        return
    for e in entries:
        audio = e["audio"].name if e["audio"] else "—"
        print(f"{e['created']:16}  {e['name']:28}  {e['style']:10}  "
              f"{e['bpm']:3} bpm  {e['key']:14}  {e['bars']:3} takty  [{audio}]")
        print(f"  → {e['path']}")


def cmd_render(args):
    proj = load_project(args.project)
    print(f"Renderuję: {proj['name']} ({proj['bars']} taków @ {proj['bpm']} bpm)…")

    def progress(p):
        pct = int(p * 100)
        print(f"\r  ścieżki: {pct}%", end="", flush=True)

    stems = render_stems(proj, progress=progress)
    print()
    mix = mix_stems(proj, stems)

    out_dir = Path(args.out) if args.out else Path(args.project).parent
    out_dir.mkdir(parents=True, exist_ok=True)
    base = out_dir / (Path(args.project).stem if args.out is None else "track")

    wav_path = base.with_suffix(".wav")
    write_wav(wav_path, mix)
    print(f"  WAV: {wav_path}")

    if args.mp3:
        mp3_path = base.with_suffix(".mp3")
        if export_mp3(wav_path, mp3_path):
            print(f"  MP3: {mp3_path}")
            if not args.keep_wav:
                wav_path.unlink(missing_ok=True)
        else:
            print("  (ffmpeg/lame niedostępne — pominięto MP3)")

    if args.midi:
        mid_path = base.with_suffix(".mid")
        write_midi(proj, mid_path)
        print(f"  MIDI: {mid_path}")

    if args.stems:
        stems_dir = out_dir / "stems"
        stems_dir.mkdir(exist_ok=True)
        for name, arr in stems.items():
            write_wav(stems_dir / f"{name}.wav", arr)
        print(f"  stems → {stems_dir}/")


def cmd_delete(args):
    path = Path(args.path)
    if not path.exists():
        print(f"Nie znaleziono: {path}")
        sys.exit(1)
    delete_library_entry(path)
    print(f"Usunięto: {path}")


def main():
    p = argparse.ArgumentParser(
        prog="ds-dubstep",
        description="DS Dubstep Kit — generator i renderer aranżacji dubstep",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    # generate
    g = sub.add_parser("generate", help="Wygeneruj nową aranżację")
    g.add_argument("--style", choices=list(STYLES.keys()), default="Brostep")
    g.add_argument("--bpm", type=int, default=None)
    g.add_argument("--key", type=int, default=None, help="0=C … 11=B")
    g.add_argument("--scale", choices=["minor", "phrygian", "harmonic minor"], default="minor")
    g.add_argument("--bars", type=int, default=144)
    g.add_argument("--energy", type=float, default=0.7)
    g.add_argument("--density", type=float, default=0.6)
    g.add_argument("--swing", type=float, default=None)
    g.add_argument("--seed", type=int, default=None)
    g.add_argument("--name", default=None)
    g.add_argument("--out", "-o", default=None, help="Plik .dsproj")
    g.add_argument("--library", action="store_true", help="Zapisz od razu do biblioteki (+ render)")
    g.add_argument("--stems", action="store_true", help="Przy --library zapisz też stems")
    g.set_defaults(func=cmd_generate)

    # library
    lib = sub.add_parser("library", help="Lista utworów w bibliotece")
    lib.set_defaults(func=cmd_library)

    # render
    r = sub.add_parser("render", help="Renderuj istniejący projekt .dsproj")
    r.add_argument("project", help="Ścieżka do project.dsproj")
    r.add_argument("--out", "-o", default=None, help="Katalog wyjściowy")
    r.add_argument("--mp3", action="store_true")
    r.add_argument("--midi", action="store_true")
    r.add_argument("--stems", action="store_true")
    r.add_argument("--keep-wav", action="store_true")
    r.set_defaults(func=cmd_render)

    # delete
    d = sub.add_parser("delete", help="Usuń wpis z biblioteki")
    d.add_argument("path", help="Katalog wpisu biblioteki")
    d.set_defaults(func=cmd_delete)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
