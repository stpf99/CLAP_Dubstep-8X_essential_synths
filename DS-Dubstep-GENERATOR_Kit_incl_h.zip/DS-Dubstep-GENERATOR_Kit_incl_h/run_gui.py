#!/usr/bin/env python3
"""Uruchom GUI DS Dubstep Kit."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ds.gui import main

if __name__ == "__main__":
    main()
