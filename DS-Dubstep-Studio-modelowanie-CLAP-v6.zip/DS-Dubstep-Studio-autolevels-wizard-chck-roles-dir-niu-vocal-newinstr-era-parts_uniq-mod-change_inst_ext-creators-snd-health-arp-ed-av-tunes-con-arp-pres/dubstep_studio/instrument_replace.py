"""instrument_replace.py — zamiana instrumentów wg roli + polityka per rola.

Polityka roli (lead / bass / …):
  allowed  — dozwolone cele zamiany (puste = cały ROLE_POOLS ∩ available)
  skip     — zawsze pomijaj przy zamianie (te tory nie są ruszane)
  required — wymagane typy po generacji (jeśli brak → dodaj / podmień w roli)

Reguły tabeli: src→dst z prawdopodobieństwem; dst zawężony do allowed.
"""
from __future__ import annotations

import random

ROLE_POOLS = {
    "drums": ["kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker"],
    "bass": ["sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow", "acid"],
    "lead": ["screech", "supersaw", "pluck", "stab", "vox", "piano", "theremin", "panflute",
             "bell", "pulse"],
    "pad": ["pad", "strings", "hollow", "reese", "handpan", "tongue", "organ", "brass", "choir"],
    "fx": ["riser", "boom", "zap", "noisesweep"],
    "vocal": ["vox", "speak"],
}

ROLE_LABELS = {
    "drums": "Perkusja", "bass": "Bas", "lead": "Lead",
    "pad": "Pad / harmoniczne", "fx": "FX", "vocal": "Wokal / mowa",
}

TYPE_TO_ROLE = {t: role for role, types in ROLE_POOLS.items() for t in types}


def default_policy():
    """Pusta polityka = brak ograniczeń allowed, brak skip/required."""
    return {role: {"allowed": [], "skip": [], "required": []} for role in ROLE_POOLS}


def normalize_policy(pol):
    out = default_policy()
    if not pol:
        return out
    for role, cfg in pol.items():
        if role not in out:
            continue
        out[role] = {
            "allowed": [str(x) for x in (cfg.get("allowed") or []) if x in ROLE_POOLS.get(role, []) or True],
            "skip": [str(x) for x in (cfg.get("skip") or [])],
            "required": [str(x) for x in (cfg.get("required") or [])],
        }
        # allowed: filtruj do puli roli
        pool = set(ROLE_POOLS.get(role, []))
        out[role]["allowed"] = [t for t in out[role]["allowed"] if t in pool]
        out[role]["skip"] = [t for t in out[role]["skip"] if t in pool]
        out[role]["required"] = [t for t in out[role]["required"] if t in pool]
    return out


def default_rules():
    return [
        dict(enabled=False, role="lead", src="*", dst="*", prob=0.55, keep_notes=True, regen_sound=True),
        dict(enabled=False, role="bass", src="*", dst="*", prob=0.40, keep_notes=True, regen_sound=True),
        dict(enabled=False, role="pad", src="*", dst="*", prob=0.45, keep_notes=True, regen_sound=True),
        dict(enabled=False, role="drums", src="hat", dst="*", prob=0.30, keep_notes=True, regen_sound=True),
    ]


def random_rules(rng=None, n=None, policy=None):
    rng = rng or random.Random()
    pol = normalize_policy(policy)
    roles = list(ROLE_POOLS.keys())
    n = n if n is not None else rng.randint(2, 5)
    rules = []
    for _ in range(n):
        role = rng.choice(roles)
        pool = list(pol[role]["allowed"]) or list(ROLE_POOLS[role])
        if not pool:
            continue
        src = "*" if rng.random() < 0.55 else rng.choice(pool)
        dst_pool = [t for t in pool if t != src] or pool
        dst = "*" if rng.random() < 0.65 else rng.choice(dst_pool)
        rules.append(dict(
            enabled=True, role=role, src=src, dst=dst,
            prob=round(rng.uniform(0.35, 0.85), 2),
            keep_notes=rng.random() < 0.7, regen_sound=True,
        ))
    return rules


def normalize_rule(r):
    return dict(
        enabled=bool(r.get("enabled", True)),
        role=str(r.get("role") or "lead"),
        src=str(r.get("src") or "*"),
        dst=str(r.get("dst") or "*"),
        prob=max(0.0, min(1.0, float(r.get("prob", 0.5)))),
        keep_notes=bool(r.get("keep_notes", True)),
        regen_sound=bool(r.get("regen_sound", True)),
    )


def _allowed_pool(role, policy, avail):
    pol = (policy or {}).get(role) or {}
    allowed = pol.get("allowed") or []
    base = list(ROLE_POOLS.get(role, []))
    if allowed:
        pool = [t for t in allowed if t in avail]
    else:
        pool = [t for t in base if t in avail]
    return pool


def _pick_dst(role, src_type, dst_spec, avail, rng, used, policy):
    pool = _allowed_pool(role, policy, avail)
    pool = [t for t in pool if t != src_type] or list(pool)
    if not pool:
        return None
    if dst_spec and dst_spec != "*":
        if dst_spec in pool:
            return dst_spec
        # dst poza allowed — nie używaj
        return None
    fresh = [t for t in pool if t not in used]
    return rng.choice(fresh or pool)


def apply(proj, rules, rng=None, avail=None, policy=None):
    """Zamiany + ensure required. Zwraca listę eventów."""
    from . import core, generator as G

    rng = rng or random.Random(int(proj.get("seed", 0)) + 88)
    policy = normalize_policy(policy)
    rules = [normalize_rule(r) for r in (rules or []) if r]
    rules = [r for r in rules if r["enabled"] and r["prob"] > 0]

    if avail is None:
        try:
            avail = set(core.available_types())
        except Exception:
            avail = set(core.TYPES)

    used = {tr["type"] for tr in proj.get("tracks") or []}
    events = []
    cfg = G.STYLES.get(proj.get("style") or "Brostep") or G.STYLES["Brostep"]
    skip_all = set()
    for role, cfg_p in policy.items():
        skip_all.update(cfg_p.get("skip") or [])

    for tr in list(proj.get("tracks") or []):
        if tr.get("lock_sound") and tr.get("lock_notes"):
            continue
        if tr["type"] in skip_all:
            continue
        role = TYPE_TO_ROLE.get(tr["type"])
        if not role:
            continue
        # skip z polityki roli
        if tr["type"] in (policy.get(role, {}).get("skip") or []):
            continue
        for rule in rules:
            if rule["role"] != role:
                continue
            src = rule["src"]
            if src != "*" and src != tr["type"]:
                continue
            if rng.random() > rule["prob"]:
                continue
            new_type = _pick_dst(role, tr["type"], rule["dst"], avail, rng, used, policy)
            if not new_type or new_type == tr["type"]:
                continue
            old = tr["type"]
            tr["type"] = new_type
            tr["plugin"] = core.PLUGIN_ID.get(new_type, tr.get("plugin"))
            used.discard(old)
            used.add(new_type)
            if tr["name"].startswith(old):
                tr["name"] = new_type + tr["name"][len(old):]
            else:
                tr["name"] = G.unique_name(proj, new_type)
            if rule["regen_sound"] and not tr.get("lock_sound"):
                G.randomize_sound(proj, tr, random.Random(f"{proj.get('seed', 0)}-repl-{tr['name']}"))
            if not rule["keep_notes"] and not tr.get("lock_notes"):
                try:
                    c = G.Ctx(proj, cfg)
                    G.GEN[new_type](c, tr)
                    G.mutate_track(proj, cfg, tr, random.Random(f"{proj.get('seed', 0)}-replm-{tr['name']}"))
                except Exception:
                    pass
            elif rule["keep_notes"] and tr.get("notes") and not tr.get("lock_notes"):
                try:
                    from .generator import ROLE_REG, _shift_to_reg
                    lo, hi = ROLE_REG.get(role, (36, 72))
                    tr["notes"], _ = _shift_to_reg(tr["notes"], lo, hi, rng)
                except Exception:
                    pass
            events.append({"track": tr["name"], "from": old, "to": new_type, "role": role, "kind": "replace"})
            break

    # wymagane typy
    req_events = ensure_required(proj, policy, avail, rng)
    events.extend(req_events)

    seen = {}
    for tr in proj.get("tracks") or []:
        if tr["name"] in seen:
            tr["name"] = G.unique_name(proj, tr["type"])
        seen[tr["name"]] = True
    try:
        proj["tracks"] = G._order_tracks(proj["tracks"])
        proj["links"] = G.default_links(proj.get("style") or "Brostep", proj["tracks"])
    except Exception:
        pass
    proj["replace_rules"] = rules
    proj["replace_policy"] = policy
    proj["replace_report"] = events
    return events


def ensure_required(proj, policy, avail, rng):
    """Dodaje brakujące wymagane typy (allowed/required ∩ available)."""
    from . import core, generator as G

    policy = normalize_policy(policy)
    events = []
    have = {tr["type"] for tr in proj.get("tracks") or []}
    cfg = G.STYLES.get(proj.get("style") or "Brostep") or G.STYLES["Brostep"]
    for role, cfg_p in policy.items():
        for t in cfg_p.get("required") or []:
            if t not in avail or t in have:
                continue
            # spróbuj podmienić inny tor tej roli (nie-required, nie-skip)
            skip = set(cfg_p.get("skip") or [])
            required = set(cfg_p.get("required") or [])
            cand = [tr for tr in proj["tracks"]
                    if TYPE_TO_ROLE.get(tr["type"]) == role
                    and tr["type"] not in required
                    and tr["type"] not in skip
                    and not (tr.get("lock_sound") and tr.get("lock_notes"))]
            if cand:
                tr = rng.choice(cand)
                old = tr["type"]
                tr["type"] = t
                tr["plugin"] = core.PLUGIN_ID.get(t, tr.get("plugin"))
                tr["name"] = G.unique_name(proj, t)
                if not tr.get("lock_sound"):
                    try:
                        G.randomize_sound(proj, tr, random.Random(f"{proj.get('seed', 0)}-req-{t}"))
                    except Exception:
                        pass
                if not tr.get("lock_notes"):
                    try:
                        c = G.Ctx(proj, cfg)
                        G.GEN[t](c, tr)
                    except Exception:
                        pass
                events.append({"track": tr["name"], "from": old, "to": t, "role": role, "kind": "required_swap"})
            else:
                try:
                    tr = G.add_instance(proj, t)
                    events.append({"track": tr["name"], "from": None, "to": t, "role": role, "kind": "required_add"})
                except Exception:
                    try:
                        from .core import new_track, PLUGIN_ID
                        tr = new_track(G.unique_name(proj, t), t)
                        tr["plugin"] = PLUGIN_ID.get(t, tr.get("plugin"))
                        proj["tracks"].append(tr)
                        events.append({"track": tr["name"], "from": None, "to": t, "role": role, "kind": "required_add"})
                    except Exception:
                        pass
            have.add(t)
    return events
