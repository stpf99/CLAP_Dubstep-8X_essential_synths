"""plugin_modeler.py — karta modelowania pluginów CLAP.

Modelowanie oparte o słowa kluczowe (tagi). Z bazy tagów pobierane są zakresy
i typy OSC (kształtowanie fali). Przy wielu tagach wynik jest MULTITIMBRE
(osobne instancje / ścieżki), NIE wypadkową matematyczną parametrów.

Zasób OSC jest zunifikowany; nowe odmiany i rodzaje instrumentów można
dodawać do DEFINITIONS, testować, a potem kompilować w tle (make).

MIDI CC 0–127 mapowane na operatory (parametry silnika). Instancje L/R
zalecane parzyste (docelowo do 64 L + 64 R przez host / multitimbre).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import threading
from copy import deepcopy
from pathlib import Path

# ---------------------------------------------------------------------------
# Zunifikowany zasób wariantów OSC (kształtowanie fali)
# Indeksy zgodne z N_WAVE w ds_engine.h: 0=Sine 1=Triangle 2=Saw 3=Square 4=Noise 5=Metal
# ---------------------------------------------------------------------------
OSC_VARIANTS = {
    "sine": {
        "wave": 0, "morph": (0.0, 0.15), "desc": "Czysta sinusoida / sub",
        "tags": ["sub", "pure", "sine", "bass", "soft"],
        "typical": ["sub", "theremin", "pad"],
    },
    "triangle": {
        "wave": 1, "morph": (0.0, 0.35), "desc": "Trójkąt – miękki, harmonicznie ubogi",
        "tags": ["triangle", "soft", "flute", "pad", "keys"],
        "typical": ["piano", "panflute", "choir", "organ"],
    },
    "saw": {
        "wave": 2, "morph": (0.0, 0.45), "desc": "Piła – bogata, uniwersalna",
        "tags": ["saw", "bright", "lead", "bass", "supersaw", "reese", "brass"],
        "typical": ["wobble", "reese", "supersaw", "brass", "strings", "neuro"],
    },
    "square": {
        "wave": 3, "morph": (0.0, 0.4), "desc": "Prostokąt / pulse (PW)",
        "tags": ["square", "pulse", "pwm", "organ", "acid", "retro"],
        "typical": ["acid", "organ", "pulse", "hollow"],
    },
    "noise": {
        "wave": 4, "morph": (0.0, 0.1), "desc": "Szum – perkusja / FX / sweeps",
        "tags": ["noise", "fx", "perc", "riser", "sweep", "snare", "hat"],
        "typical": ["snare", "hat", "clap", "riser", "noisesweep", "shaker"],
    },
    "metal": {
        "wave": 5, "morph": (0.0, 0.25), "desc": "Metal (6 partiali 808-like) – dzwony, haty",
        "tags": ["metal", "bell", "clang", "hat", "perc", "industrial"],
        "typical": ["hat", "bell", "crash", "rim"],
    },
    "fm": {
        "wave": 2, "morph": (0.15, 0.5), "desc": "FM (modulator na saw/square)",
        "tags": ["fm", "growl", "screech", "metallic", "lead", "bass"],
        "typical": ["growl", "screech", "fmbass", "zap"],
        "extra": {"FM Amount": (0.25, 0.7), "FM Ratio": (1.0, 4.0)},
    },
    "formant": {
        "wave": 2, "morph": (0.2, 0.55), "desc": "Formanty / samogłoski",
        "tags": ["formant", "vowel", "growl", "vox", "choir", "talk"],
        "typical": ["growl", "vox", "choir", "speak"],
        "extra": {"Formant Mix": (0.5, 0.95), "Vowel": (0.0, 4.0)},
    },
    "modal": {
        "wave": 0, "morph": (0.0, 0.1), "desc": "Synteza modalna (handpan / tongue)",
        "tags": ["modal", "handpan", "tongue", "physical", "perc", "melodic"],
        "typical": ["handpan", "tongue"],
        "extra": {"Ring Time": (0.3, 0.9), "Strike Brightness": (0.3, 0.8)},
    },
}

# Mapowanie nazw parametrów hosta → (enum-ish id, preferowany CC)
# CC 0–127; rezerwujemy typowe (1=mod, 7=vol, 10=pan, 11=expr, 64=sustain…)
PARAM_CC_MAP = {
    "Waveform": 20,
    "Wave Morph": 21,
    "Attack": 73,
    "Decay": 75,
    "Sustain": 79,
    "Release": 72,
    "Glide": 5,
    "Tune": 76,
    "Fine": 77,
    "Key Track": 78,
    "Unison Voices": 22,
    "Unison Detune": 23,
    "Stereo Width": 24,
    "Sub Osc": 25,
    "Noise": 26,
    "Noise Decay": 27,
    "Noise Highpass": 28,
    "FM Amount": 29,
    "FM Ratio": 30,
    "Formant Mix": 31,
    "Vowel": 32,
    "Filter Type": 33,
    "Cutoff": 74,
    "Resonance": 71,
    "Filter Env": 34,
    "Filter Decay": 35,
    "LFO Sync": 36,
    "LFO Rate": 37,
    "LFO Div": 38,
    "LFO Shape": 39,
    "LFO to Cutoff": 40,
    "LFO to Vowel": 41,
    "LFO to FM": 42,
    "LFO to Pitch": 43,
    "Pitch Env": 44,
    "Pitch Decay": 45,
    "Drive": 46,
    "Level": 7,
    "Tone Level": 47,
    "Pulse Width": 48,
    "Ring Time": 49,
    "Strike Brightness": 50,
    "Input Mix": 51,
}

# Baza słów kluczowych → preferowane OSC + zakresy parametrów + rola
# Przy wielu tagach: lista instancji (multitimbre), nie średnia.
KEYWORD_DB = {
    # basy
    "sub": {"osc": ["sine"], "role": "bass", "params": {"Cutoff": (0.15, 0.4), "Sub Osc": (0.0, 0.4), "Drive": (0.05, 0.25), "Level": (0.7, 0.9)}},
    "wobble": {"osc": ["saw"], "role": "bass", "params": {"Cutoff": (0.2, 0.55), "LFO to Cutoff": (0.5, 1.0), "Resonance": (0.3, 0.7), "Unison Voices": (2, 4)}},
    "reese": {"osc": ["saw"], "role": "bass", "params": {"Unison Voices": (3, 6), "Unison Detune": (0.15, 0.4), "Cutoff": (0.35, 0.65)}},
    "neuro": {"osc": ["saw", "fm"], "role": "bass", "params": {"FM Amount": (0.2, 0.55), "Cutoff": (0.25, 0.5), "Drive": (0.3, 0.6)}},
    "growl": {"osc": ["fm", "formant"], "role": "bass", "params": {"FM Amount": (0.35, 0.7), "Formant Mix": (0.6, 0.95), "LFO to Vowel": (0.4, 0.9)}},
    "acid": {"osc": ["square"], "role": "bass", "params": {"Pulse Width": (0.2, 0.45), "Resonance": (0.55, 0.85), "Filter Env": (0.6, 1.0), "Drive": (0.3, 0.55)}},
    "fmbass": {"osc": ["fm"], "role": "bass", "params": {"FM Amount": (0.3, 0.65), "FM Ratio": (1.5, 3.5), "Cutoff": (0.3, 0.55)}},
    # lead / stab
    "lead": {"osc": ["saw", "square"], "role": "lead", "params": {"Cutoff": (0.5, 0.85), "Attack": (0.0, 0.08), "Unison Voices": (2, 5)}},
    "screech": {"osc": ["fm", "saw"], "role": "lead", "params": {"FM Amount": (0.4, 0.8), "Unison Voices": (4, 7), "Filter Env": (0.5, 1.0)}},
    "stab": {"osc": ["saw", "square"], "role": "lead", "params": {"Decay": (0.1, 0.3), "Attack": (0.0, 0.05), "Drive": (0.15, 0.4)}},
    "pluck": {"osc": ["triangle", "saw"], "role": "lead", "params": {"Attack": (0.0, 0.03), "Decay": (0.15, 0.45), "Sustain": (0.0, 0.25)}},
    "pulse": {"osc": ["square"], "role": "lead", "params": {"Pulse Width": (0.15, 0.4), "Resonance": (0.4, 0.7), "LFO Rate": (0.3, 0.7)}},
    "supersaw": {"osc": ["saw"], "role": "lead", "params": {"Unison Voices": (5, 7), "Unison Detune": (0.2, 0.45), "Stereo Width": (0.6, 0.95)}},
    # pad / harmoniczne
    "pad": {"osc": ["saw", "triangle"], "role": "pad", "params": {"Attack": (0.2, 0.5), "Release": (0.4, 0.8), "Unison Voices": (4, 7), "Stereo Width": (0.6, 0.95)}},
    "strings": {"osc": ["saw"], "role": "pad", "params": {"Attack": (0.3, 0.55), "Release": (0.5, 0.85), "Unison Detune": (0.15, 0.35)}},
    "choir": {"osc": ["formant", "triangle"], "role": "pad", "params": {"Formant Mix": (0.7, 0.95), "Attack": (0.25, 0.5), "Unison Voices": (5, 7)}},
    "organ": {"osc": ["square"], "role": "pad", "params": {"Pulse Width": (0.25, 0.45), "Sub Osc": (0.1, 0.3), "Sustain": (0.85, 1.0)}},
    "brass": {"osc": ["saw", "formant"], "role": "pad", "params": {"Attack": (0.08, 0.2), "Formant Mix": (0.3, 0.6), "Filter Env": (0.4, 0.8)}},
    "hollow": {"osc": ["square", "triangle"], "role": "pad", "params": {"Cutoff": (0.3, 0.55), "Resonance": (0.15, 0.4)}},
    # keys / perc melodic
    "piano": {"osc": ["triangle"], "role": "lead", "params": {"Attack": (0.0, 0.05), "Decay": (0.4, 0.7), "Sustain": (0.15, 0.35), "Noise": (0.02, 0.08)}},
    "bell": {"osc": ["metal"], "role": "lead", "params": {"Attack": (0.0, 0.03), "Decay": (0.5, 0.9), "Noise": (0.1, 0.25), "Sustain": (0.0, 0.1)}},
    "handpan": {"osc": ["modal"], "role": "lead", "params": {"Ring Time": (0.4, 0.8), "Strike Brightness": (0.4, 0.75)}},
    "tongue": {"osc": ["modal"], "role": "lead", "params": {"Ring Time": (0.25, 0.55), "Strike Brightness": (0.35, 0.7)}},
    # fx
    "riser": {"osc": ["noise", "saw"], "role": "fx", "params": {"Attack": (0.3, 0.7), "LFO to Cutoff": (0.5, 1.0), "Noise": (0.4, 0.9)}},
    "zap": {"osc": ["fm", "noise"], "role": "fx", "params": {"Decay": (0.1, 0.3), "FM Amount": (0.3, 0.7), "Attack": (0.0, 0.05)}},
    "boom": {"osc": ["sine", "noise"], "role": "fx", "params": {"Decay": (0.3, 0.6), "Sub Osc": (0.3, 0.7), "Noise": (0.2, 0.5)}},
    "sweep": {"osc": ["noise"], "role": "fx", "params": {"Noise": (0.7, 1.0), "LFO to Cutoff": (0.6, 1.0), "Filter Type": (0.6, 1.0)}},
    "noisesweep": {"osc": ["noise"], "role": "fx", "params": {"Noise": (0.8, 1.0), "LFO to Cutoff": (0.7, 1.0)}},
    # vocal
    "vox": {"osc": ["formant"], "role": "vocal", "params": {"Formant Mix": (0.6, 0.9), "Attack": (0.1, 0.3)}},
    "speak": {"osc": ["formant"], "role": "vocal", "params": {"Formant Mix": (0.7, 0.95)}},
    # perkusja (keywords)
    "kick": {"osc": ["sine"], "role": "drums", "params": {"Attack": (0.0, 0.02), "Decay": (0.15, 0.4), "Pitch Env": (0.4, 0.9)}},
    "snare": {"osc": ["noise", "triangle"], "role": "drums", "params": {"Noise": (0.5, 0.9), "Decay": (0.1, 0.35)}},
    "hat": {"osc": ["metal", "noise"], "role": "drums", "params": {"Noise": (0.3, 0.7), "Decay": (0.05, 0.2)}},
    "clap": {"osc": ["noise"], "role": "drums", "params": {"Noise": (0.6, 0.95), "Decay": (0.08, 0.25)}},
    # ogólne deskryptory
    "bright": {"osc": ["saw", "square"], "role": None, "params": {"Cutoff": (0.6, 0.95), "Drive": (0.1, 0.35)}},
    "dark": {"osc": ["saw", "sine"], "role": None, "params": {"Cutoff": (0.15, 0.4), "Tone Level": (0.3, 0.6)}},
    "wide": {"osc": ["saw"], "role": None, "params": {"Stereo Width": (0.7, 1.0), "Unison Voices": (4, 7)}},
    "narrow": {"osc": [], "role": None, "params": {"Stereo Width": (0.0, 0.3), "Unison Voices": (1, 2)}},
    "soft": {"osc": ["sine", "triangle"], "role": None, "params": {"Drive": (0.0, 0.15), "Attack": (0.1, 0.4)}},
    "aggressive": {"osc": ["saw", "fm"], "role": None, "params": {"Drive": (0.4, 0.8), "Resonance": (0.4, 0.75)}},
    "long": {"osc": [], "role": None, "params": {"Release": (0.5, 0.9), "Attack": (0.2, 0.5)}},
    "short": {"osc": [], "role": None, "params": {"Decay": (0.08, 0.25), "Release": (0.05, 0.2), "Sustain": (0.0, 0.2)}},
}

# Istniejące bazy CLAP (id bez prefixu) – do dopasowania przy spawn
BASE_INSTRUMENTS = {
    "sub", "wobble", "reese", "growl", "screech", "kick", "snare", "hat", "clap",
    "rim", "tom", "crash", "shaker", "fmbass", "neuro", "hollow", "supersaw",
    "pluck", "pad", "stab", "riser", "boom", "zap", "vox", "speak", "theremin",
    "panflute", "handpan", "tongue", "piano", "acid", "strings",
    "organ", "brass", "bell", "choir", "pulse", "noisesweep",
}

ROLE_TO_DEFAULT_BASE = {
    "bass": "wobble",
    "lead": "supersaw",
    "pad": "pad",
    "drums": "hat",
    "fx": "zap",
    "vocal": "vox",
}


def tokenize_keywords(text: str) -> list[str]:
    """Rozbija tekst na tokeny (małe litery, alfanumeryczne + myślniki)."""
    if not text:
        return []
    tokens = re.findall(r"[a-zA-Z0-9_\-]+", text.lower())
    return [t for t in tokens if t]


def lookup_keywords(tokens: list[str]) -> list[dict]:
    """Zwraca listę wpisów KEYWORD_DB dla rozpoznanych tokenów (kolejność zachowana)."""
    found = []
    seen = set()
    for t in tokens:
        if t in KEYWORD_DB and t not in seen:
            found.append({"key": t, **KEYWORD_DB[t]})
            seen.add(t)
        # proste synonimy / skróty
        elif t in ("bass", "bas") and "sub" not in seen:
            found.append({"key": "sub", **KEYWORD_DB["sub"]})
            seen.add("sub")
        elif t in ("lead", "melody", "mel") and "lead" not in seen:
            found.append({"key": "lead", **KEYWORD_DB["lead"]})
            seen.add("lead")
    return found


def pick_osc_for_entry(entry: dict) -> dict:
    """Wybiera wariant OSC z listy preferowanych."""
    osc_keys = entry.get("osc") or []
    for k in osc_keys:
        if k in OSC_VARIANTS:
            return {"name": k, **OSC_VARIANTS[k]}
    return {"name": "saw", **OSC_VARIANTS["saw"]}


def build_multitimbre_spec(keywords: str, max_layers: int = 8) -> dict:
    """
    Z słów kluczowych buduje specyfikację MULTITIMBRE.
    Każdy rozpoznany tag → osobna warstwa (instancja), nie średnia parametrów.
    Zwraca:
      {
        "tokens": [...],
        "layers": [ {key, role, osc, base, params, cc_map}, ... ],
        "stereo_pairs": bool,   # zalecane parzyste L/R
        "suggested_instances_lr": (n_l, n_r),
      }
    """
    tokens = tokenize_keywords(keywords)
    entries = lookup_keywords(tokens)
    if not entries:
        # fallback: jeden layer saw lead
        entries = [{"key": "lead", **KEYWORD_DB["lead"]}]

    layers = []
    for e in entries[:max_layers]:
        osc = pick_osc_for_entry(e)
        role = e.get("role")
        # baza instrumentu: najpierw exact key jeśli jest w BASE, potem typical z OSC, potem rola
        base = e["key"] if e["key"] in BASE_INSTRUMENTS else None
        if not base:
            for t in osc.get("typical") or []:
                if t in BASE_INSTRUMENTS:
                    base = t
                    break
        if not base and role:
            base = ROLE_TO_DEFAULT_BASE.get(role, "pad")
        if not base:
            base = "pad"

        params = dict(e.get("params") or {})
        # dołóż zakresy z OSC.extra jeśli są
        for k, v in (osc.get("extra") or {}).items():
            if k not in params:
                params[k] = v
        # wave / morph z OSC
        params.setdefault("Waveform", (osc["wave"], osc["wave"]))  # stały
        if "morph" in osc:
            params.setdefault("Wave Morph", osc["morph"])

        cc = {name: PARAM_CC_MAP[name] for name in params if name in PARAM_CC_MAP}

        layers.append({
            "key": e["key"],
            "role": role or "lead",
            "osc_name": osc["name"],
            "osc_desc": osc.get("desc", ""),
            "wave": osc["wave"],
            "base": base,
            "params": params,
            "cc_map": cc,
        })

    n = len(layers)
    # parzyste instancje L/R: min 1 para, docelowo do 64+64
    n_pairs = max(1, min(64, (n + 1) // 2 * 2 // 2))  # co najmniej 1, zaokrąglone
    if n == 1:
        n_l, n_r = 1, 1  # mono-stereo pair
    else:
        n_l = min(64, (n + 1) // 2)
        n_r = min(64, n // 2)
        if n_r == 0:
            n_r = 1

    return {
        "tokens": tokens,
        "layers": layers,
        "stereo_pairs": True,
        "suggested_instances_lr": (n_l, n_r),
        "max_cc_operators": min(128, len(PARAM_CC_MAP)),
    }


def sample_layer_params(layer: dict, rng) -> dict:
    """Losuje konkretne wartości z zakresów warstwy (do preview / spawn)."""
    out = {}
    for name, val in (layer.get("params") or {}).items():
        if isinstance(val, (list, tuple)) and len(val) == 2:
            a, b = float(val[0]), float(val[1])
            if a == b:
                out[name] = a
            else:
                out[name] = rng.uniform(min(a, b), max(a, b))
        else:
            out[name] = float(val)
    return out


def cc_table_for_spec(spec: dict) -> list[dict]:
    """Płaska tabela CC dla UI: {cc, param, layer_key, lo, hi}."""
    rows = []
    used = set()
    for layer in spec.get("layers") or []:
        for param, rng in (layer.get("params") or {}).items():
            cc = layer.get("cc_map", {}).get(param) or PARAM_CC_MAP.get(param)
            if cc is None or cc in used:
                # znajdź wolny CC 20–119
                for c in range(20, 120):
                    if c not in used and c not in (32,):  # unikaj bank
                        cc = c
                        break
            if cc is None:
                continue
            used.add(cc)
            lo, hi = (rng[0], rng[1]) if isinstance(rng, (list, tuple)) and len(rng) == 2 else (0.0, 1.0)
            rows.append({
                "cc": int(cc),
                "param": param,
                "layer": layer.get("key", ""),
                "base": layer.get("base", ""),
                "lo": float(lo),
                "hi": float(hi),
            })
    rows.sort(key=lambda r: r["cc"])
    return rows


# ---------------------------------------------------------------------------
# Definicje użytkownika (JSON) – po teście można dodać i skompilować w tle
# ---------------------------------------------------------------------------
USER_DEFS_PATH = Path(os.path.expanduser("~/.config/ds-studio/user_plugin_defs.json"))
# fallback lokalny w projekcie
def _local_defs_path() -> Path:
    here = Path(__file__).resolve().parent.parent
    return here / "user_plugin_defs.json"


def load_user_defs() -> list[dict]:
    for p in (USER_DEFS_PATH, _local_defs_path()):
        if p.is_file():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
    return []


def save_user_def(entry: dict) -> Path:
    """Dodaje wpis do definicji użytkownika. entry: name, id, base, params, keywords, layers…"""
    defs = load_user_defs()
    # nadpisz po id jeśli istnieje
    eid = entry.get("id") or entry.get("name", "").lower().replace(" ", "_")
    entry = dict(entry)
    entry["id"] = eid
    defs = [d for d in defs if d.get("id") != eid]
    defs.append(entry)
    path = USER_DEFS_PATH
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(defs, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        path = _local_defs_path()
        path.write_text(json.dumps(defs, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def generate_typedef_snippet(entry: dict) -> str:
    """Generuje szkic TypeDef C++ do wklejenia / diffu w ds_engine.h."""
    name = entry.get("name") or "Custom"
    slug = re.sub(r"[^a-z0-9]+", "", (entry.get("id") or name).lower())
    base = entry.get("base") or "pad"
    desc = entry.get("desc") or f"User model: {name}"
    wave = 2
    layers = entry.get("layers") or []
    if layers:
        wave = layers[0].get("wave", 2)
    return f'''    // user model: {name}
    {{"stpf99.dubstep.{slug}", "DS {name}", "{desc}", false, 261.6256f,
     {{P_WAVE,{wave}}}, {{P_KEYTRK,1}}, false, false, 0}},  // TODO: dopisz full Init z karty modelowania
'''


_compile_lock = threading.Lock()
_compile_status = {"running": False, "log": "", "ok": None}


def compile_status() -> dict:
    return dict(_compile_status)


def compile_in_background(project_root: str | Path | None = None, target: str = "all") -> None:
    """Uruchamia `make` w tle (JIT-like po teście / aktualizacji definicji)."""
    root = Path(project_root) if project_root else Path(__file__).resolve().parent.parent
    if not (root / "Makefile").is_file():
        _compile_status.update(running=False, log="Brak Makefile", ok=False)
        return

    def _run():
        with _compile_lock:
            if _compile_status["running"]:
                return
            _compile_status.update(running=True, log="Kompilacja…", ok=None)
        try:
            r = subprocess.run(
                ["make", "-j", str(os.cpu_count() or 2), target],
                cwd=str(root),
                capture_output=True,
                text=True,
                timeout=300,
            )
            log = (r.stdout or "") + (r.stderr or "")
            _compile_status.update(running=False, log=log[-4000:], ok=(r.returncode == 0))
        except Exception as ex:
            _compile_status.update(running=False, log=str(ex), ok=False)

    threading.Thread(target=_run, daemon=True).start()


# ---------------------------------------------------------------------------
# MIDI (mido) – lista portów USB / wirtualnych
# ---------------------------------------------------------------------------
def list_midi_inputs() -> list[str]:
    try:
        import mido
        return list(mido.get_input_names())
    except Exception:
        return []


def list_midi_outputs() -> list[str]:
    try:
        import mido
        return list(mido.get_output_names())
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Piano-roll helper (siatka nut do preview)
# ---------------------------------------------------------------------------
def empty_piano_roll(bars: int = 2, ppq: int = 4) -> list[dict]:
    """Pusta siatka: lista eventów {bar, step, note, vel, dur_steps}."""
    return []


def add_note(roll: list, bar: int, step: int, note: int, vel: int = 100, dur: int = 1) -> list:
    roll = list(roll)
    roll.append({"bar": bar, "step": step, "note": max(0, min(127, note)),
                 "vel": max(1, min(127, vel)), "dur": max(1, dur)})
    return roll


def roll_to_midi_notes(roll: list, channel: int = 0) -> list[tuple]:
    """(tick, type, note, vel, ch) – tick w 1/16."""
    events = []
    for e in roll:
        tick = e["bar"] * 16 + e["step"]
        events.append((tick, "note_on", e["note"], e["vel"], channel))
        events.append((tick + e.get("dur", 1), "note_off", e["note"], 0, channel))
    events.sort(key=lambda x: (x[0], 0 if x[1] == "note_off" else 1))
    return events
