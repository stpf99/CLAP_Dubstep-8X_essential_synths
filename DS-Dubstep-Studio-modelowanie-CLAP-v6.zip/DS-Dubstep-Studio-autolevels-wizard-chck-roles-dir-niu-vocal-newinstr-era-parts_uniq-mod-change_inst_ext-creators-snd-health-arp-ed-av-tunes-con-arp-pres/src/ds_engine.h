// ds_engine.h — wspólny silnik "DS Dubstep Kit" (CLAP, bez GUI)
// Jeden silnik, 8 typów wtyczek. Każdy typ eksponuje tylko swój podzbiór parametrów
// (reszta = stałe ukryte), a host (Bitwig) rysuje generyczne suwaki.
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "ds_speech.h"

namespace ds {

// ---------------------------------------------------------------- parametry
enum Param {
  P_WAVE, P_MORPH, P_ATK, P_DEC, P_SUS, P_REL, P_GLIDE, P_TUNE, P_FINE, P_KEYTRK,
  P_UNISON, P_DETUNE, P_WIDTH, P_SUB, P_NOISE, P_NDEC, P_NCUT, P_NBURST,
  P_FM, P_FMRATIO, P_FORM, P_VOWEL,
  P_FTYPE, P_CUTOFF, P_RESO, P_FENV, P_FDEC,
  P_LFO_SYNC, P_LFO_RATE, P_LFO_DIV, P_LFO_SHAPE, P_LFO_CUT, P_LFO_VOW, P_LFO_FM, P_LFO_PIT,
  P_PENV, P_PDEC, P_DRIVE, P_LEVEL,
  P_TONE, P_NLP, P_RTIME, P_RCUT, P_RPIT, P_RVOL, P_PW,   // dopisane w v2 (ID-ki starych parametrów bez zmian)
  P_SP_MODE, P_SP_BANK, P_SP_SPEED, P_SP_MORPH, P_SP_DIALECT, P_SP_RANGE, P_SP_INTON, P_SP_SCALE, P_SP_TRACT, P_SP_HOLD, P_SP_BREATH,  // v3: DS Speak
  P_IN, P_RING, P_NKEY, P_BRIGHT,  // v4: wejście audio (instrument jako filtr), modalne (handpan/tongue), szum śledzący wysokość
  NP
};

enum Kind { LIN, LOG, INT };  // LOG: wartość CLAP 0..1, silnik lo*(hi/lo)^v

struct ParamInfo {
  const char* name; const char* group; Kind kind;
  float lo, hi, def; const char* unit; const char* const* names;
};

inline const char* const N_WAVE[]  = {"Sine", "Triangle", "Saw", "Square", "Noise", "Metal"};
inline const char* const N_FTYPE[] = {"Lowpass", "Bandpass", "Highpass"};
inline const char* const N_SYNC[]  = {"Free", "Tempo"};
inline const char* const N_DIV[]   = {"2/1", "1/1", "1/2.", "1/2", "1/4.", "1/4", "1/8.", "1/4T",
                                      "1/8", "1/8T", "1/16", "1/16T", "1/32"};
inline const float DIV_BEATS[13]   = {8, 4, 3, 2, 1.5f, 1, 0.75f, 2.f / 3, 0.5f, 1.f / 3, 0.25f, 1.f / 6, 0.125f};
inline const char* const N_SHAPE[] = {"Sine", "Triangle", "Saw Down", "Square", "Sample&Hold"};
inline const char* const N_SPMODE[]  = {"Sequence", "Key Select", "Letters"};
inline const char* const N_SPBANK[]  = {"Custom Text", "Dubstep", "Hype", "Countdown"};
inline const char* const N_DIALECT[] = {"Neutral", "Bright", "Dark", "Tonal", "Robot"};
inline const char* const N_SPSCALE[] = {"Free", "Minor", "Major", "Phrygian", "Pentatonic"};
inline const char* const N_OFFON[]   = {"Off", "On"};

inline const ParamInfo PI[NP] = {
  /*WAVE*/    {"Waveform",        "Oscillator", INT, 0, 5, 2, "", N_WAVE},
  /*MORPH*/   {"Wave Morph",      "Oscillator", LIN, 0, 1, 0, "", nullptr},
  /*ATK*/     {"Attack",          "Amp Env",    LOG, 0.5f, 4000, 3, "ms", nullptr},
  /*DEC*/     {"Decay",           "Amp Env",    LOG, 5, 8000, 300, "ms", nullptr},
  /*SUS*/     {"Sustain",         "Amp Env",    LIN, 0, 1, 0.8f, "", nullptr},
  /*REL*/     {"Release",         "Amp Env",    LOG, 5, 8000, 120, "ms", nullptr},
  /*GLIDE*/   {"Glide",           "Pitch",      LIN, 0, 1000, 0, "ms", nullptr},
  /*TUNE*/    {"Tune",            "Pitch",      LIN, -36, 36, 0, "st", nullptr},
  /*FINE*/    {"Fine",            "Pitch",      LIN, -100, 100, 0, "ct", nullptr},
  /*KEYTRK*/  {"Key Track",       "Pitch",      LIN, 0, 1, 1, "", nullptr},
  /*UNISON*/  {"Unison Voices",   "Oscillator", INT, 1, 7, 1, "", nullptr},
  /*DETUNE*/  {"Unison Detune",   "Oscillator", LIN, 0, 100, 15, "ct", nullptr},
  /*WIDTH*/   {"Stereo Width",    "Oscillator", LIN, 0, 1, 0.5f, "", nullptr},
  /*SUB*/     {"Sub Osc",         "Oscillator", LIN, 0, 1, 0, "", nullptr},
  /*NOISE*/   {"Noise",           "Noise",      LIN, 0, 1, 0, "", nullptr},
  /*NDEC*/    {"Noise Decay",     "Noise",      LOG, 2, 2000, 100, "ms", nullptr},
  /*NCUT*/    {"Noise Highpass",  "Noise",      LOG, 100, 16000, 100, "Hz", nullptr},
  /*NBURST*/  {"Noise Bursts",    "Noise",      INT, 1, 5, 1, "", nullptr},
  /*FM*/      {"FM Amount",       "FM",         LIN, 0, 1, 0, "", nullptr},
  /*FMRATIO*/ {"FM Ratio",        "FM",         LIN, 0.25f, 12, 2, "x", nullptr},
  /*FORM*/    {"Formant Mix",     "Formant",    LIN, 0, 1, 0, "", nullptr},
  /*VOWEL*/   {"Vowel A-E-I-O-U", "Formant",    LIN, 0, 4, 0, "", nullptr},
  /*FTYPE*/   {"Filter Type",     "Filter",     INT, 0, 2, 0, "", N_FTYPE},
  /*CUTOFF*/  {"Cutoff",          "Filter",     LOG, 20, 20000, 20000, "Hz", nullptr},
  /*RESO*/    {"Resonance",       "Filter",     LIN, 0, 1, 0.1f, "", nullptr},
  /*FENV*/    {"Filter Env Amt",  "Filter",     LIN, -6, 6, 0, "oct", nullptr},
  /*FDEC*/    {"Filter Env Decay","Filter",     LOG, 5, 4000, 300, "ms", nullptr},
  /*LFO_SYNC*/{"LFO Sync",        "LFO",        INT, 0, 1, 1, "", N_SYNC},
  /*LFO_RATE*/{"LFO Rate",        "LFO",        LOG, 0.05f, 40, 2, "Hz", nullptr},
  /*LFO_DIV*/ {"LFO Division",    "LFO",        INT, 0, 12, 8, "", N_DIV},
  /*LFO_SHAPE*/{"LFO Shape",      "LFO",        INT, 0, 4, 0, "", N_SHAPE},
  /*LFO_CUT*/ {"LFO > Cutoff",    "LFO",        LIN, -6, 6, 0, "oct", nullptr},
  /*LFO_VOW*/ {"LFO > Vowel",     "LFO",        LIN, -4, 4, 0, "", nullptr},
  /*LFO_FM*/  {"LFO > FM",        "LFO",        LIN, -1, 1, 0, "", nullptr},
  /*LFO_PIT*/ {"LFO > Pitch",     "LFO",        LIN, -12, 12, 0, "st", nullptr},
  /*PENV*/    {"Pitch Env Amt",   "Pitch",      LIN, -24, 60, 0, "st", nullptr},
  /*PDEC*/    {"Pitch Env Decay", "Pitch",      LOG, 3, 800, 40, "ms", nullptr},
  /*DRIVE*/   {"Drive",           "Output",     LIN, 0, 1, 0, "", nullptr},
  /*LEVEL*/   {"Level",           "Output",     LIN, 0, 1, 0.8f, "", nullptr},
  /*TONE*/    {"Tone Level",      "Oscillator", LIN, 0, 1, 1, "", nullptr},
  /*NLP*/     {"Noise Lowpass",   "Noise",      LOG, 200, 20000, 20000, "Hz", nullptr},
  /*RTIME*/   {"Ramp Time",       "Ramp",       LOG, 200, 16000, 2000, "ms", nullptr},
  /*RCUT*/    {"Ramp > Cutoff",   "Ramp",       LIN, -6, 6, 0, "oct", nullptr},
  /*RPIT*/    {"Ramp > Pitch",    "Ramp",       LIN, -48, 48, 0, "st", nullptr},
  /*RVOL*/    {"Ramp > Level",    "Ramp",       LIN, 0, 1, 0, "", nullptr},
  /*PW*/      {"Pulse Width",     "Oscillator", LIN, 0.05f, 0.5f, 0.5f, "", nullptr},
  /*SP_MODE*/ {"Text Advance",    "Speech",     INT, 0, 2, 0, "", N_SPMODE},
  /*SP_BANK*/ {"Text Bank",       "Speech",     INT, 0, 3, 0, "", N_SPBANK},
  /*SP_SPEED*/{"Speech Speed",    "Speech",     LIN, 0.4f, 2.5f, 1, "x", nullptr},
  /*SP_MORPH*/{"Morph Time",      "Speech",     LOG, 4, 200, 35, "ms", nullptr},
  /*SP_DIAL*/ {"Dialect",         "Speech",     INT, 0, 4, 0, "", N_DIALECT},
  /*SP_RANGE*/{"Letter Pitch Range","Speech",   LIN, 0, 24, 4, "st", nullptr},
  /*SP_INTON*/{"Intonation",      "Speech",     LIN, 0, 1, 0.5f, "", nullptr},
  /*SP_SCALE*/{"Pitch Scale",     "Speech",     INT, 0, 4, 0, "", N_SPSCALE},
  /*SP_TRACT*/{"Formant Shift",   "Speech",     LIN, -12, 12, 0, "st", nullptr},
  /*SP_HOLD*/ {"Hold Vowel",      "Speech",     INT, 0, 1, 1, "", N_OFFON},
  /*SP_BREATH*/{"Breath",         "Speech",     LIN, 0, 1, 0.1f, "", nullptr},
  /*IN*/      {"Input Mix",       "Input",      LIN, 0, 1, 0, "", nullptr},
  /*RING*/    {"Ring Time",       "Modal",      LOG, 80, 8000, 1500, "ms", nullptr},
  /*NKEY*/    {"Noise Key Track", "Noise",      LIN, 0, 1, 0, "", nullptr},
  /*BRIGHT*/  {"Strike Brightness","Modal",     LIN, 0, 1, 0.6f, "", nullptr},
};

inline float toEng(int p, double cv) {
  const ParamInfo& pi = PI[p];
  if (pi.kind == LOG) {
    cv = std::min(1.0, std::max(0.0, cv));
    return pi.lo * std::pow(pi.hi / pi.lo, (float)cv);
  }
  float v = (float)std::min((double)pi.hi, std::max((double)pi.lo, cv));
  return pi.kind == INT ? std::round(v) : v;
}
inline double toClap(int p, float ev) {
  const ParamInfo& pi = PI[p];
  if (pi.kind == LOG) {
    ev = std::min(pi.hi, std::max(pi.lo, ev));
    return std::log(ev / pi.lo) / std::log(pi.hi / pi.lo);
  }
  return std::min(pi.hi, std::max(pi.lo, ev));
}

// ---------------------------------------------------------------- definicje wtyczek
struct Init { int p; float v; };
struct TypeDef {
  const char* id; const char* name; const char* desc;
  bool oneshot;      // perkusja: ignoruje note-off, zawsze retrigger (choke)
  float ref;         // częstotliwość odniesienia (Hz) dla nuty 60 przy KEYTRK=1
  std::vector<Init> ex;   // parametry eksponowane (kolejność = kolejność w hoście) + defaulty
  std::vector<Init> hid;  // ukryte stałe
  bool retrig = false;    // zawsze retrigger obwiedni (pluck/stab/vox), bez legato
  bool speech = false;    // DS Speak: nuta = słowo/fonem z tekstu, syntezator formantowy
  int modal = 0;          // 1 = handpan, 2 = tongue drum: bank częstotliwości własnych (synteza modalna)
  void defaults(float* out) const {
    for (int i = 0; i < NP; i++) out[i] = PI[i].def;
    for (auto& h : hid) out[h.p] = h.v;
    for (auto& e : ex) out[e.p] = e.v;
  }
};

inline const std::vector<TypeDef>& types() {
  static const std::vector<TypeDef> T = {
    // ---- 0: SUB — czysty podkład sinusoidalny, mono, glide
    {"stpf99.dubstep.sub", "DS Sub", "Sub bass: sine/tri, mono glide, soft drive", false, 261.6256f,
     {{P_WAVE,0},{P_MORPH,0},{P_ATK,3},{P_DEC,200},{P_SUS,1},{P_REL,90},{P_GLIDE,40},{P_TUNE,0},{P_FINE,0},
      {P_SUB,0},{P_CUTOFF,900},{P_DRIVE,0.15f},{P_LEVEL,0.85f}},
     {{P_KEYTRK,1},{P_UNISON,1},{P_RESO,0},{P_FTYPE,0}}},
    // ---- 1: WOBBLE — saw + filtr LP z LFO zsynchronizowanym do tempa
    {"stpf99.dubstep.wobble", "DS Wobble", "Wobble bass: saw unison + tempo-synced LFO filter", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0},{P_ATK,2},{P_DEC,400},{P_SUS,1},{P_REL,120},{P_GLIDE,30},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,2},{P_DETUNE,14},{P_WIDTH,0.4f},{P_SUB,0.3f},{P_CUTOFF,450},{P_RESO,0.5f},
      {P_LFO_SYNC,1},{P_LFO_RATE,2},{P_LFO_DIV,8},{P_LFO_SHAPE,0},{P_LFO_CUT,3.5f},{P_DRIVE,0.4f},{P_LEVEL,0.75f}},
     {{P_KEYTRK,1},{P_FTYPE,0},{P_FENV,0}}},
    // ---- 2: REESE — rozstrojone piły, wolny ruch filtra
    {"stpf99.dubstep.reese", "DS Reese", "Reese bass: detuned saws, slow phasing filter", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0},{P_ATK,4},{P_DEC,300},{P_SUS,1},{P_REL,150},{P_GLIDE,60},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,3},{P_DETUNE,22},{P_WIDTH,0.45f},{P_SUB,0.35f},{P_CUTOFF,1800},{P_RESO,0.15f},
      {P_LFO_SYNC,0},{P_LFO_RATE,0.25f},{P_LFO_DIV,3},{P_LFO_SHAPE,1},{P_LFO_CUT,1.5f},{P_DRIVE,0.5f},{P_LEVEL,0.7f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}},
    // ---- 3: GROWL — FM + filtr formantowy z LFO (samogłoski)
    {"stpf99.dubstep.growl", "DS Growl", "Growl/yoi: FM + vowel formant filter morphing", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0.3f},{P_ATK,2},{P_DEC,300},{P_SUS,1},{P_REL,100},{P_GLIDE,25},{P_TUNE,0},{P_FINE,0},
      {P_SUB,0.25f},{P_FM,0.45f},{P_FMRATIO,2},{P_FORM,0.85f},{P_VOWEL,1.5f},{P_CUTOFF,6000},{P_RESO,0.3f},
      {P_LFO_SYNC,1},{P_LFO_RATE,3},{P_LFO_DIV,8},{P_LFO_SHAPE,1},{P_LFO_CUT,1.0f},{P_LFO_VOW,1.5f},{P_LFO_FM,0.3f},
      {P_DRIVE,0.7f},{P_LEVEL,0.65f}},
     {{P_KEYTRK,1},{P_UNISON,1},{P_FTYPE,0}}},
    // ---- 4: SCREECH — metaliczny lead z FM, scoop pitch, unison
    {"stpf99.dubstep.screech", "DS Screech", "Screech lead: FM saw unison, pitch scoop, filter env", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0.2f},{P_ATK,2},{P_DEC,400},{P_SUS,0.7f},{P_REL,150},{P_GLIDE,80},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,5},{P_DETUNE,25},{P_WIDTH,0.8f},{P_FM,0.55f},{P_FMRATIO,3.01f},{P_CUTOFF,7000},{P_RESO,0.3f},
      {P_FENV,2},{P_FDEC,300},{P_LFO_SYNC,0},{P_LFO_RATE,5.5f},{P_LFO_SHAPE,0},{P_LFO_FM,0.2f},{P_LFO_PIT,0.2f},
      {P_PENV,5},{P_PDEC,80},{P_DRIVE,0.45f},{P_LEVEL,0.6f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}},
    // ---- 5: KICK — sinus + pitch envelope + klik szumowy
    {"stpf99.dubstep.kick", "DS Kick", "Kick: sine with pitch envelope, noise click, drive", true, 50.f,
     {{P_WAVE,0},{P_MORPH,0},{P_ATK,0.5f},{P_DEC,280},{P_TUNE,0},{P_FINE,0},{P_KEYTRK,0},{P_PENV,36},{P_PDEC,28},
      {P_NOISE,0.15f},{P_NDEC,4},{P_NCUT,2000},{P_CUTOFF,20000},{P_DRIVE,0.3f},{P_LEVEL,0.9f}},
     {{P_UNISON,1},{P_FTYPE,0},{P_RESO,0},{P_SUB,0}}},
    // ---- 6: SNARE — korpus + szum z burstami (clap)
    {"stpf99.dubstep.snare", "DS Snare", "Snare/clap: body tone + highpassed noise bursts", true, 190.f,
     {{P_WAVE,1},{P_MORPH,0},{P_ATK,0.5f},{P_DEC,140},{P_TUNE,0},{P_FINE,0},{P_KEYTRK,0},{P_PENV,10},{P_PDEC,30},
      {P_NOISE,0.8f},{P_NDEC,180},{P_NCUT,1200},{P_NBURST,1},{P_CUTOFF,14000},{P_DRIVE,0.35f},{P_LEVEL,0.8f}},
     {{P_UNISON,1},{P_FTYPE,0},{P_RESO,0},{P_SUB,0}}},
    // ---- 7: HAT — 6 oscylatorów "metal" (808) + szum, HP
    {"stpf99.dubstep.hat", "DS Hat", "Hat/perc: metallic square cluster + noise, highpass, choke", true, 205.3f,
     {{P_WAVE,5},{P_ATK,0.5f},{P_DEC,55},{P_TUNE,0},{P_KEYTRK,0},{P_NOISE,0.5f},{P_NDEC,45},{P_NCUT,7000},
      {P_FTYPE,2},{P_CUTOFF,6500},{P_RESO,0.25f},{P_DRIVE,0.1f},{P_LEVEL,0.7f}},
     {{P_UNISON,1},{P_MORPH,0},{P_SUB,0},{P_FINE,0}}},
    // ======================= v2: 16 nowych instrumentów =======================
    // ---- 8: CLAP — szum z burstami, pasmo (HP+LP), bez tonu
    {"stpf99.dubstep.clap", "DS Clap", "Clap: band-limited noise bursts, no tone", true, 190.f,
     {{P_TONE,0},{P_NOISE,1},{P_NDEC,220},{P_NCUT,900},{P_NLP,4500},{P_NBURST,4},{P_DRIVE,0.3f},{P_LEVEL,0.8f}},
     {{P_UNISON,1},{P_KEYTRK,0},{P_CUTOFF,20000},{P_FTYPE,0}}},
    // ---- 9: RIM — krótki klik/rimshot
    {"stpf99.dubstep.rim", "DS Rim", "Rim/click: short tuned tri + noise tick", true, 420.f,
     {{P_WAVE,1},{P_DEC,40},{P_TUNE,0},{P_KEYTRK,0},{P_PENV,8},{P_PDEC,12},{P_NOISE,0.25f},{P_NDEC,10},{P_NCUT,3000},{P_DRIVE,0.3f},{P_LEVEL,0.7f}},
     {{P_ATK,0.5f},{P_UNISON,1},{P_CUTOFF,20000},{P_FTYPE,0}}},
    // ---- 10: TOM — sinus z pitch env, grany melodycznie
    {"stpf99.dubstep.tom", "DS Tom", "Tom: sine with pitch env, keytracked fills", true, 261.6256f,
     {{P_WAVE,0},{P_DEC,350},{P_TUNE,0},{P_KEYTRK,1},{P_PENV,12},{P_PDEC,60},{P_NOISE,0.08f},{P_NDEC,20},{P_NCUT,1500},{P_DRIVE,0.2f},{P_LEVEL,0.8f}},
     {{P_ATK,0.5f},{P_UNISON,1},{P_CUTOFF,20000},{P_FTYPE,0}}},
    // ---- 11: CRASH — metal + długi szum
    {"stpf99.dubstep.crash", "DS Crash", "Crash/cymbal: metal cluster + long noise wash", true, 205.3f,
     {{P_WAVE,5},{P_DEC,1800},{P_TUNE,0},{P_TONE,0.6f},{P_NOISE,0.8f},{P_NDEC,1500},{P_NCUT,4000},{P_NLP,16000},{P_FTYPE,2},{P_CUTOFF,3000},
      {P_RESO,0.1f},{P_DRIVE,0.1f},{P_LEVEL,0.5f}},
     {{P_ATK,0.5f},{P_UNISON,1},{P_KEYTRK,0}}},
    // ---- 12: SHAKER — szum, krótkie burst-y
    {"stpf99.dubstep.shaker", "DS Shaker", "Shaker: filtered noise bursts", true, 205.3f,
     {{P_NOISE,0.9f},{P_NDEC,70},{P_NCUT,5000},{P_NLP,12000},{P_NBURST,2},{P_DRIVE,0.05f},{P_LEVEL,0.5f}},
     {{P_TONE,0},{P_ATK,0.5f},{P_DEC,60},{P_UNISON,1},{P_KEYTRK,0},{P_CUTOFF,20000},{P_FTYPE,0}}},
    // ---- 13: FM BASS — metaliczny bas FM
    {"stpf99.dubstep.fmbass", "DS FM Bass", "FM bass: sine carrier, ratio FM, LFO on FM index", false, 261.6256f,
     {{P_WAVE,0},{P_ATK,2},{P_DEC,250},{P_SUS,0.8f},{P_REL,90},{P_GLIDE,20},{P_TUNE,0},{P_SUB,0.2f},{P_FM,0.5f},{P_FMRATIO,1},
      {P_LFO_SYNC,1},{P_LFO_RATE,3},{P_LFO_DIV,8},{P_LFO_SHAPE,1},{P_LFO_FM,0.35f},{P_CUTOFF,4000},{P_RESO,0.1f},{P_DRIVE,0.5f},{P_LEVEL,0.7f}},
     {{P_KEYTRK,1},{P_UNISON,1},{P_FTYPE,0}}},
    // ---- 14: NEURO — rozstrojone piły + formanty + szybkie LFO
    {"stpf99.dubstep.neuro", "DS Neuro", "Neuro bass: detuned saws, formant + FM, fast LFO", false, 261.6256f,
     {{P_WAVE,2},{P_ATK,2},{P_DEC,300},{P_SUS,1},{P_REL,100},{P_GLIDE,25},{P_TUNE,0},{P_UNISON,3},{P_DETUNE,20},{P_WIDTH,0.5f},{P_SUB,0.25f},
      {P_FM,0.3f},{P_FMRATIO,2},{P_FORM,0.6f},{P_VOWEL,1.5f},{P_CUTOFF,2500},{P_RESO,0.45f},{P_LFO_SYNC,1},{P_LFO_RATE,4},{P_LFO_DIV,9},
      {P_LFO_SHAPE,2},{P_LFO_CUT,2.5f},{P_LFO_VOW,2},{P_DRIVE,0.8f},{P_LEVEL,0.6f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}},
    // ---- 15: HOLLOW — pulse/kwadrat z PW, pusty bas riddim
    {"stpf99.dubstep.hollow", "DS Hollow", "Hollow bass: pulse-width square, filter wobble", false, 261.6256f,
     {{P_WAVE,3},{P_PW,0.3f},{P_ATK,1},{P_DEC,200},{P_SUS,0.9f},{P_REL,60},{P_GLIDE,0},{P_TUNE,0},{P_UNISON,2},{P_DETUNE,8},{P_SUB,0.3f},
      {P_CUTOFF,700},{P_RESO,0.35f},{P_LFO_SYNC,1},{P_LFO_RATE,2},{P_LFO_DIV,5},{P_LFO_SHAPE,0},{P_LFO_CUT,2.0f},{P_DRIVE,0.4f},{P_LEVEL,0.75f}},
     {{P_KEYTRK,1},{P_FTYPE,0},{P_WIDTH,0.3f}}},
    // ---- 16: SUPERSAW — szeroki stos pił
    {"stpf99.dubstep.supersaw", "DS Supersaw", "Supersaw: 7 detuned saws, wide, filter env", false, 261.6256f,
     {{P_WAVE,2},{P_ATK,15},{P_DEC,400},{P_SUS,0.8f},{P_REL,400},{P_GLIDE,30},{P_TUNE,0},{P_UNISON,7},{P_DETUNE,35},{P_WIDTH,1},
      {P_CUTOFF,9000},{P_RESO,0.1f},{P_FENV,1},{P_FDEC,500},{P_DRIVE,0.15f},{P_LEVEL,0.5f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}},
    // ---- 17: PLUCK — krótki pluck, filtr z obwiednią
    {"stpf99.dubstep.pluck", "DS Pluck", "Pluck: short filtered saw/square, per-note retrigger", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0.3f},{P_ATK,0.5f},{P_DEC,220},{P_REL,120},{P_TUNE,0},{P_UNISON,2},{P_DETUNE,10},{P_CUTOFF,1500},{P_RESO,0.25f},
      {P_FENV,3},{P_FDEC,160},{P_DRIVE,0.2f},{P_LEVEL,0.65f}},
     {{P_SUS,0},{P_KEYTRK,1},{P_GLIDE,0},{P_FTYPE,0}}, true},
    // ---- 18: PAD — powolna tekstura
    {"stpf99.dubstep.pad", "DS Pad", "Pad: slow attack, detuned saw/tri, drifting filter", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0.4f},{P_ATK,900},{P_DEC,1500},{P_SUS,0.8f},{P_REL,1500},{P_TUNE,0},{P_UNISON,5},{P_DETUNE,20},{P_WIDTH,0.9f},{P_SUB,0.2f},
      {P_CUTOFF,2200},{P_RESO,0.15f},{P_LFO_SYNC,0},{P_LFO_RATE,0.2f},{P_LFO_SHAPE,1},{P_LFO_CUT,1.0f},{P_DRIVE,0},{P_LEVEL,0.5f}},
     {{P_KEYTRK,1},{P_GLIDE,0},{P_FTYPE,0}}},
    // ---- 19: STAB — krótki akord/stab
    {"stpf99.dubstep.stab", "DS Stab", "Stab: detuned saw/FM hit, filter env, per-note retrigger", false, 261.6256f,
     {{P_WAVE,2},{P_ATK,0.5f},{P_DEC,160},{P_SUS,0.15f},{P_REL,120},{P_TUNE,0},{P_UNISON,3},{P_DETUNE,18},{P_WIDTH,0.7f},{P_FM,0.2f},{P_FMRATIO,2},
      {P_CUTOFF,3000},{P_RESO,0.3f},{P_FENV,2.5f},{P_FDEC,200},{P_DRIVE,0.35f},{P_LEVEL,0.6f}},
     {{P_KEYTRK,1},{P_GLIDE,0},{P_FTYPE,0}}, true},
    // ---- 20: RISER — narastający FX (pitch/cutoff/level ramp)
    {"stpf99.dubstep.riser", "DS Riser", "Riser: noise + saw stack with pitch/cutoff/level ramp", false, 261.6256f,
     {{P_WAVE,2},{P_ATK,50},{P_REL,300},{P_TUNE,0},{P_UNISON,5},{P_DETUNE,30},{P_TONE,0.5f},{P_NOISE,0.5f},{P_NCUT,800},{P_NLP,12000},
      {P_CUTOFF,400},{P_RESO,0.4f},{P_RTIME,8000},{P_RCUT,5},{P_RPIT,24},{P_RVOL,0.9f},{P_DRIVE,0.2f},{P_LEVEL,0.5f}},
     {{P_SUS,1},{P_KEYTRK,1},{P_GLIDE,0},{P_FTYPE,0},{P_WIDTH,0.8f}}},
    // ---- 21: BOOM — impact / sub drop
    {"stpf99.dubstep.boom", "DS Boom", "Boom/impact: long sine drop with noise rumble", true, 40.f,
     {{P_WAVE,0},{P_DEC,2500},{P_TUNE,0},{P_PENV,30},{P_PDEC,450},{P_NOISE,0.25f},{P_NDEC,600},{P_NCUT,200},{P_NLP,3000},{P_DRIVE,0.3f},{P_LEVEL,0.9f}},
     {{P_ATK,0.5f},{P_UNISON,1},{P_KEYTRK,0},{P_CUTOFF,20000},{P_FTYPE,0}}},
    // ---- 22: ZAP — laserowy zjazd pitch
    {"stpf99.dubstep.zap", "DS Zap", "Zap/laser: fast pitch dive with FM", true, 261.6256f,
     {{P_WAVE,2},{P_DEC,400},{P_TUNE,0},{P_KEYTRK,1},{P_PENV,48},{P_PDEC,280},{P_FM,0.4f},{P_FMRATIO,3},{P_CUTOFF,8000},{P_RESO,0.2f},
      {P_DRIVE,0.3f},{P_LEVEL,0.55f}},
     {{P_ATK,0.5f},{P_UNISON,2},{P_DETUNE,20},{P_FTYPE,0}}},
    // ---- 23: VOX — sample-less „vocal chop" (formanty)
    {"stpf99.dubstep.vox", "DS Vox", "Vox chop: saw through vowel formants, per-note retrigger", false, 261.6256f,
     {{P_WAVE,2},{P_ATK,5},{P_DEC,200},{P_SUS,0.8f},{P_REL,120},{P_GLIDE,30},{P_TUNE,0},{P_UNISON,2},{P_DETUNE,10},{P_FORM,1},{P_VOWEL,0},
      {P_LFO_SYNC,0},{P_LFO_RATE,5},{P_LFO_SHAPE,0},{P_LFO_VOW,0},{P_CUTOFF,8000},{P_DRIVE,0.25f},{P_LEVEL,0.6f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}, true},
    // ======================= v3: mowa =======================
    // ---- 24: SPEAK — angielska synteza mowy: litery -> fonemy -> formanty F1-F3 na oscylatorach, morph między fonemami
    {"stpf99.dubstep.speak", "DS Speak", "Speech synth: English text -> phonemes -> formant morphing on oscillators, per-letter pitch map", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0},{P_ATK,6},{P_REL,90},{P_GLIDE,25},{P_TUNE,0},{P_FINE,0},{P_UNISON,2},{P_DETUNE,8},{P_WIDTH,0.4f},
      {P_CUTOFF,9000},{P_RESO,0.1f},{P_DRIVE,0.15f},{P_LEVEL,0.7f},
      {P_SP_MODE,0},{P_SP_BANK,0},{P_SP_SPEED,1},{P_SP_MORPH,35},{P_SP_DIALECT,0},{P_SP_RANGE,4},{P_SP_INTON,0.5f},
      {P_SP_SCALE,0},{P_SP_TRACT,0},{P_SP_HOLD,1},{P_SP_BREATH,0.1f}},
     {{P_KEYTRK,1},{P_SUS,1},{P_DEC,300},{P_FTYPE,0},{P_SUB,0},{P_FORM,0}}, true, true},
    // ======================= v4: instrumenty akustyczne =======================
    // ---- 25: THEREMIN — sinus/trójkąt, długi glide, vibrato, lekki formant "oo"
    {"stpf99.dubstep.theremin", "DS Theremin", "Theremin: near-sine, long glide, delayed-feel vibrato, soft vowel formant", false, 261.6256f,
     {{P_WAVE,0},{P_MORPH,0.12f},{P_ATK,60},{P_REL,220},{P_GLIDE,140},{P_TUNE,0},{P_FINE,0},{P_FORM,0.2f},{P_VOWEL,3.2f},
      {P_CUTOFF,4500},{P_RESO,0.12f},{P_LFO_SYNC,0},{P_LFO_RATE,5.8f},{P_LFO_SHAPE,0},{P_LFO_PIT,0.35f},{P_DRIVE,0.05f},{P_LEVEL,0.6f}},
     {{P_KEYTRK,1},{P_SUS,1},{P_DEC,300},{P_UNISON,1},{P_FTYPE,0},{P_SUB,0}}},
    // ---- 26: PAN FLUTE — trójkąt/sinus + szum oddechu śledzący wysokość
    {"stpf99.dubstep.panflute", "DS Pan Flute", "Pan flute: soft tone with pitch-tracking breath noise, slow attack", false, 261.6256f,
     {{P_WAVE,0},{P_MORPH,0.3f},{P_ATK,70},{P_REL,160},{P_GLIDE,20},{P_TUNE,0},{P_FINE,0},{P_NOISE,0.22f},{P_NKEY,1},{P_NCUT,800},{P_NLP,6000},
      {P_CUTOFF,6500},{P_RESO,0.1f},{P_LFO_SYNC,0},{P_LFO_RATE,5.2f},{P_LFO_SHAPE,0},{P_LFO_PIT,0.12f},{P_DRIVE,0},{P_LEVEL,0.65f}},
     {{P_KEYTRK,1},{P_SUS,1},{P_DEC,300},{P_UNISON,1},{P_FTYPE,0},{P_SUB,0}}},
    // ---- 27: HANDPAN — synteza modalna: tony własne 1 : 2 : 3 (ding), szybko gasnące górne
    {"stpf99.dubstep.handpan", "DS Handpan", "Handpan: modal partials 1:2:3, soft strike, long ring", true, 261.6256f,
     {{P_ATK,0.5f},{P_TUNE,0},{P_FINE,0},{P_PENV,2},{P_PDEC,45},{P_NOISE,0.06f},{P_NDEC,12},{P_NCUT,1500},{P_NLP,6000},
      {P_RING,1800},{P_BRIGHT,0.55f},{P_CUTOFF,9000},{P_DRIVE,0},{P_LEVEL,0.75f}},
     {{P_UNISON,1},{P_KEYTRK,1},{P_DEC,6000},{P_SUS,0},{P_FTYPE,0},{P_SUB,0}}, false, false, 1},
    // ---- 28: TONGUE DRUM — modalna blaszka stalowa (tony 1 : 2.76 : 5.4 : 8.9), krótszy ring
    {"stpf99.dubstep.tongue", "DS Tongue Drum", "Tongue drum: steel-tongue modal partials, short ring, mallet tick", true, 261.6256f,
     {{P_ATK,0.5f},{P_TUNE,0},{P_FINE,0},{P_PENV,0},{P_PDEC,20},{P_NOISE,0.12f},{P_NDEC,6},{P_NCUT,2500},{P_NLP,9000},
      {P_RING,900},{P_BRIGHT,0.5f},{P_CUTOFF,10000},{P_DRIVE,0},{P_LEVEL,0.75f}},
     {{P_UNISON,1},{P_KEYTRK,1},{P_DEC,6000},{P_SUS,0},{P_FTYPE,0},{P_SUB,0}}, false, false, 2},
    // ======================= v5: piano / acid / strings (ten sam silnik, inne defaulty + ekspozycja) =======================
    // ---- 29: PIANO — krótkie uderzenie, lekkie detune, filtr LP, per-note retrigger (keys)
    {"stpf99.dubstep.piano", "DS Piano", "Piano-like keys: soft hammer attack, mild detune, filtered, per-note retrigger", false, 261.6256f,
     {{P_WAVE,1},{P_MORPH,0.15f},{P_ATK,1.5f},{P_DEC,900},{P_SUS,0.25f},{P_REL,450},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,3},{P_DETUNE,6},{P_WIDTH,0.35f},{P_CUTOFF,5500},{P_RESO,0.12f},{P_FENV,1.2f},{P_FDEC,350},
      {P_NOISE,0.04f},{P_NDEC,25},{P_DRIVE,0.05f},{P_LEVEL,0.7f}},
     {{P_KEYTRK,1},{P_FTYPE,0},{P_SUB,0},{P_GLIDE,0}}, true, false, 0},
    // ---- 30: ACID — TB303-ish: square/saw, resonant filter env, glide, drive
    {"stpf99.dubstep.acid", "DS Acid", "Acid 303-style: resonant filter envelope, square/saw, glide, drive", false, 110.f,
     {{P_WAVE,3},{P_PW,0.45f},{P_MORPH,0.2f},{P_ATK,1},{P_DEC,180},{P_SUS,0.55f},{P_REL,80},{P_GLIDE,40},{P_TUNE,0},
      {P_CUTOFF,800},{P_RESO,0.75f},{P_FENV,2.8f},{P_FDEC,220},{P_FTYPE,0},
      {P_SUB,0.15f},{P_DRIVE,0.45f},{P_LEVEL,0.7f}},
     {{P_KEYTRK,1},{P_UNISON,1}}, false, false, 0},
    // ---- 31: STRINGS — wolny atak, długi release, unison, miękki LP (smyczki)
    {"stpf99.dubstep.strings", "DS Strings", "String ensemble: slow attack, long release, wide detune, soft lowpass", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0.35f},{P_ATK,350},{P_DEC,1200},{P_SUS,0.85f},{P_REL,1400},{P_GLIDE,25},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,6},{P_DETUNE,18},{P_WIDTH,0.85f},{P_SUB,0.1f},{P_CUTOFF,4200},{P_RESO,0.1f},
      {P_LFO_SYNC,0},{P_LFO_RATE,0.35f},{P_LFO_SHAPE,0},{P_LFO_CUT,0.6f},{P_DRIVE,0.08f},{P_LEVEL,0.55f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}, false, false, 0},
    // ======================= v6: modeler variants (keyword-driven new kinds) =======================
    // ---- 32: ORGAN — square + pulse width + soft sub, slow LFO chorus-like
    {"stpf99.dubstep.organ", "DS Organ", "Electric organ: square/pulse, mild sub, slow width LFO, sustained", false, 261.6256f,
     {{P_WAVE,3},{P_PW,0.35f},{P_MORPH,0.25f},{P_ATK,8},{P_DEC,200},{P_SUS,0.95f},{P_REL,180},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,3},{P_DETUNE,8},{P_WIDTH,0.5f},{P_SUB,0.2f},{P_CUTOFF,4800},{P_RESO,0.12f},
      {P_LFO_SYNC,0},{P_LFO_RATE,0.4f},{P_LFO_SHAPE,0},{P_LFO_CUT,0.4f},{P_DRIVE,0.1f},{P_LEVEL,0.65f}},
     {{P_KEYTRK,1},{P_FTYPE,0},{P_GLIDE,0}}, false, false, 0},
    // ---- 33: BRASS — saw + formant-ish + filter env bite, medium attack
    {"stpf99.dubstep.brass", "DS Brass", "Brass-like: saw unison, formant, filter envelope bite, medium attack", false, 261.6256f,
     {{P_WAVE,2},{P_MORPH,0.2f},{P_ATK,40},{P_DEC,350},{P_SUS,0.75f},{P_REL,220},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,4},{P_DETUNE,12},{P_WIDTH,0.55f},{P_SUB,0.15f},{P_FM,0.15f},{P_FMRATIO,1.5f},
      {P_FORM,0.45f},{P_VOWEL,2.0f},{P_CUTOFF,3200},{P_RESO,0.25f},{P_FENV,1.8f},{P_FDEC,280},
      {P_DRIVE,0.25f},{P_LEVEL,0.68f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}, false, false, 0},
    // ---- 34: BELL — short metallic (metal wave + noise tick), long quiet ring
    {"stpf99.dubstep.bell", "DS Bell", "Bell: metal partials + noise strike, long soft decay, per-note retrigger", false, 523.25f,
     {{P_WAVE,5},{P_MORPH,0.1f},{P_ATK,0.8f},{P_DEC,2200},{P_SUS,0.05f},{P_REL,1800},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,2},{P_DETUNE,4},{P_WIDTH,0.4f},{P_NOISE,0.18f},{P_NDEC,12},{P_NCUT,4000},
      {P_CUTOFF,9000},{P_RESO,0.08f},{P_FENV,0.6f},{P_FDEC,400},{P_DRIVE,0.05f},{P_LEVEL,0.6f}},
     {{P_KEYTRK,1},{P_FTYPE,0},{P_SUB,0},{P_GLIDE,0}}, true, false, 0},
    // ---- 35: CHOIR — formant-heavy pad, slow attack, wide detune (ah/eh morph)
    {"stpf99.dubstep.choir", "DS Choir", "Choir pad: formant morph, wide unison, slow attack/release", false, 261.6256f,
     {{P_WAVE,1},{P_MORPH,0.4f},{P_ATK,280},{P_DEC,900},{P_SUS,0.9f},{P_REL,1100},{P_TUNE,0},{P_FINE,0},
      {P_UNISON,6},{P_DETUNE,22},{P_WIDTH,0.9f},{P_FORM,0.9f},{P_VOWEL,1.0f},
      {P_LFO_SYNC,0},{P_LFO_RATE,0.25f},{P_LFO_SHAPE,1},{P_LFO_VOW,1.2f},{P_LFO_CUT,0.5f},
      {P_CUTOFF,3800},{P_RESO,0.15f},{P_DRIVE,0.06f},{P_LEVEL,0.5f}},
     {{P_KEYTRK,1},{P_FTYPE,0}}, false, false, 0},
    // ---- 36: PULSE — pure pulse/PWM lead, resonant, agile
    {"stpf99.dubstep.pulse", "DS Pulse", "Pulse/PWM lead: square with pulse-width, resonant filter, fast envelopes", false, 261.6256f,
     {{P_WAVE,3},{P_PW,0.25f},{P_MORPH,0.15f},{P_ATK,2},{P_DEC,220},{P_SUS,0.45f},{P_REL,90},{P_GLIDE,15},{P_TUNE,0},
      {P_UNISON,2},{P_DETUNE,6},{P_WIDTH,0.35f},{P_CUTOFF,2800},{P_RESO,0.55f},{P_FENV,2.2f},{P_FDEC,180},
      {P_LFO_SYNC,0},{P_LFO_RATE,2.5f},{P_LFO_SHAPE,0},{P_LFO_CUT,0.8f},{P_DRIVE,0.3f},{P_LEVEL,0.7f}},
     {{P_KEYTRK,1},{P_FTYPE,0},{P_SUB,0.1f}}, false, false, 0},
    // ---- 37: NOISESWEEP — noise + HP/LP sweep, FX / riser-ish sustained
    {"stpf99.dubstep.noisesweep", "DS NoiseSweep", "Noise sweep: filtered noise, LFO cutoff, long envelopes (FX/riser)", false, 261.6256f,
     {{P_WAVE,4},{P_MORPH,0},{P_ATK,50},{P_DEC,1500},{P_SUS,0.7f},{P_REL,800},{P_TUNE,0},
      {P_NOISE,0.9f},{P_NDEC,800},{P_NCUT,400},{P_NLP,12000},{P_CUTOFF,6000},{P_RESO,0.2f},{P_FTYPE,2},
      {P_LFO_SYNC,1},{P_LFO_RATE,0.5f},{P_LFO_DIV,4},{P_LFO_SHAPE,2},{P_LFO_CUT,3.0f},
      {P_DRIVE,0.2f},{P_LEVEL,0.55f}},
     {{P_KEYTRK,0.3f},{P_UNISON,1},{P_SUB,0}}, false, false, 0},
  };
  return T;
}

// ---------------------------------------------------------------- DSP
namespace dsp {
inline float blep(float t, float dt) {
  if (t < dt) { t /= dt; return t + t - t * t - 1.f; }
  if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
  return 0.f;
}
struct SVFc { float a1, a2, a3, k; };
inline SVFc svfCoef(float fc, float fs, float k) {
  float g = std::tan(3.14159265f * fc / fs);
  float a1 = 1.f / (1.f + g * (g + k));
  return {a1, g * a1, g * g * a1, k};
}
struct SVF {
  float ic1 = 0, ic2 = 0;
  inline void run(float x, const SVFc& c, float& lp, float& bp, float& hp) {
    float v3 = x - ic2;
    float v1 = c.a1 * ic1 + c.a2 * v3;
    float v2 = ic2 + c.a2 * ic1 + c.a3 * v3;
    ic1 = 2.f * v1 - ic1; ic2 = 2.f * v2 - ic2;
    lp = v2; bp = v1; hp = x - c.k * v1 - v2;
  }
  void reset() { ic1 = ic2 = 0; }
};
}  // namespace dsp

class Engine {
 public:
  void init(const TypeDef* t, double sampleRate) {
    T = t; fs = (float)sampleRate;
    smooth = 1.f - std::exp(-1.f / (0.005f * fs));
    float d[NP]; t->defaults(d);
    for (int i = 0; i < NP; i++) tgt[i] = cur[i] = d[i];
    reset();
    if (t->speech) {
      if (bankScripts.empty()) for (int b = 1; b <= 3; b++) bankScripts.emplace_back(sp::buildScript(sp::bankText(b)));
      if (!customScript && !pend.load()) setText(sp::bankText(0));
    }
  }
  ~Engine() { delete pend.exchange(nullptr); }
  void reset() { v = Voice(); stack.clear(); for (int& x : widx) x = 0; }
  // tekst dla DS Speak (wątek główny); audio podmienia skrypt przy najbliższej nucie
  void setText(const std::string& txt) { delete pend.exchange(sp::buildScript(txt)); }
  void snap() { for (int i = 0; i < NP; i++) cur[i] = tgt[i]; }
  void setTempo(double b) { bpm = (float)(b > 20 ? b : 140); }
  void setParam(int p, float e) {
    tgt[p] = e;
    if (PI[p].kind == INT) cur[p] = e;
  }
  void noteOn(int key, float vel) {
    stack.erase(std::remove(stack.begin(), stack.end(), key), stack.end());
    stack.push_back(key);
    bool legato = !T->oneshot && !T->retrig && v.active && v.gated;
    v.nTgt = (float)key; v.vel = vel;
    if (!legato) {
      if (!v.active || T->oneshot || cur[P_GLIDE] < 0.5f) v.nCur = (float)key;
      if (!v.active) { v.level = 0; for (auto& f : v.flt) f.reset(); for (auto& row : v.frm) for (auto& f : row) f.reset(); v.lpN[0] = v.lpN[1] = 0; v.lpN2[0] = v.lpN2[1] = 0;
                       for (auto& row : v.spf) { for (auto& f : row) f.reset(); }
                       for (auto& f : v.spn) f.reset();
                       v.sp = SpState(); }
      if (T->oneshot && !T->modal) v.level = 0;
      if (!v.active || T->oneshot) {
        for (int i = 0; i < 7; i++) { v.ph[i] = i * 0.173f; v.mph[i] = 0; }
        for (int i = 0; i < 6; i++) v.metPh[i] = 0;
        v.subPh = 0;
      }
      v.stage = ATTACK; v.lfoPh = 0; v.sh = rnd(); v.rampT = 0;
      v.nenv = 1; v.burstIdx = 0; v.burstTimer = 0;
    }
    v.penv = 1; v.fenv = 1; v.active = true; v.gated = true;
    if (T->speech) spStart(key);
    if (T->modal) {                                  // uderzenie: amplitudy tonów własnych (jasność = udział górnych)
      const ModalDef& M = modalDef(T->modal - 1); float br = 0.35f + 1.3f * cur[P_BRIGHT], a = 1.f;
      for (int k = 0; k < M.n; k++) { v.pa[k] = M.amp[k] * a; a *= br; }
    }
  }
  void noteOff(int key) {
    stack.erase(std::remove(stack.begin(), stack.end(), key), stack.end());
    if (T->oneshot) return;
    if (!stack.empty()) { v.nTgt = (float)stack.back(); return; }
    v.gated = false;
    if (T->speech && v.sp.active) return;      // słowo dokończy się samo (końcówka po trzymanej samogłosce), potem release
    if (v.active) v.stage = RELEASE;
  }
  void allOff() { stack.clear(); if (!T->oneshot) { v.gated = false; v.sp.active = false; v.sp.holding = false; if (v.active) v.stage = RELEASE; } }

  void render(float* L, float* R, int n, const float* iL = nullptr, const float* iR = nullptr) {
    for (int i = 0; i < n; i++) {
      xin[0] = iL ? iL[i] : 0.f; xin[1] = iR ? iR[i] : (iL ? iL[i] : 0.f);
      for (int p = 0; p < NP; p++) if (PI[p].kind != INT) cur[p] += (tgt[p] - cur[p]) * smooth;
      if (!v.active) { L[i] = R[i] = 0.f; continue; }
      float o[2]; tick(o); L[i] = o[0]; R[i] = o[1];
    }
  }

 private:
  enum Stage { ATTACK, DECAY, RELEASE };
  // stan artykulatora DS Speak; c[] = bieżące (f1,f2,f3,av,af,ah,nc,nq,pitch[st]), b[] = start segmentu, t[] = cel
  struct SpState {
    bool active = false, holding = false;
    const sp::Word* w = nullptr; int idx = -1;
    float pos = 0, len = 1, ramp = 1, gain = 1;
    float c[9] = {500, 1500, 2500, 0, 0, 0, 4000, 1, 0}, b[9] = {0}, t[9] = {0};
  };
  struct Voice {
    SpState sp;
    dsp::SVF spf[2][3], spn[2];
    bool active = false, gated = false;
    int stage = ATTACK;
    float level = 0, vel = 1, nCur = 60, nTgt = 60;
    float ph[7] = {0}, mph[7] = {0}, metPh[6] = {0}, subPh = 0, mp[6] = {0}, pa[6] = {0};
    float lfoPh = 0, sh = 0, penv = 0, fenv = 0, nenv = 0;
    int burstIdx = 0, burstTimer = 0;
    dsp::SVF flt[2], frm[2][2];
    float lpN[2] = {0, 0}, lpN2[2] = {0, 0}, rampT = 0;
  };
  const TypeDef* T = nullptr;
  float fs = 48000, bpm = 140, smooth = 0.01f;
  float tgt[NP] = {0}, cur[NP] = {0}, pw_ = 0.5f;
  Voice v; std::vector<int> stack; uint32_t rng = 0x1234567u;
  float xin[2] = {0, 0};   // wejście audio (instrument jako filtr), ustawiane per próbka w render()
  struct ModalDef { int n; float ratio[6], amp[6], dmul[6]; };
  static const ModalDef& modalDef(int i) {
    static const ModalDef M[2] = {
      {5, {1.f, 2.01f, 2.99f, 4.05f, 5.1f, 0}, {1.f, 0.55f, 0.32f, 0.14f, 0.08f, 0}, {1.f, 0.7f, 0.45f, 0.3f, 0.2f, 0}},   // handpan
      {4, {1.f, 2.76f, 5.4f, 8.93f, 0, 0}, {1.f, 0.38f, 0.16f, 0.07f, 0, 0}, {1.f, 0.5f, 0.3f, 0.18f, 0, 0}}};              // tongue drum
    return M[i];
  }
  // DS Speak
  std::unique_ptr<sp::Script> customScript; std::atomic<sp::Script*> pend{nullptr};
  std::vector<std::unique_ptr<sp::Script>> bankScripts; int widx[4] = {0, 0, 0, 0};

  struct Dia { float fscale, range, inton, speed, morph; int scale; };
  const Dia& dia() const {
    static const Dia D[5] = {{1.f, 1.f, 1.f, 1.f, 1.f, 0},          // Neutral
                             {1.12f, 1.f, 1.25f, 1.1f, 0.9f, 0},    // Bright: wyższe formanty, żywsza intonacja
                             {0.88f, 0.8f, 0.8f, 0.9f, 1.1f, 0},    // Dark: niższe formanty, spokojniej
                             {1.f, 2.6f, 1.6f, 0.85f, 1.4f, 1},     // Tonal: szeroki zakres liter, kontury, skala moll
                             {1.f, 0.f, 0.f, 1.f, 0.3f, 0}};       // Robot: monotonia, twarde przejścia
    return D[std::min(4, std::max(0, (int)cur[P_SP_DIALECT]))];
  }
  static float quantizeSt(float st, int sc) {
    static const int S[5][8] = {{0}, {0, 2, 3, 5, 7, 8, 10, 12}, {0, 2, 4, 5, 7, 9, 11, 12}, {0, 1, 3, 5, 7, 8, 10, 12}, {0, 3, 5, 7, 10, 12, 12, 12}};
    float o = std::floor(st / 12.f), r = st - 12.f * o, best = 0, bd = 1e9f;
    for (int k = 0; k < 8; k++) { float d = std::fabs(r - S[sc][k]); if (d < bd) { bd = d; best = (float)S[sc][k]; } }
    return 12.f * o + best;
  }
  // wysokość litery: pozycja na skali (zakres liter) + kontur intonacji słowa, opcjonalnie kwantyzacja do skali
  float spPitch(const sp::Seg& g) {
    const Dia& D = dia();
    float st = g.slot * 0.5f * cur[P_SP_RANGE] * D.range + g.contour * cur[P_SP_INTON] * D.inton;
    int sc = (int)cur[P_SP_SCALE]; if (sc == 0) sc = D.scale;
    return sc > 0 ? quantizeSt(st, sc) : st;
  }
  void spBegin(int i) {                       // start segmentu i: zapamiętaj stan, ustaw cel i czas przejścia
    SpState& s = v.sp; const sp::Seg& g = s.w->segs[i]; const Dia& D = dia();
    s.idx = i; s.pos = 0;
    float spd = std::max(0.2f, cur[P_SP_SPEED] * D.speed);
    s.len = std::max(1.f, g.dur * 0.001f * fs / spd);
    float rms = g.ramp > 0.f ? g.ramp : cur[P_SP_MORPH] * D.morph;
    s.ramp = std::max(1.f, std::min(s.len, rms * 0.001f * fs));
    for (int k = 0; k < 9; k++) s.b[k] = s.c[k];
    s.t[0] = g.f1; s.t[1] = g.f2; s.t[2] = g.f3; s.t[3] = g.av; s.t[4] = g.af; s.t[5] = g.ah; s.t[6] = g.nc; s.t[7] = g.nq;
    s.t[8] = spPitch(g);
  }
  void spStart(int key) {
    sp::Script* ns = pend.exchange(nullptr);
    if (ns) { v.sp.active = false; v.sp.w = nullptr; customScript.reset(ns); widx[0] = 0; }
    int bank = std::min(3, std::max(0, (int)cur[P_SP_BANK]));
    const sp::Script* S = bank == 0 ? customScript.get() : (bank - 1 < (int)bankScripts.size() ? bankScripts[bank - 1].get() : nullptr);
    if (!S) { v.sp.active = false; return; }
    int mode = (int)cur[P_SP_MODE];
    const std::vector<sp::Word>& L = mode == 2 ? S->units : S->words;
    if (L.empty()) { v.sp.active = false; return; }
    int n = (int)L.size(), i;
    if (mode == 1) i = ((key % n) + n) % n;
    else { i = widx[bank] % n; widx[bank] = (i + 1) % n; }
    v.sp.w = &L[i]; v.sp.gain = L[i].gain; v.sp.active = true; v.sp.holding = false;
    spBegin(0);
  }
  void spNext() {
    SpState& s = v.sp;
    if (s.idx + 1 < (int)s.w->segs.size()) { spBegin(s.idx + 1); return; }
    s.active = false; s.holding = false; v.stage = RELEASE;   // koniec słowa
  }
  void spAdvance() {                          // co próbkę: morf formantów/głosu/wysokości do celu segmentu
    SpState& s = v.sp;
    if (!s.active) return;
    if (s.holding) {
      if (v.gated) return;                    // trzymamy samogłoskę do note-off
      s.holding = false; spNext(); if (!s.active) return;
    }
    s.pos += 1.f;
    float p = std::min(1.f, s.pos / s.ramp); p = p * p * (3.f - 2.f * p);
    for (int k = 0; k < 9; k++) s.c[k] = s.b[k] + (s.t[k] - s.b[k]) * p;
    if (s.pos >= s.len) {
      if (s.idx == s.w->hold && v.gated && cur[P_SP_HOLD] > 0.5f) s.holding = true;
      else spNext();
    }
  }
  // źródło (oscylatory) -> 3 formanty F1-F3 + szum frykacyjny/aspiracja sterowane artykulatorem
  void spStage(float& sl, float& sr, float f0) {
    SpState& s = v.sp; const Dia& D = dia();
    float sh = D.fscale * std::exp2(cur[P_SP_TRACT] / 12.f), br = cur[P_SP_BREATH];
    float vo = s.c[3] * (1.f - br), as = s.c[5] + br * s.c[3] * 0.9f, fa = s.c[4];
    float lim = 0.42f * fs;
    float F[3] = {std::min(lim, std::max(120.f, s.c[0] * sh)), std::min(lim, std::max(250.f, s.c[1] * sh)), std::min(lim, std::max(500.f, s.c[2] * sh))};
    static const float BW[3] = {90.f, 120.f, 180.f}, G[3] = {1.f, 0.85f, 0.55f};
    dsp::SVFc fc[3];
    for (int k = 0; k < 3; k++) fc[k] = dsp::svfCoef(F[k], fs, std::min(1.f, std::max(0.05f, BW[k] / F[k])));
    float nc = std::min(lim, std::max(400.f, s.c[6] * (1.f + (sh - 1.f) * 0.6f)));
    dsp::SVFc cn = dsp::svfCoef(nc, fs, std::min(2.f, std::max(0.05f, 1.f / std::max(0.2f, s.c[7]))));
    float norm = std::min(2.5f, std::max(0.5f, std::sqrt(f0 / 150.f)));   // wyrównanie głośności względem wysokości
    float x[2] = {sl * vo + rnd() * as * 0.6f, sr * vo + rnd() * as * 0.6f}, lp, bp, hp;
    for (int ch = 0; ch < 2; ch++) {
      float y = 0.f;
      for (int k = 0; k < 3; k++) { v.spf[ch][k].run(x[ch], fc[k], lp, bp, hp); y += bp * fc[k].k * G[k]; }
      v.spn[ch].run(rnd(), cn, lp, bp, hp);
      y = y * 1.8f * norm + bp * cn.k * fa * 0.65f;
      x[ch] = y * s.gain;
    }
    sl = x[0]; sr = x[1];
  }

  float rnd() { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return (rng & 0xFFFFFF) * (2.f / 16777216.f) - 1.f; }
  static float lfoShape(int s, float p, float sh) {
    switch (s) {
      case 0: return std::sin(6.2831853f * p);
      case 1: { float q = p + 0.25f; q -= std::floor(q); return 1.f - 4.f * std::fabs(q - 0.5f); }
      case 2: return 1.f - 2.f * p;
      case 3: return p < 0.5f ? 1.f : -1.f;
      default: return sh;
    }
  }
  float waveAt(int idx, float t, float dt, float metal) {
    switch (idx) {
      case 0: return std::sin(6.2831853f * t);
      case 1: return 1.f - 4.f * std::fabs(t - 0.5f);
      case 2: return 2.f * t - 1.f - dsp::blep(t, dt);
      case 3: { float t2 = t + (1.f - pw_); if (t2 >= 1.f) t2 -= 1.f;
                return (t < pw_ ? 1.f : -1.f) + dsp::blep(t, dt) - dsp::blep(t2, dt) - (2.f * pw_ - 1.f); }
      case 4: return rnd();
      default: return metal;
    }
  }
  static float tc(float ms, float fs) { return std::exp(-4.6f / std::max(1.f, ms * 0.001f * fs)); }

  void tick(float* out) {
    // --- glide
    float gl = cur[P_GLIDE];
    if (gl < 0.5f) v.nCur = v.nTgt;
    else v.nCur += (v.nTgt - v.nCur) * (1.f - std::exp(-4000.f / (gl * fs)));

    // --- LFO
    int div = std::min(12, std::max(0, (int)cur[P_LFO_DIV]));
    float rate = cur[P_LFO_SYNC] > 0.5f ? (bpm / 60.f) / DIV_BEATS[div] : cur[P_LFO_RATE];
    v.lfoPh += rate / fs;
    if (v.lfoPh >= 1.f) { v.lfoPh -= std::floor(v.lfoPh); v.sh = rnd(); }
    float lfo = lfoShape((int)cur[P_LFO_SHAPE], v.lfoPh, v.sh);

    if (T->speech) spAdvance();
    // --- ramp (riser)
    v.rampT += 1.f;
    float rr = std::min(1.f, v.rampT / std::max(1.f, cur[P_RTIME] * 0.001f * fs));
    pw_ = cur[P_PW];
    // --- pitch
    float semis = cur[P_TUNE] + cur[P_FINE] * 0.01f + cur[P_KEYTRK] * (v.nCur - 60.f)
                + cur[P_LFO_PIT] * lfo + cur[P_PENV] * v.penv + cur[P_RPIT] * rr + (T->speech ? v.sp.c[8] : 0.f);
    float f = std::min(T->ref * std::exp2(semis / 12.f), 0.45f * fs);
    f = std::max(f, 1.f);

    // --- oscylatory
    int wi = (int)cur[P_WAVE], wj = std::min(wi + 1, 5);
    float m = (wi >= 5) ? 0.f : cur[P_MORPH];
    int nu = std::min(7, std::max(1, (int)cur[P_UNISON]));
    float fmAmt = std::min(1.f, std::max(0.f, cur[P_FM] + cur[P_LFO_FM] * lfo));
    float pm = fmAmt * 1.5915f;  // 10 rad / 2pi
    float metal = 0.f;
    if (wi == 5 || (wj == 5 && m > 0.f)) {
      static const float MR[6] = {1.f, 1.483f, 1.8f, 2.546f, 2.63f, 3.897f};
      float s = 0;
      for (int k = 0; k < 6; k++) {
        float dt = std::min(0.45f, f * MR[k] / fs);
        v.metPh[k] += dt; if (v.metPh[k] >= 1.f) v.metPh[k] -= 1.f;
        s += (v.metPh[k] < 0.5f ? 1.f : -1.f) + dsp::blep(v.metPh[k], dt)
           - dsp::blep(v.metPh[k] + 0.5f >= 1.f ? v.metPh[k] - 0.5f : v.metPh[k] + 0.5f, dt);
      }
      metal = s * 0.35f;
    }
    float sl = 0, sr = 0, norm = 1.f / std::sqrt((float)nu);
    for (int u = 0; u < nu; u++) {
      float off = nu > 1 ? (2.f * u / (nu - 1) - 1.f) : 0.f;
      float fu = f * std::exp2(off * cur[P_DETUNE] / 1200.f);
      float dt = std::min(0.45f, fu / fs);
      v.ph[u] += dt; if (v.ph[u] >= 1.f) v.ph[u] -= 1.f;
      float t = v.ph[u];
      if (pm > 0.f) {
        v.mph[u] += std::min(0.45f, fu * cur[P_FMRATIO] / fs); if (v.mph[u] >= 1.f) v.mph[u] -= 1.f;
        t += pm * std::sin(6.2831853f * v.mph[u]); t -= std::floor(t);
      }
      float a = waveAt(wi, t, dt, metal);
      float s = (m > 0.f) ? a + (waveAt(wj, t, dt, metal) - a) * m : a;
      float pan = off * cur[P_WIDTH];
      sl += s * std::sqrt(1.f - pan) ; sr += s * std::sqrt(1.f + pan);
    }
    sl *= norm; sr *= norm;
    if (cur[P_SUB] > 0.001f) {
      v.subPh += 0.5f * f / fs; if (v.subPh >= 1.f) v.subPh -= 1.f;
      float s = std::sin(6.2831853f * v.subPh) * cur[P_SUB] * 1.4142f;
      sl += s; sr += s;
    }
    { float tg = 0.7f * cur[P_TONE]; sl *= tg; sr *= tg; }
    if (T->modal) {                                  // synteza modalna zamiast oscylatorów
      const ModalDef& M = modalDef(T->modal - 1); float s = 0;
      for (int k = 0; k < M.n; k++) {
        v.mp[k] += std::min(0.45f * fs, f * M.ratio[k]) / fs; if (v.mp[k] >= 1.f) v.mp[k] -= 1.f;
        s += v.pa[k] * std::sin(6.2831853f * v.mp[k]);
        v.pa[k] *= tc(cur[P_RING] * M.dmul[k], fs);
      }
      sl = sr = s * 0.5f;
    }
    if (cur[P_IN] > 0.001f) {                        // wejście audio zastępuje/miesza źródło -> dalej filtr, formanty, obwiednia nut
      float mx = std::min(1.f, cur[P_IN]);
      sl = sl * (1.f - mx) + xin[0] * mx; sr = sr * (1.f - mx) + xin[1] * mx;
    }

    // --- filtr
    int ft = (int)cur[P_FTYPE];
    float fcMod = cur[P_FENV] * v.fenv + cur[P_LFO_CUT] * lfo + cur[P_RCUT] * rr;
    bool bypass = ft == 0 && cur[P_CUTOFF] > 19000.f && std::fabs(cur[P_FENV]) < 0.01f && std::fabs(cur[P_LFO_CUT]) < 0.01f && std::fabs(cur[P_RCUT]) < 0.01f;
    if (!bypass) {
      float fc = std::min(0.45f * fs, std::max(20.f, cur[P_CUTOFF] * std::exp2(fcMod)));
      dsp::SVFc c = dsp::svfCoef(fc, fs, 2.f - 1.96f * cur[P_RESO]);
      float lp, bp, hp, x[2] = {sl, sr};
      for (int ch = 0; ch < 2; ch++) {
        v.flt[ch].run(x[ch], c, lp, bp, hp);
        x[ch] = ft == 0 ? lp : (ft == 1 ? bp * c.k : hp);
      }
      sl = x[0]; sr = x[1];
    }
    // --- formanty
    if (T->speech) {
      spStage(sl, sr, f);
    } else if (cur[P_FORM] > 0.001f) {
      static const float F1[5] = {730, 530, 270, 570, 300}, F2[5] = {1090, 1840, 2290, 840, 870};
      float vp = std::min(3.999f, std::max(0.f, cur[P_VOWEL] + cur[P_LFO_VOW] * lfo));
      int i0 = (int)vp; float fr = vp - i0;
      float f1 = F1[i0] + (F1[i0 + 1] - F1[i0]) * fr, f2 = F2[i0] + (F2[i0 + 1] - F2[i0]) * fr;
      dsp::SVFc c1 = dsp::svfCoef(f1, fs, 0.33f), c2 = dsp::svfCoef(f2, fs, 0.33f);
      float x[2] = {sl, sr}, lp, bp, hp;
      for (int ch = 0; ch < 2; ch++) {
        v.frm[ch][0].run(x[ch], c1, lp, bp, hp); float b1 = bp * c1.k;
        v.frm[ch][1].run(x[ch], c2, lp, bp, hp); float b2 = bp * c2.k;
        x[ch] = x[ch] * (1.f - cur[P_FORM]) + (b1 + b2) * 1.6f * cur[P_FORM];
      }
      sl = x[0]; sr = x[1];
    }

    // --- obwiednia amp
    float e = v.level;
    if (v.stage == ATTACK) {
      e += 1.f / std::max(1.f, cur[P_ATK] * 0.001f * fs);
      if (e >= 1.f) { e = 1.f; v.stage = DECAY; }
    } else if (v.stage == DECAY) {
      float cd = tc(cur[P_DEC], fs);
      bool toZero = T->oneshot || cur[P_SUS] < 1e-4f;
      float sus = toZero ? 0.f : cur[P_SUS];
      e = sus + (e - sus) * cd;
      if (toZero && e < 1e-4f) { e = 0; v.active = false; }
    } else {
      e *= tc(cur[P_REL], fs);
      if (e < 1e-4f) { e = 0; v.active = false; }
    }
    v.level = e;
    v.fenv *= tc(cur[P_FDEC], fs);
    v.penv *= tc(cur[P_PDEC], fs);

    // --- szum (burst-y + HP)
    float nl = 0, nr = 0;
    if (cur[P_NOISE] > 0.001f) {
      int nb = (int)cur[P_NBURST];
      if (T->oneshot && v.burstIdx < nb - 1 && ++v.burstTimer >= (int)(0.011f * fs)) {
        v.burstTimer = 0; v.burstIdx++; v.nenv = 1.f;
      }
      bool fast = T->oneshot && v.burstIdx < nb - 1;
      v.nenv *= tc(fast ? 8.f : cur[P_NDEC], fs);
      float ncut = cur[P_NCUT], nlp = cur[P_NLP], nk = cur[P_NKEY];
      if (nk > 0.001f) { ncut = ncut * (1.f - nk) + f * 0.7f * nk; nlp = std::min(0.45f * fs, nlp * (1.f - nk) + f * 1.6f * nk); }
      float a = 1.f - std::exp(-6.2831853f * ncut / fs);
      float g = cur[P_NOISE] * (T->oneshot ? v.nenv : e);
      float r0 = rnd(), r1 = rnd();
      v.lpN[0] += a * (r0 - v.lpN[0]); v.lpN[1] += a * (r1 - v.lpN[1]);
      float h0 = r0 - v.lpN[0], h1 = r1 - v.lpN[1];
      if (nlp < 19000.f) {
        float al = 1.f - std::exp(-6.2831853f * nlp / fs);
        v.lpN2[0] += al * (h0 - v.lpN2[0]); v.lpN2[1] += al * (h1 - v.lpN2[1]); h0 = v.lpN2[0]; h1 = v.lpN2[1];
      }
      nl = h0 * g; nr = h1 * g;
    }

    // --- miks, drive, level
    float ol = sl * e + nl, orr = sr * e + nr;
    float d = cur[P_DRIVE];
    if (d > 0.001f) {
      float g = 1.f + d * 14.f, inv = 1.f / std::tanh(g), w = std::min(1.f, d * 5.f);
      ol += (std::tanh(ol * g) * inv - ol) * w;
      orr += (std::tanh(orr * g) * inv - orr) * w;
    }
    float gain = cur[P_LEVEL] * (0.2f + 0.8f * v.vel) * (1.f - cur[P_RVOL] * (1.f - rr));
    out[0] = std::max(-2.f, std::min(2.f, ol * gain));
    out[1] = std::max(-2.f, std::min(2.f, orr * gain));
  }
};

}  // namespace ds
