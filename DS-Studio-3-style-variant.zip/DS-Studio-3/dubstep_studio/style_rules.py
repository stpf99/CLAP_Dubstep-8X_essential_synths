"""style_rules.py — „Nieprzewidywalność stylu": losowe warianty STYLÓW PODSTAWOWYCH w granicach gatunku.

Style podstawowe (ST.ORDER, nie albumy / style specjalne) miały stałe pule: kilka wzorów stopy, jeden tryb hatu, jedna lista progresji, jeden szablon formy.
Dlatego każdy utwór „Techno" czy „Riddim" brzmiał jak ten sam szkielet. Tutaj każdy projekt dostaje własny WARIANT stylu:

  * NIEZMIENNIKI GATUNKU (nigdy nie ruszane): stopa 4/4 w techno / house / trance / EDM; werbel/clap na 3. dobie w halftime dubstepie (krok 8, stopa tam nie gra);
    werbel 2 i 4 (kroki 4 i 12) w DnB / drumstepie / electro; stopa zawsze na kroku 0; brak perkusji w klasyce; ride w jazzie; tempo w oknie gatunku;
    rdzeń instrumentów (`core`), wzory albumów i style specjalne.
  * SWOBODY (losowane z ziarna projektu): dodatkowe uderzenia stopy w dozwolonych krokach, ghost-nuty, tryb hatu z listy dozwolonych (z wagami), tryb suba,
    swing / swing8 w zakresie gatunku, tempo ±, progresje (podmiany stopni z palety gatunku, łańcuchy kwintowe w jazzie / barokowi / liquidzie), proporcje sekcji,
    nowe wzory basu (WOB) i growla (GROWL) — próbkowane z WYUCZONYCH niezmienników biblioteki stylu (start na kroku 0, siatka kroków, liczba zdarzeń, długości, tokeny),
    dodatkowe instrumenty z puli rodziny gatunkowej, lekka mutacja nut melodycznych.

Jedno pokrętło `wild` (0…1; projekt: proj["wild"]):
  0.0 = dawne zachowanie, wynik identyczny co do nuty (brak wariantu),  ~0.6 = domyślnie,  1.0 = najwięcej swobody (nadal w granicach gatunku).

Wariant jest deterministyczny (seed projektu + nazwa stylu), zapisany w proj["style_variant"] (JSON) i ponownie stosowany przy regeneracji ścieżek.
Hybrydy („A 60% + B 40%") — każdy czysty składnik dostaje swój wariant, potem składanie działa jak dawniej.
"""
from __future__ import annotations

import contextlib
import copy
import math
import random

from . import styles as ST

HALF = {"Brostep", "Riddim", "Tearout", "Melodic", "Deep", "Dubstep", "Trap"}          # halftime: werbel na kroku 8
TWOSTEP = {"Drumstep", "DnB", "Liquid DnB", "Neurofunk"}                               # werbel 4 + 12, stopa 0 + ~10
FOUR = {"EDM", "Techno", "Acid Techno", "Hard Techno", "House", "Techno Trax", "Tunnel Trance", "Trance", "Psytrance"}   # stopa 4/4
BREAKS = {"Electro", "Jazz Rock", "Experimental", "Raw Synthesis"}
AMBIENT = {"Space Electronica", "Berlin School"}
CLASSIC = {"Baroque", "Romantic", "Minimal Classical"}
JAZZ = {"Jazz"}

# okno tempa gatunku: ± od bazowego BPM (przy wild = 1)
BPM_R = {"Brostep": 2, "Riddim": 2, "Tearout": 5, "Melodic": 3, "Deep": 2, "Dubstep": 2, "Drumstep": 3, "Trap": 8, "EDM": 4,
         "Techno": 5, "Acid Techno": 5, "Hard Techno": 10, "House": 4, "Electro": 6, "Techno Trax": 4, "Tunnel Trance": 4, "Trance": 4, "Psytrance": 5,
         "DnB": 3, "Liquid DnB": 3, "Neurofunk": 3, "Space Electronica": 10, "Berlin School": 8, "Baroque": 12, "Romantic": 10, "Minimal Classical": 10,
         "Jazz": 14, "Jazz Rock": 12, "Experimental": 20, "Raw Synthesis": 10}

# dozwolone tryby hatu z wagami (tryby z gen_hat: 16 | 8 | trap | ride | offbeat | off | none)
HAT_W = {"Brostep": {"16": .5, "8": .35, "trap": .15}, "Riddim": {"8": .55, "off": .3, "16": .15}, "Tearout": {"16": .8, "8": .2},
         "Melodic": {"8": .5, "16": .3, "off": .2}, "Deep": {"off": .5, "8": .3, "offbeat": .2}, "Dubstep": {"8": .5, "16": .3, "off": .2},
         "Drumstep": {"16": .6, "8": .4}, "Trap": {"trap": .7, "16": .2, "8": .1}, "EDM": {"off": .5, "offbeat": .35, "8": .15},
         "Techno": {"offbeat": .55, "16": .25, "8": .2}, "Acid Techno": {"16": .5, "offbeat": .3, "8": .2}, "Hard Techno": {"16": .6, "offbeat": .25, "8": .15},
         "House": {"offbeat": .7, "16": .2, "8": .1}, "Techno Trax": {"offbeat": .75, "16": .15, "8": .1}, "Tunnel Trance": {"offbeat": .75, "16": .15, "8": .1},
         "Trance": {"offbeat": .75, "16": .15, "8": .1}, "Psytrance": {"offbeat": .8, "16": .2},
         "DnB": {"16": .6, "8": .3, "trap": .1}, "Liquid DnB": {"16": .5, "8": .4, "off": .1}, "Neurofunk": {"16": .55, "8": .4, "trap": .05},
         "Electro": {"16": .6, "8": .25, "offbeat": .15}, "Jazz Rock": {"16": .5, "8": .3, "ride": .2},
         "Experimental": {"16": .2, "8": .2, "trap": .15, "offbeat": .2, "off": .15, "ride": .1}, "Raw Synthesis": {"16": .5, "8": .3, "offbeat": .2},
         "Space Electronica": {"offbeat": .5, "8": .25, "off": .25}, "Berlin School": {"offbeat": .5, "8": .3, "off": .2}}   # klasyka i jazz: hat stały (none / ride)

SUB_OK = {"Techno": ["offbeat", "roll", "hold", "pulse8"], "Acid Techno": ["offbeat", "roll", "pulse8"], "Hard Techno": ["roll", "offbeat"],
          "House": ["hold", "offbeat", "pulse8", "funk"], "Electro": ["funk", "pulse8", "offbeat"], "Techno Trax": ["offbeat", "roll", "pulse8"],
          "Tunnel Trance": ["roll", "offbeat"], "Trance": ["offbeat", "roll", "pulse8"], "Psytrance": ["roll", "pulse8"],
          "Space Electronica": ["hold", "pulse8"], "Berlin School": ["pulse8", "hold", "roll"], "Jazz Rock": ["funk", "walk", "pulse8"],
          "Raw Synthesis": ["pulse8", "roll", "offbeat", "funk"], "Baroque": ["walk", "hold"], "Romantic": ["hold", "walk"], "Minimal Classical": ["hold", "pulse8"]}

SWING_R = {"Brostep": (0, .04), "Riddim": (0, .03), "Tearout": (0, .03), "Melodic": (.02, .10), "Deep": (.04, .12), "Dubstep": (0, .04), "Drumstep": (0, .08),
           "Trap": (0, .04), "EDM": (0, .02), "Techno": (0, .07), "Acid Techno": (0, .08), "Hard Techno": (0, .03), "House": (.04, .14), "Electro": (0, .08),
           "Techno Trax": (0, .03), "Tunnel Trance": (0, .02), "Trance": (0, .02), "Psytrance": (0, .02), "DnB": (0, .07), "Liquid DnB": (.03, .10),
           "Neurofunk": (0, .04), "Space Electronica": (0, .10), "Berlin School": (0, .06), "Baroque": (0, .03), "Romantic": (0, .03), "Minimal Classical": (0, .03),
           "Jazz": (0, .08), "Jazz Rock": (.02, .09), "Experimental": (0, .12), "Raw Synthesis": (0, .08)}
SWING8_R = {"House": (0.0, 0.06), "Jazz": (0.10, 0.16), "Jazz Rock": (0.03, 0.09), "Experimental": (0.0, 0.12)}

LEAD_OK = {"Brostep": ["accent", "rare", "melodic"], "Riddim": ["rare", "none"], "Tearout": ["accent", "rare"], "Melodic": ["melodic", "accent"],
           "Deep": ["none", "rare"], "Dubstep": ["rare", "accent"], "Drumstep": ["melodic", "accent"], "Trap": ["rare", "accent"], "EDM": ["melodic", "accent"]}
REESE_OK = {"Brostep": ["late", "all", "none"], "Riddim": ["none", "late"], "Tearout": ["all", "late"], "Melodic": ["all", "late"], "Deep": ["all", "late", "none"],
            "Dubstep": ["late", "all", "none"], "Drumstep": ["all", "late"], "Trap": ["none", "late"], "EDM": ["all", "late"]}

# paleta stopni do podmian w progresjach (0 = tonika; 1 = II / frygijska bII; 5 = VI; 6 = VII ...)
PAL = {"Techno": [0, 5, 6, 1], "Acid Techno": [0, 5, 6], "Hard Techno": [0, 1, 5, 6], "Psytrance": [0, 1, 6, 5], "Techno Trax": [5, 2, 6, 3, 4],
       "Tunnel Trance": [5, 2, 6, 3, 4], "Trance": [5, 2, 6, 3, 4], "EDM": [3, 4, 5, 2, 6], "House": [1, 3, 4, 5, 6, 2], "Electro": [5, 3, 6, 2],
       "DnB": [5, 6, 1, 3], "Liquid DnB": [3, 5, 2, 6, 4], "Neurofunk": [1, 5, 6], "Space Electronica": [3, 4, 5, 2, 6], "Berlin School": [3, 4, 5, 2, 6],
       "Raw Synthesis": [3, 4, 5], "Experimental": [1, 6, 3, 5, 2, 4], "Minimal Classical": [5, 3, 4, 2], "Jazz Rock": [3, 6, 5, 2, 4], "Romantic": [5, 3, 4, 2, 6]}
CHAIN = {"Jazz", "Baroque", "Liquid DnB", "Trance", "Romantic", "Jazz Rock", "Techno Trax", "Tunnel Trance"}       # + łańcuchy kwintowe (ii–V–I, VI–II–V–I…)
HALF_PAL = [0, 5, 6, 3, 2, 4]

# zakresy długości sekcji (takty); dropy w stylach klubowych nie krótsze niż 16
SEC_R = {"intro": (4, 32), "build": (4, 16), "drop": (8, 48), "break": (4, 32), "outro": (4, 32)}
EXTRA_KEEP = {"crash", "riser", "clap"}             # efekty strukturalne — nie wycinamy

KICK_STEPS_HALF = {3: 1, 6: 2, 7: 2, 10: 3, 11: 1.5, 13: 1.5, 14: 2}
HALF_EXTRA_N = {"Riddim": (0, 1), "Deep": (1, 2), "Melodic": (1, 1), "Dubstep": (1, 2), "Brostep": (1, 3), "Tearout": (2, 4), "Trap": (2, 3)}
TWO_EXTRA_N = {"Drumstep": (0, 2), "DnB": (0, 2), "Liquid DnB": (0, 1), "Neurofunk": (1, 2)}
AMBIENT_KICKS = [[0, 8], [0], [0, 8, 14], [0, 6, 8], [0, 10], [0, 4, 8]]
JAZZ_KICKS = [[0], [0, 8], [0, 6, 8], [0, 10], [0, 3, 8]]
GHOST_STEPS = [2, 3, 6, 7, 9, 10, 11, 14, 15]


# ------------------------------------------------------------------ pomocnicze
def _act(rng, p, w):
    """Czy zastosować swobodę: prawdopodobieństwo bazowe p skalowane pokrętłem (w=0.6 ≈ p)."""
    return rng.random() < min(0.95, p * (0.25 + 1.25 * w))


def _wchoice(rng, weights: dict):
    tot = sum(weights.values()); x = rng.uniform(0, tot); acc = 0.0
    for k, v in weights.items():
        acc += v
        if x <= acc:
            return k
    return next(iter(weights))


def _pick_steps(rng, weights: dict, n: int, gap: int = 2, have=()):
    """Losuje n różnych kroków (z wagami) z zachowaniem minimalnego odstępu."""
    out, pool = list(have), dict(weights)
    for _ in range(n):
        pool = {s: v for s, v in pool.items() if all(abs(s - o) >= gap for o in out)}
        if not pool:
            break
        s = _wchoice(rng, pool); out.append(s)
    return sorted(set(out))


def _kick_patterns(style, base, rng, w):
    """Nowe wzory stopy zgodne z gatunkiem; zwraca pulę (oryginały + nowe) albo None gdy stopa jest niezmiennikiem."""
    new = []
    n_new = 1 + int(round(2 * w))
    for _ in range(n_new * 3):
        if len(new) >= n_new:
            break
        if style in HALF:
            lo, hi = HALF_EXTRA_N[style]; k = rng.randint(lo, hi)
            pat = _pick_steps(rng, KICK_STEPS_HALF, k, 2, have=[0])              # nigdy 4 / 8 / 12: werbel jest na 8
        elif style in TWOSTEP:
            lo, hi = TWO_EXTRA_N[style]; k = rng.randint(lo, hi)
            second = _wchoice(rng, {10: .7, 9: .12, 11: .18})
            pat = _pick_steps(rng, {6: 2, 7: 2, 13: 1.5, 14: 2, 15: 1}, k, 2, have=[0, second])
        elif style in ("Electro", "Jazz Rock"):
            pat = _pick_steps(rng, {3: 1, 6: 2, 7: 2, 10: 3, 11: 1, 14: 2, 15: 1}, rng.randint(1, 3), 2, have=[0])
        elif style == "Experimental":
            first = [0] if rng.random() < .6 else [rng.choice([3, 5])]
            pat = _pick_steps(rng, {2: 1, 3: 1, 5: 1, 7: 1.5, 9: 1, 11: 1.5, 13: 1, 14: 1}, rng.randint(1, 3), 2, have=first)
        elif style == "Raw Synthesis":
            pat = _pick_steps(rng, {6: 2, 8: 2, 10: 2}, rng.randint(1, 2), 2, have=[0])     # snare [12]: stopa nie na 12
        elif style in AMBIENT:
            pat = list(rng.choice(AMBIENT_KICKS))
        elif style in JAZZ:
            pat = list(rng.choice(JAZZ_KICKS))
        else:
            return None
        if pat and pat not in base and pat not in new:
            new.append(pat)
    if not new:
        return None
    pool = [list(p) for p in base] + new
    if w > 0.8 and len(pool) > 3:                                                   # przy dużej swobodzie część oryginałów (poza pierwszym) wypada
        keep = [pool[0]] + [p for p in pool[1:] if rng.random() > 0.3 * (w - 0.7) * 3]
        pool = keep if len(keep) >= 2 else pool
    return pool[:7]


def _ghost(style, rng, w):
    if style in TWOSTEP:
        n = {"Liquid DnB": (2, 4), "DnB": (1, 3), "Drumstep": (0, 2), "Neurofunk": (0, 1)}[style]; vel = (30, 52)
    elif style == "House":
        if rng.random() > .4 * (.3 + w):
            return None
        n, vel = (1, 2), (28, 38)
    elif style == "Techno":
        if rng.random() > .2 * (.3 + w):
            return None
        n, vel = (1, 1), (28, 36)
    elif style in ("Electro", "Jazz Rock"):
        n, vel = (2, 4), (38, 56)
    elif style in JAZZ:
        n, vel = (3, 5), (44, 58)
    elif style == "Experimental":
        n, vel = (2, 4), (34, 48)
    else:
        return None
    k = rng.randint(*n)
    steps = _pick_steps(rng, {s: 1 for s in GHOST_STEPS}, k, 1)
    return [[s, rng.randint(*vel)] for s in steps] or None


def _snare_steps(style, rng):
    """Werbel zmieniamy tylko tam, gdzie gatunek na to pozwala (eksperyment / raw)."""
    if style == "Experimental":
        return rng.choice([[6, 13], [4, 12], [5, 12], [4, 11], [12], [8], [6, 12]])
    if style == "Raw Synthesis":
        return rng.choice([[12], [4, 12], [8], [10]])
    return None


def _chain_end(length, rng, end=0):
    seq = [end]
    for _ in range(length - 1):
        seq.insert(0, (seq[0] + 4) % 7)             # poprzednik w kwintach: V→I, II→V, VI→II…
    return seq


def _mut_prog(p, pal, rng, keep_first=True):
    q = list(p)
    op = rng.choice(["sub", "sub", "rot", "dup", "trim"])
    if op == "sub" and len(q) > 1:
        i = rng.randrange(1 if keep_first else 0, len(q))
        c = [d for d in pal if d != q[i]]
        if c:
            q[i] = rng.choice(c)
    elif op == "rot" and len(q) > 2:
        t = q[1:]; q = q[:1] + t[1:] + t[:1] if keep_first else q[1:] + q[:1]
    elif op == "dup" and len(q) <= 4:
        q = q + q[:-1] + [rng.choice(pal)]
    elif op == "trim" and len(q) >= 4:
        q = q[:len(q) // 2] or q
    return q


def _progs(style, base, rng, w):
    pal = PAL.get(style, HALF_PAL if style in HALF else [0, 5, 6, 3])
    pool = [list(p) for p in base]
    new = []
    for _ in range(1 + int(round(2 * w))):
        if style in CHAIN and rng.random() < .5:
            end = 0 if style not in ("Romantic", "Baroque") or rng.random() < .7 else rng.choice([0, 5])
            new.append(_chain_end(rng.choice([3, 4, 4, 5]), rng, end) + ([0] if rng.random() < .5 and end == 0 else []))
        else:
            src = list(rng.choice(pool))
            new.append(_mut_prog(src, pal, rng, keep_first=style not in JAZZ and style != "House"))
    out = pool[:]
    for p in new:
        p = [int(d) % 7 for d in p][:8]
        if p and p not in out:
            out.append(p)
    return out if len(out) > len(pool) or style in HALF else None


def _template(tpl, style, rng, w):
    t = [[n, int(b)] for n, b in tpl]
    club = style in HALF or style in TWOSTEP or style in FOUR
    changed = False
    for s in t:
        if _act(rng, 0.45, w):
            lo, hi = SEC_R[s[0]]
            if club and s[0] == "drop":
                lo = 16
            nb = int(round(s[1] * rng.choice([0.5, 0.75, 1.0, 1.0, 1.5, 2.0]) / 4) * 4)
            nb = max(lo, min(hi, nb))
            if nb != s[1]:
                s[1] = nb; changed = True
    if t and t[0][0] == "intro" and t[-1][0] == "outro":                            # intro pierwsze, outro ostatnie (niezmiennik)
        pass
    return t if changed else None


def _extras(style, cfg, family_pool, rng, w):
    ex = list(cfg.get("extras") or [])
    core = set(cfg.get("core") or [])
    out = list(ex)
    for t in [t for t in out if t not in EXTRA_KEEP and t not in core]:
        if len(out) > 5 and _act(rng, 0.18, w):
            out.remove(t)
    cand = [t for t in family_pool if t not in out and t not in core]
    rng.shuffle(cand)
    for t in cand[:2]:
        if _act(rng, 0.30, w):
            out.append(t)
    rng.shuffle(out)                                                                 # kolejność wpływa na dobór przy ograniczonej liczbie instrumentów
    return out if out != ex else None


# ------------------------------------------------------------------ biblioteki wzorów basu / growla: próbkowanie z wyuczonych niezmienników
def _learn(lib):
    pats = [p for p in lib if p]
    if not pats:
        return None
    starts = [[s for s, _, _ in p] for p in pats]
    g = 0
    for ss in starts:
        for s in ss:
            g = math.gcd(g, s)
    g = g or 1
    toks = {}
    for p in pats:
        for _, t, _ in p:
            toks[t] = toks.get(t, 0) + 1
    return dict(first=[p[0][0] for p in pats], first_tok=[p[0][1] for p in pats], g=g, nmin=min(len(p) for p in pats), nmax=max(len(p) for p in pats),
                lens=sorted({ln for p in pats for _, _, ln in p}), toks=toks,
                cmin=min(sum(ln for _, _, ln in p) for p in pats) / 16.0, cmax=max(sum(ln for _, _, ln in p) for p in pats) / 16.0)


def _vary_lib(lib, rng, w):
    L = _learn(lib)
    if not L:
        return None
    new = []
    n_new = 1 + int(round(2 * w))
    for _ in range(80):
        if len(new) >= n_new:
            break
        n = rng.randint(L["nmin"], max(L["nmin"], min(16, L["nmax"] + (1 if w > .6 else 0))))
        first = rng.choice(L["first"])
        pool = [s for s in range(first + L["g"], 16, L["g"])]
        if len(pool) < n - 1:
            continue
        starts = sorted([first] + rng.sample(pool, n - 1))
        pat = []
        for i, s in enumerate(starts):
            nxt = starts[i + 1] if i + 1 < len(starts) else 16
            ln = max(1, min(nxt - s, rng.choice(L["lens"])))
            tok = rng.choice(L["first_tok"]) if i == 0 else _wchoice(rng, L["toks"])
            pat.append([s, tok, ln])
        cov = sum(ln for _, _, ln in pat) / 16.0
        if not (L["cmin"] - .12 <= cov <= L["cmax"] + .12):
            continue
        if pat in new or [list(e) for e in pat] in [[list(e) for e in p] for p in lib]:
            continue
        new.append(pat)
    return [[list(e) for e in p] for p in lib] + new if new else None


# ------------------------------------------------------------------ jeden styl → delta konfiguracji
def _family_pool(style, G):
    ex = []
    for g, ss in ST.GROUPS:
        if style in ss:
            for n in ss:
                for t in dict.__getitem__(G.STYLES, n).get("extras", []):
                    if t not in ex:
                        ex.append(t)
    return ex


def vary(style, cfg, G, rng, w):
    """-> (delta konfiguracji, {"WOB": {klucz: wzory}, "GROWL": {...}}) dla czystego stylu podstawowego."""
    d, libs = {}, {}
    r = BPM_R.get(style, 0)
    if r:
        d["bpm"] = int(round(cfg["bpm"] + rng.uniform(-r, r) * w))
    if style in SWING_R and _act(rng, 0.8, w):
        lo, hi = SWING_R[style]; base = float(cfg.get("swing", 0.0))
        d["swing"] = round(max(lo, min(hi, base + rng.uniform(-(hi - lo), hi - lo) * .5 * w)) if hi > lo else base, 3)
    if style in SWING8_R and _act(rng, 0.7, w):
        lo, hi = SWING8_R[style]; d["swing8"] = round(rng.uniform(lo, hi), 3)
    if style in HAT_W and cfg.get("hat") not in ("none", "ride") and _act(rng, 0.7, w):
        d["hat"] = _wchoice(rng, HAT_W[style])
    if style in SUB_OK and _act(rng, 0.7, w):
        d["sub_mode"] = rng.choice(SUB_OK[style])
    if not cfg.get("fourfloor"):
        kp = _kick_patterns(style, cfg.get("kick") or [[0]], rng, w)
        if kp:
            d["kick"] = kp
    g = _ghost(style, rng, w)
    if g is not None and _act(rng, 0.85, w):
        d["ghost"] = g
    sn = _snare_steps(style, rng)
    if sn and _act(rng, 0.8, w):
        d["snare"] = sn
    if _act(rng, 0.85, w):
        from . import generator as _G
        pr = _progs(style, cfg.get("progs") or _G.PROGS, rng, w)
        if pr:
            d["progs"] = pr
    if style in LEAD_OK and _act(rng, 0.5, w):
        d["lead"] = rng.choice(LEAD_OK[style])
    if style in REESE_OK and _act(rng, 0.5, w):
        d["reese"] = rng.choice(REESE_OK[style])
    if style in HALF | TWOSTEP | {"EDM"} and _act(rng, 0.4, w):
        d["chord_len"] = rng.choice([1, 2])
    for key in ("wob_div", "growl_div"):
        base = list(cfg.get(key) or [])
        if base and style in HALF | TWOSTEP | {"EDM"} and _act(rng, 0.5, w):
            ext = set(base)
            for v in rng.sample(base, min(2, len(base))):
                ext.add(max(2, min(12, v + rng.choice([-1, 1]))))
            d[key] = sorted(ext)
    tp = _template(cfg["template"], style, rng, w)
    if tp:
        d["template"] = tp
    ex = _extras(style, cfg, _family_pool(style, G), rng, w)
    if ex:
        d["extras"] = ex
    mu = dict(cfg.get("mutate") or {})
    if style in CLASSIC | JAZZ | AMBIENT | {"Experimental"}:
        mu.update(drop=round(.03 * w, 3), jitter=round(.05 * w, 3), octave=round(.04 * w, 3), shift=round(.06 * w, 3))
    else:                                                                            # basowe gatunki: bez zmiany oktawy (sub / wobble)
        mu.update(drop=round(max(mu.get("drop", 0), .03 * w), 3), jitter=round(max(mu.get("jitter", 0), .05 * w), 3))
    if mu:
        d["mutate"] = mu
    for libname, key in (("WOB", cfg.get("wob")), ("GROWL", cfg.get("growl") if style in HALF | TWOSTEP else None)):
        if key and not str(key).startswith("sp:") and _act(rng, 0.85, w):
            lib = getattr(G, libname).get(key) if hasattr(G, libname) else None
            nv = _vary_lib(lib or [], rng, w) if lib else None
            if nv:
                libs.setdefault(libname, {})[key] = nv
    return d, libs


# ------------------------------------------------------------------ plan projektu, materializacja, zakres
def components(style, G):
    parts = G.STYLES.parts(style)
    return [n for n in parts if n in ST.ORDER]


def plan(style, seed, wild):
    """Wariant stylu dla projektu (JSON) albo None gdy wild <= 0 / brak stylów podstawowych."""
    w = max(0.0, min(1.0, float(wild or 0.0)))
    if w <= 0.0:
        return None
    from . import generator as G
    cfgs, libs = {}, {"WOB": {}, "GROWL": {}}
    for s in components(style, G):
        rng = random.Random(f"wild:{seed}:{s}")
        d, lb = vary(s, dict.__getitem__(G.STYLES, s), G, rng, w)
        if d:
            cfgs[s] = d
        for ln, items in lb.items():
            for k, v in items.items():
                libs[ln].setdefault(k, v)
    if not cfgs and not any(libs.values()):
        return None
    return dict(wild=round(w, 3), seed=int(seed), cfg=cfgs, libs={k: v for k, v in libs.items() if v})


def materialize(pl):
    """plan → (słowniki konfiguracji {styl: pełna konfiguracja}, nakładki bibliotek)."""
    from . import generator as G
    over = {}
    for s, delta in (pl.get("cfg") or {}).items():
        c = dict(dict.__getitem__(G.STYLES, s)); c.update(copy.deepcopy(delta)); over[s] = c
    return over, copy.deepcopy(pl.get("libs") or {})


def scope_for(pl):
    """Kontekst, w którym STYLES[...] / WOB / GROWL widzą wariant (wątkowo-lokalnie)."""
    if not pl:
        return contextlib.nullcontext()
    over, libs = materialize(pl)
    return ST.variant_scope(over, libs)


def scope_for_proj(proj):
    return scope_for((proj or {}).get("style_variant"))


def in_variant(fn):
    """Dekorator: funkcja (pierwszy argument = proj) widzi wariant stylu zapisany w projekcie."""
    import functools

    @functools.wraps(fn)
    def wrapped(proj, *a, **k):
        with scope_for_proj(proj):
            return fn(proj, *a, **k)
    return wrapped


def summary(pl):
    """Krótki opis wariantu (do paska stanu / podpowiedzi)."""
    if not pl:
        return "styl: bez wariantu (dawne wzory)"
    rows = []
    for s, d in pl["cfg"].items():
        bits = []
        if "bpm" in d: bits.append(f"{d['bpm']} BPM")
        if "hat" in d: bits.append(f"hat {d['hat']}")
        if "kick" in d: bits.append(f"{len(d['kick'])} wz. stopy")
        if "sub_mode" in d: bits.append(f"sub {d['sub_mode']}")
        if "progs" in d: bits.append(f"{len(d['progs'])} progresji")
        rows.append(f"{s}: " + ", ".join(bits))
    return "wariant stylu (" + f"{pl['wild']:.0%}" + "): " + "; ".join(rows)
