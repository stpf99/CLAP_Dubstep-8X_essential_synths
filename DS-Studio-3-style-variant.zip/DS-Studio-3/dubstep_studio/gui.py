"""gui.py — DS Dubstep Studio (PyQt6): generator, ścieżki/parametry, linki, biblioteka, auto-remix."""
from __future__ import annotations

import copy
import os
import random
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import core, generator as G, live as L, noteops as N, presets as PR, remix as R, styles as ST
from .board_gui import BoardTab
from .live_gui import LiveTab

DYN_PARAMS = (
    "Dynamics", "Dyn Preset", "Dyn Amount",
    "Dyn Curve", "Dyn Detect", "Dyn Knee",
    "Low Ratio", "Mid Ratio", "High Ratio",
    "Low Thresh", "Mid Thresh", "High Thresh",
    "Low Trim", "Mid Trim", "High Trim",
    "Expander", "Expand Ratio",
)
DYN_MODE_PL = {"Off": "Wyłączony", "Limiter 3-Band": "Limiter 3-pasmowy", "Normalizer 3-Band": "Normalizer 3-pasmowy"}
DYN_CURVE_PL = {
    "Linear (skos)": "Równomierne obniżanie — klasyczny skos.",
    "Logarithmic": "Łagodniejszy start, potem mocniej (domyślny, dobry na bas).",
    "Convex (wypukła)": "Wolny początek, potem ostre cięcie.",
    "Concave (wklęsła)": "Ostry start (szybko łapie peak), potem łagodnieje — najlepsze na trzęsące kolumny.",
}
DYN_PRESET_INFO = {
    "Transparent": "Łagodny: łapie tylko szczyty, normalizer celuje ok. −18 dB na pasmo. Podział 150 Hz / 2,5 kHz.",
    "Bass Tight": "Pilnuje dołu: bas mocno kontrolowany, góra ścięta. Dobry dla basów i wobble. Podział 120 Hz / 1,8 kHz.",
    "Punchy": "Wolniejszy atak zostawia transjenty (stopy, werble). Podział 200 Hz / 3 kHz.",
    "Loud": "Głośny: +8 dB przed limiterem, szybkie czasy. Uwaga: przy normalizerze na perkusji wyciąga ogony.",
    "Bright Lead": "Poskramia górę i dół, środek zostaje. Dla leadów i supersaw. Podział 250 Hz / 4 kHz.",
    "Warm Pad": "Bardzo wolny, gładki (release 250–400 ms). Dla padów i drone'ów.",
    "Sub Focus": "Skupiony na subie: mocny dół, środek i góra mocno przyciszone. Podział 90 Hz / 900 Hz.",
    "Less Bass": "Mniej basu: pasmo poniżej ok. 150 Hz stale przycięte o ok. 5 dB (ściszane przez Siłę) + niższy sufit dołu. Domyślny preset. Dotyczy też stóp i subów.",
}
GROUP_COL = {"Perkusja": "#e5484d", "Bas": "#2dd4bf", "Synth / lead": "#c4b5fd", "FX": "#f5a524", "Mowa": "#60a5fa", "Akustyczne": "#34d399"}


def tcolor(ttype):
    for g, ts in core.GROUPS.items():
        if ttype in ts:
            c = QtGui.QColor(GROUP_COL.get(g, "#a78bfa"))
            i = ts.index(ttype)
            return c.lighter(100 + min(8, i) * 5) if i % 2 else c.darker(100 + min(8, i) * 4)
    return QtGui.QColor("#9ca3af")
SECCOL = {"intro": "#1f2937", "build": "#3b2f12", "drop": "#3a1217", "break": "#12303a", "outro": "#1f2937"}


class Worker(QtCore.QThread):
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(str)
    prog = QtCore.pyqtSignal(float)

    def __init__(self, fn):
        super().__init__(); self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(self.prog.emit))
        except Exception:
            self.fail.emit(traceback.format_exc())


class Player:
    def __init__(self):
        self.proc = None; self.t0 = 0.0

    def play(self, path):
        self.stop()
        ext = str(path).lower().rsplit(".", 1)[-1]
        order = (["ffplay", "mpv", "pw-play", "paplay", "aplay"] if ext == "mp3" else ["pw-play", "paplay", "aplay", "ffplay", "mpv"])
        dev = os.environ.get("DS_AUDIO_DEVICE", "").strip()      # to samo urządzenie co w Live ([live] audio_device)
        args = {"ffplay": ["-nodisp", "-autoexit", "-loglevel", "quiet"], "mpv": ["--no-video", "--really-quiet"] + ([f"--audio-device={dev}"] if dev else []),
                "aplay": ["-q"] + (["-D", dev] if dev else []), "pw-play": ["--target", dev] if dev else [], "paplay": [f"--device={dev}"] if dev else []}
        for c in order:
            exe = shutil.which(c)
            if exe and (c not in ("pw-play", "paplay") or L.StreamPlayer.usable("pw-cat" if c == "pw-play" else "paplay")):
                self.proc = subprocess.Popen([exe] + args.get(c, []) + [str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.t0 = time.time()
                return True
        return False

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
        self.proc = None

    def elapsed(self):
        return time.time() - self.t0 if self.proc and self.proc.poll() is None else None


class Overview(W.QWidget):
    """Podgląd aranżacji: pasy z nutami + sekcje + playhead. Przeciągnięcie myszą zaznacza okno taktów (do edycji grupy nut)."""
    selChanged = QtCore.pyqtSignal(int, int)

    def __init__(self):
        super().__init__(); self.proj = None; self.head = None; self.sel = None; self._drag = None; self.setMinimumHeight(230)

    def _bar_at(self, x):
        p = self.proj
        if not p or not p["bars"]:
            return 0
        return max(0, min(p["bars"] - 1, int((x - 66) / max(1, self.width() - 70) * p["bars"])))

    def mousePressEvent(self, e):
        self._drag = self._bar_at(e.position().x()); self.sel = (self._drag, self._drag + 1)
        self.selChanged.emit(*self.sel); self.update()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            b = self._bar_at(e.position().x()); self.sel = (min(self._drag, b), max(self._drag, b) + 1)
            self.selChanged.emit(*self.sel); self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def set_project(self, p):
        self.proj = p; self.setMinimumHeight(max(230, 16 * len(p["tracks"]) + 30) if p else 230); self.update()

    def paintEvent(self, ev):
        qp = QtGui.QPainter(self); qp.fillRect(self.rect(), QtGui.QColor("#0f1115"))
        p = self.proj
        if not p or not p["bars"]:
            return
        w, h, top = self.width() - 70, self.height() - 22, 18
        beats = p["bars"] * 4; lane = h / max(1, len(p["tracks"]))
        for s in p["sections"]:
            x0 = 66 + s["start"] * 4 / beats * w; x1 = 66 + (s["start"] + s["bars"]) * 4 / beats * w
            qp.fillRect(QtCore.QRectF(x0, top, x1 - x0, h), QtGui.QColor(SECCOL[s["type"]]))
            qp.setPen(QtGui.QColor("#9ca3af")); qp.drawText(QtCore.QPointF(x0 + 3, 12), s["name"])
        for i, t in enumerate(p["tracks"]):
            y0 = top + i * lane
            qp.setPen(tcolor(t["type"])); qp.drawText(QtCore.QPointF(4, y0 + min(lane * 0.8, 12)), t["name"])
            qp.setPen(QtGui.QColor("#1b1f27")); qp.drawLine(66, int(y0 + lane), 66 + int(w), int(y0 + lane))
            if not t["notes"]:
                continue
            ks = [n[2] for n in t["notes"]]; lo, hi = min(ks), max(ks); rng = max(1, hi - lo)
            nh = max(1.5, min(6.0, (lane - 3) / (rng + 1)))
            col = QtGui.QColor(tcolor(t["type"])); col.setAlpha(120 if t["mute"] else 230)
            for on, dur, key, vel in t["notes"]:
                x = 66 + on / beats * w
                y = y0 + 2 + (lane - 4 - nh) * (1 - (key - lo) / rng)
                qp.fillRect(QtCore.QRectF(x, y, max(1.2, dur / beats * w), nh), col)
        if self.sel:
            x0 = 66 + self.sel[0] * 4 / beats * w; x1 = 66 + self.sel[1] * 4 / beats * w
            qp.fillRect(QtCore.QRectF(x0, top, max(2.0, x1 - x0), h), QtGui.QColor(255, 255, 255, 45))
            qp.setPen(QtGui.QColor("#ffffff")); qp.drawRect(QtCore.QRectF(x0, top, max(2.0, x1 - x0), h))
        if self.head is not None:
            x = 66 + min(1.0, self.head / beats) * w
            qp.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 1)); qp.drawLine(int(x), top, int(x), top + int(h))



class StyleCreatorDialog(W.QDialog):
    """Kreator stylu: baza predefiniowana → korekta / randomizacja → zapis własnego stylu."""

    HATS = ["16", "8", "trap", "offbeat", "off", "ride", "none"]
    WOBS = ["brostep", "riddim", "tearout", "melodic", "deep", "techno", "hard", "acid", "roll", "ambient", "seq", "classic", "baroque"]
    GROWLS = ["brostep", "riddim", "tearout", "melodic", "deep", "neurof"]
    REESE = ["none", "late", "all"]
    LEADS = ["none", "rare", "accent", "melodic"]
    SUBS = ["hold", "offbeat", "roll", "pulse8", "funk", "walk", "off"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Kreator stylu")
        self.setMinimumSize(640, 560)
        self._knobs = {}
        self._base_name = "Brostep"
        lay = W.QVBoxLayout(self)
        row = W.QHBoxLayout()
        row.addWidget(W.QLabel("Baza:"))
        self.base = W.QComboBox(); self.base.addItems(list(ST.ORDER))
        self.base.currentTextChanged.connect(self.load_base)
        row.addWidget(self.base, 1)
        b_load = W.QPushButton("Wczytaj bazę"); b_load.clicked.connect(lambda: self.load_base(self.base.currentText()))
        b_rnd = W.QPushButton("Randomizuj"); b_rnd.setToolTip("Losuje pokrętła wokół aktualnej bazy")
        b_rnd.clicked.connect(self.randomize)
        row.addWidget(b_load); row.addWidget(b_rnd)
        lay.addLayout(row)
        form = W.QFormLayout()
        self.name = W.QLineEdit(); self.name.setPlaceholderText("Nazwa nowego stylu (np. MyTear)")
        self.bpm = W.QSpinBox(); self.bpm.setRange(60, 200)
        self.swing = W.QDoubleSpinBox(); self.swing.setRange(0, 0.2); self.swing.setSingleStep(0.01)
        self.hat = W.QComboBox(); self.hat.addItems(self.HATS)
        self.wob = W.QComboBox(); self.wob.addItems(self.WOBS)
        self.growl = W.QComboBox(); self.growl.addItems(self.GROWLS)
        self.reese = W.QComboBox(); self.reese.addItems(self.REESE)
        self.lead = W.QComboBox(); self.lead.addItems(self.LEADS)
        self.sub_mode = W.QComboBox(); self.sub_mode.addItems(self.SUBS)
        self.chord_len = W.QSpinBox(); self.chord_len.setRange(1, 8)
        self.cls = W.QDoubleSpinBox(); self.cls.setRange(0, 5); self.cls.setSingleStep(0.5)
        self.cls.setToolTip("Klasa ostrości 0 (łagodny) … 5 (agresywny) — STYLE_CLASS")
        for lbl, w in (("Nazwa stylu", self.name), ("BPM", self.bpm), ("Swing", self.swing), ("Hat", self.hat),
                       ("Wobble", self.wob), ("Growl", self.growl), ("Reese", self.reese), ("Lead", self.lead),
                       ("Sub mode", self.sub_mode), ("Chord len", self.chord_len), ("Ostrość (0–5)", self.cls)):
            form.addRow(lbl, w)
        lay.addLayout(form)
        # instrumenty
        ig = W.QGroupBox("Core / Extras (zaznacz)"); il = W.QHBoxLayout(ig)
        self.core_list = W.QListWidget(); self.core_list.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.ex_list = W.QListWidget(); self.ex_list.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        for t_ in core.TYPES:
            if t_ in core.OPTIONAL:
                continue
            self.core_list.addItem(t_); self.ex_list.addItem(t_)
        il.addWidget(W.QLabel("Core:")); il.addWidget(self.core_list, 1)
        il.addWidget(W.QLabel("Extras:")); il.addWidget(self.ex_list, 1)
        lay.addWidget(ig)
        self.preview = W.QPlainTextEdit(); self.preview.setReadOnly(True); self.preview.setMaximumHeight(100)
        lay.addWidget(self.preview)
        btns = W.QHBoxLayout()
        b_apply = W.QPushButton("Zastosuj w Generatorze (bez zapisu)")
        b_save = W.QPushButton("Zapisz styl")
        b_del = W.QPushButton("Usuń zapisany")
        b_close = W.QPushButton("Zamknij")
        b_apply.clicked.connect(self.apply_to_gen)
        b_save.clicked.connect(self.save_style)
        b_del.clicked.connect(self.delete_style)
        b_close.clicked.connect(self.reject)
        for b in (b_apply, b_save, b_del, b_close):
            btns.addWidget(b)
        lay.addLayout(btns)
        self.load_base(self.base.currentText())

    def _selected(self, lw):
        return [it.text() for it in lw.selectedItems()]

    def _select(self, lw, names):
        names = set(names)
        for i in range(lw.count()):
            it = lw.item(i)
            it.setSelected(it.text() in names)

    def load_base(self, name=None):
        name = name or self.base.currentText()
        self._base_name = name
        try:
            cfg = G.STYLES[name]
        except KeyError:
            return
        k = ST.style_knobs_from(cfg)
        self._set_knobs(k)
        if not self.name.text().strip():
            self.name.setText(f"{name} Custom")
        self._refresh_preview()

    def _set_knobs(self, k):
        self.bpm.setValue(int(k.get("bpm", 140)))
        self.swing.setValue(float(k.get("swing", 0.0)))
        for cb, key, pool in ((self.hat, "hat", self.HATS), (self.wob, "wob", self.WOBS), (self.growl, "growl", self.GROWLS),
                              (self.reese, "reese", self.REESE), (self.lead, "lead", self.LEADS), (self.sub_mode, "sub_mode", self.SUBS)):
            v = k.get(key, pool[0])
            if v in pool:
                cb.setCurrentText(v)
        self.chord_len.setValue(int(k.get("chord_len", 2)))
        self.cls.setValue(float(k.get("_class", 2.5)))
        self._select(self.core_list, k.get("core") or [])
        self._select(self.ex_list, k.get("extras") or [])
        self._knobs = k

    def _gather(self):
        k = dict(self._knobs)
        k.update(bpm=self.bpm.value(), swing=self.swing.value(), hat=self.hat.currentText(), wob=self.wob.currentText(),
                 growl=self.growl.currentText(), reese=self.reese.currentText(), lead=self.lead.currentText(),
                 sub_mode=self.sub_mode.currentText(), chord_len=self.chord_len.value(),
                 core=self._selected(self.core_list), extras=self._selected(self.ex_list),
                 _class=self.cls.value())
        return k

    def _refresh_preview(self):
        k = self._gather()
        self.preview.setPlainText(
            f"BPM {k['bpm']}  swing {k['swing']}  hat={k['hat']} wob={k['wob']} growl={k['growl']}\n"
            f"reese={k['reese']} lead={k['lead']} sub={k['sub_mode']} chord_len={k['chord_len']} ostrość={k['_class']}\n"
            f"core: {', '.join(k['core'])}\nextras: {', '.join(k['extras'])}"
        )

    def randomize(self):
        k = ST.randomize_style_knobs(self._base_name, G.STYLES, random.Random())
        self._set_knobs(k)
        self._refresh_preview()

    def apply_to_gen(self):
        k = self._gather()
        name = self.name.text().strip() or f"{self._base_name} Custom"
        try:
            base_cfg = dict(G.STYLES[self._base_name])
        except KeyError:
            base_cfg = None
        cfg = ST.build_style_cfg(k, base_cfg)
        G.STYLES[name] = cfg
        ST.STYLE_CLASS[name] = float(k.get("_class", 2.5))
        ST.STYLE_COL.setdefault(name, k.get("_color", "#a78bfa"))
        if name not in ST.ORDER:
            ST.ORDER.append(name)
        mw = self.parent()
        if mw and hasattr(mw, "style"):
            if mw.style.findText(name) < 0:
                mw.style.addItem(name)
            mw.use_style(name)
            # ustaw instrumenty z core+extras
            mw.set_instruments(list(cfg.get("core", [])) + list(cfg.get("extras", [])))
            if hasattr(mw, "bpm"):
                mw.bpm.setValue(int(cfg.get("bpm", 140)))
            mw.status.setText(f"Kreator: zastosowano styl „{name}” w Generatorze (niezapisany na dysk, dopóki nie Zapisz)")
        self._refresh_preview()

    def save_style(self):
        k = self._gather()
        name = self.name.text().strip()
        if not name:
            W.QMessageBox.information(self, "Kreator", "Podaj nazwę stylu."); return
        try:
            base_cfg = dict(G.STYLES[self._base_name])
        except KeyError:
            base_cfg = None
        cfg = ST.build_style_cfg(k, base_cfg)
        ST.save_custom_style(name, cfg)
        G.STYLES[name] = cfg
        ST.STYLE_CLASS[name] = float(k.get("_class", 2.5))
        ST.STYLE_COL.setdefault(name, "#a78bfa")
        if name not in ST.ORDER:
            ST.ORDER.append(name)
        mw = self.parent()
        if mw and hasattr(mw, "style") and mw.style.findText(name) < 0:
            mw.style.addItem(name)
        W.QMessageBox.information(self, "Kreator", f"Zapisano styl „{name}”\n{ST.custom_styles_path()}")
        self._refresh_preview()

    def delete_style(self):
        name = self.name.text().strip()
        if not name:
            return
        ST.delete_custom_style(name)
        W.QMessageBox.information(self, "Kreator", f"Usunięto „{name}” z pliku użytkownika (wbudowane style zostają).")




class TimbreMuxDialog(W.QDialog):
    """Paleta muxu ustawień barwy + podsłuch krótkiej próbki."""

    def __init__(self, main, timbre_id, player):
        super().__init__(main)
        from . import timbre_bank as TB
        self.main = main
        self.player = player
        self.setWindowTitle(f"Mux barwy — {timbre_id}")
        self.resize(420, 480)
        self.timbre_id = timbre_id
        self.spec = dict(TB.TIMBRES.get(timbre_id) or {})
        lay = W.QVBoxLayout(self)
        lay.addWidget(W.QLabel(f"<b>{timbre_id}</b> — {self.spec.get('desc','')} (base: {self.spec.get('base')})"))
        self.sliders = {}
        form = W.QFormLayout()
        params = self.spec.get("params") or {}
        import random
        rng = random.Random()
        for name, val in params.items():
            if isinstance(val, (list, tuple)) and len(val) == 2:
                lo, hi = float(val[0]), float(val[1])
                cur = (lo + hi) / 2
            else:
                lo, hi, cur = 0.0, 1.0, float(val)
            s = W.QSlider(Qt.Orientation.Horizontal)
            s.setRange(0, 1000)
            s.setValue(int(cur * 1000))
            lbl = W.QLabel(f"{cur:.2f}")
            s.valueChanged.connect(lambda v, L=lbl: L.setText(f"{v/1000:.2f}"))
            row = W.QHBoxLayout(); row.addWidget(s, 1); row.addWidget(lbl)
            box = W.QWidget(); box.setLayout(row)
            form.addRow(name, box)
            self.sliders[name] = (s, lo, hi)
        lay.addLayout(form)
        self.stereo = W.QCheckBox("Stereo dual (2 instancje)")
        self.stereo.setChecked(bool(self.spec.get("stereo")))
        lay.addWidget(self.stereo)
        btns = W.QHBoxLayout()
        bp = W.QPushButton("Podsłuch próbki"); bp.clicked.connect(self._preview)
        ba = W.QPushButton("Zastosuj na projekt / tor"); ba.clicked.connect(self._apply)
        bc = W.QPushButton("Zamknij"); bc.clicked.connect(self.reject)
        btns.addWidget(bp); btns.addWidget(ba); btns.addWidget(bc)
        lay.addLayout(btns)

    def _params(self):
        out = {}
        for name, (s, lo, hi) in self.sliders.items():
            # slider 0..1 mapped - actually we used full 0..1 of param space from mid of window
            out[name] = s.value() / 1000.0
        return out

    def _preview(self):
        self.main._preview_extra_or_timbre(timbre=None, base=self.spec.get("base"), params=self._params())

    def _apply(self):
        from . import timbre_bank as TB
        if not self.main.proj:
            W.QMessageBox.information(self, "Mux", "Brak projektu.")
            return
        params = self._params()
        base = self.spec.get("base")
        tr = next((t for t in self.main.proj["tracks"] if t["type"] == base and not t.get("lock_sound")), None)
        if not tr:
            created = TB.spawn_timbre(self.main.proj, self.timbre_id)
            tr = created[0] if created else None
        if tr:
            tr.setdefault("params", {}).update(params)
            tr["timbre_id"] = self.timbre_id + "/mux"
            if self.stereo.isChecked() and not any(t.get("timbre_id", "").endswith("/muxR") for t in self.main.proj["tracks"]):
                # druga instancja
                TB.spawn_timbre(self.main.proj, self.timbre_id)
            self.main.set_project(self.main.proj)
            self.main.status.setText(f"Mux {self.timbre_id} → {tr['name']}")
        self.accept()





class GeometryCanvas(W.QWidget):
    """Proste płótno WYSIWYG: figury w normowanej przestrzeni 0..1 × 0..1."""

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.doc = {"shapes": [], "bars": 64}
        self._sel = None
        self._drag = None
        self.setMouseTracking(True)
        self.setBackgroundRole(QtGui.QPalette.ColorRole.Base)
        self.setAutoFillBackground(True)

    def set_doc(self, doc):
        self.doc = doc or {"shapes": [], "bars": 64}
        self.update()

    def selected_id(self):
        return self._sel

    def _map(self, x, y):
        return x * self.width(), y * self.height()

    def _unmap(self, x, y):
        return x / max(1, self.width()), y / max(1, self.height())

    def paintEvent(self, ev):
        from . import geometry_editor as GE
        p = QtGui.QPainter(self)
        p.fillRect(self.rect(), QtGui.QColor(28, 28, 32))
        # siatka taktów
        bars = max(1, int(self.doc.get("bars") or 64))
        pen = QtGui.QPen(QtGui.QColor(55, 55, 60)); pen.setStyle(Qt.PenStyle.DotLine)
        p.setPen(pen)
        for i in range(0, bars + 1, max(1, bars // 8)):
            x = int(i / bars * self.width())
            p.drawLine(x, 0, x, self.height())
        colors = {
            "contour": QtGui.QColor(80, 160, 255, 110),
            "intensity": QtGui.QColor(255, 140, 60, 110),
        }
        for sh in sorted(self.doc.get("shapes") or [], key=lambda s: s.get("z", 0)):
            col = colors.get(sh.get("channel"), QtGui.QColor(180, 180, 180, 100))
            if sh["id"] == self._sel:
                col = QtGui.QColor(col.red(), col.green(), col.blue(), 180)
            p.setBrush(col)
            pen = QtGui.QPen(QtGui.QColor(220, 220, 230) if sh["id"] == self._sel else QtGui.QColor(120, 120, 130))
            pen.setWidth(2 if sh["id"] == self._sel else 1)
            p.setPen(pen)
            self._draw_shape(p, sh)
            # etykieta
            cx = int((sh["x"] + sh["w"] / 2) * self.width())
            cy = int((sh["y"] + sh["h"] / 2) * self.height())
            p.setPen(QtGui.QColor(230, 230, 240))
            label = f"{sh.get('kind','')} / {sh.get('channel','')[:3]}"
            if sh.get("track"):
                label += f" [{sh['track']}]"
            p.drawText(cx - 40, cy, label)

    def _draw_shape(self, p, sh):
        x = int(sh["x"] * self.width()); y = int(sh["y"] * self.height())
        w = max(4, int(sh["w"] * self.width())); h = max(4, int(sh["h"] * self.height()))
        rot = sh.get("rot", 0)
        p.save()
        p.translate(x + w / 2, y + h / 2)
        p.rotate(rot)
        p.translate(-w / 2, -h / 2)
        kind = sh.get("kind") or "rect"
        if kind in ("rect", "square"):
            p.drawRect(0, 0, w, h)
        elif kind in ("ellipse", "circle"):
            p.drawEllipse(0, 0, w, h)
        elif kind == "triangle":
            path = QtGui.QPainterPath()
            path.moveTo(w / 2, 0); path.lineTo(w, h); path.lineTo(0, h); path.closeSubpath()
            p.drawPath(path)
        elif kind == "triangle_r":
            path = QtGui.QPainterPath()
            path.moveTo(0, 0); path.lineTo(w, 0); path.lineTo(w / 2, h); path.closeSubpath()
            p.drawPath(path)
        elif kind == "trapezoid":
            path = QtGui.QPainterPath()
            path.moveTo(w * 0.2, 0); path.lineTo(w * 0.8, 0); path.lineTo(w, h); path.lineTo(0, h); path.closeSubpath()
            p.drawPath(path)
        elif kind == "trapezoid_r":
            path = QtGui.QPainterPath()
            path.moveTo(0, 0); path.lineTo(w, 0); path.lineTo(w * 0.8, h); path.lineTo(w * 0.2, h); path.closeSubpath()
            p.drawPath(path)
        else:
            p.drawRect(0, 0, w, h)
        p.restore()

    def mousePressEvent(self, ev):
        from . import geometry_editor as GE
        ux, uy = self._unmap(ev.position().x(), ev.position().y())
        hit = None
        for sh in sorted(self.doc.get("shapes") or [], key=lambda s: -s.get("z", 0)):
            if GE.point_in_shape(ux, uy, sh):
                hit = sh["id"]; break
        self._sel = hit
        if hit and ev.button() == Qt.MouseButton.LeftButton:
            self._drag = (ux, uy, hit)
        self.update()

    def mouseMoveEvent(self, ev):
        if not self._drag:
            return
        ux, uy = self._unmap(ev.position().x(), ev.position().y())
        x0, y0, sid = self._drag
        dx, dy = ux - x0, uy - y0
        for sh in self.doc.get("shapes") or []:
            if sh["id"] == sid:
                sh["x"] = max(0.0, min(0.98, sh["x"] + dx))
                sh["y"] = max(0.0, min(0.98, sh["y"] + dy))
                break
        self._drag = (ux, uy, sid)
        self.update()

    def mouseReleaseEvent(self, ev):
        self._drag = None


class MainWindow(W.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DS Dubstep Studio")
        self.resize(1180, 820)
        self.meta = core.meta()
        try:
            from . import arranger as ARR
            ARR.load_bank()          # zapisane barwy/extras ad hoc → rejestry (widoczne w kartach Barwy/Extras)
        except Exception:
            pass
        self.proj = None; self.cache = {}; self.player = Player(); self.worker = None
        self.style_override = None   # nazwa hybrydy (z pola szachowego / projektu) zamiast stylu z listy
        self.remix_entries = []   # [(path, proj)]
        tabs = W.QTabWidget(); self.setCentralWidget(tabs)
        tabs.addTab(self._build_gen(), "Generator")
        self.board = BoardTab(self); tabs.addTab(self.board, "Pole stylów (hybrydy)")
        tabs.addTab(self._build_tracks(), "Ścieżki / parametry")
        tabs.addTab(self._build_replace(), "Instrument replace")
        tabs.addTab(self._build_creator(), "Kreator / Extras / Barwy")
        tabs.addTab(self._build_geometry(), "Edytor WYSIWYG")
        tabs.addTab(self._build_video(), "Wideo / RTMP")
        tabs.addTab(self._build_links(), "Linki (przekazywanie)")
        tabs.addTab(self._build_lib(), "Biblioteka")
        tabs.addTab(self._build_remix(), "Auto-remix")
        self.live = LiveTab(self)
        tabs.addTab(self.live, "Live / Endless")
        from .listen_gui import ListenTab
        self.listen_tab = ListenTab(self)
        tabs.addTab(self.listen_tab, "Nasłuch")
        from .modeling_gui import ModelTab
        self.model_tab = ModelTab(self); tabs.addTab(self.model_tab, "Modelowanie CLAP")
        self.tabs = tabs
        self.undo = {}
        self.ov.selChanged.connect(self._ov_sel)
        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(40)
        self.refresh_library()
        self.on_style(self.cur_style())
        self.live.apply_conf(self.live.conf)      # config.txt wygrywa z domyślnymi stylu
        self.refresh_presets()

    # ------------------------------------------------------------------ Generator
    def _build_gen(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        pb = W.QHBoxLayout(); pb.addWidget(W.QLabel("Preset:"))
        self.preset_cb = W.QComboBox(); self.preset_cb.setMinimumWidth(220); pb.addWidget(self.preset_cb, 1)
        for txt, fn in (("Wczytaj", self.preset_load), ("Zapisz jako…", self.preset_save), ("Usuń", self.preset_delete),
                        ("Eksportuj…", self.preset_export), ("Importuj…", self.preset_import),
                        ("Import MIDI…", self.preset_import_midi)):
            b = W.QPushButton(txt); b.clicked.connect(fn); pb.addWidget(b)
        v.addLayout(pb)
        f = W.QFormLayout()
        self.style = W.QComboBox(); self.style.addItems(ST.ORDER + [s_ for s_ in G.STYLES if s_ not in ST.ORDER]); self.style.currentTextChanged.connect(self._combo_style)
        self.style_lbl = W.QLabel(""); self.style_lbl.setWordWrap(True)
        self.scene_apply = W.QCheckBox("Komplet sceny stylu")
        self.scene_apply.setChecked(True)
        self.scene_apply.setToolTip('Po wyborze stylu/hybrydy lub Losuj styl ustawia pełny zestaw parametrów charakterystycznych dla gatunku: energia, gęstość, skala, długość, spektakularność, epoka, charakter, reżyser, niuanse, uniq, arp.')
        self.b_rnd_style = W.QPushButton("Losuj styl")
        self.b_rnd_style.setToolTip('Losuje styl z listy i (gdy zaznaczono) stosuje komplet sceny')
        self.b_rnd_style.clicked.connect(self.randomize_style_scene)
        self.b_style_creator = W.QPushButton("Kreator stylu…")
        self.b_style_creator.setToolTip("Konstruktor: baza predefiniowana → korekta / randomizacja → zapis własnego stylu")
        self.b_style_creator.clicked.connect(self.open_style_creator)
        self.bpm = W.QSpinBox(); self.bpm.setRange(60, 200)
        self.keyc = W.QComboBox(); self.keyc.addItems(["losowa"] + core.NOTE_NAMES)
        self.scale = W.QComboBox(); self.scale.addItems(core.SCALES.keys())
        self.bars = W.QSpinBox(); self.bars.setRange(32, 256); self.bars.setSingleStep(8); self.bars.setValue(144)
        self.energy = self._slider(70); self.density = self._slider(60); self.swing = self._slider(0)
        self.predict = self._slider(60)
        self.predict.setToolTip("Przewidywalność perkusji (narastanie buildów, fille, crash, stopa/hat przed dropem).\n"
                                "100% = dawne, regularne reguły · ok. 60% = regularnie, ale każdy build/fill inny · 0% = najmniej przewidywalnie\n"
                                "(nadal w sensownych ramach: monotoniczne narastanie, siatka 1/16–1/32 lub triole, jeden wspólny plan werbla, tomów, hatu i crasha).")
        self.seed = W.QSpinBox(); self.seed.setRange(0, 999999); self.rndseed = W.QCheckBox("losuj seed"); self.rndseed.setChecked(True)
        self.name = W.QLineEdit(); self.name.setPlaceholderText("(opcjonalnie) nazwa utworu")
        stw = W.QWidget()
        sw = W.QVBoxLayout(stw); sw.setContentsMargins(0, 0, 0, 0)
        sw.addWidget(self.style); sw.addWidget(self.scene_apply); sw.addWidget(self.b_rnd_style); sw.addWidget(self.style_lbl); sw.addWidget(self.b_style_creator)
        seed_w = W.QWidget(); seed_l = W.QHBoxLayout(seed_w); seed_l.setContentsMargins(0, 0, 0, 0)
        seed_l.addWidget(self.seed); seed_l.addWidget(self.rndseed)
        # niuanse + spektakularność (poniżej swing)
        self.niu_on = W.QCheckBox("Niuanse artykulacji")
        self.niu_on.setToolTip(
            "Po generacji wzorów: reguły na partiach nut —\n"
            "przesunięcia skali (początek/środek/koniec), arp trigger,\n"
            "duo interwałowe, monotone seq, zaniki/wzmocnienia velocity,\n"
            "ghost notes, stutter… Siła −1…+1 (ujemna = uproszczenie)."
        )
        self.niu_str = W.QSlider(Qt.Orientation.Horizontal)
        self.niu_str.setRange(-100, 100); self.niu_str.setValue(0)
        self.niu_str_lbl = W.QLabel("0.00")
        self.niu_str.valueChanged.connect(lambda v: self.niu_str_lbl.setText(f"{v/100:+.2f}"))
        niu_w = W.QWidget(); niu_l = W.QHBoxLayout(niu_w); niu_l.setContentsMargins(0, 0, 0, 0)
        niu_l.addWidget(self.niu_on); niu_l.addWidget(self.niu_str, 1); niu_l.addWidget(self.niu_str_lbl)
        self.dance_on = W.QCheckBox("Rytmy taneczne melodii")
        self.dance_on.setToolTip(
            "Opcjonalnie, po niuansach. Najpierw KROKI stylu (siatka z perkusji stylu + nazwane kroki taneczne:\n"
            "offbeat house, 3-3-2/tresillo, clave, dembow, 2-step DnB, half-time, shuffle, bossa, funk 16, trance gate),\n"
            "potem EKSPRESJA pod vibe (klimat, mood, energia): akcenty, staccato↔legato, synkopy, antycypacje, cichy ghost, pauzy.\n"
            "Tylko partie melodyczne grające rytmicznie, w drop/intro/outro/break, i tylko gdy jest perkusja (pady i sustained bez zmian)."
        )
        self.dance_str = W.QSlider(Qt.Orientation.Horizontal)
        self.dance_str.setRange(0, 100); self.dance_str.setValue(60)
        self.dance_lbl = W.QLabel("0.60")
        self.dance_str.valueChanged.connect(lambda v: self.dance_lbl.setText(f"{v/100:.2f}"))
        dance_w = W.QWidget(); dance_l = W.QHBoxLayout(dance_w); dance_l.setContentsMargins(0, 0, 0, 0)
        dance_l.addWidget(self.dance_on); dance_l.addWidget(self.dance_str, 1); dance_l.addWidget(self.dance_lbl)
        self.uniq_on = W.QCheckBox("Niepowtarzalność segmentów")
        self.uniq_on.setToolTip(
            "Po niuansach: receptury per intro/build/break/outro (rolki, cisze, echo…),\n"
            "mikro-wariacje w powtarzających się taktach, korekta podobieństwa\n"
            "między segmentami tego samego typu (build2 ≠ build1)."
        )
        self.uniq_str = W.QSlider(Qt.Orientation.Horizontal)
        self.uniq_str.setRange(0, 100); self.uniq_str.setValue(60)
        self.uniq_str_lbl = W.QLabel("0.60")
        self.uniq_str.valueChanged.connect(lambda v: self.uniq_str_lbl.setText(f"{v/100:.2f}"))
        self.uniq_drops = W.QCheckBox("także dropy")
        self.uniq_drops.setToolTip("Lekkie mikro-wariacje także w sekcjach drop (ghost/accent/flam).")
        uniq_w = W.QWidget(); uniq_l = W.QHBoxLayout(uniq_w); uniq_l.setContentsMargins(0, 0, 0, 0)
        uniq_l.addWidget(self.uniq_on); uniq_l.addWidget(self.uniq_str, 1); uniq_l.addWidget(self.uniq_str_lbl); uniq_l.addWidget(self.uniq_drops)
        self.struct_aff = W.QCheckBox("Domknięcie powinowactw struktury")
        self.struct_aff.setToolTip(
            "Po generacji ponawia role → replace → linki → autolevel (2 przebiegi),\n"
            "żeby cała struktura była spójna względem aktualnych parametrów.\n"
            "W Live uwzględnia porę dnia / complexity / mutacje stylu (już dobrane w planie)."
        )
        self.struct_aff.setChecked(False)
        self.aff_passes = W.QSpinBox(); self.aff_passes.setRange(1, 4); self.aff_passes.setValue(2)
        self.aff_passes.setToolTip("Liczba przebiegów domknięcia (2 zwykle wystarcza)")
        aff_w = W.QWidget(); aff_l = W.QHBoxLayout(aff_w); aff_l.setContentsMargins(0, 0, 0, 0)
        aff_l.addWidget(self.struct_aff); aff_l.addWidget(W.QLabel("przebiegi")); aff_l.addWidget(self.aff_passes); aff_l.addStretch(1)
        from . import health_mode as HM
        self.health_on = W.QCheckBox("Health")
        self.health_on.setToolTip(
            "Nadrzędny tryb sesji (offline): odpoczynek umysłu / stres / trening / percepcja.\n"
            "Upraszcza aranżację, łagodny łuk sekcji, stereo hemi-sync, krzywa BPM."
        )
        self.health_mode = W.QComboBox()
        for key in HM.MODES:
            self.health_mode.addItem(HM.MODE_LABELS[key], key)
        self.health_int = W.QSlider(Qt.Orientation.Horizontal)
        self.health_int.setRange(0, 100); self.health_int.setValue(60)
        self.health_int_lbl = W.QLabel("0.60")
        self.health_int.valueChanged.connect(lambda v: self.health_int_lbl.setText(f"{v/100:.2f}"))
        health_w = W.QWidget(); hl = W.QHBoxLayout(health_w); hl.setContentsMargins(0, 0, 0, 0)
        hl.addWidget(self.health_on); hl.addWidget(self.health_mode, 1)
        hl.addWidget(self.health_int, 1); hl.addWidget(self.health_int_lbl)
        from . import arp_engine as ARP
        self.arp_on = W.QCheckBox("Arp")
        self.arp_on.setToolTip("Arpeggiator (1–24 kroków, tryby up/down/chord…, gate).\nGdy wyłączony — silnik może i tak czasem wylosować schemat z wag.")
        self.arp_mode = W.QComboBox()
        for k in ARP.MODES:
            self.arp_mode.addItem(ARP.MODE_LABELS[k], k)
        self.arp_steps = W.QSpinBox(); self.arp_steps.setRange(1, 24); self.arp_steps.setValue(8)
        self.arp_rate = W.QComboBox()
        for r in ARP.RATES:
            self.arp_rate.addItem(f"1/{16//r if 16%r==0 else str(r)+'×16'}", r)
        self.arp_rate.setCurrentIndex(1)
        self.arp_gate = W.QSlider(Qt.Orientation.Horizontal)
        self.arp_gate.setRange(5, 100); self.arp_gate.setValue(85)
        self.arp_gate_lbl = W.QLabel("0.85")
        self.arp_gate.valueChanged.connect(lambda v: self.arp_gate_lbl.setText(f"{v/100:.2f}"))
        self.arp_oct = W.QSpinBox(); self.arp_oct.setRange(0, 3); self.arp_oct.setValue(1)
        arp_w = W.QWidget(); al = W.QHBoxLayout(arp_w); al.setContentsMargins(0, 0, 0, 0)
        al.addWidget(self.arp_on); al.addWidget(self.arp_mode)
        al.addWidget(W.QLabel("steps")); al.addWidget(self.arp_steps)
        al.addWidget(W.QLabel("rate")); al.addWidget(self.arp_rate)
        al.addWidget(W.QLabel("gate")); al.addWidget(self.arp_gate, 1); al.addWidget(self.arp_gate_lbl)
        al.addWidget(W.QLabel("oct")); al.addWidget(self.arp_oct)
        self.spectacle = W.QComboBox()
        from . import niuanse as NIU
        from . import era_profiles as ERA
        for key in ("monotone", "plain", "balanced", "vivid", "anthem"):
            self.spectacle.addItem(NIU.SPECTACLE_LABELS[key], key)
        self.spectacle.setCurrentIndex(2)
        self.spectacle.setToolTip(
            "Spektakularność aranżacji: od monotonicznej (mało warstw)\n"
            "do anthem (wiele instancji lead/bas/pad, bogatsze niuanse)."
        )
        self.era = W.QComboBox()
        for key in ERA.ERA_ORDER:
            self.era.addItem(ERA.ERA_LABELS[key], key)
        self.era.setCurrentIndex(0)
        self.era.setToolTip(
            "Zasób epoki (nie marki syntezatorów):\n"
            "Minimal 70s ≈ mało torów, proste sekwencje (Kraftwerk-ish)\n"
            "… aż do Maximal now = gęsty DAW (wiele warstw, współczesne typy).\n"
            "Auto = mapowanie ze stylu."
        )
        for lbl, wd in [("Styl", stw), ("BPM", self.bpm), ("Tonacja", self.keyc), ("Skala", self.scale), ("Długość (takty)", self.bars),
                        ("Energia", self.energy), ("Gęstość / złożoność", self.density), ("Swing", self.swing),
                        ("Przewidywalność perkusji", self.predict),
                        ("Niuanse", niu_w), ("Rytmy taneczne", dance_w), ("Niepowtarzalność", uniq_w), ("Powinowactwa", aff_w),
                        ("Health mode", health_w), ("Arpeggiator", arp_w),
                        ("Spektakularność", self.spectacle), ("Zasób epoki", self.era),
                        ("Seed", seed_w), ("Nazwa", self.name)]:
            f.addRow(lbl, wd)
        form_host = W.QWidget(); form_host.setLayout(f)
        top = W.QHBoxLayout(); top.addWidget(form_host, 1)
        box_host = W.QWidget(); box = W.QVBoxLayout(box_host)
        box.addWidget(W.QLabel("Instrumenty (wtyczki CLAP; DS Speak opcjonalnie)"))
        avail = set(core.available_types())
        self.itree = W.QTreeWidget(); self.itree.setHeaderHidden(True); self.itree.setMinimumWidth(230); self.itree.setMaximumHeight(330)
        for g, ts in core.GROUPS.items():
            ts = [t for t in ts if t in avail]
            if not ts:
                continue
            gi = W.QTreeWidgetItem(self.itree, [g]); gi.setFlags(gi.flags() | Qt.ItemFlag.ItemIsUserTristate | Qt.ItemFlag.ItemIsUserCheckable)
            for t in ts:
                ci = W.QTreeWidgetItem(gi, [t]); ci.setFlags(ci.flags() | Qt.ItemFlag.ItemIsUserCheckable); ci.setCheckState(0, Qt.CheckState.Unchecked)
                ci.setForeground(0, QtGui.QBrush(tcolor(t)))
                ci.setData(0, Qt.ItemDataRole.UserRole + 1, False)  # True = 🔒 zablokowany typ
        self.itree.expandAll()
        self.itree.itemDoubleClicked.connect(self._toggle_inst_lock)
        box.addWidget(self.itree)
        box.addWidget(W.QLabel("2× klik instrument = 🔒 (smart/Styl nie zmienia zaznaczenia)"))
        ib = W.QHBoxLayout()
        for txt, fn in (("Styl", lambda: self.set_instruments(G.default_instruments(self.cur_style()))),
                        ("Podstawowe 8", lambda: self.set_instruments(core.CORE8)), ("Wszystkie", lambda: self.set_instruments(core.available_types()))):
            b = W.QPushButton(txt); b.clicked.connect(fn); ib.addWidget(b)
        box.addLayout(ib)
        # --- REŻYSER (nadrzędny tryb) ---
        dg = W.QGroupBox("Reżyser (nadrzędny tryb generacji)"); dl = W.QVBoxLayout(dg)
        self.dir_on = W.QCheckBox("Włącz reżysera")
        self.dir_on.setToolTip("Gdy włączony: mood→agresja/optymizm, scenariusz, dobór instrumentów,\nokna parametrów, zamiany ról, autolevel — nadrzędnie nad resztą.")
        dl.addWidget(self.dir_on)
        row_m = W.QHBoxLayout()
        row_m.addWidget(W.QLabel("Nastrój (mood):"))
        self.dir_mood = W.QSlider(Qt.Orientation.Horizontal); self.dir_mood.setRange(-100, 100); self.dir_mood.setValue(0)
        self.dir_mood_lbl = W.QLabel("wyważony (0.00)")
        self.dir_mood.valueChanged.connect(self._mood_lbl)
        row_m.addWidget(self.dir_mood, 1); row_m.addWidget(self.dir_mood_lbl)
        dl.addLayout(row_m)
        row_f = W.QHBoxLayout()
        self.dir_scenario = W.QCheckBox("Scenariusze"); self.dir_scenario.setChecked(True)
        self.dir_pick = W.QCheckBox("Dobór instrumentów"); self.dir_pick.setChecked(True)
        self.dir_windows = W.QCheckBox("Okna parametrów"); self.dir_windows.setChecked(True)
        self.dir_roles = W.QCheckBox("Zamiany ról"); self.dir_roles.setChecked(True)
        self.dir_autolevel = W.QCheckBox("Autolevels"); self.dir_autolevel.setChecked(True)
        for chk in (self.dir_scenario, self.dir_pick, self.dir_windows, self.dir_roles, self.dir_autolevel):
            row_f.addWidget(chk)
        dl.addLayout(row_f)
        row_v = W.QHBoxLayout()
        row_v.addWidget(W.QLabel("Variety:"))
        self.dir_variety = W.QSlider(Qt.Orientation.Horizontal); self.dir_variety.setRange(0, 100); self.dir_variety.setValue(60)
        row_v.addWidget(self.dir_variety, 1)
        row_v.addWidget(W.QLabel("Siła scenariusza:"))
        self.dir_scen_str = W.QSlider(Qt.Orientation.Horizontal); self.dir_scen_str.setRange(0, 100); self.dir_scen_str.setValue(50)
        row_v.addWidget(self.dir_scen_str, 1)
        row_v.addWidget(W.QLabel("Role:"))
        self.dir_role_amt = W.QSlider(Qt.Orientation.Horizontal); self.dir_role_amt.setRange(0, 100); self.dir_role_amt.setValue(50)
        row_v.addWidget(self.dir_role_amt, 1)
        dl.addLayout(row_v)
        # --- Autokorekta krytyczna (profile płynności) ---
        from . import critical_correct as CC
        row_cc = W.QHBoxLayout()
        self.cc_on = W.QCheckBox("Autokorekta krytyczna")
        self.cc_on.setToolTip(
            "Po generacji (lub przyciskiem na projekcie): koryguje cały utwór wg profilu płynności.\n"
            "Zmienia instrumenty, zakresy nut, parametry, automacje (Cutoff/Morph/Glide…), formę i poziomy.\n"
            "Cel: płynniejsze brzmienia zamiast samych pozycji nut + jednego oscylatora.\n"
            "Trigger: checkbox + suwak intensywności + profil (preset) — dowolna kombinacja."
        )
        self.cc_profile = W.QComboBox()
        for key in CC.PROFILE_ORDER:
            self.cc_profile.addItem(CC.PROFILE_LABELS.get(key, key), key)
        self.cc_profile.setToolTip("Profil sztywnych zakresów i okien parametrów (ambient/minimal/soft/aggressive lub auto ze stylu).")
        self.cc_int = W.QSlider(Qt.Orientation.Horizontal)
        self.cc_int.setRange(0, 100); self.cc_int.setValue(65)
        self.cc_int_lbl = W.QLabel("0.65")
        self.cc_int.valueChanged.connect(lambda v: self.cc_int_lbl.setText(f"{v/100:.2f}"))
        self.cc_apply_btn = W.QPushButton("Zastosuj na projekcie")
        self.cc_apply_btn.setToolTip("Uruchom autokorektę na aktualnym projekcie (bez pełnej regeneracji).")
        self.cc_apply_btn.clicked.connect(self.apply_critical_correct_now)
        row_cc.addWidget(self.cc_on)
        row_cc.addWidget(W.QLabel("Profil:"))
        row_cc.addWidget(self.cc_profile, 1)
        row_cc.addWidget(W.QLabel("Intensywność:"))
        row_cc.addWidget(self.cc_int, 1)
        row_cc.addWidget(self.cc_int_lbl)
        row_cc.addWidget(self.cc_apply_btn)
        dl.addLayout(row_cc)
        box.addWidget(dg)
        # --- ARANŻER (barwy / extras / kreator / nowe ad hoc / efekty WYSIWYG) ---
        ag = W.QGroupBox("Aranżer (zasoby: barwy · extras · kreator — lub nowe ad hoc — + efekty WYSIWYG)"); al = W.QVBoxLayout(ag)
        self.arr_on = W.QCheckBox("Włącz aranżera")
        self.arr_on.setToolTip("Przy aranżacji sam nakłada barwy z banku, dokłada extras FX (riser w buildzie, uderzenie na dropie,\n"
                               "tekstury w break/intro/outro), korzysta z kreatora, a gdy trzeba — tworzy nowe ad hoc.\n"
                               "Efekty ustala figurami w edytorze WYSIWYG (widać je i edytuje w zakładce „Edytor WYSIWYG”).")
        al.addWidget(self.arr_on)
        row_a = W.QHBoxLayout()
        self.arr_amount = W.QSlider(Qt.Orientation.Horizontal); self.arr_amount.setRange(0, 100); self.arr_amount.setValue(50)
        self.arr_adhoc = W.QSlider(Qt.Orientation.Horizontal); self.arr_adhoc.setRange(0, 100); self.arr_adhoc.setValue(40)
        self.arr_wys_str = W.QSlider(Qt.Orientation.Horizontal); self.arr_wys_str.setRange(0, 100); self.arr_wys_str.setValue(60)
        for lbl, sl in (("Ilość:", self.arr_amount), ("Nowe ad hoc:", self.arr_adhoc), ("Siła WYSIWYG:", self.arr_wys_str)):
            row_a.addWidget(W.QLabel(lbl)); row_a.addWidget(sl, 1)
        al.addLayout(row_a)
        row_b = W.QHBoxLayout()
        self.arr_wys = W.QCheckBox("Efekty WYSIWYG"); self.arr_wys.setChecked(True)
        self.arr_layers = W.QCheckBox("Warstwy stereo"); self.arr_layers.setChecked(True)
        self.arr_creator = W.QCheckBox("Kreator"); self.arr_creator.setChecked(True)
        self.arr_persist = W.QCheckBox("Zapisuj ad hoc do banku")
        self.arr_persist.setToolTip("Nowe barwy/extras trafiają do ~/DubstepStudio/adhoc_bank.json i są widoczne w kartach Barwy/Extras po restarcie.")
        for cb in (self.arr_wys, self.arr_layers, self.arr_creator, self.arr_persist):
            row_b.addWidget(cb)
        al.addLayout(row_b)
        box.addWidget(ag)
        # legacy (gdy reżyser wyłączony)
        self.smart_inst = W.QCheckBox("Inteligentny dobór + okna parametrów")
        self.smart_inst.setChecked(True)
        self.smart_inst.setToolTip(
            "Wagowy dobór instrumentów (pasma + agresja + komplementarność).\n"
            "Parametry w wąskich oknach wokół charakteru stylu — nie pełne min…max."
        )
        self.auto_lvl = W.QCheckBox("Autolevels (legacy)")
        self.role_swap = W.QCheckBox("Zamiana ról (legacy)")
        self.scenarios = W.QCheckBox("Scenariusze (legacy)")
        self.character = W.QComboBox()
        self.character.addItems(["very_optimistic", "optimistic", "balanced", "restrained", "dark"])
        self.character.setCurrentText("balanced")
        leg = W.QHBoxLayout()
        for leg_w in (self.smart_inst, self.auto_lvl, self.role_swap, self.scenarios):
            leg.addWidget(leg_w)
        leg.addWidget(W.QLabel("char:")); leg.addWidget(self.character)
        box.addLayout(leg)
        # --- DS Speak: aktywne tylko gdy zaznaczono instrument "speak" (domyślnie wyłączony)
        self.sp_box = W.QGroupBox("Mowa (DS Speak) — tekst"); sl = W.QVBoxLayout(self.sp_box)
        self.sp_auto = W.QRadioButton("Auto — generator układa tekst"); self.sp_man = W.QRadioButton("Ręczny — własny tekst (ENG)")
        self.sp_auto.setChecked(True)
        self.sp_theme = W.QComboBox(); self.sp_theme.addItems(["wg stylu"] + list(G.SPEAK_THEMES))
        self.sp_text = W.QPlainTextEdit(); self.sp_text.setMaximumHeight(64)
        self.sp_text.setPlaceholderText("np. Drop the bass! Wobble. Hands up?  — każda nuta = kolejne słowo; ! akcent, ? pytanie, WIELKIE = okrzyk")
        for x in (self.sp_auto, self.sp_theme, self.sp_man, self.sp_text):
            sl.addWidget(x)
        box.addWidget(self.sp_box)
        self.itree.itemChanged.connect(lambda *_: self._sync_speak())
        self._sync_speak()
        top.addWidget(box_host); v.addLayout(top)
        r = W.QHBoxLayout()
        self.b_gen = W.QPushButton("Generuj"); self.b_gen.clicked.connect(self.generate)
        self.b_play = W.QPushButton("▶ Podgląd"); self.b_play.clicked.connect(self.preview)
        self.b_stop = W.QPushButton("■ Stop"); self.b_stop.clicked.connect(self.player.stop)
        self.b_save = W.QPushButton("Zapisz do biblioteki (MIDI+MP3+projekt)"); self.b_save.clicked.connect(self.save_lib)
        self.stems_chk = W.QCheckBox("+ stemy WAV")
        for b in (self.b_gen, self.b_play, self.b_stop, self.b_save, self.stems_chk):
            r.addWidget(b)
        v.addLayout(r)
        self.pb = W.QProgressBar(); self.pb.setRange(0, 100); self.status = W.QLabel("Gotowe.")
        v.addWidget(self.pb); v.addWidget(self.status)
        self.ov = Overview(); v.addWidget(self.ov, 1)
        return w

    @staticmethod
    def _slider(val):
        s = W.QSlider(Qt.Orientation.Horizontal); s.setRange(0, 100); s.setValue(val); return s

    # --- styl: lista albo hybryda z pola szachowego
    def open_style_creator(self):
        dlg = StyleCreatorDialog(self)
        dlg.exec()

    def _mood_lbl(self, v=None):
        m = (self.dir_mood.value() if v is None else v) / 100.0
        from . import director as DIR
        self.dir_mood_lbl.setText(f"{DIR.mood_name(m)} ({m:+.2f})")

    def arp_cfg(self):
        if not getattr(self, "arp_on", None) or not self.arp_on.isChecked():
            # enabled=False → silnik może auto-wylosować schemat + structural inject
            return {"enabled": False, "structural_inject": True}
        return {
            "enabled": True,
            "mode": self.arp_mode.currentData() or "up",
            "steps": self.arp_steps.value(),
            "rate": self.arp_rate.currentData() or 2,
            "gate": self.arp_gate.value() / 100.0,
            "octaves": self.arp_oct.value(),
            "prob": 1.0,
            "structural_inject": True,
        }

    def health_cfg(self):
        if not getattr(self, "health_on", None) or not self.health_on.isChecked():
            return {"on": False}
        return {
            "on": True,
            "mode": self.health_mode.currentData() or "mind_rest",
            "intensity": self.health_int.value() / 100.0,
        }

    def arranger_cfg(self):
        if not getattr(self, "arr_on", None) or not self.arr_on.isChecked():
            return None
        return dict(on=True, amount=self.arr_amount.value() / 100.0, adhoc_amount=self.arr_adhoc.value() / 100.0,
                    wysiwyg=self.arr_wys.isChecked(), wysiwyg_strength=self.arr_wys_str.value() / 100.0,
                    layers=self.arr_layers.isChecked(), use_creator=self.arr_creator.isChecked(),
                    persist=self.arr_persist.isChecked())

    def director_cfg(self):
        from . import director as DIR
        d = DIR.normalize(None)
        d["on"] = self.dir_on.isChecked()
        d["mood"] = self.dir_mood.value() / 100.0
        d["scenario"] = self.dir_scenario.isChecked()
        d["pick_instruments"] = self.dir_pick.isChecked()
        d["windows"] = self.dir_windows.isChecked()
        d["roles"] = self.dir_roles.isChecked()
        d["autolevel"] = self.dir_autolevel.isChecked()
        d["variety"] = self.dir_variety.value() / 100.0
        d["scenario_strength"] = self.dir_scen_str.value() / 100.0
        d["role_amount"] = self.dir_role_amt.value() / 100.0
        locks = self.locked_instruments()
        d["skip"] = [typ for typ, on in locks.items() if not on]
        # autokorekta krytyczna
        if hasattr(self, "cc_on"):
            d["critical_correct"] = dict(
                on=self.cc_on.isChecked(),
                intensity=self.cc_int.value() / 100.0,
                profile=self.cc_profile.currentData() or "auto",
                change_instruments=True,
                change_form=True,
                change_ranges=True,
                change_params=True,
                change_automation=True,
                change_levels=True,
                passes=2,
            )
        return d


    def apply_critical_correct_now(self):
        """Autokorekta krytyczna na aktualnym projekcie (preset/profil + intensywność)."""
        if not getattr(self, "proj", None):
            self.status.setText("Brak projektu — najpierw wygeneruj utwór.")
            return
        from . import critical_correct as CC
        import random
        dirc = self.director_cfg()
        cc = dict(dirc.get("critical_correct") or {})
        cc["on"] = True  # przycisk zawsze uruchamia
        if hasattr(self, "cc_int"):
            cc["intensity"] = self.cc_int.value() / 100.0
        if hasattr(self, "cc_profile"):
            cc["profile"] = self.cc_profile.currentData() or "auto"
        seed = int(self.proj.get("seed") or 0)
        CC.apply_critical_correct(self.proj, cc, rng=random.Random(seed + 707))
        rep = self.proj.get("critical_correct_report") or {}
        st = rep.get("stats") or {}
        self.set_project(self.proj)
        self.status.setText(
            f"Autokorekta: profil={rep.get('resolved_profile')}  "
            f"params={st.get('params', 0)} notes={st.get('notes', 0)} auto={st.get('auto', 0)} "
            f"replace={st.get('replaced', 0)} form={st.get('form', 0)}"
        )

    def cur_style(self):
        return self.style_override or self.style.currentText()

    def _show_style(self):
        o = self.style_override
        self.style_lbl.setText(f"<b>Hybryda:</b> <span style='color:{ST.color_of(o)}'>■</span> {o}" if o else "")
        self.style_lbl.setTextFormat(Qt.TextFormat.RichText)

    def _combo_style(self, st):
        self.style_override = None; self._show_style(); self.on_style(st)

    def use_style(self, name):
        """Ustaw styl Generatora: czysty (z listy) albo hybrydę „A 60% + B 40%”."""
        if dict.__contains__(G.STYLES, name):
            if self.style.currentText() == name:
                self._combo_style(name)
            else:
                self.style.setCurrentText(name)
        else:
            self.style_override = name; self._show_style(); self.on_style(name)

    # --- presety (globalne, domyślnie puste)
    def refresh_presets(self, select=None):
        names = PR.names(); self.preset_cb.clear()
        self.preset_cb.addItems(names if names else ["(brak presetów — „Zapisz jako…”)"]); self.preset_cb.setEnabled(bool(names))
        if select in names:
            self.preset_cb.setCurrentText(select)

    def collect_preset(self):
        """Pełny snapshot wszystkich przewidywalnych grup ustawień (Generator, Board, Live, Director, Arranger, Flags)."""
        lv = self.live.collect_cfg()
        key = None if self.keyc.currentIndex() == 0 else self.keyc.currentIndex() - 1
        # Live: wszystkie klucze z collect_cfg, które mają sens w presecie (bez board/board_strength — te w board)
        live_keys = ("mode", "locks", "tod_on", "tod_force", "tod_factors", "arr_bars", "lookahead",
                     "max_store", "return_live", "mutate_p", "use_board", "new_hybrids",
                     "complexity", "complexity_intensity", "complexity_follow_tod", "mood_bias", "groove", "tidy")
        live = {k: lv[k] for k in live_keys if k in lv}
        # Director / Arranger
        try:
            director = self.director_cfg()
        except Exception:
            director = None
        try:
            arranger = self.arranger_cfg()
        except Exception:
            arranger = None
        # Flagi Generatora (checkboxy poza czystym generate)
        flags = {}
        for attr, key in (
            ("scene_apply", "scene_apply"),
            ("smart_inst", "smart_instruments"),
            ("auto_lvl", "autolevels"),
            ("role_swap", "role_swap"),
            ("scenarios", "scenarios"),
            ("niu_on", "niuanse"),
            ("dance_on", "dance"),
            ("uniq_on", "uniq"),
            ("uniq_drops", "uniq_drops"),
            ("struct_aff", "structure_affinity"),
            ("arp_on", "arp"),
            ("health_on", "health"),
        ):
            w = getattr(self, attr, None)
            if w is not None and hasattr(w, "isChecked"):
                flags[key] = w.isChecked()
        # suwaki niuansów / uniq / health jeśli istnieją
        for attr, key in (("niu_str", "niuanse_strength"), ("dance_str", "dance_strength"), ("uniq_str", "uniq_strength"),
                          ("health_int", "health_intensity"), ("health_mode", "health_mode")):
            w = getattr(self, attr, None)
            if w is None:
                continue
            if hasattr(w, "value"):
                flags[key] = w.value() / 100.0 if "strength" in key or "intensity" in key else w.value()
            elif hasattr(w, "currentData"):
                flags[key] = w.currentData()
            elif hasattr(w, "currentText"):
                flags[key] = w.currentText()
        return dict(
            generator=dict(
                style=self.cur_style(), style_base=self.style.currentText(),
                bpm=self.bpm.value(), key=key, scale=self.scale.currentText(),
                bars=self.bars.value(), energy=self.energy.value() / 100,
                density=self.density.value() / 100, swing=self.swing.value() / 100,
                predict=self.predict.value() / 100,
                instruments=self.selected_instruments(),
                speak_manual=self.sp_man.isChecked(),
                speak_text=self.sp_text.toPlainText().strip(),
                speak_theme=None if self.sp_theme.currentIndex() == 0 else self.sp_theme.currentText(),
            ),
            board=dict(cells=self.board.cells_list(), strength=self.board.get_strength()),
            live=live,
            director=director,
            arranger=arranger,
            flags=flags,
        )

    def apply_preset(self, d, groups=None):
        """Zastosuj preset. groups=None → wszystkie dostępne grupy; inaczej zbiór nazw:
        {"generator","board","live","director","arranger","flags"}."""
        if groups is None:
            groups = {"generator", "board", "live", "director", "arranger", "flags"}
        g, b, lv = d.get("generator", {}), d.get("board", {}), d.get("live", {})

        if "board" in groups:
            self.board.set_cells(b.get("cells", []))
            self.board.set_strength(b.get("strength", 0.4))

        if "generator" in groups:
            base = g.get("style_base") or g.get("style")
            if base and dict.__contains__(G.STYLES, base):
                self.style.blockSignals(True); self.style.setCurrentText(base); self.style.blockSignals(False)
            st = g.get("style")
            self.style_override = st if st and "%" in st and st in G.STYLES else None
            self._show_style()
            if g.get("bpm"):
                self.bpm.setValue(int(g["bpm"]))
            self.keyc.setCurrentIndex(0 if g.get("key") is None else int(g["key"]) + 1)
            if g.get("scale") in core.SCALES:
                self.scale.setCurrentText(g["scale"])
            if g.get("bars"):
                self.bars.setValue(int(g["bars"]))
            for wd, k in ((self.energy, "energy"), (self.density, "density"), (self.swing, "swing"), (self.predict, "predict")):
                if k in g:
                    wd.setValue(int(round(float(g[k]) * 100)))
            if g.get("instruments"):
                self.set_instruments(g["instruments"])
            (self.sp_man if g.get("speak_manual") else self.sp_auto).setChecked(True)
            self.sp_text.setPlainText(g.get("speak_text") or "")
            self.sp_theme.setCurrentIndex(max(0, self.sp_theme.findText(g.get("speak_theme") or "")))

        if "live" in groups:
            self.live.set_cfg_widgets(lv)

        if "director" in groups and d.get("director") and hasattr(self, "dir_on"):
            dc = d["director"]
            self.dir_on.setChecked(bool(dc.get("on")))
            if "mood" in dc and hasattr(self, "dir_mood"):
                self.dir_mood.setValue(int(round(float(dc["mood"]) * 100)))
            for attr, key in (("dir_scenario", "scenario"), ("dir_pick", "pick_instruments"),
                              ("dir_windows", "windows"), ("dir_roles", "roles"),
                              ("dir_autolevel", "autolevel")):
                w = getattr(self, attr, None)
                if w is not None and key in dc:
                    w.setChecked(bool(dc[key]))
            if "variety" in dc and hasattr(self, "dir_variety"):
                self.dir_variety.setValue(int(round(float(dc["variety"]) * 100)))
            if "scenario_strength" in dc and hasattr(self, "dir_scen_str"):
                self.dir_scen_str.setValue(int(round(float(dc["scenario_strength"]) * 100)))
            if "role_amount" in dc and hasattr(self, "dir_role_amt"):
                self.dir_role_amt.setValue(int(round(float(dc["role_amount"]) * 100)))
            cc = dc.get("critical_correct") or {}
            if hasattr(self, "cc_on") and cc:
                self.cc_on.setChecked(bool(cc.get("on")))
                if hasattr(self, "cc_int") and "intensity" in cc:
                    self.cc_int.setValue(int(round(float(cc["intensity"]) * 100)))

        if "arranger" in groups and d.get("arranger") and hasattr(self, "arr_on"):
            ac = d["arranger"] or {}
            self.arr_on.setChecked(bool(ac.get("on")))
            if "amount" in ac and hasattr(self, "arr_amount"):
                self.arr_amount.setValue(int(round(float(ac["amount"]) * 100)))
            if "adhoc_amount" in ac and hasattr(self, "arr_adhoc"):
                self.arr_adhoc.setValue(int(round(float(ac["adhoc_amount"]) * 100)))
            for attr, key in (("arr_wys", "wysiwyg"), ("arr_layers", "layers"),
                              ("arr_creator", "use_creator"), ("arr_persist", "persist")):
                w = getattr(self, attr, None)
                if w is not None and key in ac:
                    w.setChecked(bool(ac[key]))
            if "wysiwyg_strength" in ac and hasattr(self, "arr_wys_str"):
                self.arr_wys_str.setValue(int(round(float(ac["wysiwyg_strength"]) * 100)))

        if "flags" in groups and d.get("flags"):
            fl = d["flags"]
            for attr, key in (
                ("scene_apply", "scene_apply"),
                ("smart_inst", "smart_instruments"),
                ("auto_lvl", "autolevels"),
                ("role_swap", "role_swap"),
                ("scenarios", "scenarios"),
                ("niu_on", "niuanse"),
                ("dance_on", "dance"),
                ("uniq_on", "uniq"),
                ("uniq_drops", "uniq_drops"),
                ("struct_aff", "structure_affinity"),
                ("arp_on", "arp"),
                ("health_on", "health"),
            ):
                w = getattr(self, attr, None)
                if w is not None and key in fl and hasattr(w, "setChecked"):
                    w.setChecked(bool(fl[key]))
            for attr, key, scale in (
                ("niu_str", "niuanse_strength", 100),
                ("dance_str", "dance_strength", 100),
                ("uniq_str", "uniq_strength", 100),
                ("health_int", "health_intensity", 100),
            ):
                w = getattr(self, attr, None)
                if w is not None and key in fl and hasattr(w, "setValue"):
                    w.setValue(int(round(float(fl[key]) * scale)))


    # --- selektywne stosowanie presetu (checkboxy grup) ---
    def _preset_groups_dialog(self, d, title="Zastosuj preset", default_all=True):
        """Dialog z checkboxami: które grupy ustawień z presetu zastosować.
        Zwraca set nazw grup albo None (Anuluj)."""
        available = []
        labels = {
            "generator": "Generator (styl, BPM, skala, energia, gęstość, swing, instrumenty, Speak)",
            "board": "Pole stylów / hybrydy (komórki + siła)",
            "live": "Live / Endless (tryb, blokady, pory dnia, complexity, mutacje…)",
            "director": "Reżyser (mood, scenariusze, role, autolevel, critical correct)",
            "arranger": "Aranżer (amount, WYSIWYG, warstwy, kreator)",
            "flags": "Flagi Generatora (smart, niuanse, uniq, health, arp, scenariusze…)",
        }
        for k in ("generator", "board", "live", "director", "arranger", "flags"):
            if k == "generator" or d.get(k):
                available.append(k)
            elif k == "flags" and d.get("flags"):
                available.append(k)
        if not available:
            available = ["generator"]
        dlg = W.QDialog(self)
        dlg.setWindowTitle(title)
        dlg.setMinimumWidth(480)
        v = W.QVBoxLayout(dlg)
        v.addWidget(W.QLabel("Zaznacz grupy ustawień do zastosowania:"))
        checks = {}
        for k in available:
            cb = W.QCheckBox(labels.get(k, k))
            cb.setChecked(default_all)
            checks[k] = cb
            v.addWidget(cb)
        # szybkie zaznacz/odznacz
        row = W.QHBoxLayout()
        b_all = W.QPushButton("Zaznacz wszystkie")
        b_none = W.QPushButton("Odznacz wszystkie")
        b_all.clicked.connect(lambda: [c.setChecked(True) for c in checks.values()])
        b_none.clicked.connect(lambda: [c.setChecked(False) for c in checks.values()])
        row.addWidget(b_all); row.addWidget(b_none); row.addStretch(1)
        v.addLayout(row)
        buttons = W.QDialogButtonBox(W.QDialogButtonBox.StandardButton.Ok | W.QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        v.addWidget(buttons)
        if dlg.exec() != W.QDialog.DialogCode.Accepted:
            return None
        chosen = {k for k, cb in checks.items() if cb.isChecked()}
        return chosen or None

    def preset_import_midi(self):
        """Import MIDI → analiza → propozycja stylu/instrumentów/gęstości → selective apply."""
        path, _ = W.QFileDialog.getOpenFileName(
            self, "Import MIDI (analiza → preset)",
            str(Path.home()),
            "MIDI (*.mid *.midi);;Wszystkie (*)",
        )
        if not path:
            return
        try:
            from . import midi_import as MI
            result = MI.analyze_midi(path)
        except Exception as ex:
            W.QMessageBox.critical(self, "Import MIDI", f"Nie udało się przeanalizować pliku:\n{ex}")
            return
        an = result.get("analysis", {})
        sug = an.get("suggested_styles") or []
        # dialog: wybór stylu + podgląd analizy
        dlg = W.QDialog(self)
        dlg.setWindowTitle("Import MIDI — propozycja ustawień")
        dlg.setMinimumWidth(520)
        v = W.QVBoxLayout(dlg)
        info = (
            f"Plik: {Path(path).name}\n"
            f"BPM ≈ {an.get('bpm_int', '?')}   |   takty ≈ {an.get('bars', '?')}   |   nuty: {an.get('note_count', '?')}\n"
            f"Gęstość: {an.get('density_mod', '?')} ({an.get('notes_per_bar', '?')} nut/takt)   |   "
            f"Energia: {an.get('energy_mod', '?')}\n"
            f"Skala (score {an.get('scale_score', 0):.0%}): {result['generator'].get('scale')}   |   "
            f"tonacja: {result['generator'].get('key')}\n"
            f"Ścieżki MIDI → typy: " + ", ".join(
                f"{t['name'] or '—'}→{t['type']}" for t in (an.get("tracks") or [])[:8]
            )
        )
        v.addWidget(W.QLabel(info))
        v.addWidget(W.QLabel("Wybierz styl (lub zostaw propozycję / wpisz hybrydę):"))
        style_cb = W.QComboBox()
        style_cb.setEditable(True)
        # propozycje z analizy na górze
        for name, sc in sug:
            style_cb.addItem(f"{name}  (score {sc:.0%})", name)
        # wszystkie style
        style_cb.insertSeparator(style_cb.count())
        for s in ST.ORDER:
            style_cb.addItem(s, s)
        # ustaw propozycję
        if sug:
            style_cb.setCurrentIndex(0)
        v.addWidget(style_cb)
        # checkboxy: co zastosować od razu
        v.addWidget(W.QLabel("Zastosuj od razu:"))
        cb_gen = W.QCheckBox("Generator (BPM, skala, energia, gęstość, instrumenty)")
        cb_gen.setChecked(True)
        cb_live = W.QCheckBox("Live (tryb current, arr_bars wg długości)")
        cb_live.setChecked(True)
        v.addWidget(cb_gen); v.addWidget(cb_live)
        buttons = W.QDialogButtonBox(
            W.QDialogButtonBox.StandardButton.Ok | W.QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        v.addWidget(buttons)
        if dlg.exec() != W.QDialog.DialogCode.Accepted:
            return
        chosen_style = style_cb.currentData() or style_cb.currentText().split("  (")[0].strip()
        data = MI.analysis_to_preset_data(result, style_override=chosen_style or None)
        groups = set()
        if cb_gen.isChecked():
            groups.add("generator")
        if cb_live.isChecked():
            groups.add("live")
        if not groups:
            groups = {"generator"}
        self.apply_preset(data, groups=groups)
        # opcjonalnie zapisz jako preset
        stem = Path(path).stem
        save, ok = W.QInputDialog.getText(
            self, "Zapisać jako preset?",
            "Nazwa presetu (Anuluj = tylko zastosuj, bez zapisu):",
            text=f"MIDI — {stem}",
        )
        if ok and save.strip():
            PR.put(save.strip(), data)
            self.refresh_presets(save.strip())
        self.status.setText(
            f"MIDI zaimportowany: styl={chosen_style}, BPM={data['generator']['bpm']}, "
            f"inst={len(data['generator'].get('instruments') or [])} → {', '.join(sorted(groups))}"
        )

    def preset_load(self):
        n = self.preset_cb.currentText(); d = PR.get(n) if self.preset_cb.isEnabled() else None
        if d is None:
            self.status.setText("Brak wybranego presetu."); return
        groups = self._preset_groups_dialog(d, title=f"Wczytaj preset „{n}”")
        if groups is None:
            return
        self.apply_preset(d, groups=groups)
        self.status.setText(f"Wczytano preset „{n}” → {', '.join(sorted(groups))} (Icecast bez zmian)")

    def preset_save(self):
        cur = self.preset_cb.currentText() if self.preset_cb.isEnabled() else ""
        n, ok = W.QInputDialog.getText(self, "Zapisz preset", "Nazwa presetu (istniejąca zostanie nadpisana):", text=cur)
        n = n.strip()
        if not ok or not n:
            return
        PR.put(n, self.collect_preset()); self.refresh_presets(n); self.status.setText(f"Zapisano preset „{n}” → {PR.path()}")

    def preset_delete(self):
        n = self.preset_cb.currentText()
        if self.preset_cb.isEnabled() and W.QMessageBox.question(self, "Usuń preset", f"Usunąć „{n}”?") == W.QMessageBox.StandardButton.Yes:
            PR.delete(n); self.refresh_presets(); self.status.setText(f"Usunięto „{n}”")

    def preset_export(self):
        n = self.preset_cb.currentText()
        if not self.preset_cb.isEnabled():
            return
        path, _ = W.QFileDialog.getSaveFileName(self, "Eksport presetu", str(Path.home() / f"{n}.json"), "JSON (*.json)")
        if path:
            PR.export_file(n, path); self.status.setText(f"Wyeksportowano „{n}” → {path}")

    def preset_import(self):
        path, _ = W.QFileDialog.getOpenFileName(self, "Import presetów", str(Path.home()), "JSON (*.json)")
        if not path:
            return
        try:
            ns = PR.import_file(path)
        except (OSError, ValueError) as ex:
            W.QMessageBox.critical(self, "Import", str(ex)); return
        self.refresh_presets(ns[0] if ns else None)
        self.status.setText(f"Zaimportowano: {', '.join(ns) or '—'}")
        # od razu zaproponuj zastosowanie pierwszego z checkboxami grup
        if ns:
            d = PR.get(ns[0])
            if d:
                groups = self._preset_groups_dialog(d, title=f"Zastosować zaimportowany „{ns[0]}”?")
                if groups:
                    self.apply_preset(d, groups=groups)
                    self.status.setText(
                        f"Zaimportowano i zastosowano „{ns[0]}” → {', '.join(sorted(groups))}"
                    )

    def on_style(self, st):
        """BPM/swing/instrumenty zawsze; pełna scena gdy Komplet sceny stylu."""
        try:
            cfg = G.STYLES[st]
            self.bpm.setValue(int(cfg.get("bpm", 140)))
            self.swing.setValue(int(float(cfg.get("swing", 0)) * 100))
        except Exception:
            pass
        try:
            self.set_instruments(G.default_instruments(st))
        except Exception:
            pass
        if getattr(self, "scene_apply", None) is None or self.scene_apply.isChecked():
            self.apply_style_scene(ST.scene_for(st))

    def apply_style_scene(self, scene: dict):
        """Nakłada komplet parametrów Generatora ze sceny stylu (bez nadpisywania locków instrumentów)."""
        if not scene:
            return
        if "bpm" in scene and hasattr(self, "bpm"):
            self.bpm.setValue(int(scene["bpm"]))
        if "swing" in scene and hasattr(self, "swing"):
            self.swing.setValue(int(round(float(scene["swing"]) * 100)))
        if "energy" in scene:
            self.energy.setValue(int(round(float(scene["energy"]) * 100)))
        if "density" in scene:
            self.density.setValue(int(round(float(scene["density"]) * 100)))
        if "bars" in scene and hasattr(self, "bars"):
            self.bars.setValue(int(scene["bars"]))
        if scene.get("scale") and hasattr(self, "scale"):
            i = self.scale.findText(str(scene["scale"]))
            if i >= 0:
                self.scale.setCurrentIndex(i)
        if scene.get("character") and hasattr(self, "character"):
            i = self.character.findText(str(scene["character"]))
            if i >= 0:
                self.character.setCurrentIndex(i)
        if scene.get("spectacle") and hasattr(self, "spectacle"):
            i = self.spectacle.findData(scene["spectacle"])
            if i >= 0:
                self.spectacle.setCurrentIndex(i)
        if scene.get("era") and hasattr(self, "era"):
            i = self.era.findData(scene["era"])
            if i >= 0:
                self.era.setCurrentIndex(i)
        # flags
        def _set(cb_name, key):
            cb = getattr(self, cb_name, None)
            if cb is not None and key in scene:
                cb.setChecked(bool(scene[key]))
        _set("niu_on", "niuanse")
        _set("uniq_on", "uniq")
        _set("uniq_drops", "uniq_drops")
        _set("scenarios", "scenarios")
        _set("smart_inst", "smart_instruments")
        _set("auto_lvl", "autolevels")
        _set("role_swap", "role_swap")
        _set("struct_aff", "structure_affinity")
        if hasattr(self, "niu_str") and "niuanse_strength" in scene:
            self.niu_str.setValue(int(round(float(scene["niuanse_strength"]) * 100)))
        if hasattr(self, "uniq_str") and "uniq_strength" in scene:
            self.uniq_str.setValue(int(round(float(scene["uniq_strength"]) * 100)))
        if hasattr(self, "aff_passes") and "affinity_passes" in scene:
            self.aff_passes.setValue(int(scene["affinity_passes"]))
        # director
        if hasattr(self, "dir_on") and "director_on" in scene:
            self.dir_on.setChecked(bool(scene["director_on"]))
        if hasattr(self, "dir_mood") and "director_mood" in scene:
            self.dir_mood.setValue(int(round(float(scene["director_mood"]) * 100)))
        if hasattr(self, "dir_variety") and "director_variety" in scene:
            self.dir_variety.setValue(int(round(float(scene["director_variety"]) * 100)))
        # arp
        if hasattr(self, "arp_on") and "arp_enabled" in scene:
            self.arp_on.setChecked(bool(scene["arp_enabled"]))
        # status
        bits = [f"scena {scene.get('style', '')}",
                f"E{scene.get('energy', 0):.2f}", f"D{scene.get('density', 0):.2f}",
                str(scene.get("spectacle", "")), str(scene.get("era", "")),
                str(scene.get("character", ""))]
        if hasattr(self, "status"):
            self.status.setText(" · ".join(x for x in bits if x))

    def randomize_style_scene(self):
        """Losuje styl z ORDER i stosuje scenę (gdy checkbox)."""
        import random as _r
        name, scene = ST.random_style_and_scene(_r.Random())
        # ustaw combo bez podwójnego on_style jeśli to ten sam
        self.style_override = None
        if self.style.currentText() == name:
            self.on_style(name)
        else:
            # on_style via signal
            if not (getattr(self, "scene_apply", None) and self.scene_apply.isChecked()):
                # tymczasowo wymuść scenę przy losowaniu
                prev = self.scene_apply.isChecked() if getattr(self, "scene_apply", None) else True
                if getattr(self, "scene_apply", None):
                    self.scene_apply.setChecked(True)
                self.style.setCurrentText(name)
                if getattr(self, "scene_apply", None):
                    self.scene_apply.setChecked(prev)
            else:
                self.style.setCurrentText(name)
        self._show_style()

    def refresh_instrument_lists(self):
        """Po dodaniu/rozpoznaniu instrumentu użytkownika: dorzuca nowe typy do drzewa instrumentów i list wyboru (bez restartu)."""
        self.meta = core.meta()
        avail = set(core.available_types())
        have = {}
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            have[g.text(0)] = g
        known = {g.child(k).text(0) for g in have.values() for k in range(g.childCount())}
        for gname, ts in core.GROUPS.items():
            for t in ts:
                if t in avail and t not in known:
                    g = have.get(gname)
                    if g is None:
                        g = W.QTreeWidgetItem(self.itree, [gname]); g.setFlags(g.flags() | Qt.ItemFlag.ItemIsUserTristate | Qt.ItemFlag.ItemIsUserCheckable)
                        have[gname] = g
                    ci = W.QTreeWidgetItem(g, [t]); ci.setFlags(ci.flags() | Qt.ItemFlag.ItemIsUserCheckable); ci.setCheckState(0, Qt.CheckState.Unchecked)
                    ci.setForeground(0, QtGui.QBrush(tcolor(t)))
                    ci.setData(0, Qt.ItemDataRole.UserRole + 1, False)
                    g.setExpanded(True)
        have_add = {self.add_type.itemText(i) for i in range(self.add_type.count())}
        for t in core.available_types():
            if t not in have_add:
                self.add_type.addItem(t)
        try:
            self.style.blockSignals(True)
            cur = self.style.currentText()
            names = ST.ORDER + [s_ for s_ in G.STYLES if s_ not in ST.ORDER]
            if [self.style.itemText(i) for i in range(self.style.count())] != names:
                self.style.clear(); self.style.addItems(names); self.style.setCurrentText(cur)
        finally:
            self.style.blockSignals(False)

    def set_instruments(self, types):
        """Ustawia zaznaczenie typów; pozycje z 🔒 (lock) pozostają bez zmian."""
        want = set(types)
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                c = g.child(k)
                if c.data(0, Qt.ItemDataRole.UserRole + 1):
                    continue
                name = c.text(0).lstrip("🔒 ").strip()
                c.setCheckState(0, Qt.CheckState.Checked if name in want else Qt.CheckState.Unchecked)

    def _toggle_inst_lock(self, item, _col):
        if item is None or item.childCount() > 0:
            return
        locked = not bool(item.data(0, Qt.ItemDataRole.UserRole + 1))
        item.setData(0, Qt.ItemDataRole.UserRole + 1, locked)
        name = item.text(0).lstrip("🔒 ").strip()
        item.setText(0, ("🔒 " + name) if locked else name)
        item.setForeground(0, QtGui.QBrush(tcolor(name)))
        self.status.setText(f"{'Zablokowano' if locked else 'Odblokowano'} instrument: {name}")

    def locked_instruments(self):
        """typ -> True=force include, False=skip przy generacji."""
        out = {}
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                c = g.child(k)
                if c.data(0, Qt.ItemDataRole.UserRole + 1):
                    name = c.text(0).lstrip("🔒 ").strip()
                    out[name] = c.checkState(0) == Qt.CheckState.Checked
        return out

    def _sync_speak(self):
        self.sp_box.setEnabled("speak" in self.selected_instruments())

    def selected_instruments(self):
        out = []
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                c = g.child(k)
                if c.checkState(0) == Qt.CheckState.Checked:
                    out.append(c.text(0).lstrip("🔒 ").strip())
        return out

    def busy(self, msg):
        self.status.setText(msg); self.pb.setValue(0)

    def run_bg(self, fn, done, msg):
        if self.worker and self.worker.isRunning():
            return
        self.busy(msg)
        self.worker = Worker(fn)
        self.worker.prog.connect(lambda x: self.pb.setValue(int(x * 100)))
        self.worker.done.connect(lambda r: (self.pb.setValue(100), done(r)))
        self.worker.fail.connect(lambda e: (self.status.setText("Błąd — szczegóły w oknie"), W.QMessageBox.critical(self, "Błąd", e)))
        self.worker.start()

    def generate(self):
        seed = random.randrange(1000000) if self.rndseed.isChecked() else self.seed.value()
        self.seed.setValue(seed)
        key = None if self.keyc.currentIndex() == 0 else self.keyc.currentIndex() - 1
        dirc = self.director_cfg()
        smart = self.smart_inst.isChecked()
        alvl = self.auto_lvl.isChecked()
        rswap = self.role_swap.isChecked()
        inst = self.selected_instruments()
        locks = self.locked_instruments()  # typ -> True=force, False=skip
        if not dirc["on"] and not smart and not inst:
            W.QMessageBox.information(self, "DS Studio", "Zaznacz instrumenty, włącz dobór wagowy albo reżysera."); return
        p = G.generate(self.cur_style(), bpm=self.bpm.value(), key=key, scale=self.scale.currentText(), bars=self.bars.value(),
                       energy=self.energy.value() / 100, density=self.density.value() / 100, swing=self.swing.value() / 100,
                       predict=self.predict.value() / 100,
                       seed=seed, name=self.name.text() or None, instruments=None if (dirc["on"] or smart) else inst,
                       speak_text=self.sp_text.toPlainText().strip() if self.sp_man.isChecked() else None,
                       speak_theme=None if self.sp_theme.currentIndex() == 0 else self.sp_theme.currentText(),
                       smart_instruments=smart, autolevels=alvl, role_swap=rswap,
                       scenarios=self.scenarios.isChecked(),
                       character=self.character.currentText(),
                       director=dirc, arranger=self.arranger_cfg(),
                       niuanse=self.niu_on.isChecked(),
                       dance=self.dance_on.isChecked(), dance_strength=self.dance_str.value() / 100.0,
                       niuanse_strength=self.niu_str.value() / 100.0,
                       spectacle=self.spectacle.currentData() or "balanced",
                       era=self.era.currentData() or "auto",
                       uniq=self.uniq_on.isChecked(),
                       uniq_strength=self.uniq_str.value() / 100.0,
                       uniq_drops=self.uniq_drops.isChecked(),
                       replace_on=self.repl_on.isChecked() if hasattr(self, "repl_on") else False,
                       replace_rules=self.replace_rules() if hasattr(self, "replace_rules") else None,
                       replace_policy=self.replace_policy() if hasattr(self, "replace_policy") else None,
                       health=self.health_cfg() if hasattr(self, "health_cfg") else None,
                       arp=self.arp_cfg() if hasattr(self, "arp_cfg") else None,
                       structure_affinity=self.struct_aff.isChecked(),
                       affinity_passes=self.aff_passes.value())
        if locks:
            p["tracks"] = [tr for tr in p["tracks"] if locks.get(tr["type"]) is not False]
            have = {tr["type"] for tr in p["tracks"]}
            for typ, force in locks.items():
                if force and typ not in have:
                    G.add_instance(p, typ)
            p["tracks"] = G._order_tracks(p["tracks"])
            p["links"] = G.default_links(p["style"], p["tracks"])
        self.set_project(p)
        extra = []
        if smart:
            types = ", ".join(t["type"] for t in p["tracks"])
            extra.append(f"dobór wagowy (agg={p.get('aggression', 0):.1f}): {types}")
            self.set_instruments([t["type"] for t in p["tracks"]])
        if p.get("role_swaps"):
            nswap = sum(len(x.get("swaps") or []) for x in p["role_swaps"])
            extra.append(f"zamiana ról: {nswap} w {len(p['role_swaps'])} torach")
        if p.get("critical_correct_report"):
            cr = p["critical_correct_report"]
            st = cr.get("stats") or {}
            extra.append(
                f"autokorekta[{cr.get('resolved_profile')}]: "
                f"p={st.get('params', 0)} n={st.get('notes', 0)} a={st.get('auto', 0)} r={st.get('replaced', 0)}"
            )
        if p.get("scenarios") and p.get("scenario_report"):
            sr = p["scenario_report"]
            arc = " → ".join(f"{s['type']}{s['bars']}" for s in p["sections"][:8])
            if "passes" in sr:
                extra.append(f"scenariusz (korekty×{sr.get('passes', 0)}): {arc}")
            else:
                extra.append(f"scenariusz {p.get('character')}: {arc}")
        if p.get("director") and p["director"].get("on"):
            extra.append(f"reżyser mood={p.get('mood', 0):+.2f} A={p.get('A', 0):.2f} o={p.get('o', 0):.2f}")
        if p.get("role_events"):
            extra.append(f"role: {len(p['role_events'])} okien")
        if p.get("niuanse_report"):
            n = sum(len(v) for v in p["niuanse_report"].values())
            extra.append(f"niuanse×{n} na {len(p['niuanse_report'])} torach")
        if p.get("spectacle") is not None:
            extra.append(f"spektakl={p['spectacle']:.2f}")
        if p.get("era"):
            extra.append(f"era={p.get('era_label') or p['era']}")
        if p.get("structure_affinity_report"):
            n = len(p["structure_affinity_report"])
            extra.append(f"powinowactwa×{n}")
        if p.get("arp_inject_report"):
            r = p["arp_inject_report"]
            extra.append(f"arp-inject {r.get('injected_notes', 0)} nut @ {len(r.get('tracks') or [])} torów")
        if p.get("uniq_report"):
            ur = p["uniq_report"]
            ns = len(ur.get("sections") or {})
            extra.append(f"uniq×{ns} seg (s={p.get('uniq_strength', 0):.2f})")
        if p.get("replace_report"):
            extra.append("replace: " + ", ".join(f"{e['from']}→{e['to']}" for e in p["replace_report"][:6]))
        if p.get("health_mode") and p["health_mode"].get("on"):
            hm = p["health_mode"]
            extra.append(f"health={hm.get('mode')}@{hm.get('intensity', 0):.2f}")
        if p.get("arp") and p["arp"].get("enabled"):
            a = p["arp"]
            extra.append(f"arp={a.get('mode')}×{a.get('steps')}r{a.get('rate')}")
        base = f"Wygenerowano: {p['name']} — {core.key_name(p)}, {p['bpm']} BPM, {p['bars']} taktów ({p['bars'] * 240 / p['bpm']:.0f} s), {len(p['tracks'])} ścieżek"
        self.status.setText(base + ((" | " + " | ".join(extra)) if extra else ""))

    def set_project(self, p):
        self.proj = core.ensure_types(p); self.cache = {}; self.undo = {}
        try:
            from . import arranger as ARR, geometry_editor as GE
            ARR.restore(p)           # barwy/extras ad hoc zapisane w projekcie
            if hasattr(self, "geo_view") and p.get("geometry_doc"):
                import copy as _copy
                self._geo_doc = _copy.deepcopy(p["geometry_doc"]); self._geo_doc["bars"] = int(p.get("bars") or 64)
                self.geo_view.set_doc(self._geo_doc)
                if hasattr(self, "_geo_refresh_tracks"):
                    self._geo_refresh_tracks()
        except Exception:
            pass
        self.ne_a.setMaximum(max(1, p["bars"])); self.ne_b.setMaximum(max(1, p["bars"]))
        self.ne_a.setValue(1); self.ne_b.setValue(max(1, p["bars"])); self.ov.sel = None
        self.ov.set_project(p); self.fill_track_list(); self.fill_links()
        self.bpm.setValue(int(p["bpm"])); self.style.blockSignals(True)
        if dict.__contains__(G.STYLES, p["style"]):
            self.style.setCurrentText(p["style"]); self.style_override = None
        else:
            self.style_override = p["style"] if p["style"] in G.STYLES else None
        self.style.blockSignals(False); self._show_style()

    def need_proj(self):
        if not self.proj:
            W.QMessageBox.information(self, "DS Studio", "Najpierw wygeneruj lub wczytaj projekt."); return False
        return True

    def preview(self):
        if not self.need_proj():
            return
        if self.live.eng.running:
            self.live.stop()          # podgląd offline i strumień Live nie grają naraz
        proj = self.proj

        def job(prog):
            stems = core.render_stems(proj, prog, self.cache)
            mix = core.mix_stems(proj, stems)
            path = Path(tempfile.gettempdir()) / "ds_studio_preview.wav"
            core.write_wav(path, mix)
            return path
        self.run_bg(job, self._play_path, "Renderuję 8 ścieżek przez wtyczki CLAP…")

    def _play_path(self, path):
        ok = self.player.play(path)
        self.status.setText("Odtwarzanie…" if ok else "Brak odtwarzacza (pw-play/paplay/aplay/ffplay/mpv) — plik: " + str(path))

    def run_autolevel(self):
        """Pełny autolevel: render stemów (cache) → RMS → gainy."""
        if not self.need_proj():
            return
        proj = self.proj

        def job(prog):
            return core.autolevel(proj, progress=prog, cache=self.cache)

        def done(report):
            self.show_track(self.tlist.currentRow())
            if not report:
                self.status.setText("Autolevels: brak słyszalnych ścieżek."); return
            parts = [f"{n}: {a:.2f}→{b:.2f}" for n, (a, b, _) in list(report.items())[:8]]
            more = f" (+{len(report)-8})" if len(report) > 8 else ""
            self.status.setText("Autolevels: " + ", ".join(parts) + more)

        self.run_bg(job, done, "Autolevels — renderuję stemy i mierzę RMS…")

    def save_lib(self):
        if not self.need_proj():
            return
        proj, ws = self.proj, self.stems_chk.isChecked()
        self.run_bg(lambda prog: core.save_to_library(proj, core.render_stems(proj, prog, self.cache), None, ws),
                    lambda d: (self.status.setText(f"Zapisano: {d}"), self.refresh_library()), "Renderuję i zapisuję do biblioteki…")

    def _tick(self):
        e = self.player.elapsed()
        if self.proj and e is not None and self.player.proc is not None and str(self.player.proc.args[-1]).endswith("preview.wav"):
            self.ov.head = e * self.proj["bpm"] / 60.0
        else:
            self.ov.head = None
        self.ov.update()

    # ------------------------------------------------------------------ Ścieżki
    def _build_tracks(self):
        w = W.QWidget(); h = W.QHBoxLayout(w)
        self.tlist = W.QListWidget(); self.tlist.setFixedWidth(170); self.tlist.currentRowChanged.connect(self.show_track)
        h.addWidget(self.tlist)
        right = W.QVBoxLayout(); h.addLayout(right, 1)
        top = W.QHBoxLayout()
        self.t_mute = W.QCheckBox("Mute"); self.t_solo = W.QCheckBox("Solo")
        self.t_lock_snd = W.QCheckBox("🔒 Sound"); self.t_lock_snd.setToolTip("Nie losuj parametrów brzmienia tej ścieżki")
        self.t_lock_notes = W.QCheckBox("🔒 Nuty"); self.t_lock_notes.setToolTip("Nie przelosowuj wzoru nut / zamiany ról")
        self.t_lock_gain = W.QCheckBox("🔒 Gain"); self.t_lock_gain.setToolTip("Autolevels nie zmienia gainu tej ścieżki")
        self.t_gain = W.QSlider(Qt.Orientation.Horizontal); self.t_gain.setRange(0, 150); self.t_gain.setFixedWidth(160)
        self.t_mute.toggled.connect(lambda x: self._tset("mute", x)); self.t_solo.toggled.connect(lambda x: self._tset("solo", x))
        self.t_lock_snd.toggled.connect(lambda x: self._tset("lock_sound", x))
        self.t_lock_notes.toggled.connect(lambda x: self._tset("lock_notes", x))
        self.t_lock_gain.toggled.connect(lambda x: self._tset("lock_gain", x))
        self.t_gain.valueChanged.connect(lambda x: self._tset("gain", x / 100))
        b1 = W.QPushButton("Losuj brzmienie"); b1.clicked.connect(lambda: self.reroll(True, False))
        b2 = W.QPushButton("Losuj wzór nut"); b2.clicked.connect(lambda: self.reroll(False, True))
        b3 = W.QPushButton("Oba"); b3.clicked.connect(lambda: self.reroll(True, True))
        bal = W.QPushButton("Autolevels"); bal.setToolTip("Pomiar RMS stemów → gainy pod TARGET_REL (używa cache renderu)")
        bal.clicked.connect(self.run_autolevel)
        for x in (self.t_mute, self.t_solo, self.t_lock_snd, self.t_lock_notes, self.t_lock_gain, W.QLabel("Gain"), self.t_gain, bal, b1, b2, b3):
            top.addWidget(x)
        top.addStretch(1); right.addLayout(top)
        inst = W.QHBoxLayout()
        self.add_type = W.QComboBox(); self.add_type.addItems(core.available_types())
        ba = W.QPushButton("＋ Dodaj instancję"); ba.clicked.connect(self.add_inst)
        bd = W.QPushButton("－ Usuń ścieżkę"); bd.clicked.connect(self.del_inst)
        for x in (W.QLabel("Wtyczka:"), self.add_type, ba, bd):
            inst.addWidget(x)
        inst.addStretch(1); right.addLayout(inst)
        # --- routing: pre (nuty z innej ścieżki) i post (audio innej ścieżki jako wejście = instrument jako filtr)
        rg = W.QGroupBox("Routing: pre (nuty) / post (audio → ten instrument jako filtr)"); rl = W.QHBoxLayout(rg)
        self.rt_notes = W.QComboBox(); self.rt_tr = W.QSpinBox(); self.rt_tr.setRange(-36, 36); self.rt_tr.setSuffix(" st")
        self.rt_in = W.QComboBox(); self.rt_mix = W.QSlider(Qt.Orientation.Horizontal); self.rt_mix.setRange(0, 100); self.rt_mix.setFixedWidth(90)
        self.rt_hide = W.QCheckBox("ukryj źródło w miksie"); self.rt_hide.setChecked(True)
        for lbl, wd in (("Nuty z:", self.rt_notes), ("transp.", self.rt_tr), ("Wejście audio z:", self.rt_in), ("mix", self.rt_mix), ("", self.rt_hide)):
            if lbl:
                rl.addWidget(W.QLabel(lbl))
            rl.addWidget(wd)
        rl.addStretch(1); right.addWidget(rg)
        self.rt_notes.currentTextChanged.connect(self._route_changed); self.rt_in.currentTextChanged.connect(self._route_changed)
        self.rt_tr.valueChanged.connect(self._route_changed); self.rt_mix.valueChanged.connect(self._route_changed); self.rt_hide.toggled.connect(self._route_changed)
        # --- grupa nut: okno taktów (też zaznaczane myszą na przeglądzie w zakładce Generator) + operacja
        ng = W.QGroupBox("Edycja grupy nut (okno taktów)"); nl = W.QHBoxLayout(ng)
        self.ne_a = W.QSpinBox(); self.ne_b = W.QSpinBox(); self.ne_a.setMinimum(1); self.ne_b.setMinimum(1); self.ne_a.setMaximum(256); self.ne_b.setMaximum(256)
        self.ne_op = W.QComboBox(); self.ne_op.addItems([o[1] for o in N.OPS])
        self.ne_amt = W.QDoubleSpinBox(); self.ne_amt.setRange(-96, 100); self.ne_amt.setDecimals(2)
        self.ne_scale = W.QComboBox(); self.ne_scale.addItems(list(N.NOTE_SCALES))
        bap = W.QPushButton("Zastosuj"); bun = W.QPushButton("Cofnij"); ball = W.QPushButton("Całość")
        bap.clicked.connect(self.notes_apply); bun.clicked.connect(self.notes_undo); ball.clicked.connect(lambda: (self.ne_a.setValue(1), self.ne_b.setValue(self.ne_b.maximum())))
        self.ne_op.currentIndexChanged.connect(self._op_changed)
        for lbl, wd in (("takty od", self.ne_a), ("do", self.ne_b), ("operacja", self.ne_op), ("parametr", self.ne_amt), ("skala", self.ne_scale)):
            nl.addWidget(W.QLabel(lbl)); nl.addWidget(wd)
        for b_ in (ball, bap, bun):
            nl.addWidget(b_)
        nl.addStretch(1); right.addWidget(ng); self._op_changed(0)
        self.t_scroll = W.QScrollArea(); self.t_scroll.setWidgetResizable(True)
        self.t_params = W.QWidget()
        self.t_params_lay = W.QVBoxLayout(self.t_params)
        self.t_params_lay.setContentsMargins(4, 4, 4, 4)
        self.t_scroll.setWidget(self.t_params)
        right.addWidget(self.t_scroll, 1)
        return w

    def fill_track_list(self):
        cur = max(0, self.tlist.currentRow())
        self.tlist.blockSignals(True)
        self.tlist.clear()
        for tr in (self.proj or {}).get("tracks") or []:
            n = len(tr.get("notes") or [])
            locks = []
            if tr.get("lock_sound"):
                locks.append("S")
            if tr.get("lock_notes"):
                locks.append("N")
            if tr.get("lock_gain"):
                locks.append("G")
            tag = f" 🔒{''.join(locks)}" if locks else ""
            self.tlist.addItem(f"{tr['name']}  ({n}n){tag}")
        self.tlist.blockSignals(False)
        if self.tlist.count() == 0:
            if hasattr(self, "t_params_lay"):
                self._clear_layout(self.t_params_lay)
            return
        cur = min(cur, self.tlist.count() - 1)
        self.tlist.setCurrentRow(cur)
        self.show_track(cur)


    def _ov_sel(self, a, b):
        self.ne_a.setValue(a + 1); self.ne_b.setValue(b)
        self.status.setText(f"Zaznaczono takty {a + 1}–{b} (edycja w zakładce Ścieżki → Edycja grupy nut)")

    def _op_changed(self, i):
        key, _, plab, dflt = N.OPS[max(0, i)]
        self.ne_amt.setEnabled(plab is not None); self.ne_amt.setValue(dflt); self.ne_amt.setPrefix((plab + ": ") if plab else "")
        self.ne_scale.setEnabled(key in ("snap", "scale_up", "scale_down", "random_scale"))

    def notes_apply(self):
        if not self.need_proj() or self.tlist.currentRow() < 0:
            return
        t = self.proj["tracks"][self.tlist.currentRow()]
        a, b = min(self.ne_a.value(), self.ne_b.value()) - 1, max(self.ne_a.value(), self.ne_b.value())
        key = N.OPS[self.ne_op.currentIndex()][0]
        old = copy.deepcopy(t["notes"])
        new = N.apply_op(self.proj, t["notes"], key, a, b, self.ne_amt.value() if self.ne_amt.isEnabled() else None, self.ne_scale.currentText())
        self.undo.setdefault(t["name"], []).append(old)
        t["notes"] = new
        self.ov.set_project(self.proj); self.fill_track_list()
        self.status.setText(f"{t['name']}: {N.OPS[self.ne_op.currentIndex()][1]} — takty {a + 1}–{b} ({len(old)} → {len(new)} nut)")

    def notes_undo(self):
        if not self.proj or self.tlist.currentRow() < 0:
            return
        t = self.proj["tracks"][self.tlist.currentRow()]; st = self.undo.get(t["name"])
        if st:
            t["notes"] = st.pop(); self.ov.set_project(self.proj); self.fill_track_list(); self.status.setText(f"{t['name']}: cofnięto")

    def _route_changed(self, *_):
        if not self.proj or self.tlist.currentRow() < 0 or getattr(self, "_rt_lock", False):
            return
        t = self.proj["tracks"][self.tlist.currentRow()]
        nf, inf = self.rt_notes.currentText(), self.rt_in.currentText()
        t["notes_from"] = None if nf.startswith("—") else nf
        t["input_from"] = None if inf.startswith("—") else inf
        t["notes_transpose"] = self.rt_tr.value(); t["input_mix"] = self.rt_mix.value() / 100.0; t["input_hide_source"] = self.rt_hide.isChecked()
        self.ov.set_project(self.proj)

    def _fill_route(self, t):
        self._rt_lock = True
        others = ["— brak —"] + [x["name"] for x in self.proj["tracks"] if x is not t]
        for cb, key in ((self.rt_notes, "notes_from"), (self.rt_in, "input_from")):
            cb.clear(); cb.addItems(others); cb.setCurrentText(t.get(key) or others[0])
        self.rt_tr.setValue(int(t.get("notes_transpose", 0))); self.rt_mix.setValue(int(t.get("input_mix", 1.0) * 100))
        self.rt_hide.setChecked(t.get("input_hide_source", True))
        self._rt_lock = False

    def _tset(self, key, val):
        if self.proj and self.tlist.currentRow() >= 0:
            self.proj["tracks"][self.tlist.currentRow()][key] = val

    @staticmethod
    def _clear_layout(layout):
        """Usuwa dzieci layoutu bez niszczenia samego layoutu (unika RuntimeError QVBoxLayout deleted)."""
        if layout is None:
            return
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
                continue
            sub = item.layout()
            if sub is not None:
                MainWindow._clear_layout(sub)

    def show_track(self, row):
        if row < 0 or not self.proj:
            return
        if row >= len(self.proj["tracks"]):
            return
        if not hasattr(self, "t_params_lay"):
            return
        t = self.proj["tracks"][row]
        self._fill_route(t)
        for wd, key in ((self.t_mute, "mute"), (self.t_solo, "solo"),
                         (self.t_lock_snd, "lock_sound"), (self.t_lock_notes, "lock_notes"), (self.t_lock_gain, "lock_gain")):
            wd.blockSignals(True); wd.setChecked(bool(t.get(key, False))); wd.blockSignals(False)
        self.t_gain.blockSignals(True); self.t_gain.setValue(int(t["gain"] * 100)); self.t_gain.blockSignals(False)
        self._clear_layout(self.t_params_lay)
        lay = self.t_params_lay
        if t["type"] == "speak":
            gb = W.QGroupBox("Tekst DS Speak — 1 nuta = 1 słowo (! akcent, ? pytanie, WIELKIE = okrzyk)"); gl = W.QVBoxLayout(gb)
            ed = W.QPlainTextEdit(t.get("text", "")); ed.setMaximumHeight(90)
            ml = W.QLabel("tryb: " + t.get("text_mode", "auto"))
            bapply = W.QPushButton("Zastosuj (ręczny)"); bauto = W.QPushButton("Auto-tekst z motywu")

            def apply_text(_=False, tt=t, e=ed, l=ml):
                tt["text"] = e.toPlainText().strip(); tt["text_mode"] = "manual"; l.setText("tryb: manual")

            def auto_text(_=False, tt=t, e=ed, l=ml):
                rng = random.Random(random.randrange(10 ** 6))
                tt["text"] = G.auto_text(tt.get("text_theme"), self.proj["style"], len(tt["notes"]) or 8, rng)
                tt["text_mode"] = "auto"; e.setPlainText(tt["text"]); l.setText("tryb: auto")
            bapply.clicked.connect(apply_text); bauto.clicked.connect(auto_text)
            rr_w = W.QWidget(); rr = W.QHBoxLayout(rr_w); rr.setContentsMargins(0, 0, 0, 0)
            rr.addWidget(bapply); rr.addWidget(bauto); rr.addWidget(ml); rr.addStretch(1)
            gl.addWidget(ed); gl.addWidget(rr_w); lay.addWidget(gb)
        pl = self.meta.plugins[t["plugin"]]; groups = {}
        if "Dynamics" in pl["params"]:
            lay.addWidget(self._dyn_box(t))
        for name, p in pl["params"].items():
            if name in DYN_PARAMS:                    # parametry Dynamics mają osobny panel powyżej
                continue
            g = groups.get(p["module"])
            if g is None:
                gb = W.QGroupBox(p["module"]); g = groups[p["module"]] = W.QFormLayout(gb); lay.addWidget(gb)
            frac = t["params"].get(name, self.meta.def_frac(t["type"], name))
            s = W.QSlider(Qt.Orientation.Horizontal); s.setRange(0, 1000); s.setValue(int(frac * 1000))
            lab = W.QLabel(self.meta.fmt(t["type"], name, frac)); lab.setMinimumWidth(90)
            s.valueChanged.connect(lambda val, n=name, l=lab, tt=t: self._param(tt, n, val / 1000, l))
            lk = W.QCheckBox("🔒"); lk.setToolTip("Zablokuj parametr — losowanie brzmienia go nie zmienia")
            locked = name in (t.get("locked_params") or [])
            lk.blockSignals(True); lk.setChecked(locked); lk.blockSignals(False)
            def _toggle_plock(on, n=name, tt=t):
                lp = list(tt.get("locked_params") or [])
                if on and n not in lp:
                    lp.append(n)
                elif not on and n in lp:
                    lp.remove(n)
                tt["locked_params"] = lp
            lk.toggled.connect(_toggle_plock)
            row_w = W.QWidget(); rl = W.QHBoxLayout(row_w); rl.setContentsMargins(0, 0, 0, 0)
            rl.addWidget(s, 1); rl.addWidget(lab); rl.addWidget(lk)
            g.addRow(name, row_w)
        lay.addStretch(1)

    def _dyn_box(self, t):
        """Panel Dynamics v6: limiter/normalizer/expander 3-pasmowy + krzywe (skos/log/wypukła/wklęsła), Peak/RMS, per-pasmo."""
        pm = self.meta.plugins[t["plugin"]]["params"]; ty = t["type"]
        has_adv = "Dyn Curve" in pm  # po przebudowie CLAP z v6

        modes = pm["Dynamics"]["texts"]
        pres = pm["Dyn Preset"]["texts"]
        gb = W.QGroupBox("Dynamics — limiter / expander 3-pasmowy + krzywe (opcja instrumentu)")
        v = W.QVBoxLayout(gb)

        # --- wiersz główny: tryb / preset / siła ---
        row = W.QHBoxLayout()
        cm, cp = W.QComboBox(), W.QComboBox()
        cm.addItems([DYN_MODE_PL.get(m, m) for m in modes])
        cp.addItems(pres)
        for i, n in enumerate(pres):
            cp.setItemData(i, DYN_PRESET_INFO.get(n, ""), Qt.ItemDataRole.ToolTipRole)
        am = W.QSlider(Qt.Orientation.Horizontal); am.setRange(0, 100); al = W.QLabel("")
        info = W.QLabel(""); info.setWordWrap(True); info.setStyleSheet("color:#9ca3af")

        def eng(name):
            return self.meta.frac2eng(ty, name, t["params"].get(name, self.meta.def_frac(ty, name)))
        def idx(name):
            return int(round(eng(name)))
        def put(name, e):
            t["params"][name] = self.meta.eng2frac(ty, name, e)

        cm.setCurrentIndex(idx("Dynamics"))
        cp.setCurrentIndex(idx("Dyn Preset"))
        am.setValue(int(round(eng("Dyn Amount") * 100)))

        # --- zaawansowane (tylko gdy CLAP ma nowe parametry) ---
        adv_widgets = []
        cc = cd = ck = ce = cer = None
        band_sliders = {}  # name -> (slider, label)

        if has_adv:
            adv = W.QGroupBox("Zaawansowane — krzywe i pasma")
            av = W.QVBoxLayout(adv)

            # krzywa + detekcja + knee + expander
            r2 = W.QHBoxLayout()
            cc = W.QComboBox()
            curves = pm.get("Dyn Curve", {}).get("texts") or list(DYN_CURVE_PL.keys())
            cc.addItems(curves)
            for i, n in enumerate(curves):
                cc.setItemData(i, DYN_CURVE_PL.get(n, ""), Qt.ItemDataRole.ToolTipRole)
            cc.setCurrentIndex(idx("Dyn Curve") if "Dyn Curve" in pm else 1)

            cd = W.QComboBox()
            dets = pm.get("Dyn Detect", {}).get("texts") or ["Peak", "RMS"]
            cd.addItems(dets)
            cd.setCurrentIndex(idx("Dyn Detect") if "Dyn Detect" in pm else 0)

            ck = W.QSlider(Qt.Orientation.Horizontal); ck.setRange(0, 120); ckl = W.QLabel("")
            ck.setValue(int(round(eng("Dyn Knee") * 10)) if "Dyn Knee" in pm else 60)

            ce = W.QCheckBox("Expander")
            ce.setChecked(idx("Expander") > 0 if "Expander" in pm else False)
            cer = W.QSlider(Qt.Orientation.Horizontal); cer.setRange(10, 80); cerl = W.QLabel("")
            cer.setValue(int(round(eng("Expand Ratio") * 10)) if "Expand Ratio" in pm else 20)

            r2.addWidget(W.QLabel("Krzywa:")); r2.addWidget(cc, 1)
            r2.addWidget(W.QLabel("Detekcja:")); r2.addWidget(cd)
            r2.addWidget(W.QLabel("Knee:")); r2.addWidget(ck, 1); r2.addWidget(ckl)
            av.addLayout(r2)

            r3 = W.QHBoxLayout()
            r3.addWidget(ce); r3.addWidget(W.QLabel("Expand Ratio:")); r3.addWidget(cer, 1); r3.addWidget(cerl)
            av.addLayout(r3)

            # tabela pasm: Low / Mid / High × Ratio / Thresh / Trim
            grid = W.QGridLayout()
            grid.addWidget(W.QLabel(""), 0, 0)
            for col, lab in enumerate(("Ratio :1", "Thresh dB", "Trim dB"), 1):
                grid.addWidget(W.QLabel(lab), 0, col)
            bands = [
                ("Low", "Low Ratio", "Low Thresh", "Low Trim", (1, 20), (-24, 0), (-12, 6)),
                ("Mid", "Mid Ratio", "Mid Thresh", "Mid Trim", (1, 20), (-24, 0), (-12, 6)),
                ("High", "High Ratio", "High Thresh", "High Trim", (1, 20), (-24, 0), (-12, 6)),
            ]
            for row_i, (blab, rn, tn, trn, rr, tr, tmr) in enumerate(bands, 1):
                grid.addWidget(W.QLabel(blab), row_i, 0)
                for col, (pname, rng) in enumerate(((rn, rr), (tn, tr), (trn, tmr)), 1):
                    if pname not in pm:
                        continue
                    s = W.QSlider(Qt.Orientation.Horizontal)
                    lo, hi = rng
                    # mapujemy wartość silnika na 0..1000
                    s.setRange(0, 1000)
                    val = eng(pname)
                    frac = (val - lo) / (hi - lo) if hi > lo else 0
                    s.setValue(int(round(max(0, min(1, frac)) * 1000)))
                    lab = W.QLabel("")
                    def _fmt(p=pname, lo=lo, hi=hi, s=s, lab=lab):
                        v = lo + (s.value() / 1000.0) * (hi - lo)
                        if "Ratio" in p:
                            lab.setText(f"{v:.1f}")
                        else:
                            lab.setText(f"{v:.1f}")
                        put(p, v)
                    s.valueChanged.connect(_fmt)
                    _fmt()
                    band_sliders[pname] = (s, lab)
                    cell = W.QHBoxLayout(); cell.addWidget(s, 1); cell.addWidget(lab)
                    w = W.QWidget(); w.setLayout(cell)
                    grid.addWidget(w, row_i, col)
            av.addLayout(grid)
            v.addWidget(adv)
            adv_widgets = [adv, cc, cd, ck, ckl, ce, cer, cerl] + [w for pair in band_sliders.values() for w in pair]

        def refresh():
            on = cm.currentIndex() > 0
            cp.setEnabled(on); am.setEnabled(on); al.setText(f"{am.value()}%")
            info.setText(DYN_PRESET_INFO.get(cp.currentText(), "") if on else "Wyłączone — instrument gra bez dodatkowej obróbki dynamiki.")
            if has_adv:
                for w in (cc, cd, ck, ce, cer):
                    if w is not None:
                        w.setEnabled(on)
                for s, lab in band_sliders.values():
                    s.setEnabled(on)
                if ck is not None:
                    ckl.setText(f"{ck.value() / 10:.1f} dB")
                if cer is not None:
                    cerl.setText(f"{cer.value() / 10:.1f}:1")
                    cer.setEnabled(on and ce.isChecked())

        def on_mode(i):
            put("Dynamics", i); refresh()
        def on_pre(i):
            put("Dyn Preset", i); refresh()
        def on_amt(x):
            put("Dyn Amount", x / 100.0); refresh()
        cm.currentIndexChanged.connect(on_mode)
        cp.currentIndexChanged.connect(on_pre)
        am.valueChanged.connect(on_amt)

        if has_adv:
            def on_curve(i):
                put("Dyn Curve", i); refresh()
            def on_detect(i):
                put("Dyn Detect", i); refresh()
            def on_knee(x):
                put("Dyn Knee", x / 10.0); refresh()
            def on_exp(c):
                put("Expander", 1 if c else 0); refresh()
            def on_expr(x):
                put("Expand Ratio", x / 10.0); refresh()
            cc.currentIndexChanged.connect(on_curve)
            cd.currentIndexChanged.connect(on_detect)
            ck.valueChanged.connect(on_knee)
            ce.toggled.connect(on_exp)
            cer.valueChanged.connect(on_expr)

        row.addWidget(W.QLabel("Tryb:")); row.addWidget(cm)
        row.addWidget(W.QLabel("Preset:")); row.addWidget(cp, 1)
        row.addWidget(W.QLabel("Siła:")); row.addWidget(am, 1); row.addWidget(al)
        v.addLayout(row); v.addWidget(info)

        br = W.QHBoxLayout()
        ball = W.QPushButton("Zastosuj do wszystkich ścieżek")
        boff = W.QPushButton("Wyłącz na wszystkich")
        ball.setToolTip("Kopiuje tryb, preset, siłę i ustawienia zaawansowane na wszystkie ścieżki z Dynamics")
        def to_all(off=False):
            n = 0
            for o in self.proj["tracks"]:
                opm = self.meta.plugins[o["plugin"]]["params"]
                if "Dynamics" not in opm:
                    continue
                oty = o["type"]
                o["params"]["Dynamics"] = self.meta.eng2frac(oty, "Dynamics", 0 if off else cm.currentIndex())
                if not off:
                    o["params"]["Dyn Preset"] = self.meta.eng2frac(oty, "Dyn Preset", cp.currentIndex())
                    o["params"]["Dyn Amount"] = self.meta.eng2frac(oty, "Dyn Amount", am.value() / 100.0)
                    if has_adv and "Dyn Curve" in opm:
                        o["params"]["Dyn Curve"] = self.meta.eng2frac(oty, "Dyn Curve", cc.currentIndex())
                        o["params"]["Dyn Detect"] = self.meta.eng2frac(oty, "Dyn Detect", cd.currentIndex())
                        o["params"]["Dyn Knee"] = self.meta.eng2frac(oty, "Dyn Knee", ck.value() / 10.0)
                        o["params"]["Expander"] = self.meta.eng2frac(oty, "Expander", 1 if ce.isChecked() else 0)
                        o["params"]["Expand Ratio"] = self.meta.eng2frac(oty, "Expand Ratio", cer.value() / 10.0)
                        for pname, (s, _) in band_sliders.items():
                            if pname in opm:
                                # odtwórz wartość z suwaka
                                for blab, rn, tn, trn, rr, tr, tmr in [
                                    ("Low", "Low Ratio", "Low Thresh", "Low Trim", (1, 20), (-24, 0), (-12, 6)),
                                    ("Mid", "Mid Ratio", "Mid Thresh", "Mid Trim", (1, 20), (-24, 0), (-12, 6)),
                                    ("High", "High Ratio", "High Thresh", "High Trim", (1, 20), (-24, 0), (-12, 6)),
                                ]:
                                    if pname == rn:
                                        lo, hi = rr
                                    elif pname == tn:
                                        lo, hi = tr
                                    elif pname == trn:
                                        lo, hi = tmr
                                    else:
                                        continue
                                    val = lo + (s.value() / 1000.0) * (hi - lo)
                                    o["params"][pname] = self.meta.eng2frac(oty, pname, val)
                n += 1
            if off:
                cm.setCurrentIndex(0)
            self.status.setText(f"Dynamics: {'wyłączono' if off else 'zastosowano'} na {n} ścieżkach")
        ball.clicked.connect(lambda: to_all(False))
        boff.clicked.connect(lambda: to_all(True))
        br.addWidget(ball); br.addWidget(boff); br.addStretch(1)
        v.addLayout(br)
        refresh()
        return gb

    def _param(self, t, name, frac, lab):
        t["params"][name] = frac; lab.setText(self.meta.fmt(t["type"], name, frac))

    def add_inst(self):
        if not self.need_proj():
            return
        tr = G.add_instance(self.proj, self.add_type.currentText())
        self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()
        self.tlist.setCurrentRow([t["name"] for t in self.proj["tracks"]].index(tr["name"]))
        self.status.setText(f"Dodano instancję: {tr['name']} ({len(self.proj['tracks'])} ścieżek)")

    def del_inst(self):
        if not self.need_proj() or self.tlist.currentRow() < 0 or len(self.proj["tracks"]) < 2:
            return
        G.remove_track(self.proj, self.proj["tracks"][self.tlist.currentRow()]["name"])
        self.tlist.setCurrentRow(0); self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()

    def reroll(self, sound, notes):
        if not self.need_proj():
            return
        tr = self.proj["tracks"][self.tlist.currentRow()]
        msgs = []
        if notes and tr.get("lock_notes"):
            msgs.append("nuty 🔒")
        if (sound or not notes) and tr.get("lock_sound"):
            msgs.append("sound 🔒")
        if notes:
            G.reroll_track(self.proj, tr["name"], sound=sound)
        else:
            G.randomize_sound(self.proj, tr, random.Random(random.randrange(10 ** 6)))
        self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()
        self.show_track(self.tlist.currentRow())
        self.status.setText(f"{tr['name']}: " + (f"pominięto ({', '.join(msgs)})" if msgs else "przelosowano"))

    # ------------------------------------------------------------------ Linki
    
    # ------------------------------------------------------------------ Instrument replace
    def _build_replace(self):
        from . import instrument_replace as IR
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel(
            "<b>Zamiana instrumentów</b> — reguły + polityka roli (dozwolone / zawsze pomijaj / wymagane).<br>"
            "Wymagane: po generacji muszą być na torach (dodanie lub podmiana w roli). "
            "Pomijaj: te typy nigdy nie są zamieniane."
        ))
        self.repl_on = W.QCheckBox("Stosuj przy generacji (reguły + polityka)")
        self.repl_on.setChecked(False)
        v.addWidget(self.repl_on)

        # --- polityka per rola ---
        pol_box = W.QGroupBox("Polityka roli — wybór z dostępnych brzmień")
        pol_l = W.QVBoxLayout(pol_box)
        self.repl_role = W.QComboBox()
        for k in IR.ROLE_POOLS:
            self.repl_role.addItem(IR.ROLE_LABELS.get(k, k), k)
        self.repl_role.currentIndexChanged.connect(self._repl_policy_show)
        pol_l.addWidget(self.repl_role)
        grids = W.QGridLayout()
        grids.addWidget(W.QLabel("Dozwolone cele (puste = cała rola)"), 0, 0)
        grids.addWidget(W.QLabel("Zawsze pomijaj (nie zamieniaj)"), 0, 1)
        grids.addWidget(W.QLabel("Wymagane (muszą być)"), 0, 2)
        self.repl_allowed = W.QListWidget(); self.repl_allowed.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.repl_skip = W.QListWidget(); self.repl_skip.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.repl_required = W.QListWidget(); self.repl_required.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        for lst in (self.repl_allowed, self.repl_skip, self.repl_required):
            lst.setMaximumHeight(120)
        grids.addWidget(self.repl_allowed, 1, 0)
        grids.addWidget(self.repl_skip, 1, 1)
        grids.addWidget(self.repl_required, 1, 2)
        pol_l.addLayout(grids)
        pb = W.QHBoxLayout()
        b_save = W.QPushButton("Zapisz politykę roli")
        b_save.clicked.connect(self._repl_policy_save)
        b_clear = W.QPushButton("Wyczyść rolę")
        b_clear.clicked.connect(self._repl_policy_clear)
        pb.addWidget(b_save); pb.addWidget(b_clear); pb.addStretch(1)
        pol_l.addLayout(pb)
        v.addWidget(pol_box)
        self._repl_policy = IR.default_policy()
        self._repl_policy_fill_lists()

        # --- tabela reguł ---
        v.addWidget(W.QLabel("Reguły zamian (src → dst, ograniczone przez „Dozwolone”):"))
        self.repl_table = W.QTableWidget(0, 7)
        self.repl_table.setHorizontalHeaderLabels(["On", "Rola", "Z (src)", "Na (dst)", "Prawdop.", "Zachowaj nuty", "Losuj brzmienie"])
        self.repl_table.horizontalHeader().setStretchLastSection(True)
        self.repl_table.setSelectionBehavior(W.QAbstractItemView.SelectionBehavior.SelectRows)
        v.addWidget(self.repl_table, 1)
        row = W.QHBoxLayout()
        for txt, fn in (
            ("＋ Reguła", self._repl_add),
            ("− Usuń", self._repl_del),
            ("Losuj reguły", self._repl_random),
            ("Domyślne reguły", self._repl_defaults),
            ("Zastosuj na projekcie", self._repl_apply_now),
        ):
            b = W.QPushButton(txt); b.clicked.connect(fn); row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        self.repl_log = W.QLabel("")
        self.repl_log.setWordWrap(True)
        v.addWidget(self.repl_log)
        self._repl_load_rules(IR.default_rules())
        return w

    def _repl_avail_for_role(self, role):
        from . import instrument_replace as IR
        try:
            avail = set(core.available_types())
        except Exception:
            avail = set(core.TYPES)
        return [t for t in IR.ROLE_POOLS.get(role, []) if t in avail] or list(IR.ROLE_POOLS.get(role, []))

    def _repl_policy_fill_lists(self):
        role = self.repl_role.currentData() if hasattr(self, "repl_role") else "lead"
        types = self._repl_avail_for_role(role)
        pol = self._repl_policy.get(role, {"allowed": [], "skip": [], "required": []})
        for lst, key in ((self.repl_allowed, "allowed"), (self.repl_skip, "skip"), (self.repl_required, "required")):
            lst.clear()
            selected = set(pol.get(key) or [])
            for t in types:
                item = W.QListWidgetItem(t)
                lst.addItem(item)
                item.setSelected(t in selected)

    def _repl_policy_show(self, *_):
        self._repl_policy_fill_lists()

    def _repl_policy_save(self):
        role = self.repl_role.currentData()
        self._repl_policy[role] = {
            "allowed": [i.text() for i in self.repl_allowed.selectedItems()],
            "skip": [i.text() for i in self.repl_skip.selectedItems()],
            "required": [i.text() for i in self.repl_required.selectedItems()],
        }
        self.repl_log.setText(
            f"Polityka „{role}”: dozwolone={self._repl_policy[role]['allowed'] or '∗'}, "
            f"pomijaj={self._repl_policy[role]['skip'] or '—'}, wymagane={self._repl_policy[role]['required'] or '—'}"
        )

    def _repl_policy_clear(self):
        role = self.repl_role.currentData()
        self._repl_policy[role] = {"allowed": [], "skip": [], "required": []}
        self._repl_policy_fill_lists()
        self.repl_log.setText(f"Wyczyszczono politykę roli „{role}”.")

    def replace_policy(self):
        # auto-save current role selection before read
        if hasattr(self, "repl_role"):
            self._repl_policy_save()
        return getattr(self, "_repl_policy", None)

    def _repl_load_rules(self, rules):
        from . import instrument_replace as IR
        self.repl_table.setRowCount(0)
        for r in rules:
            self._repl_add_row(IR.normalize_rule(r))

    def _repl_add_row(self, r=None):
        from . import instrument_replace as IR
        r = r or IR.normalize_rule({})
        i = self.repl_table.rowCount()
        self.repl_table.insertRow(i)
        chk = W.QTableWidgetItem()
        chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        chk.setCheckState(Qt.CheckState.Checked if r["enabled"] else Qt.CheckState.Unchecked)
        self.repl_table.setItem(i, 0, chk)
        role = W.QComboBox()
        for k in IR.ROLE_POOLS:
            role.addItem(IR.ROLE_LABELS.get(k, k), k)
        ri = role.findData(r["role"])
        role.setCurrentIndex(max(0, ri))
        self.repl_table.setCellWidget(i, 1, role)
        src = W.QComboBox(); dst = W.QComboBox()

        def fill_src_dst():
            ro = role.currentData() or "lead"
            # dst ograniczone polityką allowed jeśli ustawiona
            pol = (getattr(self, "_repl_policy", {}) or {}).get(ro) or {}
            allowed = pol.get("allowed") or []
            base = list(IR.ROLE_POOLS.get(ro, []))
            pool = (["*"] + (allowed if allowed else base))
            skip = set(pol.get("skip") or [])
            for cb, cur in ((src, r.get("src", "*")), (dst, r.get("dst", "*"))):
                cb.blockSignals(True); cb.clear()
                items = [x for x in pool if x == "*" or x not in skip]
                if cb is src:
                    items = ["*"] + [x for x in base if x not in skip]
                cb.addItems(items or ["*"])
                ix = cb.findText(cur if cur in [cb.itemText(j) for j in range(cb.count())] else "*")
                cb.setCurrentIndex(max(0, ix)); cb.blockSignals(False)

        fill_src_dst()
        role.currentIndexChanged.connect(lambda *_: fill_src_dst())
        self.repl_table.setCellWidget(i, 2, src)
        self.repl_table.setCellWidget(i, 3, dst)
        prob = W.QDoubleSpinBox(); prob.setRange(0, 1); prob.setSingleStep(0.05); prob.setValue(float(r.get("prob", 0.5)))
        self.repl_table.setCellWidget(i, 4, prob)
        kn = W.QTableWidgetItem(); kn.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        kn.setCheckState(Qt.CheckState.Checked if r.get("keep_notes", True) else Qt.CheckState.Unchecked)
        self.repl_table.setItem(i, 5, kn)
        rs = W.QTableWidgetItem(); rs.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        rs.setCheckState(Qt.CheckState.Checked if r.get("regen_sound", True) else Qt.CheckState.Unchecked)
        self.repl_table.setItem(i, 6, rs)

    def replace_rules(self):
        rules = []
        for i in range(self.repl_table.rowCount()):
            on = self.repl_table.item(i, 0)
            role = self.repl_table.cellWidget(i, 1)
            src = self.repl_table.cellWidget(i, 2)
            dst = self.repl_table.cellWidget(i, 3)
            prob = self.repl_table.cellWidget(i, 4)
            kn = self.repl_table.item(i, 5)
            rs = self.repl_table.item(i, 6)
            rules.append(dict(
                enabled=on.checkState() == Qt.CheckState.Checked if on else False,
                role=role.currentData() if role else "lead",
                src=src.currentText() if src else "*",
                dst=dst.currentText() if dst else "*",
                prob=prob.value() if prob else 0.5,
                keep_notes=kn.checkState() == Qt.CheckState.Checked if kn else True,
                regen_sound=rs.checkState() == Qt.CheckState.Checked if rs else True,
            ))
        return rules

    def _repl_add(self):
        self._repl_add_row()

    def _repl_del(self):
        rows = sorted({i.row() for i in self.repl_table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.repl_table.removeRow(r)

    def _repl_random(self):
        from . import instrument_replace as IR
        self._repl_load_rules(IR.random_rules(policy=getattr(self, "_repl_policy", None)))
        self.repl_log.setText("Wylosowano reguły (z uwzględnieniem polityki).")

    def _repl_defaults(self):
        from . import instrument_replace as IR
        self._repl_load_rules(IR.default_rules())
        self.repl_log.setText("Reguły domyślne (wyłączone).")

    def _repl_apply_now(self):
        if not self.proj:
            W.QMessageBox.information(self, "Replace", "Brak projektu — najpierw wygeneruj utwór.")
            return
        from . import instrument_replace as IR
        import random
        self._repl_policy_save()
        ev = IR.apply(self.proj, self.replace_rules(), rng=random.Random(), policy=self._repl_policy)
        self.set_project(self.proj)
        if ev:
            self.repl_log.setText("Zmiany: " + ", ".join(
                f"{e.get('from') or '∅'}→{e['to']}" + (f"[{e.get('kind','')}]" if e.get('kind') != 'replace' else "")
                for e in ev))
            self.status.setText("Instrument replace: " + ", ".join(f"{e.get('from')}→{e['to']}" for e in ev[:8]))
        else:
            self.repl_log.setText("Brak zamian (pomijaj / reguły wyłączone / brak celów).")



    def _build_creator(self):
        from . import extras_fx as FX, timbre_bank as TB, scenario_creator as SC
        w = W.QWidget(); v = W.QVBoxLayout(w)
        # nagłówek sesji
        top = W.QHBoxLayout()
        self.sc_style = W.QComboBox()
        styles = list(getattr(ST, "ORDER", None) or list(G.STYLES.keys())[:30])
        self.sc_style.addItems(styles)
        self.sc_bars = W.QSpinBox(); self.sc_bars.setRange(32, 256); self.sc_bars.setValue(64); self.sc_bars.setSingleStep(8)
        top.addWidget(W.QLabel("Styl:")); top.addWidget(self.sc_style, 1)
        top.addWidget(W.QLabel("Takty:")); top.addWidget(self.sc_bars)
        self.sc_step_lbl = W.QLabel("Krok: —")
        top.addWidget(self.sc_step_lbl)
        v.addLayout(top)

        tabs = W.QTabWidget(); v.addWidget(tabs, 1)

        # ========== MANUAL WIZARD ==========
        mw = W.QWidget(); mv = W.QVBoxLayout(mw)
        mv.addWidget(W.QLabel(
            "<b>Tryb ręczny</b> — zaznacz jak w kreatorze stylów, potem „Zastosuj krok” / „Zastosuj wszystko”. "
            "Extras są sortowane wagami charakteru stylu."
        ))

        # 1 sections
        g1 = W.QGroupBox("1. Sekcje"); gl1 = W.QVBoxLayout(g1)
        self.sc_preset = W.QComboBox()
        self.sc_preset.addItem("Szablon stylu", "style_template")
        for k in SC.SECTION_PRESETS:
            self.sc_preset.addItem(k, k)
        gl1.addWidget(self.sc_preset)
        self.sc_sec_list = W.QListWidget(); self.sc_sec_list.setMaximumHeight(90)
        gl1.addWidget(self.sc_sec_list)
        b_sec = W.QPushButton("Odśwież podgląd sekcji"); b_sec.clicked.connect(self._sc_refresh_secs)
        gl1.addWidget(b_sec)
        mv.addWidget(g1)

        # 2 palette multi
        g2 = W.QGroupBox("2. Paleta instrumentów (zaznacz core / extras)"); gl2 = W.QHBoxLayout(g2)
        self.sc_core = W.QListWidget(); self.sc_core.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.sc_ex = W.QListWidget(); self.sc_ex.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        for t_ in core.TYPES:
            if t_ in getattr(core, "OPTIONAL", ()):
                continue
            self.sc_core.addItem(t_); self.sc_ex.addItem(t_)
        gl2.addWidget(W.QLabel("Core:")); gl2.addWidget(self.sc_core, 1)
        gl2.addWidget(W.QLabel("Extras inst.:")); gl2.addWidget(self.sc_ex, 1)
        mv.addWidget(g2)

        # 3 timbres multi + mux
        g3 = W.QGroupBox("3. Barwy pochodne (zaznacz) + mux ustawień"); gl3 = W.QVBoxLayout(g3)
        self.sc_tb = W.QListWidget(); self.sc_tb.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.sc_tb.setMaximumHeight(100)
        for k, spec in TB.TIMBRES.items():
            self.sc_tb.addItem(f"{k} — {spec.get('desc','')} [{spec.get('base')}]")
        gl3.addWidget(self.sc_tb)
        bm = W.QHBoxLayout()
        b_mux = W.QPushButton("Mux barwy + podsłuch próbki…"); b_mux.clicked.connect(self._sc_open_mux)
        bm.addWidget(b_mux); bm.addStretch(1)
        gl3.addLayout(bm)
        mv.addWidget(g3)

        # 4 extras weighted multi
        g4 = W.QGroupBox("4. Extras FX (wagi stylu — zaznacz)"); gl4 = W.QVBoxLayout(g4)
        self.sc_fx_info = W.QLabel("")
        gl4.addWidget(self.sc_fx_info)
        self.sc_fx = W.QListWidget(); self.sc_fx.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.sc_fx.setMaximumHeight(120)
        gl4.addWidget(self.sc_fx)
        b_fxr = W.QPushButton("Odśwież listę wag stylu"); b_fxr.clicked.connect(self._sc_fill_fx)
        gl4.addWidget(b_fxr)
        mv.addWidget(g4)

        # 5 polish
        g5 = W.QGroupBox("5. Polish"); gl5 = W.QHBoxLayout(g5)
        self.sc_uniq = W.QCheckBox("Uniq"); self.sc_uniq.setChecked(True)
        self.sc_niu = W.QCheckBox("Niuanse")
        gl5.addWidget(self.sc_uniq); gl5.addWidget(self.sc_niu); gl5.addStretch(1)
        mv.addWidget(g5)

        br = W.QHBoxLayout()
        for txt, fn in (
            ("Wczytaj propozycje stylu", self._sc_load_style_hints),
            ("Zastosuj wszystko (ręcznie)", self._sc_apply_manual),
            ("Krok auto", self._sc_step_auto),
            ("Auto całość", self._sc_run_auto),
            ("Wczytaj do edytora", self._sc_apply),
        ):
            b = W.QPushButton(txt); b.clicked.connect(fn); br.addWidget(b)
        mv.addLayout(br)
        self.sc_log = W.QPlainTextEdit(); self.sc_log.setReadOnly(True); self.sc_log.setMaximumHeight(100)
        mv.addWidget(self.sc_log)
        tabs.addTab(mw, "Kreator (manual / auto)")

        # ========== library extras / barwy (jak wcześniej, krócej) ==========
        ew = W.QWidget(); ev = W.QVBoxLayout(ew)
        self.fx_group = W.QComboBox(); self.fx_group.addItem("(wszystkie)", "")
        for gname in FX.EXTRAS_GROUPS:
            self.fx_group.addItem(gname, gname)
        self.fx_group.currentIndexChanged.connect(self._fx_fill)
        self.fx_list = W.QListWidget()
        ev.addWidget(self.fx_group); ev.addWidget(self.fx_list, 1)
        self.fx_desc = W.QLabel(""); ev.addWidget(self.fx_desc)
        self.fx_list.currentTextChanged.connect(self._fx_desc)
        fb = W.QHBoxLayout()
        b1 = W.QPushButton("Dodaj do projektu"); b1.clicked.connect(self._fx_add)
        b2 = W.QPushButton("Podsłuch próbki"); b2.clicked.connect(self._fx_preview)
        b3 = W.QPushButton("Losuj wg stylu"); b3.clicked.connect(self._fx_rand_style)
        fb.addWidget(b1); fb.addWidget(b2); fb.addWidget(b3); fb.addStretch(1); ev.addLayout(fb)
        tabs.addTab(ew, "Biblioteka Extras")
        self._fx_fill()

        tw = W.QWidget(); tv = W.QVBoxLayout(tw)
        self.tb_list = W.QListWidget()
        for k, spec in TB.TIMBRES.items():
            self.tb_list.addItem(f"{k}  —  {spec.get('desc','')}  [{spec.get('base')}]")
        tv.addWidget(self.tb_list, 1)
        tb = W.QHBoxLayout()
        for txt, fn in (("Mux + podsłuch…", self._sc_open_mux), ("Nałóż na tor", self._tb_apply_sel),
                        ("Dodaj tor", self._tb_spawn), ("Mutuj", self._tb_mutate)):
            b = W.QPushButton(txt); b.clicked.connect(fn); tb.addWidget(b)
        tv.addLayout(tb)
        tabs.addTab(tw, "Barwy / mux")

        self._sc_session = None
        self.sc_style.currentTextChanged.connect(self._sc_fill_fx)
        self._sc_fill_fx()
        self._sc_refresh_secs()
        return w

    def _sc_refresh_secs(self):
        from . import scenario_creator as SC
        preset = self.sc_preset.currentData() if hasattr(self, "sc_preset") else "classic_drop"
        bars = self.sc_bars.value()
        self.sc_sec_list.clear()
        if preset == "style_template":
            tpl = G.STYLES.get(self.sc_style.currentText(), {}).get("template") or SC.SECTION_PRESETS["classic_drop"]
            total = sum(b for _, b in tpl) or 1
            scale = bars / total
            pos = 0
            for name, b in tpl:
                nb = max(4, int(round(b * scale / 4) * 4))
                self.sc_sec_list.addItem(f"{name} ×{nb}t @ {pos}")
                pos += nb
        else:
            sec, _ = SC.sections_from_preset(preset, bars)
            for s in sec:
                self.sc_sec_list.addItem(f"{s['type']} ×{s['bars']}t @ {s['start']}")

    def _sc_fill_fx(self):
        from . import extras_fx as FX
        style = self.sc_style.currentText() if hasattr(self, "sc_style") else "Brostep"
        ranked = FX.ranked_extras_for_style(style, limit=20)
        if hasattr(self, "sc_fx"):
            self.sc_fx.clear()
            bucket = ranked[0][3] if ranked else "?"
            self.sc_fx_info.setText(f"Charakter stylu → kubełek extras: <b>{bucket}</b> (wyżej = mocniej sugerowane)")
            for name, w, desc, _ in ranked:
                item = W.QListWidgetItem(f"{name}  (w={w:.2f}) — {desc}")
                item.setData(Qt.ItemDataRole.UserRole, name)
                self.sc_fx.addItem(item)
                # auto-select top 2–3
            for i in range(min(3, self.sc_fx.count())):
                self.sc_fx.item(i).setSelected(True)

    def _sc_load_style_hints(self):
        """Wypełnia zaznaczenia propozycjami ze stylu (jak kreator stylów)."""
        style = self.sc_style.currentText()
        cfg = G.STYLES.get(style) or {}
        core_i = set(cfg.get("core") or [])
        ex_i = set(cfg.get("extras") or [])
        for lst, pool in ((self.sc_core, core_i), (self.sc_ex, ex_i)):
            for i in range(lst.count()):
                lst.item(i).setSelected(lst.item(i).text() in pool)
        self._sc_fill_fx()
        self._sc_refresh_secs()
        self.sc_log.setPlainText(f"Propozycje stylu „{style}” zaznaczone (core/extras + wagi FX).")

    def _sc_selected_instruments(self):
        core_s = [self.sc_core.item(i).text() for i in range(self.sc_core.count()) if self.sc_core.item(i).isSelected()]
        ex_s = [self.sc_ex.item(i).text() for i in range(self.sc_ex.count()) if self.sc_ex.item(i).isSelected()]
        # unikaj duplikatów, core najpierw
        out, seen = [], set()
        for t in core_s + ex_s:
            if t not in seen:
                seen.add(t); out.append(t)
        return out

    def _sc_selected_timbres(self):
        out = []
        for i in range(self.sc_tb.count()):
            if self.sc_tb.item(i).isSelected():
                out.append(self.sc_tb.item(i).text().split(" —")[0].strip())
        return out

    def _sc_selected_extras(self):
        out = []
        for i in range(self.sc_fx.count()):
            it = self.sc_fx.item(i)
            if it.isSelected():
                out.append(it.data(Qt.ItemDataRole.UserRole) or it.text().split()[0])
        return out

    def _sc_apply_manual(self):
        """Pełny przebieg z ręcznymi zaznaczeniami."""
        from . import scenario_creator as SC
        from . import extras_fx as FX
        import random
        style = self.sc_style.currentText()
        bars = self.sc_bars.value()
        session = SC.new_session(style, bars)
        rng = random.Random(session["seed"])
        # sections
        preset = self.sc_preset.currentData()
        if preset == "style_template":
            ch = SC.auto_choice("sections", session, rng)
        else:
            sec, pos = SC.sections_from_preset(preset, bars)
            session["bars"] = pos
            ch = {"sections": sec, "preset": preset}
        SC.apply_step(session, choice=ch, auto=False, rng=rng)
        # palette
        inst = self._sc_selected_instruments()
        if not inst:
            inst = SC.auto_choice("palette", session, rng)["instruments"]
        SC.apply_step(session, choice={"instruments": inst}, auto=False, rng=rng)
        # timbres
        tbs = self._sc_selected_timbres()
        SC.apply_step(session, choice={"timbres": tbs}, auto=False, rng=rng)
        # extras
        fxs = self._sc_selected_extras()
        if not fxs:
            fxs, _ = FX.weighted_extras_for_style(style, n=2, rng=rng)
        SC.apply_step(session, choice={"extras": fxs}, auto=False, rng=rng)
        # notes
        SC.apply_step(session, choice={"do_notes": True}, auto=False, rng=rng)
        # polish
        SC.apply_step(session, choice={
            "uniq": self.sc_uniq.isChecked(), "uniq_strength": 0.55,
            "niuanse": self.sc_niu.isChecked(), "niuanse_strength": 0.35,
        }, auto=False, rng=rng)
        self._sc_session = session
        self.sc_log.setPlainText("\n".join(session.get("log") or []))
        self.sc_step_lbl.setText("Krok: done (manual)")
        W.QMessageBox.information(self, "Kreator", "Scenariusz ręczny gotowy — „Wczytaj do edytora”.")

    def _sc_new(self):
        from . import scenario_creator as SC
        self._sc_session = SC.new_session(self.sc_style.currentText(), self.sc_bars.value())
        self.sc_log.setPlainText("Nowa sesja auto.")
        self.sc_step_lbl.setText(f"Krok: {SC.STEP_LABELS.get(SC.step_name(self._sc_session), '')}")

    def _sc_step_auto(self):
        from . import scenario_creator as SC
        if not self._sc_session:
            self._sc_new()
        SC.apply_step(self._sc_session, auto=True)
        self.sc_log.setPlainText("\n".join(self._sc_session.get("log") or []))
        sn = SC.step_name(self._sc_session)
        self.sc_step_lbl.setText(f"Krok: {SC.STEP_LABELS.get(sn, sn)}")

    def _sc_run_auto(self):
        from . import scenario_creator as SC
        self._sc_session = SC.run_auto(self.sc_style.currentText(), self.sc_bars.value())
        self.sc_log.setPlainText("\n".join(self._sc_session.get("log") or []))
        self.sc_step_lbl.setText("Krok: done")

    def _sc_apply(self):
        if not self._sc_session or not self._sc_session.get("proj"):
            W.QMessageBox.information(self, "Kreator", "Brak projektu sesji.")
            return
        self.set_project(self._sc_session["proj"])
        self.status.setText("Wczytano projekt z kreatora scenariusza.")

    def _sc_open_mux(self):
        """Dialog muxu parametrów barwy + podsłuch krótkiej próbki."""
        from . import timbre_bank as TB
        tid = None
        if hasattr(self, "tb_list") and self.tb_list.currentItem():
            tid = self.tb_list.currentItem().text().split("  —")[0].strip()
        if not tid and hasattr(self, "sc_tb"):
            for i in range(self.sc_tb.count()):
                if self.sc_tb.item(i).isSelected():
                    tid = self.sc_tb.item(i).text().split(" —")[0].strip(); break
        if not tid:
            tid = next(iter(TB.TIMBRES))
        dlg = TimbreMuxDialog(self, tid, self.player)
        dlg.exec()

    def _fx_fill(self):
        from . import extras_fx as FX
        self.fx_list.clear()
        g = self.fx_group.currentData() if hasattr(self, "fx_group") else ""
        for name in FX.list_extras(g or None):
            spec = FX.get_extra(name) or {}
            self.fx_list.addItem(f"{name}  —  {spec.get('desc','')}")

    def _fx_desc(self, text):
        from . import extras_fx as FX
        name = (text or "").split("  —")[0].strip()
        spec = FX.get_extra(name)
        self.fx_desc.setText((spec.get("desc", "") + f"  [{spec.get('type')}]") if spec else "")

    def _fx_add(self):
        from . import extras_fx as FX
        if not self.proj:
            W.QMessageBox.information(self, "Extras", "Najpierw projekt.")
            return
        item = self.fx_list.currentItem()
        if not item:
            return
        name = item.text().split("  —")[0].strip()
        tr = FX.spawn_extra(self.proj, name, start_bar=0, bars=4)
        if tr:
            self.set_project(self.proj)
            self.status.setText(f"Extra {name} → {tr['name']}")

    def _fx_rand_style(self):
        from . import extras_fx as FX
        import random
        if not self.proj:
            W.QMessageBox.information(self, "Extras", "Najpierw projekt.")
            return
        style = self.proj.get("style") or (self.sc_style.currentText() if hasattr(self, "sc_style") else "Brostep")
        names, bucket = FX.weighted_extras_for_style(style, n=2, rng=random.Random())
        for n in names:
            FX.spawn_extra(self.proj, n, start_bar=0, bars=4)
        self.set_project(self.proj)
        self.status.setText(f"Extras [{bucket}]: {', '.join(names)}")

    def _build_geometry(self):
        from . import geometry_editor as GE
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel(
            "<b>Edytor WYSIWYG</b> — figury (trójkąt, elipsa, kwadrat, prostokąt, trapez, koło) + obrót. "
            "Każda ścieżka: <i>kontur nut</i> i <i>intensywność</i> (bez części wspólnych przy partycji)."
        ))
        tools = W.QHBoxLayout()
        self.geo_kind = W.QComboBox()
        for k in GE.SHAPE_KINDS:
            self.geo_kind.addItem(GE.SHAPE_LABELS[k], k)
        self.geo_channel = W.QComboBox()
        for k in GE.CHANNELS:
            self.geo_channel.addItem(GE.CHANNEL_LABELS[k], k)
        self.geo_rot = W.QSpinBox(); self.geo_rot.setRange(0, 359); self.geo_rot.setSingleStep(90); self.geo_rot.setValue(0)
        self.geo_rot.setToolTip("Kąt obrotu (°). 90 / 180 / 270 albo dowolny.")
        self.geo_track = W.QComboBox(); self.geo_track.addItem("(global)", "")
        self.geo_strength = W.QSlider(Qt.Orientation.Horizontal)
        self.geo_strength.setRange(0, 100); self.geo_strength.setValue(100)
        tools.addWidget(W.QLabel("Figura:")); tools.addWidget(self.geo_kind)
        tools.addWidget(W.QLabel("Kanał:")); tools.addWidget(self.geo_channel)
        tools.addWidget(W.QLabel("Obrót°:")); tools.addWidget(self.geo_rot)
        tools.addWidget(W.QLabel("Tor:")); tools.addWidget(self.geo_track, 1)
        tools.addWidget(W.QLabel("Siła:")); tools.addWidget(self.geo_strength, 1)
        v.addLayout(tools)

        self.geo_view = GeometryCanvas(self)
        self.geo_view.setMinimumHeight(320)
        v.addWidget(self.geo_view, 1)

        row = W.QHBoxLayout()
        for txt, fn in (
            ("＋ Dodaj figurę", self._geo_add),
            ("− Usuń zaznaczoną", self._geo_del),
            ("Auto 2 tory / ścieżka", self._geo_auto),
            ("Wypełnij z generatora", self._geo_fill_gen),
            ("Zastosuj na projekt", self._geo_apply),
            ("Odśwież listę torów", self._geo_refresh_tracks),
        ):
            b = W.QPushButton(txt); b.clicked.connect(fn); row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        self.geo_log = W.QLabel("")
        v.addWidget(self.geo_log)
        self._geo_doc = GE.default_document(64)
        self.geo_view.set_doc(self._geo_doc)
        return w

    def _geo_refresh_tracks(self):
        self.geo_track.clear()
        self.geo_track.addItem("(global)", "")
        if self.proj:
            for tr in self.proj["tracks"]:
                self.geo_track.addItem(tr["name"], tr["name"])
            self._geo_doc["bars"] = int(self.proj.get("bars") or 64)
            self.geo_view.set_doc(self._geo_doc)

    def _geo_add(self):
        from . import geometry_editor as GE
        sh = GE.new_shape(
            kind=self.geo_kind.currentData() or "rect",
            x=0.1 + 0.05 * (len(self._geo_doc["shapes"]) % 5),
            y=0.1 + 0.08 * (len(self._geo_doc["shapes"]) % 4),
            w=0.2, h=0.25,
            rot=float(self.geo_rot.value()),
            channel=self.geo_channel.currentData() or "contour",
            track=self.geo_track.currentData() or None,
        )
        sh["strength"] = self.geo_strength.value() / 100.0
        sh["z"] = len(self._geo_doc["shapes"])
        self._geo_doc["shapes"].append(sh)
        self.geo_view.set_doc(self._geo_doc)
        self.geo_log.setText(f"Dodano {sh['kind']} / {sh['channel']} → {sh.get('track') or 'global'}")

    def _geo_del(self):
        sid = self.geo_view.selected_id()
        if not sid:
            return
        self._geo_doc["shapes"] = [s for s in self._geo_doc["shapes"] if s["id"] != sid]
        self.geo_view.set_doc(self._geo_doc)
        self.geo_log.setText("Usunięto figurę.")

    def _geo_auto(self):
        from . import geometry_editor as GE
        if not self.proj:
            W.QMessageBox.information(self, "WYSIWYG", "Najpierw wygeneruj projekt.")
            return
        self._geo_doc = GE.auto_layout_tracks(self.proj, self._geo_doc)
        self.geo_view.set_doc(self._geo_doc)
        self._geo_refresh_tracks()
        self.geo_log.setText("Auto: kontur + intensywność dla każdej ścieżki (bez nachodzenia).")

    def _geo_fill_gen(self):
        """Oznacz figury fill_mode=generator i zastosuj."""
        for s in self._geo_doc.get("shapes") or []:
            s["fill_mode"] = "generator"
        self._geo_apply()

    def _geo_apply(self):
        from . import geometry_editor as GE
        if not self.proj:
            W.QMessageBox.information(self, "WYSIWYG", "Brak projektu.")
            return
        # sync bars
        self._geo_doc["bars"] = int(self.proj.get("bars") or 64)
        # update strength from UI for selected
        sid = self.geo_view.selected_id()
        for s in self._geo_doc["shapes"]:
            if s["id"] == sid:
                s["strength"] = self.geo_strength.value() / 100.0
                s["rot"] = float(self.geo_rot.value())
                s["kind"] = self.geo_kind.currentData() or s["kind"]
                s["channel"] = self.geo_channel.currentData() or s["channel"]
                s["track"] = self.geo_track.currentData() or None
        rep = GE.apply_to_project(self.proj, self._geo_doc)
        self.set_project(self.proj)
        self.geo_log.setText(f"Zastosowano figur: {rep.get('applied', 0)}; intensywność: {rep.get('intensity', [])[:4]}")
        self.status.setText("Edytor WYSIWYG zastosowany na projekt.")

    def _fx_preview(self):
        """Krótki render jednego extra i odsłuch."""
        from . import extras_fx as FX
        item = self.fx_list.currentItem()
        if not item:
            return
        name = item.text().split("  —")[0].strip()
        self._preview_extra_or_timbre(extra=name)

    def _preview_extra_or_timbre(self, extra=None, timbre=None, params=None, base=None):
        """Mini-projekt 1–2s → render → player."""
        import tempfile, random
        from . import extras_fx as FX, timbre_bank as TB
        try:
            proj = core.new_project(style="Brostep", bpm=120, key=0, scale="minor", bars=2, seed=1)
            proj["sections"] = [{"name": "d1", "type": "drop", "start": 0, "bars": 2}]
            proj["chords"] = [[0, 3], [0, 3]]
            if extra:
                FX.spawn_extra(proj, extra, 0, 2, random.Random(1))
            elif timbre or base:
                if timbre and timbre in TB.TIMBRES:
                    TB.spawn_timbre(proj, timbre, random.Random(1))
                else:
                    tr = core.new_track(base or "pluck", base or "pluck")
                    tr["plugin"] = core.PLUGIN_ID.get(tr["type"], "")
                    if params:
                        tr["params"] = dict(params)
                    tr["notes"] = [[0.0, 0.5, 60, 100], [1.0, 0.5, 64, 90], [2.0, 0.4, 67, 85], [3.0, 0.8, 60, 95]]
                    proj["tracks"].append(tr)
            if not proj["tracks"]:
                W.QMessageBox.warning(self, "Podsłuch", "Brak toru do renderu.")
                return
            # upewnij nuty
            for tr in proj["tracks"]:
                if not tr.get("notes"):
                    tr["notes"] = [[0.0, 0.4, 60, 100], [1.0, 0.4, 67, 90]]
            self.status.setText("Render próbki…")
            W.QApplication.processEvents()
            stems = core.render_stems(proj, None, {})                 # {nazwa_ścieżki: tablica (n,2)} — nie pliki
            mix = core.mix_stems(proj, stems)
            path = Path(tempfile.gettempdir()) / "ds_studio_sample.wav"   # osobny plik: nie nadpisujemy podglądu całości w trakcie odtwarzania
            core.write_wav(path, mix)
            if self.player.play(path):
                self.status.setText(f"Podsłuch: {extra or timbre or base}")
            else:
                self.status.setText("Brak odtwarzacza (pw-play/paplay/aplay/ffplay/mpv) — plik: " + str(path))
        except Exception as e:
            self.status.setText(f"Podsłuch błąd: {e}")

    def _tb_current_id(self):
        item = self.tb_list.currentItem() if hasattr(self, "tb_list") else None
        if not item:
            return None
        return item.text().split("  —")[0].strip()

    def _tb_apply_sel(self):
        from . import timbre_bank as TB
        tid = self._tb_current_id()
        if not tid or not self.proj:
            return
        spec = TB.TIMBRES.get(tid)
        tr = next((t for t in self.proj["tracks"] if spec and t["type"] == spec["base"] and not t.get("lock_sound")), None)
        if not tr:
            tr = next((t for t in self.proj["tracks"] if not t.get("lock_sound")), None)
        if tr and TB.apply_timbre_to_track(tr, tid):
            self.set_project(self.proj)
            self.status.setText(f"Barwa {tid} → {tr['name']}")

    def _tb_spawn(self):
        from . import timbre_bank as TB
        tid = self._tb_current_id()
        if not tid or not self.proj:
            return
        created = TB.spawn_timbre(self.proj, tid)
        self.set_project(self.proj)
        self.status.setText(f"Barwa {tid}: {[t['name'] for t in created]}")

    def _tb_mutate(self):
        from . import timbre_bank as TB
        import random
        if not self.proj:
            return
        a, b = random.choice(TB.MUTATION_PAIRS)
        spec = TB.mutate_specs(a, b, random.Random())
        created = TB.spawn_timbre(self.proj, a)
        for tr in created:
            TB.apply_timbre_to_track(tr, "mut", custom_spec=spec)
            tr["timbre_id"] = spec.get("desc")
        self.set_project(self.proj)
        self.status.setText(f"Mutacja {a}+{b}")


    def _build_video(self):
        from . import video_render as VR
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel(
            "<b>Wideo / RTMP</b> — szablony teledysku i live show z eventów projektu (MIDI/sekcje). "
            "Render FFmpeg; wspólna architektura parametrów (rcore) jak CLAP."
        ))
        form = W.QFormLayout()
        self.vid_tpl = W.QComboBox()
        for t in VR.list_templates():
            self.vid_tpl.addItem(f"{t['title']} — {t.get('desc','')}", t["id"])
        self.vid_w = W.QSpinBox(); self.vid_w.setRange(640, 3840); self.vid_w.setValue(1280)
        self.vid_h = W.QSpinBox(); self.vid_h.setRange(360, 2160); self.vid_h.setValue(720)
        self.vid_fps = W.QSpinBox(); self.vid_fps.setRange(15, 60); self.vid_fps.setValue(30)
        self.vid_vbr = W.QLineEdit("4M"); self.vid_abr = W.QLineEdit("192k")
        form.addRow("Szablon", self.vid_tpl)
        form.addRow("Szerokość", self.vid_w); form.addRow("Wysokość", self.vid_h)
        form.addRow("FPS", self.vid_fps)
        form.addRow("Bitrate wideo", self.vid_vbr); form.addRow("Bitrate audio", self.vid_abr)
        v.addLayout(form)

        rtmp_g = W.QGroupBox("RTMP"); rl = W.QFormLayout(rtmp_g)
        self.rtmp_on = W.QCheckBox("Włącz stream po renderze")
        self.rtmp_url = W.QLineEdit("rtmp://localhost/live/stream")
        self.rtmp_key = W.QLineEdit(); self.rtmp_key.setEchoMode(W.QLineEdit.EchoMode.Password)
        self.rtmp_vbr = W.QLineEdit("2500k")
        self.rtmp_reconnect = W.QCheckBox("Ponawiaj połączenie"); self.rtmp_reconnect.setChecked(True)
        rl.addRow(self.rtmp_on)
        rl.addRow("URL", self.rtmp_url); rl.addRow("Klucz", self.rtmp_key)
        rl.addRow("Bitrate stream", self.rtmp_vbr)
        rl.addRow(self.rtmp_reconnect)
        v.addWidget(rtmp_g)

        row = W.QHBoxLayout()
        b1 = W.QPushButton("Render MP4…"); b1.clicked.connect(self._vid_render)
        b2 = W.QPushButton("Eksport AV (proj+mp4)…"); b2.clicked.connect(self._vid_export_av)
        b3 = W.QPushButton("Stream RTMP"); b3.clicked.connect(self._vid_rtmp)
        self._vid_btns = [b1, b2, b3]
        row.addWidget(b1); row.addWidget(b2); row.addWidget(b3); row.addStretch(1)
        v.addLayout(row)
        self.vid_pb = W.QProgressBar(); self.vid_pb.setRange(0, 100); self.vid_pb.setValue(0)
        self.vid_pb.setTextVisible(True); self.vid_pb.setFormat("%p%")
        v.addWidget(self.vid_pb)
        self.vid_log = W.QLabel("Wymaga ffmpeg w PATH. Render: vid.host (numpy + ffmpeg). RTMP: RtmpStreamer z reconnect, klatki zsynchronizowane z audio.")
        self.vid_log.setWordWrap(True)
        v.addWidget(self.vid_log)
        v.addStretch(1)
        return w

    def _vid_av_settings(self):
        return dict(width=self.vid_w.value(), height=self.vid_h.value(), fps=self.vid_fps.value(),
                    video_bitrate=self.vid_vbr.text().strip() or "4M",
                    audio_bitrate=self.vid_abr.text().strip() or "192k")

    def _vid_set_busy(self, busy, msg=""):
        for b in (getattr(self, "_vid_btns", None) or []):
            b.setEnabled(not busy)
        if msg:
            self.vid_log.setText(msg)
        if not busy:
            self.vid_pb.setValue(100 if msg and not msg.startswith("Błąd") and not msg.startswith("RTMP błąd") else self.vid_pb.value())

    def _vid_run(self, fn, msg, on_done):
        """Render/stream w tle (Worker) — GUI nie blokuje się, pasek postępu się aktualizuje."""
        if self.worker and self.worker.isRunning():
            W.QMessageBox.information(self, "Wideo", "Trwa inne zadanie — poczekaj na zakończenie.")
            return

        def work(prog):
            def p(x):
                # x: 0..1 z host.export_mp4 / stream_project
                try:
                    prog(float(x))
                except Exception:
                    pass
            return fn(p)

        self.vid_pb.setValue(0)
        self._vid_set_busy(True, msg)
        self.busy(msg)
        self.worker = Worker(work)
        self.worker.prog.connect(lambda x: (self.vid_pb.setValue(int(max(0, min(1, x)) * 100)),
                                           self.pb.setValue(int(max(0, min(1, x)) * 100)),
                                           self.vid_log.setText(f"{msg}  {int(max(0, min(1, x)) * 100)}%")))
        self.worker.done.connect(lambda r: (self._vid_set_busy(False), self.pb.setValue(100), on_done(r)))
        self.worker.fail.connect(lambda e: (self._vid_set_busy(False, "Błąd — szczegóły w oknie"),
                                            self.status.setText("Błąd wideo"),
                                            W.QMessageBox.critical(self, "Wideo", e)))
        self.worker.start()

    def _vid_render(self):
        from . import video_render as VR
        if not self.proj:
            W.QMessageBox.information(self, "Wideo", "Najpierw wygeneruj projekt audio.")
            return
        path, _ = W.QFileDialog.getSaveFileName(self, "Zapisz MP4", "video.mp4", "MP4 (*.mp4)")
        if not path:
            return
        tpl = self.vid_tpl.currentData() or "live_show"
        av = self._vid_av_settings()
        proj = self.proj

        def job(prog):
            return VR.render_video(proj, tpl, av, path, None, progress=prog)

        def done(out):
            self.vid_log.setText(f"Zapisano: {out}")
            self.status.setText(f"Wideo: {out}")
            self.vid_pb.setValue(100)

        self._vid_run(job, "Render MP4…", done)

    def _vid_export_av(self):
        from . import video_render as VR
        if not self.proj:
            W.QMessageBox.information(self, "Wideo", "Brak projektu.")
            return
        d = W.QFileDialog.getExistingDirectory(self, "Katalog eksportu AV")
        if not d:
            return
        tpl = self.vid_tpl.currentData() or "live_show"
        av = self._vid_av_settings()
        proj = self.proj

        def job(prog):
            return VR.export_project_av(proj, d, tpl, av, progress=prog)

        def done(meta):
            self.vid_log.setText(f"Eksport AV: {meta}")
            self.status.setText("Eksport AV gotowy")
            self.vid_pb.setValue(100)

        self._vid_run(job, "Eksport AV…", done)

    def _vid_rtmp(self):
        from . import video_render as VR
        if not self.proj:
            W.QMessageBox.information(self, "RTMP", "Brak projektu.")
            return
        rtmp = dict(
            enabled=True, url=self.rtmp_url.text().strip(),
            key=self.rtmp_key.text().strip(),
            video_bitrate=self.rtmp_vbr.text().strip() or "2500k",
            width=self.vid_w.value(), height=self.vid_h.value(), fps=self.vid_fps.value(),
            reconnect=self.rtmp_reconnect.isChecked(),
        )
        tpl = self.vid_tpl.currentData() or "live_show"
        proj = self.proj
        logs = []

        def job(prog):
            def log(m):
                logs.append(str(m))
            return VR.stream_rtmp(proj, tpl, rtmp, None, progress=prog, log=log)

        def done(info):
            tail = (" | ".join(logs[-3:]) + " — ") if logs else ""
            self.vid_log.setText(f"{tail}Stream: {info}")
            self.status.setText(f"RTMP: {info.get('status', info) if isinstance(info, dict) else info}")
            self.vid_pb.setValue(100)

        self._vid_run(job, "RTMP: nadawanie…", done)

    def _build_links(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel("Źródła (akcent kick/snare/hat, energia sekcji, build, faza taktu, wysokość basu) sterują parametrami dowolnej ścieżki.\n"
                             "Np. kick → Level basów = sidechain; build → Cutoff screecha; bass_note → Vowel growla."))
        self.ltab = W.QTableWidget(0, 5); self.ltab.setHorizontalHeaderLabels(["Źródło", "Ścieżka docelowa", "Parametr", "Ilość (−1…1)", "Release (beaty)"])
        self.ltab.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        v.addWidget(self.ltab, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Dodaj link", self.link_add), ("Usuń zaznaczony", self.link_del), ("Przywróć domyślne dla stylu", self.link_reset)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        r.addStretch(1); v.addLayout(r)
        return w

    def _names(self):
        return [t["name"] for t in self.proj["tracks"]] if self.proj else []

    def _params_for(self, track):
        t = core.find_track(self.proj, track) if self.proj else None
        if t is None:
            return []
        return [n for n, p in self.meta.plugins[t["plugin"]]["params"].items() if p["kind"] != "int"]

    def fill_links(self):
        self.ltab.setRowCount(0)
        for L in (self.proj["links"] if self.proj else []):
            self._link_row(L)

    def _link_row(self, L):
        r = self.ltab.rowCount(); self.ltab.insertRow(r)
        src = W.QComboBox(); src.addItems(core.LINK_SOURCES); src.setCurrentText(L["src"])
        dst = W.QComboBox(); dst.addItems(self._names()); dst.setCurrentText(L["dst"])
        par = W.QComboBox(); par.addItems(self._params_for(L["dst"])); par.setCurrentText(L["param"])
        amt = W.QDoubleSpinBox(); amt.setRange(-1, 1); amt.setSingleStep(0.05); amt.setValue(L["amount"])
        rel = W.QDoubleSpinBox(); rel.setRange(0.05, 8); rel.setSingleStep(0.05); rel.setValue(L.get("rel", 0.5))

        def sync(*_):
            L["src"], L["dst"], L["param"], L["amount"], L["rel"] = src.currentText(), dst.currentText(), par.currentText(), amt.value(), rel.value()

        def dst_changed(tn):
            par.blockSignals(True); par.clear(); par.addItems(self._params_for(tn)); par.blockSignals(False); sync()
        dst.currentTextChanged.connect(dst_changed)
        for wd in (src, par):
            wd.currentTextChanged.connect(sync)
        for wd in (amt, rel):
            wd.valueChanged.connect(sync)
        for c, wd in enumerate((src, dst, par, amt, rel)):
            self.ltab.setCellWidget(r, c, wd)

    def link_add(self):
        if self.need_proj():
            names = self._names()
            L = {"src": "kick", "dst": "sub" if "sub" in names else names[0], "param": "Level", "amount": -0.3, "rel": 0.5}
            self.proj["links"].append(L); self._link_row(L)

    def link_del(self):
        r = self.ltab.currentRow()
        if self.proj and r >= 0:
            del self.proj["links"][r]; self.fill_links()

    def link_reset(self):
        if self.need_proj():
            self.proj["links"] = G.default_links(self.proj["style"], self.proj["tracks"]); self.fill_links()

    # ------------------------------------------------------------------ Biblioteka
    def _build_lib(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        self.lib = W.QTableWidget(0, 7)
        self.lib.setHorizontalHeaderLabels(["Nazwa", "Styl", "BPM", "Tonacja", "Takty", "Utworzono", "Rodzice"])
        self.lib.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        self.lib.setSelectionBehavior(W.QAbstractItemView.SelectionBehavior.SelectRows)
        self.lib.setSelectionMode(W.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.lib.setEditTriggers(W.QAbstractItemView.EditTrigger.NoEditTriggers)
        v.addWidget(W.QLabel(f"Biblioteka: {core.lib_dir()}"))
        v.addWidget(self.lib, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Odśwież", self.refresh_library), ("▶ Odtwórz", self.lib_play), ("■ Stop", lambda: self.player.stop()),
                        ("Wczytaj do edytora", self.lib_load), ("Usuń", self.lib_delete), ("Otwórz folder", self.lib_open),
                        ("→ Do auto-remixu", self.lib_to_remix)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)
        return w

    def refresh_library(self):
        self.entries = core.list_library(); self.lib.setRowCount(len(self.entries))
        for i, e in enumerate(self.entries):
            for c, val in enumerate([e["name"], e["style"], e["bpm"], e["key"], e["bars"], e["created"], ", ".join(e["parents"])]):
                self.lib.setItem(i, c, W.QTableWidgetItem(str(val)))

    def _sel(self):
        return [self.entries[i.row()] for i in self.lib.selectionModel().selectedRows()]

    def lib_play(self):
        s = self._sel()
        if s and s[0]["audio"]:
            self.player.play(s[0]["audio"])

    def lib_load(self):
        s = self._sel()
        if s:
            self.set_project(core.load_project(s[0]["path"])); self.tabs.setCurrentIndex(0)
            self.status.setText(f"Wczytano {s[0]['name']}")

    def lib_delete(self):
        s = self._sel()
        if s and W.QMessageBox.question(self, "Usuń", f"Usunąć {len(s)} pozycji z dysku?") == W.QMessageBox.StandardButton.Yes:
            for e in s:
                core.delete_library_entry(e["path"])
            self.refresh_library()

    def lib_open(self):
        s = self._sel()
        subprocess.Popen(["xdg-open", str(s[0]["path"] if s else core.lib_dir())])

    def lib_to_remix(self):
        s = self._sel()
        if len(s) < 1:
            return
        self.remix_entries = [(e["path"], core.load_project(e["path"])) for e in s]
        for p, pr in self.remix_entries:
            pr["id"] = Path(p).name
        self.fill_remix(); self.tabs.setCurrentIndex(4)

    # ------------------------------------------------------------------ Remix
    def _build_remix(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel("Wybierz utwory w Bibliotece → „Do auto-remixu”. W tabeli zaznacz, z którego utworu ma pochodzić każda ścieżka.\n"
                             "Wiersze = wszystkie instrumenty z wybranych utworów (24 typy, także kilka instancji). Struktura, progresja i linki z mastera; nuty/brzmienie ze źródeł."))
        f = W.QHBoxLayout()
        self.r_master = W.QComboBox(); self.r_bpm = W.QSpinBox(); self.r_bpm.setRange(0, 220); self.r_bpm.setSpecialValueText("z mastera")
        self.r_key = W.QComboBox(); self.r_key.addItems(["z mastera"] + core.NOTE_NAMES)
        self.r_harm = W.QCheckBox("Przeharmonizuj ścieżki melodyczne do progresji mastera"); self.r_harm.setChecked(True)
        self.r_name = W.QLineEdit(); self.r_name.setPlaceholderText("nazwa remixu")
        for lbl, wd in (("Master:", self.r_master), ("BPM:", self.r_bpm), ("Tonacja:", self.r_key)):
            f.addWidget(W.QLabel(lbl)); f.addWidget(wd)
        v.addLayout(f); v.addWidget(self.r_harm); v.addWidget(self.r_name)
        self.rtab = W.QTableWidget(0, 0); v.addWidget(self.rtab, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Auto-remix (losowe przypisanie)", self.remix_auto), ("Zbuduj i podglądaj", lambda: self.remix_build(False)),
                        ("Zbuduj i zapisz do biblioteki", lambda: self.remix_build(True))):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)
        self.rgroups = {}; self.rnames = []
        return w

    def fill_remix(self):
        projs = [p for _, p in self.remix_entries]; n = len(projs)
        self.rnames = R.track_names(projs)
        self.r_master.clear(); self.r_master.addItems([p["name"] for p in projs])
        self.rtab.setColumnCount(n + 1); self.rtab.setRowCount(len(self.rnames))
        self.rtab.setHorizontalHeaderLabels(["— wył. —"] + [f"{p['name']}\n{p['style']} {p['bpm']}bpm {core.key_name(p)}" for p in projs])
        self.rtab.setVerticalHeaderLabels(self.rnames)
        self.rtab.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        self.rgroups = {}
        for r, name in enumerate(self.rnames):
            grp = W.QButtonGroup(self); self.rgroups[name] = grp
            off = W.QRadioButton("—"); grp.addButton(off, 0); self.rtab.setCellWidget(r, 0, off)
            first = True
            for c, p in enumerate(projs):
                t = core.find_track(p, name); cnt = len(t["notes"]) if t else 0
                rb = W.QRadioButton(f"{cnt} nut"); grp.addButton(rb, c + 1); rb.setEnabled(cnt > 0)
                if cnt and first:
                    rb.setChecked(True); first = False
                self.rtab.setCellWidget(r, c + 1, rb)
            if first:
                off.setChecked(True)

    def remix_auto(self):
        if not self.remix_entries:
            return
        rng = random.Random(random.randrange(10 ** 6))
        projs = [p for _, p in self.remix_entries]
        master, assign = R.auto_assign(projs, rng)
        ids = [p["id"] for p in projs]
        self.r_master.setCurrentIndex(ids.index(master["id"]))
        for name in self.rnames:
            p = assign.get(name)
            self.rgroups[name].button(0 if p is None else ids.index(p["id"]) + 1).setChecked(True)

    def remix_build(self, save):
        if not self.remix_entries:
            return
        projs = [p for _, p in self.remix_entries]
        master = projs[self.r_master.currentIndex()]
        assign = {n: (None if self.rgroups[n].checkedId() <= 0 else projs[self.rgroups[n].checkedId() - 1]) for n in self.rnames}
        if not any(assign.values()):
            W.QMessageBox.information(self, "DS Studio", "Wybierz źródło dla przynajmniej jednej ścieżki."); return
        key = None if self.r_key.currentIndex() == 0 else self.r_key.currentIndex() - 1
        p = R.remix(assign, master, bpm=self.r_bpm.value() or None, key=key, harmony=self.r_harm.isChecked(),
                    name=self.r_name.text() or None, seed=random.randrange(10 ** 6))
        self.set_project(p)
        self.status.setText(f"Remix: {p['name']} ({core.key_name(p)}, {p['bpm']} BPM, {len(p['tracks'])} ścieżek)")
        if save:
            self.save_lib()
        else:
            self.tabs.setCurrentIndex(0); self.preview()

    def closeEvent(self, e):
        self.live.shutdown(); self.player.stop(); super().closeEvent(e)


def main():
    app = W.QApplication(sys.argv)
    app.setStyle("Fusion")
    pal = QtGui.QPalette()
    for role, col in ((QtGui.QPalette.ColorRole.Window, "#14161b"), (QtGui.QPalette.ColorRole.WindowText, "#e5e7eb"),
                      (QtGui.QPalette.ColorRole.Base, "#0f1115"), (QtGui.QPalette.ColorRole.AlternateBase, "#14161b"),
                      (QtGui.QPalette.ColorRole.Text, "#e5e7eb"), (QtGui.QPalette.ColorRole.Button, "#1f232b"),
                      (QtGui.QPalette.ColorRole.ButtonText, "#e5e7eb"), (QtGui.QPalette.ColorRole.Highlight, "#e5484d"),
                      (QtGui.QPalette.ColorRole.HighlightedText, "#ffffff")):
        pal.setColor(role, QtGui.QColor(col))
    app.setPalette(pal)
    try:
        win = MainWindow()
    except Exception as ex:
        W.QMessageBox.critical(None, "DS Dubstep Studio", str(ex)); return 1
    win.show()
    return app.exec()
