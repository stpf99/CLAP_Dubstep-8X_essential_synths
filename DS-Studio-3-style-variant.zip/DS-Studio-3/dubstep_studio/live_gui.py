"""live_gui.py — zakładka „Live / Endless": sterowanie strumieniem, panel trybu auto, oś czasu aranżacji, zrzut MP3."""
from __future__ import annotations

import copy
import datetime
import os
import random
import subprocess
import sys
from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import config as CF, core, live as L, styles as ST

STYLE_COL = ST.STYLE_COL
SECCOL = {"intro": "#1f2937", "build": "#4a3a14", "drop": "#4a1a20", "break": "#14384a", "outro": "#1f2937"}
LOCK_LABEL = {"style": "Styl", "bpm": "BPM", "key": "Tonacja", "scale": "Skala", "energy": "Energia", "density": "Gęstość",
              "swing": "Swing", "bars": "Długość", "instruments": "Instrumenty"}


class Bridge(QtCore.QObject):
    ev = QtCore.pyqtSignal(str, object)


def fmt_t(s):
    s = int(max(0, s)); return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


class Timeline(W.QWidget):
    """Oś czasu: blok = jedna aranżacja (kolor stylu + paski sekcji intro/build/drop/break/outro). Klik = zaznacz, Ctrl/Shift = wiele,
    dwuklik = odsłuch od punktu startowego. Przerywany blok na końcu = aranżacja właśnie generowana."""
    selChanged = QtCore.pyqtSignal()
    playRequested = QtCore.pyqtSignal(int)
    RULER = 20

    def __init__(self):
        super().__init__()
        self.arrs = []; self.pps = 5.0; self.sel = set(); self.anchor = None
        self.head = None; self.playing = None; self.planning = None
        self.setMinimumHeight(150); self.setSizePolicy(W.QSizePolicy.Policy.Minimum, W.QSizePolicy.Policy.Expanding)

    def total(self):
        return (self.arrs[-1].start_sec + self.arrs[-1].dur) if self.arrs else 0.0

    def relayout(self):
        est = 0.0
        if self.planning:
            k = self.planning["kw"]; est = k["bars"] * 240.0 / k["bpm"]
        self.setMinimumWidth(int((self.total() + est) * self.pps) + 60); self.update()

    def _at(self, x):
        t = x / self.pps
        for a in self.arrs:
            if a.start_sec <= t < a.start_sec + a.dur:
                return a
        return None

    def mousePressEvent(self, e):
        a = self._at(e.position().x())
        mods = e.modifiers()
        if a is None:
            if not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier)):
                self.sel = set()
        elif mods & Qt.KeyboardModifier.ShiftModifier and self.anchor is not None:
            lo, hi = sorted((self.anchor, a.idx)); self.sel = set(range(lo, hi + 1))
        elif mods & Qt.KeyboardModifier.ControlModifier:
            self.sel ^= {a.idx}; self.anchor = a.idx
        else:
            self.sel = {a.idx}; self.anchor = a.idx
        self.update(); self.selChanged.emit()

    def mouseDoubleClickEvent(self, e):
        a = self._at(e.position().x())
        if a is not None:
            self.sel = {a.idx}; self.anchor = a.idx; self.update(); self.selChanged.emit(); self.playRequested.emit(a.idx)

    def paintEvent(self, ev):
        p = QtGui.QPainter(self); p.fillRect(self.rect(), QtGui.QColor("#0f1115"))
        h = self.height(); top = self.RULER; bh = h - top - 6
        f = p.font(); f.setPointSize(8); p.setFont(f)
        step = 30 if self.pps >= 3 else 60 if self.pps >= 1.5 else 300
        tmax = self.width() / self.pps
        p.setPen(QtGui.QColor("#6b7280"))
        for s in range(0, int(tmax) + 1, step):
            x = int(s * self.pps); p.drawLine(x, top - 5, x, top - 1); p.drawText(x + 3, 12, fmt_t(s))
        for a in list(self.arrs):
            x, w = int(a.start_sec * self.pps), max(2, int(a.dur * self.pps))
            r = QtCore.QRect(x, top, w - 1, bh)
            base = QtGui.QColor(ST.color_of(a.style))
            if a.evicted:
                p.fillRect(r, QtGui.QColor("#1b1d22")); p.setPen(QtGui.QColor("#4b5563")); p.drawRect(r)
                p.drawText(r.adjusted(4, 2, -2, -2), Qt.AlignmentFlag.AlignTop, f"#{a.idx + 1} (usunięta)"); continue
            p.fillRect(r, base.darker(300))
            spb = 240.0 / a.proj["bpm"]                              # sekundy na takt
            for s in a.proj["sections"]:                              # pasek sekcji u dołu bloku
                sx = int((a.start_sec + s["start"] * spb) * self.pps); sw = max(1, int(s["bars"] * spb * self.pps))
                p.fillRect(QtCore.QRect(sx, top + bh - 14, sw, 14), QtGui.QColor(SECCOL.get(s["type"], "#1f2937")).lighter(160))
                p.fillRect(QtCore.QRect(sx, top + bh - 14, sw, 3), QtGui.QColor(SECCOL.get(s["type"], "#1f2937")).lighter(260))
            p.fillRect(QtCore.QRect(x, top, w - 1, 4), base)
            p.setPen(QtGui.QColor("#e5e7eb"))
            tx = r.adjusted(5, 7, -3, -16)
            lines = [f"#{a.idx + 1}  {a.style}", f"{a.proj['bpm']} BPM · {core.key_name(a.proj)}", f"{a.proj['bars']} t · {fmt_t(a.dur)} · {a.plan['slot']}"]
            for k, ln in enumerate(lines):
                p.drawText(tx.adjusted(0, k * 13, 0, 0), Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft, ln)
            if a.pinned:
                p.drawText(r.adjusted(0, 6, -4, 0), Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight, "📌")
            sel = a.idx in self.sel; cur = a.idx == self.playing
            p.setPen(QtGui.QPen(QtGui.QColor("#ffffff") if sel else base if cur else QtGui.QColor("#374151"), 2 if (sel or cur) else 1))
            p.setBrush(Qt.BrushStyle.NoBrush); p.drawRect(r)
        if self.planning:
            k = self.planning["kw"]; x = int(self.total() * self.pps); w = max(30, int(k["bars"] * 240.0 / k["bpm"] * self.pps))
            r = QtCore.QRect(x, top, w - 1, bh)
            pen = QtGui.QPen(QtGui.QColor(ST.color_of(k["style"])), 1, Qt.PenStyle.DashLine); p.setPen(pen); p.drawRect(r)
            p.drawText(r.adjusted(5, 5, -3, -3), Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap, f"⏳ generuję…\n{k['style']} {k['bpm']} BPM")
        if self.head is not None:
            x = int(self.head * self.pps); p.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 2)); p.drawLine(x, 0, x, h)


class LiveTab(W.QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.bridge = Bridge(); self.bridge.ev.connect(self._on_event)
        self.eng = L.LiveEngine(lambda kind, **kw: self.bridge.ev.emit(kind, kw))
        self._err_shown = False
        self.conf = CF.load(); self._ice_seen = None; self._ice_stable = 0
        v = W.QVBoxLayout(self)

        # --- sterowanie
        r = W.QHBoxLayout()
        self.b_start = W.QPushButton("▶ Start Live"); self.b_stop = W.QPushButton("■ Stop"); self.b_pause = W.QPushButton("⏸ Pauza")
        self.b_next = W.QPushButton("⏭ Następna teraz"); self.b_live = W.QPushButton("⇥ Wróć na żywo")
        self.b_pause.setCheckable(True)
        for b, fn in ((self.b_start, self.start), (self.b_stop, self.stop), (self.b_pause, self.pause), (self.b_next, self.skip), (self.b_live, self.to_live)):
            b.clicked.connect(fn); r.addWidget(b)
        r.addStretch(1); v.addLayout(r)
        self.status = W.QLabel("Zatrzymany. Strumień generuje aranżacje na bieżąco (bez renderowania całości z góry).")
        v.addWidget(self.status)

        # --- panel trybu auto
        box = W.QGroupBox("Tryb auto — jak powstaje każda następna aranżacja"); g = W.QGridLayout(box)
        self.rb_cur = W.QRadioButton("Styl aktualnie ustawiony (styl i ustawienia z zakładki Generator)")
        self.rb_rnd = W.QRadioButton("Losowanie kompletne (style, ich wariacje i ustawienia — kaskadowo)")
        self.rb_cur.setChecked(True)
        g.addWidget(self.rb_cur, 0, 0, 1, 6); g.addWidget(self.rb_rnd, 1, 0, 1, 6)
        self.lock = {}
        self.lock_row = W.QWidget(); lr = W.QHBoxLayout(self.lock_row)
        lr.addWidget(W.QLabel("Na sztywno z Generatora (nie losuj):"))
        for k in L.LOCK_KEYS:
            c = W.QCheckBox(LOCK_LABEL[k]); self.lock[k] = c; lr.addWidget(c)
        lr.addStretch(1); g.addWidget(self.lock_row, 2, 0, 1, 6)
        self.tod_on = W.QCheckBox("Tempo i energia wg pory dnia (wolniej/ostrożniej w wybranych porach, wpływa też na wagę stylów)"); self.tod_on.setChecked(True)
        g.addWidget(self.tod_on, 3, 0, 1, 6)
        self.tod_force = W.QComboBox(); self.tod_force.addItems(["Zegar systemowy"] + [s[0] for s in L.TOD_SLOTS])
        g.addWidget(W.QLabel("Pora:"), 4, 0); g.addWidget(self.tod_force, 4, 1)
        self.tod_sp = {}
        for i, (n, _, _) in enumerate(L.TOD_SLOTS):
            sp = W.QSpinBox(); sp.setRange(60, 130); sp.setSuffix(" %"); sp.setValue(int(round(L.TOD_DEFAULT[n] * 100))); self.tod_sp[n] = sp
            g.addWidget(W.QLabel(f"BPM {n}:"), 5, i * 2); g.addWidget(sp, 5, i * 2 + 1)
        self.arr_bars = W.QSpinBox(); self.arr_bars.setRange(16, 256); self.arr_bars.setValue(32); self.arr_bars.setSingleStep(8)
        self.lookahead = W.QSpinBox(); self.lookahead.setRange(1, 4); self.lookahead.setValue(1)
        self.max_store = W.QSpinBox(); self.max_store.setRange(2, 1000); self.max_store.setValue(60)
        self.ret_live = W.QCheckBox("Po odsłuchu z osi wróć na żywo"); self.ret_live.setChecked(True)
        g.addWidget(W.QLabel("Takty / aranżację:"), 6, 0); g.addWidget(self.arr_bars, 6, 1)
        g.addWidget(W.QLabel("Wyprzedzenie (aranżacje):"), 6, 2); g.addWidget(self.lookahead, 6, 3)
        g.addWidget(W.QLabel("Magazyn (max aranżacji):"), 6, 4); g.addWidget(self.max_store, 6, 5)
        g.addWidget(self.ret_live, 7, 0, 1, 6)
        self.use_board = W.QCheckBox("Użyj pola szachowego (zakładka „Pole stylów”) jako styl multihybrydowy"); self.mutate_sp = W.QSpinBox()
        self.mutate_sp.setRange(0, 100); self.mutate_sp.setSuffix(" %"); self.mutate_sp.setToolTip("Losowanie kompletne: szansa, że wylosowany styl zostanie zmutowany (pole szachowe albo losowy partner)")
        g.addWidget(self.use_board, 8, 0, 1, 4); g.addWidget(W.QLabel("Mutacje stylu (losowanie):"), 8, 4); g.addWidget(self.mutate_sp, 8, 5)
        self.new_hyb = W.QCheckBox("Losuj nowe hybrydy (każda aranżacja = świeża hybryda 2–3 stylów)")
        self.new_hyb.setToolTip("Tryb losowy: zamiast czystego stylu każda aranżacja dostaje nową, losową hybrydę z dowolnych grup stylów\n"
                                "(losowe proporcje, bez powtórek z ostatnich aranżacji). Ma pierwszeństwo przed mutacjami i polem szachowym.\n"
                                "Nie działa, gdy styl jest zablokowany („Na sztywno z Generatora”).")
        g.addWidget(self.new_hyb, 11, 0, 1, 6)
        self.cx_follow = W.QCheckBox("Nastrój wg pory dnia"); self.cx_follow.setChecked(True)
        self.cx_follow.setToolTip("Rano→easy listening, Popołudnie→balanced, Wieczór→energetic, Noc→chill.\nSuwak intensywności nadal działa.")
        self.cx_mode = W.QComboBox()
        for key in L.COMPLEXITY_ORDER:
            self.cx_mode.addItem(L.COMPLEXITY_LABELS[key], key)
        self.cx_mode.setCurrentIndex(2)
        self.cx_mode.setToolTip("Zbiorowy nastrój losowania kompletnego: energy, density, era, spectacle,\nniuanse, uniq, wagi stylów — jednym wyborem + suwak intensywności.")
        self.cx_int = W.QSlider(Qt.Orientation.Horizontal)
        self.cx_int.setRange(0, 100); self.cx_int.setValue(50)
        self.cx_int_lbl = W.QLabel("0.50")
        self.cx_int.valueChanged.connect(lambda v: self.cx_int_lbl.setText(f"{v/100:.2f}"))
        g.addWidget(W.QLabel("Złożoność / nastrój:"), 9, 0)
        g.addWidget(self.cx_mode, 9, 1, 1, 2)
        g.addWidget(self.cx_follow, 9, 3, 1, 2)
        g.addWidget(W.QLabel("Intensywność nastroju:"), 10, 0)
        g.addWidget(self.cx_int, 10, 1, 1, 3)
        g.addWidget(self.cx_int_lbl, 10, 4)
        self.mood_bias = W.QSlider(Qt.Orientation.Horizontal); self.mood_bias.setRange(-50, 50); self.mood_bias.setValue(0)
        self.mood_bias_lbl = W.QLabel("0.00")
        self.mood_bias.valueChanged.connect(lambda v: self.mood_bias_lbl.setText(f"{v/100:+.2f}"))
        self.mood_bias.setToolTip("Przesuwa nastrój losowania: w prawo = jaśniej i żwawiej (więcej dur / dorycka / miksolidyjska), w lewo = ciemniej i poważniej.\n"
                                  "0 = nastrój wynika tylko z wybranej złożoności (każdy tryb ma teraz nastrój lekko jasny).")
        self.groove = W.QCheckBox("Groove (rytmy taneczne melodii, perkusjonalia, czytelny bit)")
        self.groove.setChecked(True)
        self.groove.setToolTip("Losowanie: włącza „Rytmy taneczne melodii” (siła rośnie z intensywnością), dokłada 1–2 perkusjonalia\n"
                               "(shaker, rim, clap, conga…) i podnosi przewidywalność perkusji, żeby bit był regularny i czytelny.\n"
                               "Ustawienia z Generatora są dolną granicą — losowanie ich nie obniża.")
        self.tidy = W.QSlider(Qt.Orientation.Horizontal); self.tidy.setRange(0, 100); self.tidy.setValue(70)
        self.tidy_lbl = W.QLabel("0.70")
        self.tidy.valueChanged.connect(lambda v: self.tidy_lbl.setText(f"{v/100:.2f}"))
        self.tidy.setToolTip("Porządek warstw w losowaniu: 0 = jak dawniej. Od 0.25: limit leadów i długich warstw (pady, drone, chór…) spoza rdzenia stylu,\n"
                             "rzadszy arpeggiator na wysokiej intensywności, od 0.5 bez zamian ról instrumentów w trakcie utworu.\n"
                             "Lekarstwo na „zagmatwane” wyższe tryby.")
        g.addWidget(W.QLabel("Jasność nastroju:"), 12, 0)
        g.addWidget(self.mood_bias, 12, 1, 1, 3); g.addWidget(self.mood_bias_lbl, 12, 4)
        g.addWidget(self.groove, 13, 0, 1, 3)
        g.addWidget(W.QLabel("Porządek warstw:"), 14, 0)
        g.addWidget(self.tidy, 14, 1, 1, 3); g.addWidget(self.tidy_lbl, 14, 4)
        # --- Icecast2 + config.txt
        ig = W.QWidget(); gi = W.QGridLayout(ig)
        self.ic_on = W.QCheckBox("Nadawaj do Icecast2"); self.ic_local = W.QCheckBox("Graj też lokalnie (odznacz na serwerze bez audio)")
        self.ic_host = W.QLineEdit(); self.ic_port = W.QSpinBox(); self.ic_port.setRange(1, 65535)
        self.ic_mount = W.QLineEdit(); self.ic_user = W.QLineEdit(); self.ic_pass = W.QLineEdit(); self.ic_pass.setEchoMode(W.QLineEdit.EchoMode.Password)
        self.ic_fmt = W.QComboBox(); self.ic_fmt.addItems(["mp3", "ogg", "opus"]); self.ic_br = W.QSpinBox(); self.ic_br.setRange(32, 320); self.ic_br.setSingleStep(32); self.ic_br.setSuffix(" kbps")
        self.ic_name = W.QLineEdit(); self.ic_adm = W.QLineEdit(); self.ic_adm.setEchoMode(W.QLineEdit.EchoMode.Password); self.ic_tls = W.QCheckBox("TLS")
        self.ic_adm.setPlaceholderText("opcjonalne — tytuł utworu w Icecast")
        gi.addWidget(self.ic_on, 0, 0, 1, 2); gi.addWidget(self.ic_local, 0, 2, 1, 3); gi.addWidget(self.ic_tls, 0, 5)
        self.pl_cb = W.QComboBox(); self.pl_cb.addItems(["auto", "aplay", "pw-cat", "paplay", "mpv", "ffplay"])
        self.dev_cb = W.QComboBox(); self.dev_cb.setEditable(True); self.dev_cb.setMinimumWidth(240)
        self.dev_cb.setToolTip("Urządzenie wyjściowe odsłuchu lokalnego (puste = domyślne). aplay: plughw:1,0; paplay/pw-cat: nazwa sinka; mpv: alsa/plughw:1,0")
        self.dev_btn = W.QPushButton("Odśwież listę"); self.dev_btn.clicked.connect(self.refresh_devices)
        self.pl_cb.currentTextChanged.connect(self.apply_audio); self.dev_cb.currentTextChanged.connect(self.apply_audio)
        for r_, (lab, wd) in enumerate((("Host:", self.ic_host), ("Port:", self.ic_port), ("Mount:", self.ic_mount), ("Użytkownik źródła:", self.ic_user),
                                         ("Hasło źródła:", self.ic_pass), ("Format:", self.ic_fmt), ("Bitrate:", self.ic_br), ("Nazwa streamu:", self.ic_name), ("Hasło admina:", self.ic_adm))):
            col = (r_ % 3) * 2; row = 1 + r_ // 3
            gi.addWidget(W.QLabel(lab), row, col); gi.addWidget(wd, row, col + 1)
        self.ic_status = W.QLabel("Icecast: wyłączony"); self.ic_status.setWordWrap(True); gi.addWidget(self.ic_status, 4, 0, 1, 6)
        cr = W.QHBoxLayout()
        for txt, fn in (("Zapisz config.txt", self.save_conf), ("Przeładuj config.txt", self.reload_conf), ("Otwórz config.txt", self.open_conf)):
            b = W.QPushButton(txt); b.clicked.connect(fn); cr.addWidget(b)
        cr.addStretch(1); self.conf_lbl = W.QLabel(str(self.conf["path"])); cr.addWidget(self.conf_lbl); gi.addLayout(cr, 5, 0, 1, 6)
        gi.addWidget(W.QLabel("Odtwarzacz:"), 6, 0); gi.addWidget(self.pl_cb, 6, 1); gi.addWidget(W.QLabel("Urządzenie:"), 6, 2); gi.addWidget(self.dev_cb, 6, 3, 1, 2); gi.addWidget(self.dev_btn, 6, 5)
        cfgtabs = W.QTabWidget(); cfgtabs.addTab(box, "Tryb auto"); cfgtabs.addTab(ig, "Icecast2 / config.txt"); v.addWidget(cfgtabs)
        self.rb_cur.toggled.connect(self._mode_ui); self._mode_ui()

        # --- oś czasu
        zr = W.QHBoxLayout(); zr.addWidget(W.QLabel("Oś czasu (dwuklik = odsłuch od startu aranżacji, Ctrl/Shift = zaznacz wiele)"))
        zr.addStretch(1); zr.addWidget(W.QLabel("Zoom:"))
        self.zoom = W.QSlider(Qt.Orientation.Horizontal); self.zoom.setRange(5, 40); self.zoom.setValue(15); self.zoom.setMaximumWidth(160)
        self.follow = W.QCheckBox("Śledź playhead"); self.follow.setChecked(True)
        zr.addWidget(self.zoom); zr.addWidget(self.follow); v.addLayout(zr)
        self.tl = Timeline(); self.sa = W.QScrollArea(); self.sa.setWidget(self.tl); self.sa.setWidgetResizable(True)
        self.sa.setMinimumHeight(190); self.tl.resize(400, 170)
        v.addWidget(self.sa, 1)
        self.zoom.valueChanged.connect(self._zoom); self._zoom()
        self.tl.selChanged.connect(self._sel_changed); self.tl.playRequested.connect(self.play_from)

        # --- zaznaczenie
        self.info = W.QLabel("Zaznacz aranżację na osi czasu…"); self.info.setWordWrap(True); v.addWidget(self.info)
        r = W.QHBoxLayout()
        for txt, fn in (("▶ Odsłuchaj od startu", self.play_sel), ("📌 Przypnij / odepnij", self.pin_sel), ("Wczytaj do edytora", self.load_sel),
                        ("Zapisz do biblioteki", self.save_sel), ("Wyczyść magazyn (poza przypiętymi)", self.clear_store), ("Otwórz folder magazynu", self.open_store)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)

        # --- zrzut MP3
        dg = W.QGroupBox("Zrzut MP3"); dr = W.QHBoxLayout(dg)
        self.scope = W.QComboBox()
        self.scope.addItems(["Zaznaczone aranżacje", "Cały magazyn", "Ostatnie N minut", "Auto: losowe N aranżacji z magazynu"])
        self.dump_n = W.QSpinBox(); self.dump_n.setRange(1, 600); self.dump_n.setValue(5)
        self.b_dump = W.QPushButton("Zrzut MP3…"); self.b_dump.clicked.connect(self.dump)
        dr.addWidget(W.QLabel("Zakres:")); dr.addWidget(self.scope, 1); dr.addWidget(W.QLabel("N:")); dr.addWidget(self.dump_n); dr.addWidget(self.b_dump)
        v.addWidget(dg)

        self.apply_conf(self.conf)
        self.push_timer = QtCore.QTimer(self); self.push_timer.timeout.connect(self._push); self.push_timer.start(500)
        self.tick_timer = QtCore.QTimer(self); self.tick_timer.timeout.connect(self._tick); self.tick_timer.start(50)
        self._push()
        if self.conf["live"]["auto_start"]:
            QtCore.QTimer.singleShot(1500, self.start)

    # ------------------------------------------------------------------ ustawienia -> silnik
    def _mode_ui(self):
        rnd = self.rb_rnd.isChecked()
        for w in (self.lock_row, self.tod_on, self.tod_force, self.new_hyb, self.mood_bias, self.groove, self.tidy, *self.tod_sp.values()):
            w.setEnabled(rnd)

    def _zoom(self):
        self.tl.pps = self.zoom.value() / 3.0; self.tl.relayout()

    def collect_cfg(self):
        return dict(mode="random" if self.rb_rnd.isChecked() else "current", locks={k: c.isChecked() for k, c in self.lock.items()},
                    tod_on=self.tod_on.isChecked(), tod_force=None if self.tod_force.currentIndex() == 0 else self.tod_force.currentText(),
                    tod_factors={n: sp.value() / 100.0 for n, sp in self.tod_sp.items()}, arr_bars=self.arr_bars.value(),
                    lookahead=self.lookahead.value(), max_store=self.max_store.value(), return_live=self.ret_live.isChecked(),
                    use_board=self.use_board.isChecked(), board=self.main.board.cells_list(), board_strength=self.main.board.get_strength(),
                    mutate_p=self.mutate_sp.value() / 100.0, new_hybrids=self.new_hyb.isChecked(),
                    complexity=self.cx_mode.currentData() or "balanced",
                    complexity_intensity=self.cx_int.value() / 100.0,
                    complexity_follow_tod=self.cx_follow.isChecked(),
                    mood_bias=self.mood_bias.value() / 100.0, groove=self.groove.isChecked(), tidy=self.tidy.value() / 100.0,
                    keep_sessions=self.conf["live"]["keep_sessions"], clean_on_exit=self.conf["live"]["clean_on_exit"])

    def set_cfg_widgets(self, c):
        """Ustawia kontrolki trybu auto ze słownika w formacie collect_cfg (presety)."""
        (self.rb_rnd if c.get("mode") == "random" else self.rb_cur).setChecked(True)
        lk = c.get("locks", {})
        for k, cb in self.lock.items():
            cb.setChecked(bool(lk.get(k)))
        self.tod_on.setChecked(bool(c.get("tod_on", True))); self.tod_force.setCurrentIndex(max(0, self.tod_force.findText(c.get("tod_force") or "")))
        for n, sp in self.tod_sp.items():
            if n in c.get("tod_factors", {}):
                sp.setValue(int(round(c["tod_factors"][n] * 100)))
        for wd, k in ((self.arr_bars, "arr_bars"), (self.lookahead, "lookahead"), (self.max_store, "max_store")):
            if k in c:
                wd.setValue(int(c[k]))
        self.ret_live.setChecked(bool(c.get("return_live", True))); self.use_board.setChecked(bool(c.get("use_board")))
        self.mutate_sp.setValue(int(round(float(c.get("mutate_p", 0)) * 100))); self.new_hyb.setChecked(bool(c.get("new_hybrids")))
        if hasattr(self, "cx_mode"):
            i = self.cx_mode.findData(c.get("complexity") or "balanced")
            if i >= 0:
                self.cx_mode.setCurrentIndex(i)
            self.cx_int.setValue(int(round(float(c.get("complexity_intensity", 0.5)) * 100)))
            self.cx_follow.setChecked(bool(c.get("complexity_follow_tod", True)))
            self.mood_bias.setValue(int(round(float(c.get("mood_bias", 0.0)) * 100)))
            self.groove.setChecked(bool(c.get("groove", True))); self.tidy.setValue(int(round(float(c.get("tidy", 0.7)) * 100)))

    def collect_base(self):
        """Pełny snapshot Generatora → generate() (current + baza pod random)."""
        m = self.main
        dirc = m.director_cfg() if hasattr(m, "director_cfg") else None
        return dict(
            style=m.cur_style(), bpm=m.bpm.value(),
            key=None if m.keyc.currentIndex() == 0 else m.keyc.currentIndex() - 1,
            scale=m.scale.currentText(),
            energy=m.energy.value() / 100, density=m.density.value() / 100, swing=m.swing.value() / 100,
            predict=(m.predict.value() / 100) if hasattr(m, "predict") else 0.6,
            dance=bool(getattr(m, "dance_on", None) and m.dance_on.isChecked()),
            dance_strength=(m.dance_str.value() / 100) if hasattr(m, "dance_str") else 0.6,
            instruments=m.selected_instruments() or L.G.default_instruments(m.cur_style()),
            speak_text=m.sp_text.toPlainText().strip() if m.sp_man.isChecked() else None,
            speak_theme=None if m.sp_theme.currentIndex() == 0 else m.sp_theme.currentText(),
            smart_instruments=getattr(m, "smart_inst", None) and m.smart_inst.isChecked(),
            autolevels=getattr(m, "auto_lvl", None) and m.auto_lvl.isChecked(),
            role_swap=getattr(m, "role_swap", None) and m.role_swap.isChecked(),
            scenarios=getattr(m, "scenarios", None) and m.scenarios.isChecked(),
            character=m.character.currentText() if hasattr(m, "character") else "balanced",
            director=dirc,
            arranger=m.arranger_cfg() if hasattr(m, "arranger_cfg") else None,
            niuanse=getattr(m, "niu_on", None) and m.niu_on.isChecked(),
            niuanse_strength=(m.niu_str.value() / 100.0) if hasattr(m, "niu_str") else 0.0,
            spectacle=(m.spectacle.currentData() or "balanced") if hasattr(m, "spectacle") else "balanced",
            era=(m.era.currentData() or "auto") if hasattr(m, "era") else "auto",
            uniq=getattr(m, "uniq_on", None) and m.uniq_on.isChecked(),
            uniq_strength=(m.uniq_str.value() / 100.0) if hasattr(m, "uniq_str") else 0.6,
            uniq_drops=getattr(m, "uniq_drops", None) and m.uniq_drops.isChecked(),
            health=m.health_cfg() if hasattr(m, "health_cfg") else {"on": False},
            structure_affinity=getattr(m, "struct_aff", None) and m.struct_aff.isChecked(),
            affinity_passes=m.aff_passes.value() if hasattr(m, "aff_passes") else 2,
            arp=m.arp_cfg() if hasattr(m, "arp_cfg") else {"enabled": False, "structural_inject": True},
            replace_on=getattr(m, "repl_on", None) and m.repl_on.isChecked(),
            replace_rules=m.replace_rules() if hasattr(m, "replace_rules") else None,
            replace_policy=m.replace_policy() if hasattr(m, "replace_policy") else None,
        )

    def collect_ice(self):
        c = dict(self.conf["icecast"])        # pola bez kontrolek w GUI (opis, genre, url, public, legacy, metadata, admin_user, reconnect_sec) zostają z config.txt
        c.update(enabled=self.ic_on.isChecked(), local_playback=self.ic_local.isChecked(), host=self.ic_host.text().strip() or "localhost", port=self.ic_port.value(),
                 mount=("/" + self.ic_mount.text().strip().lstrip("/")) if self.ic_mount.text().strip() else "/stream", source_user=self.ic_user.text().strip() or "source",
                 password=self.ic_pass.text(), format=self.ic_fmt.currentText(), bitrate=self.ic_br.value(), name=self.ic_name.text().strip(),
                 admin_password=self.ic_adm.text(), tls=self.ic_tls.isChecked())
        return c

    def _push(self):
        self.eng.set_cfg(self.collect_cfg()); self.eng.set_base(self.collect_base())
        ice = self.collect_ice()          # zmiany połączenia stosujemy dopiero po ~1 s bez edycji (bez restartu przy każdym wpisanym znaku)
        self._ice_stable = self._ice_stable + 1 if ice == self._ice_seen else 0; self._ice_seen = ice
        if self._ice_stable == 2 or not self.eng.running:
            rtmp, av = self.collect_rtmp_av()
            self.eng.set_output(ice, ice["local_playback"], rtmp_cfg=rtmp, av_cfg=av)
        st = self.eng.out_status()
        extra = f"   ·   {st['rtmp']}" if st.get("rtmp") else ""
        self.ic_status.setText(f"{st['icecast']}   ·   {st['local']}{extra}")

    def collect_rtmp_av(self):
        """RTMP + AV z zakładki Wideo/RTMP głównego okna (jeśli dostępne)."""
        m = self.main
        if not hasattr(m, "rtmp_on"):
            return {"enabled": False}, {}
        try:
            av = m._vid_av_settings() if hasattr(m, "_vid_av_settings") else {}
            # bitrate stream: "2500k" → 2500
            vbr = (m.rtmp_vbr.text().strip() if hasattr(m, "rtmp_vbr") else "2500k").rstrip("kK")
            try:
                vbr_i = int(float(vbr))
            except Exception:
                vbr_i = 2500
            rtmp = dict(
                enabled=bool(m.rtmp_on.isChecked()),
                url=m.rtmp_url.text().strip() if hasattr(m, "rtmp_url") else "",
                key=m.rtmp_key.text().strip() if hasattr(m, "rtmp_key") else "",
                reconnect=bool(m.rtmp_reconnect.isChecked()) if hasattr(m, "rtmp_reconnect") else True,
                reconnect_sec=5, retries=0, timeout_sec=10, live=True,
                width=av.get("width", 1280), height=av.get("height", 720), fps=av.get("fps", 30),
                v_bitrate=vbr_i, a_bitrate=128, v_codec="libx264", v_preset="veryfast",
            )
            tpl = m.vid_tpl.currentData() if hasattr(m, "vid_tpl") else "live_show"
            av = dict(av, template=tpl or "live_show", palette=None)
            return rtmp, av
        except Exception:
            return {"enabled": False}, {}

    # ------------------------------------------------------------------ config.txt
    def refresh_devices(self):
        cur = self.dev_cb.currentText(); self.dev_cb.blockSignals(True); self.dev_cb.clear(); self.dev_cb.addItem("")
        for pl, did, desc in L.list_devices():
            self.dev_cb.addItem(did); self.dev_cb.setItemData(self.dev_cb.count() - 1, f"{pl}: {desc}", Qt.ItemDataRole.ToolTipRole)
        self.dev_cb.setEditText(cur); self.dev_cb.blockSignals(False)

    def apply_audio(self, *_):
        """Odtwarzacz i urządzenie wyjściowe odsłuchu lokalnego — działa od razu (restart rury do odtwarzacza)."""
        pl, dev = self.pl_cb.currentText(), self.dev_cb.currentText().strip()
        for k, v in (("DS_LIVE_PLAYER", None if pl == "auto" else pl), ("DS_AUDIO_DEVICE", dev or None)):
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        if getattr(self, "eng", None) is not None and self.eng.running and self.eng.out.use_local():
            self.eng.out.local.start()

    def apply_conf(self, conf):
        lv, ic, ge, m = conf["live"], conf["icecast"], conf["generator"], self.main
        (self.rb_rnd if lv["mode"] == "random" else self.rb_cur).setChecked(True)
        for k, c in self.lock.items():
            c.setChecked(k in lv["locks"])
        self.tod_on.setChecked(lv["tod_on"]); i = self.tod_force.findText(lv["tod_force"] or ""); self.tod_force.setCurrentIndex(max(0, i))
        for n, sp in self.tod_sp.items():
            sp.setValue(int(round(lv["tod_factors"][n] * 100)))
        self.refresh_devices(); self.pl_cb.blockSignals(True); self.pl_cb.setCurrentText(lv.get("player", "auto")); self.pl_cb.blockSignals(False)
        self.dev_cb.blockSignals(True); self.dev_cb.setEditText(lv.get("audio_device", "")); self.dev_cb.blockSignals(False); self.apply_audio()
        self.new_hyb.setChecked(bool(lv.get("new_hybrids"))); self.mutate_sp.setValue(int(round(lv.get("mutate_p", 0) * 100))); self.arr_bars.setValue(lv["arr_bars"]); self.lookahead.setValue(lv["lookahead"]); self.max_store.setValue(lv["max_store"]); self.ret_live.setChecked(lv["return_live"])
        if hasattr(self, "cx_mode"):
            i = self.cx_mode.findData(lv.get("complexity") or "balanced")
            if i >= 0:
                self.cx_mode.setCurrentIndex(i)
            self.cx_int.setValue(int(round(float(lv.get("complexity_intensity", 0.5)) * 100)))
            self.cx_follow.setChecked(bool(lv.get("complexity_follow_tod", True)))
        self.ic_on.setChecked(ic["enabled"]); self.ic_local.setChecked(ic["local_playback"]); self.ic_tls.setChecked(ic["tls"]); self.ic_host.setText(ic["host"])
        self.ic_port.setValue(ic["port"]); self.ic_mount.setText(ic["mount"]); self.ic_user.setText(ic["source_user"]); self.ic_pass.setText(ic["password"])
        self.ic_fmt.setCurrentText(ic["format"]); self.ic_br.setValue(ic["bitrate"]); self.ic_name.setText(ic["name"]); self.ic_adm.setText(ic["admin_password"])
        if ge["style"] in L.G.STYLES:                                  # zakładka Generator = baza trybu „styl aktualnie ustawiony"
            m.use_style(ge["style"])
            if ge["bpm"]:
                m.bpm.setValue(ge["bpm"])
            m.keyc.setCurrentIndex(0 if ge["key"] is None else ge["key"] + 1)
            m.scale.setCurrentText(ge["scale"]); m.energy.setValue(int(ge["energy"] * 100)); m.density.setValue(int(ge["density"] * 100))
            if ge["swing"] >= 0:
                m.swing.setValue(int(ge["swing"] * 100))
            m.set_instruments(CF.to_base(conf)["instruments"])
        self._ice_stable = 0

    def save_conf(self):
        c, ic, m = self.collect_cfg(), self.collect_ice(), self.main
        yn = lambda b: "yes" if b else "no"
        U = {("icecast", "enabled"): yn(ic["enabled"]), ("icecast", "local_playback"): yn(ic["local_playback"]), ("icecast", "tls"): yn(ic["tls"]),
             ("icecast", "host"): ic["host"], ("icecast", "port"): ic["port"], ("icecast", "mount"): ic["mount"], ("icecast", "source_user"): ic["source_user"],
             ("icecast", "password"): ic["password"], ("icecast", "format"): ic["format"], ("icecast", "bitrate"): ic["bitrate"], ("icecast", "name"): ic["name"],
             ("icecast", "admin_password"): ic["admin_password"],
             ("live", "player"): self.pl_cb.currentText(), ("live", "audio_device"): self.dev_cb.currentText().strip(),
             ("live", "mutate"): int(round(c["mutate_p"] * 100)), ("live", "new_hybrids"): yn(c["new_hybrids"]), ("live", "mode"): c["mode"], ("live", "arr_bars"): c["arr_bars"], ("live", "lookahead"): c["lookahead"], ("live", "max_store"): c["max_store"],
             ("live", "return_live"): yn(c["return_live"]), ("live", "tod_on"): yn(c["tod_on"]), ("live", "tod_force"): c["tod_force"] or "auto",
             ("live", "tod_rano"): int(round(c["tod_factors"]["Rano"] * 100)), ("live", "tod_popoludnie"): int(round(c["tod_factors"]["Popołudnie"] * 100)),
             ("live", "tod_wieczor"): int(round(c["tod_factors"]["Wieczór"] * 100)), ("live", "tod_noc"): int(round(c["tod_factors"]["Noc"] * 100)),
             ("live", "lock"): ",".join(k for k, v_ in c["locks"].items() if v_)}
        b = self.collect_base()
        U.update({("generator", "style"): b["style"], ("generator", "bpm"): b["bpm"], ("generator", "key"): "auto" if b["key"] is None else b["key"],
                  ("generator", "scale"): b["scale"], ("generator", "energy"): round(b["energy"], 2), ("generator", "density"): round(b["density"], 2),
                  ("generator", "swing"): round(b["swing"], 2), ("generator", "instruments"): ",".join(b["instruments"])})
        try:
            CF.save_values(self.conf["path"], U); self.conf = CF.load(self.conf["path"])
            self.main.status.setText(f"Zapisano {self.conf['path']} (łącznie z bieżącymi ustawieniami zakładki Generator)")
        except OSError as ex:
            W.QMessageBox.critical(self, "config.txt", str(ex))

    def reload_conf(self):
        self.conf = CF.load(self.conf["path"]); self.apply_conf(self.conf); self.main.status.setText(f"Wczytano {self.conf['path']}")

    def open_conf(self):
        subprocess.Popen(["xdg-open" if sys.platform != "darwin" else "open", str(self.conf["path"])])

    # ------------------------------------------------------------------ sterowanie
    def start(self):
        if self.eng.running:
            return
        self.main.player.stop()                      # podgląd offline i strumień nie grają naraz
        self._err_shown = False
        self.tl.arrs = self.eng.arrs; self.tl.sel = set(); self.tl.planning = None; self.tl.head = None
        self._push(); self.eng.start(); self.tl.arrs = self.eng.arrs
        self.status.setText("Start — generuję pierwszą aranżację…")

    def stop(self):
        self.eng.stop(); self.tl.head = None; self.tl.playing = None; self.tl.planning = None; self.tl.update()
        self.status.setText(f"Zatrzymany. Magazyn: {self.eng.session or '—'}")

    def pause(self):
        self.eng.set_paused(self.b_pause.isChecked())
        self.b_pause.setText("▶ Wznów" if self.b_pause.isChecked() else "⏸ Pauza")

    def skip(self):
        if not self.eng.skip():
            self.status.setText("Następna aranżacja jeszcze się generuje…")

    def to_live(self):
        self.eng.back_to_live()

    def play_from(self, idx):
        if not self.eng.running:
            self.start(); return
        if not self.eng.jump(idx):
            self.status.setText("Tej aranżacji nie ma już w magazynie.")
        else:
            self.b_pause.setChecked(False); self.b_pause.setText("⏸ Pauza")

    # ------------------------------------------------------------------ zdarzenia z wątków
    def _on_event(self, kind, kw):
        if kind == "planning":
            self.tl.planning = kw["plan"]; self.status.setText(f"Generuję #{kw['idx'] + 1}: {kw['plan']['desc']}"); self.tl.relayout()
        elif kind == "added":
            self.tl.planning = None; self.tl.relayout()
        elif kind == "playing":
            self.tl.playing = kw["idx"]; self._sel_changed()
            a = self.eng.arrs[kw["idx"]]
            self.status.setText(("🎧 odsłuch z osi: " if self.eng.auditing else "● LIVE: ") + a.label() + f" ({a.plan['desc']})")
        elif kind == "evicted":
            self.tl.update()
        elif kind == "error" and not self._err_shown:
            self._err_shown = True; self.status.setText("Błąd silnika Live — szczegóły w oknie")
            W.QMessageBox.critical(self, "Live", kw["msg"])

    def _tick(self):
        pos = self.eng.position()
        if pos is None or pos[0] >= len(self.eng.arrs):
            self.tl.head = None
        else:
            self.tl.head = self.eng.arrs[pos[0]].start_sec + pos[1]
            if self.follow.isChecked():
                self.sa.ensureVisible(int(self.tl.head * self.tl.pps), 20, 120, 0)
        self.tl.update()

    # ------------------------------------------------------------------ zaznaczenie / magazyn
    def _sel_arrs(self):
        return [self.eng.arrs[i] for i in sorted(self.tl.sel) if i < len(self.eng.arrs)]

    def _sel_changed(self):
        s = self._sel_arrs()
        if not s:
            self.info.setText("Zaznacz aranżację na osi czasu…"); return
        if len(s) > 1:
            self.info.setText(f"Zaznaczono {len(s)} aranżacji, razem {fmt_t(sum(a.dur for a in s))}."); return
        a = s[0]; p = a.proj
        self.info.setText(f"{a.label()} · {fmt_t(a.dur)} · start na osi {fmt_t(a.start_sec)} · pora: {a.plan['slot']} · "
                          f"energia {p['energy']:.2f}, gęstość {p['density']:.2f}, swing {p['swing']:.2f} · {len(p['tracks'])} ścieżek: "
                          f"{', '.join(t['type'] for t in p['tracks'])}{' · 📌 przypięta' if a.pinned else ''}{' · USUNIĘTA z magazynu' if a.evicted else ''}")

    def play_sel(self):
        s = self._sel_arrs()
        if s:
            self.play_from(s[0].idx)

    def pin_sel(self):
        s = self._sel_arrs()
        if s:
            self.eng.set_pinned([a.idx for a in s], not all(a.pinned for a in s)); self._sel_changed(); self.tl.update()

    def load_sel(self):
        s = self._sel_arrs()
        if len(s) != 1 or s[0].evicted:
            self.status.setText("Zaznacz jedną aranżację."); return
        self.main.set_project(copy.deepcopy(s[0].proj)); self.main.tabs.setCurrentIndex(0)
        self.main.status.setText(f"Wczytano z Live: {s[0].label()} (ustawia też bazę dla trybu „styl aktualnie ustawiony”)")

    def save_sel(self):
        s = [a for a in self._sel_arrs() if not a.evicted]
        if not s:
            self.status.setText("Zaznacz aranżację do zapisu."); return
        try:
            for a in s:
                d = L.save_arr_to_library(a)
            self.main.refresh_library(); self.status.setText(f"Zapisano {len(s)} do biblioteki (ostatnia: {d.name})")
        except Exception as ex:
            W.QMessageBox.critical(self, "Live", str(ex))

    def clear_store(self):
        self.eng.clear_store(); self.tl.update()

    def open_store(self):
        if self.eng.session:
            subprocess.Popen(["xdg-open" if sys.platform != "darwin" else "open", str(self.eng.session)])

    # ------------------------------------------------------------------ zrzut MP3
    def dump(self):
        arrs = [a for a in self.eng.arrs if not a.evicted]; i = self.scope.currentIndex(); n = self.dump_n.value()
        if i == 0:
            sel = self._sel_arrs()
        elif i == 1:
            sel = arrs
        elif i == 2:
            sel, acc = [], 0.0
            for a in reversed(arrs):
                sel.insert(0, a); acc += a.dur
                if acc >= n * 60:
                    break
        else:
            sel = L.pick_auto(arrs, n)
        sel = [a for a in sel if not a.evicted]
        if not sel:
            W.QMessageBox.information(self, "Live", "Brak aranżacji do zrzutu (zaznacz na osi albo zmień zakres)."); return
        default = str(Path.home() / "DubstepStudio" / f"live-{datetime.datetime.now():%Y%m%d-%H%M}.mp3")
        path, _ = W.QFileDialog.getSaveFileName(self, "Zrzut MP3", default, "MP3 (*.mp3)")
        if not path:
            return
        names = ", ".join(f"#{a.idx + 1}" for a in sel[:12]) + ("…" if len(sel) > 12 else "")
        self.main.run_bg(lambda prog: L.dump_mp3(sel, path, prog),
                         lambda p: self.main.status.setText(f"Zrzut gotowy: {p} ({len(sel)} aranżacji: {names})"), f"Zrzut MP3: {len(sel)} aranżacji…")

    def shutdown(self):
        self.push_timer.stop(); self.tick_timer.stop(); self.eng.stop()
