"""styles.py — style spoza dubstepu + hybrydy (mutacje) między dowolnymi stylami.

Styl = słownik konfiguracji czytany przez generator.py (klucze jak w STYLES, plus nowe opcjonalne):
  core       lista ścieżek „podstawowych" zamiast CORE8 (np. muzyka klasyczna bez perkusji)
  voices     {typ: n} — ile instancji wtyczki (wtyczki są jednogłosowe, akord = kilka instancji)
  snare      kroki werbla/clapa (domyślnie [8]; [] = brak),  ghost = [(krok, vel)] ciche werble
  hat        "16" | "8" | "trap" | "offbeat" | "off" | "ride" | "none"
  swing8     opóźnienie ósemek „i" w ułamku ćwierćnuty (0.1667 = pełne trioli)
  sub_mode   "hold" | "offbeat" | "roll" | "pulse8" | "funk" | "walk" | "off"
  progs      lista progresji (stopnie skali), scales = preferowane skale
  arp        {"step","pattern","prob","phase"} — arpeggio na pluck;  gate = kroki bramkowanego supersaw (trance)
  comp       rytmy komponowania akordów (stab);  melody = klucz rytmiki linii melodycznej (panflute/theremin)
  pad_mode   "drop" = pady grają też w dropie;  mutate = {"drop","jitter","octave","shift"} — losowa mutacja nut

HYBRYDA: nazwa stylu w formie „Techno 60% + DnB 40%". Jej konfiguracja jest składana deterministycznie z konfiguracji składników
(StyleDict.__missing__), więc działa wszędzie tam, gdzie wystarczy nazwa stylu: w projektach zapisanych w bibliotece, w remiksie, w Live.
"""
from __future__ import annotations

import contextlib
import contextvars
import random
import re

# ------------------------------------------------------------------ warianty stylu (style_rules.py) — wątkowo-lokalne nakładki
_variant_over = contextvars.ContextVar("ds_style_variant_over", default=None)   # {pure_name: full_cfg}
_variant_libs = contextvars.ContextVar("ds_style_variant_libs", default=None)   # {"WOB": {key: pats}, "GROWL": {...}}


@contextlib.contextmanager
def variant_scope(over, libs=None):
    """Kontekst, w którym STYLES[pure] i WOB/GROWL widzą wariant (deterministyczny z seeda projektu).

    over  — słownik {nazwa_czystego_stylu: pełna_konfiguracja} (delta już wtopiona)
    libs  — opcjonalnie {"WOB": {klucz: lista wzorów}, "GROWL": {...}}
    """
    from . import generator as G  # lokalny import: unika cyklu przy starcie pakietu
    tok_o = _variant_over.set(over or {})
    tok_l = _variant_libs.set(libs or {})
    saved_styles = {}
    for name, cfg in (over or {}).items():
        if dict.__contains__(G.STYLES, name):
            saved_styles[name] = dict.__getitem__(G.STYLES, name)
            dict.__setitem__(G.STYLES, name, cfg)
    hyb_backup = getattr(G.STYLES, "_hyb", None)
    if hyb_backup is not None:
        G.STYLES._hyb = {}
    saved_libs = {}
    for libname, items in (libs or {}).items():
        lib = getattr(G, libname, None)
        if not isinstance(lib, dict):
            continue
        for key, pats in items.items():
            if key in lib:
                saved_libs.setdefault(libname, {})[key] = lib[key]
            lib[key] = pats
    try:
        yield
    finally:
        for name, cfg in saved_styles.items():
            dict.__setitem__(G.STYLES, name, cfg)
        if hyb_backup is not None:
            G.STYLES._hyb = hyb_backup
        for libname, items in saved_libs.items():
            lib = getattr(G, libname, None)
            if isinstance(lib, dict):
                for key, pats in items.items():
                    lib[key] = pats
        _variant_over.reset(tok_o)
        _variant_libs.reset(tok_l)


def active_variant_over():
    return _variant_over.get()


def active_variant_libs():
    return _variant_libs.get()


# ------------------------------------------------------------------ szablony struktur
T_CLUB = [("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]
T_TRANCE = [("intro", 16), ("build", 8), ("drop", 32), ("break", 32), ("build", 8), ("drop", 32), ("outro", 16)]
T_DNB = [("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]
T_AMB = [("intro", 32), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]
T_MIN = [("intro", 16), ("drop", 32), ("break", 16), ("drop", 32), ("outro", 16)]
T_CLASSIC = [("intro", 8), ("drop", 16), ("break", 8), ("drop", 16), ("outro", 8)]
T_ROMANTIC = [("intro", 8), ("drop", 16), ("break", 12), ("build", 4), ("drop", 20), ("outro", 8)]
T_JAZZ = [("intro", 8), ("drop", 32), ("break", 16), ("drop", 32), ("outro", 8)]
T_FUSION = [("intro", 8), ("drop", 24), ("break", 16), ("build", 8), ("drop", 32), ("outro", 8)]
T_EXP = [("intro", 12), ("drop", 20), ("break", 12), ("build", 4), ("drop", 28), ("break", 8), ("outro", 12)]

NONE_KICK = [[0]]


def _mk(**kw):
    d = dict(extras=[], bpm=130, kick=[[0, 4, 8, 12]], hat="offbeat", wob="techno", growl="deep", wob_div=[8, 9], growl_div=[5],
             reese="none", lead="none", chord_len=2, swing=0.0, template=T_CLUB)
    d.update(kw)
    return d


NEW_STYLES = {
    # ---------------- techno / house / trance
    "Techno": _mk(core=["kick", "snare", "hat", "sub", "wobble", "acid"], extras=["openhat", "hoover", "clap", "rim", "shaker", "crash", "riser", "boom", "pluck", "stab", "zap", "tom", "fmbass", "pad", "cowbell", "conga", "drone"],
                  bpm=130, fourfloor=True, snare=[4, 12], hat="offbeat", wob="techno", sub_mode="offbeat", swing=0.03,
                  progs=[[0], [0, 0, 0, 5], [0, 0, 5, 6]], scales=["minor", "phrygian"]),
    "Acid Techno": _mk(core=["kick", "snare", "hat", "sub", "wobble", "acid", "fmbass"], extras=["cowbell", "openhat", "clap", "rim", "shaker", "crash", "riser", "zap", "stab", "tom", "boom", "neuro", "hoover"],
                       bpm=135, fourfloor=True, snare=[4, 12], hat="16", wob="acid", sub_mode="offbeat", wob_div=[9, 10, 11], swing=0.04,
                       progs=[[0], [0, 0, 5, 0], [0, 0, 0, 6]], scales=["minor", "phrygian"]),
    "Hard Techno": _mk(core=["kick", "snare", "hat", "sub", "wobble", "reese", "screech", "acid"], extras=["hoover", "glitch", "clap", "crash", "riser", "boom", "zap", "neuro", "tom", "stab", "rim", "fmbass", "openhat", "ride"], bpm=150, fourfloor=True, snare=[4, 12], hat="16", wob="hard",
                       sub_mode="roll", reese="late", lead="accent", wob_div=[10, 11], progs=[[0], [0, 0, 5, 6]], scales=["phrygian", "minor"]),
    "Techno Trax": _mk(core=["kick", "snare", "hat", "sub", "wobble", "screech"], extras=["hoover", "openhat", "clap", "crash", "riser", "boom", "supersaw", "stab", "pluck", "zap", "tom", "shaker", "vox", "brass"],
                       bpm=138, fourfloor=True, snare=[4, 12], hat="offbeat", wob="techno", sub_mode="offbeat", lead="melodic", voices={"supersaw": 2},
                       arp=dict(step=2, pattern="trance", prob=0.9), progs=[[0, 5, 2, 6], [0, 0, 5, 6]], scales=["minor", "phrygian", "harmonic minor"]),
    "Tunnel Trance": _mk(core=["kick", "snare", "hat", "sub", "wobble", "screech"], extras=["hoover", "choir", "clap", "crash", "riser", "boom", "supersaw", "pluck", "pad", "stab", "zap", "tom", "vox", "openhat", "bell"],
                         bpm=142, fourfloor=True, snare=[4, 12], hat="offbeat", wob="roll", sub_mode="roll", lead="melodic", voices={"supersaw": 3, "pad": 2},
                         gate=[0, 2, 3, 5, 6, 8, 10, 11, 13, 14], arp=dict(step=1, pattern="trance", prob=0.85), template=T_TRANCE,
                         progs=[[0, 5, 2, 6], [0, 2, 5, 6]], scales=["minor", "harmonic minor"]),
    "Trance": _mk(core=["kick", "snare", "hat", "sub", "wobble", "screech", "supersaw"], extras=["choir", "bell", "clap", "crash", "riser", "boom", "pluck", "pad", "stab", "vox", "panflute", "zap", "strings", "piano", "flute", "openhat", "brass", "hoover", "cello"],
                  bpm=138, fourfloor=True, snare=[4, 12], hat="offbeat", wob="techno", sub_mode="offbeat", lead="melodic", voices={"supersaw": 3, "pad": 2},
                  arp=dict(step=2, pattern="updown", prob=0.9), template=T_TRANCE, progs=[[0, 5, 2, 6]], scales=["minor", "major"]),
    "Psytrance": _mk(core=["kick", "hat", "sub", "wobble", "screech", "acid"], extras=["hoover", "openhat", "clap", "crash", "riser", "boom", "zap", "fmbass", "neuro", "stab", "pluck", "shaker", "tom", "vox", "supersaw", "glitch", "conga", "bell"],
                     bpm=145, fourfloor=True, snare=[], hat="offbeat", wob="psy", sub_mode="roll", lead="rare", wob_div=[10, 11, 12],
                     arp=dict(step=1, pattern="psy", prob=0.6), progs=[[0], [0, 0, 1, 0], [0, 1, 0, 6]], scales=["phrygian", "harmonic minor"]),
    "House": _mk(core=["kick", "snare", "hat", "sub", "wobble", "piano"], extras=["epiano", "organ", "openhat", "clap", "rim", "shaker", "crash", "riser", "boom", "pluck", "stab", "pad", "vox", "supersaw", "strings", "acid", "brass", "conga", "cowbell", "vibes", "choir"],
                 bpm=124, fourfloor=True, snare=[4, 12], hat="offbeat", wob="house", sub_mode="hold", lead="rare", swing=0.08, swing8=0.03,
                 voices={"stab": 3, "pad": 2}, comp=[[2, 6, 10, 14], [3, 10], [0, 6, 12], [2, 8, 14]],
                 progs=[[0, 3, 0, 4], [0, 5, 3, 4], [1, 4, 0, 5], [0, 6, 5, 6]], scales=["minor", "dorian"]),
    # ---------------- electro / drum & bass
    "Electro": _mk(core=["kick", "snare", "hat", "sub", "wobble"], extras=["bass808", "cowbell", "clap", "rim", "tom", "zap", "stab", "pluck", "vox", "shaker", "crash", "riser", "boom", "openhat", "glitch", "hoover", "bell", "epiano"],
                   bpm=128, kick=[[0, 6, 10], [0, 3, 10], [0, 7, 10, 14], [0, 10]], snare=[4, 12], ghost=[(7, 40), (15, 46)], hat="16", wob="electro",
                   sub_mode="funk", lead="rare", swing=0.04, progs=[[0, 0, 5, 0], [0, 3, 0, 6]], scales=["minor", "phrygian", "dorian"]),
    "DnB": _mk(core=["kick", "snare", "hat", "sub", "wobble", "reese"], extras=["ride", "epiano", "rim", "shaker", "crash", "riser", "boom", "pluck", "pad", "stab", "vox", "neuro", "zap", "piano", "strings", "fmbass", "openhat", "glitch", "choir"],
               bpm=174, kick=[[0, 10], [0, 10, 14], [0, 6, 10]], snare=[4, 12], ghost=[(7, 40), (14, 48), (15, 40)], hat="16", wob="dnb", reese="all", lead="rare",
               swing=0.03, template=T_DNB, scales=["minor", "phrygian"]),
    "Liquid DnB": _mk(core=["kick", "snare", "hat", "sub", "wobble", "reese", "pad"], extras=["epiano", "upright", "rim", "shaker", "crash", "riser", "pluck", "stab", "supersaw", "vox", "handpan", "panflute", "boom", "piano", "strings", "ride", "flute", "vibes", "choir", "cello", "bell", "openhat"],
                      bpm=174, kick=[[0, 10], [0, 10, 13]], snare=[4, 12], ghost=[(7, 36), (11, 32), (15, 42)], hat="16", wob="liquid", reese="all", lead="melodic",
                      swing=0.06, voices={"pad": 3}, template=T_DNB, progs=[[0, 5, 2, 6], [0, 3, 5, 6], [0, 2, 5, 6]], scales=["minor", "dorian"]),
    "Neurofunk": _mk(extras=["glitch", "hoover", "rim", "crash", "riser", "boom", "neuro", "fmbass", "hollow", "zap", "stab", "openhat", "ride"], bpm=174, kick=[[0, 10], [0, 6, 10, 14]], snare=[4, 12],
                     ghost=[(14, 50)], hat="16", wob="neurof", growl="neurof", reese="all", lead="accent", wob_div=[9, 10, 11], growl_div=[10, 11], template=T_DNB,
                     progs=[[0], [0, 0, 5, 6], [0, 1, 0, 6]], scales=["phrygian", "minor"]),
    # ---------------- space / ambient
    "Space Electronica": _mk(core=["kick", "hat", "sub", "wobble", "reese", "pad"], extras=["drone", "choir", "bell", "supersaw", "pluck", "handpan", "theremin", "panflute", "tongue", "riser", "boom", "vox", "shaker", "rim", "crash", "strings", "piano", "vibes", "flute", "marimba", "cello"],
                             bpm=108, kick=[[0, 8]], snare=[], hat="offbeat", wob="ambient", wob_div=[2, 3, 4], reese="all", lead="melodic", pad_mode="drop", melody="space",
                             arp=dict(step=2, pattern="updown", prob=0.9), voices={"pad": 2}, chord_len=4, template=T_AMB,
                             progs=[[0, 5, 2, 6], [0, 3, 0, 5], [0, 6, 5, 6]], scales=["minor", "dorian", "lydian"]),
    "Berlin School": _mk(core=["kick", "hat", "sub", "wobble", "reese", "pluck"], extras=["drone", "choir", "bell", "pad", "supersaw", "theremin", "handpan", "panflute", "riser", "boom", "stab", "shaker", "strings", "piano", "vibes", "marimba", "flute", "organ", "epiano"],
                         bpm=118, kick=[[0, 8]], snare=[], hat="offbeat", wob="seq", wob_div=[3, 4, 5], sub_mode="pulse8", reese="late", lead="melodic", pad_mode="drop",
                         melody="space", arp=dict(step=1, pattern="up", prob=1.0, phase=True), voices={"pluck": 2, "pad": 2}, chord_len=4, template=T_AMB,
                         progs=[[0, 5], [0, 0, 3, 3], [0, 5, 3, 4]], scales=["minor", "dorian", "phrygian"]),
    # ---------------- klasyka
    "Baroque": _mk(core=["sub", "piano"], extras=["harpsichord", "organ", "flute", "cello", "pluck", "pad", "panflute", "stab", "strings", "brass"], bpm=108, kick=NONE_KICK, snare=[], hat="none", wob="baroque", sub_mode="walk", lead="melodic",
                   melody="classic", arp=dict(step=2, pattern="updown", prob=0.95), pad_mode="drop", voices={"pluck": 2, "pad": 3, "stab": 2, "piano": 2}, chord_len=1, template=T_CLASSIC,
                   progs=[[0, 3, 4, 0], [0, 4, 5, 2, 3, 0, 3, 4], [0, 5, 3, 4], [1, 4, 0, 0]], scales=["major", "harmonic minor", "minor"]),
    "Romantic": _mk(core=["sub", "strings", "piano"], extras=["cello", "flute", "brass", "choir", "pad", "supersaw", "panflute", "theremin", "pluck", "handpan", "tom", "boom", "crash", "riser", "tongue", "bell"], bpm=72, kick=NONE_KICK, snare=[],
                    hat="none", wob="classic", sub_mode="hold", lead="melodic", melody="romantic", pad_mode="drop", voices={"pad": 3, "supersaw": 2, "strings": 2}, chord_len=2,
                    template=T_ROMANTIC, progs=[[0, 5, 2, 6], [0, 3, 4, 0], [0, 4, 5, 3], [5, 3, 4, 0]], scales=["harmonic minor", "minor", "major"]),
    "Minimal Classical": _mk(core=["sub", "piano"], extras=["marimba", "vibes", "bell", "pluck", "handpan", "pad", "panflute", "tongue", "theremin", "strings", "flute", "cello", "epiano"], bpm=116, kick=NONE_KICK, snare=[], hat="none", wob="minimal",
                             sub_mode="hold", lead="melodic", melody="classic", arp=dict(step=1, pattern="up", prob=1.0, phase=True), pad_mode="drop",
                             voices={"pluck": 2, "pad": 2, "piano": 2}, chord_len=2, template=T_MIN, progs=[[0, 5], [0, 3, 5, 4], [0, 2, 5, 4]], scales=["minor", "major", "dorian"]),
    # ---------------- jazz / fusion
    "Jazz": _mk(core=["kick", "snare", "hat", "sub", "piano"], extras=["epiano", "upright", "ride", "vibes", "rim", "stab", "pluck", "panflute", "handpan", "tongue", "theremin", "shaker", "strings", "pad", "brass", "flute", "conga", "organ", "marimba"], bpm=124,
                kick=[[0], [0, 8], [0, 6, 8], [0, 10]], snare=[], ghost=[(3, 50), (6, 46), (10, 52), (14, 56)], hat="ride", wob="funk", sub_mode="walk", lead="melodic",
                melody="jazz", swing8=0.12, voices={"stab": 3}, comp=[[0, 6], [3, 10], [6, 12], [2, 8, 14], [0, 10]], chord_len=1, template=T_JAZZ,
                progs=[[1, 4, 0, 0], [1, 4, 0, 5], [0, 5, 1, 4], [2, 5, 1, 4], [0, 3, 1, 4]], scales=["major", "dorian", "mixolydian"]),
    "Jazz Rock": _mk(core=["kick", "snare", "hat", "sub", "screech", "piano"], extras=["epiano", "organ", "brass", "upright", "conga", "rim", "stab", "pluck", "theremin", "panflute", "fmbass", "shaker", "crash", "riser", "hollow", "strings", "pad", "ride", "cowbell", "flute"],
                     bpm=112, kick=[[0, 6, 10], [0, 3, 10, 14], [0, 7, 10], [0, 10]], snare=[4, 12], ghost=[(3, 45), (7, 50), (10, 45), (15, 55)], hat="16", wob="funk",
                     sub_mode="funk", lead="melodic", melody="jazz", swing8=0.05, voices={"stab": 2}, comp=[[0, 6, 10], [3, 7, 14], [2, 6, 10, 14], [0, 3, 8, 11]],
                     template=T_FUSION, progs=[[0, 3, 0, 4], [0, 6, 5, 6], [0, 3, 6, 2], [0, 5, 3, 4]], scales=["dorian", "minor", "mixolydian"]),
    # ---------------- eksperyment
    "Experimental": _mk(extras=["glitch", "bell", "drone", "vibes", "zap", "riser", "boom", "theremin", "neuro", "fmbass", "vox", "tom", "rim", "shaker", "tongue", "handpan", "stab", "clap", "hollow", "crash", "acid", "piano", "strings", "marimba", "hoover", "openhat", "choir", "cowbell", "conga", "bass808", "harpsichord", "flute", "organ", "brass"],
                        bpm=118, kick=[[0, 7, 11], [0, 5], [3, 9, 14], [0, 4, 13]], snare=[6, 13], ghost=[(2, 40), (9, 44), (11, 40)], hat="16", wob="exp", growl="exp",
                        reese="late", lead="accent", chord_len=1, swing=0.05, swing8=0.07, template=T_EXP, mutate=dict(drop=0.22, jitter=0.30, octave=0.12, shift=0.35),
                        progs=[[0, 1, 6, 3], [0, 6, 1, 5]], scales=["phrygian", "harmonic minor"]),
    "Raw Synthesis": _mk(core=["kick", "snare", "hat", "sub", "wobble", "reese", "screech"], extras=["glitch", "hoover", "zap", "riser", "boom", "fmbass", "neuro", "hollow", "pluck", "stab", "theremin", "tom", "rim", "shaker", "supersaw", "organ", "bass808", "drone", "openhat", "cowbell", "bell"], bpm=126,
                         kick=[[0, 8], [0, 6, 10]], snare=[12], hat="16", wob="raw", sub_mode="pulse8", reese="late", lead="rare", mutate=dict(drop=0.10, jitter=0.15, octave=0.10, shift=0.15),
                         progs=[[0], [0, 5], [0, 0, 3, 4]], scales=["minor", "phrygian", "dorian"]),
}

# ------------------------------------------------------------------ biblioteki wzorów basu (dopisywane do generator.WOB / GROWL)
_roll = [(1, "r", 1), (2, "r", 1), (3, "o", 1), (5, "r", 1), (6, "r", 1), (7, "o", 1), (9, "r", 1), (10, "f", 1), (11, "o", 1), (13, "r", 1), (14, "r", 1), (15, "o", 1)]
WOB_NEW = {
    "techno": [[(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "r", 2)], [(2, "r", 2), (6, "r", 2), (10, "r", 1), (11, "o", 1), (14, "r", 2)], [(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "f", 2)]],
    "acid": [[(0, "r", 1), (2, "r", 1), (3, "o", 1), (5, "r", 1), (6, "b", 1), (8, "r", 1), (10, "f", 1), (11, "r", 1), (13, "o", 1), (14, "r", 1)],
             [(0, "r", 2), (3, "r", 1), (4, "o", 1), (6, "r", 1), (8, "b", 2), (11, "r", 1), (12, "f", 1), (14, "o", 1)],
             [(0, "r", 1), (1, "r", 1), (3, "o", 1), (4, "r", 1), (7, "t", 1), (8, "r", 1), (10, "o", 1), (12, "r", 1), (13, "b", 1), (15, "r", 1)]],
    "hard": [[(s, "r", 1) for s in (2, 3, 6, 7, 10, 11, 14, 15)], [(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "o", 2)]],
    "roll": [_roll, [(s, ("o" if s % 4 == 3 else "r"), 1) for s in (1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15)]],
    "psy": [_roll, [(s, ("b" if s in (7, 15) else "o" if s % 4 == 3 else "r"), 1) for s in (1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15)]],
    "electro": [[(0, "r", 1), (3, "r", 1), (6, "o", 1), (8, "r", 1), (11, "f", 1), (14, "r", 1)], [(0, "r", 2), (5, "r", 1), (8, "t", 1), (10, "r", 1), (13, "o", 1)],
                [(0, "r", 1), (2, "r", 1), (6, "f", 1), (8, "r", 1), (10, "r", 1), (12, "o", 2)]],
    "dnb": [[(0, "r", 6), (6, "t", 2), (8, "r", 4), (12, "f", 4)], [(0, "r", 3), (3, "r", 3), (6, "o", 2), (8, "r", 8)], [(0, "r", 2), (2, "r", 2), (4, "f", 4), (8, "r", 2), (10, "b", 2), (12, "r", 4)],
            [(0, "r", 10), (10, "t", 2), (12, "f", 4)]],
    "liquid": [[(0, "r", 6), (8, "f", 4), (12, "t", 4)], [(0, "r", 4), (6, "r", 2), (8, "t", 8)], [(0, "r", 3), (4, "f", 4), (10, "r", 6)]],
    "neurof": [[(0, "r", 2), (2, "r", 1), (3, "o", 1), (4, "r", 2), (6, "t", 2), (8, "r", 2), (10, "f", 2), (12, "b", 2), (14, "r", 2)],
               [(0, "r", 3), (3, "r", 1), (4, "f", 2), (6, "o", 2), (8, "r", 3), (11, "r", 1), (12, "t", 4)], [(0, "r", 1), (1, "r", 1), (2, "o", 2), (4, "r", 4), (8, "b", 2), (10, "r", 2), (12, "f", 4)]],
    "ambient": [[(0, "r", 16)], [(0, "r", 8), (8, "f", 8)], [(0, "r", 12), (12, "t", 4)]],
    "seq": [[(s, t, 2) for s, t in zip(range(0, 16, 2), ("r", "r", "o", "r", "f", "r", "o", "t"))], [(s, t, 2) for s, t in zip(range(0, 16, 2), ("r", "f", "r", "o", "r", "t", "f", "r"))]],
    "house": [[(0, "r", 2), (3, "r", 1), (6, "f", 2), (10, "r", 2), (13, "o", 1)], [(0, "r", 3), (4, "t", 2), (8, "r", 2), (10, "f", 2), (14, "o", 2)], [(2, "r", 2), (6, "r", 2), (8, "f", 2), (12, "r", 2)]],
    "funk": [[(0, "r", 1), (3, "r", 1), (6, "o", 1), (8, "r", 1), (10, "f", 1), (12, "r", 2), (15, "b", 1)], [(0, "r", 2), (3, "o", 1), (5, "r", 1), (8, "t", 1), (10, "r", 1), (13, "f", 1), (14, "b", 2)],
             [(0, "r", 1), (2, "r", 1), (4, "o", 1), (7, "r", 1), (8, "f", 2), (11, "t", 1), (12, "r", 2)]],
    "baroque": [[(0, "r", 4), (4, "f", 4), (8, "o", 4), (12, "f", 4)], [(0, "r", 4), (4, "t", 4), (8, "f", 4), (12, "t", 4)],
                [(0, "r", 2), (2, "t", 2), (4, "f", 2), (6, "t", 2), (8, "o", 2), (10, "f", 2), (12, "t", 2), (14, "f", 2)]],
    "classic": [[(0, "r", 16)], [(0, "r", 8), (8, "f", 8)], [(0, "r", 4), (4, "f", 4), (8, "t", 4), (12, "f", 4)]],
    "minimal": [[(0, "r", 2), (2, "f", 2), (4, "o", 2), (6, "f", 2), (8, "r", 2), (10, "f", 2), (12, "o", 2), (14, "f", 2)]],
    "exp": [[(0, "r", 1), (3, "b", 1), (5, "o", 2), (9, "f", 1), (11, "u", 1), (14, "t", 2)], [(0, "r", 5), (5, "u", 3), (10, "b", 1), (13, "o", 3)], [(1, "r", 1), (2, "r", 1), (6, "p", 2), (7, "r", 1), (12, "b", 4)]],
    "raw": [[(0, "r", 1), (2, "r", 1), (4, "o", 1), (6, "r", 1), (8, "f", 1), (10, "r", 1), (12, "b", 1), (14, "o", 1)],
            [(0, "r", 2), (2, "o", 1), (4, "r", 2), (6, "f", 1), (8, "r", 2), (10, "o", 1), (12, "t", 2), (14, "u", 1)],
            [(0, "r", 1), (1, "r", 1), (2, "o", 1), (3, "r", 1), (4, "f", 1), (5, "r", 1), (6, "b", 1), (7, "r", 1)]],
}
GROWL_NEW = {
    "neurof": [[(8, "r", 2), (10, "o", 1), (11, "t", 1), (12, "f", 2), (14, "r", 2)]],
    "exp": [[(4, "o", 2), (10, "u", 2)], [(2, "b", 1), (9, "o", 3)]],
}

# ------------------------------------------------------------------ rytmika linii melodycznych (panflute / theremin)
MEL_RHY = {
    "classic": [[(0, 4), (4, 4), (8, 4), (12, 4)], [(0, 6), (6, 2), (8, 4), (12, 4)], [(0, 2), (2, 2), (4, 4), (8, 2), (10, 2), (12, 4)], [(0, 4), (4, 2), (6, 2), (8, 8)],
                [(0, 2), (2, 2), (4, 2), (6, 2), (8, 2), (10, 2), (12, 4)]],
    "romantic": [[(0, 8), (8, 8)], [(0, 6), (6, 2), (8, 8)], [(0, 4), (4, 4), (8, 8)], [(0, 12), (12, 4)]],
    "jazz": [[(0, 3), (3, 3), (6, 2), (8, 2), (10, 2), (12, 4)], [(2, 2), (4, 2), (6, 2), (8, 4), (12, 2), (14, 2)], [(0, 2), (2, 2), (4, 4), (8, 2), (10, 3), (13, 3)],
             [(0, 6), (6, 2), (8, 2), (10, 2), (12, 2), (14, 2)]],
    "space": [[(0, 16)], [(0, 8), (8, 8)], [(0, 6), (6, 10)]],
}

# ------------------------------------------------------------------ brzmienie wg stylu (parametr, 'r', lo, hi) | (parametr, 'c', [wybór]) — jak SOUND_STYLE w generator.py
SOUND_STYLE_NEW = {
    "Techno": {"kick": [("Decay", "r", 140, 240), ("Drive", "r", 0.3, 0.6)], "hat": [("Decay", "r", 20, 60)], "sub": [("Glide", "r", 0, 15)]},
    "Acid Techno": {"wobble": [("Resonance", "r", 0.55, 0.8), ("Cutoff", "r", 400, 1200), ("Drive", "r", 0.4, 0.7), ("Glide", "r", 40, 110)], "kick": [("Decay", "r", 140, 230)]},
    "Hard Techno": {"kick": [("Decay", "r", 100, 180), ("Drive", "r", 0.5, 0.85), ("Pitch Env Amt", "r", 30, 50)], "wobble": [("Drive", "r", 0.6, 0.9)], "hat": [("Decay", "r", 18, 45)]},
    "Techno Trax": {"kick": [("Decay", "r", 160, 260)], "stab": [("Drive", "r", 0.3, 0.6)], "zap": [("Decay", "r", 300, 700)]},
    "Tunnel Trance": {"supersaw": [("Attack", "r", 5, 20), ("Release", "r", 100, 260), ("Cutoff", "r", 6000, 12000)], "kick": [("Decay", "r", 180, 300)], "sub": [("Glide", "r", 0, 10)]},
    "Trance": {"supersaw": [("Unison Detune", "r", 25, 50), ("Release", "r", 400, 1000)], "pluck": [("Decay", "r", 120, 300)], "kick": [("Decay", "r", 180, 300)]},
    "Psytrance": {"kick": [("Decay", "r", 140, 220), ("Pitch Env Amt", "r", 28, 44)], "sub": [("Glide", "r", 0, 10), ("Drive", "r", 0.2, 0.5)], "fmbass": [("FM Amount", "r", 0.4, 0.8)]},
    "House": {"kick": [("Decay", "r", 200, 320), ("Drive", "r", 0.15, 0.4)], "clap": [("Noise Decay", "r", 150, 260)], "hat": [("Decay", "r", 35, 90)], "sub": [("Glide", "r", 10, 40)]},
    "Electro": {"kick": [("Decay", "r", 160, 280)], "snare": [("Decay", "r", 110, 220)], "hat": [("Decay", "r", 20, 50)], "sub": [("Glide", "r", 0, 20)]},
    "DnB": {"kick": [("Decay", "r", 80, 160)], "snare": [("Decay", "r", 100, 180), ("Tune", "r", 0, 4)], "hat": [("Decay", "r", 15, 45)], "sub": [("Glide", "r", 0, 10)],
            "reese": [("Cutoff", "r", 900, 2600)]},
    "Liquid DnB": {"kick": [("Decay", "r", 120, 220), ("Drive", "r", 0.1, 0.3)], "snare": [("Decay", "r", 140, 240), ("Drive", "r", 0.1, 0.3)], "hat": [("Decay", "r", 20, 50)],
                   "reese": [("Drive", "r", 0.2, 0.45), ("Cutoff", "r", 1200, 2500)]},
    "Neurofunk": {"kick": [("Decay", "r", 80, 140)], "neuro": [("Drive", "r", 0.75, 0.98)], "reese": [("Drive", "r", 0.55, 0.85)]},
    "Space Electronica": {"kick": [("Decay", "r", 250, 420), ("Drive", "r", 0.05, 0.2)], "hat": [("Decay", "r", 40, 90), ("Noise", "r", 0.1, 0.3)],
                          "pad": [("Attack", "r", 1200, 2600), ("Release", "r", 1800, 3500), ("Cutoff", "r", 1200, 2800)], "sub": [("Glide", "r", 40, 120), ("Sub Osc", "r", 0.0, 0.1)]},
    "Berlin School": {"pluck": [("Decay", "r", 80, 200), ("Cutoff", "r", 1200, 3500), ("Filter Env Amt", "r", 1.5, 3.5)], "pad": [("Attack", "r", 800, 2000)]},
    "Baroque": {"pluck": [("Decay", "r", 120, 260), ("Cutoff", "r", 1500, 3500), ("Waveform", "c", [2, 3]), ("Resonance", "r", 0.05, 0.2)],
                "pad": [("Attack", "r", 80, 300), ("Release", "r", 400, 900)], "panflute": [("Attack", "r", 30, 90)], "sub": [("Cutoff", "r", 600, 1800), ("Glide", "r", 0, 10)]},
    "Romantic": {"pad": [("Attack", "r", 600, 1600), ("Release", "r", 1400, 3200), ("Wave Morph", "r", 0.1, 0.4)],
                 "supersaw": [("Attack", "r", 150, 500), ("Release", "r", 800, 2200), ("Unison Detune", "r", 8, 22), ("Cutoff", "r", 3500, 8000)],
                 "sub": [("Glide", "r", 0, 30), ("Cutoff", "r", 500, 1200)], "tom": [("Decay", "r", 400, 700)]},
    "Minimal Classical": {"pluck": [("Decay", "r", 80, 180)], "handpan": [("Ring Time", "r", 800, 1800)], "pad": [("Attack", "r", 300, 900)]},
    "Jazz": {"kick": [("Decay", "r", 80, 150), ("Drive", "r", 0.0, 0.15), ("Pitch Env Amt", "r", 10, 24)], "snare": [("Decay", "r", 60, 120), ("Noise", "r", 0.4, 0.7), ("Drive", "r", 0.0, 0.2)],
             "hat": [("Decay", "r", 40, 100), ("Noise", "r", 0.4, 0.7)], "sub": [("Waveform", "c", [0]), ("Glide", "r", 0, 25), ("Cutoff", "r", 500, 1000), ("Sub Osc", "r", 0.05, 0.2)],
             "stab": [("Decay", "r", 150, 350), ("Cutoff", "r", 1500, 3000), ("Drive", "r", 0.0, 0.2)], "pluck": [("Decay", "r", 250, 600), ("Cutoff", "r", 1500, 3000)]},
    "Jazz Rock": {"kick": [("Decay", "r", 100, 200), ("Drive", "r", 0.2, 0.4)], "snare": [("Decay", "r", 110, 190)], "sub": [("Drive", "r", 0.15, 0.4), ("Glide", "r", 0, 30)],
                  "screech": [("Cutoff", "r", 3000, 7000), ("Drive", "r", 0.2, 0.45), ("FM Amount", "r", 0.2, 0.5)], "stab": [("Decay", "r", 120, 260)]},
    "Raw Synthesis": {"wobble": [("Drive", "r", 0.0, 0.25), ("Resonance", "r", 0.5, 0.85)], "sub": [("Drive", "r", 0.0, 0.1)], "kick": [("Noise", "r", 0.0, 0.1)], "hat": [("Noise", "r", 0.6, 0.9)]},
}

STYLE_THEME_NEW = {"Techno": "Dark", "Acid Techno": "Dark", "Hard Techno": "Dark", "Electro": "Hype", "DnB": "Hype", "Liquid DnB": "Dubstep", "Neurofunk": "Dark",
                   "Space Electronica": "Countdown", "Berlin School": "Countdown", "Techno Trax": "Hype", "Tunnel Trance": "Hype", "Trance": "Hype", "Psytrance": "Dark",
                   "House": "Hype", "Baroque": "Dark", "Romantic": "Dark", "Minimal Classical": "Countdown", "Jazz": "Hype", "Jazz Rock": "Hype",
                   "Experimental": "Dark", "Raw Synthesis": "Countdown"}

# „klasa" ostrości/tempa 0 (najspokojniejszy) … 5 (najostrzejszy): waży losowanie stylu wg pory dnia w trybie Live
STYLE_CLASS = {"Brostep": 3.0, "Riddim": 3.0, "Tearout": 5.0, "Melodic": 1.0, "Deep": 0.0, "Dubstep": 2.0, "Drumstep": 4.0, "Trap": 2.0, "EDM": 3.5,
               "Techno": 3.0, "Acid Techno": 3.5, "Hard Techno": 4.5, "Techno Trax": 4.0, "Tunnel Trance": 4.0, "Trance": 3.0, "Psytrance": 4.5, "House": 2.0,
               "Electro": 2.5, "DnB": 3.5, "Liquid DnB": 1.5, "Neurofunk": 4.0, "Space Electronica": 0.0, "Berlin School": 0.5, "Baroque": 0.5, "Romantic": 0.0,
               "Minimal Classical": 0.5, "Jazz": 0.5, "Jazz Rock": 2.0, "Experimental": 2.5, "Raw Synthesis": 3.0}

# ------------------------------------------------------------------ kolejność i grupy (pole szachowe) + kolory
GROUPS = [("Dubstep", ["Brostep", "Riddim", "Tearout", "Melodic", "Deep", "Dubstep", "Drumstep", "Trap", "EDM"]),
          ("Techno / House", ["Techno", "Acid Techno", "Hard Techno", "House", "Electro"]),
          ("Trance", ["Techno Trax", "Tunnel Trance", "Trance", "Psytrance"]),
          ("Drum & Bass", ["DnB", "Liquid DnB", "Neurofunk"]),
          ("Space / ambient", ["Space Electronica", "Berlin School"]),
          ("Klasyka / jazz", ["Baroque", "Romantic", "Minimal Classical", "Jazz", "Jazz Rock"]),
          ("Eksperyment", ["Experimental", "Raw Synthesis"])]
ORDER = [s for _, ss in GROUPS for s in ss]
STYLE_COL = {"Brostep": "#e5484d", "Riddim": "#f5a524", "Tearout": "#ff6b3d", "Melodic": "#c4b5fd", "Deep": "#2dd4bf", "Dubstep": "#60a5fa", "Drumstep": "#34d399",
             "Trap": "#e879f9", "EDM": "#facc15", "Techno": "#94a3b8", "Acid Techno": "#a3e635", "Hard Techno": "#64748b", "House": "#fb923c", "Electro": "#22d3ee",
             "Techno Trax": "#f472b6", "Tunnel Trance": "#818cf8", "Trance": "#a78bfa", "Psytrance": "#4ade80", "DnB": "#ef4444", "Liquid DnB": "#38bdf8", "Neurofunk": "#84cc16",
             "Space Electronica": "#6366f1", "Berlin School": "#0ea5e9", "Baroque": "#d6a86b", "Romantic": "#e11d48", "Minimal Classical": "#cbd5e1", "Jazz": "#f59e0b",
             "Jazz Rock": "#b45309", "Experimental": "#f43f5e", "Raw Synthesis": "#14b8a6"}

# ------------------------------------------------------------------ hybrydy
_PART = re.compile(r"^(.+?) (\d{1,3})%$")


def parse_hybrid(name, pure):
    """„A 60% + B 40%" -> {"A": .6, "B": .4}; None gdy to nie hybryda albo składnik nieznany. pure = słownik czystych stylów."""
    if not isinstance(name, str) or "%" not in name:
        return None
    out = {}
    for part in name.split(" + "):
        m = _PART.match(part.strip())
        if not m or not dict.__contains__(pure, m.group(1)):
            return None
        out[m.group(1)] = out.get(m.group(1), 0.0) + int(m.group(2))
    tot = sum(out.values())
    return {k: v / tot for k, v in out.items()} if tot > 0 else None


def hybrid_name(weights, min_share=0.04):
    """Słownik wag -> nazwa stylu (pojedynczy składnik = czysty styl). Procenty zaokrąglone do 100 metodą największych reszt."""
    w = {k: v for k, v in weights.items() if v > 0}
    tot = sum(w.values())
    if not tot:
        return None
    w = {k: v / tot for k, v in w.items() if v / tot >= min_share}
    tot = sum(w.values()); w = {k: v / tot for k, v in w.items()}
    if len(w) == 1:
        return next(iter(w))
    raw = {k: v * 100 for k, v in w.items()}; pct = {k: int(v) for k, v in raw.items()}
    for k in sorted(raw, key=lambda k: raw[k] - pct[k], reverse=True)[:100 - sum(pct.values())]:
        pct[k] += 1
    order = sorted(pct, key=lambda k: (-pct[k], k))
    return " + ".join(f"{k} {pct[k]}%" for k in order if pct[k] > 0)


def blend(pure, parts, name):
    """Składa konfigurację hybrydy. Wzory dzielone są na „aspekty" (rytm / bas / harmonia / struktura): każdy aspekt pochodzi od jednego ze składników,
    wybranego losowo z prawdopodobieństwem równym wadze (deterministycznie wg nazwy), więc mutacja widocznie zmienia charakter, a nie tylko uśrednia liczby."""
    names = sorted(parts, key=lambda n: (-parts[n], n)); tot = sum(parts.values()); w = {n: parts[n] / tot for n in names}
    cf = {n: dict.__getitem__(pure, n) for n in names}; D = names[0]

    def pick(salt):
        r = random.Random(f"hyb:{name}:{salt}").uniform(0, 1); acc = 0.0
        for n in names:
            acc += w[n]
            if r <= acc:
                return n
        return D

    ref = cf[D]["bpm"]; adj = 0.0                     # tempo: uśrednione po złożeniu oktaw (174 ≈ 2×87), żeby DnB nie ciągnęło połowy tempa
    for n in names:
        b = float(cf[n]["bpm"])
        while b > ref * 1.4:
            b /= 2
        while b < ref / 1.4:
            b *= 2
        adj += b * w[n]
    out = dict(bpm=int(round(adj)), parts={n: round(w[n], 4) for n in names})
    out["swing"] = round(sum(cf[n].get("swing", 0.0) * w[n] for n in names), 4)
    out["swing8"] = round(sum(cf[n].get("swing8", 0.0) * w[n] for n in names), 4)

    R, B, H, S = pick("rhythm"), pick("bass"), pick("harmony"), pick("structure")
    for k in ("hat", "snare", "ghost", "fourfloor"):
        if k in cf[R]:
            out[k] = cf[R][k]
    pools = []                                          # stopa: pule wszystkich składników bez four-on-the-floor w proporcji do wag (lub pula R gdy R = four-on-the-floor)
    if cf[R].get("fourfloor"):
        pools = [list(p) for p in cf[R]["kick"]]
    else:
        for n in names:
            if not cf[n].get("fourfloor"):
                pools += [list(p) for p in cf[n]["kick"]] * max(1, round(w[n] * 5))
        pools = pools or [list(p) for p in cf[R]["kick"]]
    out["kick"] = pools
    for k in ("wob", "growl", "reese", "sub_mode", "wob_div", "growl_div"):
        if k in cf[B]:
            out[k] = cf[B][k]
    for k in ("lead", "chord_len", "comp", "arp", "gate", "pad_mode", "melody", "scales"):
        if k in cf[H]:
            out[k] = cf[H][k]
    progs = []
    for n in names:
        progs += [list(p) for p in cf[n].get("progs", [])] * max(1, round(w[n] * 4)) if cf[n].get("progs") else []
    if progs:
        out["progs"] = progs
    out["template"] = cf[S]["template"]
    extras, core, voices = [], [], {}
    for n in names:                                     # unia dodatków (próg 12 %), podstawy (25 %), głosów (25 %)
        if w[n] >= 0.12:
            extras += [t for t in cf[n].get("extras", []) if t not in extras]
        if w[n] >= 0.25:
            core += [t for t in cf[n].get("core", ["kick", "snare", "hat", "sub", "wobble", "reese", "growl", "screech"]) if t not in core]
            for t, c in cf[n].get("voices", {}).items():
                voices[t] = max(voices.get(t, 0), c)
    if not core:                                        # np. 5 składników po 20 % — podstawa od składnika dominującego
        core = list(cf[D].get("core", ["kick", "snare", "hat", "sub", "wobble", "reese", "growl", "screech"]))
    out["core"] = core; out["extras"] = [t for t in extras if t not in core]
    if voices:
        out["voices"] = voices
    mu = {k: sum(cf[n].get("mutate", {}).get(k, 0.0) * w[n] for n in names) for k in ("drop", "jitter", "octave", "shift")}
    if any(v > 0.02 for v in mu.values()):
        out["mutate"] = {k: round(v, 3) for k, v in mu.items()}
    for k in ("hat", "wob", "growl", "reese", "lead", "chord_len", "wob_div", "growl_div", "template", "kick", "snare"):
        out.setdefault(k, cf[D].get(k))
    if out.get("snare") is None:
        out.pop("snare", None)
    return out


class StyleDict(dict):
    """Słownik stylów: czyste style jako zwykłe klucze, hybrydy („A 60% + B 40%") składane na żądanie i trzymane w osobnej pamięci
    (nie pojawiają się w iteracji, więc nie trafiają na listy losowania)."""

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self._hyb = {}

    def __missing__(self, name):
        if name in self._hyb:
            return self._hyb[name]
        parts = parse_hybrid(name, self)
        if not parts:
            raise KeyError(name)
        self._hyb[name] = blend(self, parts, name)
        return self._hyb[name]

    def __contains__(self, name):
        return dict.__contains__(self, name) or parse_hybrid(name, self) is not None

    def get(self, name, default=None):
        try:
            return self[name]
        except KeyError:
            return default

    def parts(self, name):
        """{czysty styl: waga} dla czystego stylu i hybrydy."""
        if dict.__contains__(self, name):
            return {name: 1.0}
        return parse_hybrid(name, self) or {name: 1.0}


# ------------------------------------------------------------------ pole szachowe: komórki -> receptura
def board_weights(cells, strength):
    """cells: [(baza, mutacja, poziom 1..3)]; strength 0..1 = udział mutacji. Baza (lewa oś) daje szkielet, mutacje (górna oś) — dodatki;
    komórka na przekątnej (A, A) = czysty A po obu stronach. Wiele komórek = hybryda wielokrotna."""
    base, mut = {}, {}
    for b, m, lv in cells:
        base[b] = base.get(b, 0) + lv; mut[m] = mut.get(m, 0) + lv
    if not base:
        return {}
    sb, sm = sum(base.values()), sum(mut.values()); out = {}
    for k, v in base.items():
        out[k] = out.get(k, 0.0) + (1 - strength) * v / sb
    for k, v in mut.items():
        out[k] = out.get(k, 0.0) + strength * v / sm
    return out


def board_name(cells, strength):
    return hybrid_name(board_weights(cells, strength))


def color_of(name, pure=None):
    """Kolor stylu; dla hybrydy — mieszanka kolorów składników wg wag."""
    if name in STYLE_COL:
        return STYLE_COL[name]
    parts = parse_hybrid(name, pure if pure is not None else STYLE_COL) if "%" in str(name) else None
    if not parts:
        return "#9ca3af"
    r = g = b = 0.0
    for n, wt in parts.items():
        c = STYLE_COL.get(n, "#9ca3af"); r += int(c[1:3], 16) * wt; g += int(c[3:5], 16) * wt; b += int(c[5:7], 16) * wt
    return "#%02x%02x%02x" % (int(r), int(g), int(b))


# ------------------------------------------------------------------ style użytkownika (kreator GUI)
import json
import os
from pathlib import Path as _Path


def custom_styles_path() -> _Path:
    return _Path(os.environ["DS_CUSTOM_STYLES"]) if os.environ.get("DS_CUSTOM_STYLES") else _Path.home() / "DubstepStudio" / "custom_styles.json"


def load_custom_styles() -> dict:
    """{nazwa: cfg} z pliku użytkownika."""
    p = custom_styles_path()
    if not p.exists():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_custom_style(name: str, cfg: dict):
    d = load_custom_styles()
    d[name] = cfg
    p = custom_styles_path(); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def delete_custom_style(name: str):
    d = load_custom_styles()
    if name in d:
        del d[name]
        p = custom_styles_path(); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def register_custom_styles(styles_dict):
    """Wstawia style użytkownika do StyleDict (nadpisuje nazwę jeśli koliduje z wbudowanym — ostrożnie)."""
    for name, cfg in load_custom_styles().items():
        if not isinstance(cfg, dict):
            continue
        styles_dict[name] = cfg
        if name not in ORDER:
            ORDER.append(name)
        STYLE_CLASS.setdefault(name, float(cfg.get("_class", 2.5)))
        STYLE_COL.setdefault(name, cfg.get("_color", "#9ca3af"))


def style_knobs_from(cfg: dict) -> dict:
    """Uproszczony widok suwaków kreatora z pełnej konfiguracji stylu."""
    return {
        "bpm": int(cfg.get("bpm", 140)),
        "swing": float(cfg.get("swing", 0.0)),
        "hat": cfg.get("hat", "offbeat"),
        "wob": cfg.get("wob", "brostep"),
        "growl": cfg.get("growl", "brostep"),
        "reese": cfg.get("reese", "late"),
        "lead": cfg.get("lead", "accent"),
        "sub_mode": cfg.get("sub_mode", "hold"),
        "chord_len": int(cfg.get("chord_len", 2)),
        "core": list(cfg.get("core") or ["kick", "snare", "hat", "sub", "wobble", "reese", "growl", "screech"]),
        "extras": list(cfg.get("extras") or []),
        "wob_div": list(cfg.get("wob_div") or [8, 9]),
        "growl_div": list(cfg.get("growl_div") or [5]),
        "scales": list(cfg.get("scales") or ["minor"]),
        "template": [list(x) for x in cfg.get("template") or [("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("outro", 16)]],
        "_class": float(cfg.get("_class", 2.5)),
        "_color": cfg.get("_color", "#9ca3af"),
    }


def build_style_cfg(knobs: dict, base_cfg: dict | None = None) -> dict:
    """Składa pełny cfg stylu z pokręteł kreatora (+ opcjonalna baza)."""
    out = dict(base_cfg) if base_cfg else _mk()
    out["bpm"] = int(knobs.get("bpm", out.get("bpm", 140)))
    out["swing"] = float(knobs.get("swing", out.get("swing", 0.0)))
    for k in ("hat", "wob", "growl", "reese", "lead", "sub_mode"):
        if k in knobs and knobs[k] is not None:
            out[k] = knobs[k]
    out["chord_len"] = int(knobs.get("chord_len", out.get("chord_len", 2)))
    out["core"] = list(knobs.get("core") or out.get("core") or [])
    out["extras"] = [t for t in (knobs.get("extras") or out.get("extras") or []) if t not in out["core"]]
    out["wob_div"] = list(knobs.get("wob_div") or out.get("wob_div") or [8])
    out["growl_div"] = list(knobs.get("growl_div") or out.get("growl_div") or [5])
    if knobs.get("scales"):
        out["scales"] = list(knobs["scales"])
    if knobs.get("template"):
        out["template"] = [(a, int(b)) for a, b in knobs["template"]]
    out["_class"] = float(knobs.get("_class", out.get("_class", 2.5)))
    out["_color"] = knobs.get("_color", out.get("_color", "#9ca3af"))
    return out


def randomize_style_knobs(base_name: str, pure: dict, rng=None) -> dict:
    """Losuje pokrętła wokół stylu bazowego (wstępna randomizacja kreatora)."""
    import random as _r
    rng = rng or _r.Random()
    cfg = dict(pure[base_name]) if base_name in pure else _mk()
    k = style_knobs_from(cfg)
    k["bpm"] = int(max(70, min(180, k["bpm"] + rng.randint(-12, 12))))
    k["swing"] = round(max(0.0, min(0.15, k["swing"] + rng.uniform(-0.03, 0.04))), 3)
    hats = ["16", "8", "trap", "offbeat", "off", "ride", "none"]
    k["hat"] = rng.choice(hats)
    for key, pool in (("wob", ["brostep", "riddim", "tearout", "melodic", "deep", "techno", "hard", "acid", "roll", "ambient"]),
                      ("growl", ["brostep", "riddim", "tearout", "melodic", "deep", "neurof"]),
                      ("reese", ["none", "late", "all"]),
                      ("lead", ["none", "rare", "accent", "melodic"]),
                      ("sub_mode", ["hold", "offbeat", "roll", "pulse8", "funk", "walk", "off"])):
        if rng.random() < 0.55:
            k[key] = rng.choice(pool)
    k["chord_len"] = rng.choice([1, 2, 2, 4])
    # core/extras: mieszaj z puli
    all_t = ["kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker",
             "sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow",
             "screech", "supersaw", "pluck", "pad", "stab", "vox", "riser", "boom", "zap"]
    core_n = rng.randint(4, 8)
    k["core"] = rng.sample(all_t, core_n)
    if "kick" not in k["core"] and rng.random() < 0.85:
        k["core"].insert(0, "kick")
    rest = [t for t in all_t if t not in k["core"]]
    k["extras"] = rng.sample(rest, rng.randint(2, min(8, len(rest))))
    k["wob_div"] = sorted(rng.sample(range(2, 13), rng.randint(1, 3)))
    k["growl_div"] = sorted(rng.sample(range(4, 12), rng.randint(1, 2)))
    k["_class"] = round(rng.uniform(0.0, 5.0), 1)
    return k


# ================================================================== SCENY STYLU
# Komplet ustawień GUI/generatora charakterystycznych dla gatunku (i hybryd).
# Sam cfg stylu (bpm/hat/wob…) to „jak grać”; scena to „jak ustawić studio”.
# Pola sceny mapują się 1:1 na suwaki / checkboxy Generatora.

# jawne nadpisania (reszta stylów = heurystyka z STYLE_CLASS + cfg)
_SCENE_OVERRIDES = {
    "Brostep": dict(energy=0.82, density=0.68, spectacle="vivid", era="modern_10s", character="dark",
                    niuanse=True, niuanse_strength=0.25, uniq=True, uniq_strength=0.55, director_mood=-0.25),
    "Riddim": dict(energy=0.78, density=0.72, spectacle="vivid", era="modern_10s", character="restrained",
                   niuanse=True, niuanse_strength=0.15, uniq=True, uniq_strength=0.5, director_mood=-0.35),
    "Tearout": dict(energy=0.95, density=0.8, spectacle="anthem", era="maximal_now", character="dark",
                    niuanse=True, niuanse_strength=0.35, uniq=True, uniq_strength=0.65, director_mood=-0.6),
    "Melodic": dict(energy=0.62, density=0.55, spectacle="balanced", era="modern_10s", character="optimistic",
                    niuanse=True, niuanse_strength=0.4, uniq=True, uniq_strength=0.5, director_mood=0.35),
    "Deep": dict(energy=0.42, density=0.4, spectacle="plain", era="analog_80s", character="restrained",
                 niuanse=True, niuanse_strength=0.2, uniq=False, uniq_strength=0.35, director_mood=-0.15),
    "Neurofunk": dict(energy=0.88, density=0.75, spectacle="vivid", era="maximal_now", character="dark",
                      niuanse=True, niuanse_strength=0.3, uniq=True, uniq_strength=0.6, director_mood=-0.55),
    "Liquid DnB": dict(energy=0.55, density=0.5, spectacle="balanced", era="modern_10s", character="optimistic",
                       niuanse=True, niuanse_strength=0.35, uniq=True, uniq_strength=0.45, director_mood=0.25),
    "DnB": dict(energy=0.8, density=0.7, spectacle="vivid", era="modern_10s", character="balanced",
                niuanse=True, niuanse_strength=0.25, uniq=True, uniq_strength=0.55, director_mood=-0.1),
    "Techno": dict(energy=0.75, density=0.72, spectacle="balanced", era="digital_90s", character="restrained",
                   niuanse=False, niuanse_strength=0.1, uniq=True, uniq_strength=0.4, director_mood=-0.3),
    "Hard Techno": dict(energy=0.9, density=0.82, spectacle="vivid", era="maximal_now", character="dark",
                        niuanse=True, niuanse_strength=0.2, uniq=True, uniq_strength=0.55, director_mood=-0.5),
    "Acid Techno": dict(energy=0.8, density=0.75, spectacle="vivid", era="digital_90s", character="dark",
                        niuanse=True, niuanse_strength=0.25, uniq=True, uniq_strength=0.5, director_mood=-0.4),
    "Trance": dict(energy=0.78, density=0.65, spectacle="anthem", era="modern_10s", character="optimistic",
                   niuanse=True, niuanse_strength=0.45, uniq=True, uniq_strength=0.5, director_mood=0.45),
    "Psytrance": dict(energy=0.88, density=0.8, spectacle="anthem", era="maximal_now", character="very_optimistic",
                      niuanse=True, niuanse_strength=0.4, uniq=True, uniq_strength=0.6, director_mood=0.55),
    "House": dict(energy=0.68, density=0.6, spectacle="balanced", era="digital_90s", character="optimistic",
                  niuanse=True, niuanse_strength=0.2, uniq=False, uniq_strength=0.35, director_mood=0.3),
    "Space Electronica": dict(energy=0.35, density=0.35, spectacle="plain", era="minimal_70s", character="restrained",
                              niuanse=True, niuanse_strength=0.3, uniq=True, uniq_strength=0.4, director_mood=0.0),
    "Berlin School": dict(energy=0.4, density=0.42, spectacle="plain", era="minimal_70s", character="balanced",
                          niuanse=True, niuanse_strength=0.35, uniq=True, uniq_strength=0.45, director_mood=0.1),
    "Baroque": dict(energy=0.45, density=0.5, spectacle="balanced", era="minimal_70s", character="balanced",
                    niuanse=True, niuanse_strength=0.5, uniq=True, uniq_strength=0.4, director_mood=0.15),
    "Jazz": dict(energy=0.5, density=0.48, spectacle="balanced", era="analog_80s", character="optimistic",
                 niuanse=True, niuanse_strength=0.45, uniq=True, uniq_strength=0.55, director_mood=0.2),
    "Experimental": dict(energy=0.6, density=0.55, spectacle="vivid", era="maximal_now", character="dark",
                         niuanse=True, niuanse_strength=0.55, uniq=True, uniq_strength=0.75, director_mood=-0.2),
}


def _scene_from_class(cls: float, cfg: dict | None = None) -> dict:
    """Heurystyka sceny z klasy ostrości (0..5) + opcjonalnego cfg stylu."""
    c = max(0.0, min(5.0, float(cls)))
    u = c / 5.0
    # energy / density rosną z klasą, z lekkim „sweet spot”
    energy = round(0.35 + 0.55 * u + 0.05 * (1 - abs(u - 0.7)), 3)
    density = round(0.32 + 0.5 * u, 3)
    if c < 1.0:
        spectacle, era, character = "plain", "minimal_70s", "restrained"
        mood = -0.05
    elif c < 2.0:
        spectacle, era, character = "balanced", "analog_80s", "balanced"
        mood = 0.1
    elif c < 3.2:
        spectacle, era, character = "balanced", "modern_10s", "balanced"
        mood = -0.05
    elif c < 4.2:
        spectacle, era, character = "vivid", "modern_10s", "dark"
        mood = -0.3
    else:
        spectacle, era, character = "anthem", "maximal_now", "dark"
        mood = -0.5
    scales = list((cfg or {}).get("scales") or ["minor"])
    scale = scales[0] if scales else "minor"
    # długość z template
    bars = 144
    if cfg and cfg.get("template"):
        bars = int(max(64, min(256, sum(int(b) for _, b in cfg["template"]) * 2)))
        bars = (bars // 8) * 8
    return dict(
        energy=energy, density=density, scale=scale, bars=bars,
        spectacle=spectacle, era=era, character=character,
        niuanse=True, niuanse_strength=round(0.15 + 0.35 * (1 - abs(u - 0.5)), 3),
        uniq=(c >= 1.0), uniq_strength=round(0.35 + 0.3 * u, 3), uniq_drops=(c >= 2.5),
        director_on=True, director_mood=mood, director_variety=0.55,
        scenarios=True, smart_instruments=True, autolevels=True, role_swap=True,
        structure_affinity=(c >= 2.0), affinity_passes=2,
        arp_enabled=(c <= 2.5 and "arp" in (cfg or {})),
        health_on=False,
    )


def pure_scene(name: str, pure: dict | None = None) -> dict:
    """Scena dla czystego stylu: override → heurystyka z klasy."""
    pure = pure or {}
    cfg = None
    try:
        from . import generator as G
        if name in G.STYLES:
            cfg = dict.__getitem__(G.STYLES, name) if hasattr(G.STYLES, '__getitem__') else G.STYLES.get(name)
    except Exception:
        cfg = pure.get(name)
    if cfg is None and name in pure:
        cfg = pure[name]
    cls = float(STYLE_CLASS.get(name, (cfg or {}).get("_class", 2.5)))
    base = _scene_from_class(cls, cfg)
    if name in _SCENE_OVERRIDES:
        base.update(_SCENE_OVERRIDES[name])
    # bpm/swing zawsze ze stylu gdy dostępne
    if cfg:
        base["bpm"] = int(cfg.get("bpm", base.get("bpm", 140)))
        base["swing"] = float(cfg.get("swing", 0.0))
        if cfg.get("scales"):
            base["scale"] = list(cfg["scales"])[0]
    else:
        base.setdefault("bpm", 140)
        base.setdefault("swing", 0.0)
    base["style"] = name
    return base


def _lerp(a, b, t):
    return a + (b - a) * t


def blend_scenes(parts: dict) -> dict:
    """Ważona scena hybrydy. Bool → próg 0.45; choice → składnik o największej wadze."""
    if not parts:
        return _scene_from_class(2.5)
    items = [(n, pure_scene(n), w) for n, w in parts.items() if w > 0]
    tot = sum(w for _, _, w in items) or 1.0
    items = [(n, sc, w / tot) for n, sc, w in items]
    # dominant for discrete
    dom = max(items, key=lambda x: x[2])[1]
    out = dict(dom)
    # continuous
    for key in ("energy", "density", "swing", "niuanse_strength", "uniq_strength",
                "director_mood", "director_variety"):
        out[key] = round(sum(sc.get(key, 0) * w for _, sc, w in items), 3)
    out["bpm"] = int(round(sum(sc.get("bpm", 140) * w for _, sc, w in items)))
    out["bars"] = int(round(sum(sc.get("bars", 144) * w for _, sc, w in items) / 8) * 8)
    out["bars"] = max(64, min(256, out["bars"]))
    # bool by weight
    for key in ("niuanse", "uniq", "uniq_drops", "director_on", "scenarios",
                "smart_instruments", "autolevels", "role_swap", "structure_affinity",
                "arp_enabled", "health_on"):
        out[key] = sum(float(bool(sc.get(key))) * w for _, sc, w in items) >= 0.45
    out["affinity_passes"] = int(round(sum(sc.get("affinity_passes", 2) * w for _, sc, w in items)))
    out["affinity_passes"] = max(1, min(4, out["affinity_passes"]))
    # discrete from dominant
    for key in ("scale", "spectacle", "era", "character"):
        out[key] = dom.get(key)
    out["style"] = hybrid_name({n: w for n, _, w in items}) or dom.get("style")
    return out


def scene_for(style_name: str, pure: dict | None = None) -> dict:
    """Scena kompletna dla czystego stylu albo hybrydy A 60% + B 40%."""
    if pure is None:
        try:
            from . import generator as G
            pure = G.STYLES
        except Exception:
            pure = {}
    parts = parse_hybrid(style_name, pure) if isinstance(style_name, str) and "%" in style_name else None
    if parts and len(parts) > 1:
        return blend_scenes(parts)
    if parts and len(parts) == 1:
        return pure_scene(next(iter(parts)), pure)
    return pure_scene(style_name, pure)


def random_style_and_scene(rng=None, class_target=None, pure_only=True):
    """Losuje styl (opcjonalnie blisko class_target) i zwraca (name, scene)."""
    rng = rng or random.Random()
    pool = list(ORDER) if pure_only else list(ORDER)
    if not pool:
        pool = ["Brostep"]
    if class_target is not None:
        weights = []
        for s in pool:
            c = float(STYLE_CLASS.get(s, 2.5))
            weights.append(2.718 ** (-((c - float(class_target)) ** 2) / (2 * 1.4 ** 2)))
        t = sum(weights) or 1.0
        r, acc = rng.random() * t, 0.0
        name = pool[-1]
        for s, w in zip(pool, weights):
            acc += w
            if r <= acc:
                name = s; break
    else:
        name = rng.choice(pool)
    return name, scene_for(name)
