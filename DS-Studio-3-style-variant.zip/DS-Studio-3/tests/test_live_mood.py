"""Live (losowanie): nastrój, skale, groove i porządek warstw — regresja „za melancholijnie, bez rytmiki, wyższe tryby zagmatwane”."""
import copy
import random
import unittest

from dubstep_studio import core, live as L

AVAIL = set(core.TYPES) | {"openhat", "ride", "cowbell", "conga", "bass808", "upright", "organ", "epiano", "harpsichord", "flute",
                           "brass", "choir", "cello", "vibes", "marimba", "bell", "hoover", "drone"}
BASE = dict(style="Brostep", bpm=140, key=0, scale="minor", energy=0.7, density=0.6, swing=0.0, instruments=None)
MINORISH = ("minor", "phrygian", "harmonic minor")


def _cfg(name, **over):
    c = copy.deepcopy(L.DEFAULT_CFG)
    c.update(mode="random", complexity=name, complexity_follow_tod=False, tod_on=False, complexity_intensity=0.7)
    c.update(over)
    return c


def _plans(name, n=120, base=BASE, **over):
    return [L.plan_next(_cfg(name, **over), base, random.Random(s), AVAIL, hour=12)["kw"] for s in range(n)]


class TestLiveMood(unittest.TestCase):
    def test_scales_are_not_only_minor(self):
        for name in L.COMPLEXITY_ORDER:
            ks = _plans(name)
            non_minor = sum(k["scale"] not in MINORISH for k in ks) / len(ks)
            self.assertGreater(non_minor, 0.4, f"{name}: za mało skal jasnych ({non_minor:.0%})")
            self.assertTrue({"major", "dorian", "mixolydian"} & {k["scale"] for k in ks}, name)

    def test_scale_lock_is_respected(self):
        for k in _plans("easy_listening", base=dict(BASE, scale="phrygian"), n=30,
                        locks={**L.DEFAULT_CFG["locks"], "scale": True}):
            self.assertEqual(k["scale"], "phrygian")

    def test_no_dark_director_by_default(self):
        for name in L.COMPLEXITY_ORDER:
            for k in _plans(name, n=60):
                d = k.get("director")
                if isinstance(d, dict) and d.get("on"):
                    self.assertGreaterEqual(d["mood"], 0.0, name)

    def test_mood_bias_moves_mood_both_ways(self):
        def mean_mood(b):
            ms = [k["director"]["mood"] for k in _plans("balanced", n=60, mood_bias=b) if isinstance(k.get("director"), dict)]
            return sum(ms) / len(ms)
        self.assertGreater(mean_mood(0.4), mean_mood(0.0) + 0.2)
        self.assertLess(mean_mood(-0.5), mean_mood(0.0) - 0.2)

    def test_groove_turns_on_dance_and_predictability(self):
        for name in L.COMPLEXITY_ORDER:
            for k in _plans(name, n=30):
                self.assertTrue(k["dance"], name)
                self.assertGreaterEqual(k["dance_strength"], 0.45, name)
                self.assertGreaterEqual(k["predict"], 0.6, name)
        for k in _plans("intense", n=30, groove=False):
            self.assertFalse(k["dance"])
            self.assertEqual(k["predict"], 0.6)

    def test_groove_never_lowers_generator_settings(self):
        r = L._gen_extras_from_base({"dance": True, "dance_strength": 0.95, "predict": 0.97},
                                    bundle=L._complexity_bundle(_cfg("chaos"), "Popołudnie", 1.0, random.Random(1)))
        self.assertEqual((r["dance_strength"], r["predict"]), (0.95, 0.97))

    def test_percussion_present(self):
        for name in L.COMPLEXITY_ORDER:
            for k in _plans(name, n=40):
                self.assertTrue(set(k["instruments"]) & set(L.PERC_ADD), name)

    def test_tidy_limits_layers_and_roles(self):
        for name in ("energetic", "intense"):
            for k in _plans(name, n=60):
                from dubstep_studio import generator as G
                ins, cr = k["instruments"], set(G.STYLES[k["style"]].get("core", core.CORE8))
                self.assertLessEqual(sum(t in L.SUSTAINED and t not in cr for t in ins), 1, ins)     # rdzeń stylu może mieć własne długie warstwy
                d = k.get("director")
                if isinstance(d, dict):
                    self.assertFalse(d.get("roles"), name)
        old = _plans("intense", n=60, tidy=0.0)
        self.assertTrue(any((k.get("director") or {}).get("roles") for k in old), "tidy=0 ma przywracać dawne zamiany ról")

    def test_tidy_reduces_instrument_count(self):
        a = sum(len(k["instruments"]) for k in _plans("intense", n=80, tidy=0.0, groove=False))
        b = sum(len(k["instruments"]) for k in _plans("intense", n=80, tidy=0.9, groove=False))
        self.assertLess(b, a)

    def test_core_of_style_untouched(self):
        from dubstep_studio import generator as G
        for k in _plans("intense", n=40):
            for t in G.STYLES[k["style"]].get("core", core.CORE8):
                if t in AVAIL:
                    self.assertIn(t, k["instruments"], (k["style"], t))

    def test_pick_scale_brightness_ordering(self):
        rng = random.Random(7)
        dark = sum(L._pick_scale(rng, -0.8, 2.5) in ("major", "lydian", "mixolydian") for _ in range(800))
        bright = sum(L._pick_scale(rng, 0.8, 2.5) in ("major", "lydian", "mixolydian") for _ in range(800))
        self.assertGreater(bright, dark + 150)


if __name__ == "__main__":
    unittest.main()
