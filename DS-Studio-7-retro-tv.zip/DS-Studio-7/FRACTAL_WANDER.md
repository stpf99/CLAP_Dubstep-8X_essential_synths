# Fractal Wander — dodatek do DS-Studio-7

## Wtyczki (vid/plugins.py)

### room_fractal_wander
Scena: Mandelbrot + ciągły potencjał + scałkowana ścieżka kamery.

**Biomy:** space, desert, forest, jungle, ocean, canyon, ice, volcanic

| Parametr | Opis |
|----------|------|
| biome | krajobraz |
| speed / zoom / detail | baza ruchu i ostrości |
| **detail_scale** | **1…10000** — × mniej szczegółów (1=pełne, 10000=skrajnie mało) |
| **detail_auto** | **true**: skala z poziomu CPU/jakości (zakładka CPU / quality); false: tylko detail_scale |
| **mode_3d** | pseudo-3D: mapa wysokości z potencjału + cieniowanie + mgła głębi |
| height / layers | relief i warstwy parallax / płaszczyzny głębi |
| **world** | mapa świata z całek — dodatkowe elementy (gwiazdy/skały/drzewa) z ekstremów potencjału, reaguje na energię/build z dsproj |
| react / src / color | reakcja na sygnał i paletę |

**Auto CPU:** gdy `detail_auto=true`, mnożnik bierze się z `ctx.state["quality_level"]` (0=max … 6=minimal), ustawianego przez host z `quality` / zakładki CPU. Ręczny `detail_scale` nadal działa jako dodatkowy mnożnik.

### cam_fractal_path
Kamera na tej samej scałkowanej ścieżce (dryf + oddech zoomu).

## Szablony (vid/templates.py) — Wideo/RTMP i Live/RTMP
fractal_space, fractal_desert, fractal_forest, fractal_jungle,
fractal_ocean, fractal_canyon, fractal_ice, fractal_volcanic

Canyon / desert / volcanic mają domyślnie `mode_3d=true`.
Wszystkie mają `detail_auto=true` (dostosowanie do mocy CPU).

SECTION_MODS reaguje na intro/build/drop/break/outro (react/speed/detail sceny).

## Host
VideoJob ustawia `ctx.state["quality_level"]` z `pv["quality_level"]` lub mapowania `quality` (max/balanced/low/minimal).

## Podglądy
previews/fractal_wander/

## GUI

### Zakładka Wideo / RTMP (gui.py)
- **Jakość** (auto / max / balanced / low / minimal) + **Limit CPU**
- Grupa **Fractal** (aktywna przy szablonie `Fractal: …`):
  - Tryb 3D
  - Detail auto (z jakości/CPU)
  - Detail scale 1…10000
  - World (mapa całek)

### Zakładka Live → RTMP + wideo (live_gui.py)
Te same pola: Fractal 3D, Detail auto, Detail scale, World (całki) — obok Jakość / Limit CPU.

Wartości trafiają do `av` → `apply_fractal_overrides` → parametry warstwy `room_fractal_wander` oraz `pv.quality_level` (detail_auto).


## Pochodna szablonu (wszystkie szablony)

`derive_projvideo` + opcja GUI **Pochodna szablonu**:
- losuje parametry warstw wokół bazy (choice/bool z prawdopodobieństwem),
- dostosowuje wagi linków,
- buduje cue na każdą sekcję klipu z krzywą intro→build→drop→break→outro + dryfem w czasie.

GUI (Wideo/RTMP i Live): checkbox, siła 0.05–1.0, seed (0=losowy).
AV: `derive`, `derive_strength`, `derive_seed` → `build_projvideo` / AvSink.


## Kompozycja wizualna
compose_cues / composition_summary / role warstw / Opisz kompozycję w GUI.
