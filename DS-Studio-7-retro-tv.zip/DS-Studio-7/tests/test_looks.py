"""Wspólny katalog wyglądów (vid.looks): ta sama lista w oknie głównym i w Live, parsowanie, synchronizacja, render rx:* i tpl:*."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path

import numpy as np

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

from dubstep_studio import config as CF, core, video_render as VR
from dubstep_studio.vid import looks as LK, plugins, templates as TP


class FakeCombo:
    def __init__(self):
        self.items = []; self.idx = -1; self.blocked = False; self.sets = 0

    def addItem(self, text, data=None): self.items.append((text, data))
    def addItems(self, texts): [self.addItem(t) for t in texts]
    def count(self): return len(self.items)
    def findData(self, d): return next((i for i, (_, x) in enumerate(self.items) if x == d and d is not None), -1)
    def findText(self, t): return next((i for i, (x, _) in enumerate(self.items) if x == t), -1)
    def currentIndex(self): return self.idx
    def currentData(self): return self.items[self.idx][1] if 0 <= self.idx < len(self.items) else None
    def currentText(self): return self.items[self.idx][0] if 0 <= self.idx < len(self.items) else ""
    def blockSignals(self, b): self.blocked = b
    def setCurrentIndex(self, i): self.idx = i; self.sets += 1


def _proj(bars=2):
    return dict(style="Tearout", bpm=140, bars=bars, key=0, scale="minor", energy=0.8, density=0.7, seed=1, tracks=[],
                sections=[dict(type="drop", start=0, bars=bars, name="drop")])


def _silent_wav(sec):
    fd, p = tempfile.mkstemp(suffix=".wav"); os.close(fd)
    core.write_wav(p, np.zeros((int(sec * core.SR), 2), np.float32)); return p


class TestCatalog(unittest.TestCase):
    def test_catalog_covers_templates_and_scenes_with_unique_ids(self):
        cat = LK.catalog(); ids = [c["id"] for c in cat]
        self.assertEqual(len(ids), len(set(ids)))
        for t in TP.TEMPLATES:
            self.assertIn(f"tpl:{t}", ids)
        for sc, _, _ in LK.REACTIVE:
            self.assertIn(f"rx:{sc}", ids)
        self.assertEqual([c["id"] for c in VR.list_templates()], ids)          # okno główne i CLI widzą tę samą listę
        self.assertTrue(all(c["engine"] in ("template", "reactive") and c["title"] and c["label"] for c in cat))

    def test_parse_roundtrip_and_legacy(self):
        for c in LK.catalog():
            p = LK.parse(c["id"])
            self.assertEqual((p["engine"], p["template"], p["scene"]), (c["engine"], c["template"], c["scene"]))
            self.assertEqual(LK.look_id_for(p["engine"], p["template"], p["scene"]), c["id"])
        self.assertEqual(LK.parse("live_show"), dict(engine="template", template="live_show", scene="auto"))     # stare id szablonu
        self.assertEqual(LK.parse("morph")["engine"], "reactive")                                              # stara nazwa sceny
        self.assertEqual(LK.parse("rx:nie_ma")["scene"], "auto")
        self.assertEqual(LK.parse(None)["engine"], "template")
        self.assertTrue(LK.is_reactive("rx:tunnel")); self.assertFalse(LK.is_reactive("tpl:led_wall"))
        self.assertEqual(LK.template_of("rx:ring"), LK.DEFAULT_TEMPLATE)
        self.assertEqual(LK.apply_to_av(dict(fps=25), "tpl:led_wall")["template"], "led_wall")

    def test_palettes_shared(self):
        self.assertEqual(LK.palette_choices(), ["auto"] + list(plugins.PALETTES))

    def test_two_combos_same_content_and_mirror(self):
        a, b = FakeCombo(), FakeCombo()
        LK.fill_look_combo(a, "tpl:live_show"); LK.fill_look_combo(b, "rx:auto")
        self.assertEqual(a.items, b.items)                                  # identyczne pozycje w obu zakładkach
        a.setCurrentIndex(a.findData("rx:morph"))
        self.assertTrue(LK.mirror_combo(a, b)); self.assertEqual(b.currentData(), "rx:morph"); self.assertFalse(b.blocked)
        self.assertFalse(LK.mirror_combo(a, b))                             # już zgodne → brak zmiany
        pa, pb = FakeCombo(), FakeCombo(); LK.fill_palette_combo(pa); LK.fill_palette_combo(pb)
        pa.setCurrentIndex(pa.findText("acid")); LK.mirror_combo(pa, pb); self.assertEqual(pb.currentText(), "acid")


class TestConfigTemplate(unittest.TestCase):
    def test_template_key(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.txt"
            p.write_text(CF.DEFAULT_TEXT, encoding="utf-8")
            self.assertEqual(CF.load(p)["video"]["template"], "live_show")
            p.write_text(CF.DEFAULT_TEXT.replace("template = live_show", "template = led_wall"), encoding="utf-8")
            v = CF.load(p)["video"]
            self.assertEqual(LK.look_id_for("template", v["template"], v["scene"]), "tpl:led_wall")


@unittest.skipUnless(shutil.which("ffmpeg"), "brak ffmpeg")
class TestRender(unittest.TestCase):
    def test_render_reactive_mp4_via_look_id(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "v.mp4"
            r = VR.render_video(_proj(), "rx:ring", dict(width=320, height=180, fps=10), out, None, mute_audio=True)
            self.assertEqual(Path(r), out); self.assertGreater(out.stat().st_size, 1000)

    def test_export_project_av_reactive(self):
        wav = _silent_wav(4.0)
        try:
            with tempfile.TemporaryDirectory() as d:
                meta = VR.export_project_av(_proj(), d, "rx:bars", dict(width=320, height=180, fps=10), audio_wav=wav)
                self.assertEqual(meta["template"], "rx:bars")
                self.assertTrue((Path(d) / "video.mp4").stat().st_size > 1000 and (Path(d) / "track.wav").exists())
                self.assertFalse((Path(d) / "projvideo.json").exists())          # wygląd reaktywny nie ma warstw szablonu
                self.assertEqual(json.loads((Path(d) / "av_meta.json").read_text())["template"], "rx:bars")
        finally:
            os.unlink(wav)

    def test_stream_reactive_local_only(self):
        mix = np.zeros((int(core.SR * 1.5), 2), np.float32)
        st = VR.stream_reactive(_proj(), "scope", dict(local_only=True, url=""), dict(width=320, height=180, fps=10), mix=mix)
        self.assertIn("Podgląd lokalny", st)

    def test_template_ids_still_normalized(self):
        self.assertEqual(LK.template_of("tpl:led_wall"), "led_wall")
        pv = VR.build_projvideo(_proj(), "tpl:led_wall", dict(width=320, height=180, fps=10))
        self.assertTrue(pv["layers"])


if __name__ == "__main__":
    unittest.main()


class TestPaletteIsColourOnly(unittest.TestCase):
    """Paleta to wyłącznie kolorystyka: wybrana przez użytkownika wygrywa z planem utworu we WSZYSTKICH szablonach MIDI; „auto” = z planu."""

    def test_chosen_palette_beats_plan_for_every_template(self):
        for tid in TP.TEMPLATES:
            for pal in plugins.PALETTES:
                pv = TP.build_projvideo(_proj(), tid, palette=pal)
                self.assertEqual(pv["palette"], pal, (tid, pal))

    def test_auto_uses_plan_palette(self):
        for tid in TP.TEMPLATES:
            a = TP.build_projvideo(_proj(), tid, palette="auto")["palette"]
            self.assertIn(a, plugins.PALETTES)
            self.assertEqual(a, TP.build_projvideo(_proj(), tid, palette=None)["palette"])

    def test_every_entry_of_the_shared_catalog_accepts_every_palette(self):
        for c in LK.catalog():
            if c["engine"] == "template":
                self.assertEqual(VR.build_projvideo(_proj(), c["id"], dict(palette="ice"))["palette"], "ice")
        self.assertEqual(LK.palette_choices(), ["auto"] + list(plugins.PALETTES))          # jedna lista palet, bez dubli z scen reaktywnych
        self.assertEqual(len(set(LK.palette_choices())), len(LK.palette_choices()))
