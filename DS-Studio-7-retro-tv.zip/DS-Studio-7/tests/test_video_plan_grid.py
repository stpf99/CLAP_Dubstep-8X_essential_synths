"""Testy vid.plan_grid: macierz taktów == build_vector, dedup powtórzeń, dekoder, tory klatkowe, unieważnianie cache."""
from __future__ import annotations

import copy
import unittest

import numpy as np

from dubstep_studio.vid import plan as VP
from dubstep_studio.vid import plan_grid as PG
from tests.test_video_plan import _proj


def _big(bars=128, ntr=12, per_bar=8, seed=3):
    rng = np.random.RandomState(seed)
    types = ["kick", "snare", "hat", "sub", "wobble", "neuro", "pad", "screech", "vox", "riser", "clap", "pluck"][:ntr]
    tracks = []
    for ty in types:
        # powtarzalny wzorzec 4-taktowy → dużo identycznych taktów
        pat = np.sort(rng.rand(per_bar) * 16)
        notes = [[float(b * 16 + o), 0.25, 36, 0.9] for b in range(bars // 4) for o in pat]
        tracks.append(dict(name=ty, type=ty, notes=notes))
    secs, s, kinds = [], 0, ["intro", "build", "drop", "break", "drop", "outro"]
    sizes = [8, 8, 32, 16, 48, 16]
    for k, sz in zip(kinds, sizes):
        secs.append(dict(type=k, start=s, bars=sz, name=k)); s += sz
    return dict(style="Tearout", seed=1, bpm=140, energy=0.8, density=0.7, bars=s, tracks=tracks, sections=secs)


class TestGrid(unittest.TestCase):
    def test_bar_vector_matches_build_vector(self):
        p = _proj()
        V, sidx, secs = PG.bar_vectors(p, smooth=1, section_len=False)
        for b in (0, 5, 9, 17, 22, 30):
            sec = secs[int(sidx[b])]
            ref = VP.build_vector(p, sec, b, b + 1)
            np.testing.assert_allclose(V[b], ref, atol=1e-5, err_msg=f"takt {b}")

    def test_address_matches_scalar(self):
        p = _proj()
        V, _, _ = PG.bar_vectors(p, smooth=1)
        addr, nu, _ = PG.addresses(V, q=10_000)   # praktycznie bez kwantyzacji
        for b in range(len(V)):
            self.assertEqual(int(addr[b]), VP.address(V[b]))

    def test_dedup_on_repeating_project(self):
        p = _big()
        V, _, _ = PG.bar_vectors(p)
        addr, nu, inv = PG.addresses(V)
        self.assertEqual(len(addr), 128 * 0 + len(V))
        self.assertLess(nu, len(V) / 3)           # powtórzenia → dużo mniej unikalnych wierszy niż taktów
        # identyczny wiersz → identyczny adres
        for u in np.unique(inv):
            self.assertEqual(len(set(addr[inv == u].tolist())), 1)

    def test_decode_ranges_and_variation(self):
        p = _big()
        g = PG.build_grid(p)
        P = np.asarray(g["P"])
        self.assertEqual(P.shape, (g["bars"], len(PG.CHANNELS)))
        self.assertTrue((P[:, :12] >= 0).all() and (P[:, :12] <= 1).all())
        # ta sama wartość adresu może dawać różne parametry (korekta resztą) — ale nie szum
        a = np.asarray(g["addr"])
        for ad in np.unique(a):
            rows = P[a == ad][:, PG.CH["beams"]]
            self.assertLess(float(rows.max() - rows.min()), 0.6)

    def test_frame_track(self):
        p = _big()
        plan = VP.plan_project(p, force=True)
        ft = PG.FrameTrack(plan, 140.0, 30)
        d = ft.at(0)
        self.assertIn(d["scene"], VP.SCENES)
        self.assertIn(d["palette"], VP.PALETTES)
        self.assertEqual(ft.ch.shape[0], len(PG.CHANNELS))
        # ciągłość: brak skoku większego niż 1 takt-ramp między sąsiednimi klatkami (zakres 0..1)
        dj = np.abs(np.diff(ft.channel("bloom")))
        self.assertLess(float(dj.max()), 0.5)
        # po końcu — clamp
        self.assertEqual(ft.at(10**7)["bar"], ft.at(ft.n - 1)["bar"])

    def test_signature_invalidates_stale_plan(self):
        p = _proj()
        VP.plan_project(p, force=True)
        old_sig = p["video_plan"]["sig"]
        p2 = copy.deepcopy(p)
        p2["tracks"][0]["notes"].append([40.0, 0.25, 36, 1.0])
        p2["style"] = "Jazz"
        plan2 = VP.plan_project(p2)                 # bez force: ma przeliczyć, bo treść inna
        self.assertNotEqual(plan2["sig"], old_sig)
        plan3 = VP.plan_project(p2)                 # ta sama treść → ten sam obiekt z cache
        self.assertIs(plan3, p2["video_plan"])

    def test_json_roundtrip(self):
        import json
        p = _big()
        VP.plan_project(p, force=True)
        json.dumps(p["video_plan"])


class TestPlanFx(unittest.TestCase):
    """Kanały planu w rendererze reaktywnym (livefx.Viz) i w silniku szablonów (host.VideoJob) + audio per takt."""

    @staticmethod
    def _A(r, punch=0.9):
        return dict(spec=r.rand(40).astype(np.float32), low=.5, mid=.4, high=.3, rms=.6, level=.1,
                    punch=punch, wave=(r.randn(2048) * .2).astype(np.float32))

    def test_viz_without_mod_unchanged_and_with_mod_differs(self):
        from dubstep_studio.vid import livefx as LF
        plan = VP.plan_project(_big(), force=True)
        mod = PG.FrameTrack(plan, 140.0, 30).at(1200)
        for scene in ("morph", "ring", "tunnel", "bars", "scope"):
            for fx in (0, 1, 2, 3):
                outs = []
                for m in (None, {}, mod):
                    v, e = LF.Viz(160, 90), LF.Evolution(16, seed=1)
                    r = np.random.RandomState(3)
                    a = self._A(r); e.update(a, 2)
                    outs.append(v.render(a, 1.0, scene, fx, e, "neon", 1.0, True, m))
                    self.assertEqual(outs[-1].shape, (90, 160, 3))
                self.assertTrue(np.array_equal(outs[0], outs[1]), f"{scene} fx{fx}: mod=None ≠ {{}}")
            # na najwyższym poziomie jakości plan musi coś zmienić
            self.assertFalse(np.array_equal(outs[0], outs[2]), scene)

    def test_audio_bar_stats(self):
        fps, bpm, nb = 10, 120.0, 4                      # takt = 2 s = 20 klatek
        x = np.concatenate([np.full(20, 0.2), np.full(20, 0.4), np.full(20, 0.6), np.full(20, 0.8)])
        st = PG.audio_bar_stats(dict(fps=fps, rms=x, low=x, mid=x, high=x), bpm, nb)
        np.testing.assert_allclose(st[:, 0], [0.2, 0.4, 0.6, 0.8], atol=1e-6)
        short = PG.audio_bar_stats(dict(fps=fps, rms=x[:30], low=x[:30], mid=x[:30], high=x[:30]), bpm, nb)
        self.assertEqual(short.shape, (4, 4))            # krótsze cechy niż utwór: bez wyjątku

    def test_attach_audio_changes_params_not_addresses(self):
        p = _big(); plan = VP.plan_project(p, force=True)
        a0, P0 = list(plan["grid"]["addr"]), np.asarray(plan["grid"]["P"])
        nbf = int(p["bars"] * 240 / 140 * 15) + 1
        t = np.arange(nbf) / 15.0
        low = (0.5 + 0.5 * np.sin(t * 3.0)).astype(np.float32)
        feat = dict(fps=15, rms=low, low=low, mid=1 - low, high=low * 0.5)
        PG.attach_audio(plan, p, feat)
        self.assertEqual(plan["grid"]["addr"], a0)
        self.assertFalse(np.allclose(P0, np.asarray(plan["grid"]["P"])))
        g = plan["grid"]; PG.attach_audio(plan, p, feat)
        self.assertIs(plan["grid"], g)                    # idempotentne

    def test_videojob_uses_bar_channels(self):
        from dubstep_studio.vid import templates as TP, host as VH
        from dubstep_studio.vid.signals import audio_features
        p = _big(); p["key"] = 0; p["scale"] = "minor"
        for tr in p["tracks"]:
            tr["notes"] = [[a, b, c, d * 127] for a, b, c, d in tr["notes"]]
        pv = TP.build_projvideo(p, template="live_show", size=(160, 90), fps=10)
        secs = p["bars"] * 4 * 60.0 / 140
        r = np.random.RandomState(2)
        mix = (r.randn(int(secs * 44100), 2) * 0.1).astype(np.float32)
        job = VH.VideoJob(p, pv, audio_features(mix, 10))
        self.assertIsNotNone(job._ft)
        self.assertTrue(p["video_plan"]["grid"]["audio"])
        vals = {round(job.params_at(int(i * 10 * 240 / 140))["bloom"]["amount"], 3) for i in range(20, 44)}
        self.assertGreater(len(vals), 3)                  # w obrębie dropu zmienia się co takt (dawniej stała na sekcję)
        self.assertEqual(job.frame(5).shape, (90, 160, 3))
        # bez planu w projekcie i bez cue → stara ścieżka bez wyjątku
        p2 = dict(p); p2.pop("video_plan", None)
        job2 = VH.VideoJob(p2, dict(pv, cues=[]), None)
        self.assertEqual(job2.frame(3).shape, (90, 160, 3))


if __name__ == "__main__":
    unittest.main()
