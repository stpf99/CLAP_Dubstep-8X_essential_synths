"""TV 8-bit (M3U): parse_m3u, palety retro + kwantyzacja, reaktywność piksela, nasłuch → szablon tymczasowy,
[tv] w config.txt, pre-analiza stylu kanału → preset dla Start Live (audio_source=live, tap z Output)
oraz end-to-end TvStream na pliku testowym (ffmpeg dekoder → filtr → klatki)."""
import os
import tempfile
import time
import unittest
from pathlib import Path

import numpy as np

from dubstep_studio import config as CF, core, tv as T

SR = core.SR

M3U_SAMPLE = """#EXTM3U
#EXTINF:-1 tvg-logo="http://192.168.1.242:9981/imagecache/237" tvg-id="9a24b0666b1f80e290c111ccf99ec4e3",4Fun Kids
http://192.168.1.242:9981/stream/channelid/1722819738?profile=pass
#EXTINF:-1 tvg-logo="http://192.168.1.242:9981/imagecache/177" tvg-id="5330e289e75d9374624c86c865183b9c",HOME TV
http://192.168.1.242:9981/stream/channelid/165818451?profile=pass
#EXTINF:-1 tvg-logo="http://192.168.1.242:9981/imagecache/217" tvg-id="75f3de52c6a845df31b6cb839da1e891" tvg-chno="1",TVP1
http://192.168.1.242:9981/stream/channelid/1390343029?profile=pass
http://example.org/no-extinf.m3u8
"""


def feats(punch=0.0, low=0.0, mid=0.0, high=0.0, rms=0.0, n=40):
    return [dict(punch=punch, low=low, mid=mid, high=high, rms=rms) for _ in range(n)]


class TestM3U(unittest.TestCase):
    def test_parse_sample(self):
        ch = T.parse_m3u(M3U_SAMPLE)
        self.assertEqual(len(ch), 4)
        self.assertEqual(ch[0]["name"], "4Fun Kids")
        self.assertEqual(ch[0]["tvg_id"], "9a24b0666b1f80e290c111ccf99ec4e3")
        self.assertEqual(ch[0]["logo"], "http://192.168.1.242:9981/imagecache/237")
        self.assertIsNone(ch[0]["chno"])
        self.assertEqual(ch[2]["chno"], 1)
        self.assertEqual(ch[2]["name"], "TVP1")
        # linia bez #EXTINF: nazwa z nazwy pliku
        self.assertIn("no-extinf", ch[3]["name"])

    def test_parse_plain_list(self):
        ch = T.parse_m3u("http://a/stream1\nhttp://a/stream2\n")
        self.assertEqual([c["name"] for c in ch], ["stream1", "stream2"])


class TestFilter(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(7)
        self.frame = rng.integers(0, 256, (240, 426, 3), dtype=np.uint8)
        self.p = dict(template="gameboy", pixel=6, react=0, dither=False, scanlines=False)

    def test_quantized_to_palette(self):
        f = T.RetroFilter(426, 240, self.p)
        out = f.apply(self.frame, dict(punch=0.0))
        self.assertEqual(out.shape, (240, 426, 3))
        pal = {tuple(c) for c in T.GAMEBOY}
        used = {tuple(px) for px in out.reshape(-1, 3)[::37]}
        self.assertTrue(used.issubset(pal), "kolor spoza palety Game Boy")

    def test_react_pixel_pulses(self):
        p2 = dict(self.p, react=100)
        f = T.RetroFilter(426, 240, p2)
        a = f.apply(self.frame, dict(punch=0.0))          # brak uderzenia → jak bazowy
        b = f.apply(self.frame, dict(punch=1.0))          # mocne uderzenie → większe bloki → inny obraz
        self.assertFalse(np.array_equal(a, b))
        self.assertEqual(f.apply(self.frame, dict(punch=0.0)).tobytes(), a.tobytes())

    def test_dither_and_scanlines_change_image(self):
        f = T.RetroFilter(426, 240, dict(self.p, dither=True))
        d = f.apply(self.frame, dict(punch=0.0))
        self.assertFalse(np.array_equal(d, T.RetroFilter(426, 240, dict(self.p)).apply(self.frame, dict(punch=0.0))))
        s = T.RetroFilter(426, 240, dict(self.p, scanlines=True)).apply(self.frame, dict(punch=0.0))
        self.assertFalse(np.array_equal(s, T.RetroFilter(426, 240, dict(self.p)).apply(self.frame, dict(punch=0.0))))

    def test_all_palettes_valid(self):
        for tid, (title, pal) in T.PALETTES_TV.items():
            self.assertTrue(len(pal) >= 4, tid)
            self.assertTrue(pal.max() <= 255 and pal.min() >= 0, tid)
            f = T.RetroFilter(426, 240, dict(template=tid))
            out = f.apply(self.frame, dict(punch=0.0))
            self.assertEqual(out.dtype, np.uint8, tid)

    def test_osd_draws_text(self):
        f = T.RetroFilter(426, 240, self.p)
        base = f.apply(self.frame, dict(punch=0.0))
        osd = f.osd(base.copy(), "TVP1")
        self.assertTrue(np.array_equal(base, osd) is False)
        self.assertEqual(osd.dtype, np.uint8)

    def test_templates_fallback(self):
        f = T.RetroFilter(426, 240, dict(template="nie-ma-takiej"))
        self.assertIn("NES", f.label())                       # nieznany → NES


class TestListen(unittest.TestCase):
    def test_bassy_beat_pick_nes(self):
        r = T.listen_template(feats(punch=0.8, low=0.7, rms=0.5))
        self.assertEqual(r["template"], "nes")
        self.assertTrue(r.get("temp"))
        self.assertIn("tymczasowy", r["label"])

    def test_speech_pick_terminal(self):
        r = T.listen_template(feats(punch=0.05, low=0.1, mid=0.8, rms=0.25))
        self.assertIn(r["template"], ("amber", "green"))

    def test_quiet_pick_c64(self):
        r = T.listen_template(feats(punch=0.05, low=0.1, mid=0.1, rms=0.05))
        self.assertEqual(r["template"], "c64")

    def test_empty_no_crash(self):
        self.assertEqual(T.listen_template([]), {})


class TestStylePreanalysis(unittest.TestCase):
    """Pre-analiza stylu kanału → raport listen.py → preset dla Start Live (muzyka jako nowy strumień TV)."""

    @classmethod
    def setUpClass(cls):
        sr = SR
        dur = 26.0
        n = int(sr * dur)
        t = np.arange(n) / sr
        beat = 60.0 / 128.0                                  # 128 BPM, 4-on-the-floor
        sig = np.zeros(n, np.float32)
        for kt in np.arange(0.0, dur, beat):                 # stopa
            i0, ln = int(kt * sr), int(0.12 * sr)
            if i0 + ln < n:
                tt = np.arange(ln) / sr
                sig[i0:i0 + ln] += (np.sin(2 * np.pi * 55 * tt) * np.exp(-tt * 30) * 0.9).astype(np.float32)
        for ht in np.arange(0.0, dur, beat / 2):             # hi-haty co 1/8
            i0, ln = int(ht * sr), int(0.03 * sr)
            if i0 + ln < n:
                rng = np.random.default_rng(int(ht * 1000) % 9999)
                sig[i0:i0 + ln] += (rng.standard_normal(ln) * np.exp(-np.arange(ln) / sr * 200) * 0.25).astype(np.float32)
        wob = 0.5 + 0.5 * np.sin(2 * np.pi * 2.5 * t)        # wobble basu ~2,5 Hz
        sig += (np.sin(2 * np.pi * 110 * t) * (0.25 + 0.2 * wob) * (t % beat < beat * 0.75)).astype(np.float32)
        sig += (np.sin(2 * np.pi * 440 * t) * 0.06 + np.sin(2 * np.pi * 523.25 * t) * 0.05).astype(np.float32)
        cls.st = np.stack([sig, sig], axis=1)

    def test_report_and_preset(self):
        rep = T.build_style_report(self.st, SR)
        self.assertIsNotNone(rep, "brak raportu z pre-analizy")
        A = rep["features"]
        self.assertTrue(A["bpm"] == 0 or 90 <= A["bpm"] <= 180, f"BPM poza zakresem studia: {A['bpm']}")
        self.assertGreater(A["bpm"], 0, "tempo niewykryte na sygnale 4-on-the-floor 128 BPM")
        pre = T.style_preset(rep)
        for k in ("generator", "board", "live", "director", "flags"):
            self.assertIn(k, pre, f"brak grupy {k} w presecie")
        g = pre["generator"]
        self.assertTrue(g["style"])                          # styl z wag (hybryda albo pojedynczy)
        self.assertTrue(g["instruments"])
        self.assertIn("BPM", T.style_label(rep))

    def test_short_or_silent_signal(self):
        self.assertIsNone(T.build_style_report(np.zeros((SR * 4, 2), np.float32), SR))      # za krótki
        rep = T.build_style_report(np.zeros((SR * 20, 2), np.float32), SR)                  # cisza
        self.assertTrue(rep is None or rep["features"].get("silent", False) or rep["features"]["bpm"] == 0)


class TestAudioSource(unittest.TestCase):
    """audio_source = live: PCM z Live (external_audio) karmi analizator TV; channel ignoruje zewnętrzne PCM."""

    def test_external_audio_only_in_live_mode(self):
        s = T.TvStream("http://x/y", dict(template="nes", audio_source="live"), dict(enabled=False))
        s.run = True                                          # bez start() — brak ffmpeg; testujemy samą logikę audio
        pcm = np.zeros(2400, "<i2").tobytes()                 # 1200 ramek stereo (4800 bajtów)
        s.external_audio(pcm)
        self.assertEqual(s.samples, 1200)
        self.assertGreater(s.an.total, 0)
        self.assertEqual(s.params["audio_source"], "live")
        s.stop()                                              # nie może wywalić (run=False → ignoruje)
        s.external_audio(pcm)
        self.assertEqual(s.samples, 1200)

    def test_channel_mode_ignores_external_and_switches(self):
        s = T.TvStream("http://x/y", dict(template="nes"), dict(enabled=False))
        s.run = True
        pcm = np.zeros(2400, "<i2").tobytes()                 # 1200 ramek stereo (4800 bajtów)
        s.external_audio(pcm)
        self.assertEqual(s.samples, 0)                        # domyślnie channel — zewnętrzne PCM ignorowane
        s.set_audio_source("live")
        self.assertEqual(s.audio_src, "live")
        self.assertEqual(s.params["audio_source"], "live")
        s.set_audio_source("live")                            # idempotentnie
        s.external_audio(pcm)
        self.assertEqual(s.samples, 1200)
        s.set_audio_source("channel")
        self.assertEqual(s.audio_src, "channel")

    def test_style_listen_window(self):
        s = T.TvStream("http://x/y", dict(template="nes"), dict(enabled=False))
        self.assertEqual(s.style_until, 0.0)
        s.start_style_listen(30)
        self.assertGreater(s.style_until, time.time() + 25)
        s.start_style_listen(500)                             # clamp do 90 s
        self.assertLessEqual(s.style_until - time.time(), 91)


class TestOutputTap(unittest.TestCase):
    """Output.add_tap/remove_tap: TV dostaje każdy kawałek miksowanego PCM muzyki Live."""

    def test_tap_gets_pcm(self):
        from dubstep_studio import live as L
        out = L.Output()
        got = []
        out.add_tap(got.append)
        out.add_tap(got.append)                               # ten sam fn nie dubluje się
        self.assertEqual(len(out.taps), 1)
        dummy = type("P", (), {"write": lambda self, b: True, "start": lambda self: True,
                               "stop": lambda self: None, "alive": lambda self: True, "name": "dummy"})()
        out.local = dummy
        out._put(b"\x00" * 64)
        self.assertEqual(len(got), 1)
        self.assertEqual(len(got[0]), 64)
        out.remove_tap(got.append)
        out._put(b"\x00" * 64)
        self.assertEqual(len(got), 1)                         # po usunięciu tap cisza
        # tap rzucający wyjątek nie zabija odtwarzacza
        def boom(_b):
            raise RuntimeError("x")
        out.add_tap(boom)
        self.assertTrue(out._put(b"\x00" * 64))


class TestConfig(unittest.TestCase):
    def test_defaults_present_without_section(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.txt"
            p.write_text("[video]\nsize = 640x360\n", encoding="utf-8")     # stary config bez [tv]
            c = CF.load(p)
            self.assertEqual(c["tv"]["template"], "auto")
            self.assertEqual(c["tv"]["pixel"], 6)
            self.assertTrue(c["tv"]["dither"])
            self.assertEqual(c["tv"]["size"], "640x360")

    def test_section_override_and_clamp(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.txt"
            p.write_text("[tv]\npixel = 99\nreact = -5\ntemplate = amber\nrtmp = yes\nsize = 426x240\nfps = 60\n"
                         "playlist_url = http://192.168.1.242:9981/playlists/id/88/channels.m3u\n", encoding="utf-8")
            c = CF.load(p)["tv"]
            self.assertEqual(c["pixel"], 24)                  # clamp 2..24
            self.assertEqual(c["react"], 0)
            self.assertEqual(c["template"], "amber")
            self.assertTrue(c["rtmp"])
            self.assertEqual(c["size"], "426x240")
            self.assertEqual(c["fps"], 50)                    # clamp 5..50
            self.assertEqual(c["playlist_url"], "http://192.168.1.242:9981/playlists/id/88/channels.m3u")

    def test_save_values_tv(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.txt"
            p.write_text(CF.DEFAULT_TEXT, encoding="utf-8")
            CF.save_values(p, {("tv", "pixel"): 9, ("tv", "template"): "pico8"})
            c = CF.load(p)["tv"]
            self.assertEqual(c["pixel"], 9); self.assertEqual(c["template"], "pico8")

    def test_style_for_live_and_audio_source(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.txt"
            p.write_text("[tv]\nstyle_for_live = yes\naudio_source = live\n", encoding="utf-8")
            c = CF.load(p)["tv"]
            self.assertTrue(c["style_for_live"])
            self.assertEqual(c["audio_source"], "live")
            p.write_text("[video]\nsize = 640x360\n", encoding="utf-8")      # stary config → domyślne
            c = CF.load(p)["tv"]
            self.assertFalse(c["style_for_live"])
            self.assertEqual(c["audio_source"], "channel")
            p.write_text(CF.DEFAULT_TEXT, encoding="utf-8")
            CF.save_values(p, {("tv", "style_for_live"): "yes", ("tv", "audio_source"): "live"})
            c = CF.load(p)["tv"]
            self.assertTrue(c["style_for_live"]); self.assertEqual(c["audio_source"], "live")


@unittest.skipUnless(os.environ.get("DS_TV_E2E", "1") == "1", "end-to-end wyłączone DS_TV_E2E=0")
class TestTvStreamE2E(unittest.TestCase):
    """Syntetyczny plik (mpeg4 + aac) → TvStream (lokalny plik zamiast HTTP): dekoder → filtr → klatki."""

    @classmethod
    def setUpClass(cls):
        import subprocess
        cls.tmp = tempfile.TemporaryDirectory()
        cls.clip = str(Path(cls.tmp.name) / "clip.mp4")
        cmd = ["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=320x240:rate=25:duration=6",
               "-f", "lavfi", "-i", "sine=frequency=220:duration=6", "-c:v", "mpeg4", "-q:v", "4", "-c:a", "aac", "-shortest", cls.clip]
        subprocess.run(cmd, check=True, capture_output=True)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_stream_produces_8bit_frames(self):
        s = T.TvStream(self.clip, dict(template="nes", pixel=6, react=40, local_audio=False, preview="off"),
                       dict(enabled=False), out_size=(426, 240), fps=25, title="Kanał TEST")
        s.start()
        try:
            # plik jest dekodowany bez `-re` (zalewka klatek); czekaj na 10 klatek albo na koniec dekodera + stabilizację
            dl, last, last_t = time.time() + 25, -1, time.time()
            while time.time() < dl:
                if s.sent_v >= 10:
                    break
                if s.sent_v == last and s.sent_v > 0 and time.time() - last_t > 1.5:
                    break                                  # dekoder skończył, render wyczerpał kolejkę
                if s.sent_v != last:
                    last, last_t = s.sent_v, time.time()
                time.sleep(0.05)
            self.assertGreaterEqual(s.sent_v, 5, f"za mało klatek; status: {s.status}; err: {s._err[:200]}")
            fr = s.latest_frame()
            self.assertIsNotNone(fr)
            data, w, h, _k = fr
            self.assertEqual((w, h), s.pipe)
            img = np.frombuffer(data, np.uint8).reshape(h, w, 3)
            used = {tuple(px) for px in img.reshape(-1, 3)[::53]}
            self.assertTrue(used.issubset({tuple(c) for c in T.NES}), "klatka nie jest skwantyzowana do NES")
            self.assertIn("Kanał TEST", s.status)
            # nasłuch: okno zamyka się samo i ustawia szablon tymczasowy
            s.listen_until = time.time() - 0.01; s.listen_buf = [dict(punch=0.8, low=0.7, mid=0.2, high=0.1, rms=0.4)]
            s._listen_tick(dict(punch=0.8, low=0.7, rms=0.4))
            self.assertTrue(s.params.get("temp")); self.assertEqual(s.params["template"], "nes")
            self.assertIn("tymczasowy", s.temp_label)
        finally:
            s.stop()
        self.assertIsNone(s.latest)
        self.assertFalse(s.run)

    def test_probe_channel_file(self):
        r = T.probe_channel(self.clip, timeout=6)
        self.assertTrue(r["ok"], r)
        self.assertIn("video", r["info"]) if False else None    # info zależy od ffprobe; sprawdzamy sam ok


if __name__ == "__main__":
    unittest.main()
