"""Testy warstwy vid.plan: wektory → adres → params, powtórzone motywy, integracja reactive/template."""
from __future__ import annotations

import unittest

from dubstep_studio.vid import plan as VP


def _proj(style="Brostep", seed=7, energy=0.8, density=0.7):
    # dwa dropy o podobnej gęstości → ten sam motif hash możliwy
    tracks = [
        dict(name="kick", type="kick", notes=[[0.0, 0.25, 36, 1.0], [4.0, 0.25, 36, 1.0], [8.0, 0.25, 36, 0.9],
                                              [16.0, 0.25, 36, 1.0], [20.0, 0.25, 36, 1.0], [32.0, 0.25, 36, 1.0], [36.0, 0.25, 36, 1.0]]),
        dict(name="snare", type="snare", notes=[[2.0, 0.25, 40, 0.9], [6.0, 0.25, 40, 0.9], [18.0, 0.25, 40, 0.9], [34.0, 0.25, 40, 0.9]]),
        dict(name="sub", type="sub", notes=[[0.0, 2.0, 36, 0.8], [16.0, 2.0, 36, 0.8], [32.0, 2.0, 36, 0.8]]),
        dict(name="wobble", type="wobble", notes=[[16.0, 4.0, 40, 0.7], [32.0, 4.0, 40, 0.7]]),
        dict(name="neuro", type="neuro", notes=[[16.0, 2.0, 48, 0.6], [32.0, 2.0, 48, 0.6]]),
    ]
    sections = [
        dict(type="intro", start=0, bars=4, name="intro"),
        dict(type="build", start=4, bars=4, name="build"),
        dict(type="drop", start=8, bars=8, name="drop1"),
        dict(type="break", start=16, bars=4, name="break"),
        dict(type="drop", start=20, bars=8, name="drop2"),
        dict(type="outro", start=28, bars=4, name="outro"),
    ]
    return dict(style=style, seed=seed, bpm=140, energy=energy, density=density, bars=32,
                tracks=tracks, sections=sections, key=0, scale="minor")


class TestVideoPlan(unittest.TestCase):
    def test_vector_dim(self):
        p = _proj()
        u = VP.build_vector(p, p["sections"][2], 8, 16)
        self.assertEqual(u.shape, (VP.DIM,))
        self.assertAlmostEqual(float((u * u).sum()) ** 0.5, 1.0, places=5)

    def test_plan_spans_and_motif_reuse(self):
        p = _proj()
        plan = VP.plan_project(p, force=True)
        self.assertEqual(len(plan["spans"]), 6)
        self.assertIn("palette", plan)
        # drop1 i drop2 przy podobnej treści mogą dzielić motif
        drops = [s for s in plan["spans"] if s["type"] == "drop"]
        self.assertEqual(len(drops), 2)
        # determinizm
        plan2 = VP.plan_project(dict(p), force=True)
        self.assertEqual([s["addr"] for s in plan["spans"]], [s["addr"] for s in plan2["spans"]])

    def test_decode_fields(self):
        d = VP.decode(3, "drop", seed=1)
        self.assertIn(d["scene"], VP.SCENES)
        self.assertIn(d["palette"], VP.PALETTES)
        self.assertIn("brush", d)
        self.assertIn("post", d)

    def test_reactive_for(self):
        p = _proj("Tearout")
        rx = VP.reactive_for(p)
        self.assertIn(rx["palette"], VP.PALETTES)
        self.assertIn(rx["drop_scene"], VP.SCENES)
        self.assertTrue(rx["agents"] >= 8)

    def test_params_at(self):
        p = _proj()
        plan = VP.plan_project(p, force=True)
        # 8 barów * 4 beaty * 60/140 sec ≈ początek dropu
        t = 8 * 4 * 60.0 / 140.0 + 0.5
        pr = VP.params_at(plan, t, bpm=140)
        self.assertIsNotNone(pr)
        self.assertIn("scene", pr)

    def test_apply_projvideo(self):
        p = _proj()
        plan = VP.plan_project(p, force=True)
        pv = dict(version=1, palette="mono", layers=[], links=[], cues=[], meta={})
        out = VP.apply_to_projvideo(pv, plan, p)
        self.assertEqual(out["palette"], plan["palette"])
        self.assertEqual(len(out["cues"]), 6)

    def test_soft_style_differs(self):
        a = VP.plan_project(_proj("Tearout", seed=1), force=True)
        b = VP.plan_project(_proj("Jazz", seed=1), force=True)
        # różne style → często inna paleta lub inne adresy
        self.assertTrue(
            a["palette"] != b["palette"] or [s["addr"] for s in a["spans"]] != [s["addr"] for s in b["spans"]]
        )


if __name__ == "__main__":
    unittest.main()
