"""Podgląd lokalny wideo i diagnostyka RTMP: powód błędu, NullStreamer, LiveAV/Output bez RTMP, config, ffplay (sterownik SDL dummy)."""
from __future__ import annotations

import os
import shutil
import socket
import tempfile
import time
import unittest
from pathlib import Path

import numpy as np

os.environ["SDL_VIDEODRIVER"] = "dummy"      # testy nie mogą otwierać okien
os.environ["SDL_AUDIODRIVER"] = "dummy"

from dubstep_studio import config as CF, live as L
from dubstep_studio.vid import host as VH, livefx as LF
from tests.test_video_plan_grid import _big

SR = 44100


def _pcm(sec, f=110.0):
    t = np.arange(int(sec * SR)) / SR
    x = (np.sin(2 * np.pi * f * t) * 0.4 * 32767).astype("<i2")
    return np.repeat(x[:, None], 2, 1).tobytes()


def _free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def _wait(fn, sec=6.0):
    t0 = time.time()
    while time.time() - t0 < sec:
        v = fn()
        if v:
            return v
        time.sleep(0.05)
    return None


class TestRtmpDiagnostics(unittest.TestCase):
    def test_explain_refused_dns_timeout_and_hint(self):
        e = VH.rtmp_explain("rtmp://localhost/video", "", "Error opening output files: Connection refused")
        self.assertIn("brak serwera RTMP na localhost:1935", e)
        self.assertIn("nazwy strumienia", e)                             # URL bez /nazwa i bez klucza
        e2 = VH.rtmp_explain("rtmp://localhost/video/stream", "", "Connection refused")
        self.assertNotIn("nazwy strumienia", e2)
        self.assertIn("nie znaleziono hosta", VH.rtmp_explain("rtmp://nie.ma/app/s", "", "Name or service not known"))
        self.assertIn("nie odpowiada", VH.rtmp_explain("rtmp://10.255.255.1/app/s", "", "Connection timed out"))
        self.assertEqual(VH.rtmp_url_hint("rtmp://localhost/video", "klucz"), "")      # klucz = nazwa strumienia

    def test_probe(self):
        port = _free_port()
        ok, msg = VH.rtmp_probe(f"rtmp://127.0.0.1:{port}/a/b")
        self.assertFalse(ok); self.assertIn("brak serwera RTMP", msg)
        srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(1)
        try:
            self.assertTrue(VH.rtmp_probe(f"rtmp://127.0.0.1:{srv.getsockname()[1]}/a/b")[0])
        finally:
            srv.close()

    @unittest.skipUnless(shutil.which("ffmpeg"), "brak ffmpeg")
    def test_streamer_without_server_reports_reason_and_stops_fast(self):
        port = _free_port()
        st = VH.RtmpStreamer(dict(url=f"rtmp://127.0.0.1:{port}/video", key="", v_codec="libx264", v_preset="ultrafast", v_bitrate=500,
                                  a_bitrate=64, reconnect=True, reconnect_sec=1, timeout_sec=3), (160, 90), 10, lambda m: None)
        st.start()
        got = _wait(lambda: (st.write_frame(bytes(160 * 90 * 3)), st.write_audio(bytes(4800 * 4)), st.maintain(), st.last_error)[-1], 8)
        self.assertTrue(got and "brak serwera RTMP" in got, got)
        t0 = time.time(); st.stop()
        self.assertLess(time.time() - t0, 5.0)                           # dawniej: zawieszenie na stdin.close() przy niedziałającym połączeniu

    @unittest.skipUnless(shutil.which("ffmpeg"), "brak ffmpeg")
    def test_streamer_to_local_ffmpeg_server(self):
        import subprocess
        port = _free_port()
        srv = subprocess.Popen(["ffmpeg", "-loglevel", "warning", "-listen", "1", "-f", "flv", "-i", f"rtmp://127.0.0.1:{port}/video/stream", "-f", "null", "-"],
                               stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            time.sleep(1.0)
            st = VH.RtmpStreamer(dict(url=f"rtmp://127.0.0.1:{port}/video/stream", key="", v_codec="libx264", v_preset="ultrafast", v_bitrate=500,
                                      a_bitrate=64, reconnect=False, timeout_sec=5), (160, 90), 10, lambda m: None)
            st.start()
            ok = _wait(lambda: (st.write_frame(bytes(160 * 90 * 3)), st.write_audio(bytes(4800 * 4)), time.sleep(0.1), st.maintain(), st.status == "nadaje")[-1], 10)
            self.assertTrue(ok, st.status + " " + st.err_tail)
            st.stop()
        finally:
            srv.terminate(); srv.wait(timeout=3)


class TestLocalPreview(unittest.TestCase):
    def test_null_streamer_api(self):
        n = VH.NullStreamer()
        self.assertTrue(n.start() and n.alive() and n.write_frame(b"x") and n.write_audio(b"y"))
        n.maintain(); n.stop(); self.assertEqual(n.frames, 1)

    @unittest.skipUnless(VH.LocalPreview.available(), "brak ffplay")
    def test_ffplay_window(self):
        p = VH.LocalPreview((160, 90), 10)
        self.assertTrue(p.start())
        try:
            for _ in range(10):
                p.write_frame(bytes(160 * 90 * 3)); time.sleep(0.03)
            self.assertTrue(p.alive()); self.assertGreater(p.frames, 0)
        finally:
            p.stop()
        self.assertFalse(p.alive())

    def test_liveav_preview_without_rtmp(self):
        av = LF.LiveAV(dict(width=320, height=180, fps=15, preview="gui"), dict(enabled=False, url="rtmp://localhost/video"))
        self.assertIsInstance(av.st, VH.NullStreamer); self.assertFalse(av.net)
        av.start(); av.begin(_big(), None, None, title="T")
        try:
            b = _pcm(3); step = LF.LiveAV.CH * 4
            for i in range(0, len(b), step):
                av.audio(b[i:i + step])
            fr = _wait(av.latest_frame)
            self.assertIsNotNone(fr)
            data, w, h, k = fr
            self.assertEqual(len(data), w * h * 3); self.assertEqual((w, h), av.pipe)
            self.assertTrue(av.status.startswith("Podgląd lokalny"), av.status)
        finally:
            av.stop()

    def test_liveav_with_rtmp_keeps_streamer(self):
        av = LF.LiveAV(dict(width=320, height=180, fps=15), dict(enabled=True, url="rtmp://localhost/live/x"))
        self.assertIsInstance(av.st, VH.RtmpStreamer); self.assertTrue(av.net)

    def test_output_preview_only(self):
        out = L.Output()
        out.configure(dict(enabled=False), True, rtmp_cfg=dict(enabled=False, url="rtmp://localhost/video"),
                      av_cfg=dict(width=320, height=180, fps=15, preview="gui", engine="template", template="live_show"))   # szablon MIDI bez RTMP → TEN SAM szablon w podglądzie
        self.assertFalse(out.rtmp_on()); self.assertTrue(out.preview_on())
        out.started = True; out._sync_av()
        try:
            self.assertIsInstance(out.av, VH.AvSink); self.assertIsInstance(out.av.st, VH.NullStreamer); self.assertFalse(out.av.net)
            out.begin_av(_big(), None, None, title="T")
            b = _pcm(2); step = LF.LiveAV.CH * 4
            for i in range(0, len(b), step):
                out.av.audio(b[i:i + step])
            fr = _wait(out.preview_frame)
            self.assertIsNotNone(fr)
            data, w, h, k = fr
            self.assertEqual((w, h), (320, 180)); self.assertEqual(len(data), w * h * 3)
            self.assertIn("Podgląd lokalny", out.status()["rtmp"])
        finally:
            out.started = False; out._sync_av()
        self.assertIsNone(out.av)

    def test_output_preview_only_reactive_still_liveav(self):
        out = L.Output()
        out.configure(dict(enabled=False), True, rtmp_cfg=dict(enabled=False, url="rtmp://localhost/video"),
                      av_cfg=dict(width=320, height=180, fps=15, preview="gui", engine="reactive", scene="ring"))
        out.started = True; out._sync_av()
        try:
            self.assertIsInstance(out.av, LF.LiveAV)
        finally:
            out.started = False; out._sync_av()

    def test_preview_off_means_no_av(self):
        out = L.Output(); out.configure(dict(enabled=False), True, rtmp_cfg=dict(enabled=False, url=""), av_cfg=dict(preview="off"))
        out.started = True; out._sync_av()
        self.assertIsNone(out.av); self.assertEqual(out.status()["rtmp"], "RTMP: wyłączony")
        out.started = False


class TestConfigPreview(unittest.TestCase):
    def test_default_and_override(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "config.txt"
            p.write_text(CF.DEFAULT_TEXT, encoding="utf-8")
            self.assertEqual(CF.load(p)["video"]["preview"], "off")
            for val, exp in (("gui", "gui"), ("window", "window"), ("cokolwiek", "off")):
                p.write_text(CF.DEFAULT_TEXT.replace("preview = off", f"preview = {val}"), encoding="utf-8")
                self.assertEqual(CF.load(p)["video"]["preview"], exp)


if __name__ == "__main__":
    unittest.main()
