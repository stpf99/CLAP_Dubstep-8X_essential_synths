"""Szybsze ścieżki renderu wideo muszą dawać ten sam obraz co dawne, wolniejsze implementacje (różnica ≤ 1/255)."""
from __future__ import annotations

import os
import unittest

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

import numpy as np

from dubstep_studio.vid import canvas as CV, host as VH, plugins as PL, templates as TP


def _noise(h=72, w=128, seed=3):
    return np.random.default_rng(seed).random((h, w, 3), dtype=np.float32)


class _Ctx:
    def __init__(self, c):
        self.canvas = c; self.i = 0; self.rng = np.random.default_rng(1)


class TestFastPaths(unittest.TestCase):
    def test_zoom_equals_fancy_index(self):
        img = _noise()
        for z, cx, cy in ((1.05, .5, .5), (1.3, .2, .8), (1.5, 1.0, 0.0), (2.0, .5, .5)):
            h, w = img.shape[:2]; vw, vh = w / z, h / z
            x0 = min(max(cx * w - vw / 2, 0), w - vw); y0 = min(max(cy * h - vh / 2, 0), h - vh)
            xs = (x0 + (np.arange(w) + 0.5) * vw / w).astype(np.int32).clip(0, w - 1); ys = (y0 + (np.arange(h) + 0.5) * vh / h).astype(np.int32).clip(0, h - 1)
            np.testing.assert_array_equal(CV.Canvas.zoom(img, z, cx, cy), img[ys][:, xs])

    def test_glow_separable_equals_2d_formula(self):
        c = CV.Canvas(160, 90); ref = np.zeros((90, 160, 3), np.float32)
        for cx, cy, r, col, k in ((80.3, 40.7, 30, (1, .5, .2), .7), (5.5, 80.2, 40, (.2, .9, 1), 1.0), (170, 10, 25, (1, 1, 1), .5)):
            c.glow(cx, cy, r, col, k)
            r_ = max(2, int(r)); X0, Y0, X1, Y1 = max(0, int(cx) - r_), max(0, int(cy) - r_), min(160, int(cx) + r_ + 1), min(90, int(cy) + r_ + 1)
            yy, xx = np.ogrid[Y0:Y1, X0:X1]
            g = np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (0.18 * r_ * r_)))[..., None].astype(np.float32)
            ref[Y0:Y1, X0:X1] += g * np.asarray(col, np.float32) * k
        self.assertLess(float(np.abs(c.img - ref).max()), 1e-4)

    def test_gradient_cache_matches_and_is_not_shared(self):
        a = CV.Canvas(32, 48); b = CV.Canvas(32, 48)
        a.gradient_v((0, 0, .1), (.5, .2, 0)); b.gradient_v((0, 0, .1), (.5, .2, 0)); a.img[0, 0] = 9
        t = np.linspace(0, 1, 48, dtype=np.float32)[:, None, None]
        np.testing.assert_allclose(b.img, np.broadcast_to(np.asarray((0, 0, .1), np.float32) * (1 - t) + np.asarray((.5, .2, 0), np.float32) * t, (48, 32, 3)), atol=1e-6)
        self.assertNotEqual(float(b.img[0, 0, 0]), 9.0)

    def test_bloom_fast_equals_reference(self):
        img = _noise() ** 3
        ctx = _Ctx(CV.Canvas(128, 72)); pl = PL.FxBloom(); pl.p = dict(amount=.6, threshold=.2)
        f = 4; hh, ww = 72 // f * f, 128 // f * f
        sm = img[:hh, :ww].reshape(hh // f, f, ww // f, f, 3).mean((1, 3)); br = np.maximum(sm - .2 * .8, 0)
        for _ in range(2):
            br = (br + np.roll(br, 1, 0) + np.roll(br, -1, 0) + np.roll(br, 1, 1) + np.roll(br, -1, 1)) / 5.0
        ref = img.copy(); ref[:hh, :ww] += np.repeat(np.repeat(br, f, 0), f, 1) * (.6 * 2.2)
        out = pl.apply(ctx, img.copy(), 0)
        self.assertLess(float(np.abs(out - ref).max()), 1e-4)
        dark = np.zeros_like(img); self.assertEqual(float(np.abs(pl.apply(ctx, dark.copy(), 0)).max()), 0.0)

    def test_frames_are_deterministic_and_stateless_in_buffers(self):
        proj = dict(style="Tearout", bpm=140, bars=2, key=0, scale="minor", energy=.8, density=.7, seed=1, tracks=[], sections=[dict(type="drop", start=0, bars=2, name="drop")])
        for tid in TP.TEMPLATES:
            pv = TP.build_projvideo(proj, tid, size=(320, 180), fps=30)
            j1 = VH.VideoJob(proj, pv, None); j2 = VH.VideoJob(proj, pv, None)
            for i in (0, 7, 31):
                a = j1.frame(i); b = j2.frame(i)
                self.assertEqual(a.dtype, np.uint8); self.assertEqual(a.shape, (180, 320, 3))
                np.testing.assert_array_equal(a, b)
            a0 = j1.frame(7).copy(); j1.frame(8)                                   # bufor roboczy nie może zmieniać wcześniej zwróconej klatki
            np.testing.assert_array_equal(a0, j2.frame(7))

    def test_export_mp4_threaded_writer(self):
        import shutil, tempfile
        if not shutil.which("ffmpeg"):
            self.skipTest("brak ffmpeg")
        from dubstep_studio import core
        proj = dict(style="Tearout", bpm=140, bars=1, key=0, scale="minor", energy=.8, density=.7, seed=1, tracks=[], sections=[dict(type="drop", start=0, bars=1, name="drop")])
        pv = TP.build_projvideo(proj, "tunnel_trip", size=(320, 180), fps=15)
        with tempfile.TemporaryDirectory() as d:
            wav = os.path.join(d, "a.wav"); core.write_wav(wav, np.zeros((int(3 * core.SR), 2), np.float32))
            out = VH.export_mp4(proj, pv, os.path.join(d, "o.mp4"), audio_wav=wav, enc=dict(crf=28, v_preset="ultrafast"))
            self.assertGreater(os.path.getsize(out), 1000)


if __name__ == "__main__":
    unittest.main()
