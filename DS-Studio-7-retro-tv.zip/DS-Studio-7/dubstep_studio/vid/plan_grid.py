"""plan_grid.py — macierzowa warstwa pseudo-AI na poziomie TAKTÓW (rozszerzenie plan.py).

plan.py decyduje raz na SEKCJĘ. Tu ta sama idea idzie w dół do taktu i do klatki, bez żadnej
pętli per-nuta/per-klatka w Pythonie:

  1. V = bar_vectors(proj)              macierz (taktów × DIM) — jedno przejście po nutach (bincount)
  2. dedup: wiersze skwantyzowane → np.unique → adres liczony TYLKO dla unikalnych wierszy
  3. A = argmax(V_u @ M.T)              jedno mnożenie macierzy zamiast pętli argmin
  4. P = T[addr, typ_sekcji] + R @ D.T  dekoder: tablica prototypów + liniowa korekta reszty (V - M[addr])
  5. FrameTrack: P → tablice (kanały × klatki) przez indeksowanie; lookup w klatce = O(1)

Wspólny język (AXES ↔ CHANNELS) jest jawną tabelą poniżej — to jedyne miejsce, gdzie dane audio
(grupy instrumentów, sekcje, barwa) spotykają parametry wideo (pędzle, kamera, postefekty).
Powtórzone takty (ten sam wiersz po kwantyzacji) dostają identyczne parametry z jednego obliczenia.
"""
from __future__ import annotations

import hashlib
import json
import math

import numpy as np

from . import plan as VP

# ---- wspólny język: nazwy osi wektora U (kolejność = plan.build_vector) ----
AXES = (
    "sec", "len", "energy", "density", "tempo",
    "d_kick", "d_bass", "d_lead", "d_perc", "d_pad", "d_vocal",
    "g_bass", "g_lead", "g_perc", "g_fx",
    "agg", "t_hard", "t_soft", "t_acoustic", "vocal",
    "form_pos", "drops_before", "is_drop", "is_build",
)
assert len(AXES) == VP.DIM
AX = {n: i for i, n in enumerate(AXES)}

# kanały ciągłe wyjścia (wszystkie 0..1 poza agents)
CHANNELS = (
    "beams", "particles", "trail",
    "cam_amount", "cam_speed", "cam_punch",
    "bloom", "glitch", "strobe", "scanlines", "mirror", "vignette",
    "fx", "agents",
)
CH = {n: i for i, n in enumerate(CHANNELS)}

# korekta dekodera: kanał ← Σ gain · (V[oś] − M[addr][oś]); rzadka macierz D (C × DIM)
RESIDUAL_RULES = {
    "beams": {"d_kick": 1.2, "d_bass": 0.6, "energy": 0.4},
    "particles": {"d_perc": 1.0, "d_lead": 0.6},
    "trail": {"d_pad": 0.8, "d_lead": 0.3},
    "cam_amount": {"d_kick": 0.6, "is_drop": 0.2},
    "cam_speed": {"tempo": 0.3},
    "cam_punch": {"d_kick": 0.8, "d_bass": 0.3},
    "bloom": {"d_lead": 0.6, "d_pad": 0.4, "energy": 0.3},
    "glitch": {"d_perc": 0.4, "g_fx": 0.8, "t_hard": 0.5},
    "strobe": {"d_kick": 0.4, "is_drop": 0.3},
    "scanlines": {"d_kick": -0.2},
    "mirror": {"d_lead": 0.4},
    "vignette": {"energy": -0.3},
    "agents": {"d_perc": 12.0, "d_bass": 6.0},
}

# cechy audio per takt (z miksu): odchylenie od średniej utworu → korekta kanałów (kolejność: rms, low, mid, high)
AUDIO_AXES = ("a_rms", "a_low", "a_mid", "a_high")
AUDIO_RULES = {
    "beams": {"a_low": 0.6, "a_rms": 0.2},
    "particles": {"a_mid": 0.6},
    "bloom": {"a_high": 0.6, "a_rms": 0.2},
    "glitch": {"a_high": 0.4},
    "strobe": {"a_low": 0.3},
    "cam_punch": {"a_low": 0.4},
    "agents": {"a_rms": 10.0},
}
SEC_ORDER = VP.SEC_TYPES
CAT_NAMES = ("scene", "palette", "src")


def _decoder_matrix() -> np.ndarray:
    D = np.zeros((len(CHANNELS), VP.DIM), np.float32)
    for ch, rules in RESIDUAL_RULES.items():
        for ax, g in rules.items():
            D[CH[ch], AX[ax]] = g
    return D


def _audio_matrix() -> np.ndarray:
    A = np.zeros((len(CHANNELS), len(AUDIO_AXES)), np.float32)
    for ch, rules in AUDIO_RULES.items():
        for ax, g in rules.items():
            A[CH[ch], AUDIO_AXES.index(ax)] = g
    return A


_D = _decoder_matrix()
_DA = _audio_matrix()
_PROTO_CACHE: np.ndarray | None = None


def _flatten(params: dict) -> np.ndarray:
    b, c, p = params["brush"], params["camera"], params["post"]
    return np.array([
        b["beams_intensity"], b["particles"], b["trail"],
        c["amount"], c["speed"], c["punch"],
        p["bloom"], p["glitch"], p["strobe"], p["scanlines"], p["mirror"], p["vignette"],
        params["fx"], params["agents"],
    ], np.float32)


def prototype_table() -> np.ndarray:
    """T[addr, sekcja, kanał] — decode() policzone RAZ dla wszystkich 48×5 kombinacji (stała tablica)."""
    global _PROTO_CACHE
    if _PROTO_CACHE is None:
        K = VP.codebook().shape[0]
        T = np.zeros((K, len(SEC_ORDER), len(CHANNELS)), np.float32)
        for a in range(K):
            for s, st in enumerate(SEC_ORDER):
                T[a, s] = _flatten(VP.decode(a, st, seed=0))
        _PROTO_CACHE = T
    return _PROTO_CACHE


# ------------------------------------------------------------------ sygnatura projektu (do unieważniania cache)
def proj_signature(proj: dict) -> str:
    """Tania sygnatura treści: styl/seed/bpm/sekcje + (typ, liczba nut, pierwsza/ostatnia nuta) per ścieżka."""
    h = hashlib.blake2b(digest_size=10)
    h.update(json.dumps([proj.get("style"), proj.get("seed"), proj.get("bpm"), proj.get("bars"),
                         proj.get("energy"), proj.get("density"),
                         [(s.get("type"), s.get("start"), s.get("bars", s.get("length"))) for s in (proj.get("sections") or [])]],
                        default=str).encode())
    for tr in proj.get("tracks") or []:
        notes = tr.get("notes") or []
        first = notes[0][:2] if notes else None
        last = notes[-1][:2] if notes else None
        h.update(json.dumps([tr.get("type"), bool(tr.get("mute")), len(notes), first, last], default=str).encode())
    return h.hexdigest()


# ------------------------------------------------------------------ krok 1: macierz wektorów
def _n_bars(proj: dict, sections: list) -> int:
    end = max([int(math.ceil(float(s.get("start") or 0) + float(s.get("bars") or s.get("length") or 8))) for s in sections] or [0])
    return max(1, int(proj.get("bars") or 0), end)


def _sections(proj: dict) -> list:
    secs = list(proj.get("sections") or [])
    if not secs:
        secs = [dict(type="drop", start=0, bars=int(proj.get("bars") or 32), name="drop")]
    return secs


def _density_matrix(proj: dict, nb: int) -> np.ndarray:
    """(G × nb): eventy grupy na takt / 8 (identycznie jak plan._density_in_span dla okna 1 taktu), jeden bincount na ścieżkę."""
    groups = list(VP.GROUP_TYPES)
    cnt = np.zeros((len(groups), nb), np.float32)
    for tr in proj.get("tracks") or []:
        if tr.get("mute"):
            continue
        ty = str(tr.get("type") or "")
        idx = [i for i, g in enumerate(groups) if ty in VP.GROUP_TYPES[g]]
        notes = tr.get("notes") or []
        if not idx or not notes:
            continue
        try:
            on = np.asarray([n[0] for n in notes], np.float64)
        except Exception:
            on = np.asarray([float(n[0]) for n in notes if n and isinstance(n[0], (int, float))], np.float64)
        b = np.floor(on / 4.0).astype(np.int64)
        b = b[(b >= 0) & (b < nb)]
        bc = np.bincount(b, minlength=nb)[:nb].astype(np.float32)
        for i in idx:
            cnt[i] += bc
    return np.minimum(1.0, cnt / 8.0)


def _sec_index_per_bar(sections: list, nb: int) -> np.ndarray:
    idx = np.full(nb, -1, np.int32)
    for k, s in enumerate(sections):
        a = int(math.floor(float(s.get("start") or 0)))
        b = int(math.ceil(float(s.get("start") or 0) + float(s.get("bars") or s.get("length") or 8)))
        a, b = max(0, a), min(nb, b)
        sl = idx[a:b]
        sl[sl < 0] = k          # pierwsza pasująca sekcja wygrywa (jak plan.span_at_bar)
    # luki: przed pierwszą → 0, po ostatniej → ostatnia
    last = len(sections) - 1
    cur = 0
    for i in range(nb):
        if idx[i] < 0:
            idx[i] = cur if i < int(float(sections[0].get("start") or 0)) else last
        else:
            cur = int(idx[i])
    return idx


def bar_vectors(proj: dict, smooth: int = 3, section_len: bool = True, normalize: bool = True):
    """Zwraca (V, sec_idx, sections): V ∈ R^(nb × DIM) w jednym przejściu (bez pętli po taktach)."""
    sections = _sections(proj)
    nb = _n_bars(proj, sections)
    dens = _density_matrix(proj, nb)
    if smooth and smooth > 1:                      # okno przesuwne po taktach (frazowanie zamiast migotania)
        k = np.ones(int(smooth), np.float32) / float(smooth)
        pad = int(smooth) // 2
        dens = np.stack([np.convolve(np.pad(r, (pad, int(smooth) - 1 - pad), mode="edge"), k, mode="valid") for r in dens])
    groups = list(VP.GROUP_TYPES)
    gi = {g: i for i, g in enumerate(groups)}
    sidx = _sec_index_per_bar(sections, nb)
    stt = VP._track_stats(proj)
    tot = float(stt["total"])
    bt = stt["by_type"]

    V = np.zeros((nb, VP.DIM), np.float32)
    st_types = [str(s.get("type") or "drop") for s in sections]
    sec_i = np.array([VP.SEC_IDX.get(t, 2) / max(1, len(VP.SEC_TYPES) - 1) for t in st_types], np.float32)
    sec_len = np.array([float(s.get("bars") or s.get("length") or 8) for s in sections], np.float32)
    energy = float(proj.get("energy") if proj.get("energy") is not None else 0.7)
    density = float(proj.get("density") if proj.get("density") is not None else 0.6)
    bpm = float(proj.get("bpm") or 140)
    V[:, AX["sec"]] = sec_i[sidx]
    V[:, AX["len"]] = np.minimum(1.0, (sec_len[sidx] if section_len else 1.0) / 32.0)
    V[:, AX["energy"]] = energy
    V[:, AX["density"]] = density
    V[:, AX["tempo"]] = min(1.0, max(0.0, (bpm - 60.0) / 140.0))
    for i, g in enumerate(("kick", "bass", "lead", "perc", "pad", "vocal")):
        V[:, 5 + i] = dens[gi[g]]
    for i, g in enumerate(("bass", "lead", "perc", "fx")):
        V[:, 11 + i] = min(1.0, stt["by_group"].get(g, 0) / tot)
    V[:, AX["agg"]] = VP._style_agg(str(proj.get("style") or ""))
    hard = sum(bt.get(t, 0) for t in ("neuro", "growl", "screech", "hoover", "glitch", "tearout"))
    soft = sum(bt.get(t, 0) for t in ("upright", "epiano", "piano", "strings", "choir", "drone", "flute"))
    ac = sum(bt.get(t, 0) for t in ("theremin", "panflute", "handpan", "tongue", "vibes", "marimba", "bell"))
    V[:, AX["t_hard"]] = min(1.0, hard / tot)
    V[:, AX["t_soft"]] = min(1.0, soft / tot)
    V[:, AX["t_acoustic"]] = min(1.0, ac / tot)
    V[:, AX["vocal"]] = min(1.0, stt["by_group"].get("vocal", 0) / tot * 4.0)
    ns = len(sections)
    V[:, AX["form_pos"]] = sidx / max(1, ns - 1)
    is_drop_sec = np.array([t == "drop" for t in st_types], np.float32)
    drops_before = np.concatenate([[0.0], np.cumsum(is_drop_sec)[:-1]]).astype(np.float32)
    V[:, AX["drops_before"]] = np.minimum(1.0, drops_before[sidx] / 3.0)
    V[:, AX["is_drop"]] = is_drop_sec[sidx]
    V[:, AX["is_build"]] = np.array([1.0 if t == "build" else (0.5 if t == "break" else 0.0) for t in st_types], np.float32)[sidx]
    if normalize:
        n = np.linalg.norm(V, axis=1, keepdims=True)
        V = np.where(n > 1e-6, V / np.maximum(n, 1e-12), V)
    return V, sidx, sections


def audio_bar_stats(feat: dict, bpm: float, nb: int) -> np.ndarray:
    """(nb × 4) średnie rms/low/mid/high na takt z cech klatkowych (signals.audio_features); sumy kumulowane, bez pętli."""
    fps = float(feat.get("fps") or 30)
    cols = []
    edges = np.round(np.arange(nb + 1) * (240.0 / float(bpm) * fps)).astype(np.int64)
    for k in ("rms", "low", "mid", "high"):
        a = np.asarray(feat.get(k), np.float64).reshape(-1)
        if not a.size:
            cols.append(np.zeros(nb)); continue
        cs = np.concatenate([[0.0], np.cumsum(a)])
        e0 = np.clip(edges[:-1], 0, a.size - 1)
        e1 = np.clip(np.maximum(edges[1:], e0 + 1), 1, a.size)
        cols.append((cs[e1] - cs[e0]) / np.maximum(1, e1 - e0))
    return np.stack(cols, axis=1).astype(np.float32)


# ------------------------------------------------------------------ kroki 2-4: dedup → adres → dekoder
def addresses(V: np.ndarray, M: np.ndarray | None = None, q: int = 16):
    """Adres dla każdego wiersza; policzony tylko dla unikalnych (po kwantyzacji 1/q). Zwraca (addr, uniq_count, inv)."""
    M = VP.codebook() if M is None else M
    Q = np.round(V * q).astype(np.int16)
    _, first, inv = np.unique(Q, axis=0, return_index=True, return_inverse=True)
    inv = np.asarray(inv).reshape(-1)
    a_u = np.argmax(V[first] @ M.T, axis=1)          # unit·unit: argmax(dot) ≡ argmin(L2)
    return a_u[inv].astype(np.int32), int(len(first)), inv


def decode_bars(V: np.ndarray, addr: np.ndarray, sidx: np.ndarray, sections: list, audio: np.ndarray | None = None) -> np.ndarray:
    """P (nb × C): prototyp[addr, sekcja] + (V − M[addr]) @ D.T [+ odchylenie audio @ DA.T], przycięte do zakresów.
    Audio NIE zmienia adresu (adres = struktura utworu) — tylko drobne parametry taktu."""
    T = prototype_table()
    M = VP.codebook()
    st = np.array([VP.SEC_IDX.get(str(s.get("type") or "drop"), 2) for s in sections], np.int32)[sidx]
    P = T[addr, st] + (V - M[addr]) @ _D.T
    if audio is not None and len(audio) == len(P):
        dev = audio - audio.mean(axis=0, keepdims=True)          # względem średniej utworu (niezależne od głośności)
        P = P + dev @ _DA.T
    P[:, :12] = np.clip(P[:, :12], 0.0, 1.0)
    P[:, CH["fx"]] = np.clip(np.round(P[:, CH["fx"]]), 0, 3)
    P[:, CH["agents"]] = np.clip(np.round(P[:, CH["agents"]]), 8, 64)
    return P


def build_grid(proj: dict, smooth: int = 3, feat: dict | None = None) -> dict:
    """Zwarta, serializowalna siatka taktowa (listy) do wstawienia w plan['grid']. feat = signals.audio_features (opcjonalnie)."""
    V, sidx, sections = bar_vectors(proj, smooth=smooth)
    addr, n_unique, inv = addresses(V)
    audio = audio_bar_stats(feat, float(proj.get("bpm") or 140), len(V)) if feat else None
    P = decode_bars(V, addr, sidx, sections, audio)
    return dict(
        version=1, smooth=int(smooth), bars=int(len(addr)), unique_rows=n_unique, audio=audio is not None,
        addr=addr.tolist(), phrase=inv.astype(int).tolist(), sec=sidx.astype(int).tolist(),
        channels=list(CHANNELS), P=np.round(P, 4).tolist(),
    )


def attach_audio(plan: dict, proj: dict, feat: dict) -> dict:
    """Przelicza siatkę planu z cechami miksu (raz, wektorowo). Adresy/sekcje bez zmian; idempotentne."""
    if plan is None or not feat:
        return plan
    old = plan.get("grid") or {}
    if old.get("audio") and old.get("audio_n") == len(feat.get("rms", [])):
        return plan
    g = build_grid(proj, smooth=int(old.get("smooth", 3)), feat=feat)
    g["audio_n"] = int(len(feat.get("rms", [])))
    plan["grid"] = g
    return plan


# ------------------------------------------------------------------ krok 5: tory klatkowe (O(1) lookup)
class FrameTrack:
    """Kanały (C × n_klatek) + kategorie sekcyjne (scena/paleta/src) policzone raz; at(k)/at_time(t) bez pętli."""

    def __init__(self, plan: dict, bpm: float, fps: int, n_frames: int | None = None, ramp: float = 0.25):
        grid = plan.get("grid") or {}
        P = np.asarray(grid.get("P"), np.float32)
        if P.ndim != 2 or not len(P):
            raise ValueError("plan bez grid — wywołaj plan_project()")
        self.bpm, self.fps = float(bpm), int(fps)
        nb = len(P)
        if n_frames is None:
            n_frames = int(math.ceil(nb * 240.0 / self.bpm * self.fps)) + 1
        self.n = int(n_frames)
        pos = np.arange(self.n, dtype=np.float64) * (self.bpm / 240.0 / self.fps)   # pozycja w taktach
        b0 = np.clip(np.floor(pos).astype(np.int64), 0, nb - 1)
        b1 = np.clip(b0 + 1, 0, nb - 1)
        frac = pos - np.floor(pos)
        w = np.clip((frac - (1.0 - ramp)) / max(ramp, 1e-6), 0.0, 1.0).astype(np.float32)   # miękkie przejście w końcówce taktu
        w[pos >= nb] = 0.0
        self.ch = (P[b0] * (1.0 - w)[:, None] + P[b1] * w[:, None]).T.copy()        # (C, n)
        self.bar = b0.astype(np.int32)
        # kategorie: stabilne w obrębie sekcji (z adresu sekcji z plan['spans'])
        spans = plan.get("spans") or []
        sec_of_bar = np.asarray(grid.get("sec"), np.int32)
        span_by_i = {int(s["i"]): s for s in spans}
        scene = []
        pal = []
        src = []
        for k in range(int(sec_of_bar.max()) + 1 if len(sec_of_bar) else 0):
            p = (span_by_i.get(k) or (spans[min(k, len(spans) - 1)] if spans else {})).get("params") or {}
            scene.append(p.get("scene", "morph"))
            pal.append(p.get("palette", plan.get("palette", "neon")))
            src.append((p.get("brush") or {}).get("src", "energy"))
        self._cats = {"scene": scene, "palette": pal, "src": src}
        self._sec_of_bar = sec_of_bar
        self._chidx = {n: i for i, n in enumerate(grid.get("channels") or CHANNELS)}

    def at(self, k: int) -> dict:
        k = min(max(int(k), 0), self.n - 1)
        b = int(self.bar[k])
        s = int(self._sec_of_bar[min(b, len(self._sec_of_bar) - 1)])
        out = {n: float(self.ch[i, k]) for n, i in self._chidx.items()}
        out["bar"] = b
        out["scene"] = self._cats["scene"][s]
        out["palette"] = self._cats["palette"][s]
        out["src"] = self._cats["src"][s]
        return out

    def at_time(self, t: float) -> dict:
        return self.at(int(t * self.fps))

    def channel(self, name: str) -> np.ndarray:
        """Cały tor jednego kanału (n,) — do wektorowego użycia w renderze offline."""
        return self.ch[self._chidx[name]]
