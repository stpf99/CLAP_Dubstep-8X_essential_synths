"""templates.py — szablony wideo i automatyczna reżyseria pokazu z danych projektu.

projvideo (pv) to słownik JSON, odpowiednik „stanu wtyczek” projektu audio:
  {version, template, size:[w,h], fps, render_scale, palette, meta:{title,style,bpm,key,focus_track}, layers:[{id,plugin,params}],
   links:[{src,dst,param,amount}], cues:[{section:k, mods:{layer_id:{param:wartość}}}]}
build_projvideo(proj, szablon, ...) bierze szablon (szkielet warstw) i dopasowuje go do projektu: dobiera wykonawców do istniejących
ścieżek (kick/snare/bas/lead…), wybiera ścieżkę „focus” do teledysku 1-track, rozpisuje cue na każdą sekcję (intro/build/drop/break/outro).
Para projaudio.json + projvideo.json to pełny, przenośny opis AV utworu (patrz export_package w host.py)."""
from __future__ import annotations

import copy
import math
import json
from pathlib import Path

from .. import core
from .plugins import PALETTES
from .registry import VREG
from .signals import GROUPS

L = lambda lid, plugin, **params: {"id": lid, "plugin": plugin, "params": params}      # noqa: E731

TEMPLATES = {
    "kraftwerk_robots": dict(
        title="Roboty na scenie (koncert-maszyna)", palette="kraftwerk", desc="Siatka neonowa, rząd robotów grających swoje partie, wiązki, scanlines — hołd dla estetyki „człowiek-maszyna”",
        layers=[L("room", "room_grid", density=0.5, speed=0.35, pulse=0.6, color="c"), L("beams", "brush_beams", count=5, intensity=0.35, src="kick", color="b"),
                L("robots", "perf_robot", _auto="robots"), L("parts", "brush_particles", amount=0.35, src="kick", color="hot"),
                L("cam", "cam_drift", amount=0.25, speed=0.15), L("bloom", "fx_bloom", amount=0.35, threshold=0.55), L("scan", "fx_scanlines", amount=0.4, vignette=0.4),
                L("spec", "ov_spectrum", bars=32, opacity=0.4, height=0.14), L("title", "ov_title", corner="bl", scale=1.0), L("fade", "fx_fade", fade_in=1.5, fade_out=3.0)],
        links=[("kick", "room", "pulse", 0.3), ("energy", "beams", "intensity", 0.4), ("energy", "scan", "amount", 0.2), ("kick", "bloom", "amount", 0.25)]),
    "single_track_mv": dict(
        title="Teledysk 1-track", palette="neon", desc="Void + obracający się wireframe + neonowy ślad nut jednej ścieżki (wybierz focus albo auto)",
        layers=[L("room", "room_void", pulse=0.6, glow=0.4, src="energy", color="a"), L("wire", "perf_wire", scale=1.1, spin=0.4, src="focus", color="c"),
                L("trail", "brush_trail", src="focus", width=3, length=0.7, color="b"), L("scope", "brush_scope", y=0.5, height=0.2, glow=0.5, color="c"),
                L("cam", "cam_punch", amount=0.35, shake=0.1, base=1.04, src="kick"), L("glitch", "fx_glitch", amount=0.2, src="snare"), L("bloom", "fx_bloom", amount=0.5),
                L("wave", "ov_wave", y=0.92, height=0.1, opacity=0.6), L("title", "ov_title", corner="tl", scale=0.9), L("fade", "fx_fade", fade_in=1.0, fade_out=3.0)],
        links=[("energy", "trail", "width", 0.3), ("snare", "glitch", "amount", 0.4), ("focus", "wire", "scale", 0.25)]),
    "live_show": dict(
        title="Live show (auto)", palette="neon", desc="Scena z reflektorami, wiązki, cząstki, strobo na kick — automatyczny pokaz z całego projektu",
        layers=[L("room", "room_stage", spots=5, fog=0.4, intensity=0.6), L("beams", "brush_beams", count=6, intensity=0.55, src="kick", sweep=0.6),
                L("robots", "perf_robot", _auto="robots"), L("parts", "brush_particles", amount=0.5, src="kick", color="hot"),
                L("cam", "cam_punch", amount=0.4, shake=0.12, base=1.03, src="kick"), L("strobe", "fx_strobe", amount=0.3, threshold=0.6, src="kick"),
                L("bloom", "fx_bloom", amount=0.45), L("wave", "ov_wave", y=0.93, height=0.09, opacity=0.7), L("spec", "ov_spectrum", bars=48, opacity=0.35, height=0.16),
                L("title", "ov_title", corner="tl", scale=0.9, live=True), L("fade", "fx_fade", fade_in=0.8, fade_out=2.5)],
        links=[("kick", "strobe", "amount", 0.5), ("kick", "parts", "amount", 0.4), ("energy", "room", "ambient", 0.4), ("energy", "beams", "intensity", 0.3)]),
    "led_wall": dict(
        title="Ściana LED + orb", palette="acid", desc="Ściana pikseli reagująca na widmo i pulsująca kula",
        layers=[L("room", "room_ledwall", cols=32, gap=0.3, base=0.1), L("orb", "perf_orb", scale=0.9, rings=0.6, src="kick", color="b"),
                L("cam", "cam_drift", amount=0.15, speed=0.2), L("bloom", "fx_bloom", amount=0.6, threshold=0.4), L("title", "ov_title", corner="br", scale=0.9), L("fade", "fx_fade")],
        links=[("kick", "orb", "scale", 0.3)]),
    "tunnel_trip": dict(
        title="Tunel", palette="sunset", desc="Tunel ramek + bryła + lustro/glitch na dropach",
        layers=[L("room", "room_tunnel", count=14, speed=0.55, sway=0.4, src="kick"), L("wire", "perf_wire", shape="octa", scale=0.9, spin=0.6, src="bass", color="hot"),
                L("mirror", "fx_mirror", mode="lr", mix=0.0), L("glitch", "fx_glitch", amount=0.15, src="snare"), L("bloom", "fx_bloom", amount=0.5),
                L("cam", "cam_punch", amount=0.3, shake=0.2, base=1.02, src="kick"), L("title", "ov_title", corner="bl", scale=0.8), L("fade", "fx_fade")],
        links=[("energy", "room", "speed", 0.3)]),
    # --- Fractal wander (Mandelbrot + scałkowana ścieżka) — dostępne w Wideo/RTMP i Live/RTMP ---
    "fractal_space": dict(
        title="Fractal: Kosmos", palette="neon",
        desc="Wędrówka przez mgławice Mandelbrota — scałkowana ścieżka kamery, warstwy parallax, gwiazdy",
        layers=[L("room", "room_fractal_wander", biome="space", speed=0.4, zoom=1.0, detail=0.75, height=0.55, layers=3, react=0.5, src="energy", color="c", detail_auto=True, detail_scale=1.0, mode_3d=False, world=0.45),
                L("cam", "cam_fractal_path", amount=0.45, zoom_breathe=0.35, src="energy"),
                L("parts", "brush_particles", amount=0.2, src="kick", color="hot"),
                L("bloom", "fx_bloom", amount=0.55, threshold=0.45),
                L("title", "ov_title", corner="bl", scale=0.85), L("fade", "fx_fade", fade_in=1.5, fade_out=3.5)],
        links=[("energy", "room", "react", 0.35), ("kick", "bloom", "amount", 0.25), ("energy", "cam", "amount", 0.2)]),
    "fractal_desert": dict(
        title="Fractal: Pustynia", palette="sunset",
        desc="Lot nad wydmami z potencjału fraktalnego — ciepły relief, horyzont, dryf kamery",
        layers=[L("room", "room_fractal_wander", biome="desert", speed=0.45, zoom=0.95, detail=0.7, height=0.75, layers=3, react=0.4, src="energy", color="a", detail_auto=True, detail_scale=1.0, mode_3d=True, world=0.4),
                L("cam", "cam_fractal_path", amount=0.5, zoom_breathe=0.25, src="bass"),
                L("bloom", "fx_bloom", amount=0.4, threshold=0.5),
                L("title", "ov_title", corner="bl", scale=0.85), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.3), ("bass", "cam", "amount", 0.25)]),
    "fractal_forest": dict(
        title="Fractal: Las", palette="acid",
        desc="Przejście przez gęstwinę fraktalną — pnie, światło przebijające, warstwy głębi",
        layers=[L("room", "room_fractal_wander", biome="forest", speed=0.4, zoom=1.05, detail=0.72, height=0.7, layers=3, react=0.45, src="energy", color="c", detail_auto=True, detail_scale=1.0, mode_3d=False, world=0.45),
                L("cam", "cam_fractal_path", amount=0.4, zoom_breathe=0.3, src="energy"),
                L("parts", "brush_particles", amount=0.15, src="hat", color="b"),
                L("bloom", "fx_bloom", amount=0.35, threshold=0.55),
                L("title", "ov_title", corner="bl", scale=0.8), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.35), ("hat", "parts", "amount", 0.2)]),
    "fractal_jungle": dict(
        title="Fractal: Dżungla", palette="acid",
        desc="Gęstsza, bardziej organiczna wersja lasu — silniejszy canopy i żyłkowanie fazy",
        layers=[L("room", "room_fractal_wander", biome="jungle", speed=0.42, zoom=1.0, detail=0.78, height=0.75, layers=4, react=0.5, src="energy", color="c", detail_auto=True, detail_scale=1.0, mode_3d=False, world=0.45),
                L("cam", "cam_fractal_path", amount=0.45, zoom_breathe=0.3, src="energy"),
                L("bloom", "fx_bloom", amount=0.4),
                L("title", "ov_title", corner="bl", scale=0.8), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.4)]),
    "fractal_ocean": dict(
        title="Fractal: Ocean", palette="ice",
        desc="Falująca powierzchnia z fazy orbity + refleksy — spokojniejszy dryf",
        layers=[L("room", "room_fractal_wander", biome="ocean", speed=0.35, zoom=0.9, detail=0.68, height=0.5, layers=3, react=0.4, src="energy", color="c", detail_auto=True, detail_scale=1.0, mode_3d=False, world=0.45),
                L("cam", "cam_fractal_path", amount=0.35, zoom_breathe=0.4, src="pad"),
                L("bloom", "fx_bloom", amount=0.5, threshold=0.4),
                L("wave", "ov_wave", y=0.9, height=0.08, opacity=0.35, color="b"),
                L("title", "ov_title", corner="bl", scale=0.8), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.3), ("pad", "cam", "amount", 0.2)]),
    "fractal_canyon": dict(
        title="Fractal: Kanion", palette="sunset",
        desc="Czerwone granie i ostre krawędzie potencjału — dramatyczny relief",
        layers=[L("room", "room_fractal_wander", biome="canyon", speed=0.4, zoom=1.0, detail=0.75, height=0.8, layers=3, react=0.45, src="energy", color="a", detail_auto=True, detail_scale=1.0, mode_3d=True, world=0.5),
                L("cam", "cam_fractal_path", amount=0.5, zoom_breathe=0.25, src="bass"),
                L("bloom", "fx_bloom", amount=0.45),
                L("title", "ov_title", corner="bl", scale=0.85), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.35), ("bass", "cam", "amount", 0.25)]),
    "fractal_ice": dict(
        title="Fractal: Lód", palette="ice",
        desc="Kryształy i iskry z fazy — chłodna, jasna wędrówka",
        layers=[L("room", "room_fractal_wander", biome="ice", speed=0.38, zoom=1.05, detail=0.8, height=0.6, layers=3, react=0.4, src="energy", color="c", detail_auto=True, detail_scale=1.0, mode_3d=False, world=0.45),
                L("cam", "cam_fractal_path", amount=0.4, zoom_breathe=0.35, src="energy"),
                L("bloom", "fx_bloom", amount=0.55, threshold=0.4),
                L("title", "ov_title", corner="bl", scale=0.85), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.35), ("kick", "bloom", "amount", 0.2)]),
    "fractal_volcanic": dict(
        title="Fractal: Wulkan", palette="sunset",
        desc="Lawa i żar z potencjału — mocna reakcja na energię i kick",
        layers=[L("room", "room_fractal_wander", biome="volcanic", speed=0.45, zoom=0.95, detail=0.72, height=0.7, layers=3, react=0.65, src="energy", color="a", detail_auto=True, detail_scale=1.0, mode_3d=True, world=0.55),
                L("cam", "cam_fractal_path", amount=0.5, zoom_breathe=0.3, src="kick"),
                L("parts", "brush_particles", amount=0.35, src="kick", color="hot"),
                L("bloom", "fx_bloom", amount=0.65, threshold=0.4),
                L("strobe", "fx_strobe", amount=0.0, src="kick"),
                L("title", "ov_title", corner="bl", scale=0.85), L("fade", "fx_fade")],
        links=[("energy", "room", "react", 0.4), ("kick", "parts", "amount", 0.3), ("kick", "bloom", "amount", 0.3)]),
}

# reżyseria: modyfikacje parametrów na typ sekcji (wartości bezwzględne, nakładane na te warstwy, które istnieją w szablonie)
SECTION_MODS = {
    "intro": {"strobe": {"amount": 0.0}, "glitch": {"amount": 0.05}, "beams": {"intensity": 0.2}, "parts": {"amount": 0.15}, "cam": {"amount": 0.15}, "bloom": {"amount": 0.3}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.3}, "room": {"react": 0.25, "speed": 0.3}},
    "build": {"strobe": {"amount": 0.2}, "glitch": {"amount": 0.2}, "beams": {"intensity": 0.55, "sweep": 0.85}, "parts": {"amount": 0.35}, "cam": {"amount": 0.35}, "bloom": {"amount": 0.5}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.6}, "room": {"react": 0.45, "speed": 0.45}},
    "drop": {"strobe": {"amount": 0.55}, "glitch": {"amount": 0.4}, "beams": {"intensity": 0.8, "sweep": 0.6}, "parts": {"amount": 0.8}, "cam": {"amount": 0.7}, "bloom": {"amount": 0.7}, "mirror": {"mix": 0.6}, "robots": {"glow": 0.9}, "room": {"react": 0.75, "speed": 0.6, "detail": 0.85}},
    "break": {"strobe": {"amount": 0.0}, "glitch": {"amount": 0.0}, "beams": {"intensity": 0.25, "sweep": 0.2}, "parts": {"amount": 0.1}, "cam": {"amount": 0.12}, "bloom": {"amount": 0.35}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.35}, "room": {"react": 0.2, "speed": 0.25}},
    "outro": {"strobe": {"amount": 0.0}, "glitch": {"amount": 0.03}, "beams": {"intensity": 0.15}, "parts": {"amount": 0.1}, "cam": {"amount": 0.1}, "bloom": {"amount": 0.3}, "mirror": {"mix": 0.0}, "robots": {"glow": 0.25}, "room": {"react": 0.2, "speed": 0.25}},
}


def list_templates():
    return [dict(id=k, title=v["title"], desc=v["desc"], palette=v["palette"], layers=[l["plugin"] for l in v["layers"]]) for k, v in TEMPLATES.items()]


def list_palettes():
    return list(PALETTES)


def _track_counts(proj):
    n = {}
    for t in proj.get("tracks") or []:
        if not t.get("mute") and t.get("notes"):
            n[t["type"]] = n.get(t["type"], 0) + len(t["notes"])
    return n


def pick_focus(proj):
    """Ścieżka do teledysku 1-track: najbardziej „melodyczna” (lead > bas > pad) z największą liczbą nut."""
    best, bs = None, -1
    for t in proj.get("tracks") or []:
        if t.get("mute") or not t.get("notes"):
            continue
        ty = t["type"]; w = 3.0 if ty in GROUPS["lead"] or ty in GROUPS["vocal"] else 2.0 if ty in GROUPS["bass"] else 1.0 if ty in GROUPS["pad"] else 0.2
        sc = w * (len(t["notes"]) ** 0.5)
        if sc > bs:
            best, bs = t["name"], sc
    return best


def _robot_roster(proj, n):
    """Do n robotów przypisuje źródła z istniejących ścieżek (kolejność ważności: kick, snare, bas, lead, perc, pad, vocal)."""
    cnt = _track_counts(proj); have = {g for g, types in GROUPS.items() if any(cnt.get(t) for t in types)}
    order = [g for g in ("kick", "bass", "snare", "lead", "perc", "pad", "vocal", "clap", "tom") if g in have] or ["energy"]
    return [order[k % len(order)] for k in range(n)]


def _spread(n):
    return [0.5] if n == 1 else [0.14 + 0.72 * k / (n - 1) for k in range(n)]


def build_projvideo(proj, template="kraftwerk_robots", size=(1280, 720), fps=30, palette=None, robots=None, focus_track=None, render_scale=1.0, auto_cues=True):
    tpl = TEMPLATES.get(template) or TEMPLATES["live_show"]
    palette = None if str(palette or "").strip().lower() in ("", "auto") else str(palette).strip().lower()      # „auto” = z planu utworu (jak w silniku reaktywnym)
    key = core.key_name(proj) if proj.get("tracks") is not None else ""
    pv = dict(version=1, template=template, size=[int(size[0]), int(size[1])], fps=int(fps), render_scale=float(render_scale), palette=palette or tpl["palette"],
              meta=dict(title=str(proj.get("name", "")), style=str(proj.get("style", "")), bpm=int(round(float(proj.get("bpm") or 0))), key=key, focus_track=focus_track or pick_focus(proj)),
              layers=[], links=[], cues=[])
    if pv["palette"] not in PALETTES:
        pv["palette"] = "kraftwerk"
    for l in tpl["layers"]:
        params = dict(l["params"]); auto = params.pop("_auto", None)
        if auto == "robots":
            nr = int(robots or (5 if int(size[0]) >= 1000 else 4)); roster = _robot_roster(proj, nr); xs = _spread(nr)
            for k in range(nr):
                pv["layers"].append(dict(id=f"robot{k + 1}", plugin="perf_robot", params=dict(params, x=xs[k], src=roster[k], scale=0.85 if nr <= 4 else 0.7, color=("a", "c", "a", "c", "a")[k % 5], accent=("b", "hot")[k % 2],
                                                                                           y=0.8 + 0.02 * (k % 2))))
        else:
            pv["layers"].append(dict(id=l["id"], plugin=l["plugin"], params=params))
    ids = {l["id"] for l in pv["layers"]}
    robots_ids = [l["id"] for l in pv["layers"] if l["plugin"] == "perf_robot"]
    for src, dst, prm, amt in tpl["links"]:
        pv["links"].append(dict(src=src, dst=dst, param=prm, amount=amt)) if dst in ids else None
    for rid in robots_ids:                                                           # każdy robot lekko świeci od własnego źródła
        r = next(l for l in pv["layers"] if l["id"] == rid)
        pv["links"].append(dict(src=r["params"]["src"], dst=rid, param="glow", amount=0.3))
        # domyślna formacja gdy kilka wykonawców — bez kolizji, ruch zbiorowy
    n_perf = sum(1 for L in pv["layers"] if str(L.get("plugin", "")).startswith("perf_"))
    if n_perf >= 2 and not pv.get("formation"):
        pv["formation"] = "orbit" if n_perf >= 3 else "line"
        pv["formation_sep"] = 0.14
        pv["formation_radius"] = 0.26
    if auto_cues:
        pv["cues"] = auto_cues_for(proj, pv)
    # warstwa planu: palette + cues z wektorów projektu (powtórzone motywy = ten sam addr)
    try:
        from . import plan as VPLAN
        plan = VPLAN.plan_project(proj)
        pv = VPLAN.apply_to_projvideo(pv, plan, proj, keep_palette=palette in PALETTES)         # wybrana paleta wygrywa z planem
    except Exception:
        pass
    return pv


def auto_cues_for(proj, pv):
    """Cue na każdą sekcję — spójny łuk kompozycji (role warstw + energia sekcji z dsproj)."""
    import random as _random
    return compose_cues(proj, pv, rng=_random.Random(0), strength=0.25, musical=True)




# ---- role warstw w kompozycji wizualnej (łatwiejsze ogarnięcie całości) ----
LAYER_ROLES = {
    "room": "tło / przestrzeń",
    "performer": "wykonawca / fokus",
    "brush": "akcent ruchomy",
    "camera": "ruch kamery",
    "fx": "postprodukcja",
    "overlay": "nakładka info",
}

# parametry typowe dla „oddechu” kompozycji w czasie (bezpieczne do modulacji)
BREATH_PARAMS = {
    "room": ("speed", "pulse", "react", "intensity", "fog", "detail", "height", "world", "zoom"),
    "performer": ("scale", "spin", "glow", "rings"),
    "brush": ("amount", "intensity", "count", "width", "length"),
    "camera": ("amount", "zoom_breathe", "speed", "shake"),
    "fx": ("amount", "mix", "threshold", "vignette"),
    "overlay": ("opacity", "height", "scale"),
}


def composition_summary(proj, pv) -> str:
    """Krótki, czytelny opis kompozycji wizualnej (GUI / log)."""
    layers = pv.get("layers") or []
    by_kind = {}
    for L in layers:
        pid = L.get("plugin", "")
        kind = getattr(VREG.get(pid), "kind", "?") if pid in VREG else "?"
        by_kind.setdefault(kind, []).append(L.get("id", pid))
    parts = []
    for kind in ("room", "performer", "brush", "camera", "fx", "overlay"):
        if kind in by_kind:
            role = LAYER_ROLES.get(kind, kind)
            parts.append(f"{role}: {', '.join(by_kind[kind])}")
    secs = proj.get("sections") or []
    cues = pv.get("cues") or []
    arc = " → ".join((s.get("type") or "?") for s in secs[:12])
    if len(secs) > 12:
        arc += "…"
    derived = "tak" if pv.get("derived") else "nie"
    strength = pv.get("derive_strength")
    head = f"Szablon: {pv.get('template', '?')} · paleta: {pv.get('palette', '?')} · pochodna: {derived}"
    if strength is not None:
        head += f" ({strength})"
    body = " | ".join(parts) if parts else "(brak warstw)"
    cue_n = len(cues)
    return f"{head}\nWarstwy: {body}\nŁuk sekcji ({len(secs)}): {arc or '—'} · cue: {cue_n}"


def _section_energy(s, k, nsec):
    """Energia sekcji z e0/e1 projektu albo z typu + pozycji."""
    e0 = s.get("e0"); e1 = s.get("e1")
    if e0 is not None or e1 is not None:
        a = float(e0 if e0 is not None else 0.5)
        b = float(e1 if e1 is not None else a)
        return 0.5 * (a + b)
    type_w = {"intro": 0.28, "build": 0.7, "drop": 1.0, "break": 0.38, "outro": 0.22}
    pos = k / max(1, nsec - 1)
    arc = 0.4 + 0.6 * (1.0 - abs(2.0 * pos - 1.0) ** 1.15)
    return arc * type_w.get(s.get("type") or "drop", 0.65)


def compose_cues(proj, pv, rng=None, strength=0.45, musical=True):
    """Buduje spójne cue na cały klip: role warstw + energia sekcji z dsproj + łagodne trajektorie.
    musical=True: mniej chaosu, czytelniejszy łuk (intro spokój → build napięcie → drop szczyt → break oddech → outro wygaszenie)."""
    import random as _random
    rng = rng or _random.Random()
    strength = max(0.0, min(1.0, float(strength)))
    sections = proj.get("sections") or [{"type": "drop", "start": 0, "bars": max(1, int(proj.get("bars") or 8)), "e0": 0.6, "e1": 0.6}]
    nsec = max(1, len(sections))

    # mapa warstw + kind
    layer_info = []
    for L in pv.get("layers") or []:
        pid = L.get("plugin")
        if pid not in VREG:
            continue
        cls = VREG.get(pid)
        kind = getattr(cls, "kind", "") or ""
        specs = cls.specs()
        base = dict(L.get("params") or {})
        layer_info.append(dict(id=L["id"], plugin=pid, kind=kind, specs=specs, base=base, layer=L))

    # parametry do oddechu per rola
    breath = []
    for info in layer_info:
        names = BREATH_PARAMS.get(info["kind"], ())
        for name in names:
            pm = info["specs"].get(name)
            if pm is None or pm.kind in ("choice", "bool"):
                continue
            val = info["base"].get(name, pm.default)
            try:
                val = float(val)
            except Exception:
                continue
            breath.append((info["id"], name, pm, val, info["kind"]))

    cues = []
    prev_mods = {}
    for k, s in enumerate(sections):
        stype = s.get("type") or "drop"
        e = _section_energy(s, k, nsec)
        # lekki smooth z poprzednią energią
        if k > 0:
            e = 0.65 * e + 0.35 * _section_energy(sections[k - 1], k - 1, nsec)
        # waga kompozycyjna
        w = max(0.08, min(1.15, e * (0.9 + 0.2 * strength)))
        if musical:
            # czytelniejsze progi
            if stype == "intro":
                w *= 0.85
            elif stype == "drop":
                w = min(1.2, w * 1.08)
            elif stype == "break":
                w *= 0.9
            elif stype == "outro":
                w *= 0.8

        mods = {}
        # 1) SECTION_MODS jako szkielet reżyserii
        for lid, m in SECTION_MODS.get(stype, SECTION_MODS["drop"]).items():
            targets = [x["id"] for x in layer_info if x["plugin"] == "perf_robot"] if lid == "robots" else [lid]
            for tid in targets:
                info = next((x for x in layer_info if x["id"] == tid), None)
                if not info:
                    continue
                mm = {}
                for pn, v in m.items():
                    pm = info["specs"].get(pn)
                    if pm is None or pm.kind in ("choice", "bool"):
                        continue
                    target = float(v) * (0.55 + 0.45 * w)
                    if musical and tid in prev_mods and pn in prev_mods[tid]:
                        # ogranicz skok względem poprzedniej sekcji
                        prev = float(prev_mods[tid][pn])
                        target = prev + max(-0.2, min(0.2, target - prev))
                    mm[pn] = pm.clamp(target)
                if mm:
                    mods.setdefault(tid, {}).update(mm)

        # 2) oddech ról: room/camera/fx jadą po łuku energii; brush mocniej na drop
        pos = k / max(1, nsec - 1)
        for tid, name, pm, base_val, kind in breath:
            frac = pm.frac(base_val)
            # trajektoria zależna od roli
            if kind == "room":
                # tło: wolny grow/shrink
                delta = 0.12 * strength * (w - 0.5) + 0.06 * strength * math.sin(pos * math.pi)
            elif kind == "camera":
                delta = 0.18 * strength * (w - 0.45) + (0.08 * strength if stype in ("drop", "build") else -0.03)
            elif kind == "brush":
                delta = 0.22 * strength * (w - 0.4) * (1.15 if stype == "drop" else 0.7)
            elif kind == "fx":
                delta = 0.2 * strength * max(0.0, w - 0.35)
            elif kind == "performer":
                delta = 0.1 * strength * (w - 0.5)
            else:
                delta = 0.08 * strength * (w - 0.5)
            if not musical:
                delta += rng.uniform(-0.1, 0.1) * strength
            else:
                delta += rng.uniform(-0.03, 0.03) * strength
            target_frac = max(0.0, min(1.0, frac + delta))
            mods.setdefault(tid, {})[name] = pm.from_frac(target_frac)

        prev_mods = {tid: dict(m) for tid, m in mods.items()}
        cues.append(dict(
            section=k,
            name=s.get("name") or stype,
            type=stype,
            energy=round(float(e), 3),
            weight=round(float(w), 3),
            mods=mods,
        ))
    return cues


def derive_projvideo(proj, pv, rng=None, strength=0.55, seed=None, musical=True):
    """Nowa pochodna dowolnego szablonu — spójniejsza kompozycja:
    - losuje parametry warstw w oknie wokół bazy (z zachowaniem tożsamości estetycznej),
    - dostosowuje wagi linków,
    - buduje cue na cały klip przez compose_cues (role + energia sekcji z dsproj),
    - zapisuje czytelne summary w meta.
    """
    import random as _random
    pv = copy.deepcopy(pv)
    if seed is not None:
        rng = _random.Random(int(seed))
    rng = rng or _random.Random()
    strength = max(0.05, min(1.0, float(strength)))

    keep_always = {"src", "color", "biome", "mode", "shape", "corner", "engine"}
    # delikatniejsze losowanie gdy musical — czytelniejsza kompozycja
    half_base = 0.06 + (0.28 if musical else 0.42) * strength

    for layer in pv.get("layers") or []:
        pid = layer.get("plugin")
        if pid not in VREG:
            continue
        cls = VREG.get(pid)
        pl = cls(**dict(layer.get("params") or {}))
        for pm in cls.PARAMS:
            if pm.name in keep_always:
                continue
            if pm.kind in ("choice", "bool"):
                if rng.random() < (0.12 if musical else 0.25) * strength:
                    if pm.kind == "bool":
                        pl.p[pm.name] = rng.random() < 0.5
                    elif pm.choices:
                        pl.p[pm.name] = rng.choice(list(pm.choices))
                continue
            frac = pm.frac(pl.p.get(pm.name, pm.default))
            lo = max(0.0, frac - half_base)
            hi = min(1.0, frac + half_base)
            if hi <= lo:
                lo, hi = 0.0, 1.0
            pl.p[pm.name] = pm.from_frac(rng.uniform(lo, hi))
        layer["params"] = dict(pl.p)

    for link in pv.get("links") or []:
        a = float(link.get("amount", 0.3))
        jitter = (0.12 if musical else 0.25) * strength
        link["amount"] = max(-1.0, min(1.0, a + rng.uniform(-jitter, jitter)))

    pv["cues"] = compose_cues(proj, pv, rng=rng, strength=strength, musical=musical)
    pv["derived"] = True
    pv["derive_strength"] = round(strength, 3)
    meta = pv.setdefault("meta", {})
    meta["derived"] = True
    meta["derive_seed"] = seed if seed is not None else rng.randint(0, 10 ** 9)
    meta["composition"] = composition_summary(proj, pv)
    return pv



def validate(pv):
    """Naprawia/odrzuca nieznane wtyczki i parametry (pv z pliku mógł powstać w innej wersji)."""
    pv = copy.deepcopy(pv); pv.setdefault("palette", "kraftwerk"); pv.setdefault("meta", {}); pv.setdefault("links", []); pv.setdefault("cues", []); pv.setdefault("fps", 30)
    pv.setdefault("size", [1280, 720]); pv["layers"] = [l for l in pv.get("layers", []) if l.get("plugin") in VREG]
    for l in pv["layers"]:
        specs = VREG.get(l["plugin"]).specs(); l["params"] = {k: specs[k].clamp(v) for k, v in (l.get("params") or {}).items() if k in specs}
    return pv


def save_projvideo(pv, path):
    Path(path).write_text(json.dumps(pv, ensure_ascii=False, indent=1), encoding="utf-8")
    return str(path)


def load_projvideo(path):
    return validate(json.loads(Path(path).read_text(encoding="utf-8")))
