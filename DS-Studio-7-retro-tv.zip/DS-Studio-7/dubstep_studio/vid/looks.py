"""looks.py — wspólny katalog „szablonów” wideo dla CAŁEGO programu (okno główne „Wideo / RTMP” i Live/Endless).

Jeden identyfikator wygląd (look id) opisuje, czym i jak rysujemy obraz:
  tpl:<szablon>   silnik SZABLONOWY (zdarzenia MIDI/sekcje projektu → warstwy: roboty, wiązki, kamera, postefekty)   np. tpl:live_show
  rx:<scena>      silnik REAKTYWNY (lekki, z dźwięku + plan pseudo-AI)                                              np. rx:morph, rx:auto
Obie listy (szablony i sceny) oraz palety pochodzą z tego jednego miejsca, więc obie zakładki pokazują to samo i da się je zsynchronizować.
Bez importów Qt; ciężkie moduły (templates/plugins) ładowane leniwie.
"""
from __future__ import annotations

DEFAULT_TEMPLATE = "live_show"
DEFAULT_SCENE = "auto"

# (scena, tytuł, opis) — reaktywny silnik livefx
REACTIVE = (
    ("auto", "Reaktywna: auto wg sekcji", "Lekki wizualizator z dźwięku; scena i paleta z planu utworu (build → tunel, drop → morph/pierścień, przerwy → spokojniej)"),
    ("morph", "Reaktywna: Morph (agenci)", "Agenci z wolumencja.py słuchający swoich pasm"),
    ("ring", "Reaktywna: Pierścień", "Widmo na okręgu z wiązkami"),
    ("tunnel", "Reaktywna: Tunel", "Tunel pulsujący z basem"),
    ("bars", "Reaktywna: Słupki", "Słupki widma z odbiciem"),
    ("scope", "Reaktywna: Oscyloskop", "Fala i widmo na środku"),
)


def _templates():
    from . import templates as TP
    return TP.list_templates()


def catalog() -> list[dict]:
    """Wspólna lista: najpierw szablony teledysku (silnik szablonowy), potem sceny reaktywne.
    Każdy wpis: id, title, desc, engine (template|reactive), template, scene, label (tekst do combo)."""
    out = []
    for t in _templates():
        out.append(dict(id=f"tpl:{t['id']}", title=t["title"], desc=t.get("desc", ""), engine="template", template=t["id"], scene=DEFAULT_SCENE,
                        label=f"{t['title']} — szablon MIDI" + (f" — {t['desc']}" if t.get("desc") else "")))
    for sc, title, desc in REACTIVE:
        out.append(dict(id=f"rx:{sc}", title=title, desc=desc, engine="reactive", template=DEFAULT_TEMPLATE, scene=sc, label=f"{title} — {desc}"))
    return out


def parse(look_id) -> dict:
    """look id → dict(engine, template, scene). Toleruje stare wartości (samo id szablonu, sama nazwa sceny) i śmieci → domyślny wygląd."""
    s = str(look_id or "").strip()
    if s.startswith("rx:"):
        sc = s[3:] or DEFAULT_SCENE
        return dict(engine="reactive", template=DEFAULT_TEMPLATE, scene=sc if sc == "auto" or sc in {r[0] for r in REACTIVE} else DEFAULT_SCENE)
    if s.startswith("tpl:"):
        s = s[4:]
    if s in {r[0] for r in REACTIVE} and s != "auto":                  # stara konwencja: sama nazwa sceny
        return dict(engine="reactive", template=DEFAULT_TEMPLATE, scene=s)
    return dict(engine="template", template=s or DEFAULT_TEMPLATE, scene=DEFAULT_SCENE)


def is_reactive(look_id) -> bool:
    return parse(look_id)["engine"] == "reactive"


def template_of(look_id) -> str:
    """Id szablonu dla kodu, który zna tylko silnik szablonowy (dla wyglądu reaktywnego — domyślny szablon)."""
    return parse(look_id)["template"]


def look_id_for(engine, template=None, scene=None) -> str:
    if str(engine or "").lower() == "template":
        return f"tpl:{template or DEFAULT_TEMPLATE}"
    return f"rx:{scene or DEFAULT_SCENE}"


def apply_to_av(av: dict, look_id) -> dict:
    """Wpisuje engine/template/scene wynikające z look id do słownika [video]/av (kopia)."""
    p = parse(look_id)
    return dict(av or {}, engine=p["engine"], template=p["template"], scene=p["scene"])


def palette_choices() -> list[str]:
    from .plugins import PALETTES
    return ["auto"] + list(PALETTES)


def fill_look_combo(combo, current=None):
    """Wypełnia QComboBox (addItem(text, data)) wspólnym katalogiem; data = look id. Zwraca liczbę pozycji."""
    for it in catalog():
        combo.addItem(it["label"], it["id"])
    if current is not None and hasattr(combo, "findData"):
        combo.setCurrentIndex(max(0, combo.findData(current)))
    return combo.count()


def fill_palette_combo(combo):
    combo.addItems(palette_choices())
    return combo


def mirror_combo(src, dst):
    """Przenosi wybór z jednego QComboBox do drugiego bez wywoływania sygnałów (dane = look id; palety bez danych = po tekście). Zwraca True, gdy zmieniono."""
    d = src.currentData()
    i = dst.findData(d) if d is not None else dst.findText(src.currentText())
    if i >= 0 and i != dst.currentIndex():
        dst.blockSignals(True); dst.setCurrentIndex(i); dst.blockSignals(False)
        return True
    return False
