"""canvas.py — płótno RGB float32 (h, w, 3), 0..1, tylko numpy (bez PIL — działa na SBC).
Prymitywy: gradient, prostokąt, linia, okrąg, poświata (addytywna), tekst (wbudowana czcionka 5x7), kadrowanie/zoom kamery."""
from __future__ import annotations

import numpy as np

# czcionka 5x7: kolumny (bit0 = górny wiersz)
_F = {
    " ": (0, 0, 0, 0, 0), "A": (0x7E, 0x11, 0x11, 0x11, 0x7E), "B": (0x7F, 0x49, 0x49, 0x49, 0x36), "C": (0x3E, 0x41, 0x41, 0x41, 0x22),
    "D": (0x7F, 0x41, 0x41, 0x22, 0x1C), "E": (0x7F, 0x49, 0x49, 0x49, 0x41), "F": (0x7F, 0x09, 0x09, 0x09, 0x01), "G": (0x3E, 0x41, 0x49, 0x49, 0x7A),
    "H": (0x7F, 0x08, 0x08, 0x08, 0x7F), "I": (0, 0x41, 0x7F, 0x41, 0), "J": (0x20, 0x40, 0x41, 0x3F, 0x01), "K": (0x7F, 0x08, 0x14, 0x22, 0x41),
    "L": (0x7F, 0x40, 0x40, 0x40, 0x40), "M": (0x7F, 0x02, 0x0C, 0x02, 0x7F), "N": (0x7F, 0x04, 0x08, 0x10, 0x7F), "O": (0x3E, 0x41, 0x41, 0x41, 0x3E),
    "P": (0x7F, 0x09, 0x09, 0x09, 0x06), "Q": (0x3E, 0x41, 0x51, 0x21, 0x5E), "R": (0x7F, 0x09, 0x19, 0x29, 0x46), "S": (0x46, 0x49, 0x49, 0x49, 0x31),
    "T": (0x01, 0x01, 0x7F, 0x01, 0x01), "U": (0x3F, 0x40, 0x40, 0x40, 0x3F), "V": (0x1F, 0x20, 0x40, 0x20, 0x1F), "W": (0x3F, 0x40, 0x38, 0x40, 0x3F),
    "X": (0x63, 0x14, 0x08, 0x14, 0x63), "Y": (0x07, 0x08, 0x70, 0x08, 0x07), "Z": (0x61, 0x51, 0x49, 0x45, 0x43),
    "0": (0x3E, 0x51, 0x49, 0x45, 0x3E), "1": (0, 0x42, 0x7F, 0x40, 0), "2": (0x42, 0x61, 0x51, 0x49, 0x46), "3": (0x21, 0x41, 0x45, 0x4B, 0x31),
    "4": (0x18, 0x14, 0x12, 0x7F, 0x10), "5": (0x27, 0x45, 0x45, 0x45, 0x39), "6": (0x3C, 0x4A, 0x49, 0x49, 0x30), "7": (0x01, 0x71, 0x09, 0x05, 0x03),
    "8": (0x36, 0x49, 0x49, 0x49, 0x36), "9": (0x06, 0x49, 0x49, 0x29, 0x1E), ":": (0, 0x36, 0x36, 0, 0), "-": (8, 8, 8, 8, 8), ".": (0, 0x60, 0x60, 0, 0),
    "/": (0x20, 0x10, 0x08, 0x04, 0x02), "!": (0, 0, 0x5F, 0, 0), "+": (8, 8, 0x3E, 8, 8), "#": (0x14, 0x7F, 0x14, 0x7F, 0x14), "%": (0x23, 0x13, 0x08, 0x64, 0x62),
    "_": (0x40, 0x40, 0x40, 0x40, 0x40), "*": (0x14, 0x08, 0x3E, 0x08, 0x14), "=": (0x14, 0x14, 0x14, 0x14, 0x14), ">": (0, 0x41, 0x22, 0x14, 0x08), "<": (0x08, 0x14, 0x22, 0x41, 0),
}
_GLYPH = {}
_GRAD = {}
_GAUSS = {}


def _glyph(ch):
    g = _GLYPH.get(ch)
    if g is None:
        cols = _F.get(ch, _F.get(ch.upper(), _F[" "]))
        g = np.array([[(c >> r) & 1 for c in cols] for r in range(7)], np.float32)
        _GLYPH[ch] = g
    return g


class Canvas:
    def __init__(self, w, h):
        self.w, self.h = int(w), int(h)
        self.img = np.zeros((self.h, self.w, 3), np.float32)

    # ---- całe płótno
    def clear(self, col=(0, 0, 0)):
        self.img[:] = col

    def gradient_v(self, c0, c1):
        """Gradient pionowy. Tło zwykle nie zmienia się między klatkami (ta sama paleta) → gotowy pasek (h,1,3) jest w cache,
        a wypełnienie to jedno rozgłoszenie zamiast linspace + 2 mnożeń + dodawania na pełnej klatce w każdej klatce."""
        key = (self.h, tuple(float(x) for x in c0), tuple(float(x) for x in c1))
        strip = _GRAD.get(key)
        if strip is None:
            if len(_GRAD) > 64:
                _GRAD.clear()
            t = np.linspace(0.0, 1.0, self.h, dtype=np.float32)[:, None, None]
            strip = _GRAD[key] = (np.asarray(c0, np.float32) * (1 - t) + np.asarray(c1, np.float32) * t).astype(np.float32)
        self.img[:] = strip

    def to_uint8(self):
        return (np.clip(self.img, 0, 1) * 255.0 + 0.5).astype(np.uint8)

    # ---- prymitywy
    def _blend(self, ys, xs, col, a, add):
        m = (ys >= 0) & (ys < self.h) & (xs >= 0) & (xs < self.w)
        ys, xs = ys[m], xs[m]
        if ys.size == 0:
            return
        col = np.asarray(col, np.float32)
        if add:
            np.add.at(self.img, (ys, xs), col * a) if ys.size < 64 else self._add_fast(ys, xs, col * a)
        else:
            self.img[ys, xs] = self.img[ys, xs] * (1 - a) + col * a

    def _add_fast(self, ys, xs, v):
        self.img[ys, xs] += v

    def rect(self, x0, y0, x1, y1, col, alpha=1.0, add=False):
        x0, x1 = sorted((int(round(x0)), int(round(x1)))); y0, y1 = sorted((int(round(y0)), int(round(y1))))
        x0, y0 = max(0, x0), max(0, y0); x1, y1 = min(self.w, x1), min(self.h, y1)
        if x1 <= x0 or y1 <= y0:
            return
        reg = self.img[y0:y1, x0:x1]
        col = np.asarray(col, np.float32)
        if add:
            reg += col * alpha
        else:
            reg *= (1 - alpha); reg += col * alpha

    def frame_rect(self, x0, y0, x1, y1, col, th=1, alpha=1.0, add=False):
        th = max(1, int(th))
        self.rect(x0, y0, x1, y0 + th, col, alpha, add); self.rect(x0, y1 - th, x1, y1, col, alpha, add)
        self.rect(x0, y0, x0 + th, y1, col, alpha, add); self.rect(x1 - th, y0, x1, y1, col, alpha, add)

    def line(self, x0, y0, x1, y1, col, th=1, alpha=1.0, add=True):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        if n > 4 * (self.w + self.h):
            return
        xs = np.linspace(x0, x1, n).round().astype(np.int32); ys = np.linspace(y0, y1, n).round().astype(np.int32)
        th = max(1, int(th)); horiz = abs(x1 - x0) >= abs(y1 - y0)          # grubość: th przesunięć prostopadle do kierunku linii
        for d in range(-(th // 2), th - th // 2):
            self._blend(ys + d, xs, col, alpha, add) if horiz else self._blend(ys, xs + d, col, alpha, add)

    def disc(self, cx, cy, r, col, alpha=1.0, add=False):
        r = max(1, int(r)); x0, x1 = int(cx) - r, int(cx) + r + 1; y0, y1 = int(cy) - r, int(cy) + r + 1
        X0, Y0, X1, Y1 = max(0, x0), max(0, y0), min(self.w, x1), min(self.h, y1)
        if X1 <= X0 or Y1 <= Y0:
            return
        yy, xx = np.ogrid[Y0:Y1, X0:X1]
        m = (((xx - cx) ** 2 + (yy - cy) ** 2) <= r * r)[..., None].astype(np.float32)
        col = np.asarray(col, np.float32); reg = self.img[Y0:Y1, X0:X1]
        if add:
            reg += m * col * alpha
        else:
            reg[:] = reg * (1 - m * alpha) + m * col * alpha

    def ring(self, cx, cy, r, col, th=2, alpha=1.0, add=True):
        r = max(2, int(r)); x0, x1 = int(cx) - r - th, int(cx) + r + th + 1; y0, y1 = int(cy) - r - th, int(cy) + r + th + 1
        X0, Y0, X1, Y1 = max(0, x0), max(0, y0), min(self.w, x1), min(self.h, y1)
        if X1 <= X0 or Y1 <= Y0:
            return
        yy, xx = np.ogrid[Y0:Y1, X0:X1]
        d = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
        m = (np.abs(d - r) <= th / 2.0)[..., None].astype(np.float32)
        col = np.asarray(col, np.float32); reg = self.img[Y0:Y1, X0:X1]
        if add:
            reg += m * col * alpha
        else:
            reg[:] = reg * (1 - m * alpha) + m * col * alpha

    def glow(self, cx, cy, r, col, k=1.0):
        """Addytywna poświata gaussowska o promieniu r."""
        r = max(2, int(r)); x0, x1 = int(cx) - r, int(cx) + r + 1; y0, y1 = int(cy) - r, int(cy) + r + 1
        X0, Y0, X1, Y1 = max(0, x0), max(0, y0), min(self.w, x1), min(self.h, y1)
        if X1 <= X0 or Y1 <= Y0 or k <= 0:
            return
        # gaussian jest rozdzielny: exp(-(dx²+dy²)/s) = exp(-dx²/s)·exp(-dy²/s) → 2 małe exp 1-D + iloczyn zewnętrzny zamiast exp na całym (2r+1)² polu
        s2 = 0.18 * r * r
        gx = np.exp(-((np.arange(X0, X1, dtype=np.float32) - np.float32(cx)) ** 2) / np.float32(s2))
        gy = np.exp(-((np.arange(Y0, Y1, dtype=np.float32) - np.float32(cy)) ** 2) / np.float32(s2))
        g = (gy[:, None] * gx[None, :])[..., None]
        self.img[Y0:Y1, X0:X1] += g * (np.asarray(col, np.float32) * np.float32(k))

    def text(self, x, y, s, scale=2, col=(1, 1, 1), alpha=1.0, align="left"):
        scale = max(1, int(scale)); s = str(s)
        wpx = len(s) * 6 * scale
        if align == "center":
            x -= wpx / 2
        elif align == "right":
            x -= wpx
        x, y = int(x), int(y)
        for k, ch in enumerate(s):
            g = _glyph(ch)
            if not g.any():
                continue
            big = np.kron(g, np.ones((scale, scale), np.float32))
            gx = x + k * 6 * scale
            X0, Y0 = max(0, gx), max(0, y); X1, Y1 = min(self.w, gx + big.shape[1]), min(self.h, y + big.shape[0])
            if X1 <= X0 or Y1 <= Y0:
                continue
            m = big[Y0 - y: Y1 - y, X0 - gx: X1 - gx][..., None]
            reg = self.img[Y0:Y1, X0:X1]
            reg[:] = reg * (1 - m * alpha) + m * np.asarray(col, np.float32) * alpha

    # ---- kamera: nearest-neighbour zoom/pan (z>=1, cx/cy 0..1 środek kadru)
    @staticmethod
    def zoom(img, z, cx=0.5, cy=0.5):
        h, w = img.shape[:2]
        if z <= 1.0005:
            return img
        vw, vh = w / z, h / z
        x0 = min(max(cx * w - vw / 2, 0), w - vw); y0 = min(max(cy * h - vh / 2, 0), h - vh)
        xs = (x0 + (np.arange(w) + 0.5) * vw / w).astype(np.int32).clip(0, w - 1)
        ys = (y0 + (np.arange(h) + 0.5) * vh / h).astype(np.int32).clip(0, h - 1)
        # kadrujemy do okna, które faktycznie jest próbkowane (przy zoomie z>1 to 1/z² klatki), potem 2 × take bez pośredniej kopii „fancy-index”
        yo, ye, xo, xe = int(ys[0]), int(ys[-1]) + 1, int(xs[0]), int(xs[-1]) + 1
        if ys[0] > ys[-1] or xs[0] > xs[-1]:                    # (nie zdarza się dla z>=1; zabezpieczenie)
            return img.take(ys, 0).take(xs, 1)
        return img[yo:ye, xo:xe].take(xs - xo, 1).take(ys - yo, 0)
