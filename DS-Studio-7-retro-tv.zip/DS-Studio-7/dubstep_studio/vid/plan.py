"""plan.py — warstwa pseudo-AI: wektory projektu → adres w codebooku → parametry wideo.

Po generate() projekt ma pełną strukturę (sekcje, tracki, style, energie). Ta warstwa
raz buduje `proj["video_plan"]` i nie przelicza decyzji estetycznych co klatkę:

  U = f(V_struct, V_role, V_rhythm, V_timbre, V_mood)
  a = argmin_k ||U - M[k]||
  params = Decode[a]

Powtórzone motywy (ten sam typ sekcji + hash instrumentów + gęstość rytmu) dostają
ten sam adres → spójny teledysk / Live bez regeneracji.

Użycie:
  plan_project(proj)           # zapisuje proj["video_plan"]
  params_at(plan, t_sec)       # lookup na osi czasu
  apply_to_projvideo(pv, plan) # cues/palette pod szablon
  reactive_for(proj)           # palette/scene/drop/calm dla livefx.Engine
"""
from __future__ import annotations

import hashlib
import math
from typing import Any

import numpy as np

# ---- wspólny język: grupy jak w signals / core (rozszerzone o v6) ----
GROUP_TYPES = {
    "kick": ("kick",),
    "snare": ("snare",),
    "hat": ("hat", "openhat"),
    "clap": ("clap",),
    "tom": ("tom", "conga"),
    "crash": ("crash", "ride", "cowbell"),
    "perc": ("hat", "shaker", "rim", "clap", "openhat", "ride", "cowbell", "conga", "glitch"),
    "bass": ("sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow", "acid", "bass808", "upright"),
    "lead": ("screech", "supersaw", "pluck", "stab", "theremin", "panflute", "handpan", "tongue",
             "piano", "hoover", "epiano", "organ", "harpsichord", "brass", "choir", "cello", "flute"),
    "pad": ("pad", "strings", "drone", "choir"),
    "vocal": ("vox", "speak"),
    "fx": ("riser", "boom", "zap", "glitch"),
}

SEC_TYPES = ("intro", "build", "drop", "break", "outro")
SEC_IDX = {s: i for i, s in enumerate(SEC_TYPES)}

# agresja stylu (0..1) — zgrubnie, bez importu generatora
STYLE_AGG = {
    "tearout": 0.95, "brostep": 0.85, "riddim": 0.75, "dubstep": 0.8, "drumstep": 0.85,
    "trap": 0.7, "edm": 0.65, "neurofunk": 0.9, "hard techno": 0.9, "techno": 0.7,
    "acid techno": 0.75, "psytrance": 0.8, "trance": 0.55, "house": 0.5, "electro": 0.65,
    "dnb": 0.8, "liquid dnb": 0.45, "melodic": 0.4, "deep": 0.3, "space electronica": 0.25,
    "berlin school": 0.2, "jazz": 0.2, "baroque": 0.15, "romantic": 0.15, "experimental": 0.7,
    "raw synthesis": 0.85,
}

PALETTES = ("kraftwerk", "neon", "acid", "sunset", "mono", "ice")
SCENES = ("morph", "ring", "tunnel", "bars", "scope")

# wymiary wektora U
DIM = 24


def _style_agg(style: str) -> float:
    s = (style or "").lower()
    best, score = 0.55, -1
    for k, v in STYLE_AGG.items():
        if k in s and len(k) > score:
            best, score = v, len(k)
    # hybrydy „A 60% + B 40%”: średnia ważona jeśli da się sparsować
    if "+" in s and "%" in s:
        parts = []
        for chunk in s.split("+"):
            chunk = chunk.strip()
            w = 50.0
            name = chunk
            if "%" in chunk:
                try:
                    num, name = chunk.split("%", 1)
                    w = float(num.strip())
                    name = name.strip()
                except Exception:
                    pass
            parts.append((_style_agg(name), w))
        if parts:
            tw = sum(w for _, w in parts) or 1.0
            return sum(a * w for a, w in parts) / tw
    return best


def _track_stats(proj: dict) -> dict:
    """Zliczenia nut i zestaw typów (bez mute)."""
    by_type: dict[str, int] = {}
    by_group: dict[str, int] = {g: 0 for g in GROUP_TYPES}
    total = 0
    for tr in proj.get("tracks") or []:
        if tr.get("mute"):
            continue
        notes = tr.get("notes") or []
        n = len(notes)
        if n == 0:
            continue
        ty = str(tr.get("type") or "")
        by_type[ty] = by_type.get(ty, 0) + n
        total += n
        for g, types in GROUP_TYPES.items():
            if ty in types:
                by_group[g] += n
    return dict(by_type=by_type, by_group=by_group, total=max(1, total))


def _density_in_span(proj: dict, start_bar: float, end_bar: float) -> dict:
    """Gęstość eventów w oknie taktów (przybliżenie: on w beat*4 ≈ bar*4 jeśli RES nieznany)."""
    # nuty: [on_beats, dur, key, vel] — on w beatach
    bpm = float(proj.get("bpm") or 140)
    beats_per_bar = 4.0
    t0 = float(start_bar) * beats_per_bar
    t1 = float(end_bar) * beats_per_bar
    span = max(0.25, t1 - t0)
    gcount = {g: 0 for g in GROUP_TYPES}
    for tr in proj.get("tracks") or []:
        if tr.get("mute"):
            continue
        ty = str(tr.get("type") or "")
        groups = [g for g, types in GROUP_TYPES.items() if ty in types]
        if not groups:
            continue
        for note in tr.get("notes") or []:
            try:
                on = float(note[0])
            except (TypeError, ValueError, IndexError):
                continue
            if t0 <= on < t1:
                for g in groups:
                    gcount[g] += 1
    # normalizacja: eventy / beat
    return {g: min(1.0, gcount[g] / (span * 2.0)) for g in GROUP_TYPES}


def _motif_hash(sec_type: str, types_present: frozenset, rhythm_sig: tuple) -> str:
    raw = f"{sec_type}|{','.join(sorted(types_present))}|{rhythm_sig}"
    return hashlib.blake2b(raw.encode(), digest_size=8).hexdigest()


def build_vector(proj: dict, sec: dict | None = None, start_bar: float = 0.0, end_bar: float = 8.0) -> np.ndarray:
    """Buduje wektor U ∈ R^DIM dla okna (sekcji lub dowolnego spanu)."""
    u = np.zeros(DIM, np.float32)
    st = _track_stats(proj)
    dens = _density_in_span(proj, start_bar, end_bar)
    style = str(proj.get("style") or "")
    agg = _style_agg(style)
    energy = float(proj.get("energy") if proj.get("energy") is not None else 0.7)
    density = float(proj.get("density") if proj.get("density") is not None else 0.6)
    bpm = float(proj.get("bpm") or 140)
    sec_type = (sec or {}).get("type") or "drop"
    sec_i = SEC_IDX.get(sec_type, 2) / max(1, len(SEC_TYPES) - 1)

    # [0..4] struktura
    u[0] = sec_i
    u[1] = min(1.0, (end_bar - start_bar) / 32.0)
    u[2] = energy
    u[3] = density
    u[4] = min(1.0, max(0.0, (bpm - 60.0) / 140.0))

    # [5..10] role / gęstości grup w oknie
    for i, g in enumerate(("kick", "bass", "lead", "perc", "pad", "vocal")):
        u[5 + i] = dens.get(g, 0.0)

    # [11..14] udział grup w całym utworze
    tot = float(st["total"])
    for i, g in enumerate(("bass", "lead", "perc", "fx")):
        u[11 + i] = min(1.0, st["by_group"].get(g, 0) / tot)

    # [15] agresja stylu
    u[15] = agg

    # [16..18] barwa: neuro/growl vs upright/jazz vs acoustic share
    hard = sum(st["by_type"].get(t, 0) for t in ("neuro", "growl", "screech", "hoover", "glitch", "tearout"))
    soft = sum(st["by_type"].get(t, 0) for t in ("upright", "epiano", "piano", "strings", "choir", "drone", "flute"))
    ac = sum(st["by_type"].get(t, 0) for t in ("theremin", "panflute", "handpan", "tongue", "vibes", "marimba", "bell"))
    u[16] = min(1.0, hard / tot)
    u[17] = min(1.0, soft / tot)
    u[18] = min(1.0, ac / tot)

    # [19] vocal presence
    u[19] = min(1.0, st["by_group"].get("vocal", 0) / tot * 4.0)

    # [20..22] pozycja w formie (jeśli znamy sekcje)
    sections = proj.get("sections") or []
    if sections and sec is not None:
        try:
            idx = sections.index(sec)
        except ValueError:
            idx = 0
        u[20] = idx / max(1, len(sections) - 1)
        # ile dropów przed tą sekcją
        drops_before = sum(1 for s in sections[:idx] if s.get("type") == "drop")
        u[21] = min(1.0, drops_before / 3.0)
    u[22] = 1.0 if sec_type == "drop" else 0.0
    u[23] = 1.0 if sec_type == "build" else (0.5 if sec_type == "break" else 0.0)

    # L2 normalize (stabilny lookup)
    nrm = float(np.linalg.norm(u))
    if nrm > 1e-6:
        u /= nrm
    return u


def _codebook() -> np.ndarray:
    """Stała macierz prototypów M (K, DIM) — regułowe centroidy bez treningu ML."""
    K = 48
    M = np.zeros((K, DIM), np.float32)
    rng = np.random.RandomState(99)
    for k in range(K):
        # bazowe osie: agresja, sekcja, vocal, soft/hard
        agg = (k % 8) / 7.0
        sec = ((k // 8) % 5) / 4.0
        soft = 1.0 - agg
        M[k, 0] = sec
        M[k, 2] = 0.4 + 0.5 * agg
        M[k, 3] = 0.3 + 0.5 * agg
        M[k, 5] = 0.2 + 0.6 * agg          # kick dens
        M[k, 6] = 0.3 + 0.4 * agg          # bass
        M[k, 7] = 0.2 + 0.5 * (1 - abs(agg - 0.5) * 2)  # lead peak mid
        M[k, 8] = 0.15 + 0.5 * agg
        M[k, 15] = agg
        M[k, 16] = agg
        M[k, 17] = soft
        M[k, 18] = max(0.0, 0.4 - agg)
        M[k, 19] = 0.1 * (k % 3)
        M[k, 22] = 1.0 if sec > 0.4 and sec < 0.7 else 0.0
        M[k, 23] = 1.0 if abs(sec - 0.25) < 0.15 else 0.0
        M[k] += rng.normal(0, 0.03, DIM).astype(np.float32)
        n = float(np.linalg.norm(M[k]))
        if n > 1e-6:
            M[k] /= n
    return M


_CODEBOOK = None


def codebook() -> np.ndarray:
    global _CODEBOOK
    if _CODEBOOK is None:
        _CODEBOOK = _codebook()
    return _CODEBOOK


def address(U: np.ndarray, M: np.ndarray | None = None) -> int:
    M = codebook() if M is None else M
    # cos similarity na znormalizowanych → min L2
    d = np.linalg.norm(M - U.reshape(1, -1), axis=1)
    return int(np.argmin(d))


def decode(addr: int, sec_type: str = "drop", seed: int = 0) -> dict:
    """Adres → parametry pędzli / scen / FX / kamery / palety (wspólny język z livefx + plugins)."""
    a = int(addr) % 48
    rng = __import__("random").Random((seed or 0) ^ (a * 2654435761 & 0xFFFFFFFF))
    agg = (a % 8) / 7.0
    band = a // 8  # 0..5

    # scena
    if sec_type == "build":
        scene = "tunnel"
    elif sec_type == "drop":
        scene = ("morph", "morph", "ring", "bars")[a % 4]
    elif sec_type in ("break", "outro"):
        scene = ("scope", "morph", "bars", "ring")[a % 4]
    else:
        scene = ("morph", "scope", "bars")[a % 3]

    # paleta wg agresji + band
    if agg >= 0.75:
        palette = ("neon", "acid", "kraftwerk")[a % 3]
    elif agg >= 0.45:
        palette = ("kraftwerk", "sunset", "neon", "ice")[a % 4]
    else:
        palette = ("ice", "sunset", "mono", "kraftwerk")[a % 4]

    fx = int(round(agg * 3))
    if sec_type in ("break", "outro", "intro"):
        fx = max(0, fx - 1)
    if sec_type == "drop":
        fx = min(3, fx + 1)

    cam = 0.15 + 0.55 * agg
    if sec_type == "drop":
        cam = min(0.9, cam + 0.2)
    if sec_type in ("intro", "outro"):
        cam *= 0.5

    return dict(
        addr=a,
        scene=scene,
        palette=palette,
        fx=fx,
        drop_scene=("morph", "ring")[a % 2],
        calm_scene=("morph", "scope", "bars")[a % 3],
        brush=dict(
            beams_intensity=round(0.2 + 0.7 * agg, 3),
            particles=round(0.1 + 0.7 * agg, 3),
            trail=round(0.2 + 0.5 * (1 - abs(agg - 0.5)), 3),
            src=("kick", "bass", "energy", "lead")[a % 4],
        ),
        camera=dict(amount=round(cam, 3), speed=round(0.1 + 0.25 * agg, 3), punch=round(0.3 + 0.5 * agg, 3)),
        post=dict(
            bloom=round(0.25 + 0.5 * agg, 3),
            glitch=round(0.05 + 0.45 * agg * (1.0 if sec_type in ("drop", "build") else 0.3), 3),
            strobe=round(0.0 if sec_type not in ("drop", "build") else 0.2 + 0.4 * agg, 3),
            scanlines=round(0.2 + 0.3 * (1 - agg), 3),
            mirror=round(0.5 * agg if sec_type == "drop" else 0.0, 3),
            vignette=round(0.25 + 0.2 * (1 - agg), 3),
        ),
        agents=int(16 + 32 * agg),
        seed_branch=rng.randint(0, 10_000),
    )


def plan_project(proj: dict, force: bool = False) -> dict:
    """Buduje i zapisuje proj['video_plan']. Idempotentne: ten sam motyw → ten sam addr."""
    try:
        from . import plan_grid as _PG
        sig = _PG.proj_signature(proj)
    except Exception:
        _PG, sig = None, None
    cached = proj.get("video_plan")
    if (not force and isinstance(cached, dict) and cached.get("spans")
            and (sig is None or cached.get("sig") in (None, sig))):   # plan z innej treści projektu = nieaktualny
        return cached

    sections = list(proj.get("sections") or [])
    if not sections:
        # fallback: jedna „drop” na cały utwór
        bars = int(proj.get("bars") or 32)
        sections = [dict(type="drop", start=0, bars=bars, name="drop")]

    seed = int(proj.get("seed") or 0)
    motif_map: dict[str, int] = {}
    spans = []
    M = codebook()

    for k, sec in enumerate(sections):
        st = float(sec.get("start") or 0)
        nb = float(sec.get("bars") or sec.get("length") or 8)
        en = st + nb
        sec_type = str(sec.get("type") or "drop")
        # typy obecne w oknie
        dens = _density_in_span(proj, st, en)
        types_present = frozenset(
            ty for tr in (proj.get("tracks") or [])
            if not tr.get("mute") and tr.get("notes")
            for ty in [str(tr.get("type") or "")]
            if any(dens.get(g, 0) > 0.02 for g, types in GROUP_TYPES.items() if ty in types)
        )
        rhythm_sig = (
            int(dens.get("kick", 0) * 10),
            int(dens.get("snare", 0) * 10),
            int(dens.get("perc", 0) * 10),
            int(dens.get("bass", 0) * 10),
        )
        mh = _motif_hash(sec_type, types_present, rhythm_sig)
        if mh in motif_map:
            addr = motif_map[mh]
        else:
            U = build_vector(proj, sec, st, en)
            addr = address(U, M)
            motif_map[mh] = addr
        params = decode(addr, sec_type, seed=seed + k * 17)
        spans.append(dict(
            i=k,
            type=sec_type,
            name=sec.get("name") or sec_type,
            start_bar=st,
            end_bar=en,
            motif=mh,
            addr=addr,
            params=params,
        ))

    # global: najczęstsza paleta z dropów / pierwsza
    drop_spans = [s for s in spans if s["type"] == "drop"] or spans
    palette = drop_spans[0]["params"]["palette"]
    plan = dict(
        version=2,
        dim=DIM,
        codebook_k=int(codebook().shape[0]),
        palette=palette,
        spans=spans,
        motif_map=motif_map,
        seed=seed,
    )
    if _PG is not None:
        plan["sig"] = sig
        try:
            plan["grid"] = _PG.build_grid(proj)      # siatka taktowa: macierz wektorów → adresy → parametry
        except Exception:
            plan["grid"] = None
    proj["video_plan"] = plan
    return plan


def params_at(plan: dict, t_sec: float, bpm: float = 140.0) -> dict | None:
    """Lookup parametrów dla czasu w sekundach (oś audio)."""
    if not plan or not plan.get("spans"):
        return None
    beats = float(t_sec) * float(bpm) / 60.0
    bar = beats / 4.0
    spans = plan["spans"]
    for s in spans:
        if s["start_bar"] <= bar < s["end_bar"]:
            return s["params"]
    # po końcu — ostatni
    if bar >= spans[-1]["end_bar"]:
        return spans[-1]["params"]
    return spans[0]["params"]


def span_at_bar(plan: dict, bar: float) -> dict | None:
    for s in plan.get("spans") or []:
        if s["start_bar"] <= bar < s["end_bar"]:
            return s
    return None


def reactive_for(proj: dict) -> dict:
    """Szybkie parametry dla livefx.Engine (palette, scene defaults, agents)."""
    plan = plan_project(proj)
    spans = plan.get("spans") or []
    drop = next((s for s in spans if s["type"] == "drop"), spans[0] if spans else None)
    calm = next((s for s in spans if s["type"] in ("break", "intro", "outro")), drop)
    p_drop = (drop or {}).get("params") or decode(0, "drop")
    p_calm = (calm or {}).get("params") or decode(1, "break")
    return dict(
        palette=plan.get("palette") or p_drop.get("palette") or "neon",
        drop_scene=p_drop.get("scene") or p_drop.get("drop_scene") or "morph",
        calm_scene=p_calm.get("scene") or p_calm.get("calm_scene") or "morph",
        agents=int(p_drop.get("agents") or 32),
        plan=plan,
    )


def apply_to_projvideo(pv: dict, plan: dict | None, proj: dict | None = None, keep_palette: bool = False) -> dict:
    """Wstrzykuje palette + cues z planu do projvideo (szablon template engine).
    keep_palette=True — paleta wybrana przez użytkownika zostaje (plan nadpisuje ją tylko przy „auto”), tak samo jak w silniku reaktywnym."""
    if plan is None and proj is not None:
        plan = plan_project(proj)
    if not plan:
        return pv
    pv = dict(pv)
    if not keep_palette:
        pal = plan.get("palette")
        if pal:
            pv["palette"] = pal
    # cues per section index
    cues = []
    for sp in plan.get("spans") or []:
        p = sp.get("params") or {}
        brush, cam, post = p.get("brush") or {}, p.get("camera") or {}, p.get("post") or {}
        mods = {
            "beams": {"intensity": brush.get("beams_intensity", 0.4)},
            "parts": {"amount": brush.get("particles", 0.3)},
            "cam": {"amount": cam.get("amount", 0.3)},
            "bloom": {"amount": post.get("bloom", 0.4)},
            "glitch": {"amount": post.get("glitch", 0.1)},
            "strobe": {"amount": post.get("strobe", 0.0)},
            "scan": {"amount": post.get("scanlines", 0.3)},
            "mirror": {"mix": post.get("mirror", 0.0)},
            "robots": {"glow": 0.3 + 0.5 * (p.get("fx") or 0) / 3.0},
        }
        cues.append(dict(section=int(sp.get("i") or 0), name=sp.get("name"), mods=mods, addr=sp.get("addr")))
    if cues:
        pv["cues"] = cues
    meta = dict(pv.get("meta") or {})
    meta["video_plan"] = dict(version=plan.get("version"), palette=plan.get("palette"), spans=len(plan.get("spans") or []))
    pv["meta"] = meta
    return pv


def ensure_plan(proj: dict) -> dict:
    """Zwraca plan; buduje jeśli brak."""
    return plan_project(proj, force=False)
