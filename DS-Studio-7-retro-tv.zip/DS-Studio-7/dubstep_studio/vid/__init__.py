"""vid — host renderu wideo + wtyczki (room / performer / brush / camera / fx / overlay) + plan (pseudo-AI)."""
def _tune_malloc():
    """Render klatki alokuje kilkadziesiąt tymczasowych tablic 11 MB na klatkę. Domyślny glibc oddaje je systemowi (mmap/munmap) i przy każdej klatce
    zdobywa na nowo → miliony błędów stron (page fault). Podniesienie progów mmap/trim sprawia, że bufory wracają do puli — ten sam wynik, mniej pracy jądra.
    Tylko Linux/glibc; wyłączenie: DS_NO_MALLOC_TUNE=1."""
    import os
    if os.environ.get("DS_NO_MALLOC_TUNE") == "1":
        return False
    try:
        import ctypes
        libc = ctypes.CDLL("libc.so.6")
        ok = libc.mallopt(-3, 32 * 1024 * 1024)      # M_MMAP_THRESHOLD: bufory < 32 MB z puli sterty (maks. dozwolone przez glibc)
        ok &= libc.mallopt(-1, 512 * 1024 * 1024)    # M_TRIM_THRESHOLD: nie zwracaj sterty do systemu po każdym free()
        ok &= libc.mallopt(-2, 64 * 1024 * 1024)     # M_TOP_PAD: rezerwuj sterty z zapasem
        return bool(ok)
    except Exception:
        return False


MALLOC_TUNED = _tune_malloc()
from .registry import VREG, list_plugins, make_plugin
from . import plugins as _plugins  # noqa: F401 — rejestracja
from . import host
from . import templates
from . import plan
from . import livefx

__all__ = [
    "VREG", "list_plugins", "make_plugin",
    "host", "templates", "plan", "livefx",
]
