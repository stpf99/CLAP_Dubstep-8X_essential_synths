"""livefx.py — LEKKIE wideo na żywo reagujące na dźwięk + automatyczny dobór jakości pod obciążenie komputera + nadawanie AV (RTMP).

Jak to działa (Live, track po tracku — generator bez zmian):
  * silnik Live odtwarza kolejną aranżację → każdy kawałek PCM trafia do `LiveAV.audio()` (to samo audio, które słyszy Icecast / głośniki),
  * `Analyzer` liczy z tego PCM widmo (40 pasm), głośność i „punch” (uderzenia stopy/basu) — dokładnie dla chwili klatki,
  * `Evolution` (agenci morfujący blob → gwiazda, wg wolumencja.py) + sceny `ring` / `tunnel` / `bars` / `scope` rysują klatkę samym numpy
    w małej rozdzielczości; ffmpeg skaluje ją do rozmiaru streamu,
  * `AutoTune` co sekundę patrzy na czas renderu, zajętość CPU, wolny RAM, zaległości i gubienie klatek i sam schodzi/wchodzi po drabince
    poziomów (rozdzielczość renderu, co którą klatkę liczyć, ilość efektów). Gdy generator renderuje nowy track, wideo dostaje „lżejszy” próg.
  * kodowanie: x264 `ultrafast` + `zerolatency`, bez B-klatek, niski bitrate, niski priorytet (nice) — żadnej ciężkiej kompresji.
Audio nigdy nie czeka na wideo: wideo ma własny wątek, a gdy nie nadąża — powtarza klatkę."""
from __future__ import annotations

import copy
import math
import os
import queue
import random
import subprocess
import threading
import time

import numpy as np

from .. import core
from .canvas import Canvas
from .host import LocalPreview, NullStreamer, RtmpStreamer, ffmpeg_bin
from .plugins import PALETTES

SR = core.SR
SCENES = ("morph", "ring", "tunnel", "bars", "scope")

# poziom: div = dzielnik rozdzielczości renderu względem rozmiaru rury do ffmpeg, skip = liczymy co skip-tą klatkę (reszta = powtórzenie), fx = efekty 0..3
LEVELS = (
    dict(div=1, skip=1, fx=3),
    dict(div=1, skip=1, fx=2),
    dict(div=2, skip=1, fx=2),
    dict(div=2, skip=2, fx=1),
    dict(div=3, skip=2, fx=1),
    dict(div=4, skip=3, fx=0),
    dict(div=4, skip=5, fx=0),
)
QUALITY = {"max": 0, "balanced": 2, "low": 4, "minimal": 5}

DEFAULT_VIDEO = dict(
    engine="reactive", width=854, height=480, fps=25, scene="auto", palette="auto", quality="auto",
    cpu_target=85, min_free_mb=200, nice=5, threads=2, v_codec="libx264", v_preset="ultrafast",
    title=True, pipe_div=2, agents=32, v_bitrate=1500, preview="off",
)


def _even(n):
    return max(2, int(n) // 2 * 2)


def parse_size(s, default=(854, 480)):
    try:
        w, h = str(s).lower().replace("×", "x").split("x")
        return _even(w), _even(h)
    except Exception:
        return default


def rel_cost(lv):
    """Względny koszt renderu poziomu (piksele × klatki/s × efekty) — do przewidywania, czy zmiana poziomu się opłaca."""
    return (1.0 / lv["div"] ** 2) * (1.0 / lv["skip"]) * (1.0 + 0.18 * lv["fx"])


def _hsv(h, s, v):
    h = np.asarray(h, np.float32); s = np.asarray(s, np.float32); v = np.asarray(v, np.float32)
    h6 = (h % 1.0) * 6.0; i = np.floor(h6).astype(int) % 6; f = h6 - np.floor(h6)
    p = v * (1 - s); q = v * (1 - f * s); t = v * (1 - (1 - f) * s)
    r = np.choose(i, [v, q, p, p, t, v]); g = np.choose(i, [t, v, v, q, p, p]); b = np.choose(i, [p, p, t, v, v, q])
    return np.stack([r, g, b], axis=-1).astype(np.float32)


# ------------------------------------------------------------------ analiza dźwięku
class Analyzer:
    """Strumieniowa analiza PCM (s16le stereo): pierścień próbek + FFT 2048 w chwili klatki. AGC sprawia, że obraz wygląda dobrze przy każdej głośności."""
    N = 2048

    def __init__(self, nb=40, sr=SR):
        self.sr, self.nb = sr, nb
        self.win = np.hanning(self.N).astype(np.float32)
        hz = sr / self.N
        e = np.geomspace(1.5, min(16000.0 / hz, self.N / 2 - 2), nb + 1)
        idx = np.round(e).astype(int)
        for i in range(1, len(idx)):
            if idx[i] <= idx[i - 1]:
                idx[i] = idx[i - 1] + 1
        self.idx = idx; self.widths = np.diff(idx).astype(np.float32)
        cen = (idx[:-1] + idx[1:]) / 2.0 * hz
        self.i_low, self.i_mid, self.i_high = cen < 160, (cen >= 160) & (cen < 2500), cen >= 2500
        self.R = 16384
        self.buf = np.zeros(self.R, np.float32); self.total = 0
        self.pk, self.rms_pk, self.lo_avg, self.pe, self._last = 1.2, 0.08, 0.0, 0.0, 0
        self.wave_idx = None

    def push(self, b):
        a = np.frombuffer(b, dtype="<i2")
        if a.size % 2:
            a = a[:-1]
        if not a.size:
            return
        m = a.reshape(-1, 2).astype(np.float32).sum(axis=1) * (0.5 / 32768.0)
        self.buf = np.concatenate((self.buf, m))[-self.R:]; self.total += m.size

    def feat(self, pos):
        pos = int(pos)
        dt = min(0.5, max(1e-3, (pos - self._last) / self.sr)); self._last = pos
        end = min(max(len(self.buf) - (self.total - pos), 0), len(self.buf))
        seg = self.buf[max(0, end - self.N): end]
        if len(seg) < self.N:
            seg = np.concatenate((np.zeros(self.N - len(seg), np.float32), seg))
        mag = np.abs(np.fft.rfft(seg * self.win))[: self.idx[-1]] * (4.0 / self.N)
        bands = np.add.reduceat(mag, self.idx[:-1]) / self.widths
        db = np.log1p(bands * 40.0)
        self.pk = max(1.2, float(db.max()), self.pk * math.exp(-dt / 12.0))
        spec = np.clip(db / self.pk, 0, 1).astype(np.float32)
        low, mid, high = float(spec[self.i_low].mean()), float(spec[self.i_mid].mean()), float(spec[self.i_high].mean())
        rms = float(np.sqrt(np.mean(seg[-1024:] ** 2)))
        self.rms_pk = max(0.05, rms, self.rms_pk * math.exp(-dt / 12.0))
        self.lo_avg += (low - self.lo_avg) * min(1.0, dt / 0.35)
        punch = float(np.clip((low - self.lo_avg) * 3.2, 0, 1)) if rms > 1e-4 else 0.0
        self.pe = max(punch, self.pe * math.exp(-dt / 0.10))
        return dict(spec=spec, low=low, mid=mid, high=high, rms=min(1.0, rms / self.rms_pk), level=rms, punch=self.pe, wave=seg)


# ------------------------------------------------------------------ ewolucja agentów (wg wolumencja.py, zwektoryzowana, sterowana dźwiękiem)
class Evolution:
    """Mała populacja (≤ cap) morfujących kształtów. Reguły jak w wolumencja.py: brak hybrydyzacji, rozmiar i temperatura nie dają przewagi,
    ochrona mniejszości kolorystycznej i zimnych barw. Dźwięk: kolor agenta = pasmo widma, które „słucha” (jego rozmiar i energia rosną z pasmem),
    stopa pulsuje i rodzi nowych, wysokie tony zaostrzają kształt, bas przyciąga, głośność przyspiesza."""
    W, H = 1280.0, 720.0
    SZ = 3.4                               # wolumencja.py rysuje kropki 2,5–5,5 px na 720p; tu mają być widoczne w małym renderze
    KEYS = ("x", "y", "vx", "vy", "base", "age", "energy", "hue", "sat", "val", "speed", "attr", "growth", "cplx", "spk", "rot", "be")

    def __init__(self, cap=32, seed=None):
        self.cap = int(cap); self.rng = np.random.default_rng(seed)
        self.g = {k: np.zeros(self.cap, np.float32) for k in self.KEYS}
        self.alive = np.zeros(self.cap, bool); self.prev_punch = 0.0
        for _ in range(min(26, self.cap - 2)):
            self._spawn()

    @property
    def n(self):
        return int(self.alive.sum())

    def _spawn(self, parent=None, x=None, y=None):
        free = np.nonzero(~self.alive)[0]
        if not free.size:
            return None
        i = int(free[0]); r = self.rng; g = self.g
        if parent is None:
            vals = dict(base=r.uniform(2.5, 5.5), hue=r.uniform(0, 1), sat=r.uniform(0.45, 0.95), val=r.uniform(0.55, 1.0), speed=r.uniform(0.5, 1.5),
                        attr=r.uniform(-0.3, 0.5), growth=r.uniform(0.0018, 0.0045), cplx=r.uniform(0, 0.25), spk=float(r.integers(2, 6)))
            for k, v in vals.items():
                g[k][i] = v
            g["x"][i] = r.uniform(60, self.W - 60) if x is None else x; g["y"][i] = r.uniform(60, self.H - 60) if y is None else y
            g["energy"][i] = 1.0
        else:
            for k in self.KEYS:
                g[k][i] = g[k][parent]
            g["x"][i] = g["x"][parent] + r.uniform(-16, 16); g["y"][i] = g["y"][parent] + r.uniform(-16, 16)
            g["energy"][i] = g["energy"][parent] * 0.5; g["energy"][parent] *= 0.5
            g["age"][i] = 0; g["base"][i] = r.uniform(2.5, 5.5)
        g["vx"][i] = r.uniform(-1.3, 1.3); g["vy"][i] = r.uniform(-1.3, 1.3); g["age"][i] = 0
        self.alive[i] = True
        if parent is not None:
            self._mutate(np.array([i]), 0.15)
        return i

    def _mutate(self, idx, s):
        """Tylko własna mutacja (nigdy hybrydyzacja)."""
        if not len(idx):
            return
        g, r = self.g, self.rng
        g["hue"][idx] = (g["hue"][idx] + r.normal(0, s, len(idx))) % 1.0
        for k, lo, hi in (("sat", 0.35, 1.0), ("val", 0.5, 1.0), ("speed", 0.3, 2.0), ("attr", -0.4, 0.8), ("growth", 0.001, 0.005), ("cplx", 0.0, 1.0)):
            g[k][idx] = np.clip(g[k][idx] + r.normal(0, s, len(idx)) * (0.05 if k == "growth" else 1.0), lo, hi)
        g["spk"][idx] = np.clip(g["spk"][idx] + r.integers(-1, 2, len(idx)), 2, 8)

    def sizes(self, idx=None):
        g = self.g; i = np.nonzero(self.alive)[0] if idx is None else idx
        grown = g["base"][i] + g["age"][i] * g["growth"][i]
        return np.clip(grown * (0.92 + 0.16 * np.sin(g["age"][i] * 0.021)) * self.SZ, 6.0, 130.0)

    def update(self, A, nsteps):
        """Jedna aktualizacja na klatkę wideo: sprzężenie z dźwiękiem + nsteps kroków fizyki."""
        g, r = self.g, self.rng
        idx = np.nonzero(self.alive)[0]
        if len(idx) < 8:                                    # wymarcie → świeża populacja
            for _ in range(12):
                self._spawn()
            idx = np.nonzero(self.alive)[0]
        spec, nb = A["spec"], len(A["spec"])
        band = np.clip((np.minimum(g["hue"][idx], 0.85) / 0.85 * nb).astype(int), 0, nb - 1)
        be = spec[band]
        g["be"][idx] = np.maximum(be, g["be"][idx] * 0.82)
        p, rms, low = A["punch"], A["rms"], A["low"]
        if p > 0.55 and self.prev_punch < 0.35:             # uderzenie: impuls od środka + narodziny
            cx, cy = self.W / 2, self.H / 2
            dx, dy = g["x"][idx] - cx, g["y"][idx] - cy; d = np.hypot(dx, dy) + 1.0
            g["vx"][idx] += dx / d * 0.7 * p; g["vy"][idx] += dy / d * 0.7 * p
            for _ in range(2):
                al = np.nonzero(self.alive & (g["energy"] > 0.48))[0]
                if al.size and self.n < self.cap:
                    self._spawn(parent=int(r.choice(al)))
        self.prev_punch = p
        for _ in range(nsteps):                              # podziały: kopia + własna mutacja (jak w wolumencja.py)
            if self.n < self.cap and r.random() < 0.0065:
                al = np.nonzero(self.alive & (g["energy"] > 0.48))[0]
                if al.size:
                    self._spawn(parent=int(r.choice(al)))
        idx = np.nonzero(self.alive)[0]
        agn = 0.5 + 0.9 * low; spm = 0.7 + 1.6 * rms
        x, y, vx, vy = (g[k][idx].copy() for k in ("x", "y", "vx", "vy"))
        attr, spd, hue, ben = g["attr"][idx], g["speed"][idx], g["hue"][idx], g["be"][idx]
        m = len(idx); eye = np.eye(m, dtype=bool)
        for _ in range(nsteps):
            size = self.sizes(idx)
            dx = x[None, :] - x[:, None]; dy = y[None, :] - y[:, None]
            dist = np.hypot(dx, dy) + 1e-3
            near = (dist < 280) & ~eye
            F = np.clip((attr[:, None] + attr[None, :]) * agn * 0.32 / (dist * 0.024), -30, 30) * near
            fx = (F * dx / dist).sum(1); fy = (F * dy / dist).sum(1)
            nx, ny = dx / dist, dy / dist
            hit = near & (dist < (size[:, None] + size[None, :]) * 0.58)
            dot = (vx[:, None] - vx[None, :]) * nx + (vy[:, None] - vy[None, :]) * ny
            imp = np.where(hit & (dot > 0), dot, 0.0)
            vx -= (imp * nx).sum(1) * 0.95; vy -= (imp * ny).sum(1) * 0.95
            mutate_i = np.nonzero(hit.any(1) & (r.random(m) < 0.16))[0]
            if mutate_i.size:
                sub = idx[mutate_i]; self._mutate(sub, 0.09); hue = g["hue"][idx]
            fx += (self.W / 2 - x) * 0.0017; fy += (self.H / 2 - y) * 0.0017           # lekkie przyciąganie do środka kadru
            vx = (vx + fx * 0.065) * 0.986; vy = (vy + fy * 0.065) * 0.986
            x += vx * spd * spm; y += vy * spd * spm
            for arr, v, hi in ((x, vx, self.W - 28), (y, vy, self.H - 28)):
                lo_m = arr < 28; hi_m = arr > hi
                arr[lo_m] = 28; v[lo_m] = np.abs(v[lo_m]); arr[hi_m] = hi; v[hi_m] = -np.abs(v[hi_m])
            g["age"][idx] += 1
            similar = (np.abs(hue[:, None] - hue[None, :]) < 0.11).sum(1)
            rare = 1.0 / np.maximum(similar, 1)                                    # ochrona mniejszości
            en = g["energy"][idx] * (0.9992 - 0.00025 * rare) + 0.0012 * ben        # dźwięk karmi agentów swojego pasma
            temp = np.where((hue >= 0.45) & (hue <= 0.78), 0.12 + (0.78 - hue) * 0.4, 0.65 + np.minimum(hue, 1 - hue) * 0.35)
            en = np.where(temp < 0.38, np.minimum(1.85, en + 0.0006), en)           # ochrona zimnych
            g["energy"][idx] = np.minimum(en, 1.85)
        g["x"][idx], g["y"][idx], g["vx"][idx], g["vy"][idx] = x, y, vx, vy
        self.alive &= g["energy"] > 0.055
        g["rot"][idx] += 0.012 + 0.09 * A["high"]


# ------------------------------------------------------------------ rysowanie
def _blur3(img):
    b = (img + np.roll(img, 3, 1) + np.roll(img, -3, 1)) * (1.0 / 3.0)
    return (b + np.roll(b, 3, 0) + np.roll(b, -3, 0)) * (1.0 / 3.0)


class Viz:
    """Płótno renderu w rozdzielczości (w, h): geometria liczona raz, każda klatka to kilka operacji numpy (float32)."""
    _m = {}          # kanały planu dla bieżącej klatki (puste = zachowanie jak dawniej)

    def __init__(self, w, h, nb=40):
        self.w, self.h, self.nb = int(w), int(h), nb
        yy, xx = np.mgrid[0:self.h, 0:self.w]
        self.xs = np.arange(self.w, dtype=np.float32); self.ys = np.arange(self.h, dtype=np.float32)
        s = self.h / 2.0
        u = ((xx - self.w / 2.0) / s).astype(np.float32); v = ((yy - self.h / 2.0) / s).astype(np.float32)
        self.rad = np.sqrt(u * u + v * v).astype(np.float32)
        th = np.abs(np.arctan2(u, v)) / np.pi                        # 0 u dołu → 1 u góry, lustrzanie
        self.ring_idx = np.minimum((th * (nb - 1)).astype(np.int32), nb - 1)
        sg = (th * nb) % 1.0; self.ring_gap = (sg > 0.12) & (sg < 0.88)
        self.th2 = (np.arctan2(v, u) / (2 * np.pi) + 0.5).astype(np.float32)
        self.inv = (1.0 / (self.rad + 0.08)).astype(np.float32)
        self.k3 = np.clip(self.rad, 0, 1)[..., None].astype(np.float32)
        self.vig = np.clip(1.0 - 0.45 * self.rad ** 2, 0.25, 1.0)[..., None].astype(np.float32)
        cx = np.abs(np.arange(self.w) - self.w / 2.0) / (self.w / 2.0)
        self.col_idx = np.minimum((cx * (nb - 1)).astype(np.int32), nb - 1)
        self.col_gap = (((cx * nb) % 1.0) > 0.18)
        self.floor = self.h * 0.78
        self.yfl = (self.floor - np.arange(self.h, dtype=np.float32))[:, None]
        self.wave_idx = np.linspace(0, Analyzer.N - 1, self.w).astype(np.int32)
        self.acc = np.zeros((self.h, self.w, 3), np.float32)
        self.pal = None; self.bg = None; self.txt = None; self.txt_ver = -1
        self.rng = np.random.default_rng(1)

    def reset(self):
        self.acc[:] = 0

    def set_palette(self, name):
        if name == self.pal:
            return
        P = PALETTES.get(name) or PALETTES["neon"]; self.pal = name
        self.pa, self.pb, self.pc, self.ph_ = (np.asarray(P[k], np.float32) for k in ("a", "b", "c", "hot"))
        gy = np.linspace(0, 1, self.h, dtype=np.float32)[:, None, None]
        self.bg = (np.asarray(P["bg0"], np.float32) * (1 - gy) + np.asarray(P["bg1"], np.float32) * gy) * np.ones((1, self.w, 1), np.float32)

    def set_text(self, title, sub, ver):
        c = Canvas(self.w, self.h); sc = max(1, int(round(self.h / 130.0)))
        if sub:
            c.text(6 * sc, 5 * sc, sub, sc, (1, 1, 1), 1.0, "left")
        if title:
            c.text(self.w / 2, self.h - 12 * sc, title, sc, (1, 1, 1), 1.0, "center")
        m = c.img[..., :1].copy()
        self.txt = m * (0.55 * self.pb + 0.45); self.txt_ver = ver

    # ---- sceny (dodają światło do self.acc)
    def _morph(self, A, evo, fx):
        g = evo.g; idx = np.nonzero(evo.alive)[0]
        if not idx.size:
            return
        kx, ky = self.w / evo.W, self.h / evo.H
        X, Y = g["x"][idx] * kx, g["y"][idx] * ky
        S = evo.sizes(idx) * ky * (0.7 + 0.8 * g["be"][idx] + 0.35 * A["punch"]) * (0.8 + 0.4 * self._m.get("particles", 0.5))
        S = np.maximum(S, 1.2)
        mo = np.clip(g["cplx"][idx] + g["age"][idx] * 0.00055 + 0.4 * A["high"], 0, 1)
        amp = np.clip((mo - 0.2) / 0.8, 0, 1) * 0.75
        lobes = g["spk"][idx]; rot = g["rot"][idx]
        col = _hsv(g["hue"][idx], g["sat"][idx], g["val"][idx]) * np.clip(g["energy"][idx], 0.25, 1.2)[:, None]
        halo = fx >= 2
        for k in range(len(idx)):
            s_, a_ = float(S[k]), float(amp[k]); R = s_ * (1 + a_) + 2.0
            Rb = R * (2.0 if halo else 1.0)
            x0, x1 = max(0, int(X[k] - Rb)), min(self.w, int(X[k] + Rb) + 2); y0, y1 = max(0, int(Y[k] - Rb)), min(self.h, int(Y[k] + Rb) + 2)
            if x1 <= x0 or y1 <= y0:
                continue
            ddx = self.xs[x0:x1][None, :] - X[k]; ddy = self.ys[y0:y1][:, None] - Y[k]
            d = np.sqrt(ddx * ddx + ddy * ddy)
            rs = s_ * (1 + a_ * np.cos(float(lobes[k]) * np.arctan2(ddy, ddx) + float(rot[k]))) if a_ > 0.03 else s_
            f = np.clip(rs - d + 0.5, 0, 1)
            if halo:
                f = f * 0.85 + np.exp(-(d / (s_ * 1.8)) ** 2) * 0.22
            else:
                f = f * 0.85
            self.acc[y0:y1, x0:x1] += f[..., None] * col[k]

    def _ring(self, A, t, fx, p):
        s = A["spec"][self.ring_idx]
        r0 = 0.30 + 0.05 * p
        ln = (0.03 + 0.55 * s * (0.6 + 0.4 * A["rms"])) * (0.75 + 0.5 * self._m.get("beams", 0.5))
        d = self.rad - r0
        body = (d > 0) & (d < ln) & self.ring_gap
        fr = np.clip(d / np.maximum(ln, 1e-3), 0, 1)
        fb = body * fr; fa = body * (1 - fr)
        self.acc += fa[..., None] * self.pa + fb[..., None] * self.pb
        self.acc += (np.exp(-(d * 45.0) ** 2) * 0.7)[..., None] * self.pc
        self.acc += (np.exp(-(self.rad / (0.16 + 0.08 * p)) ** 2 * 3.0) * (0.3 + 0.7 * p))[..., None] * self.pc

    def _tunnel(self, A, t, fx, p, speed):
        z = self.inv * 0.45 + t * speed + 0.25 * p
        rings = np.exp(-(((z % 1.0) - 0.5) * (7 + 8 * A["high"])) ** 2)
        f = rings
        if fx >= 1:
            f = f + 0.6 * np.exp(-((((self.th2 * 10 + t * 0.07) % 1.0) - 0.5) * 9.0) ** 2)
        f = np.clip(f, 0, 1.2) * np.clip(self.rad * 1.4, 0, 1) * (0.35 + 0.9 * A["rms"] + 0.6 * p) * (0.75 + 0.5 * self._m.get("beams", 0.5))
        self.acc += f[..., None] * (self.pa + (self.pc - self.pa) * self.k3)

    def _bars(self, A, t, fx, p):
        hh = A["spec"][self.col_idx] * self.h * 0.62 * (0.75 + 0.5 * self._m.get("beams", 0.5))
        up = (self.yfl > 0) & (self.yfl < hh[None, :]) & self.col_gap[None, :]
        fr = np.clip(self.yfl / np.maximum(hh[None, :], 1.0), 0, 1)
        self.acc += (up * fr)[..., None] * self.pb + (up * (1 - fr))[..., None] * self.pa
        if fx >= 1:
            rf = (self.yfl < 0) & (-self.yfl < hh[None, :] * 0.35) & self.col_gap[None, :]
            self.acc += (rf * 0.25)[..., None] * self.pc

    def _scope(self, A, t, fx, p):
        wv = A["wave"][self.wave_idx]
        gain = 0.9 / max(0.12, float(np.abs(wv).max()))
        ys = np.clip((self.h * 0.5 - wv * gain * self.h * 0.32).astype(np.int32), 1, self.h - 2)
        for dy, a in ((0, 1.0), (-1, 0.5), (1, 0.5)):
            self.acc[ys + dy, np.arange(self.w)] += self.pb * a
        e = A["spec"][self.col_idx] * self.h * 0.4
        for sgn in (-1, 1):
            yy = np.clip((self.h * 0.5 + sgn * e).astype(np.int32), 1, self.h - 2)
            self.acc[yy, np.arange(self.w)] += self.pa * 0.8
        self.acc += (np.exp(-(((self.ys - self.h / 2.0) / self.h) * 14) ** 2)[:, None, None] * 0.12) * self.pc

    def _vig_for(self, v):
        """Winieta o sile z planu (cache po kwantyzacji 0.02) — bez przeliczania rad² w każdej klatce."""
        k = int(round(float(v) / 0.02))
        c = self.__dict__.setdefault("_vigc", {})
        if k not in c:
            if len(c) > 32:
                c.clear()
            c[k] = np.clip(1.0 - (0.45 * (k * 0.02) / 0.35) * self.rad ** 2, 0.25, 1.0)[..., None].astype(np.float32)
        return c[k]

    def render(self, A, t, scene, fx, evo, pal, txt_a, drop=False, mod=None):
        """mod: kanały planu pseudo-AI dla tej klatki (vid.plan_grid.FrameTrack.at) — None/{} = dawne zachowanie."""
        self.set_palette(pal)
        p = A["punch"]
        m = mod or {}
        self._m = m
        decay = {"morph": 0.80, "ring": 0.78, "tunnel": 0.55, "bars": 0.70, "scope": 0.86}.get(scene, 0.75) if fx >= 1 else 0.45
        if m and fx >= 1:
            decay = min(0.92, max(0.4, decay + (m.get("trail", 0.45) - 0.45) * 0.3))
        self.acc *= decay
        if scene == "morph":
            self._morph(A, evo, fx)
        elif scene == "ring":
            self._ring(A, t, fx, p)
        elif scene == "tunnel":
            self._tunnel(A, t, fx, p, 0.25 + 0.6 * A["rms"])
        elif scene == "bars":
            self._bars(A, t, fx, p)
        else:
            self._scope(A, t, fx, p)
        bloom = m.get("bloom") if m else None
        if fx >= 2 and (bloom is None or bloom > 0.05):
            out = self.acc + (0.45 if bloom is None else 0.9 * bloom) * _blur3(self.acc)   # bloom 0.5 ≡ dawne 0.45
        else:
            out = self.acc.copy()
        out += self.bg
        if fx >= 1:
            out *= self.vig if not m or "vignette" not in m else self._vig_for(m["vignette"])
            out *= 1.0 + 0.15 * p
            sb = m.get("strobe", 0.0) if m else 0.0
            if sb > 0.02 and p > 0.5:                                  # strobo: błysk na mocnym uderzeniu
                out *= 1.0 + sb * (p - 0.5) * 1.2
        if fx >= 2 and m:
            sc = m.get("scanlines", 0.0)
            if sc > 0.05:
                out[::2] *= 1.0 - 0.5 * sc
            mi = m.get("mirror", 0.0)
            if mi > 0.03:                                              # lustro: lewa połowa rzutowana na prawą
                wh = self.w // 2
                out[:, self.w - wh:] = out[:, self.w - wh:] * (1.0 - mi) + out[:, :wh][:, ::-1] * mi
        if fx >= 3:
            if m:
                nbands = int(round(m.get("glitch", 0.0) * 6.0)) if p > 0.45 else 0
            else:
                nbands = 2 if (drop and p > 0.6) else 0
            for _ in range(nbands):                                    # glitch: przesunięte pasy + rozjazd kanału R
                y0 = int(self.rng.integers(0, max(1, self.h - 8))); hh = int(self.rng.integers(2, max(3, self.h // 12)))
                sh = int(self.rng.integers(-max(1, self.w // 12), max(2, self.w // 12)))
                out[y0:y0 + hh] = np.roll(out[y0:y0 + hh], sh, axis=1)
            if nbands:
                out[..., 0] = np.roll(out[..., 0], 2, axis=1)
        if m and fx >= 1:                                              # kamera: drżenie ∝ amount·punch·uderzenie
            sh = m.get("cam_amount", 0.0) * m.get("cam_punch", 0.0) * p * self.w * 0.03
            dx, dy = int(round(sh * math.sin(t * 37.0))), int(round(sh * 0.5 * math.cos(t * 29.0)))
            if dx or dy:
                out = np.roll(out, (dy, dx), (0, 1))
        if self.txt is not None and txt_a > 0.01:
            out += self.txt * txt_a
        np.clip(out, 0, 1, out=out); out *= 255.0
        return (out + 0.5).astype(np.uint8)


# ------------------------------------------------------------------ silnik klatek (analiza + scena + poziom)
def _palette_for(style, seed):
    s = (style or "").lower()
    for k, p in (("dnb", "kraftwerk"), ("drum", "kraftwerk"), ("riddim", "acid"), ("brostep", "neon"), ("trap", "sunset"), ("house", "sunset"),
                 ("techno", "ice"), ("trance", "ice"), ("psy", "acid"), ("electro", "neon"), ("chill", "ice")):
        if k in s:
            return p
    names = ("kraftwerk", "neon", "acid", "sunset", "ice")
    return names[int(seed or 0) % len(names)]


class Engine:
    def __init__(self, pw, ph, fps, cfg=None):
        self.cfg = dict(DEFAULT_VIDEO); self.cfg.update({k: v for k, v in (cfg or {}).items() if v not in (None, "")})
        self.pw, self.ph, self.fps = int(pw), int(ph), int(fps)
        self.an = Analyzer(); self.evo = Evolution(int(self.cfg["agents"]), seed=None)
        self.vz = {}; self.tr = None; self.t_begin = 0.0; self.txt_ver = 0; self.pal = "neon"
        self._up = {}; self._cur_div = None; self._last_k = 0

    def _viz(self, div):
        v = self.vz.get(div)
        if v is None:
            v = self.vz[div] = Viz(max(16, self.pw // div), max(16, self.ph // div), self.an.nb)
        return v

    def begin(self, proj, title, t_now):
        proj = proj or {}
        try:
            bpm = float(proj.get("bpm") or 0) or None
        except (TypeError, ValueError):
            bpm = None
        seed = proj.get("seed"); rng = random.Random(seed if seed is not None else title)
        style = str(proj.get("style") or "")
        # pseudo-AI plan: raz na aranżację — palette/sceny z wektorów projektu (powtórzone motywy = ten sam addr)
        rx = None
        try:
            from . import plan as VPLAN
            rx = VPLAN.reactive_for(proj)
        except Exception:
            rx = None
        if rx:
            drop_sc = rx.get("drop_scene") or "morph"
            calm_sc = rx.get("calm_scene") or "morph"
            if drop_sc not in SCENES:
                drop_sc = "morph"
            if calm_sc not in SCENES:
                calm_sc = "morph"
            self.tr = dict(bpm=bpm, sections=list(proj.get("sections") or []), style=style, title=title,
                           drop=drop_sc, calm=calm_sc, plan=rx.get("plan"))
            self._plan = rx.get("plan")
            self._ft = None
            try:   # tory klatkowe z siatki taktowej: lookup O(1) zamiast skanu sekcji + importu w każdej klatce
                from . import plan_grid as _PG
                if (self._plan or {}).get("grid"):
                    self._ft = _PG.FrameTrack(self._plan, bpm or 140.0, int(self.fps))
            except Exception:
                self._ft = None
        else:
            self.tr = dict(bpm=bpm, sections=list(proj.get("sections") or []), style=style, title=title,
                           drop=rng.choice(("morph", "morph", "ring")),
                           calm=rng.choice(("morph", "morph", "scope", "bars")))
            self._plan = None
            self._ft = None
        self.t_begin = float(t_now); self.txt_ver += 1
        pal = str(self.cfg.get("palette") or "auto")
        if pal in PALETTES:
            self.pal = pal
        elif rx and rx.get("palette") in PALETTES:
            self.pal = rx["palette"]
        else:
            self.pal = _palette_for(style, seed)
        # liczba agentów z planu (agresja → gęstszy morph)
        if rx and rx.get("agents"):
            try:
                self.evo = Evolution(int(rx["agents"]), seed=seed)
            except Exception:
                pass

    def push(self, b):
        self.an.push(b)

    def _section(self, t):
        tr = self.tr
        if not tr or not tr["bpm"]:
            return None
        bar = t * tr["bpm"] / 240.0
        for s in tr["sections"]:
            if s.get("start", 0) <= bar < s.get("start", 0) + s.get("bars", 0):
                return s
        return None

    def _scene(self, t):
        sc = str(self.cfg.get("scene") or "auto")
        if sc in SCENES:
            return sc, False
        s = self._section(t); typ = (s or {}).get("type", "drop")
        # plan span: stała scena z adresu motywu (bez ponownego losowania)
        ft = getattr(self, "_ft", None)
        if ft is not None and s is not None:
            scene = ft.at_time(t)["scene"]
            if scene in SCENES:
                return scene, typ == "drop"
        plan = getattr(self, "_plan", None) or ((self.tr or {}).get("plan") if self.tr else None)
        if plan and s is not None:
            try:
                from . import plan as VPLAN
                bpm = float((self.tr or {}).get("bpm") or 140)
                # t jest czasem od begin — bars ≈ t * bpm / 60 / 4; ale sekcja ma start w taktach
                bar = float(s.get("start") or 0) + 0.01
                sp = VPLAN.span_at_bar(plan, bar)
                if sp and sp.get("params"):
                    scene = sp["params"].get("scene") or ("morph" if typ == "drop" else "scope")
                    if scene in SCENES:
                        return scene, typ == "drop"
            except Exception:
                pass
        if typ == "build":
            return "tunnel", False
        if typ == "drop":
            return self.tr["drop"] if self.tr else "morph", True
        return (self.tr["calm"] if self.tr else "morph"), False

    def frame(self, k, lv, dt_frames=1):
        tf = k / self.fps
        A = self.an.feat(int(tf * SR))
        t = tf - self.t_begin
        scene, drop = self._scene(t)
        viz = self._viz(lv["div"])
        if self._cur_div != lv["div"]:
            viz.reset(); self._cur_div = lv["div"]
        if self.tr and bool(self.cfg.get("title", True)) and viz.txt_ver != self.txt_ver:
            viz.set_palette(self.pal); viz.set_text(str(self.tr["title"]).upper()[:48], "DS LIVE", self.txt_ver)
        elif not self.tr and viz.txt_ver != -2:
            viz.set_palette(self.pal); viz.set_text("", "DS LIVE  STAND BY", -2)
        self.evo.update(A, min(8, max(1, 3 * int(dt_frames))))
        txt_a = 1.0 if t < 8 else (0.45 if self.tr else 1.0)
        ft = getattr(self, "_ft", None)
        mod = ft.at_time(max(0.0, t)) if (ft is not None and bool(self.cfg.get("plan_fx", True))) else None
        img = viz.render(A, max(0.0, t), scene, lv["fx"], self.evo, self.pal, txt_a, drop, mod)
        if viz.h != self.ph or viz.w != self.pw:
            key = (viz.h, viz.w)
            if key not in self._up:
                self._up[key] = (np.arange(self.ph) * viz.h // self.ph, np.arange(self.pw) * viz.w // self.pw)
            yi, xi = self._up[key]
            img = img[yi][:, xi]
        return np.ascontiguousarray(img).tobytes()


# ------------------------------------------------------------------ sonda systemu + automatyczny dobór poziomu
class SysProbe:
    """Zajętość CPU (z /proc/stat, bez psutil) i wolny RAM (MemAvailable). Poza Linuksem zwraca None → regulator patrzy tylko na czas renderu."""

    def __init__(self):
        self.ncpu = os.cpu_count() or 1; self._prev = self._stat()

    @staticmethod
    def _stat():
        try:
            with open("/proc/stat") as f:
                v = [int(x) for x in f.readline().split()[1:9]]
            return sum(v), v[3] + v[4]
        except Exception:
            return None

    def cpu(self):
        cur = self._stat(); prev, self._prev = self._prev, cur
        if not cur or not prev or cur[0] == prev[0]:
            return None
        return max(0.0, min(1.0, 1.0 - (cur[1] - prev[1]) / (cur[0] - prev[0])))

    @staticmethod
    def mem_mb():
        try:
            with open("/proc/meminfo") as f:
                for ln in f:
                    if ln.startswith("MemAvailable:"):
                        return int(ln.split()[1]) / 1024.0
        except Exception:
            pass
        return None


class AutoTune:
    """Drabinka poziomów LEVELS. quality=auto: schodzi od razu tyle poziomów, ile trzeba (wg przewidywanego kosztu), wchodzi wyżej po 20 s spokoju
    i tylko gdy przewidywany koszt jest bezpieczny; nieudana próba wejścia blokuje ten poziom na 90 s (potem 180 s…). Inne wartości = poziom stały."""

    def __init__(self, quality="auto", cpu_target=0.85, min_free_mb=200, ncpu=None, start=None):
        q = str(quality or "auto").strip().lower()
        self.auto = q == "auto"
        fixed = QUALITY.get(q)
        if fixed is None and q.isdigit():
            fixed = min(len(LEVELS) - 1, int(q))
        ncpu = ncpu or os.cpu_count() or 1
        self.level = (fixed if fixed is not None else (start if start is not None else (3 if ncpu <= 2 else 2)))
        if fixed is None and not self.auto:
            self.auto = True
        self.cpu_target, self.min_free, self.ncpu = float(cpu_target), float(min_free_mb), ncpu
        self.t_change = None; self.good_since = None; self.block = {}; self.pen = {}; self.last_up = None; self.reason = "start"

    def _set(self, lvl, now, why):
        self.level = max(0, min(len(LEVELS) - 1, lvl)); self.t_change = now; self.good_since = None; self.reason = why

    def update(self, now, duty, cpu=None, mem_mb=None, lag=0.0, drops=0, busy=False):
        """duty = ułamek jednego rdzenia zużywany przez render na bieżącym poziomie. -> poziom."""
        L = self.level
        if not self.auto:
            return L
        if self.t_change is None:
            self.t_change = now
        tgt = self.cpu_target - (0.10 if busy else 0.0)
        if mem_mb is not None and mem_mb < self.min_free and L < 5:
            self._set(5, now, f"mało RAM ({mem_mb:.0f} MB)"); return self.level
        press, why = 0, ""
        if duty > 0.45:
            nxt = L
            while nxt < len(LEVELS) - 1 and duty * rel_cost(LEVELS[nxt]) / rel_cost(LEVELS[L]) > 0.30:
                nxt += 1
            if nxt == L:
                nxt = min(L + 1, len(LEVELS) - 1)
            press, why = nxt - L, f"render {duty * 100:.0f}% rdzenia"
        if lag > 0.5:
            press, why = max(press, 1), f"zaległość {lag:.1f}s"
        if drops > 0:
            press, why = max(press, 1), "gubione klatki"
        if cpu is not None and cpu > tgt:
            press, why = max(press, 2 if cpu > 0.97 else 1), f"CPU {cpu * 100:.0f}%"
        if press and L < len(LEVELS) - 1 and now - self.t_change >= 2.0:
            if self.last_up is not None and now - self.last_up < 40.0:      # wejście okazało się za ciężkie
                self.pen[L] = min(600.0, self.pen.get(L, 45.0) * 2.0); self.block[L] = now + self.pen[L]
            self._set(L + press, now, why); return self.level
        good = duty < 0.25 and lag < 0.15 and drops == 0 and not busy and (cpu is None or cpu < tgt - 0.25)
        self.good_since = (self.good_since or now) if good else None
        if good and L > 0 and now - self.good_since >= 20.0 and now >= self.block.get(L - 1, 0) and now - self.t_change >= 20.0:
            pred = duty * rel_cost(LEVELS[L - 1]) / rel_cost(LEVELS[L])
            cpu_after = None if cpu is None else cpu + (pred - duty) / self.ncpu
            if pred < 0.30 and (cpu_after is None or cpu_after < tgt - 0.10):
                self.last_up = now; self._set(L - 1, now, "spokój — wyżej"); return self.level
        return self.level


# ------------------------------------------------------------------ nadawanie AV razem z silnikiem Live
class LiveAV:
    """Zamiennik AvSink dla trybu „reaktywnego”: audio z silnika Live → RTMP bez zwłoki, klatki liczone z TEGO SAMEGO audio.
    API jak AvSink: start() / stop() / audio(b) / begin(proj, feat, pv, title) / status; plus hint_busy() i stats()."""
    CH = 2048

    def __init__(self, av_cfg, rtmp_cfg, log=None, streamer=None, probe=None):
        self.av = dict(DEFAULT_VIDEO); self.av.update({k: v for k, v in (av_cfg or {}).items() if v not in (None, "")})
        self.rt = dict(rtmp_cfg or {}); self.log = log or (lambda m: None)
        if "size" in self.av and not (av_cfg or {}).get("width"):
            self.av["width"], self.av["height"] = parse_size(self.av["size"])
        w = _even(self.rt.get("width") or self.av["width"]); h = _even(self.rt.get("height") or self.av["height"])
        self.fps = max(5, min(60, int(self.rt.get("fps") or self.av["fps"])))
        pd = max(1, min(4, int(self.av.get("pipe_div") or 2)))
        self.out_size = (w, h); self.pipe = (_even(w // pd), _even(h // pd))
        cfg = dict(self.rt, out_w=w, out_h=h, fps=self.fps, lite=True, threads=int(self.av["threads"]), nice=int(self.av["nice"]),
                   v_codec=self.av["v_codec"], v_preset=self.av["v_preset"], gop_sec=2,
                   v_bitrate=int(self.rt.get("v_bitrate") or self.av["v_bitrate"]), a_bitrate=int(self.rt.get("a_bitrate") or 128))
        net = bool((self.rt.get("url") or "").strip()) and bool(self.rt.get("enabled", True))
        self.st = streamer or (RtmpStreamer(cfg, self.pipe, self.fps, self.log) if net else NullStreamer())   # bez RTMP: sam render + podgląd lokalny
        self.net = net and not isinstance(self.st, NullStreamer)
        self.preview_mode = str(self.av.get("preview") or "off").strip().lower()      # off | gui (okno programu) | window (ffplay)
        self.player = None; self.latest = None; self.preview_error = ""
        self.eng = Engine(self.pipe[0], self.pipe[1], self.fps, self.av)
        self.tune = AutoTune(self.av["quality"], float(self.av["cpu_target"]) / 100.0, float(self.av["min_free_mb"]))
        self.probe = probe or SysProbe()
        self.q = queue.Queue(maxsize=400); self.th = None; self.run = False; self.busy = False
        self.samples = 0; self.sent_v = 0; self.last = None; self.late_frames = 0; self.rendered = 0
        self.r_ewma = 0.0; self._t_tick = 0.0; self._drops0 = 0; self.cpu = None; self.errors = 0

    # --- API
    @property
    def status(self):
        s = (f"RTMP: {self.st.status}" if self.net else f"Podgląd lokalny: {self._preview_state()}")
        le = getattr(self.st, "last_error", "")
        if self.net and le and self.st.status != "nadaje":
            s += f" — {le}"
        if self.st.frames:
            auto = "auto" if self.tune.auto else "stały"
            s += (f" · {self.out_size[0]}x{self.out_size[1]}@{self.fps} · poziom {self.tune.level}/{len(LEVELS) - 1} ({auto}) · render {self.r_ewma * 1000:.1f} ms"
                  + (f" · CPU {self.cpu * 100:.0f}%" if self.cpu is not None else "") + (f" · powtórzone {self.late_frames}" if self.late_frames else ""))
        return s

    def stats(self):
        return dict(level=self.tune.level, auto=self.tune.auto, reason=self.tune.reason, render_ms=self.r_ewma * 1000, cpu=self.cpu, frames=self.sent_v,
                    repeated=self.late_frames, dropped=getattr(self.st, "dropped_v", 0), fps=self.fps, out=self.out_size, pipe=self.pipe)

    def hint_busy(self, flag):
        self.busy = bool(flag)

    def _preview_state(self):
        if self.preview_mode == "window":
            if self.player is None:
                return self.preview_error or "okno ffplay nie wystartowało"
            return "okno ffplay" if self.player.alive() else "okno zamknięte"
        return "w oknie programu" if self.preview_mode == "gui" else "wyłączony"

    def latest_frame(self):
        """(bajty rgb24, szerokość, wysokość, nr klatki) ostatnio wyrenderowanej klatki albo None — do podglądu w GUI (wątek-bezpieczne: podmiana referencji)."""
        lf = self.latest
        return None if lf is None else (lf[0], self.pipe[0], self.pipe[1], lf[1])

    def _emit(self, fr):
        self.latest = (fr, self.sent_v)
        if self.player is not None:
            self.player.write_frame(fr)

    def start(self):
        self.run = True; self.st.start()
        if self.preview_mode == "window":
            disp = (self.out_size[0], self.out_size[1]) if self.out_size[0] <= 960 else (960, int(960 * self.out_size[1] / self.out_size[0]) // 2 * 2)
            p = LocalPreview(self.pipe, self.fps, display=disp, log=self.log)
            if p.start():
                self.player = p
            else:
                self.preview_error = p.error; self.log("Podgląd: " + p.error)
        self.th = threading.Thread(target=self._loop, daemon=True); self.th.start()

    def stop(self):
        self.run = False
        if self.th:
            self.th.join(timeout=3)
        self.st.stop()
        if self.player is not None:
            self.player.stop(); self.player = None

    def audio(self, b):
        try:
            self.q.put_nowait(("pcm", b))
        except queue.Full:
            try:
                self.q.get_nowait()
            except queue.Empty:
                pass

    def begin(self, proj, feat=None, pv=None, title=None):
        try:
            self.q.put_nowait(("begin", proj, title))
        except queue.Full:
            pass

    # --- wątek wideo
    def _nice(self):
        n = int(self.av.get("nice") or 0)
        if n > 0 and hasattr(os, "setpriority"):
            try:
                os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), n)
            except Exception:
                pass

    def _frames_due(self):
        due = int(self.samples / SR * self.fps)
        while self.sent_v < due:
            k = self.sent_v; lv = LEVELS[self.tune.level]
            backlog = self.q.qsize() * self.CH / SR
            if self.last is not None and (k % lv["skip"] != 0 or backlog > 0.6):
                fr = self.last
                if k % lv["skip"] == 0:
                    self.late_frames += 1
            else:
                t0 = time.perf_counter()
                try:
                    fr = self.eng.frame(k, lv, lv["skip"]); self.errors = 0
                except Exception as e:                       # render wideo nie może zatrzymać nadawania audio
                    self.errors += 1; fr = self.last
                    if self.errors in (1, 20):
                        self.log(f"wideo: {e}")
                    if fr is None:
                        fr = bytes(self.pipe[0] * self.pipe[1] * 3)
                dt = time.perf_counter() - t0
                self.r_ewma = dt if not self.rendered else self.r_ewma * 0.9 + dt * 0.1
                self.rendered += 1
            self.last = fr; self.st.write_frame(fr); self._emit(fr); self.sent_v += 1

    def _tick(self):
        now = time.monotonic()
        if now - self._t_tick < 1.0:
            return
        self._t_tick = now
        lv = LEVELS[self.tune.level]
        duty = self.r_ewma * self.fps / lv["skip"]
        dv = getattr(self.st, "dropped_v", 0); drops = dv - self._drops0; self._drops0 = dv
        if self.st.status != "nadaje":
            drops = 0                                         # start/ponawianie połączenia — to nie wina renderu
        self.cpu = self.probe.cpu()
        self.tune.update(now, duty, self.cpu, self.probe.mem_mb(), self.q.qsize() * self.CH / SR, drops, self.busy)

    def _loop(self):
        self._nice(); self._t_tick = time.monotonic()
        while self.run:
            try:
                it = self.q.get(timeout=0.1)
            except queue.Empty:
                self.st.maintain(); self._tick(); continue
            try:
                if it[0] == "begin":
                    self.eng.begin(it[1], it[2] or "", self.samples / SR)
                    continue
                b = it[1]
                self.st.maintain(); self.st.write_audio(b)
                self.eng.push(b); self.samples += len(b) // 4
                self._frames_due(); self._tick()
            except Exception as e:
                self.log(f"wideo: {e}")


# ------------------------------------------------------------------ podgląd offline (ten sam silnik, bez RTMP) — do strojenia wyglądu i pomiaru kosztu
def export_preview(audio_file, out, seconds=20, size=(854, 480), fps=25, quality="max", scene="auto", palette="auto", bpm=None, title="PREVIEW", progress=None, proj=None, v_bitrate=1500):
    """Renderuje MP4 z audio_file (dowolny format znany ffmpeg) tym samym silnikiem co live. -> dict(statystyki)."""
    ff = ffmpeg_bin()
    if not ff:
        raise RuntimeError("Brak ffmpeg w PATH.")
    w, h = _even(size[0]), _even(size[1]); pw, ph = _even(w // 2), _even(h // 2)
    raw = subprocess.run([ff, "-v", "error", "-i", str(audio_file), "-t", str(seconds), "-f", "s16le", "-ar", str(SR), "-ac", "2", "-"], capture_output=True).stdout
    n = len(raw) // 4
    if n < SR // 2:
        raise RuntimeError("Za mało dźwięku w pliku.")
    eng = Engine(pw, ph, fps, dict(scene=scene, palette=palette)); eng.begin(proj if proj else dict(bpm=bpm, style=title), title, 0.0)   # proj → plan pseudo-AI z całego projektu
    lvl = AutoTune(quality).level; lv = LEVELS[lvl]
    cmd = [ff, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{pw}x{ph}", "-r", str(fps), "-i", "-", "-i", str(audio_file), "-t", str(n / SR),
           "-vf", f"scale={w}:{h}:flags=bilinear", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency", "-pix_fmt", "yuv420p",
           "-b:v", f"{int(v_bitrate)}k", "-c:a", "aac", "-b:a", "128k", "-shortest", str(out)]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    tot, nf, pos, last = 0.0, 0, 0, None
    try:
        for k in range(int(n / SR * fps)):
            need = min(n, int((k / fps) * SR) + 1)
            while pos < need:
                c = raw[pos * 4:(pos + 2048) * 4]; eng.push(c); pos += len(c) // 4
            if last is None or k % lv["skip"] == 0:
                t0 = time.perf_counter(); last = eng.frame(k, lv, lv["skip"]); tot += time.perf_counter() - t0; nf += 1
            p.stdin.write(last)
            if progress and k % 25 == 0:
                progress(k / max(1, n / SR * fps))
    finally:
        try:
            p.stdin.close()
        except OSError:
            pass
        err = p.stderr.read().decode("utf-8", "replace"); p.wait()
    if p.returncode != 0:
        raise RuntimeError(err[-400:])
    return dict(out=str(out), frames=nf, render_ms=1000 * tot / max(1, nf), level=lvl, agents=eng.evo.n)
