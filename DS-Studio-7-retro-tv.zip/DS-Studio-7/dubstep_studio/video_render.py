"""video_render.py — kompatybilna warstwa nad vid.host (export MP4, RTMP, szablony).

Nowa implementacja: vid/host.py (VideoJob, RtmpStreamer, AvSink, export_mp4, stream_project).
To API zachowuje stare nazwy używane przez GUI/CLI.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

from . import core
from .vid import host as VH
from .vid import templates as TP
from .vid.registry import VREG
from .vid import plan as VPLAN
from .vid import looks as LOOKS

DEFAULT_AV = dict(
    width=1280, height=720, fps=30,
    video_bitrate="4M", audio_bitrate="192k",
    preset="veryfast", pix_fmt="yuv420p",
    v_codec="libx264", v_preset="veryfast", crf=18, a_bitrate=192,
)

DEFAULT_RTMP = dict(
    enabled=False,
    url="rtmp://localhost/live/stream",
    key="",
    reconnect=True,
    reconnect_sec=5,
    retries=0,
    timeout_sec=10,
    buffer_ms=0,
    live=True,
    width=1280, height=720, fps=30,
    v_bitrate=2500, a_bitrate=128,
    v_codec="libx264", v_preset="veryfast",
)




def ensure_video_plan(proj, force=False):
    """Buduje proj['video_plan'] (wektory → adres → params). Idempotentne."""
    return VPLAN.plan_project(proj, force=force)

def list_templates():
    """Wspólny katalog wyglądów (szablony MIDI + sceny reaktywne) — ten sam w oknie głównym i w Live. Pola jak dawniej: id, title, desc."""
    return LOOKS.catalog()


def list_palettes():
    return TP.list_palettes()


def list_plugins(kind=None):
    return VREG.describe(kind)


def _enc_from_av(av):
    av = {**DEFAULT_AV, **(av or {})}
    br = av.get("v_bitrate") or av.get("video_bitrate") or 4000
    if isinstance(br, str):
        br = int(str(br).lower().replace("k", "").replace("m", "000") or 0) or 4000
    a_br = av.get("a_bitrate") or av.get("audio_bitrate") or 192
    if isinstance(a_br, str):
        a_br = int(str(a_br).lower().replace("k", "") or 0) or 192
    return dict(
        v_codec=av.get("v_codec") or "libx264",
        v_preset=av.get("v_preset") or av.get("preset") or "veryfast",
        crf=av.get("crf"),
        v_bitrate=int(br),
        a_bitrate=int(a_br),
        gop_sec=av.get("gop_sec", 2),
        fps=int(av.get("fps") or 30),
    )


def _size_fps(av, rtmp=None):
    src = {**(av or {}), **(rtmp or {})}
    w = int(src.get("width") or 1280)
    h = int(src.get("height") or 720)
    fps = int(src.get("fps") or 30)
    return w, h, fps



def apply_fractal_overrides(pv, av=None):
    """Nakłada z GUI/AV: quality, detail_scale/auto, mode_3d, world na warstwy room_fractal_wander i pv.quality_level."""
    if not pv:
        return pv
    av = av or {}
    # mapa quality → poziom AutoTune (0=max … 5=minimal)
    qmap = {"max": 0, "balanced": 2, "low": 4, "minimal": 5}
    q = str(av.get("quality") or pv.get("quality") or "max").strip().lower()
    if q == "auto":
        # offline: traktuj jak balanced; live host i tak nadpisze z CPU
        ql = 2
    elif q.isdigit():
        ql = max(0, min(6, int(q)))
    else:
        ql = qmap.get(q, 0)
    if av.get("quality_level") is not None:
        try:
            ql = int(av["quality_level"])
        except Exception:
            pass
    pv["quality"] = q
    pv["quality_level"] = ql

    overrides = {}
    if "fractal_mode_3d" in av:
        overrides["mode_3d"] = bool(av["fractal_mode_3d"])
    if "fractal_detail_auto" in av:
        overrides["detail_auto"] = bool(av["fractal_detail_auto"])
    if "fractal_detail_scale" in av:
        try:
            overrides["detail_scale"] = max(1.0, min(10000.0, float(av["fractal_detail_scale"])))
        except Exception:
            pass
    if "fractal_world" in av:
        try:
            overrides["world"] = max(0.0, min(1.0, float(av["fractal_world"])))
        except Exception:
            pass
    if not overrides and "quality_level" not in pv:
        return pv
    for layer in pv.get("layers") or []:
        if layer.get("plugin") != "room_fractal_wander":
            continue
        p = layer.setdefault("params", {})
        p.update(overrides)
    # formacja pierwszoplanowa (wszystkie szablony z performerami)
    if av.get("formation"):
        pv["formation"] = str(av["formation"]).lower()
        pv.setdefault("meta", {})["formation"] = pv["formation"]
    if av.get("formation_radius") is not None:
        pv["formation_radius"] = float(av["formation_radius"])
    if av.get("formation_sep") is not None:
        pv["formation_sep"] = float(av["formation_sep"])
    return pv

def build_projvideo(proj, template="kraftwerk_robots", av=None, **kw):
    av = {**DEFAULT_AV, **(av or {})}
    pv = TP.build_projvideo(
        proj,
        template=LOOKS.template_of(template),
        size=(int(av.get("width", 1280)), int(av.get("height", 720))),
        fps=int(av.get("fps", 30)),
        palette=kw.get("palette") or av.get("palette"),
        robots=kw.get("robots"),
        focus_track=kw.get("focus_track"),
        render_scale=float(av.get("render_scale", 1.0)),
        auto_cues=kw.get("auto_cues", True),
    )
    # pochodna szablonu: losowe parametry + wagi cue na całą rozpiętość klipu (każdy szablon)
    if av.get("derive") or kw.get("derive"):
        import random as _r
        strength = float(av.get("derive_strength", kw.get("derive_strength", 0.55)) or 0.55)
        seed = av.get("derive_seed", kw.get("derive_seed"))
        pv = TP.derive_projvideo(proj, pv, rng=_r.Random() if seed is None else _r.Random(int(seed)),
                                 strength=strength, seed=seed)
    return apply_fractal_overrides(pv, av)


def ensure_project_audio(proj, audio_wav=None, progress=None):
    if audio_wav and Path(str(audio_wav)).exists():
        return str(audio_wav)
    mix = core.render_mix(proj, progress=progress)
    import tempfile, os
    fd, path = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    core.write_wav(path, mix)
    return path


def render_video(proj, template_id="live_show", av=None, out_path=None, audio_wav=None,
                 progress=None, mute_audio=False, pv=None):
    """Render MP4 (klatki + dźwięk) przez vid.host.export_mp4 (wygląd tpl:*) albo lekki silnik reaktywny (rx:*). Zwraca ścieżkę."""
    av = {**DEFAULT_AV, **(av or {})}
    if LOOKS.is_reactive(template_id):
        return render_reactive_video(proj, LOOKS.parse(template_id)["scene"], av, out_path, audio_wav, progress, mute_audio)
    template_id = LOOKS.template_of(template_id)
    if pv is None:
        pv = build_projvideo(proj, template_id, av)
    out_path = Path(out_path or (Path.cwd() / "video.mp4"))
    enc = _enc_from_av(av)
    mix = None
    if mute_audio:
        import numpy as np
        n = int(float(proj.get("bars") or 16) * 4 * 60.0 / float(proj.get("bpm") or 140) * core.SR)
        mix = np.zeros((n, 2), np.float32)
        audio_wav = None
    return VH.export_mp4(proj, pv, str(out_path), mix=mix, audio_wav=audio_wav, enc=enc, progress=progress)


def stream_rtmp(proj, template_id="live_show", rtmp=None, audio_wav=None, progress=None,
                stop=None, log=print, pv=None, av=None):
    """Nadawanie RTMP w czasie rzeczywistym (RtmpStreamer + reconnect)."""
    rtmp = {**DEFAULT_RTMP, **(rtmp or {})}
    if not rtmp.get("url") and not rtmp.get("enabled", True) and not rtmp.get("local_only"):
        raise RuntimeError("RTMP wyłączony / brak URL")
    av = {**DEFAULT_AV, **(av or {})}
    if pv is None and LOOKS.is_reactive(template_id):                 # wygląd rx:* — silnik reaktywny
        status = stream_reactive(proj, LOOKS.parse(template_id)["scene"], rtmp, av, progress, stop, log)
        return {"url": VH.mask_url(VH.rtmp_target(rtmp), rtmp.get("key", "")), "status": status}
    template_id = LOOKS.template_of(template_id)
    w, h, fps = _size_fps(av, rtmp)
    if pv is None:
        pv = build_projvideo(proj, template_id, dict(av, width=w, height=h, fps=fps))
    else:
        pv = dict(pv)
        pv["size"] = [w, h]
        pv["fps"] = fps
    enc = _enc_from_av(dict(av, **{k: rtmp[k] for k in ("v_bitrate", "a_bitrate", "v_codec", "v_preset") if k in rtmp}))
    if rtmp.get("video_bitrate"):
        br = rtmp["video_bitrate"]
        if isinstance(br, str):
            br = int(str(br).lower().replace("k", "").replace("m", "000") or 0) or 2500
        enc["v_bitrate"] = int(br)
    if rtmp.get("v_bitrate"):
        enc["v_bitrate"] = int(rtmp["v_bitrate"])
    if rtmp.get("audio_bitrate"):
        a = rtmp["audio_bitrate"]
        if isinstance(a, str):
            a = int(str(a).lower().replace("k", "") or 0) or 128
        enc["a_bitrate"] = int(a)
    rtmp_cfg = dict(
        url=rtmp.get("url") or DEFAULT_RTMP["url"],
        key=rtmp.get("key") or "",
        reconnect=bool(rtmp.get("reconnect", True)),
        reconnect_sec=int(rtmp.get("reconnect_sec", 5)),
        retries=int(rtmp.get("retries", 0)),
        timeout_sec=int(rtmp.get("timeout_sec", 10)),
        buffer_ms=int(rtmp.get("buffer_ms", 0)),
        live=bool(rtmp.get("live", True)),
        width=w, height=h, fps=fps,
        v_bitrate=enc.get("v_bitrate", 2500),
        a_bitrate=enc.get("a_bitrate", 128),
        v_codec=enc.get("v_codec", "libx264"),
        v_preset=enc.get("v_preset", "veryfast"),
        local_only=bool(rtmp.get("local_only")), preview=bool(rtmp.get("preview")), preview_size=rtmp.get("preview_size"),
    )
    status = VH.stream_project(
        proj, pv, rtmp_cfg, enc=enc, mix=None,
        progress=progress, stop=stop or (lambda: False), log=log,
    )
    return {"url": VH.mask_url(VH.rtmp_target(rtmp_cfg), rtmp_cfg.get("key", "")), "status": status}


def stream_project_live(proj, pv, rtmp_cfg, **kw):
    return VH.stream_project(proj, pv, rtmp_cfg, **kw)


def make_av_sink(av_cfg, rtmp_cfg, log=None):
    """Sink AV do podpięcia pod silnik Live (audio callback + begin na aranżację).
    engine = reactive (domyślnie): lekki wizualizator reagujący na dźwięk + automatyczny dobór jakości (vid.livefx.LiveAV);
    engine = template: dawny render z szablonu teledysku (zdarzenia MIDI, cięższy; vid.host.AvSink)."""
    if str((av_cfg or {}).get("engine") or "reactive").lower() != "template":
        from .vid import livefx
        return livefx.LiveAV(av_cfg, rtmp_cfg, log=log)
    return VH.AvSink(av_cfg, rtmp_cfg, log=log)


def _full_seconds(proj):
    return float(proj.get("bars") or 16) * 4 * 60.0 / float(proj.get("bpm") or 140) + 2.0


def render_reactive_video(proj, scene, av=None, out_path=None, audio_wav=None, progress=None, mute_audio=False):
    """MP4 z lekkiego silnika reaktywnego (wygląd rx:*): ten sam renderer co Live, z planem pseudo-AI projektu."""
    from .vid import livefx
    av = {**DEFAULT_AV, **(av or {})}
    w, h, fps = _size_fps(av)
    out_path = Path(out_path or (Path.cwd() / "video.mp4"))
    if mute_audio:
        import numpy as np, os, tempfile
        fd, wav = tempfile.mkstemp(suffix=".wav"); os.close(fd)
        core.write_wav(wav, np.zeros((int(_full_seconds(proj) * core.SR), 2), np.float32))
    else:
        wav = ensure_project_audio(proj, audio_wav, (lambda x: progress(0.1 * float(x))) if progress else None)
    br = _enc_from_av(av)["v_bitrate"]
    q = str(av.get("quality") or "max"); q = "max" if q == "auto" else q          # offline: bez automatu CPU
    palette = av.get("palette") or "auto"
    livefx.export_preview(wav, str(out_path), seconds=_full_seconds(proj) + 5, size=(w, h), fps=fps, quality=q, scene=scene or "auto", palette=palette,
                          bpm=proj.get("bpm"), title=str(proj.get("style") or "DS STUDIO"), proj=proj, v_bitrate=br,
                          progress=(lambda x: progress(0.1 + 0.9 * float(x))) if progress else None)
    return str(out_path)


def stream_reactive(proj, scene, rtmp=None, av=None, progress=None, stop=None, log=print, mix=None):
    """Nadawanie gotowego projektu silnikiem reaktywnym (wygląd rx:*): LiveAV dostaje PCM w czasie rzeczywistym (RTMP i/lub podgląd lokalny)."""
    import time
    import numpy as np
    from .vid import livefx
    rtmp = {**DEFAULT_RTMP, **(rtmp or {})}; av = {**DEFAULT_AV, **(av or {})}
    w, h, fps = _size_fps(av, rtmp)
    local_only = bool(rtmp.get("local_only"))
    avc = dict(width=w, height=h, size=f"{w}x{h}", fps=fps, scene=scene or "auto", palette=av.get("palette") or "auto", engine="reactive",
               quality=av.get("quality") or "auto", preview="window" if (local_only or rtmp.get("preview")) else "off")
    rt = dict(rtmp, enabled=not local_only and bool(rtmp.get("url")), width=w, height=h, fps=fps)
    if mix is None:
        mix = core.render_mix(proj, progress=None)
    pcm = (np.clip(mix, -1, 1) * 32767).astype("<i2").tobytes()
    lv = livefx.LiveAV(avc, rt, log=log)
    lv.start(); lv.begin(proj, None, None, title=str(proj.get("style") or "DS STUDIO"))
    chunk = livefx.LiveAV.CH * 4; t0 = time.time(); sent = 0; SR = core.SR
    try:
        while sent < len(pcm) and not (stop and stop()):
            target = min(len(pcm), int(((time.time() - t0) + 0.35) * SR) * 4)
            while sent < target:
                n = min(chunk, len(pcm) - sent); lv.audio(pcm[sent: sent + n]); sent += n
            if progress:
                progress(sent / max(1, len(pcm)))
            time.sleep(0.01)
        time.sleep(1.0)
    finally:
        status = lv.status; lv.stop()
    return status


def export_project_av(proj, out_dir, template_id="live_show", av=None, audio_wav=None, progress=None):
    """Zapisuje proj.json + track.wav + video.mp4 + projvideo.json."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "proj.json").write_text(
        json.dumps({k: v for k, v in proj.items() if k != "geometry_doc"}, default=str, indent=2),
        encoding="utf-8",
    )
    def audio_prog(x):
        if progress:
            progress(0.12 * float(x))
    wav = ensure_project_audio(proj, audio_wav, audio_prog if progress else None)
    dest_wav = out_dir / "track.wav"
    if Path(wav).resolve() != dest_wav.resolve():
        shutil.copy(wav, dest_wav)
    if progress:
        progress(0.12)
    if LOOKS.is_reactive(template_id):                              # wygląd rx:* — bez projvideo.json (nie ma warstw szablonu)
        vid = render_reactive_video(proj, LOOKS.parse(template_id)["scene"], av, out_dir / "video.mp4", dest_wav,
                                    (lambda x: progress(0.12 + 0.88 * float(x))) if progress else None)
        meta = dict(template=template_id, video=str(vid), audio=str(dest_wav))
        (out_dir / "av_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        if progress:
            progress(1.0)
        return meta
    template_id = LOOKS.template_of(template_id)
    pv = build_projvideo(proj, template_id, av)
    TP.save_projvideo(pv, out_dir / "projvideo.json")
    def vid_prog(x):
        if progress:
            # render_video/export_mp4 już mapuje 0..1 (z miksem albo bez) → wsuwamy w 12%…100%
            progress(0.12 + 0.88 * float(x))
    vid = render_video(proj, template_id, av, out_dir / "video.mp4", dest_wav, progress=vid_prog if progress else None, pv=pv)
    meta = dict(template=template_id, video=str(vid), audio=str(dest_wav), projvideo=str(out_dir / "projvideo.json"))
    (out_dir / "av_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    if progress:
        progress(1.0)
    return meta


def frame_png(proj, template_id="live_show", t_sec=0.0, out="frame.png", av=None, pv=None):
    av = {**DEFAULT_AV, **(av or {})}
    template_id = LOOKS.template_of(template_id)
    if pv is None:
        pv = build_projvideo(proj, template_id, av)
    return VH.frame_png(proj, pv, t_sec, out)
