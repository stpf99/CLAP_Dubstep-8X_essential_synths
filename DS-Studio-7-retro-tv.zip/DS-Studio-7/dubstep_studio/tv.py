"""tv.py — zakładka „TV 8-bit (M3U)”: playlisty M3U (URL / plik), kanały TVHeadend / IPTV,
odtwarzanie strumienia z filtrem RETRO PIXEL 8-bit (Nintendo-vibe), częściowo reaktywnym na dźwięk.

Przepływ (niezależny od silnika Live — Live działa jak dotąd, to osobny nadajnik):
  * ffmpeg dekoduje kanał (HTTP / HLS / TS z M3U) na dwie rury: wideo rgb24 w małym rozmiarze + audio s16le 48 kHz stereo,
  * PCM trafia do `Analyzer` (ten sam co w vid.livefx — widmo, głośność, punch) ORAZ do odtwarzacza lokalnego / RTMP,
  * `RetroFilter` liczy klatkę 8-bit: pikselizacja (blok), kwantyzacja do palety retro + dithering Bayer,
    scanlines; rozmiar bloku pulsuje z uderzeniami basu (reaktywność "piksel z basem", siła z suwaka),
  * klatki lecą do `RtmpStreamer` (te same ustawienia RTMP co podkarta „RTMP + wideo”) i do podglądu (GUI / ffplay).

Nasłuch audio → SZABLON TYMCZASOWY: `listen_template` patrzy ~8 s na cechy dźwięku kanału i dobiera paletę,
rozmiar piksela i siłę reakcji (muzyka z mocnym basem → NES/PICO-8, rozmowy → terminal, ambient → C64…).
Wyboru nie zapisujemy do config.txt — działa do Stop („na potrzeby tymczasowe”).

PRE-ANALIZA STYLU KANAŁU → MUZYKA LIVE: `start_style_listen` zbiera ~30 s PCM kanału i liczy pełny raport
stylu z listen.py (BPM, tonacja, wagi wszystkich stylów, energia/gęstość, instrumenty). „▶ Start Live” w Live
stosuje ten raport jako preset Generatora — studio gra NOWY strumień muzyki w stylu kanału, a TV 8-bit
(audio_source = live) reaguje na ten nowy strumień i nadaje go zamiast dźwięku kanału (RTMP/odsłuch).
PCM muzyki Live pochodzi z Output.add_tap (live.py) → TvStream.external_audio.
Nic tu nie importu Qt — GUI (tv_gui.py) używa tych samych klas; testy: tests/test_tv.py.
"""
from __future__ import annotations

import math
import os
import queue
import re
import shutil
import subprocess
import threading
import time
from urllib.parse import urlparse, unquote
from urllib.request import Request, urlopen

import numpy as np

from . import core
from .vid.host import LocalPreview, NullStreamer, RtmpStreamer, ffmpeg_bin
from .vid.livefx import Analyzer, parse_size

SR = core.SR
UA = "DS-Studio-TV/1.0"

# ------------------------------------------------------------------ palety 8-bit
# Wszystko (r, g, b) 0..255. Kolejność ma znaczenie tylko dla wygody oka.

# NES 2C02 — 54 unikalnych kolorów (klasyczna paleta konsoli 8-bit)
NES = (
    (84, 84, 84), (0, 30, 116), (8, 16, 144), (48, 0, 136), (68, 0, 100), (92, 0, 48), (84, 4, 0), (60, 24, 0),
    (32, 42, 0), (8, 58, 0), (0, 64, 0), (0, 60, 0), (0, 50, 60), (0, 0, 0),
    (152, 150, 152), (8, 76, 196), (48, 50, 236), (92, 30, 228), (136, 20, 176), (160, 20, 100), (152, 34, 32),
    (120, 60, 0), (84, 90, 0), (40, 114, 0), (8, 124, 0), (0, 118, 40), (0, 102, 120),
    (236, 238, 236), (76, 154, 236), (120, 124, 236), (176, 98, 236), (228, 84, 236), (236, 88, 180), (236, 106, 100),
    (212, 136, 32), (160, 170, 0), (116, 196, 0), (76, 208, 32), (56, 204, 108), (56, 180, 204), (60, 60, 60),
    (236, 238, 236), (168, 204, 236), (188, 188, 236), (212, 178, 236), (236, 174, 236), (236, 174, 212), (236, 180, 176),
    (228, 196, 144), (204, 210, 120), (180, 222, 120), (168, 226, 144), (152, 226, 180), (160, 214, 228),
)

# Game Boy DMG-01 — 4 odcienie zieleni
GAMEBOY = ((15, 56, 15), (48, 98, 48), (139, 172, 15), (155, 188, 15))

# PICO-8 — 16 kolorów
PICO8 = ((0, 0, 0), (29, 43, 83), (126, 37, 83), (0, 135, 81), (171, 82, 54), (95, 87, 79), (194, 195, 199),
         (255, 241, 232), (255, 0, 77), (255, 163, 0), (255, 236, 39), (0, 228, 54), (41, 173, 255), (131, 118, 156),
         (255, 119, 168), (255, 204, 170))

# Commodore 64 — 16 kolorów
C64 = ((0, 0, 0), (255, 255, 255), (104, 55, 43), (112, 164, 178), (111, 61, 134), (88, 141, 67), (53, 40, 121),
       (184, 199, 111), (111, 79, 37), (67, 57, 0), (154, 103, 89), (68, 68, 68), (108, 108, 108), (154, 210, 132),
       (108, 94, 181), (149, 149, 149))

# IBM CGA — 16 kolorów
CGA = ((0, 0, 0), (0, 0, 170), (0, 170, 0), (0, 170, 170), (170, 0, 0), (170, 0, 170), (85, 85, 0), (170, 170, 170),
       (85, 85, 85), (85, 85, 255), (85, 255, 85), (85, 255, 255), (255, 85, 85), (255, 85, 255), (255, 255, 85), (255, 255, 255))

# Terminal: fosfor bursztynowy / zielony (4 odcienie)
AMBER = ((20, 8, 0), (92, 38, 0), (188, 100, 8), (255, 176, 55))
GREEN_T = ((3, 12, 3), (18, 60, 18), (60, 140, 60), (140, 235, 120))

PALETTES_TV = {
    "nes": ("NES (54 kolory)", np.asarray(NES, np.float32)),
    "gameboy": ("Game Boy DMG (4 odcienie)", np.asarray(GAMEBOY, np.float32)),
    "pico8": ("PICO-8 (16 kolorów)", np.asarray(PICO8, np.float32)),
    "c64": ("Commodore 64 (16 kolorów)", np.asarray(C64, np.float32)),
    "cga": ("IBM CGA (16 kolorów)", np.asarray(CGA, np.float32)),
    "amber": ("Terminal amber", np.asarray(AMBER, np.float32)),
    "green": ("Terminal zielony", np.asarray(GREEN_T, np.float32)),
}
TEMPLATE_IDS = ("auto",) + tuple(PALETTES_TV)

DEFAULT_TV = dict(template="auto", pixel=6, react=40, dither=True, scanlines=False, local_audio=True,
                  rtmp=False, v_bitrate=1500, preview="gui", size="640x360", fps=25)


# ------------------------------------------------------------------ M3U
_ATTR = re.compile(r'([A-Za-z0-9_-]+)="([^"]*)"')


def parse_m3u(text: str) -> list[dict]:
    """M3U / M3U8 → lista kanałów {name, url, logo, tvg_id, chno, group}. Rozumie #EXTINF z atrybutami i zwykłe listy (same URL-e)."""
    out: list[dict] = []
    name, attrs = None, {}
    for raw in str(text).splitlines():
        ln = raw.strip()
        if not ln:
            continue
        low = ln.lower()
        if low.startswith("#extinf"):
            attrs = {k.lower(): v for k, v in _ATTR.findall(ln)}
            title = ln.split(",", 1)[1].strip() if "," in ln else ""
            name = title or attrs.get("tvg-name") or ""
            continue
        if ln.startswith("#"):
            continue
        # linia z adresem (albo ścieżką pliku lokalnego)
        ch = dict(name=name or unquote(urlparse(ln).path.rsplit("/", 1)[-1] or ln), url=ln,
                  logo=attrs.get("tvg-logo", ""), tvg_id=attrs.get("tvg-id", ""),
                  chno=int(attrs["tvg-chno"]) if str(attrs.get("tvg-chno", "")).isdigit() else None,
                  group=attrs.get("group-title", ""))
        out.append(ch)
        name, attrs = None, {}
    return out


def fetch_m3u(src: str, timeout=12) -> str:
    """Playlista z URL (http/https) albo ze ścieżki pliku → tekst. Wyrzuca RuntimeError z krótkim powodem."""
    src = str(src).strip()
    if not src:
        raise RuntimeError("Podaj URL playlisty albo wybierz plik M3U.")
    p = src.split("://", 1)
    if len(p) == 1 or p[0].lower() in ("file",):                      # ścieżka lokalna / file://
        path = src[7:] if p[0].lower() == "file" else src
        try:
            return open(os.path.expanduser(path), encoding="utf-8", errors="replace").read()
        except OSError as e:
            raise RuntimeError(f"Nie można otworzyć pliku: {e}") from e
    if p[0].lower() not in ("http", "https"):
        raise RuntimeError("URL playlisty musi zaczynać się od http:// albo https://")
    req = Request(src, headers={"User-Agent": UA, "Accept": "*/*"})
    try:
        with urlopen(req, timeout=timeout) as r:
            data = r.read(4 * 1024 * 1024)
    except Exception as e:
        raise RuntimeError(f"Pobieranie playlisty nieudane: {e}") from e
    for enc in ("utf-8", "cp1250", "latin-2", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


# ------------------------------------------------------------------ filter 8-bit
_BAYER8 = np.asarray(((0, 32, 8, 40, 2, 34, 10, 42), (48, 16, 56, 24, 50, 18, 58, 26), (12, 44, 4, 36, 14, 46, 6, 38),
                      (60, 28, 52, 20, 62, 30, 54, 22), (3, 35, 11, 43, 1, 33, 9, 41), (51, 19, 59, 27, 49, 17, 57, 25),
                      (15, 47, 7, 39, 13, 45, 5, 37), (63, 31, 55, 23, 61, 29, 53, 21)), np.float32) / 64.0

_PL_MAP = str.maketrans({"ą": "a", "ć": "c", "ę": "e", "ł": "l", "ń": "n", "ó": "o", "ś": "s", "ź": "z", "ż": "z",
                         "Ą": "A", "Ć": "C", "Ę": "E", "Ł": "L", "Ń": "N", "Ó": "O", "Ś": "S", "Ź": "Z", "Ż": "Z"})


def _ascii_fold(s) -> str:
    """Pikselowa czcionka OSD zna tylko ASCII — polskie znaki składamy do bazowych liter."""
    return str(s).translate(_PL_MAP)


class RetroFilter:
    """Klatka rgb24 (h, w, 3) uint8 → wygląd 8-bit: pikselizacja + kwantyzacja do palety + dithering + scanlines.
    Reaktywność: rozmiar bloku pulsuje z punch (uderzenia basu) — siła `react` 0..1. Parametry czytane z `params` w każdej klatce
    (GUI może zmieniać na żywo); gdy `params['temp']` ustawione, to szablon z nasłuchu (tymczasowy)."""

    def __init__(self, w, h, params: dict):
        self.w, self.h = int(w), int(h)
        self.p = params                                   # dict — wspólny z GUI / nasłuchem
        self._dither_grid: dict = {}                      # cache siatki Bayera pod (h, w, |paleta|)
        self._exp_idx: dict = {}                          # cache indeksów rozciągania pod px
        self.rng = np.random.default_rng()

    # -- paleta bieżąca (jako float32 (n, 3))
    def palette(self):
        tid = str(self.p.get("template") or "auto")
        if tid not in PALETTES_TV:
            tid = "nes"
        return PALETTES_TV[tid][1]

    def label(self):
        tid = str(self.p.get("template") or "auto")
        return PALETTES_TV[tid][0] if tid in PALETTES_TV else "NES (54 kolory)"

    # -- jedna klatka
    def apply(self, frame: np.ndarray, A: dict) -> np.ndarray:
        f = self.p
        base_px = int(max(2, min(24, int(f.get("pixel", 6) or 6))))
        react = float(f.get("react", 40)) / 100.0
        punch = float((A or {}).get("punch", 0.0))
        px = int(round(base_px * (1.0 + react * 0.5 * punch)))            # piksel z basem: blok rośnie na uderzeniu
        px = max(2, min(40, px))
        small = self._pixelate(frame, px)
        small = self._punchy(small)
        small = self._quantize(small, px, bool(f.get("dither", True)))
        out = self._expand(small, px)
        if bool(f.get("scanlines", False)) and px >= 2:
            out[1::2] = (out[1::2] * 0.82).astype(np.uint8)
        return out

    # -- pikselizacja: średnia po blokach (ścięcie reszty do wielokrotności bloku)
    def _pixelate(self, frame, px):
        h, w = self.h, self.w
        H, W = (h // px) * px, (w // px) * px
        v = frame[:H, :W].reshape(H // px, px, W // px, px, 3).astype(np.float32)
        return v.mean(axis=(1, 3))

    # -- rozciągnięcie siatki bloków do dokładnie (h, w) — indeksy z clampem (brzeg = powtórzenie ostatniego bloku)
    def _expand(self, small, px):
        key = px
        idx = self._exp_idx.get(key)
        if idx is None:
            if len(self._exp_idx) > 24:
                self._exp_idx.clear()
            yi = np.minimum(np.arange(self.h) // px, small.shape[0] - 1)
            xi = np.minimum(np.arange(self.w) // px, small.shape[1] - 1)
            idx = self._exp_idx[key] = (yi, xi)
        yi, xi = idx
        return small[yi][:, xi]

    # -- podbicie kontrastu/nasycenia (8-bit gry miały jędrne kolory)
    def _punchy(self, small):
        m = small.mean(axis=-1, keepdims=True)
        return np.clip(m + (small - m) * 1.28) * 1.04 + 2.0

    # -- kwantyzacja do najbliższego koloru palety + dithering Bayer (przed kwantyzacją)
    def _quantize(self, small, px, dither):
        pal = self.palette()
        s = small
        if dither:
            bh, bw = s.shape[0], s.shape[1]
            key = (bh, bw, len(pal))
            grid = self._dither_grid.get(key)
            if grid is None:
                if len(self._dither_grid) > 8:
                    self._dither_grid.clear()
                by = np.arange(bh) % 8; bx = np.arange(bw) % 8
                grid = self._dither_grid[key] = ((_BAYER8[np.ix_(by, bx)] - 0.5)[..., None] * (255.0 / len(pal)) * 0.9).astype(np.float32)
            s = s + grid
        flat = s.reshape(-1, 3)
        best = None; best_d = None
        for i in range(0, len(pal), 16):                 # kawałkami po 16 kolorów — bez wielkich tablic tymczasowych
            part = pal[i:i + 16]
            d2 = ((flat[:, None, :] - part[None, :, :]) ** 2).sum(-1)
            idx = d2.argmin(axis=1); dm = d2[np.arange(len(flat)), idx]
            if best_d is None:
                best, best_d = idx + i, dm
            else:
                upd = dm < best_d
                best[upd] = idx[upd] + i; best_d[upd] = dm[upd]
        return pal[best].reshape(s.shape).astype(np.uint8)

    # -- OSD: nazwa kanału w pikselowej czcionce (maska) nałożona na gotową klatkę
    def osd(self, frame: np.ndarray, text: str):
        if not text:
            return frame
        try:
            from .vid.canvas import Canvas
        except Exception:
            return frame
        c = Canvas(self.w, self.h)
        sc = max(1, self.h // 120)
        c.rect(0, self.h - 16 * sc - 4, min(self.w, 8 * sc * (len(text) + 1)), self.h, (0, 0, 0), 0.55)
        c.text(6 * sc, self.h - 15 * sc, _ascii_fold(text)[:40], sc, (1, 1, 1), 1.0, "left")
        m = c.img[..., :1]
        bright = self.palette()[self.palette().sum(1).argmax()]
        col = np.asarray(bright, np.float32)[None, None, :]
        return np.where(m > 0.05, col.astype(np.uint8), frame)


# ------------------------------------------------------------------ nasłuch → szablon tymczasowy
def listen_template(feats: list[dict]) -> dict:
    """Cechy z ~8 s nasłuchu → parametry szablonu (tymczasowe). Muzyka z basem → NES/PICO-8 i większa reakcja,
    rozmowy/wiadomości → terminal amber/zielony, ambient/cicho → C64. Zwraca dict(patch do params + opis)."""
    if not feats:
        return {}
    punch = np.asarray([max(0.0, min(1.0, f.get("punch", 0.0))) for f in feats], np.float32)
    low = np.asarray([f.get("low", 0.0) for f in feats], np.float32)
    mid = np.asarray([f.get("mid", 0.0) for f in feats], np.float32)
    high = np.asarray([f.get("high", 0.0) for f in feats], np.float32)
    rms = np.asarray([f.get("rms", 0.0) for f in feats], np.float32)
    beat = float(punch.mean()); vary = float(punch.std())
    bass = float(low.mean()); bright = float(high.mean() + 1e-6); mid_e = float(mid.mean())
    loud = float(rms.mean())
    quiet = loud < 0.12
    if bass > 0.45 and beat > 0.3:
        t, px, react = "nes", 4, 65
        why = "mocny bas i wyraźny bit"
    elif bright > bass and beat > 0.18:
        t, px, react = "pico8", 4, 55
        why = "jasne, rytmiczne brzmienie"
    elif mid_e > 0.5 and beat < 0.15 and vary < 0.12:
        t, px, react = "amber", 7, 20
        why = "dominuje mowa (rozmowy/wiadomości)"
    elif beat < 0.12 and loud < 0.2:
        t, px, react = "c64", 8, 18
        why = "spokojne / ambient"
    else:
        t, px, react = "gameboy", 6, 35
        why = "uniwersalny muzyczny środek"
    if quiet:
        react = max(12, react - 15)
    return dict(template=t, pixel=px, react=react, temp=True,
                label=f"tymczasowy: {PALETTES_TV[t][0]} — {why}")


# ------------------------------------------------------------------ pre-analiza stylu kanału → muzyka Live
def build_style_report(st: np.ndarray, sr: int = SR) -> dict | None:
    """PCM f32 (n,2) → pełny raport stylu (listen.py: BPM, tonacja/skala, wagi WSZYSTKICH stylów Studia,
    energia/gęstość, instrumenty…). Okna kroczące 20 s co 2 s — identycznie jak analiza pliku w „Nasłuch”.
    None gdy sygnał za krótki / cichy."""
    from . import listen as LS                          # leniwie (ciągnie generator/styles przy pierwszym raporcie)
    st = np.asarray(st, np.float32)
    if st.ndim != 2 or st.shape[1] < 2 or len(st) < sr * 8:
        return None
    return LS.analyze_stream(st, rate=int(sr), window=20.0, step=2.0)


def style_preset(rep: dict) -> dict:
    """Raport stylu → dane presetu Studia (generator + board + live + director + flags) — ten sam format,
    który „Nasłuch” stosuje przez „Zastosuj”. Start Live nakłada go na Generator przed startem silnika."""
    from . import listen as LS
    return LS.preset_data(rep)


def style_label(rep: dict) -> str:
    """Krótki opis analizy do statusu: styl, BPM, tonacja, energia/gęstość, pewność."""
    g, A = rep.get("generator", {}), rep.get("features", {})
    k = A.get("key")
    key = core.NOTE_NAMES[k] if isinstance(k, int) and 0 <= k < len(core.NOTE_NAMES) else "?"
    return (f"{g.get('style', '?')} · {g.get('bpm', 0)} BPM · {key} {g.get('scale', '')} · "
            f"E{float(g.get('energy', 0)):.2f}/D{float(g.get('density', 0)):.2f} · pewność {float(rep.get('confidence', 0)):.0%}")


# ------------------------------------------------------------------ silnik TV (dekodek → filtr → wyjścia)
class TvStream:
    """Jeden kanał TV: ffmpeg (2 rury) + Analyzer + RetroFilter + RTMP/odsłuch/podgląd. API zbliżone do LiveAV:
    start() / stop() / latest_frame() / status / stats(); set_outputs() przełącza RTMP i odsłuch w locie.
    audio_source: „channel” (dźwięk kanału, domyślnie) albo „live” (muzyka z silnika Live — external_audio)."""

    CH = 2048

    def __init__(self, url, params: dict, rtmp_cfg: dict | None, out_size=(640, 360), fps=25, title="", log=None):
        self.url = str(url); self.params = dict(params); self.rt = dict(rtmp_cfg or {})
        self.rt.setdefault("enabled", False)
        self.out_size = (int(out_size[0]) // 2 * 2, int(out_size[1]) // 2 * 2); self.fps = max(5, min(50, int(fps)))
        self.title = str(title); self.log = log or (lambda m: None)
        w, h = self.out_size
        pd = max(1, min(4, int(self.params.get("pipe_div", 2) or 2)))
        self.pipe = (max(80, w // pd) // 2 * 2, max(45, h // pd) // 2 * 2)
        self.filter = RetroFilter(self.pipe[0], self.pipe[1], self.params)
        self.an = Analyzer()
        self.player = None; self.st = None; self.proc = None; self.pv = None
        self.q = queue.Queue(maxsize=4); self.latest = None
        self.run = False; self.threads: list[threading.Thread] = []
        self.samples = 0; self.sent_v = 0; self.render_ms = 0.0; self.errors = 0
        self.skip = 1; self.last_fr = None; self.dropped_v = 0
        self.listen_until = 0.0; self.listen_buf: list[dict] = []; self.temp_label = ""
        # źródło dźwięku TV: "channel" (kanał) albo "live" (muzyka z silnika Live jako nowy strumień)
        self.audio_src = "live" if str(self.params.get("audio_source") or "channel").strip().lower() == "live" else "channel"
        self.params["audio_source"] = self.audio_src
        # pre-analiza stylu kanału → muzyka Live (Start Live); wynik tylko w pamięci (do Stop)
        self.style_until = 0.0; self.style_buf: list[bytes] = []; self.style_n = 0
        self.style_busy = False; self.style_job = 0
        self.style_report = None; self.style_note = ""
        self.on_style = None                                # callback(rep|None, err) z wątku analizy (GUI przez bridge)
        self.started_at = None; self._err = ""
        self._osd = True

    # ---------- status / API
    @property
    def status(self):
        parts = [f"TV: {self.title[:32]}" if self.title else "TV"]
        if self.proc is not None and self.proc.poll() is None:
            parts.append("dekoder OK")
        else:
            parts.append("brak dekodera" + (f" — {self._err}" if self._err else ""))
        if self.st is not None and getattr(self.st, "net", False):
            parts.append(f"RTMP: {getattr(self.st, 'status', '?')}")
            le = getattr(self.st, "last_error", "")
            if le and getattr(self.st, "status", "") != "nadaje":
                parts[-1] += f" — {le}"
        if self.temp_label:
            parts.append(f"szablon {self.temp_label}")
        if self.audio_src == "live":
            parts.append("audio: muzyka Live (nowy strumień)")
        if self.style_until > 0.0:
            parts.append(f"🎼 pre-analiza stylu… {max(0, int(self.style_until - time.time()))} s")
        elif self.style_busy:
            parts.append("🎼 liczę analizę stylu…")
        if self.sent_v:
            parts.append(f"{self.sent_v} kl. · {self.render_ms:.1f} ms")
        return " · ".join(parts)

    def stats(self):
        return dict(frames=self.sent_v, render_ms=self.render_ms, skip=self.skip, dropped=self.dropped_v,
                    samples=self.samples, temp=bool(self.params.get("temp")), label=self.temp_label)

    def latest_frame(self):
        lf = self.latest
        return None if lf is None else (lf[0], self.pipe[0], self.pipe[1], lf[1])

    # ---------- start / stop
    def start(self):
        if self.run:
            return
        if not ffmpeg_bin():
            self._err = "brak ffmpeg w PATH"; self.log("TV: " + self._err); return
        self.run = True; self.started_at = time.time(); self._err = ""
        self._spawn_decoder()
        self._set_streamer(); self._sync_preview()
        if bool(self.params.get("local_audio", True)):
            self._start_player()
        self.threads = []
        for fn in (self._reader_v, self._reader_a, self._render_loop):
            t = threading.Thread(target=fn, daemon=True); t.start(); self.threads.append(t)
        self.log(f"TV: start {self.title} ({self.url[:80]})")

    def stop(self):
        self.run = False
        p, self.proc = self.proc, None
        if p is not None:
            try:
                if p.stderr is not None:
                    p.stderr.close()
            except Exception:
                pass
            try:
                p.terminate(); p.wait(timeout=3)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        self._set_streamer(None)
        if self.player is not None:
            self.player.stop(); self.player = None
        if self.pv is not None:
            self.pv.stop(); self.pv = None
        self.latest = None; self.temp_label = ""; self.params.pop("temp", None)
        self.style_until = 0.0; self.style_buf = []; self.style_n = 0; self.style_busy = False

    # ---------- źródło dźwięku: kanał albo muzyka Live (nowy strumień dla TV 8-bit)
    def set_audio_source(self, mode: str):
        """„channel” = dźwięk kanału (jak dotąd) | „live” = muzyka generowana przez Live (Start Live):
        reaktywność pikseli, RTMP i odsłuch TV biorą ten nowy strumień zamiast dźwięku kanału."""
        m = "live" if str(mode).strip().lower() == "live" else "channel"
        if m == self.audio_src:
            return
        self.audio_src = m; self.params["audio_source"] = m
        self.log("TV audio: " + ("muzyka z Live (nowy strumień dla TV 8-bit)" if m == "live" else "dźwięk kanału"))

    def external_audio(self, b: bytes):
        """PCM z silnika Live (s16le stereo, SR) — wołane z Output tapu; aktywne tylko przy audio_source = live.
        Karmi Analyzer (reaktywność) oraz wyjścia TV (RTMP / odsłuch lokalny)."""
        if self.audio_src != "live" or not self.run:
            return
        try:
            if len(b) % 4:
                b = b[: len(b) // 4 * 4]
            if not b:
                return
            if self.st is not None:
                self.st.write_audio(b)
            self.an.push(b)
            self.samples += len(b) // 4
            if self.player is not None:
                self.player.write(b)
        except Exception as e:
            self.log(f"TV audio (live): {e}")

    # ---------- pre-analiza stylu kanału (pełny analizator Studia) → muzyka Live
    def start_style_listen(self, seconds=30):
        """Zbiera `seconds` s PCM kanału i liczy pełny raport stylu (listen.py: BPM, tonacja, wagi stylów…).
        Wynik w style_report (tymczasowy, do Stop); „▶ Start Live” użyje go jako presetu Generatora."""
        sec = max(10, min(90, int(seconds)))
        self.style_buf = []; self.style_n = 0
        self.style_until = time.time() + sec
        self.log(f"TV: pre-analiza stylu kanału ({sec} s)…")

    def _style_analyze_async(self):
        """Koniec okna: analiza w wątku tła (STFT — kilka sekund CPU); wynik przez on_style + style_report."""
        chunks, n = self.style_buf, self.style_n
        self.style_buf = []
        self.style_busy = True
        job = self.style_job + 1; self.style_job = job

        def work():
            rep, err = None, ""
            try:
                if n < SR * 8:
                    err = "za krótki fragment audio (potrzeba ~15 s)"
                else:
                    a = np.frombuffer(b"".join(chunks), dtype="<i2").astype(np.float32) / 32768.0
                    rep = build_style_report(a.reshape(-1, 2), SR)
                    if rep is None:
                        err = "cisza — kanał bez audio?"
            except Exception as e:
                err = str(e); rep = None
            self.style_busy = False
            if self.style_job != job:
                return
            if rep is not None:
                self.style_report = rep; self.style_note = style_label(rep)
                self.log("TV pre-analiza stylu: " + self.style_note)
            if self.on_style is not None:
                try:
                    self.on_style(rep, err)
                except Exception:
                    pass

        threading.Thread(target=work, daemon=True, name="ds-tv-style").start()

    # ---------- wyjścia w locie
    def set_outputs(self, rtmp_cfg: dict | None, local: bool):
        """Zmiana RTMP / odsłuchu bez restartu kanału (uruchamia/zatrzymuje enkoder i odtwarzacz)."""
        self.rt = dict(rtmp_cfg or {}); self.rt.setdefault("enabled", False)
        self.params["local_audio"] = bool(local)
        self._set_streamer(); self._sync_preview()
        if local and self.player is None:
            self._start_player()
        elif not local and self.player is not None:
            self.player.stop(); self.player = None

    def _set_streamer(self, st="auto"):
        if st is None:
            if self.st is not None:
                try:
                    self.st.stop()
                except Exception:
                    pass
                self.st = None
            return
        net = bool(self.rt.get("enabled")) and bool((self.rt.get("url") or "").strip())
        key = (net, str(self.rt.get("url") or ""), str(self.rt.get("key") or ""), int(self.rt.get("v_bitrate") or 0), self.out_size, self.fps)
        if net and (not isinstance(self.st, RtmpStreamer) or getattr(self.st, "_cfgkey", None) != key):
            if self.st is not None:
                try:
                    self.st.stop()
                except Exception:
                    pass
            w, h = self.out_size
            cfg = dict(self.rt, out_w=w, out_h=h, fps=self.fps, lite=True, threads=2, nice=5,
                       v_codec="libx264", v_preset="ultrafast", gop_sec=2,
                       v_bitrate=int(self.rt.get("v_bitrate") or 1500), a_bitrate=int(self.rt.get("a_bitrate") or 128))
            self.st = RtmpStreamer(cfg, self.pipe, self.fps, self.log)
            self.st.net = True; self.st._cfgkey = key
            self.st.start()
        elif not net and not isinstance(self.st, NullStreamer):
            if self.st is not None:
                try:
                    self.st.stop()
                except Exception:
                    pass
            self.st = NullStreamer(); self.st.net = False

    def _start_player(self):
        from .live import StreamPlayer          # leniwie (live.py jest ciężki)
        self.player = StreamPlayer()
        if not self.player.start():
            self.log("TV: brak odtwarzacza lokalnego (audio tylko do RTMP)")
            self.player = None

    def _sync_preview(self):
        """Podgląd osobnym oknie (ffplay) — start/stop wg params['preview']; 'gui' obsługuje GUI (latest_frame)."""
        mode = str(self.params.get("preview") or "off").strip().lower()
        if mode == "window" and self.pv is None:
            disp = (self.out_size[0], self.out_size[1]) if self.out_size[0] <= 960 else (960, int(960 * self.out_size[1] / self.out_size[0]) // 2 * 2)
            p = LocalPreview(self.pipe, self.fps, title=f"DS TV 8-bit — {self.title[:40]}", display=disp, log=self.log)
            if p.start():
                self.pv = p
            else:
                self.log("TV podgląd: " + p.error)
        elif mode != "window" and self.pv is not None:
            self.pv.stop(); self.pv = None

    # ---------- dekoder ffmpeg (2 rury wyjściowe: wideo rgb24, audio s16le)
    def _spawn_decoder(self):
        rv, wv = os.pipe(); ra, wa = os.pipe()
        ff = ffmpeg_bin()
        # pass_fds dziedziczy DOKŁADNIE te numery fd — pipe:<nr> musi wskazywać na nie (nie na sztywne 3/4)
        cmd = [ff, "-nostdin", "-loglevel", "warning", "-rw_timeout", "15000000", "-thread_queue_size", "1024"]
        if self.url.lower().startswith(("http://", "https://")):
            # opcje protokołu HTTP (dla plików/rtmp ffmpeg odrzuciłby je jako „Option not found")
            cmd += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5", "-user_agent", UA]
        cmd += ["-i", self.url,
                "-map", "0:v:0", "-vf", f"scale={self.pipe[0]}:{self.pipe[1]}:flags=fast_bilinear",
                "-pix_fmt", "rgb24", "-f", "rawvideo", f"pipe:{wv}",
                "-map", "0:a:0?", "-ar", str(SR), "-ac", "2", "-f", "s16le", f"pipe:{wa}"]
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                         stderr=subprocess.PIPE, pass_fds=(wv, wa))
        except OSError as e:
            os.close(rv); os.close(wv); os.close(ra); os.close(wa)
            self._err = f"ffmpeg: {e}"; self.log("TV: " + self._err); return
        os.close(wv); os.close(wa)
        self._fd_v, self._fd_a = rv, ra
        threading.Thread(target=self._read_err, daemon=True).start()

    def _read_err(self):
        p = self.proc
        if p is None or p.stderr is None:
            return
        try:
            tail = ""
            for ln in p.stderr:
                s = ln.decode("utf-8", "replace").strip()
                if s:
                    tail = (tail + "\n" + s)[-400:]
            if self.run and tail:
                self._err = tail.splitlines()[-1][:200]; self.log("TV dekoder: " + self._err)
        except Exception:
            pass

    # ---------- wątki czytające
    def _read_exact(self, fd, n):
        buf = bytearray()
        while self.run and len(buf) < n:
            try:
                chunk = os.read(fd, n - len(buf))
            except OSError:
                return None
            if not chunk:
                return None
            buf += chunk
        return bytes(buf)

    def _reader_v(self):
        fd = getattr(self, "_fd_v", None)
        if fd is None:
            return
        n = self.pipe[0] * self.pipe[1] * 3
        while self.run:
            b = self._read_exact(fd, n)
            if b is None:
                if self.run and self.proc is not None and self.proc.poll() is not None:
                    self._err = "dekoder zakończony (kanał niedostępny?)"; self.log("TV: " + self._err)
                time.sleep(0.1)
                continue
            try:
                self.q.put_nowait(b)
            except queue.Full:
                self.dropped_v += 1
                try:
                    self.q.get_nowait(); self.q.put_nowait(b)
                except (queue.Empty, queue.Full):
                    pass
        try:
            os.close(fd)
        except OSError:
            pass

    def _reader_a(self):
        fd = getattr(self, "_fd_a", None)
        if fd is None:
            return
        n = self.CH * 4
        while self.run:
            try:
                b = os.read(fd, n)
            except OSError:
                b = b""
            if not b:
                time.sleep(0.02); continue
            if len(b) % 4:
                b = b[: len(b) // 4 * 4]
            if self.style_until > 0.0:                      # pre-analiza stylu: zawsze PCM KANAŁU (to jego styl badamy)
                self.style_buf.append(b); self.style_n += len(b) // 4
                if time.time() >= self.style_until:
                    self.style_until = 0.0
                    self._style_analyze_async()
            if self.audio_src == "channel":                 # przy "live" dźwięk kanału jest zastępowany muzyką z Live
                try:
                    if self.st is not None:
                        self.st.write_audio(b)
                    self.an.push(b)
                    self.samples += len(b) // 4
                    if self.player is not None:
                        try:
                            self.player.write(b)
                        except Exception:
                            pass
                except Exception as e:
                    self.log(f"TV audio: {e}")
        try:
            os.close(fd)
        except OSError:
            pass

    # ---------- wątek renderu: klatka z dekodera → filtr 8-bit → wyjścia
    def _render_loop(self):
        frame_no = 0
        while self.run:
            try:
                b = self.q.get(timeout=0.25)
            except queue.Empty:
                if self.st is not None:
                    try:
                        self.st.maintain()
                    except Exception:
                        pass
                continue
            if self.skip > 1 and frame_no % self.skip:
                frame_no += 1; continue
            t0 = time.perf_counter()
            try:
                img = np.frombuffer(b, np.uint8).reshape(self.pipe[1], self.pipe[0], 3)
                A = self.an.feat(int(self.samples))
                self._listen_tick(A)
                out = self.filter.apply(img, A)
                if self._osd and self.title:
                    out = self.filter.osd(out, self.title)
                fr = np.ascontiguousarray(out).tobytes()
                self.errors = 0
            except Exception as e:
                self.errors += 1; fr = self.last_fr
                if self.errors in (1, 30):
                    self.log(f"TV filtr: {e}")
                if fr is None:
                    frame_no += 1; continue
            dt = (time.perf_counter() - t0) * 1000.0
            self.render_ms = self.render_ms * 0.9 + dt * 0.1
            # lekki AutoTune: gdy filtr nie nadąża za budżetem klatki, co 2. klatkę jest powtarzana
            budget = 1000.0 / self.fps
            self.skip = 2 if self.render_ms > budget * 1.4 else 1
            if self.st is not None:
                try:
                    self.st.maintain(); self.st.write_frame(fr)
                except Exception:
                    pass
            if self.pv is not None:
                try:
                    self.pv.write_frame(fr)
                except Exception:
                    pass
            self.last_fr = fr; self.latest = (fr, self.sent_v); self.sent_v += 1
            frame_no += 1

    def _listen_tick(self, A):
        """Nasłuch 8 s → szablon tymczasowy. Bufor cech zbierany stale; po upływie okna liczony jest dobór."""
        now = time.time()
        if self.listen_until <= 0.0:
            return
        self.listen_buf.append(A)
        if now >= self.listen_until:
            self.listen_until = 0.0
            pick = listen_template(self.listen_buf)
            self.listen_buf = []
            if pick:
                t = pick.pop("template"); lab = pick.pop("label", "")
                self.params.update(pick); self.params["template"] = t; self.params["temp"] = True
                self.temp_label = lab
                self.log(f"TV nasłuch: {lab}")

    def start_listen(self, seconds=8):
        """Przycisk „Nasłuchuj”: od teraz zbieraj cechy przez `seconds` s i dobierz szablon tymczasowy."""
        self.listen_buf = []; self.listen_until = time.time() + max(2, min(30, int(seconds)))


# ------------------------------------------------------------------ pomocnicze dla GUI
def channel_logo(ch: dict, timeout=4) -> bytes | None:
    """Logo kanału (bajty) albo None — wywoływać z wątku tła."""
    url = (ch.get("logo") or "").strip()
    if not url or not url.lower().startswith(("http://", "https://")):
        return None
    try:
        req = Request(url, headers={"User-Agent": UA})
        with urlopen(req, timeout=timeout) as r:
            d = r.read(512 * 1024)
        return d or None
    except Exception:
        return None


def probe_channel(url: str, timeout=8) -> dict:
    """Szybka próba otwarcia kanału przez ffprobe (bez odtwarzania) → dict(ok, info/powód)."""
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return dict(ok=False, info="brak ffprobe")
    cmd = [ffprobe, "-v", "error", "-rw_timeout", str(timeout * 1000000), "-user_agent", UA,
           "-show_entries", "format=format_name:stream=codec_type,codec_name,width,height", "-of", "json", url]
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout + 4)
    except subprocess.TimeoutExpired:
        return dict(ok=False, info="brak odpowiedzi (timeout)")
    if p.returncode != 0:
        return dict(ok=False, info=(p.stderr.decode("utf-8", "replace").strip().splitlines() or ["brak sygnału"])[-1][:120])
    try:
        import json
        j = json.loads(p.stdout.decode("utf-8", "replace"))
        vs = [s for s in j.get("streams", []) if s.get("codec_type") == "video"]
        as_ = [s for s in j.get("streams", []) if s.get("codec_type") == "audio"]
        info = (f"{vs[0].get('codec_name', '?')} {vs[0].get('width', '?')}x{vs[0].get('height', '?')}" if vs else "bez wideo") + \
               (f" · audio {as_[0].get('codec_name', '?')}" if as_ else "")
        return dict(ok=bool(vs), info=info)
    except Exception as e:
        return dict(ok=False, info=f"odpowiedź nierozpoznana: {e}")
