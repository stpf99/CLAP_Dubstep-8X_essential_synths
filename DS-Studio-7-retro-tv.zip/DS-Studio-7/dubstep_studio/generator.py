"""generator.py — losowa aranżacja dubstepu (8 ścieżek) + losowy sound design + domyślne linki między ścieżkami."""
from __future__ import annotations

import random
import time
from collections import Counter

from . import styles as ST
from . import style_variants as SV
from .core import CORE8, MELODIC, SCALES, TYPES, DRUM_SRC, autolevel_heuristic, find_track, first_of_type, meta, new_project, new_track, sanitize_notes, track_of, unique_name

T = lambda *a: list(a)

STYLES = {
    "Brostep": dict(extras=["glitch","hoover","clap","crash","riser","boom","zap","stab","tom","fmbass"], bpm=140, kick=[[0, 10], [0, 7, 10], [0, 6, 10, 14], [0, 10, 13]], hat="16", wob="brostep", growl="brostep",
                    wob_div=[8, 9, 5, 10], growl_div=[8, 9, 10], reese="late", lead="accent", chord_len=1, swing=0.0,
                    template=[("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]),
    "Riddim": dict(extras=["glitch","clap","crash","riser","boom","hollow","rim"], bpm=140, kick=[[0], [0, 10]], hat="8", wob="riddim", growl="riddim", wob_div=[5, 9, 9, 8], growl_div=[8, 9],
                   reese="none", lead="rare", chord_len=2, swing=0.0,
                   template=[("intro", 8), ("build", 4), ("drop", 32), ("break", 8), ("build", 4), ("drop", 32), ("drop", 16), ("outro", 8)]),
    "Tearout": dict(extras=["glitch","clap","crash","riser","boom","zap","neuro","tom","fmbass","rim","stab","openhat"], bpm=150, kick=[[0, 6, 10], [0, 3, 6, 10, 13], [0, 7, 10, 14]], hat="16", wob="tearout", growl="tearout",
                    wob_div=[10, 11, 12], growl_div=[10, 11], reese="all", lead="accent", chord_len=1, swing=0.0,
                    template=[("intro", 8), ("build", 8), ("drop", 24), ("break", 8), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 8)]),
    "Melodic": dict(extras=["choir","bell","clap","crash","riser","boom","supersaw","pluck","pad","vox","shaker","stab","epiano","flute","brass"], bpm=140, kick=[[0, 10]], hat="8", wob="melodic", growl="melodic", wob_div=[3, 4, 5], growl_div=[5, 8],
                    reese="all", lead="melodic", chord_len=2, swing=0.05,
                    template=[("intro", 16), ("build", 8), ("drop", 24), ("break", 24), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]),
    "Deep": dict(extras=["rim","shaker","pad","pluck","boom","crash","riser","drone","bell","vibes","epiano"], bpm=140, kick=[[0, 10], [0, 10, 14]], hat="off", wob="deep", growl="deep", wob_div=[2, 3, 4], growl_div=[5],
                 reese="all", lead="none", chord_len=2, swing=0.08,
                 template=[("intro", 16), ("drop", 32), ("break", 8), ("drop", 32), ("outro", 16)]),
    # ---- v3: nowe style
    "Dubstep": dict(extras=["glitch","clap","crash","riser","boom","zap","stab","tom","fmbass","rim"], bpm=140, kick=[[0, 10], [0, 7, 10], [0, 10, 13]], hat="8", wob="dubstep", growl="brostep",
                    wob_div=[8, 5, 9], growl_div=[8, 9], reese="late", lead="rare", chord_len=2, swing=0.0,
                    template=[("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]),
    "Drumstep": dict(extras=["choir","ride","clap","crash","riser","boom","supersaw","pluck","pad","vox","rim","stab","shaker","openhat"], bpm=174, kick=[[0, 10], [0, 6, 10, 14], [0, 10, 13]], hat="16",
                     snare=[4, 12], wob="drumstep", growl="brostep", wob_div=[9, 10, 8], growl_div=[9, 10], reese="all", lead="melodic", chord_len=2, swing=0.03,
                     template=[("intro", 16), ("build", 8), ("drop", 24), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]),
    "Trap": dict(extras=["clap","rim","crash","riser","boom","zap","pluck","pad","tom","bass808","openhat","bell"], bpm=140, kick=[[0, 7, 10], [0, 6, 11], [0, 10, 14]], hat="trap", wob="trap", growl="deep",
                 wob_div=[5, 8], growl_div=[5], reese="none", lead="rare", chord_len=2, swing=0.0,
                 template=[("intro", 8), ("build", 4), ("drop", 16), ("break", 8), ("build", 4), ("drop", 32), ("outro", 8)]),
    "EDM": dict(extras=["hoover","choir","clap","crash","riser","boom","supersaw","pluck","pad","stab","shaker","vox","brass","openhat"], bpm=128, kick=[[0, 4, 8, 12]], hat="off", snare=[4, 12], fourfloor=True,
                wob="edm", growl="melodic", wob_div=[8, 9], growl_div=[5], reese="all", lead="melodic", chord_len=1, swing=0.0,
                template=[("intro", 16), ("build", 8), ("drop", 16), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]),
}

WOB = {
    "brostep": [[(0, "r", 8)], [(0, "r", 4), (4, "o", 4)], [(0, "r", 6), (6, "t", 2)], [(0, "r", 3), (3, "r", 1), (4, "o", 4)], [(0, "r", 2), (2, "o", 2), (4, "r", 4)]],
    "riddim": [[(0, "r", 3), (4, "r", 3), (8, "r", 3)], [(0, "r", 6), (8, "r", 6)], [(0, "r", 2), (2, "r", 2), (4, "r", 4), (10, "r", 6)],
               [(0, "r", 3), (3, "o", 1), (4, "r", 3), (8, "f", 2), (10, "r", 3)]],
    "tearout": [[(0, "r", 2), (2, "o", 2), (4, "r", 2), (6, "t", 2), (8, "r", 2), (10, "f", 2), (12, "r", 4)], [(0, "r", 4), (4, "o", 4), (8, "r", 4), (12, "b", 4)]],
    "melodic": [[(0, "r", 16)], [(0, "r", 8), (8, "f", 8)], [(0, "r", 12), (12, "o", 4)]],
    "deep": [[(0, "r", 16)], [(0, "r", 12)], [(0, "r", 8), (8, "r", 6)]],
    "dubstep": [[(0, "r", 8), (8, "r", 8)], [(0, "r", 6), (6, "t", 2), (8, "r", 6), (14, "o", 2)], [(0, "r", 4), (4, "o", 4), (8, "r", 4), (12, "f", 4)],
                [(0, "r", 3), (4, "r", 3), (8, "f", 4), (12, "o", 4)]],
    "drumstep": [[(0, "r", 4), (4, "o", 2), (6, "r", 2), (8, "t", 4), (12, "f", 4)], [(0, "r", 2), (2, "r", 2), (4, "f", 4), (8, "r", 4), (12, "o", 4)]],
    "trap": [[(0, "r", 2), (6, "t", 2)], [(0, "r", 3), (10, "f", 3)], [(0, "r", 2), (4, "r", 2), (10, "o", 2)]],
    "edm": [[(0, "r", 2), (4, "r", 2), (8, "r", 2), (12, "r", 2)], [(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "r", 2)]],
}
GROWL = {
    "brostep": [[(8, "r", 2), (10, "o", 2), (12, "r", 1), (13, "t", 1), (14, "o", 2)], [(8, "r", 3), (11, "t", 1), (12, "f", 2), (14, "r", 2)],
                [(8, "o", 2), (10, "r", 2), (12, "f", 2), (14, "t", 2)]],
    "riddim": [[(12, "r", 1), (13, "o", 1), (14, "r", 2)]],
    "tearout": [[(8, "r", 1), (9, "r", 1), (10, "o", 1), (11, "r", 1), (12, "t", 1), (13, "r", 1), (14, "o", 2)],
                [(8, "r", 2), (10, "o", 1), (11, "o", 1), (12, "f", 2), (14, "r", 1), (15, "t", 1)]],
    "melodic": [[(8, "r", 4), (12, "t", 4)]],
    "deep": [],
}
LEAD_RHYTHM = [[(0, 6), (6, 2), (8, 6), (14, 2)], [(0, 4), (4, 4), (8, 4), (12, 4)], [(0, 2), (2, 2), (4, 4), (8, 8)], [(0, 3), (3, 3), (6, 2), (8, 8)]]
PROGS = [[0, 5, 2, 6], [0, 6, 5, 6], [0, 3, 6, 5], [0, 0, 5, 6], [0, 2, 5, 6], [0, 4, 5, 3]]

# --- sound design: (parametr, 'r', lo, hi) | (parametr, 'c', [wybór])   (wartości w jednostkach silnika)
SOUND = {
    "kick": [("Decay", "r", 180, 380), ("Tune", "r", -3, 3), ("Pitch Env Amt", "r", 24, 44), ("Pitch Env Decay", "r", 18, 45),
             ("Noise", "r", 0.05, 0.3), ("Noise Decay", "r", 2, 8), ("Drive", "r", 0.15, 0.6)],
    "snare": [("Tune", "r", -4, 4), ("Decay", "r", 90, 200), ("Pitch Env Amt", "r", 6, 14), ("Noise", "r", 0.6, 1.0), ("Noise Decay", "r", 120, 260),
              ("Noise Highpass", "r", 800, 2500), ("Noise Bursts", "c", [1, 1, 2, 3]), ("Drive", "r", 0.2, 0.6), ("Cutoff", "r", 8000, 16000)],
    "hat": [("Decay", "r", 25, 90), ("Noise", "r", 0.3, 0.7), ("Noise Decay", "r", 25, 70), ("Noise Highpass", "r", 5000, 9000),
            ("Cutoff", "r", 5000, 9000), ("Drive", "r", 0.0, 0.2)],
    "sub": [("Waveform", "c", [0, 0, 1]), ("Glide", "r", 20, 90), ("Drive", "r", 0.05, 0.3), ("Cutoff", "r", 500, 1400), ("Sub Osc", "r", 0.0, 0.3)],
    "wobble": [("Waveform", "c", [2, 2, 3]), ("Wave Morph", "r", 0, 0.5), ("Unison Voices", "c", [1, 2, 3]), ("Unison Detune", "r", 8, 25),
               ("Cutoff", "r", 300, 900), ("Resonance", "r", 0.3, 0.65), ("LFO Shape", "c", [0, 0, 1, 2, 3]), ("LFO > Cutoff", "r", 2.5, 4.5),
               ("Drive", "r", 0.3, 0.6), ("Sub Osc", "r", 0.2, 0.4), ("Glide", "r", 10, 50)],
    "reese": [("Unison Voices", "c", [2, 3, 4, 5]), ("Unison Detune", "r", 14, 40), ("Cutoff", "r", 1200, 3500), ("Resonance", "r", 0.1, 0.35),
              ("LFO Rate", "r", 0.1, 0.5), ("LFO > Cutoff", "r", 1.0, 2.5), ("Drive", "r", 0.35, 0.7), ("Glide", "r", 40, 120),
              ("Sub Osc", "r", 0.2, 0.4), ("LFO Shape", "c", [0, 1])],
    "growl": [("Wave Morph", "r", 0.1, 0.6), ("FM Amount", "r", 0.3, 0.7), ("FM Ratio", "c", [1, 1.5, 2, 3, 3.01, 4, 5]), ("Formant Mix", "r", 0.6, 1.0),
              ("Vowel A-E-I-O-U", "r", 0, 3), ("LFO > Vowel", "r", 1, 3), ("Cutoff", "r", 3000, 9000), ("Resonance", "r", 0.2, 0.5),
              ("LFO Shape", "c", [1, 0, 2]), ("LFO > FM", "r", 0.1, 0.5), ("Drive", "r", 0.5, 0.85), ("Glide", "r", 15, 60)],
    "screech": [("Unison Voices", "c", [3, 5, 7]), ("Unison Detune", "r", 15, 40), ("FM Amount", "r", 0.35, 0.7), ("FM Ratio", "c", [2, 3.01, 3.5, 5, 7.01]),
                ("Cutoff", "r", 5000, 12000), ("Filter Env Amt", "r", 1, 3), ("Pitch Env Amt", "r", 3, 8), ("Pitch Env Decay", "r", 40, 120),
                ("Glide", "r", 50, 140), ("LFO > Pitch", "r", 0.1, 0.4), ("LFO Rate", "r", 4.5, 6.5), ("Drive", "r", 0.3, 0.6)],
}
SOUND.update({
    "clap": [("Noise Decay", "r", 150, 300), ("Noise Highpass", "r", 600, 1400), ("Noise Lowpass", "r", 3500, 7000), ("Noise Bursts", "c", [3, 4, 5]), ("Drive", "r", 0.2, 0.5)],
    "rim": [("Waveform", "c", [0, 1]), ("Decay", "r", 25, 70), ("Pitch Env Amt", "r", 4, 12), ("Noise", "r", 0.1, 0.4), ("Noise Highpass", "r", 2000, 5000), ("Tune", "r", -4, 6)],
    "tom": [("Decay", "r", 250, 500), ("Pitch Env Amt", "r", 8, 18), ("Pitch Env Decay", "r", 40, 90), ("Drive", "r", 0.1, 0.35)],
    "crash": [("Decay", "r", 1200, 2600), ("Noise Decay", "r", 1000, 2200), ("Noise Highpass", "r", 3000, 6000), ("Cutoff", "r", 2000, 5000), ("Tone Level", "r", 0.3, 0.8)],
    "shaker": [("Noise Decay", "r", 40, 110), ("Noise Highpass", "r", 4000, 7000), ("Noise Lowpass", "r", 9000, 15000), ("Noise Bursts", "c", [1, 2, 3])],
    "fmbass": [("FM Amount", "r", 0.3, 0.7), ("FM Ratio", "c", [0.5, 1, 1, 2, 3]), ("LFO Shape", "c", [0, 1, 2]), ("LFO > FM", "r", 0.15, 0.5), ("Drive", "r", 0.35, 0.7),
               ("Cutoff", "r", 2500, 7000), ("Glide", "r", 0, 50), ("Sub Osc", "r", 0.1, 0.3)],
    "neuro": [("Unison Voices", "c", [2, 3, 4]), ("Unison Detune", "r", 10, 30), ("FM Amount", "r", 0.15, 0.5), ("FM Ratio", "c", [1, 2, 3, 3.01]), ("Formant Mix", "r", 0.4, 0.85),
              ("Vowel A-E-I-O-U", "r", 0, 3), ("Cutoff", "r", 1800, 4000), ("Resonance", "r", 0.3, 0.6), ("LFO Shape", "c", [0, 1, 2]), ("LFO > Cutoff", "r", 1.5, 3.5),
              ("LFO > Vowel", "r", 1, 3), ("Drive", "r", 0.65, 0.95)],
    "hollow": [("Pulse Width", "r", 0.15, 0.4), ("Unison Voices", "c", [1, 2, 3]), ("Unison Detune", "r", 5, 14), ("Cutoff", "r", 450, 1100), ("Resonance", "r", 0.25, 0.55),
               ("LFO Shape", "c", [0, 1, 3]), ("LFO > Cutoff", "r", 1.5, 3.0), ("Drive", "r", 0.3, 0.6), ("Sub Osc", "r", 0.2, 0.45)],
    "supersaw": [("Unison Detune", "r", 20, 50), ("Cutoff", "r", 5000, 12000), ("Attack", "r", 5, 80), ("Release", "r", 200, 800), ("Drive", "r", 0.05, 0.3), ("Filter Env Amt", "r", 0.5, 2.5)],
    "pluck": [("Waveform", "c", [2, 3]), ("Wave Morph", "r", 0, 0.6), ("Decay", "r", 120, 400), ("Cutoff", "r", 900, 2500), ("Filter Env Amt", "r", 2, 4), ("Filter Env Decay", "r", 90, 260), ("Resonance", "r", 0.15, 0.4)],
    "pad": [("Wave Morph", "r", 0.2, 0.7), ("Attack", "r", 500, 1800), ("Release", "r", 900, 3000), ("Unison Detune", "r", 12, 32), ("Cutoff", "r", 1500, 3500), ("LFO Rate", "r", 0.1, 0.35), ("Sub Osc", "r", 0.1, 0.35)],
    "stab": [("Waveform", "c", [2, 3]), ("Unison Detune", "r", 10, 28), ("FM Amount", "r", 0.05, 0.4), ("Decay", "r", 100, 250), ("Cutoff", "r", 2000, 5000), ("Filter Env Amt", "r", 1.5, 3.5), ("Drive", "r", 0.2, 0.55)],
    "riser": [("Unison Voices", "c", [3, 5, 7]), ("Unison Detune", "r", 20, 45), ("Cutoff", "r", 250, 700), ("Resonance", "r", 0.25, 0.55), ("Ramp > Cutoff", "r", 3.5, 6), ("Ramp > Pitch", "r", 12, 36),
              ("Noise", "r", 0.3, 0.7), ("Noise Highpass", "r", 400, 1500)],
    "boom": [("Decay", "r", 1800, 3500), ("Pitch Env Amt", "r", 20, 40), ("Pitch Env Decay", "r", 300, 700), ("Noise", "r", 0.1, 0.4), ("Drive", "r", 0.15, 0.45)],
    "zap": [("Waveform", "c", [2, 3]), ("Pitch Env Amt", "r", 36, 60), ("Pitch Env Decay", "r", 150, 450), ("FM Amount", "r", 0.2, 0.6), ("FM Ratio", "c", [1, 2, 3, 3.01, 5]), ("Decay", "r", 250, 600)],
    "vox": [("Vowel A-E-I-O-U", "r", 0, 4), ("Formant Mix", "r", 0.55, 1.0), ("Unison Detune", "r", 4, 22),
            ("Decay", "r", 100, 380), ("Cutoff", "r", 4000, 12000), ("Drive", "r", 0.08, 0.45),
            ("Glide", "r", 8, 160), ("LFO > Pitch", "r", 0.0, 0.55), ("LFO Rate", "r", 3.5, 7.0),
            ("Pitch Env Amt", "r", 0, 10), ("Pitch Env Decay", "r", 30, 180)],
})
SOUND["speak"] = [("Dialect", "c", [0, 0, 1, 2, 3]), ("Speech Speed", "r", 0.8, 1.25), ("Morph Time", "r", 18, 70),
                  ("Formant Shift", "r", -6, 6), ("Letter Pitch Range", "r", 3, 14), ("Intonation", "r", 0.25, 1.0),
                  ("Breath", "r", 0.0, 0.3), ("Unison Voices", "c", [1, 2, 3, 4]), ("Unison Detune", "r", 3, 18),
                  ("Drive", "r", 0.05, 0.35), ("Cutoff", "r", 5000, 13000), ("Waveform", "c", [2, 2, 3]),
                  ("Glide", "r", 5, 120), ("LFO > Pitch", "r", 0.0, 0.45), ("LFO Rate", "r", 3.0, 6.8)]
SOUND.update({
    "theremin": [("LFO > Pitch", "r", 0.2, 0.6), ("LFO Rate", "r", 4.8, 6.6), ("Glide", "r", 90, 220), ("Formant Mix", "r", 0.1, 0.35),
                 ("Vowel A-E-I-O-U", "r", 2.5, 4), ("Cutoff", "r", 3500, 6000), ("Wave Morph", "r", 0.05, 0.3)],
    "panflute": [("Noise", "r", 0.15, 0.32), ("Wave Morph", "r", 0.15, 0.5), ("Attack", "r", 40, 110), ("LFO > Pitch", "r", 0.05, 0.2), ("Cutoff", "r", 5000, 8000)],
    "handpan": [("Ring Time", "r", 1200, 2600), ("Strike Brightness", "r", 0.4, 0.75), ("Pitch Env Amt", "r", 0, 3), ("Noise", "r", 0.03, 0.1)],
    "tongue": [("Ring Time", "r", 600, 1300), ("Strike Brightness", "r", 0.35, 0.7), ("Noise", "r", 0.08, 0.18)],
    "piano": [("Attack", "r", 1, 8), ("Decay", "r", 600, 1400), ("Release", "r", 300, 700), ("Unison Detune", "r", 3, 12),
              ("Cutoff", "r", 3500, 8000), ("Filter Env Amt", "r", 0.5, 2.0), ("Noise", "r", 0.02, 0.08), ("Drive", "r", 0.0, 0.15)],
    "acid": [("Waveform", "c", [2, 3]), ("Pulse Width", "r", 0.25, 0.55), ("Cutoff", "r", 400, 2500), ("Resonance", "r", 0.55, 0.95),
             ("Filter Env Amt", "r", 1.5, 3.5), ("Filter Env Decay", "r", 120, 400), ("Glide", "r", 10, 90), ("Drive", "r", 0.25, 0.65)],
    "strings": [("Attack", "r", 200, 600), ("Release", "r", 800, 2000), ("Unison Voices", "c", [4, 5, 6, 7]), ("Unison Detune", "r", 12, 28),
                ("Cutoff", "r", 2800, 6500), ("LFO > Cutoff", "r", 0.3, 1.0), ("LFO Rate", "r", 0.15, 0.6), ("Drive", "r", 0.0, 0.15)],
})
SOUND.update({
    "organ": [("Unison Detune", "r", 2, 9), ("Sub Osc", "r", 0.2, 0.6), ("Cutoff", "r", 3500, 9000), ("LFO > Pitch", "r", 0.02, 0.12), ("LFO Rate", "r", 5, 7.5), ("Drive", "r", 0.05, 0.3)],
    "epiano": [("Decay", "r", 700, 1500), ("FM Amount", "r", 0.08, 0.22), ("Cutoff", "r", 3000, 7500), ("Filter Env Amt", "r", 0.5, 1.8), ("Unison Detune", "r", 2, 8), ("Drive", "r", 0.0, 0.15)],
    "harpsichord": [("Wave Morph", "r", 0.3, 0.9), ("Decay", "r", 350, 700), ("Cutoff", "r", 2800, 5500), ("Filter Env Amt", "r", 0.8, 2.2), ("Noise", "r", 0.03, 0.1)],
    "flute": [("Attack", "r", 25, 80), ("Noise", "r", 0.1, 0.26), ("LFO > Pitch", "r", 0.08, 0.25), ("Cutoff", "r", 6000, 9500), ("Wave Morph", "r", 0.05, 0.3)],
    "brass": [("Attack", "r", 25, 90), ("Cutoff", "r", 1000, 2200), ("Filter Env Amt", "r", 1.5, 3.0), ("Unison Detune", "r", 5, 14), ("Drive", "r", 0.15, 0.4)],
    "choir": [("Vowel A-E-I-O-U", "r", 0, 3.5), ("Formant Mix", "r", 0.7, 1.0), ("Attack", "r", 300, 900), ("Release", "r", 900, 2200), ("Unison Detune", "r", 8, 22), ("LFO > Vowel", "r", 0.5, 2.0)],
    "cello": [("Attack", "r", 60, 160), ("Cutoff", "r", 1200, 2600), ("LFO > Pitch", "r", 0.06, 0.2), ("Glide", "r", 15, 60), ("Unison Detune", "r", 4, 12)],
    "vibes": [("Ring Time", "r", 1800, 3600), ("Strike Brightness", "r", 0.3, 0.6), ("Noise", "r", 0.02, 0.08)],
    "marimba": [("Ring Time", "r", 300, 650), ("Strike Brightness", "r", 0.35, 0.65), ("Noise", "r", 0.06, 0.16)],
    "bell": [("Ring Time", "r", 2500, 5000), ("Strike Brightness", "r", 0.4, 0.8), ("Noise", "r", 0.01, 0.06)],
    "hoover": [("Unison Detune", "r", 25, 55), ("Glide", "r", 40, 110), ("Pitch Env Amt", "r", 4, 10), ("Cutoff", "r", 3000, 7000), ("Drive", "r", 0.4, 0.8), ("FM Amount", "r", 0.15, 0.45)],
    "bass808": [("Decay", "r", 600, 1600), ("Glide", "r", 30, 120), ("Pitch Env Amt", "r", 3, 10), ("Drive", "r", 0.2, 0.55)],
    "upright": [("Decay", "r", 250, 520), ("Cutoff", "r", 500, 1000), ("Filter Env Amt", "r", 1.2, 2.4), ("Noise", "r", 0.02, 0.09)],
    "drone": [("Attack", "r", 1200, 2800), ("Cutoff", "r", 450, 1200), ("LFO Rate", "r", 0.04, 0.15), ("LFO > Cutoff", "r", 0.8, 2.0), ("Unison Detune", "r", 8, 20)],
    "openhat": [("Decay", "r", 250, 520), ("Cutoff", "r", 5500, 8500)],
    "ride": [("Decay", "r", 800, 1600), ("Cutoff", "r", 3500, 6000), ("Noise", "r", 0.25, 0.45)],
    "cowbell": [("Decay", "r", 110, 230), ("FM Amount", "r", 0.15, 0.4), ("Cutoff", "r", 1400, 2600), ("Drive", "r", 0.15, 0.4)],
    "conga": [("Decay", "r", 180, 360), ("Pitch Env Amt", "r", 5, 12), ("Noise", "r", 0.08, 0.2)],
    "glitch": [("Decay", "r", 40, 140), ("Pitch Env Amt", "r", 12, 40), ("FM Amount", "r", 0.4, 0.8), ("Cutoff", "r", 3000, 9000), ("Resonance", "r", 0.4, 0.8), ("Drive", "r", 0.4, 0.8)],
})
SOUND_STYLE = {
    "EDM": {"kick": [("Decay", "r", 200, 320), ("Noise", "r", 0.05, 0.15)], "hat": [("Decay", "r", 40, 90)], "sub": [("Glide", "r", 0, 20)]},
    "Trap": {"sub": [("Glide", "r", 60, 160), ("Sub Osc", "r", 0.0, 0.1), ("Drive", "r", 0.1, 0.3)], "hat": [("Decay", "r", 18, 45)], "kick": [("Decay", "r", 120, 220)]},
    "Drumstep": {"kick": [("Decay", "r", 120, 220)], "hat": [("Decay", "r", 20, 55)]},
    "Tearout": {"hat": [("Decay", "r", 20, 50)], "kick": [("Decay", "r", 140, 260)], "growl": [("Drive", "r", 0.7, 0.95)]},
    "Riddim": {"sub": [("Glide", "r", 0, 20)], "wobble": [("Glide", "r", 0, 12), ("Drive", "r", 0.45, 0.75)]},
    "Deep": {"sub": [("Sub Osc", "r", 0.0, 0.1)], "hat": [("Noise", "r", 0.15, 0.4)], "reese": [("Cutoff", "r", 800, 2000)]},
    "Melodic": {"screech": [("Cutoff", "r", 4000, 9000), ("Drive", "r", 0.15, 0.4)], "wobble": [("Drive", "r", 0.15, 0.4)]},
}


# agresja instrumentu 0 (łagodny) … 5 (agresywny) — do wagowego doboru i zawężania parametrów
INST_AGG = {
    "kick": 3.0, "snare": 3.5, "hat": 2.0, "clap": 3.0, "rim": 1.5, "tom": 2.5, "crash": 3.5, "shaker": 1.0,
    "sub": 2.0, "wobble": 3.5, "reese": 2.5, "growl": 4.5, "neuro": 4.5, "fmbass": 3.5, "hollow": 2.0, "acid": 3.5, "piano": 1.0, "strings": 0.5,
    "screech": 4.5, "supersaw": 2.5, "pluck": 1.5, "pad": 0.5, "stab": 3.0, "vox": 2.0,
    "riser": 3.5, "boom": 4.0, "zap": 3.5, "speak": 2.5,
    "theremin": 1.0, "panflute": 0.5, "handpan": 0.5, "tongue": 0.5,
}
INST_AGG.update(organ=1.5, epiano=1.0, harpsichord=1.0, flute=0.5, brass=2.5, choir=0.5, cello=0.5, vibes=0.5, marimba=0.5, bell=0.5, hoover=4.0,
                bass808=3.0, upright=1.0, drone=0.5, openhat=2.0, ride=1.5, cowbell=2.0, conga=1.5, glitch=4.0)
# wagi pasm (sub, low, mid, high) — sumują się ~1; używane do bilansu spektrum przy doborze
INST_BANDS = {
    "kick": (0.35, 0.45, 0.15, 0.05), "snare": (0.05, 0.20, 0.45, 0.30), "hat": (0.0, 0.05, 0.25, 0.70),
    "clap": (0.0, 0.15, 0.50, 0.35), "rim": (0.0, 0.10, 0.55, 0.35), "tom": (0.15, 0.50, 0.30, 0.05),
    "crash": (0.0, 0.10, 0.30, 0.60), "shaker": (0.0, 0.0, 0.20, 0.80),
    "sub": (0.85, 0.15, 0.0, 0.0), "wobble": (0.40, 0.35, 0.20, 0.05), "reese": (0.30, 0.40, 0.25, 0.05),
    "growl": (0.20, 0.30, 0.35, 0.15), "neuro": (0.15, 0.25, 0.40, 0.20), "fmbass": (0.25, 0.35, 0.30, 0.10),
    "hollow": (0.35, 0.40, 0.20, 0.05), "screech": (0.05, 0.10, 0.30, 0.55),
    "supersaw": (0.05, 0.15, 0.45, 0.35), "pluck": (0.05, 0.20, 0.50, 0.25), "pad": (0.10, 0.30, 0.40, 0.20),
    "stab": (0.05, 0.20, 0.45, 0.30), "vox": (0.05, 0.15, 0.50, 0.30),
    "riser": (0.10, 0.20, 0.30, 0.40), "boom": (0.50, 0.35, 0.10, 0.05), "zap": (0.05, 0.15, 0.35, 0.45),
    "speak": (0.05, 0.20, 0.50, 0.25), "theremin": (0.05, 0.15, 0.50, 0.30), "panflute": (0.05, 0.15, 0.45, 0.35),
    "handpan": (0.10, 0.30, 0.45, 0.15), "tongue": (0.10, 0.25, 0.50, 0.15),
}
INST_BANDS.update(organ=(0.10, 0.30, 0.45, 0.15), epiano=(0.05, 0.30, 0.45, 0.20), harpsichord=(0.0, 0.15, 0.50, 0.35), flute=(0.0, 0.10, 0.50, 0.40),
                  brass=(0.05, 0.25, 0.50, 0.20), choir=(0.05, 0.25, 0.55, 0.15), cello=(0.10, 0.40, 0.40, 0.10), vibes=(0.0, 0.15, 0.50, 0.35),
                  marimba=(0.0, 0.25, 0.55, 0.20), bell=(0.0, 0.05, 0.40, 0.55), hoover=(0.05, 0.20, 0.45, 0.30), bass808=(0.80, 0.20, 0.0, 0.0),
                  upright=(0.35, 0.50, 0.15, 0.0), drone=(0.25, 0.40, 0.30, 0.05), openhat=(0.0, 0.0, 0.20, 0.80), ride=(0.0, 0.05, 0.30, 0.65),
                  cowbell=(0.0, 0.10, 0.65, 0.25), conga=(0.10, 0.45, 0.35, 0.10), glitch=(0.05, 0.15, 0.40, 0.40))
# grupy do osobnego losowania (perkusja / bas / lead / fx / akustyczne)
INST_GROUPS = {
    "drums": ["kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "openhat", "ride", "cowbell", "conga"],
    "bass": ["sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow", "acid", "bass808", "upright"],
    "lead": ["screech", "supersaw", "pluck", "pad", "stab", "vox", "piano", "strings", "hoover", "epiano", "organ", "harpsichord", "brass", "choir", "cello", "drone"],
    "fx": ["riser", "boom", "zap", "glitch"],
    "acoustic": ["theremin", "panflute", "handpan", "tongue", "flute", "vibes", "marimba", "bell"],
}
# parametry, których wyższa wartość = agresywniej (bias w stronę celu)
AGG_UP = {"Drive", "Noise", "Resonance", "FM Amount", "Pitch Env Amt", "Filter Env Amt", "Unison Detune",
          "LFO > Cutoff", "LFO > FM", "LFO > Vowel", "Ramp > Cutoff", "Ramp > Pitch", "Formant Mix"}
# parametry, których niższa wartość = agresywniej (np. Decay na hat/kick bywa krótszy)
AGG_DOWN = {"Decay", "Attack", "Release", "Glide", "Morph Time"}


def style_aggression(style, energy=0.7, density=0.6):
    """0…5 — charakter ostrości gatunku (STYLE_CLASS) + energia/gęstość projektu."""
    parts = STYLES.parts(style)
    if not parts:
        base = ST.STYLE_CLASS.get(style, 2.5)
    else:
        base = sum(ST.STYLE_CLASS.get(n, 2.5) * w for n, w in parts.items())
    # energia podnosi, niska gęstość lekko łagodzi
    return max(0.0, min(5.0, base * 0.72 + energy * 1.6 + density * 0.6))


def _band_target(agg):
    """Docelowy wektor pasm (sub, low, mid, high) w zależności od agresji: łagodne = więcej sub/low, ostre = mid/high."""
    t = agg / 5.0
    return (0.35 - 0.20 * t, 0.30 - 0.05 * t, 0.20 + 0.10 * t, 0.15 + 0.15 * t)


def _inst_score(tt, target_agg, band_tgt, density, already=None, clarity=0.0):
    """Dopasowanie: agresja + pasma + komplementarność względem już wybranych."""
    a = INST_AGG.get(tt, 2.5)
    bands = INST_BANDS.get(tt, (0.25, 0.25, 0.25, 0.25))
    da = abs(a - target_agg)
    sa = max(0.05, 1.0 - (da / 3.0) ** 1.5)
    sb = sum(b * t for b, t in zip(bands, band_tgt))
    sd = 0.85 + 0.3 * density * (bands[2] + bands[3])
    # kara za dublowanie tego samego „profilu” pasm
    sc = 1.0
    if already:
        for ot in already:
            ob = INST_BANDS.get(ot, (0.25, 0.25, 0.25, 0.25))
            sim = sum(min(x, y) for x, y in zip(bands, ob))  # overlap 0..1
            if ot == tt:
                sc *= 0.15
            elif sim > 0.55:
                sc *= max(0.25 - 0.2 * clarity, (1.0 - 0.7 * (sim - 0.55)) ** (1.0 + 2.5 * clarity))
            # bonus jeśli uzupełnia puste pasmo
            for i in range(4):
                if band_tgt[i] > 0.25 and ob[i] < 0.12 and bands[i] > 0.25:
                    sc *= 1.15
    return max(0.02, sa * (0.5 + 1.0 * sb) * sd * sc)


def pick_smart_instruments(style, energy=0.7, density=0.6, seed=None, include=None, clarity=None):
    """Wagowy dobór instrumentów: charakter gatunku + bilans pasm + osobne losowanie perkusji i reszty.
    include — typy zawsze dołączane (np. speak).
    clarity 0..1 (None = jak dawniej): im wyżej, tym mniej nakładających się warstw w tym samym paśmie (bas, lead, FX) i ostrzejsza kara za dublowanie profilu pasm."""
    rng = random.Random(seed)
    cl = 0.0 if clarity is None else max(0.0, min(1.0, float(clarity)))
    cfg = STYLES[style]
    core = list(cfg.get("core", CORE8))
    extras = [t for t in cfg.get("extras", []) if t not in core]
    pool = list(dict.fromkeys(core + extras))  # zachowaj kolejność, bez duplikatów
    avail = set(pool)
    target = style_aggression(style, energy, density)
    band_tgt = _band_target(target)
    chosen = []

    def pick_from(cands, k, force=None):
        cands = [t for t in cands if t in avail and t not in chosen]
        if force:
            for f in force:
                if f in avail and f not in chosen:
                    chosen.append(f)
                    if f in cands:
                        cands.remove(f)
        if k <= 0 or not cands:
            return
        # losowanie bez zwracania; wagi odświeżane (komplementarność)
        for _ in range(min(k, len(cands))):
            weights = [_inst_score(t, target, band_tgt, density, chosen, cl) for t in cands]
            tot = sum(weights)
            if tot <= 0:
                break
            r = rng.random() * tot
            acc = 0.0
            idx = 0
            for i, w in enumerate(weights):
                acc += w
                if r <= acc:
                    idx = i
                    break
            chosen.append(cands[idx])
            cands.pop(idx)

    # --- perkusja: kick prawie zawsze gdy w puli; reszta wg gęstości i charakteru
    drums = [t for t in INST_GROUPS["drums"] if t in avail]
    n_drums = 1 + int(1.2 + density * 3.5 + (0.4 if target > 3 else 0))  # 2…5-ish
    n_drums = max(2, round(n_drums * (1.0 - 0.25 * cl)))
    force_d = ["kick"] if "kick" in avail else []
    if target >= 2.5 and "snare" in avail:
        force_d.append("snare")
    if density > 0.45 and "hat" in avail:
        force_d.append("hat")
    pick_from(drums, n_drums, force=force_d)

    # --- bas: sub + 1–3 warstwy zależnie od agresji/gęstości
    bass = [t for t in INST_GROUPS["bass"] if t in avail]
    n_bass = 1 + int(0.6 + density * 2.2 + (0.5 if target > 2.5 else 0))
    n_bass = max(1 + (1 if cl < 0.75 else 0), round(n_bass * (1.0 - 0.5 * cl)))      # klarowność: mniej warstw basu naraz
    force_b = ["sub"] if "sub" in avail else []
    if target >= 2.0 and "wobble" in avail and (cl < 0.5 or n_bass >= 2):
        force_b.append("wobble")
    pick_from(bass, n_bass, force=force_b)

    # --- lead / synth
    lead = [t for t in INST_GROUPS["lead"] if t in avail]
    n_lead = int(0.4 + density * 2.5 + (0.3 if target < 2 else 0.6 if target > 3.5 else 0.4))
    # łagodne style wolą pad/pluck; ostre screech/stab
    pick_from(lead, max(0, round(n_lead * (1.0 - 0.35 * cl))))

    # --- FX
    fx = [t for t in INST_GROUPS["fx"] if t in avail]
    n_fx = int(0.3 + density * 1.8 + (0.4 if target > 3 else 0))
    pick_from(fx, max(0, round(n_fx * (1.0 - 0.35 * cl))))

    # --- akustyczne tylko przy niskiej/średniej agresji
    if target < 2.8:
        ac = [t for t in INST_GROUPS["acoustic"] if t in avail]
        pick_from(ac, 1 if density > 0.35 and rng.random() < 0.55 else 0)

    # zawsze dołącz typy z include (speak itd.)
    if include:
        for t in include:
            if t not in chosen and t in TYPES:
                chosen.append(t)

    # minimum: jeśli pusto (dziwny styl), wróć do core
    if not chosen:
        chosen = list(core) or list(CORE8)
    # zachowaj sensowną kolejność typów
    order = {t: i for i, t in enumerate(TYPES)}
    chosen.sort(key=lambda t: order.get(t, 99))
    return chosen


def _bias_range(lo, hi, target_agg, direction="+"):
    """Zawęża [lo,hi] do okna wokół pozycji wynikającej z agresji (0…5 → 0…1).
    direction='+': wyższa agresja → górna część zakresu; '-' → dolna."""
    t = max(0.0, min(1.0, target_agg / 5.0))
    if direction == "-":
        t = 1.0 - t
    span = hi - lo
    # okno ~45% zakresu, środek przesunięty w stronę t
    half = 0.22 * span
    center = lo + t * span
    a = max(lo, center - half)
    b = min(hi, center + half)
    if b - a < 0.08 * span:  # zabezpieczenie przy bardzo wąskim
        a, b = lo + 0.15 * span * t, lo + 0.15 * span * t + 0.35 * span
        a, b = max(lo, a), min(hi, b)
    return a, b



# kierunek „rdzenia” parametru względem agresji / jasności (dla wąskich okien)
# +1 = wyższa agresja → wyższa wartość; -1 odwrotnie; 0 = neutralny (środek stylu)
PARAM_DIR = {
    "Drive": 1, "FM Amount": 1, "Resonance": 1, "Noise": 1, "Unison Detune": 0.5,
    "Filter Env Amt": 1, "Pitch Env Amt": 0.8, "LFO > Cutoff": 0.7, "LFO > FM": 0.7,
    "LFO > Vowel": 0.5, "LFO > Pitch": 0.4, "Distortion": 1, "Bitcrush": 1,
    "Cutoff": 0.6, "Wave Morph": 0.3, "Sub Osc": -0.4, "Glide": -0.5,
    "Attack": -0.7, "Decay": -0.4, "Release": -0.5, "Morph Time": -0.3,
    "Level": 0.0, "Fine": 0.0,
}


def smart_param_window(name, lo, hi, A, o, tt, width=None):
    """Wąskie okno [a,b] ⊂ [lo,hi] zamiast pełnego zakresu.

    A,o w 0..1; width ~ ułamek zakresu (domyślnie 0.28–0.40 zależnie od typu).
    """
    span = float(hi) - float(lo)
    if span <= 0:
        return lo, hi
    # szerokość: basy nieco węższe, lead/fx szersze
    if width is None:
        if tt in ("sub", "kick", "snare", "hat", "rim", "clap"):
            width = 0.26
        elif tt in ("wobble", "reese", "growl", "neuro", "fmbass", "acid"):
            width = 0.32
        elif tt in ("pad", "strings", "hollow", "handpan", "tongue"):
            width = 0.30
        else:
            width = 0.36
    half = 0.5 * width * span
    d = PARAM_DIR.get(name, 0.0)
    # pozycja środka: baza 0.45 + wpływ A/o
    center_t = 0.42 + 0.35 * (A - 0.5) * (d if d != 0 else 0.25)
    if name in ("Cutoff", "Wave Morph", "Unison Detune"):
        center_t += 0.12 * (o - 0.5)
    if name in ("Sub Osc", "Glide") and tt in ("sub", "wobble", "reese"):
        center_t = 0.55 - 0.15 * A
    center_t = max(0.05, min(0.95, center_t))
    center = lo + center_t * span
    a = max(lo, center - half)
    b = min(hi, center + half)
    if b - a < 0.1 * span:
        mid = (lo + hi) / 2
        a, b = max(lo, mid - 0.12 * span), min(hi, mid + 0.12 * span)
    return a, b


def randomize_sound(proj, tr, rng, A=None, o=None, use_windows=False, forced_params=None):
    """Losuje parametry brzmienia. Szanuje tr['lock_sound'] i tr['locked_params'].
    Gdy use_windows i A,o podane — okna z director.window zamiast pełnego min…max / smart bias."""
    if tr.get("lock_sound"):
        return
    locked = set(tr.get("locked_params") or [])
    forced = dict(forced_params or {})
    m = meta(); style = proj["style"]; tt = tr["type"]
    smart = bool(proj.get("smart_instruments")) and not use_windows
    target = float(proj.get("aggression", style_aggression(style, proj.get("energy", 0.7), proj.get("density", 0.6))))
    # aggression w proj bywa 0..5 (stare) albo 0..1 (director) — okna używają 0..1
    if A is None and use_windows:
        A = min(1.0, target / 5.0) if target > 1.5 else float(target)
    if o is None:
        o = 0.5
    spec = {p[0]: p for p in SOUND.get(tt, [])}
    for p in style_sound(proj, tr):
        spec[p[0]] = p
    for name, sp in spec.items():
        if name in locked or not m.has(tt, name):
            continue
        if name in forced:
            # wymuszona wartość w jednostkach silnika (eng)
            try:
                tr["params"][name] = m.eng2frac(tt, name, float(forced[name]))
            except Exception:
                tr["params"][name] = float(forced[name]) if 0 <= float(forced[name]) <= 1 else m.eng2frac(tt, name, float(forced[name]))
            continue
        if sp[1] == "r":
            lo, hi = float(sp[2]), float(sp[3])
            # zawsze wąskie okna gdy smart / director windows / domyślny smart_tune
            do_win = use_windows or smart or bool(proj.get("smart_tune", True))
            A_use = A if A is not None else min(1.0, target / 5.0)
            if do_win:
                if use_windows and A is not None:
                    try:
                        from . import director as DIR
                        e = DIR.window(name, sp, A, o, rng)
                    except Exception:
                        a, b = smart_param_window(name, lo, hi, A_use, o, tt)
                        e = rng.uniform(a, b)
                else:
                    a, b = smart_param_window(name, lo, hi, A_use, o, tt)
                    e = rng.uniform(a, b)
            else:
                e = rng.uniform(lo, hi)
        else:
            choices = list(sp[2])
            A_use = A if A is not None else min(1.0, target / 5.0)
            do_win = use_windows or smart or bool(proj.get("smart_tune", True))
            if do_win and len(choices) > 2:
                idx = int(round(A_use * (len(choices) - 1)))
                window = sorted({max(0, idx - 1), idx, min(len(choices) - 1, idx + 1)})
                e = rng.choice([choices[i] for i in window])
            else:
                e = rng.choice(choices)
        tr["params"][name] = m.eng2frac(tt, name, e)
    if tt in ("wobble", "growl", "neuro", "fmbass", "hollow") and "LFO Division" not in locked and "LFO Division" not in forced:
        cfg = STYLES[style]
        divs = (cfg["growl_div"] if tt in ("growl", "neuro") else cfg["wob_div"])
        if (smart or use_windows) and len(divs) > 1 and A is not None:
            idx = min(len(divs) - 1, int(round((A if use_windows else target / 5.0) * (len(divs) - 1))))
            div = divs[idx]
        else:
            div = divs[0]
        tr["params"]["LFO Division"] = m.eng2frac(tt, "LFO Division", div)


DUCK = {"sub": 1.0, "wobble": 0.9, "reese": 0.9, "growl": 0.7, "screech": 0.5, "fmbass": 0.8, "neuro": 0.7, "hollow": 0.9,
        "supersaw": 0.45, "pad": 0.5, "pluck": 0.35, "stab": 0.35, "vox": 0.3, "speak": 0.3, "theremin": 0.3, "panflute": 0.3, "handpan": 0.2, "tongue": 0.2,
        "organ": 0.3, "epiano": 0.25, "harpsichord": 0.2, "flute": 0.25, "brass": 0.4, "choir": 0.45, "cello": 0.3, "vibes": 0.2, "marimba": 0.2, "bell": 0.2,
        "hoover": 0.5, "drone": 0.5, "bass808": 1.0, "upright": 0.8}


def duck_link(tr, style, rel=0.5):
    base = wavg(style, DUCK_BASE, 0.55)
    return {"src": "kick", "dst": tr["name"], "param": "Level", "amount": -round(base * DUCK[tr["type"]], 3),
            "rel": 0.4 if tr["type"] in ("screech", "pluck", "stab", "vox") else rel}


def default_links(style, tracks):
    """Linki domyślne dla istniejących ścieżek (tracks = lista słowników)."""
    m = meta(); links = []
    L = lambda s, d, p, a, r=0.5: {"src": s, "dst": d, "param": p, "amount": a, "rel": r}
    has = lambda n, p: m.has(n["type"], p)
    for tr in tracks:
        if tr["type"] in DUCK and any(t["type"] == "kick" for t in tracks):
            links.append(duck_link(tr, style))
    rules = [("energy", "reese", "Cutoff", 0.20), ("energy", "growl", "Drive", 0.15), ("energy", "neuro", "Cutoff", 0.15), ("energy", "hat", "Level", 0.12),
             ("build", "screech", "Cutoff", 0.35), ("build", "snare", "Drive", 0.25), ("build", "supersaw", "Cutoff", 0.3), ("build", "speak", "Cutoff", 0.3),
             ("snare", "screech", "FM Amount", 0.15, 0.3), ("bass_note", "growl", "Vowel A-E-I-O-U", 0.30), ("bass_note", "vox", "Vowel A-E-I-O-U", 0.35),
             ("bar_phase", "reese", "Cutoff", 0.08), ("bar_phase", "pad", "Cutoff", 0.15), ("kick", "hollow", "Cutoff", 0.12, 0.3)]
    if "Tearout" in STYLES.parts(style):
        rules.append(("snare", "growl", "Drive", 0.10, 0.3))
    for r in rules:
        for tr in tracks:
            if tr["type"] == r[1] and has(tr, r[2]) and (r[0] not in DRUM_SRC or any(t["type"] == r[0] for t in tracks)):
                links.append(L(r[0], tr["name"], r[2], r[3], r[4] if len(r) > 4 else 0.5))
    return links



# ------------------------------------------------------------------ scenariusze (nadrzędna warstwa struktury)
# charakter pod-scenariusza: wpływa na mutację template i krzywą energii sekcji
SCENARIO_CHARS = ("very_optimistic", "optimistic", "balanced", "restrained", "dark")
_CHAR_VAL = {"very_optimistic": 1.0, "optimistic": 0.75, "balanced": 0.5, "restrained": 0.3, "dark": 0.1}


def _char_val(character):
    if isinstance(character, (int, float)):
        return max(0.0, min(1.0, float(character)))
    return _CHAR_VAL.get(str(character).strip().lower().replace(" ", "_"), 0.5)


def mutate_scenario_template(template, character, energy, density, aggression, rng):
    """Systematyczna mutacja układu czasowego z heurystyką charakteru/energii.
    Zwraca listę (typ, bary) — jeszcze przed fit_template do budżetu bars."""
    tpl = [(n, int(b)) for n, b in template]
    cv = _char_val(character)
    agg = float(aggression)
    # --- pomijanie / skracanie intro
    if tpl and tpl[0][0] == "intro":
        if rng.random() < 0.12 + 0.15 * (1 - cv) * (energy):  # mroczne/wysoka energia: częściej skip
            if rng.random() < 0.55:
                tpl = tpl[1:]
            else:
                tpl[0] = ("intro", max(4, tpl[0][1] // 2))
        elif cv > 0.7 and rng.random() < 0.25:
            # optymistyczny: dłuższe, jaśniejsze wejście
            tpl[0] = ("intro", min(32, tpl[0][1] + 4))
    # --- buildy: dostosowanie do energii / charakteru
    for i, (n, b) in enumerate(tpl):
        if n != "build":
            continue
        if energy < 0.4 and rng.random() < 0.35:
            tpl[i] = ("build", max(4, b // 2))
        elif energy > 0.75 and rng.random() < 0.4:
            tpl[i] = ("build", min(24, b + 4))
        if cv < 0.3 and rng.random() < 0.2 and i > 0:
            # mroczniej: czasem build → break
            tpl[i] = ("break", max(4, b))
    # --- break: optymistyczny skraca, dark wydłuża
    for i, (n, b) in enumerate(tpl):
        if n != "break":
            continue
        if cv > 0.7 and rng.random() < 0.4:
            tpl[i] = ("break", max(4, b - 4)) if b > 8 else tpl[i]
        if cv < 0.35 and rng.random() < 0.45:
            tpl[i] = ("break", min(32, b + 8))
    # --- dropy: agresja → więcej / dłużej
    drops = [i for i, (n, _) in enumerate(tpl) if n == "drop"]
    if agg >= 3.5 and len(drops) < 3 and rng.random() < 0.35:
        # doklej krótki drop przed outro
        out_i = next((i for i, (n, _) in enumerate(tpl) if n == "outro"), len(tpl))
        tpl.insert(out_i, ("drop", 16))
    if energy > 0.8 and drops and rng.random() < 0.3:
        i = drops[0]
        tpl[i] = ("drop", min(48, tpl[i][1] + 8))
    # --- zamiana kolejności: intro ↔ break (rzadko)
    types = [n for n, _ in tpl]
    if "intro" in types and "break" in types and rng.random() < 0.08 + 0.06 * (1 - cv):
        ii = types.index("intro"); bi = types.index("break")
        tpl[ii], tpl[bi] = (tpl[bi][0], tpl[ii][1]), (tpl[ii][0], tpl[bi][1])
    # --- optymistyczny: drugi build przed ostatnim dropem
    if cv > 0.65 and rng.random() < 0.35:
        drops = [i for i, (n, _) in enumerate(tpl) if n == "drop"]
        if len(drops) >= 2:
            i = drops[-1]
            if i > 0 and tpl[i - 1][0] != "build":
                tpl.insert(i, ("build", 8))
    # --- outro zawsze na końcu jeśli był
    if any(n == "outro" for n, _ in tpl) and tpl[-1][0] != "outro":
        outs = [(n, b) for n, b in tpl if n == "outro"]
        tpl = [(n, b) for n, b in tpl if n != "outro"] + outs[:1]
    # minimum: choć jeden drop
    if not any(n == "drop" for n, _ in tpl):
        tpl.append(("drop", 32))
    return tpl


def scenario_section_energy(stype, character, energy):
    """Bazowe (e0, e1) sekcji × charakter × energia projektu."""
    base = {
        "intro": (0.28, 0.42), "build": (0.48, 0.92), "drop": (1.0, 1.0),
        "break": (0.32, 0.38), "outro": (0.28, 0.12),
    }.get(stype, (0.5, 0.5))
    cv = _char_val(character)
    es = 0.55 + 0.45 * energy
    # optymistyczny podnosi intro/outro i break; dark obniża i wydłuża „doliny”
    bias = (cv - 0.5) * 0.2
    e0 = max(0.08, min(1.15, base[0] * es + bias * (0.5 if stype in ("intro", "break", "outro") else -0.15)))
    e1 = max(0.08, min(1.15, base[1] * es + bias * (0.4 if stype != "drop" else 0.05)))
    if stype == "drop":
        e0 = e1 = min(1.2, 0.85 + 0.2 * energy + 0.05 * cv)
    if stype == "build" and cv > 0.7:
        e1 = min(1.15, e1 + 0.08)
    if stype == "break" and cv < 0.3:
        e0 = e1 = max(0.15, e0 * 0.85)
    return round(e0, 3), round(e1, 3)


def analyze_scenario(sections, character, energy, density):
    """Post-analiza unifikalności / norm. -> lista kodów problemów."""
    issues = []
    if not sections:
        return ["empty"]
    total = sum(s["bars"] for s in sections)
    drops = [s for s in sections if s["type"] == "drop"]
    intros = [s for s in sections if s["type"] == "intro"]
    builds = [s for s in sections if s["type"] == "build"]
    breaks = [s for s in sections if s["type"] == "break"]
    if not drops:
        issues.append("no_drop")
    else:
        dbar = sum(s["bars"] for s in drops)
        if dbar < total * 0.18:
            issues.append("drop_short")
        if dbar > total * 0.72 and energy < 0.85:
            issues.append("drop_overlong")
    if intros and sum(s["bars"] for s in intros) > total * 0.28:
        issues.append("intro_long")
    # powtórzenia z rzędu tego samego typu (>2)
    run, prev = 1, None
    for s in sections:
        if s["type"] == prev:
            run += 1
            if run >= 3 and s["type"] != "drop":
                issues.append("run_" + s["type"])
                break
        else:
            run, prev = 1, s["type"]
    # łuk energii: max e powinien być w dropie
    peak = max(sections, key=lambda s: max(s.get("e0", 0), s.get("e1", 0)))
    if peak["type"] not in ("drop", "build"):
        issues.append("peak_not_drop")
    cv = _char_val(character)
    if cv > 0.7:
        # optymistyczny: druga połowa nie powinna być wyraźnie ciemniejsza
        mid = total / 2
        e1 = [max(s["e0"], s["e1"]) for s in sections if s["start"] + s["bars"] / 2 >= mid]
        e0 = [max(s["e0"], s["e1"]) for s in sections if s["start"] + s["bars"] / 2 < mid]
        if e0 and e1 and (sum(e1) / len(e1)) < (sum(e0) / len(e0)) - 0.12:
            issues.append("optimistic_dip")
    if cv < 0.3 and not breaks and density > 0.5:
        issues.append("dark_needs_break")
    if len(sections) < 3:
        issues.append("too_few_sections")
    return issues


def correct_scenario(sections, issues, character, energy, rng):
    """Korekta sekcji aż bliżej normy — w miejscu, bez pełnej regeneracji nut."""
    if not sections:
        return sections
    total = sum(s["bars"] for s in sections)
    cv = _char_val(character)

    def renumber():
        start, ord_ = 0, {}
        for s in sections:
            t = s["type"]
            ord_[t] = ord_.get(t, 0) + 1
            s["k"] = ord_[t]
            s["name"] = f"{t}{ord_[t]}"
            s["start"] = start
            start += s["bars"]
            e0, e1 = scenario_section_energy(t, character, energy)
            s["e0"], s["e1"] = e0, e1

    if "no_drop" in issues or "too_few_sections" in issues:
        sections.append({"type": "drop", "bars": max(16, total // 4)})
    if "drop_short" in issues:
        for s in sections:
            if s["type"] == "drop":
                s["bars"] = min(48, s["bars"] + 8)
                break
    if "drop_overlong" in issues:
        for s in sections:
            if s["type"] == "drop" and s["bars"] > 16:
                s["bars"] = max(16, s["bars"] - 8)
                break
    if "intro_long" in issues:
        for s in sections:
            if s["type"] == "intro" and s["bars"] > 8:
                s["bars"] = max(4, s["bars"] // 2)
    if "dark_needs_break" in issues:
        # wstaw break przed ostatnim dropem
        idx = next((i for i in range(len(sections) - 1, -1, -1) if sections[i]["type"] == "drop"), len(sections))
        sections.insert(idx, {"type": "break", "bars": 8})
    if "optimistic_dip" in issues:
        for s in sections:
            if s["start"] >= total / 2 and s["type"] in ("break", "outro"):
                s["e0"] = min(1.0, s.get("e0", 0.3) + 0.12)
                s["e1"] = min(1.0, s.get("e1", 0.3) + 0.1)
    if any(x.startswith("run_") for x in issues):
        # skróć środkowy z runu
        prev, run_i = None, []
        for i, s in enumerate(sections):
            if s["type"] == prev and s["type"] != "drop":
                run_i.append(i)
            else:
                if len(run_i) >= 2:
                    sections[run_i[len(run_i) // 2]]["bars"] = max(4, sections[run_i[len(run_i) // 2]]["bars"] // 2)
                run_i, prev = [], s["type"]
    if "peak_not_drop" in issues:
        for s in sections:
            if s["type"] == "drop":
                s["e0"] = s["e1"] = min(1.2, 0.9 + 0.15 * energy)
    renumber()
    return sections


def build_scenario(template, bars, character, energy, density, aggression, rng, max_tries=6):
    """Mutacja template → fit → energia → analiza → korekta (pętla do pass lub max_tries)."""
    report = {"character": character, "tries": 0, "issues": [], "mutations": True}
    base_tpl = list(template)
    sections = []
    for attempt in range(max_tries):
        report["tries"] = attempt + 1
        mut = mutate_scenario_template(base_tpl, character, energy, density, aggression, rng)
        fitted = fit_template(mut, bars, rng)
        start, ord_ = 0, {}
        sections = []
        for sname, n in fitted:
            ord_[sname] = ord_.get(sname, 0) + 1
            e0, e1 = scenario_section_energy(sname, character, energy)
            sections.append({"name": f"{sname}{ord_[sname]}", "type": sname, "k": ord_[sname],
                             "start": start, "bars": n, "e0": e0, "e1": e1})
            start += n
        issues = analyze_scenario(sections, character, energy, density)
        report["issues"] = list(issues)
        if not issues:
            report["pass"] = True
            break
        sections = correct_scenario(sections, issues, character, energy, rng)
        issues2 = analyze_scenario(sections, character, energy, density)
        report["issues"] = list(issues2)
        if not issues2:
            report["pass"] = True
            report["corrected"] = True
            break
        # kolejna próba: mocniejsza mutacja (nowy rng salt)
        rng = random.Random(rng.random() + attempt + 0.17)
    else:
        report["pass"] = False
    return sections, report


def fit_template(template, bars, rng):
    tot = sum(b for _, b in template)
    out = [[n, max(4, round(b * bars / tot / 4) * 4)] for n, b in template]
    diff = bars - sum(b for _, b in out)
    big = [i for i, (n, _) in enumerate(out) if n == "drop"] or [0]
    k = 0
    while diff:
        step = 4 if diff > 0 else -4
        i = big[k % len(big)]
        if out[i][1] + step >= 4:
            out[i][1] += step; diff -= step
        k += 1
        if k > 200:
            break
    return out


def reg(pc, lo):
    return lo + ((pc - lo) % 12)


class Ctx:
    def __init__(self, proj, cfg):
        self.p = proj
        self.cfg = SV.varied(proj.get("style"), cfg, proj.get("variety", 0.0), proj.get("vseed", proj.get("seed")))   # variety 0 / brak klucza = cfg bez zmian
        # predict: 1.0 = dawne reguły perkusji (bit-w-bit), <1 = rozbudowane (drum_rules.py); brak klucza w starych projektach = 1.0
        self.predict = max(0.0, min(1.0, float(proj.get("predict", 1.0))))
        self._drums = None
        self.climate = proj.get("climate") or {}
        self.B = []
        for s in proj["sections"]:
            for i in range(s["bars"]):
                self.B.append({"sec": s, "i": i, "L": s["bars"], "type": s["type"], "k": s["k"], "e": s["e0"] + (s["e1"] - s["e0"]) * i / s["bars"],
                               "root": proj["chords"][s["start"] + i][0], "third": proj["chords"][s["start"] + i][1]})
        # gęstość per-sekcja z palety klimatu (mnożnik × global density)
        base_d = float(proj.get("density") or 0.6)
        self._dens = {}
        for s in proj["sections"]:
            mul = climate_density_for(self.climate, s["type"])
            self._dens[id(s)] = max(0.15, min(1.0, base_d * mul))

    @property
    def drums(self):
        """Wspólny plan perkusji (narastanie, fille, crash) — tylko gdy predict < 1."""
        if self._drums is None:
            from . import drum_rules as DR
            self._drums = DR.DrumPlan(self)
        return self._drums

    def dens(self, B):
        """Gęstość skuteczna dla taktu B (klimat × global)."""
        return self._dens.get(id(B["sec"]), float(self.p.get("density") or 0.6))

    def rng(self, tname, salt=0):
        cl = self.climate
        if cl.get("section_motif_reuse") and cl.get("motif_seed"):
            # ten sam strumień dla (tor, typ sekcji) — powtarzalne motywy drop1≈drop2
            return random.Random(f"{cl['motif_seed']}-{tname}-{salt}")
        return random.Random(f"{self.p['seed']}-{tname}-{salt}")


def tok(b):
    th = b["third"]
    return {"r": 0, "o": 12, "f": 7, "t": th, "b": 10, "p": th + 12, "u": 14}


def structure_vel(base, sec_type, progress=0.5, step=0, role="perc", energy=0.7, dens=0.6,
                  rng=None, accent=False, human=True, mood=0.0, climate=None):
    """Velocity z intonacją zależną od sekcji (intro/build/drop/break/outro) + roli instrumentu.

    Rozszerza zakresy względem starego „~100 ±5”:
    - intro: cicho, lekko narasta
    - build: mocne narastanie (jak drum_rules BuildPlan)
    - drop: wysoki poziom + wyraźne akcenty (1, backbeat)
    - break: średnio-cicho, więcej oddechu
    - outro: opadanie

    Opcjonalnie:
    - mood (−1…+1 z director): mroczny → nieco cichszy / ciaśniejszy zakres; optymistyczny → jaśniejszy, wyższy
    - climate: lekki bias z climate.intensity / climate.energy jeśli obecne
    Deterministyczne przy podanym rng. Zwraca int 1..127.
    """
    r = rng if rng is not None else random
    progress = max(0.0, min(1.0, float(progress)))
    energy = max(0.0, min(1.0, float(energy)))
    dens = max(0.0, min(1.0, float(dens)))
    mood = max(-1.0, min(1.0, float(mood or 0.0)))

    # mnożnik sekcji (środek zakresu)
    if sec_type == "intro":
        sec = 0.48 + 0.32 * progress
    elif sec_type == "build":
        sec = 0.45 + 0.58 * (progress ** 0.85)          # lekko wypukłe narastanie
    elif sec_type == "drop":
        sec = 0.90 + (0.10 if accent else 0.0)
    elif sec_type == "break":
        sec = 0.52 + 0.18 * dens
    elif sec_type == "outro":
        sec = 0.78 - 0.42 * progress
    else:
        sec = 0.82

    # rola / akcent w takcie
    if role == "kick":
        role_m = 1.08 if (accent or step == 0) else (0.88 if step in (4, 8, 12) else 0.78)
    elif role == "snare":
        role_m = 1.10 if accent else 0.72
    elif role in ("hat", "openhat", "shaker"):
        role_m = 0.98 if step % 4 == 0 else (0.82 if step % 2 == 0 else 0.68)
    elif role in ("clap", "rim"):
        role_m = 1.05 if accent else 0.80
    elif role == "tom":
        role_m = 0.95 + 0.08 * (step / 16.0)
    elif role in ("crash", "ride"):
        role_m = 1.0
    elif role in ("bass", "sub", "reese", "wobble", "growl", "neuro", "fmbass", "bass808"):
        role_m = 0.92 if not accent else 1.02
    elif role in ("lead", "stab", "pluck", "screech", "hoover"):
        role_m = 1.0 if accent else 0.88
    elif role in ("pad", "choir", "drone"):
        role_m = 0.82
    else:
        role_m = 0.95

    e = 0.78 + 0.32 * energy
    d = 0.92 + 0.12 * dens
    # mood: −1 mroczny (ciaśniej, ciszej) … +1 optymistyczny (otwarciej, głośniej)
    mood_m = 1.0 + 0.08 * mood
    # climate (opcjonalny lekki bias)
    clim_m = 1.0
    if isinstance(climate, dict):
        ci = climate.get("intensity")
        if ci is None:
            ci = climate.get("energy")
        if ci is not None:
            try:
                clim_m = 0.94 + 0.12 * max(0.0, min(1.0, float(ci)))
            except (TypeError, ValueError):
                pass

    v = float(base) * sec * role_m * e * d * mood_m * clim_m
    if human:
        spread = 9 if role in ("kick", "snare", "clap", "rim", "tom") else 6
        # przy mrocznym mood nieco mniejsza humanizacja (bardziej „ściśnięte”)
        spread = max(3, int(round(spread * (1.0 - 0.25 * max(0.0, -mood)))))
        v += r.randint(-spread, spread)
    return max(1, min(127, int(round(v))))


def _vel_ctx(c, B=None):
    """Wspólny kontekst velocity z Context + sekcji (energy, dens, mood, climate, progress)."""
    en = float(c.p.get("energy") or 0.7)
    dn = c.dens(B) if B is not None else float(c.p.get("density") or 0.6)
    d = c.p.get("director") or {}
    mood = float(d.get("mood") or 0.0)
    climate = c.climate if isinstance(getattr(c, "climate", None), dict) else (c.p.get("climate") or {})
    progress = 0.5
    sec_type = "drop"
    if B is not None:
        progress = (B["i"] + 0.5) / max(1, B["L"])
        sec_type = B["type"]
    return en, dn, mood, climate, progress, sec_type


class Writer:
    def __init__(self, proj, tr):
        self.t = tr; self.name = tr["type"]; self.sw = proj["swing"]; self.t["notes"] = []
        self.sw8 = float(STYLES[proj["style"]].get("swing8", 0.0))

    def add(self, bar, step, key, ln, vel, drum=False):
        beat = bar * 4 + step * 0.25
        if step % 2 == 1 and self.name not in SUSTAINED:
            beat += self.sw * 0.1
        elif step % 4 == 2 and self.sw8 and self.name not in SUSTAINED:      # swing8: opóźnienie ósemek „i" (ułamek ćwierćnuty; 0.1667 = triole)
            beat += self.sw8
        dur = 0.1 if drum else max(0.05, ln * 0.25 - 0.03)
        self.t["notes"].append([round(beat, 4), round(dur, 4), int(key), max(1, min(127, int(vel)))])


# ------------------------------------------------------------------ generatory ścieżek
def gen_kick(c, tr):
    w, r, cfg = Writer(c.p, tr), c.rng(tr["name"]), c.cfg
    pools, pick = cfg["kick"], {}
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            ch = r.choice(pools)                                            # losowanie w każdym takcie — jak dawniej (ten sam strumień r)
            steps = list(pick.setdefault(SV.kick_phrase_key(c, B), ch))
            if cfg.get("fourfloor"):
                pass
            else:
                if i % 4 == 3 and r.random() < c.dens(B) * 0.7:
                    steps.append(r.choice([13, 14, 15]))
                if i % 8 == 7:
                    steps = [0, 6, 10, 12]
        elif (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            steps = pools[0][:2]
        elif t == "build" and i >= L // 2:
            steps = [0]
            if c.predict < 0.999:
                for s, v in c.drums.build(B).kick(i):
                    w.add(b, s, 36, 0, v, drum=True)
                continue
        else:
            continue
        if t == "drop":
            steps = SV.kick_steps(c, B, b, steps)                           # pickupy stopy dozwolone w gatunku (variety > 0)
        if c.predict < 0.999 and t == "drop":
            fl = c.drums.fill(b)
            if fl and fl.get("kick_mute") is not None:                      # „stop": stopa milknie przed końcem taktu
                steps = [s for s in steps if s < fl["kick_mute"]]
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        for s in sorted(set(steps)):
            accent = (s == 0) or (s in (4, 8, 12) and t == "drop")
            v = structure_vel(112, t, progress, step=s, role="kick", energy=en, dens=dn,
                              rng=r, accent=accent, mood=mood, climate=climate)
            w.add(b, s, 36, 0, v, drum=True)


def gen_snare(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if t == "drop":
            for s_ in SV.snare_steps(c, B, c.cfg.get("snare", [8])):
                v = structure_vel(115, t, progress, step=s_, role="snare", energy=en, dens=dn,
                                  rng=r, accent=True, mood=mood, climate=climate)
                w.add(b, s_, 38, 0, v, drum=True)
            if not (c.predict < 0.999 and c.drums.fill(b)):                 # w takcie z fillem werbel prowadzi plan fillów
                for s_, v_ in SV.snare_extra(c, B, b):                      # ghost / pickup werbla dozwolony w gatunku (variety > 0)
                    w.add(b, s_, 38, 0, v_, drum=True)
            for s_, v_ in c.cfg.get("ghost", []):                       # ciche werble (jazz, DnB, electro)
                if r.random() < 0.45 + 0.5 * c.dens(B):
                    w.add(b, s_, 38, 0, v_ + r.randint(-4, 4), drum=True)
            if c.predict < 0.999:                                           # wspólny plan fillów (drum_rules)
                fl = c.drums.fill(b)
                for s_, v_ in ((fl or {}).get("snare") or []):
                    w.add(b, s_, 38, 0, v_, drum=True)
            elif c.cfg["wob"] == "tearout" and i % 8 == 7:
                for s in (12, 13, 14, 15):
                    w.add(b, s, 38, 0, 80 + s * 2, drum=True)
            elif i % 8 == 7 and r.random() < c.dens(B):
                w.add(b, 14, 38, 0, 92, drum=True)
        elif t == "build" and c.predict < 0.999:
            for s_, v_ in c.drums.build(B).snare(i):
                w.add(b, s_, 38, 0, v_, drum=True)
        elif t == "build":
            p = (i + 0.5) / L
            steps = [0, 8] if p < 0.25 else [0, 4, 8, 12] if p < 0.5 else list(range(0, 16, 2)) if p < 0.75 else list(range(16))
            if i == L - 1:
                steps = [s for s in steps if s < 12]
            for s in steps:
                v = structure_vel(90, "build", p, step=s, role="snare", energy=en, dens=dn,
                                  rng=r, accent=(s % 4 == 0), mood=mood, climate=climate)
                w.add(b, s, 38, 0, v, drum=True)


def gen_hat(c, tr):
    w, r, mode = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["hat"]
    d = c.p["density"]
    if mode == "none":
        return
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if c.predict < 0.999 and t == "build":
            for s_, v_ in c.drums.build(B).hat(i):
                w.add(b, s_, 42, 0, v_, drum=True)
            continue
        fl = c.drums.fill(b) if (c.predict < 0.999 and t == "drop") else None
        if fl:
            for s_, v_ in (fl.get("hat_extra") or []):
                w.add(b, s_, 42, 0, v_, drum=True)
        hm = fl.get("hat_mute") if fl else None                            # fill wycisza hat od tego kroku
        if t == "drop":
            mode_b = SV.hat_mode(c, B, mode)                                 # tryb hatu per sekcja z puli gatunku (variety > 0)
            for s_, v_ in SV.hat_extra(c, B, b):
                if fl is None and (hm is None or s_ < hm):                   # fill ma pierwszeństwo: dodatki nie grają w jego ciszy ani nad nim
                    w.add(b, s_, 42, 0, v_, drum=True)
            if mode_b == "none":
                continue
            if mode_b == "16":
                for s in range(16):
                    if s % 2 == 1 and r.random() > 0.55 + 0.45 * d:
                        continue
                    if hm is not None and s >= hm:
                        continue
                    v = structure_vel(88, t, progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                      mood=mood, climate=climate)
                    w.add(b, s, 42, 0, v, drum=True)
            elif mode_b == "8":
                for s in range(0, 16, 2):
                    if hm is not None and s >= hm:
                        continue
                    v = structure_vel(88, t, progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                      mood=mood, climate=climate)
                    w.add(b, s, 42, 0, v, drum=True)
            elif mode_b == "trap":                         # 8-ki + rolle 1/32 pod koniec taktu
                for s in range(0, 16, 2):
                    if hm is not None and s >= hm:
                        continue
                    v = structure_vel(86, t, progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                      mood=mood, climate=climate)
                    w.add(b, s, 42, 0, v, drum=True)
                if (fl is None or (hm is None and not fl.get("hat_extra"))) and r.random() < 0.25 + 0.6 * d:
                    s0 = r.choice([10, 12, 14])
                    for q in range(4 if s0 < 14 else 3):
                        v = structure_vel(55 + q * 14, t, progress, step=s0, role="hat", energy=en, dens=dn, rng=r,
                                          mood=mood, climate=climate)
                        w.add(b, s0 + 0.5 * (q + 1), 42, 0, v, drum=True)
            elif mode_b == "ride":                         # jazzowy ride: „spang-a-lang" (z swing8 wychodzi swingowany)
                for s in (0, 4, 6, 8, 12, 14):
                    if hm is not None and s >= hm:
                        continue
                    v = structure_vel(88, t, progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                      accent=(s % 4 == 0), mood=mood, climate=climate)
                    w.add(b, s, 42, 0, v, drum=True)
            else:
                for s in (2, 6, 10, 14):
                    if hm is not None and s >= hm:
                        continue
                    v = structure_vel(78, t, progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                      mood=mood, climate=climate)
                    w.add(b, s, 42, 0, v, drum=True)
        elif t in ("intro", "outro"):
            for s in range(0, 16, 2):
                v = structure_vel(72, t, progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                  mood=mood, climate=climate)
                w.add(b, s, 42, 0, v, drum=True)
        elif t == "build" and i >= 2:
            for s in range(0, 16, 2):
                v = structure_vel(70, "build", progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                  mood=mood, climate=climate)
                w.add(b, s, 42, 0, v, drum=True)
        elif t == "break" and mode == "off":
            for s in (2, 10):
                v = structure_vel(55, "break", progress, step=s, role="hat", energy=en, dens=dn, rng=r,
                                  mood=mood, climate=climate)
                w.add(b, s, 42, 0, v, drum=True)


def _phrase_pick(c, tname, library, b, phrase=4):
    r = c.rng(tname, b // phrase)
    return r.choice(library) if library else []


def gen_wobble(c, tr):
    w = Writer(c.p, tr); style = c.cfg["wob"]; r = c.rng(tr["name"]); lib = c.cfg.get("wob_lib") or WOB[style]
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        pat = _phrase_pick(c, tr["name"], lib, b, 4 if style != "riddim" else 2)
        if style == "brostep" and B["k"] > 1 and B["i"] % 2:
            pat = _phrase_pick(c, tr["name"], lib, b + 100, 4)
        for s, tkn, ln in pat:
            accent = (s == 0)
            v = structure_vel(105, "drop", progress, step=s, role="bass", energy=en, dens=dn,
                              rng=r, accent=accent, mood=mood, climate=climate)
            w.add(b, s, base + k[tkn], ln, v)
    # zmiany podziału LFO (stepped) per sekcja drop
    ro, auto = c.rng(tr["name"] + "div"), tr["auto"]
    m = meta(); pts = []
    for s in c.p["sections"]:
        if s["type"] != "drop":
            continue
        for off in range(0, s["bars"], 8):
            if off == 0 or ro.random() < 0.5:
                pts.append([(s["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["wob_div"]))])
    auto["LFO Division"] = pts


def voice_idx(c, tr):
    """Numer instancji danego typu (pad, pad2, pad3 → 0, 1, 2): kolejne głosy grają kolejne dźwięki akordu."""
    names = [t["name"] for t in c.p["tracks"] if t["type"] == tr["type"]]
    return names.index(tr["name"]) if tr["name"] in names else 0


def chord_tones(B):
    th = B["third"]
    return [0, th, 7, 12, th + 12, 19]


def _sub_pattern(c, w, r, b, B, mode, base):
    en, dn, mood, climate, progress, sec = _vel_ctx(c, B)
    if mode == "walk":                           # walking bass: ćwierćnuty po dźwiękach akordu + chromatyczne podejście do następnego taktu
        th = B["third"]; nxt = c.B[min(b + 1, len(c.B) - 1)]
        app = reg(nxt["root"], 24) + r.choice([-1, 1])
        seq = r.choice([[0, th, 7, None], [0, 7, th, None], [0, th, 7, 12]])
        for j, s_ in enumerate((0, 4, 8, 12)):
            v = structure_vel(100, sec, progress, step=s_, role="bass", energy=en, dens=dn,
                              rng=r, accent=(s_ == 0), mood=mood, climate=climate)
            w.add(b, s_, app if seq[j] is None else base + seq[j], 4, v)
        return
    k = tok(B)
    for s_, tkn, ln in SUB_PAT[mode]:
        v = structure_vel(106, sec, progress, step=s_, role="bass", energy=en, dens=dn,
                          rng=r, accent=(s_ == 0), mood=mood, climate=climate)
        w.add(b, s_, base + k[tkn], ln, v)


def gen_sub(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    riddim = c.cfg["wob"] == "riddim"
    if c.cfg["wob"] == "trap":                       # 808: długie nuty na uderzeniach stopy (glide robi zjazdy)
        kk = first_of_type(c.p, "kick"); hits = sorted(n[0] for n in (kk["notes"] if kk else []))
        for j, on in enumerate(hits):
            B = c.B[min(len(c.B) - 1, int(on // 4))]
            if B["type"] != "drop":
                continue
            nxt = hits[j + 1] if j + 1 < len(hits) else on + 2
            ln = max(1, min(12, int(round((nxt - on) * 4)) - 0))
            base = reg(B["root"], 24) + (12 if r.random() < 0.15 else 0)
            en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
            v = structure_vel(112, "drop", progress, step=0, role="bass", energy=en, dens=dn,
                              rng=r, accent=True, mood=mood, climate=climate)
            w.t["notes"].append([round(on, 4), round(max(0.2, ln * 0.25 - 0.03), 4), base, v])
        return
    sm = c.cfg.get("sub_mode")
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        base = reg(B["root"], 24)
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if t == "drop":
            if riddim or sm == "off":
                continue
            if sm == "walk" or sm in SUB_PAT:
                _sub_pattern(c, w, r, b, B, sm, base)
                continue
            ln = 16 if not (i % 8 == 7 and r.random() < c.dens(B)) else 14
            v = structure_vel(110, t, progress, step=0, role="bass", energy=en, dens=dn,
                              rng=r, accent=True, mood=mood, climate=climate)
            w.add(b, 0, base, ln, v)
        elif sm == "walk" and t == "break":
            _sub_pattern(c, w, r, b, B, sm, base)
        elif (t == "intro" and i >= L // 2) or t == "break" or (t == "outro" and i < L * 3 // 4):
            v = structure_vel(96, t, progress, step=0, role="bass", energy=en, dens=dn,
                              rng=r, mood=mood, climate=climate)
            w.add(b, 0, base, 16, v)
    if riddim:  # sub powiela rytm wobble o oktawę niżej
        wb = first_of_type(c.p, "wobble")
        for on, dur, key, vel in (wb["notes"] if wb else []):
            w.t["notes"].append([on, dur, key - 12, vel])


def gen_reese(c, tr):
    w, r, mode = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["reese"]
    for b, B in enumerate(c.B):
        t, i, L, k = B["type"], B["i"], B["L"], B["k"]
        base = reg(B["root"], 24) + 24
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if t == "drop" and mode != "none" and (mode == "all" or k >= 2 and i >= L // 2 or k >= 3):
            v = structure_vel(100, t, progress, step=0, role="bass", energy=en, dens=dn,
                              rng=r, accent=True, mood=mood, climate=climate)
            w.add(b, 0, base, 16, v)
        elif t in ("intro", "break") and mode != "none" and b % 2 == 0:
            v = structure_vel(70, t, progress, step=0, role="bass", energy=en, dens=dn,
                              rng=r, mood=mood, climate=climate)
            w.add(b, 0, base, 32, v)
        elif t == "outro" and i < L * 3 // 4 and b % 2 == 0 and mode != "none":
            v = structure_vel(max(30, 70 - i * 4), t, progress, step=0, role="bass", energy=en, dens=dn,
                              rng=r, mood=mood, climate=climate)
            w.add(b, 0, base, 32, v)


def gen_growl(c, tr):
    w, r, style = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["growl"]
    lib = c.cfg.get("growl_lib") or GROWL[style]
    if not lib:
        return
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        if style == "brostep" and B["k"] == 1 and B["i"] < 8:
            continue
        if style == "riddim" and B["i"] % 4 != 3:
            continue
        if style == "melodic" and B["i"] % 2 == 0:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        pat = _phrase_pick(c, tr["name"], lib, b, 2)
        for s, tkn, ln in pat:
            v = structure_vel(104, "drop", progress, step=s, role="bass", energy=en, dens=dn,
                              rng=r, accent=(s == 0), mood=mood, climate=climate)
            w.add(b, s, base + k[tkn], ln, v)
    ro, auto, m, pts = c.rng(tr["name"] + "div"), tr["auto"], meta(), []
    for s in c.p["sections"]:
        if s["type"] == "drop":
            for off in range(0, s["bars"], 8):
                pts.append([(s["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["growl_div"]))])
    auto["LFO Division"] = pts


def gen_screech(c, tr):
    w, r, mode = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["lead"]
    walk = 2
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        th = B["third"]; base = reg(B["root"], 72)
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if t == "build":
            v = structure_vel(70 + int(50 * progress), t, progress, step=0, role="lead", energy=en, dens=dn,
                              rng=r, mood=mood, climate=climate)
            w.add(b, 0, 53 + int(24 * (i + 0.5) / L), 16, v)
        elif t == "break" and mode != "none" and i >= 4:
            tones = [0, th, 7, 12, th + 12, 14]
            for s, ln in r.choice(LEAD_RHYTHM):
                walk = max(0, min(len(tones) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
                v = structure_vel(100, t, progress, step=s, role="lead", energy=en, dens=dn,
                                  rng=r, accent=(s == 0), mood=mood, climate=climate)
                w.add(b, s, base + tones[walk], ln, v)
        elif t == "drop":
            if mode == "melodic" and i >= 4:
                tones = [0, th, 7, 12, th + 12]
                for s, ln in r.choice(LEAD_RHYTHM):
                    walk = max(0, min(len(tones) - 1, walk + r.choice([-1, 0, 1, 2])))
                    v = structure_vel(96, t, progress, step=s, role="lead", energy=en, dens=dn,
                                      rng=r, accent=(s == 0), mood=mood, climate=climate)
                    w.add(b, s, base + tones[walk], ln, v)
            elif mode == "accent" and (i % 4 == 3 or (B["k"] >= 3)):
                v = structure_vel(98, t, progress, step=8, role="lead", energy=en, dens=dn,
                                  rng=r, accent=True, mood=mood, climate=climate)
                w.add(b, 8, base, 8, v)
                if B["k"] >= 3:
                    v2 = structure_vel(92, t, progress, step=0, role="lead", energy=en, dens=dn,
                                       rng=r, mood=mood, climate=climate)
                    w.add(b, 0, base + 12, 2, v2); w.add(b, 2, base + 7, 2, v2); w.add(b, 4, base, 4, v2)
            elif mode == "rare" and i % 8 == 7:
                v = structure_vel(98, t, progress, step=8, role="lead", energy=en, dens=dn,
                                  rng=r, accent=True, mood=mood, climate=climate)
                w.add(b, 8, base, 8, v)



# ------------------------------------------------------------------ nowe instrumenty (v2)
def gen_clap(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        if B["type"] == "drop":
            en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
            for s_ in c.cfg.get("snare", [8]):
                v = structure_vel(100, "drop", progress, step=s_, role="clap", energy=en, dens=dn,
                                  rng=r, accent=True, mood=mood, climate=climate)
                w.add(b, s_, 39, 0, v, drum=True)
            if B["i"] % 8 == 7 and r.random() < c.dens(B):
                v = structure_vel(80, "drop", progress, step=14, role="clap", energy=en, dens=dn, rng=r,
                                  mood=mood, climate=climate)
                w.add(b, 14, 39, 0, v, drum=True)


def gen_rim(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); pick = {}
    pool = [[3, 11], [6, 14], [3, 7, 11], [2, 10], [5, 13]]
    for b, B in enumerate(c.B):
        if B["type"] in ("drop", "intro", "outro") and not (B["type"] != "drop" and B["i"] < B["L"] // 2):
            en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
            pat = pick.setdefault(B["sec"]["name"], r.choice(pool))
            for s_ in pat:
                if r.random() < 0.55 + 0.45 * c.dens(B):
                    v = structure_vel(70, B["type"], progress, step=s_, role="rim", energy=en, dens=dn, rng=r,
                                      mood=mood, climate=climate)
                    w.add(b, s_, 37, 0, v, drum=True)


def gen_tom(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if c.predict < 0.999:
            if t == "drop":
                for s_, k, v_ in ((c.drums.fill(b) or {}).get("tom") or []):
                    w.add(b, s_, k, 0, v_, drum=True)
            elif t == "build":
                for s_, k, v_ in c.drums.build(B).tom(i):
                    w.add(b, s_, k, 0, v_, drum=True)
            continue
        if t == "drop" and i % 8 == 7:
            for s_, k in zip((12, 13, 14, 15), (47, 45, 43, 41)):
                w.add(b, s_, k, 0, 95 + r.randint(-4, 4), drum=True)
        elif t == "build" and i == L - 1:
            for s_, k in zip((4, 6, 8, 10, 12, 14), (50, 48, 47, 45, 43, 41)):
                w.add(b, s_, k, 0, 80 + s_ * 2, drum=True)


def gen_crash(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        if c.predict < 0.999:
            v = 0
            if (t == "drop" and i == 0) or (t in ("break", "outro") and i == 0):
                v = 108 if t == "drop" else 85
            elif t == "drop":
                ex = c.drums.crash_extra(b, B, r)
                v = ex[1] if ex else 0
            fl = c.drums.fill(b)
            if fl and fl.get("crash_hit"):
                v = max(v, fl["crash_hit"])
            if v:
                w.add(b, 0, 49, 0, v + r.randint(-3, 3), drum=True)
            continue
        if (t == "drop" and (i == 0 or i % 16 == 0)) or (t in ("break", "outro") and i == 0):
            w.add(b, 0, 49, 0, 108 if t == "drop" else 85, drum=True)


def gen_shaker(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop" or (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            for s_ in range(16):
                if s_ % 2 == 1 or (s_ % 4 == 0 and t == "drop"):
                    w.add(b, s_, 70, 0, (58 if s_ % 4 == 3 else 42) + r.randint(-5, 5), drum=True)


def gen_fmbass(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [[(0, "r", 2), (3, "r", 1), (6, "f", 2), (10, "r", 2), (13, "t", 1)], [(0, "r", 3), (4, "o", 2), (8, "r", 2), (12, "f", 2)],
           [(2, "r", 2), (6, "r", 2), (9, "b", 2), (12, "r", 4)]]
    for b, B in enumerate(c.B):
        if B["type"] != "drop" or B["k"] < 2 and B["i"] < 16:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 4):
            w.add(b, s_, base + k[tkn], ln, 100 + r.randint(-4, 4))
    ro, m, pts = c.rng(tr["name"] + "div"), meta(), []
    for s_ in c.p["sections"]:
        if s_["type"] == "drop":
            pts.append([s_["start"] * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["wob_div"]))])
    tr["auto"]["LFO Division"] = pts


def gen_neuro(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [[(0, "r", 4), (4, "o", 2), (6, "r", 2), (8, "t", 4), (12, "f", 4)], [(0, "r", 2), (2, "r", 2), (4, "f", 4), (8, "r", 4), (12, "b", 4)],
           [(0, "r", 6), (6, "t", 2), (8, "r", 2), (10, "o", 2), (12, "f", 4)]]
    for b, B in enumerate(c.B):
        if B["type"] != "drop" or B["i"] % 8 < 4:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 4):
            w.add(b, s_, base + k[tkn], ln, 106 + r.randint(-4, 4))
    ro, m, pts = c.rng(tr["name"] + "div"), meta(), []
    for s_ in c.p["sections"]:
        if s_["type"] == "drop":
            for off in range(0, s_["bars"], 8):
                pts.append([(s_["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["growl_div"] + [9, 10]))])
    tr["auto"]["LFO Division"] = pts


def gen_hollow(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); lib = WOB["riddim"]
    for b, B in enumerate(c.B):
        if B["type"] != "drop" or (c.cfg["wob"] != "deep" and B["i"] % 2 == 0 and c.cfg["wob"] != "riddim"):
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 2):
            w.add(b, s_, base + k[tkn], ln, 104 + r.randint(-4, 4))
    ro, m, pts = c.rng(tr["name"] + "div"), meta(), []
    for s_ in c.p["sections"]:
        if s_["type"] == "drop":
            for off in range(0, s_["bars"], 8):
                pts.append([(s_["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice([5, 8, 9]))])
    tr["auto"]["LFO Division"] = pts


def gen_supersaw(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); gate = c.cfg.get("gate"); vi = voice_idx(c, tr); k = 0
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        ok, k = _maybe_arp_bar(c, tr, w, B, b, reg(B["root"], 60) + (12 if vi % 2 else 0), k, r)
        if ok:
            continue
        if gate and t == "drop":                         # trance gate: bramkowany akord (kolejne instancje = kolejne dźwięki akordu)
            for s_ in gate:
                w.add(b, s_, reg(B["root"], 60) + chord_tones(B)[vi % 3], 1, 84 + (8 if s_ % 4 == 0 else 0) + r.randint(-3, 3))
            continue
        if t == "break" or (t == "drop" and c.cfg["lead"] == "melodic") or (t == "intro" and i >= B["L"] - 4):
            tone = r.choice([B["third"], 7, 12 + B["third"]]) if vi == 0 else chord_tones(B)[vi % 3]
            if b % 2 == 0:
                w.add(b, 0, reg(B["root"], 60) + tone, 32, 88 + r.randint(-4, 4))


def _maybe_arp_bar(c, tr, w, B, b, base_reg, phase_k, rng):
    """Jeśli arp włączony i sekcja pasuje — pisze nuty, zwraca (True, new_phase)."""
    from . import arp_engine as ARP
    arp = (c.p.get("arp") if isinstance(c.p.get("arp"), dict) else None) or c.cfg.get("arp")
    arp = ARP.normalize(arp) if isinstance(arp, dict) else ARP.normalize({"enabled": False})
    if not arp.get("enabled") or not ARP.should_play_section(arp, B["type"]):
        return False, phase_k
    notes, phase_k = ARP.notes_for_bar(arp, b, base_reg, chord_tones(B), phase_k, rng)
    for on, dur, midi, vel in notes:
        w.add(b, on, midi, max(0.25, dur), vel)
    return True, phase_k


def gen_pluck(c, tr):

    w, r = Writer(c.p, tr), c.rng(tr["name"]); vi = voice_idx(c, tr)
    arp = (c.p.get("arp") if c.p.get("arp") else None) or c.cfg.get("arp")
    from . import arp_engine as ARP
    arp = ARP.normalize(arp) if isinstance(arp, dict) else ARP.normalize({"enabled": False})
    k = vi * 2
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if arp.get("enabled") and ARP.should_play_section(arp, t):
            if t == "intro" and i < B["L"] // 2 and "intro" not in arp.get("sections", ()):
                continue
            base = reg(B["root"], 60) + (12 if vi % 2 else 0)
            notes, k = ARP.notes_for_bar(arp, b, base, chord_tones(B), k, r)
            for on, dur, midi, vel in notes:
                # arp ma własne vel — lekko przeskaluj przez strukturę
                v = structure_vel(vel, t, progress, step=int(on * 4) % 16, role="pluck", energy=en, dens=dn,
                                  rng=r, mood=mood, climate=climate, human=False)
                w.add(b, on, midi, max(0.25, dur), v)
            continue
        if t == "break" or (t == "drop" and c.cfg.get("lead") == "melodic" and i % 2 == 1) or (t == "intro" and i >= B["L"] // 2):
            seq = [0, B["third"], 7, 12, 7, B["third"]]; base = reg(B["root"], 60)
            for n_, s_ in enumerate(range(0, 16, 2)):
                if r.random() < 0.4 + 0.6 * c.dens(B):
                    v = structure_vel(82 + (8 if s_ % 4 == 0 else 0), t, progress, step=s_, role="pluck",
                                      energy=en, dens=dn, rng=r, accent=(s_ % 4 == 0), mood=mood, climate=climate)
                    w.add(b, s_, base + seq[n_ % len(seq)], 1, v)


def gen_pad(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); pm = c.cfg.get("pad_mode"); vi = voice_idx(c, tr)
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if (t in ("intro", "break", "outro") or (pm == "drop" and t == "drop")) and b % 2 == 0:
            en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
            off = (7 if (b // 2) % 2 else 0) if vi == 0 else chord_tones(B)[vi % 3]
            base_v = (80 if t != "outro" else max(30, 80 - i * 4)) - (10 if t == "drop" else 0)
            v = structure_vel(base_v, t, progress, step=0, role="pad", energy=en, dens=dn,
                              rng=r, mood=mood, climate=climate)
            w.add(b, 0, reg(B["root"], 48) + off, 32, v)


def gen_stab(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [[(3, "t", 1), (7, "f", 1)], [(6, "t", 1), (10, "f", 1), (14, "t", 1)], [(2, "f", 1), (10, "t", 1)]]
    comp = c.cfg.get("comp"); vi = voice_idx(c, tr)
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        en, dn, mood, climate, progress, _ = _vel_ctx(c, B)
        if comp:                                         # comping: rytm z puli stylu, każdy głos = inny dźwięk akordu (3 instancje = trójdźwięk)
            for s_ in _phrase_pick(c, tr["name"], comp, b, 2):
                v = structure_vel(92, "drop", progress, step=s_, role="stab", energy=en, dens=dn,
                                  rng=r, accent=True, mood=mood, climate=climate)
                w.add(b, s_, reg(B["root"], 60) + chord_tones(B)[vi % 3], 1, v)
            continue
        if c.cfg["lead"] == "melodic" and B["i"] % 2 == 0 or c.cfg["lead"] != "melodic" and B["i"] % 4 < 2:
            continue
        k = tok(B); base = reg(B["root"], 60)
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 4):
            v = structure_vel(96, "drop", progress, step=s_, role="stab", energy=en, dens=dn,
                              rng=r, accent=(s_ < 4), mood=mood, climate=climate)
            w.add(b, s_, base + k[tkn], ln, v)


def gen_riser(c, tr):
    w, m = Writer(c.p, tr), meta(); pts = []
    for s_ in c.p["sections"]:
        if s_["type"] == "build":
            B = c.B[s_["start"]]
            w.add(s_["start"], 0, reg(B["root"], 48), s_["bars"] * 16, 100)
            ms = s_["bars"] * 4 * 60000.0 / c.p["bpm"]
            pts.append([s_["start"] * 4, m.eng2frac(tr["type"], "Ramp Time", min(ms, 16000))])
    tr["auto"]["Ramp Time"] = pts


def gen_boom(c, tr):
    w = Writer(c.p, tr)
    for b, B in enumerate(c.B):
        if B["type"] in ("drop", "break") and B["i"] == 0:
            w.add(b, 0, 36, 0, 112 if B["type"] == "drop" else 80, drum=True)


def gen_zap(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "build" and i == L - 1:
            w.add(b, 12, 55, 0, 100, drum=True)
        elif t == "drop" and i % 8 == 7 and r.random() < 0.7:
            w.add(b, 14, 60, 0, 90, drum=True)


# ------------------------------------------------------------------ DS Speak (mowa) — opcjonalny instrument
SPEAK_THEMES = {
    "Dubstep": ["drop the bass", "wobble", "feel the sub", "dubstep", "bass drop", "sub bass", "heavy bass", "wub wub", "low end",
                "sound system", "shake the ground", "turn the bass up", "bass line"],
    "Hype": ["hands up", "let's go", "come on", "yeah", "hey", "make some noise", "pull up", "rewind", "fire", "jump",
             "everybody scream", "turn it up", "one more time", "go go go"],
    "Dark": ["no escape", "feel the fear", "run", "dark night", "scream", "break the system", "kill the lights", "wake up", "down we go"],
    "Countdown": ["ten nine eight seven six five four three two one drop"],
}
STYLE_THEME = {"Brostep": "Dubstep", "Riddim": "Dubstep", "Tearout": "Hype", "Melodic": "Hype", "Deep": "Dark",
               "Dubstep": "Dubstep", "Drumstep": "Hype", "Trap": "Dark", "EDM": "Hype"}

# ------------------------------------------------------------------ style spoza dubstepu + hybrydy (styles.py)
STYLES = ST.StyleDict(STYLES); STYLES.update(ST.NEW_STYLES)          # hybrydy „A 60% + B 40%" składane na żądanie (STYLES[nazwa])
ST.register_custom_styles(STYLES)  # style z kreatora (~/DubstepStudio/custom_styles.json)

WOB.update(ST.WOB_NEW); GROWL.update(ST.GROWL_NEW); SOUND_STYLE.update(ST.SOUND_STYLE_NEW); STYLE_THEME.update(ST.STYLE_THEME_NEW)
MEL_RHY = ST.MEL_RHY
DUCK_BASE = {"Deep": 0.35, "Melodic": 0.45, "EDM": 0.75, "Drumstep": 0.5, "Trap": 0.4, "Techno": 0.6, "Acid Techno": 0.6, "Hard Techno": 0.7, "Techno Trax": 0.65,
             "Tunnel Trance": 0.65, "Trance": 0.6, "Psytrance": 0.55, "House": 0.75, "Electro": 0.5, "DnB": 0.45, "Liquid DnB": 0.35, "Neurofunk": 0.45,
             "Space Electronica": 0.3, "Berlin School": 0.25, "Baroque": 0.1, "Romantic": 0.1, "Minimal Classical": 0.1, "Jazz": 0.15, "Jazz Rock": 0.3,
             "Experimental": 0.4, "Raw Synthesis": 0.5}
from . import special_styles as _SP  # noqa: E402  — style specjalne (artysta/album): własne wzory, brzmienia, epoka; poza ST.ORDER
_SP.register(STYLES, WOB, GROWL, SOUND_STYLE, STYLE_THEME, DUCK_BASE)
SUB_PAT = {"offbeat": [(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "r", 2)], "pulse8": [(s_, "r", 2) for s_ in range(0, 16, 2)],
           "roll": [(s_, "o" if s_ % 4 == 3 else "r", 1) for s_ in range(16) if s_ % 4],
           "funk": [(0, "r", 2), (3, "r", 1), (6, "o", 1), (8, "r", 2), (10, "f", 1), (12, "r", 2), (15, "b", 1)]}
ARP_PAT = {"up": [0, 1, 2, 3], "updown": [0, 1, 2, 3, 4, 3, 2, 1], "trance": [0, 2, 1, 2, 3, 2, 1, 2], "psy": [0, 3, 0, 2, 0, 3, 1, 3]}
SUSTAINED = ("sub", "reese", "pad", "supersaw", "riser", "boom", "crash", "choir", "drone", "organ", "cello", "bass808")
NO_MUTATE = {"kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "riser", "boom", "zap", "speak"}


def wavg(style, table, default):
    """Średnia ważona wartości z tabeli po składnikach stylu (dla czystego stylu = zwykłe .get)."""
    return sum(table.get(n, default) * w for n, w in STYLES.parts(style).items())


def theme_of(style):
    pts = STYLES.parts(style)
    return STYLE_THEME.get(max(pts, key=lambda n: (pts[n], n)), "Dubstep")


def short_name(style):
    return style if "%" not in str(style) else "Hybrid"


def style_sound(proj, tr):
    """Nadpisania brzmienia wg stylu; w hybrydzie składnik wybierany losowo (deterministycznie) z prawdopodobieństwem równym wadze."""
    pts = STYLES.parts(proj["style"])
    if len(pts) == 1:
        name = next(iter(pts))
    else:
        x = random.Random(f"{proj['seed']}-ss-{tr['name']}").random(); acc = 0.0; name = None
        for n, w in sorted(pts.items(), key=lambda kv: (-kv[1], kv[0])):
            acc += w
            if x <= acc:
                name = n; break
        name = name or next(iter(pts))
    return SOUND_STYLE.get(name, {}).get(tr["type"], [])


def auto_text(theme, style, n, rng):
    """Układa tekst na n słów (n = liczba nut mowy; każda nuta czyta kolejne słowo). Zdania z motywu, losowe ! i ?."""
    th = theme if theme in SPEAK_THEMES else theme_of(style)
    pool, words = SPEAK_THEMES[th], []
    while len(words) < max(1, n):
        ph = rng.choice(pool).split()
        r = rng.random()
        end = "!" if r < 0.45 else ("?" if r < 0.52 else ".")
        words += ph[:-1] + [ph[-1] + end]
    return " ".join(words[:max(1, n)])



# ------------------------------------------------------------------ skale głosowe + efekt theremin (pre/post)
VOCAL_REG = {
    "chest": (48, 58),   # niski
    "mid": (55, 67),     # średni
    "head": (62, 76),    # wysoki
    "wide": (50, 74),    # szeroki zakres
}
_REG_BY_SEC = {
    "intro": ("mid", "head", "chest"),
    "build": ("mid", "head", "wide"),
    "drop": ("chest", "mid", "head", "wide"),
    "break": ("head", "mid", "wide"),
    "outro": ("mid", "chest", "head"),
}


def _pick_vocal_reg(rng, sec_type=None):
    pool = _REG_BY_SEC.get(sec_type) or ("chest", "mid", "head", "wide")
    return rng.choice(pool)


def _vocal_pool(c, root, reg_name, octaves=2):
    """Dźwięki skali projektu w rejestrze głosowym (MIDI)."""
    lo, hi = VOCAL_REG.get(reg_name, (55, 67))
    base = reg(root, lo)
    pcs = {(c.p["key"] + d) % 12 for d in SCALES[c.p["scale"]]}
    pool = [k for k in range(base, min(hi + 12, base + 12 * octaves + 1)) if k % 12 in pcs]
    return pool if pool else [base, base + 3, base + 5, base + 7, base + 10]


def _theremin_mode(rng):
    """none | pre | post | both — efekt thereminowy na głosie."""
    return rng.choices(["none", "pre", "post", "both"], weights=[0.32, 0.26, 0.22, 0.20])[0]


def _sec_in_theremin(sec_type, mode):
    if mode == "none":
        return False
    if mode == "both":
        return True
    if mode == "pre":
        return sec_type in ("intro", "build")
    if mode == "post":
        return sec_type in ("break", "outro") or sec_type == "drop"
    return False


def _apply_voice_theremin(tr, c, mode, m, rng):
    """Ustawia parametry / automatyzację Glide, LFO>Pitch, Formant, Intonation wg trybu theremin."""
    if mode == "none":
        return
    tt = tr["type"]
    # bazowe „thereminowe” ustawienia brzmienia
    def set_eng(name, lo, hi):
        if not m.has(tt, name):
            return
        tr["params"][name] = m.eng2frac(tt, name, rng.uniform(lo, hi))

    if mode in ("pre", "both", "post"):
        set_eng("Glide", 60, 200)
        set_eng("LFO > Pitch", 0.15, 0.55)
        set_eng("LFO Rate", 4.0, 7.0)
        set_eng("Pitch Env Amt", 2, 12)
        set_eng("Pitch Env Decay", 40, 160)
        if tt == "speak":
            set_eng("Intonation", 0.55, 1.0)
            set_eng("Letter Pitch Range", 6, 14)
            set_eng("Formant Shift", -5, 5)
        if tt == "vox":
            set_eng("Formant Mix", 0.5, 0.95)
            set_eng("Glide", 40, 180)

    # automatyzacja w czasie: silniejsza w sekcjach objętych trybem
    for pname, (lo_on, hi_on), (lo_off, hi_off) in (
        ("LFO > Pitch", (0.2, 0.55), (0.0, 0.08)),
        ("Glide", (70, 180), (8, 40)),
    ):
        if not m.has(tt, pname):
            continue
        pts = []
        for s in c.p.get("sections") or []:
            on = _sec_in_theremin(s["type"], mode)
            lo, hi = (lo_on, hi_on) if on else (lo_off, hi_off)
            pts.append([s["start"] * 4.0, m.eng2frac(tt, pname, rng.uniform(lo, hi))])
        if pts:
            tr["auto"][pname] = pts


def gen_vox(c, tr):
    """Wokal synth: skala projektu w zmiennym rejestrze głosowym + samogłoski + opcjonalny theremin pre/post."""
    w, r, m = Writer(c.p, tr), c.rng(tr["name"]), meta()
    th_mode = _theremin_mode(r)
    tr["vocal_register"] = r.choice(list(VOCAL_REG.keys()))
    tr["theremin_fx"] = th_mode
    lib = [[(2, "t", 2), (6, "f", 2), (10, "o", 2)], [(0, "r", 3), (6, "t", 2), (10, "f", 3)], [(4, "o", 2), (8, "t", 2), (12, "r", 3)]]
    vowel_pts = []
    walk = 2
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        active = (t == "drop" and c.cfg.get("lead") in ("melodic", "accent") and i % 4 >= 2) or (t == "break" and i >= 2)
        active = active or (t == "build" and i >= B["L"] // 2 and r.random() < 0.5)
        active = active or (t in ("intro", "outro") and r.random() < 0.35)
        if not active:
            continue
        reg_name = _pick_vocal_reg(r, t) if r.random() < 0.55 else tr["vocal_register"]
        pool = _vocal_pool(c, B["root"], reg_name, octaves=2)
        # fraza: albo tokeny (stare), albo spacer po skali głosowej
        if r.random() < 0.45:
            k = tok(B)
            base = pool[0] if pool else reg(B["root"], VOCAL_REG[reg_name][0])
            for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 2):
                # mapuj token na stopień w pool
                deg = {"r": 0, "t": min(2, len(pool) - 1), "f": min(4, len(pool) - 1), "o": min(len(pool) - 1, 5)}.get(tkn, 0)
                w.add(b, s_, pool[deg] if pool else base + k.get(tkn, 0), ln, 92 + r.randint(-6, 6))
        else:
            rh = r.choice([[(0, 3), (4, 2), (8, 3), (12, 2)], [(2, 4), (8, 4)], [(0, 2), (3, 2), (6, 2), (10, 3)], [(0, 6), (8, 4)]])
            for s_, ln in rh:
                walk = max(0, min(len(pool) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
                w.add(b, s_, pool[walk], ln, 90 + r.randint(-8, 8))
        if m.has(tr["type"], "Vowel A-E-I-O-U"):
            vowel_pts.append([b * 4, m.eng2frac(tr["type"], "Vowel A-E-I-O-U", r.choice([0, 0.5, 1, 2, 3, 4]))])
    if vowel_pts:
        tr["auto"]["Vowel A-E-I-O-U"] = vowel_pts
    _apply_voice_theremin(tr, c, th_mode, m, r)


def gen_speak(c, tr):
    """DS Speak: skala głosowa (zmienny rejestr), intonacja, opcjonalny theremin pre/post."""
    w, r, m = Writer(c.p, tr), c.rng(tr["name"]), meta()
    th_mode = _theremin_mode(r)
    tr["vocal_register"] = r.choice(list(VOCAL_REG.keys()))
    tr["theremin_fx"] = th_mode
    walk = 2
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        reg_name = _pick_vocal_reg(r, t) if (b % 3 == 0 or r.random() < 0.4) else tr["vocal_register"]
        pool = _vocal_pool(c, B["root"], reg_name, octaves=2)
        if not pool:
            continue
        th = B["third"]
        # interwały w obrębie pool (nie stałe MIDI)
        def pick():
            nonlocal walk
            walk = max(0, min(len(pool) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
            return pool[walk]

        if t == "build" and i >= L // 2:
            steps = [0, 4, 8, 12] if i == L - 1 else [0, 8]
            for s_ in steps:
                w.add(b, s_, pick(), 3, 80 + int(40 * (i + s_ / 16) / L) + r.randint(-4, 4))
        elif t == "drop":
            if i % 8 == 0:
                # okrzyk — górna część rejestru
                k = pool[min(len(pool) - 1, len(pool) * 2 // 3 + r.randint(0, max(0, len(pool) // 4)))]
                w.add(b, 0, k, 6, 108 + r.randint(-3, 3))
            elif i % 8 == 7 and r.random() < c.p["density"]:
                w.add(b, 12, pick(), 3, 96)
            elif i % 4 == 2 and r.random() < 0.35 * c.p["density"]:
                w.add(b, 8, pick(), 2, 88 + r.randint(-4, 4))
        elif t == "break" and i >= 2:
            for s_ in (0, 8) if i % 2 == 0 else (0, 6, 10):
                w.add(b, s_, pick(), 5, 90 + r.randint(-5, 5))
        elif t == "intro" and i >= L - 4 and i % 2 == 0:
            w.add(b, 8, pick(), 4, 80 + r.randint(-4, 4))
        elif t == "outro" and i < 3:
            w.add(b, 8, pool[min(walk, len(pool) - 1)], 4, 70 + r.randint(-3, 3))
    _apply_voice_theremin(tr, c, th_mode, m, r)
    if tr.get("text_mode", "auto") == "auto":
        tr["text"] = auto_text(tr.get("text_theme"), c.p["style"], len(tr["notes"]), c.rng(tr["name"], 99))



# ------------------------------------------------------------------ instrumenty akustyczne (opcjonalne, nie w paletach domyślnych)
def _penta(root, lo):
    """Pentatonika moll od toniki `root` w rejestrze od `lo` (3 oktawy)."""
    base = reg(root, lo)
    return [base + 12 * o + d for o in range(3) for d in (0, 3, 5, 7, 10)]


def _scale_pool(c, lo, n=2):
    """Dźwięki skały projektu od `lo` w górę przez n oktaw (do linii melodycznych klasyki/jazzu)."""
    pcs = {(c.p["key"] + d) % 12 for d in SCALES[c.p["scale"]]}
    return [k for k in range(lo, lo + 12 * n + 1) if k % 12 in pcs]


def gen_theremin(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); walk = 2; mel = c.cfg.get("melody")
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        th = B["third"]; base = reg(B["root"], 60); tones = [0, th, 7, 12, th + 12, 14]
        if t == "break" or (t == "intro" and i >= L - 4) or (t == "outro" and i < 2) or (t == "build" and i >= L // 2) or (bool(mel) and t == "drop"):
            rh = _phrase_pick(c, tr["name"], MEL_RHY[mel], b, 2) if mel else (((0, 8), (8, 8)) if r.random() < 0.7 else ((0, 16),))
            for s_, ln in rh:
                walk = max(0, min(len(tones) - 1, walk + r.choice([-2, -1, 1, 2])))
                w.add(b, s_, base + tones[walk], ln, 88 + r.randint(-5, 5))


def gen_panflute(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); walk = 4; mel = c.cfg.get("melody")
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if mel:
            if t not in ("break", "intro", "outro", "drop"):
                continue
            pool = _scale_pool(c, reg(B["root"], 64) - 5, 2); walk = min(walk, len(pool) - 1)
            rh = _phrase_pick(c, tr["name"], MEL_RHY[mel], b, 2)
        elif t in ("break", "intro", "outro") and b % 2 == 0 or (t == "drop" and c.cfg["lead"] == "melodic" and i % 4 == 2):
            pool = _penta(B["root"], 64)
            rh = r.choice([[(0, 6), (6, 4), (10, 6)], [(0, 4), (4, 4), (8, 8)], [(2, 5), (8, 3), (12, 4)]])
        else:
            continue
        for s_, ln in rh:
            walk = max(0, min(len(pool) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
            w.add(b, s_, pool[walk], ln, 84 + r.randint(-5, 5))


def gen_handpan(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t in ("break", "intro", "outro") or (t == "drop" and c.cfg["lead"] in ("melodic",) and i % 2 == 1):
            th = B["third"]; base = reg(B["root"], 52)
            arp = r.choice([[0, th, 7, 12, 7, th, 0, th], [0, 7, 12, th + 12, 12, 7, th, 7], [0, 0, th, 7, 12, 7, th, 0]])
            for n_, s_ in enumerate(range(0, 16, 2)):
                if r.random() < 0.55 + 0.45 * c.dens(B):
                    w.add(b, s_, base + arp[n_ % len(arp)], 1, (96 if s_ % 8 == 0 else 74) + r.randint(-6, 6), drum=True)


def gen_tongue(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t = B["type"]
        if t in ("break", "intro", "outro") and (b % 2 == 1 or t == "break"):
            pool = _penta(B["root"], 60)
            for s_ in sorted(r.sample([0, 3, 6, 8, 10, 12, 14], r.choice([3, 4, 5]))):
                w.add(b, s_, r.choice(pool), 1, 78 + r.randint(-8, 10), drum=True)


def gen_piano(c, tr):
    """Keys: akordy / arpeggia w rejestrze fortepianowym, skala projektu."""
    w, r = Writer(c.p, tr), c.rng(tr["name"]); walk = 2; k = 0
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        ok, k = _maybe_arp_bar(c, tr, w, B, b, reg(B["root"], 60), k, r)
        if ok:
            continue
        pool = _scale_pool(c, reg(B["root"], 48), 3)
        if not pool:
            continue
        if t in ("break", "intro", "outro") or (t == "drop" and c.cfg.get("lead") in ("melodic", "accent") and i % 2 == 0):
            # akord: root + third + fifth (+ opc. 7)
            th = B["third"]
            chord = [0, th, 7]
            if r.random() < 0.4:
                chord.append(10 if r.random() < 0.5 else 11)
            base = pool[min(len(pool) // 3, len(pool) - 1)]
            for d in chord:
                k = min(pool, key=lambda x: abs((x % 12) - ((base + d) % 12)))
                w.add(b, 0, k, 12 if t != "drop" else 8, 78 + r.randint(-6, 8))
            if r.random() < 0.5:
                for s_ in (4, 8, 12):
                    walk = max(0, min(len(pool) - 1, walk + r.choice([-1, 1, 2])))
                    w.add(b, s_, pool[walk], 2, 70 + r.randint(-5, 8))
        elif t == "build" and i >= L // 2:
            for s_ in range(0, 16, 2):
                walk = max(0, min(len(pool) - 1, walk + r.choice([-1, 0, 1, 2])))
                w.add(b, s_, pool[walk], 1, 72 + r.randint(-4, 10))


def gen_acid(c, tr):
    """303-style: sekwencja 16-tkowa z glide'owymi skokami, skala / chromatyczne podejścia."""
    w, r = Writer(c.p, tr), c.rng(tr["name"]); walk = 0
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        if t not in ("drop", "build", "break") and not (t == "intro" and i >= B["L"] - 4):
            continue
        pool = _scale_pool(c, reg(B["root"], 36), 2)
        if not pool:
            continue
        dens = 0.55 + 0.35 * c.dens(B)
        for s_ in range(16):
            if r.random() > dens:
                continue
            walk = max(0, min(len(pool) - 1, walk + r.choice([-3, -2, -1, 0, 1, 2, 3, 5])))
            ln = 1 if r.random() < 0.7 else 2
            vel = 88 + r.randint(-10, 12)
            if s_ % 4 == 0:
                vel = min(127, vel + 12)
            w.add(b, s_, pool[walk], ln, vel)


def gen_strings(c, tr):
    """Smyczki: długie nuty akordowe / wolne linie w break/intro/outro i pads w dropie."""
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        pool = _scale_pool(c, reg(B["root"], 52), 2)
        if not pool:
            continue
        th = B["third"]
        if t in ("intro", "outro", "break") or (t == "drop" and i % 4 == 0):
            base = pool[len(pool) // 4]
            for d, vel in ((0, 72), (th, 68), (7, 65)):
                k = min(pool, key=lambda x: abs((x % 12) - ((base + d) % 12)))
                w.add(b, 0, k, 16, vel + r.randint(-4, 4))
        elif t == "build" and i >= B["L"] // 2:
            k = pool[min(len(pool) - 1, len(pool) // 2)]
            w.add(b, 0, k, 16, 70 + r.randint(-5, 5))



def gen_openhat(c, tr):
    """Otwarty hat: akcenty na „i\" (kroki 2,6,10,14) w dropie i drugiej połowie introna; w buildzie gęściej (ósemki)."""
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop" or (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            hm = ((c.drums.fill(b) or {}).get("hat_mute") if (c.predict < 0.999 and t == "drop") else None)
            for s_ in (2, 6, 10, 14):
                if r.random() < 0.55 + 0.45 * c.dens(B):
                    if hm is not None and s_ >= hm:
                        continue
                    w.add(b, s_, 70, 0, 78 + r.randint(-6, 6), drum=True)
        elif t == "build" and i >= L // 2:
            for s_ in range(0, 16, 4):
                w.add(b, s_ + 2, 70, 0, 70 + r.randint(-5, 8), drum=True)


def gen_ride(c, tr):
    """Ride: szkielet jazzowy (ćwierćnuty + „skip\" 6/14), w dropie i środkowych sekcjach; ghost-akcenty z gęstością."""
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t in ("drop", "break") or (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            for s_ in (0, 4, 6, 8, 12, 14):
                v = 86 if s_ % 4 == 0 else 66
                w.add(b, s_, 70, 0, v + r.randint(-6, 6), drum=True)
            if r.random() < 0.3 * c.dens(B):
                w.add(b, 10, 70, 0, 52 + r.randint(-4, 4), drum=True)


def gen_perc(c, tr):
    """Perkusjonalia (cowbell / conga): krótkie figury synkopowe w dropie i buildzie; conga strojona (dwie wysokości)."""
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [(0, 3, 6, 10, 12), (2, 5, 8, 11, 14), (0, 6, 8, 14), (3, 6, 9, 12, 15)]
    hi, lo = 64, 57; last = lib[0]
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop" or (t == "build" and i >= L // 2):
            if i % 4 == 0 or b == 0:
                last = r.choice(lib)
            pat = last
            for n_, s_ in enumerate(pat):
                if r.random() < 0.6 + 0.4 * c.dens(B):
                    w.add(b, s_, hi if n_ % 2 == 0 else lo, 0, 82 + r.randint(-8, 8), drum=True)


GEN = {"kick": gen_kick, "snare": gen_snare, "hat": gen_hat, "wobble": gen_wobble, "sub": gen_sub, "reese": gen_reese,
       "growl": gen_growl, "screech": gen_screech, "clap": gen_clap, "rim": gen_rim, "tom": gen_tom, "crash": gen_crash,
       "shaker": gen_shaker, "fmbass": gen_fmbass, "neuro": gen_neuro, "hollow": gen_hollow, "supersaw": gen_supersaw,
       "pluck": gen_pluck, "pad": gen_pad, "stab": gen_stab, "riser": gen_riser, "boom": gen_boom, "zap": gen_zap, "vox": gen_vox, "piano": gen_piano, "strings": gen_strings,
       "speak": gen_speak, "theremin": gen_theremin, "panflute": gen_panflute, "handpan": gen_handpan, "tongue": gen_tongue, "acid": gen_acid,
       # v6: nowe typy dzielą wzory z pokrewnymi (rejestr/brzmienie robi wtyczka), perkusjonalia mają własne
       "organ": gen_strings, "epiano": gen_piano, "harpsichord": gen_piano, "flute": gen_panflute, "brass": gen_stab, "choir": gen_pad, "cello": gen_strings,
       "vibes": gen_handpan, "marimba": gen_tongue, "bell": gen_tongue, "hoover": gen_stab, "bass808": gen_sub, "upright": gen_sub, "drone": gen_pad,
       "openhat": gen_openhat, "ride": gen_ride, "cowbell": gen_perc, "conga": gen_perc, "glitch": gen_zap}
# kolejność generowania (wobble przed sub: riddim powiela rytm)
ORDER = ["kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow", "acid",
         "screech", "supersaw", "pluck", "pad", "stab", "vox", "piano", "strings", "riser", "boom", "zap", "speak", "theremin", "panflute", "handpan", "tongue",
         "openhat", "ride", "cowbell", "conga", "bass808", "upright", "organ", "epiano", "harpsichord", "flute", "brass", "choir", "cello", "vibes", "marimba", "bell",
         "hoover", "drone", "glitch"]



# ------------------------------------------------------------------ zamiana ról (naprzemiennie w sekcjach)
# natywna rola typu wtyczki
NATIVE_ROLE = {
    "sub": "bass", "wobble": "bass", "reese": "bass", "growl": "bass", "neuro": "bass", "fmbass": "bass", "hollow": "bass",
    "screech": "lead", "supersaw": "lead", "pluck": "lead", "stab": "lead", "vox": "lead", "piano": "lead", "strings": "pad", "acid": "bass",
    "theremin": "lead", "panflute": "lead",
    "pad": "pad", "handpan": "pad", "tongue": "pad",
    "organ": "pad", "epiano": "lead", "harpsichord": "lead", "flute": "lead", "brass": "lead", "choir": "pad", "cello": "pad", "vibes": "pad", "marimba": "pad",
    "bell": "pad", "hoover": "lead", "drone": "pad", "bass808": "bass", "upright": "bass",
}
# preferowany rejestr MIDI (lo, hi) dla roli — medianę nut przesuwamy oktawami w ten zakres
ROLE_REG = {"bass": (28, 48), "lead": (58, 86), "pad": (45, 67)}
# które sekcje chętniej „oddają” rolę natywną
_SEC_SWAP_P = {"intro": 0.55, "build": 0.35, "drop": 0.12, "break": 0.70, "outro": 0.50}
# dozwolone role zastępcze wg roli natywnej
_ALT_ROLES = {
    "bass": ("lead", "pad"),
    "lead": ("bass", "pad"),
    "pad": ("lead", "bass"),
}
# bias parametrów przy retune barwy (nazwa param → kierunek przy roli lead (+) / bass (-))
_ROLE_PARAM_BIAS = {
    "Cutoff": {"lead": +0.18, "bass": -0.15, "pad": -0.05},
    "Drive": {"lead": -0.08, "bass": +0.10, "pad": -0.12},
    "Resonance": {"lead": +0.10, "bass": -0.05, "pad": +0.05},
    "Sub Osc": {"lead": -0.12, "bass": +0.15, "pad": +0.05},
    "Glide": {"lead": -0.08, "bass": +0.12, "pad": +0.05},
    "Attack": {"lead": -0.10, "bass": +0.05, "pad": +0.15},
    "Release": {"lead": -0.08, "bass": +0.05, "pad": +0.12},
    "Wave Morph": {"lead": +0.10, "bass": -0.05, "pad": +0.08},
}


def _median_key(notes):
    if not notes:
        return 48
    ks = sorted(n[2] for n in notes)
    return ks[len(ks) // 2]


def _shift_to_reg(notes, lo, hi, rng):
    """Przesuwa nuty oktawami tak, by mediana wpadła w [lo, hi]; zwraca (nowe_nuty, shift_półtonów)."""
    if not notes:
        return notes, 0
    med = _median_key(notes)
    mid = (lo + hi) / 2
    shift = 0
    while med + shift < lo and shift < 36:
        shift += 12
    while med + shift > hi and shift > -36:
        shift -= 12
    # drobny jitter ±12 gdy jesteśmy na krawędzi i RNG pozwala
    if abs((med + shift) - mid) > 8 and rng.random() < 0.25:
        shift += 12 if (med + shift) < mid else -12
    out = []
    for on, dur, k, v in notes:
        kk = max(24, min(108, int(k) + shift))
        out.append([on, dur, kk, v])
    return out, shift


def _role_for_section(native, sec_type, agg, rng):
    """Losuje rolę dla sekcji: zostaje natywna albo zamiana (lead/bass/pad)."""
    p = _SEC_SWAP_P.get(sec_type, 0.3)
    # niska agresja → więcej zamian (łagodniejsze „przebieranki"); wysoka → rzadziej w dropie
    p *= 1.15 - 0.12 * (agg / 5.0)
    if sec_type == "drop":
        p *= 0.7 + 0.15 * (1.0 - agg / 5.0)
    if rng.random() >= max(0.05, min(0.85, p)):
        return native
    alts = _ALT_ROLES.get(native, ("pad",))
    # przy wysokiej agresji bass chętniej → lead; przy niskiej → pad
    if native == "bass":
        return "lead" if rng.random() < 0.35 + 0.4 * (agg / 5.0) else "pad"
    if native == "lead":
        return "bass" if rng.random() < 0.25 + 0.25 * (agg / 5.0) else "pad"
    return rng.choice(alts)


def _retune_params_for_role(tr, role, strength=0.55):
    """Przesuwa frakcje parametrów w stronę barwy roli (bez pełnego min–max)."""
    try:
        m = meta()
    except Exception:
        m = None
    tt = tr["type"]
    locked = set(tr.get("locked_params") or [])
    if tr.get("lock_sound"):
        return
    for pname, by_role in _ROLE_PARAM_BIAS.items():
        if pname in locked or pname not in tr.get("params", {}):
            continue
        if m is not None and not m.has(tt, pname):
            continue
        delta = by_role.get(role, 0.0) * strength
        if abs(delta) < 0.01:
            continue
        f = float(tr["params"][pname])
        tr["params"][pname] = max(0.0, min(1.0, f + delta))


def apply_role_swaps(proj, rng=None):
    """Naprzemienna zamiana ról (bass↔lead↔pad) w sekcjach + retune barwy.
    Zależne od nastroju sekcji i agresji projektu. Zwraca listę opisów zamian."""
    rng = rng or random.Random(proj.get("seed", 0) + 91)
    agg = float(proj.get("aggression", style_aggression(proj["style"], proj.get("energy", 0.7), proj.get("density", 0.6))))
    sections = proj.get("sections") or []
    if not sections:
        return []
    report = []
    for tr in proj["tracks"]:
        if tr.get("lock_notes"):
            continue
        native = NATIVE_ROLE.get(tr["type"])
        if not native or not tr.get("notes"):
            continue
        # plan ról per sekcja
        plan = []
        swaps = 0
        for s in sections:
            role = _role_for_section(native, s["type"], agg, rng)
            if role != native:
                swaps += 1
            plan.append((s, role))
        # limit: 1…N zamian, nie więcej niż ~60% sekcji przy bardzo spokojnych stylach
        max_swaps = max(1, int(0.4 * len(sections) + 0.8))
        if swaps > max_swaps:
            # cofnij nadmiar (zostaw natywną w dropach najpierw)
            over = swaps - max_swaps
            for i in range(len(plan) - 1, -1, -1):
                if over <= 0:
                    break
                s, role = plan[i]
                if role != native and s["type"] == "drop":
                    plan[i] = (s, native); over -= 1
            for i in range(len(plan) - 1, -1, -1):
                if over <= 0:
                    break
                s, role = plan[i]
                if role != native:
                    plan[i] = (s, native); over -= 1
        # zastosuj per sekcja: nuty w zakresie beatów sekcji
        new_notes = []
        role_log = []
        notes = list(tr["notes"])
        for s, role in plan:
            t0 = s["start"] * 4.0
            t1 = (s["start"] + s["bars"]) * 4.0
            chunk = [n for n in notes if t0 <= n[0] < t1]
            rest_keep = True
            lo, hi = ROLE_REG[role]
            shifted, sh = _shift_to_reg(chunk, lo, hi, rng)
            # rola bass: nieco dłuższe nuty, cichsze peak velocity
            if role == "bass" and shifted:
                shifted = [[on, min(2.0, dur * 1.15), k, max(40, int(v * 0.92))] for on, dur, k, v in shifted]
            elif role == "lead" and shifted:
                shifted = [[on, max(0.05, dur * 0.9), k, min(127, int(v * 1.05))] for on, dur, k, v in shifted]
            elif role == "pad" and shifted:
                shifted = [[on, min(3.0, dur * 1.25), k, v] for on, dur, k, v in shifted]
            new_notes.extend(shifted)
            if role != native or sh:
                role_log.append({"sec": s["name"], "type": s["type"], "role": role, "native": native, "shift": sh})
        # nuty poza sekcjami (gdyby) — bez zmian
        covered = {(s["start"], s["bars"]) for s, _ in plan}
        # sort
        new_notes.sort(key=lambda n: (n[0], n[2]))
        tr["notes"] = new_notes
        # retune barwy: dominująca rola nie-natywna, albo natywna gdy brak zamian
        roles_used = [r for _, r in plan]
        cnt = Counter(roles_used)
        dominant = cnt.most_common(1)[0][0]
        strength = 0.35 + 0.35 * (cnt[dominant] / max(1, len(roles_used)))
        if dominant != native:
            _retune_params_for_role(tr, dominant, strength=strength)
        elif any(r != native for r in roles_used):
            # mieszanka: lekki retune w stronę najczęstszej zamiany
            alt = next(r for r in roles_used if r != native)
            _retune_params_for_role(tr, alt, strength=0.25)
        tr["role_plan"] = role_log
        if role_log:
            report.append({"track": tr["name"], "type": tr["type"], "swaps": role_log})
    proj["role_swaps"] = report
    return report


def default_instruments(style):
    cfg = STYLES[style]; core_ = list(cfg.get("core", CORE8))
    return core_ + [t for t in cfg.get("extras", []) if t not in core_]


def expand_voices(style, inst):
    """voices stylu: wtyczki są jednogłosowe — akord/warstwy = kilka instancji (tylko dla typów już zaznaczonych)."""
    out = list(inst)
    for t, n in STYLES[style].get("voices", {}).items():
        k = out.count(t)
        if k:
            out += [t] * max(0, n - k)
    return out


def mutate_track(proj, cfg, tr, rng):
    """cfg[\"mutate\"] = {drop, jitter, octave, shift}: losowa mutacja nut (usunięcie / przesunięcie o 1/16 / oktawa / o stopień skali)."""
    if tr.get("lock_notes"):
        return
    mu = cfg.get("mutate")
    if not mu or tr["type"] in NO_MUTATE or not tr["notes"]:
        return
    pcs = sorted((proj["key"] + d) % 12 for d in SCALES[proj["scale"]]); out = []
    for on, dur, k, v in tr["notes"]:
        if rng.random() < mu.get("drop", 0):
            continue
        if rng.random() < mu.get("jitter", 0):
            on = max(0.0, on + rng.choice([-0.25, 0.25]))
        if rng.random() < mu.get("octave", 0):
            k += rng.choice([-12, 12])
        if rng.random() < mu.get("shift", 0):
            d = rng.choice([-1, 1]); kk = k + d
            while kk % 12 not in pcs:
                kk += d
            k = kk
        out.append([round(on, 4), dur, max(24, min(108, int(k))), v])
    out.sort(key=lambda n: (n[0], n[2])); tr["notes"] = out


def _order_tracks(tracks):
    return sorted(tracks, key=lambda t: (TYPES.index(t["type"]), t["name"]))



def apply_structure_affinity(proj, passes=2, rng=None, director=None, role_swap=None, autolevels=None,
                       replace_on=None, replace_rules=None, replace_policy=None,
                       uniq=None, uniq_strength=None, uniq_drops=None, rebuild_links=True):
    """Domknięcie powinowactw całej struktury (2–N przebiegów).

    Po jednorazowym generate() role / levels / replace / linki bywają niespójne
    (kolejność jednokierunkowa). Ta funkcja ponawia kluczowe post-passy na *tym samym*
    projekcie, aż zależności się ustabilizują albo skończą się przebiegi.

    Uwzględnia flagi z proj (zapisane przez generate) albo jawne argumenty.
    Live/TOD: wołane z już dobranymi energy/style/sekcjami — nie losuje od nowa pory dnia.
    """
    from . import director as DIR
    passes = max(1, int(passes))
    rng = rng or random.Random(int(proj.get("seed") or 0) + 101)
    d = DIR.normalize(director if director is not None else proj.get("director"))
    do_roles = d.get("on") and d.get("roles") if role_swap is None else bool(role_swap)
    if role_swap is None and not d.get("on"):
        do_roles = bool(proj.get("role_swap") or (proj.get("role_swaps")))
    do_al = (d.get("on") and d.get("autolevel")) if autolevels is None else bool(autolevels)
    if autolevels is None and not d.get("on"):
        do_al = bool(proj.get("autolevels", True))
    do_repl = bool(replace_on if replace_on is not None else proj.get("replace_on"))
    rules = replace_rules if replace_rules is not None else proj.get("replace_rules")
    policy = replace_policy if replace_policy is not None else proj.get("replace_policy")
    do_uniq = bool(uniq if uniq is not None else proj.get("uniq"))
    u_str = float(uniq_strength if uniq_strength is not None else (proj.get("uniq_strength") or 0.6))
    u_drops = bool(uniq_drops if uniq_drops is not None else proj.get("uniq_drops"))

    A = min(1.0, float(proj.get("aggression") or style_aggression(
        proj.get("style", "Brostep"), float(proj.get("energy") or 0.7), float(proj.get("density") or 0.6))) / 5.0)
    o = 0.5
    if d.get("on"):
        try:
            A = DIR.aggression(proj.get("style", "Brostep"), float(proj.get("energy") or 0.7), float(d.get("mood") or 0)) / 5.0
            A = min(1.0, max(0.0, A))
            o = 0.5 + 0.4 * float(d.get("mood") or 0)
        except Exception:
            pass

    report = []
    for i in range(passes):
        step = {"pass": i + 1}
        # 1) role ↔ sekcje
        if do_roles:
            if d.get("on") and d.get("roles"):
                ev = DIR.apply_roles(proj, d, random.Random(rng.random()), A, o)
                proj["role_events"] = ev
                step["roles"] = len(ev or [])
            else:
                apply_role_swaps(proj, random.Random(rng.random()))
                step["roles"] = "legacy"
        # 2) zamiana instrumentów wg ról (powinowactwo lead↔lead…)
        if do_repl or policy:
            from . import instrument_replace as IR
            before = [tr["type"] for tr in proj.get("tracks") or []]
            IR.apply(proj, rules or [], rng=random.Random(rng.random()), policy=policy)
            after = [tr["type"] for tr in proj.get("tracks") or []]
            step["replace"] = sum(1 for a, b in zip(before, after) if a != b)
        # 3) linki ducking / sidechain do aktualnej obsady
        if rebuild_links:
            try:
                proj["links"] = default_links(proj.get("style", "Brostep"), proj.get("tracks") or [])
                step["links"] = len(proj["links"])
            except Exception as e:
                step["links_err"] = str(e)
        # 4) autolevel heurystyczny względem nowej struktury
        if do_al:
            autolevel_heuristic(proj)
            step["autolevel"] = True
        # 5) lekki uniq (tylko przy ostatnim przebiegu, żeby nie rozjeżdżać ról)
        if do_uniq and i == passes - 1 and u_str > 0:
            from . import uniq as UNIQ
            UNIQ.apply(proj, strength=u_str * 0.55, rng=random.Random(rng.random()),
                       include_drops=u_drops)
            step["uniq"] = True
        report.append(step)

    proj["structure_affinity"] = True
    proj["structure_affinity_report"] = report
    return proj



# ====================================================================== PALETA KLIMATU
# Jednorazowy zestaw decyzji (assetów) na całą aranżację — ten sam klimat od intro do outro.
# Bez tego instrumenty / motywy / gęstość bywały losowane lokalnie i „rozjeżdżały” gatunek w czasie.

_CLIMATE_BASS = {
    "dark": ("reese", "sub", "wobble"),
    "acid": ("acid", "sub", "bass808"),
    "organic": ("bass808", "sub", "upright"),
    "bright": ("sub", "bass808", "fmbass"),
    "hard": ("reese", "wobble", "sub"),
    "space": ("sub", "drone", "bass808"),
}
_CLIMATE_LEAD = {
    "dark": ("hoover", "screech", "stab"),
    "acid": ("acid", "pluck", "supersaw"),
    "organic": ("pluck", "epiano", "organ"),
    "bright": ("supersaw", "pluck", "stab"),
    "hard": ("hoover", "screech", "supersaw"),
    "space": ("pad", "pluck", "theremin"),
}
_CLIMATE_PAD = {
    "dark": ("pad", "drone", "choir"),
    "acid": ("pad", "stab", "supersaw"),
    "organic": ("pad", "strings", "epiano"),
    "bright": ("pad", "supersaw", "choir"),
    "hard": ("pad", "drone", "stab"),
    "space": ("pad", "drone", "choir"),
}


def _climate_family(style: str, energy: float, density: float, character) -> str:
    """Gruba etykieta klimatu z nazwy stylu / energii."""
    s = (style or "").lower()
    cv = _char_val(character)
    if any(k in s for k in ("acid", "303")):
        return "acid"
    if any(k in s for k in ("berlin", "space", "ambient", "romantic", "minimal")):
        return "space"
    if any(k in s for k in ("jazz", "house", "disco", "electro cafe")):
        return "organic" if energy < 0.65 else "bright"
    if any(k in s for k in ("hard", "industrial", "gesaffelstein", "raw", "neuro", "riddim", "dnb", "prodigy")):
        return "hard"
    if any(k in s for k in ("trance", "progressive", "supersaw", "flashmob")):
        return "bright"
    if cv < 0.35 or energy < 0.45:
        return "space" if density < 0.5 else "dark"
    if energy > 0.8 or density > 0.75:
        return "hard"
    return "dark" if cv > 0.6 else "bright"


def build_climate(style, energy=0.7, density=0.6, era="auto", character="balanced",
                  scale="minor", bpm=140, seed=0, instruments=None) -> dict:
    """Zwraca zamrożony zestaw assetów / reguł na CAŁĄ generację.

    Pola:
      family, motif_seed, phrase_len,
      bass_role, lead_role, pad_role,
      density_curve (per section type → mnożnik 0.5..1.3),
      energy_curve,
      harmony_lock (używaj jednej progresji),
      section_motif_reuse,
      timbre_bias (dark/bright/narrow),
      space (0..1 obecność pada/dronu w intro/break/outro),
      drum_tight, swing_lock.
    """
    rng = random.Random(int(seed) + 991)
    family = _climate_family(style, float(energy), float(density), character)
    phrase_len = 2 if "riddim" in (style or "").lower() or float(density) > 0.8 else (8 if float(energy) < 0.4 else 4)
    dens = float(density)
    # krzywe gęstości / energii sekcji — spójne z klimatem, nie losowane per takt
    if family in ("space",):
        density_curve = {"intro": 0.55, "build": 0.75, "drop": 0.95, "break": 0.50, "outro": 0.45}
        energy_curve = {"intro": 0.45, "build": 0.70, "drop": 0.90, "break": 0.40, "outro": 0.30}
        space = 0.75
    elif family == "hard":
        density_curve = {"intro": 0.70, "build": 0.95, "drop": 1.15, "break": 0.55, "outro": 0.50}
        energy_curve = {"intro": 0.60, "build": 0.95, "drop": 1.10, "break": 0.45, "outro": 0.35}
        space = 0.25
    elif family == "acid":
        density_curve = {"intro": 0.65, "build": 0.90, "drop": 1.05, "break": 0.60, "outro": 0.50}
        energy_curve = {"intro": 0.55, "build": 0.85, "drop": 1.00, "break": 0.50, "outro": 0.35}
        space = 0.35
    elif family == "organic":
        density_curve = {"intro": 0.60, "build": 0.80, "drop": 1.00, "break": 0.65, "outro": 0.55}
        energy_curve = {"intro": 0.50, "build": 0.75, "drop": 0.95, "break": 0.55, "outro": 0.40}
        space = 0.45
    else:  # bright / dark
        density_curve = {"intro": 0.60, "build": 0.85, "drop": 1.05, "break": 0.55, "outro": 0.45}
        energy_curve = {"intro": 0.50, "build": 0.85, "drop": 1.00, "break": 0.45, "outro": 0.35}
        space = 0.40 if family == "bright" else 0.55

    # skaluj krzywe bazową gęstością/energią (nie wychodząc poza sensowny zakres)
    density_curve = {k: max(0.35, min(1.25, v * (0.7 + 0.6 * dens))) for k, v in density_curve.items()}
    energy_curve = {k: max(0.25, min(1.20, v * (0.65 + 0.7 * float(energy)))) for k, v in energy_curve.items()}

    bass_opts = _CLIMATE_BASS[family]
    lead_opts = _CLIMATE_LEAD[family]
    pad_opts = _CLIMATE_PAD[family]
    # jeśli user podał instrumenty — wybierz rolę spośród dostępnych
    inst_set = set(instruments or [])
    def _pick(opts):
        for o in opts:
            if not inst_set or o in inst_set:
                return o
        return opts[0]

    climate = dict(
        family=family,
        motif_seed=rng.randint(1, 10 ** 9),
        phrase_len=phrase_len,
        bass_role=_pick(bass_opts),
        lead_role=_pick(lead_opts),
        pad_role=_pick(pad_opts),
        density_curve=density_curve,
        energy_curve=energy_curve,
        harmony_lock=True,
        section_motif_reuse=True,
        timbre_bias={"space": "wide", "hard": "narrow", "acid": "nasal", "organic": "warm", "bright": "bright", "dark": "dark"}[family],
        space=space,
        drum_tight=family in ("hard", "acid") or dens > 0.7,
        swing_lock=family in ("organic", "bright"),
        era=era,
        style=style,
    )
    return climate


def apply_climate_to_sections(sections, climate):
    """Nadpisuje e0/e1 sekcji krzywymi z palety (z zachowaniem delikatnego łuku wewnątrz sekcji)."""
    if not climate:
        return sections
    ec = climate.get("energy_curve") or {}
    for s in sections:
        t = s.get("type") or s.get("name", "").rstrip("0123456789")
        base = ec.get(t, 0.7)
        # lekki łuk: intro/build rosną, drop płaski, break/outro opadają
        if t == "build":
            s["e0"], s["e1"] = round(base * 0.85, 3), round(min(1.15, base * 1.1), 3)
        elif t == "intro":
            s["e0"], s["e1"] = round(base * 0.8, 3), round(base, 3)
        elif t == "drop":
            s["e0"], s["e1"] = round(base, 3), round(base, 3)
        elif t == "break":
            s["e0"], s["e1"] = round(base, 3), round(base * 0.9, 3)
        elif t == "outro":
            s["e0"], s["e1"] = round(base, 3), round(base * 0.6, 3)
        else:
            s["e0"], s["e1"] = round(base * 0.9, 3), round(base, 3)
    return sections


def climate_density_for(climate, section_type, bar_index=0):
    """Mnożnik gęstości nut dla danej sekcji (używany przez generatory ścieżek)."""
    if not climate:
        return 1.0
    return float((climate.get("density_curve") or {}).get(section_type, 1.0))


def climate_motif_rng(climate, track_name, section_type, section_k=1):
    """Deterministyczny RNG motywu: ten sam dla powtórzeń tego samego typu sekcji (reuse)."""
    if not climate:
        return random.Random(hash((track_name, section_type, section_k)) & 0xFFFFFFFF)
    base = int(climate.get("motif_seed") or 0)
    if climate.get("section_motif_reuse"):
        # ten sam motyw dla drop1 i drop2 itd. — tylko typ + tor
        return random.Random((base ^ hash((track_name, section_type))) & 0xFFFFFFFF)
    return random.Random((base ^ hash((track_name, section_type, section_k))) & 0xFFFFFFFF)


def generate(style="Brostep", bpm=None, key=None, scale="minor", bars=144, energy=0.7, swing=None, density=0.6, seed=None,
             name=None, instruments=None, speak_text=None, speak_theme=None, smart_instruments=False, autolevels=False,
             role_swap=False, scenarios=False, character="balanced", director=None,
             niuanse=False, niuanse_strength=0.0, spectacle="balanced", era="auto",
             uniq=False, uniq_strength=0.6, uniq_drops=False,
             replace_rules=None, replace_on=False, replace_policy=None,
             health=None, arp=None, structure_affinity=False, affinity_passes=2, arranger=None, predict=0.6,
             dance=False, dance_strength=0.6, variety=0.5, magic_noum=False, magic=None):
    """Główna generacja. Gdy director.on — REŻYSER nadrzędnie steruje: mood→A/o, scenariusz, instrumenty,
    okna parametrów, zamiany ról, autolevel. Blokady skip/param_locks działają zawsze (niezależnie od on).
    Legacy flagi (smart_instruments, scenarios, role_swap, character, autolevels) działają gdy director wyłączony
    albo uzupełniają gdy odpowiedni pod-tryb reżysera jest off.

    magic_noum=True / magic={...}: tryb „poszukiwania Graala” — N kandydatów, przeszczepy tego co odstaje
    na plus, przetasowanie słabych, do 4 przebiegów domknięcia spójności (patrz magic_noum.py).
    """
    # --- magic noum: delegacja (kandydaci wołają generate z magic_noum=False) ---
    _magic_cfg = magic if isinstance(magic, dict) else None
    if magic_noum or (isinstance(_magic_cfg, dict) and _magic_cfg.get("on")):
        from . import magic_noum as MN
        kw = dict(
            style=style, bpm=bpm, key=key, scale=scale, bars=bars, energy=energy, swing=swing,
            density=density, seed=seed, name=name, instruments=instruments, speak_text=speak_text,
            speak_theme=speak_theme, smart_instruments=smart_instruments, autolevels=autolevels,
            role_swap=role_swap, scenarios=scenarios, character=character, director=director,
            niuanse=niuanse, niuanse_strength=niuanse_strength, spectacle=spectacle, era=era,
            uniq=uniq, uniq_strength=uniq_strength, uniq_drops=uniq_drops,
            replace_rules=replace_rules, replace_on=replace_on, replace_policy=replace_policy,
            health=health, arp=arp, structure_affinity=structure_affinity, affinity_passes=affinity_passes,
            arranger=arranger, predict=predict, dance=dance, dance_strength=dance_strength, variety=variety,
            magic_noum=False, magic=None,
        )
        cfg = dict(MN.DEFAULT_MAGIC)
        if _magic_cfg:
            cfg.update(_magic_cfg)
        cfg["on"] = True
        return MN.run_magic_noum(generate, kw, cfg=cfg)

    from . import director as DIR
    from . import scenario as SCN
    from . import health_mode as HM
    from . import arp_engine as ARP
    from . import user_rules as UR
    UR.ensure_applied()                                   # własne grupy wtyczek (user_rules.json) przed doborem instrumentów
    if health and isinstance(health, dict) and health.get("on"):
        _hk = HM.apply_to_generate_kwargs(
            dict(density=density, energy=energy, spectacle=spectacle, era=era,
                 niuanse=niuanse, niuanse_strength=niuanse_strength,
                 uniq=uniq, uniq_strength=uniq_strength, swing=swing),
            health)
        density = _hk.get("density", density)
        energy = _hk.get("energy", energy)
        spectacle = _hk.get("spectacle", spectacle)
        era = _hk.get("era", era)
        niuanse = _hk.get("niuanse", niuanse)
        niuanse_strength = _hk.get("niuanse_strength", niuanse_strength)
        uniq = _hk.get("uniq", uniq)
        uniq_strength = _hk.get("uniq_strength", uniq_strength)
        if _hk.get("swing") is not None:
            swing = _hk["swing"]
    d = DIR.normalize(director)
    cfg = STYLES[style]
    seed = int(seed if seed is not None else time.time() * 1000) % 1000000
    variety = max(0.0, min(1.0, float(variety or 0.0)))          # zmienność w granicach gatunku (style_variants.py); 0 = dawne zachowanie
    cfg = SV.varied(style, cfg, variety, seed)
    rng = random.Random(seed)
    key = rng.randrange(12) if key is None else key
    swing = cfg["swing"] if swing is None else swing
    # arp: GUI/proj/styl albo czasem auto z wag
    try:
        from . import styles as _ST
        _sc = float(_ST.STYLE_CLASS.get(str(style).split("%")[0].split("+")[0].strip(), 2.5))
    except Exception:
        _sc = 2.5
    _arp = ARP.resolve_arp(None, cfg, arp if isinstance(arp, dict) else None, density, energy, _sc, rng, auto_chance=0.32)
    if _arp.get("enabled") and not (arp and isinstance(arp, dict) and arp.get("enabled")):
        # auto: prefer structural inject + design pod wagi
        if not cfg.get("arp"):
            _arp = ARP.design_structural_arp(density, energy, _sc, random.Random(seed + 19))
            _arp["enabled"] = True
        else:
            _arp["structural_inject"] = True

    # --- mood / agresja / optymizm (reżyser) ---
    mood = float(d["mood"])
    if d["on"] and d.get("mood_jitter"):
        mood = max(-1.0, min(1.0, mood + rng.uniform(-float(d["mood_jitter"]), float(d["mood_jitter"]))))
    # mapowanie legacy character → mood gdy reżyser off ale scenarios on
    _char_mood = {"very_optimistic": 1.0, "optimistic": 0.5, "balanced": 0.0, "restrained": -0.5, "dark": -1.0}
    if not d["on"] and scenarios:
        mood = _char_mood.get(str(character), 0.0)
    if d["on"]:
        A, o = DIR.aggression(style, energy, mood)
        agg_store = A  # 0..1
    else:
        A, o = None, 0.5
        agg_store = style_aggression(style, energy, density)  # 0..5 legacy

    if d["on"] and d.get("mood_scale"):
        scale = DIR.mood_scale(cfg, mood, rng, scale)

    proj = new_project(name=name or f"{short_name(style)}-{seed}", bpm=bpm or SV.bpm_for(style, cfg, variety, seed) or cfg["bpm"], style=style, key=key, scale=scale, seed=seed,
                       swing=swing, energy=energy, density=density)
    proj["variety"], proj["vseed"] = variety, seed           # zmienność stylu: wzory zależne od (styl, variety, vseed) — reroll ścieżki ich nie zmienia
    proj["predict"] = max(0.0, min(1.0, float(predict)))      # przewidywalność perkusji (1.0 = dawne reguły); patrz drum_rules.py
    proj["smart_instruments"] = bool(smart_instruments) or (d["on"] and d.get("pick_instruments"))
    proj["autolevels"] = bool(autolevels) or (d["on"] and d.get("autolevel"))
    proj["role_swap"] = bool(role_swap) or (d["on"] and d.get("roles"))
    proj["scenarios"] = bool(scenarios) or (d["on"] and d.get("scenario"))
    proj["character"] = character if proj["scenarios"] else None
    proj["director"] = d
    proj["mood"] = mood if d["on"] or scenarios else None
    proj["aggression"] = agg_store
    if A is not None:
        proj["A"], proj["o"] = A, o

    # --- paleta klimatu (zamrożone assety na całą aranżację) ---
    climate = build_climate(
        style=style, energy=energy, density=density,
        era=era, character=character, scale=scale,
        bpm=proj.get("bpm") or (bpm or cfg.get("bpm") or 140),
        seed=seed, instruments=instruments,
    )
    proj["climate"] = climate

    # --- sekcje (scenariusz nadrzędny) ---
    use_scen = (d["on"] and d.get("scenario")) or (not d["on"] and scenarios)
    if use_scen:
        base = fit_template(cfg["template"], bars, rng)
        strength = float(d.get("scenario_strength", 0.5)) if d["on"] else 0.55
        rules = d.get("rules") if d["on"] else None
        Aa = A if A is not None else min(1.0, style_aggression(style, energy, density) / 5.0)
        oo = o if A is not None else _char_mood.get(str(character), 0.0) * 0.5 + 0.5
        flags = {"ambient": style in ("Space Electronica", "Berlin School", "Romantic", "Baroque", "Minimal Classical")}
        built, srep = SCN.build(base, sum(b for _, b in base), Aa, oo, strength, random.Random(seed + 3), rules, flags)
        # built: [typ, takty, e0, e1]
        start, ord_ = 0, {}
        es = 0.6 + 0.4 * energy
        for sname, n, e0, e1 in built:
            ord_[sname] = ord_.get(sname, 0) + 1
            proj["sections"].append({"name": f"{sname}{ord_[sname]}", "type": sname, "k": ord_[sname],
                                     "start": start, "bars": int(n),
                                     "e0": round(e0 * es, 3), "e1": round(e1 * es, 3)})
            start += int(n)
        proj["scenario_report"] = srep
        proj["bars"] = start
    else:
        es = 0.6 + 0.4 * energy
        start, ord_ = 0, {}
        for sname, n in fit_template(cfg["template"], bars, rng):
            ord_[sname] = ord_.get(sname, 0) + 1
            e0, e1 = {"intro": (0.3, 0.4), "build": (0.5, 0.95), "drop": (1.0, 1.0), "break": (0.35, 0.35), "outro": (0.3, 0.1)}[sname]
            proj["sections"].append({"name": f"{sname}{ord_[sname]}", "type": sname, "k": ord_[sname], "start": start, "bars": n,
                                     "e0": round(e0 * es, 3), "e1": round(e1 * es, 3)})
            start += n
        proj["bars"] = start

    # --- dopasuj energie sekcji do palety klimatu (spójny łuk od intro do outro) ---
    apply_climate_to_sections(proj["sections"], climate)

    # --- harmonia ---
    sc = SCALES[scale]
    if d["on"] and d.get("mood_scale"):
        prog = DIR.mood_progs(scale, mood, cfg.get("progs") or PROGS, rng)
    else:
        progs = cfg.get("progs") or PROGS
        if climate.get("harmony_lock") and progs:
            # jedna progresja na cały utwór (klimat), nie los co takt
            prog = progs[random.Random(climate["motif_seed"] + 3).randrange(len(progs))]
        else:
            prog = rng.choice(progs)
    for b in range(proj["bars"]):
        d_deg = prog[(b // cfg["chord_len"]) % len(prog)]
        proj["chords"].append([(key + sc[d_deg]) % 12, (sc[(d_deg + 2) % 7] - sc[d_deg]) % 12])

    # --- instrumenty ---
    skip = set(d.get("skip") or [])
    # legacy locked skip from instruments list is handled by GUI post-process
    if d["on"] and d.get("pick_instruments") and not d.get("instruments_locked") and instruments is None:
        try:
            avail = core.available_types()
        except Exception:
            avail = list(TYPES)
        inst_list = DIR.pick_instruments(style, A, o, float(d.get("variety", 0.6)), random.Random(seed + 17),
                                         avail, skip=skip)
        if (speak_text or speak_theme) and "speak" not in inst_list and "speak" not in skip:
            inst_list = list(inst_list) + ["speak"]
    elif instruments is None and smart_instruments:
        must = ["speak"] if (speak_text or speak_theme) else None
        inst_list = pick_smart_instruments(style, energy, density, seed=seed + 17, include=must, clarity=UR.get()["clarity"])
        inst_list = [t for t in inst_list if t not in skip]
    else:
        inst_list = instruments or default_instruments(style)
        inst_list = [t for t in inst_list if t not in skip]
        if (speak_text or speak_theme) and "speak" not in inst_list and "speak" not in skip:
            inst_list = list(inst_list) + ["speak"]

    from . import niuanse as NIU
    from . import era_profiles as ERA
    era_id = ERA.resolve_era(era, style)
    # spektakularność: user > era default gdy spectacle==auto (GUI może podać "balanced" — era i tak filtruje tory)
    spec = spectacle
    if str(spectacle).lower() in ("auto", "none", ""):
        spec = ERA.spectacle_for_era(era_id, style)
    try:
        from . import core as _core
        _avail = set(_core.available_types())
    except Exception:
        _avail = None
    inst_list = ERA.filter_instruments(inst_list, era_id, style, random.Random(seed + 19), _avail)
    inst_list = NIU.expand_spectacle_voices(inst_list, spec, random.Random(seed + 23))
    # przy minimalnej erze spectacle_voices nie powinno rozdmuchać ponad max_tracks
    inst_list = ERA.filter_instruments(inst_list, era_id, style, random.Random(seed + 20), _avail)
    for t in UR.filter_voice_types(expand_voices(style, inst_list)):      # poziom mowy (speak/vox/growl)
        if t in skip:
            continue
        proj["tracks"].append(new_track(unique_name(proj, t), t))
    for tr in proj["tracks"]:
        if tr["type"] == "speak":
            manual = bool(speak_text and speak_text.strip())
            tr["text_mode"] = "manual" if manual else "auto"
            tr["text"] = speak_text.strip() if manual else ""
            tr["text_theme"] = speak_theme
    proj["tracks"] = _order_tracks(proj["tracks"])

    # --- brzmienie + nuty ---
    use_win = bool(d["on"] and d.get("windows"))
    # inteligentne okna parametrów także bez reżysera (smart_instruments / smart_tune)
    if not use_win and (smart_instruments or proj.get("smart_tune", True)):
        use_win = False  # randomize_sound i tak użyje smart_param_window
        if A is None:
            A = min(1.0, float(proj.get("aggression", style_aggression(style, energy, density))) / 5.0)
        if o is None:
            o = 0.5
    param_locks = d.get("param_locks") or {}
    c = Ctx(proj, cfg)
    proj["arp"] = _arp
    if _arp.get("enabled"):
        cfg = dict(cfg)
        cfg["arp"] = _arp

    for tr in sorted(proj["tracks"], key=lambda t: ORDER.index(t["type"])):
        forced = param_locks.get(tr["type"]) or param_locks.get(tr["name"])
        randomize_sound(proj, tr, random.Random(f"{seed}-snd-{tr['name']}"),
                        A=A, o=o, use_windows=use_win, forced_params=forced)
        GEN[tr["type"]](c, tr)
        mutate_track(proj, cfg, tr, random.Random(f"{seed}-mut-{tr['name']}"))
    if c.predict < 0.999 and c._drums is not None:       # podgląd użytych reguł (build → reguła, takt → fill); tylko informacyjnie
        sm = c._drums.summary
        proj["drum_plan"] = {"builds": sm["builds"], "fills": {str(k): v for k, v in sm["fills"].items()}}
    proj["links"] = default_links(style, proj["tracks"])

    # --- arp/seq inject na długich nutach harmonicznych (strukturalny, wyważony) ---
    if _arp.get("enabled") and (_arp.get("structural_inject", True) or (arp and isinstance(arp, dict) and arp.get("structural_inject"))):
        try:
            from . import arp_engine as ARP
            ARP.structural_inject(
                proj, arp_cfg=_arp,
                inject=dict(enabled=True, dens_mul=0.85 + 0.3 * float(density), min_dur=1.5 + (0.5 if density < 0.45 else 0.0)),
                rng=random.Random(seed + 77),
                density=density, energy=energy,
            )
        except Exception:
            pass

    # --- era: bias parametrów ---
    from . import era_profiles as ERA
    ERA.apply_to_project(proj, era_id, random.Random(seed + 77))

    # --- zamiany ról ---
    if d["on"] and d.get("roles"):
        ev = DIR.apply_roles(proj, d, random.Random(seed + 91), A, o)
        proj["role_events"] = ev
        proj["role_swaps"] = [{"track": "director", "swaps": [{"sec": e, "type": "role", "role": e, "native": "", "shift": 0} for e in ev]}] if ev else []
    elif role_swap:
        apply_role_swaps(proj, random.Random(seed + 91))

    if (d["on"] and d.get("autolevel")) or autolevels:
        autolevel_heuristic(proj)

    # --- aranżer: barwy / extras / kreator / nowe ad hoc + efekty WYSIWYG (opcjonalnie) ---
    if arranger:
        from . import arranger as ARR
        ARR.apply(proj, arranger, random.Random(seed + 131))

    # --- niuanse artykulacji partii (skale, arp, duo, zaniki…) ---
    from . import niuanse as NIU
    proj["spectacle"] = NIU.spectacle_value(spectacle)
    if niuanse:
        from . import era_profiles as ERA
        nm = ERA.niuanse_mul(proj.get("era") or era, style)
        NIU.apply_all(proj, float(niuanse_strength) * nm, random.Random(seed + 42),
                      spectacle=proj.get("spectacle") or spectacle)

    # --- niepowtarzalność segmentów (po niuansach) ---
    if uniq and float(uniq_strength) > 0.0:
        from . import uniq as UNIQ
        UNIQ.apply(proj, strength=float(uniq_strength), rng=random.Random(seed + 55),
                   include_drops=bool(uniq_drops))

    # --- rytmy taneczne melodii: kroki stylu (klimat) → ekspresja pod vibe (opcjonalnie; patrz dance_rhythm.py) ---
    proj["dance_on"], proj["dance_strength"] = bool(dance), float(dance_strength)
    if dance and float(dance_strength) > 0.0:
        from . import dance_rhythm as DANCE
        DANCE.apply(proj, float(dance_strength), random.Random(seed + 61))

    # --- zamiana instrumentów wg reguł ról (lead→lead, bass→bass…) ---
    if replace_on and (replace_rules or replace_policy):
        from . import instrument_replace as IR
        IR.apply(proj, replace_rules or [], rng=random.Random(seed + 88), policy=replace_policy)
    elif replace_policy:
        from . import instrument_replace as IR
        IR.apply(proj, [], rng=random.Random(seed + 88), policy=replace_policy)

    # --- health mode (nadrzędny łuk sesji / hemisync / BPM) ---
    if health and isinstance(health, dict) and health.get("on"):
        from . import health_mode as HM
        HM.apply_all(proj, health, random.Random(seed + 33))

    # zapamiętaj flagi struktury (Live / ponowne affinity)
    proj["autolevels"] = bool((d["on"] and d.get("autolevel")) or autolevels)
    proj["role_swap"] = bool(role_swap)
    proj["replace_on"] = bool(replace_on)
    if replace_rules is not None:
        proj["replace_rules"] = replace_rules
    if replace_policy is not None:
        proj["replace_policy"] = replace_policy
    proj["uniq"] = bool(uniq)
    proj["uniq_strength"] = float(uniq_strength or 0)
    proj["uniq_drops"] = bool(uniq_drops)
    if director is not None:
        proj["director"] = d

    # --- domknięcie powinowactw całej struktury (opcjonalne, N przebiegów) ---
    if structure_affinity:
        apply_structure_affinity(
            proj,
            passes=int(affinity_passes or 2),
            rng=random.Random(seed + 101),
            director=d,
            role_swap=role_swap or (d.get("on") and d.get("roles")),
            autolevels=autolevels or (d.get("on") and d.get("autolevel")),
            replace_on=replace_on,
            replace_rules=replace_rules,
            replace_policy=replace_policy,
            uniq=uniq,
            uniq_strength=uniq_strength,
            uniq_drops=uniq_drops,
        )
    # --- autokorekta krytyczna (profile płynności: ambient/minimal/…) ---
    cc = (d or {}).get("critical_correct") if isinstance(d, dict) else None
    if not cc and isinstance(director, dict):
        cc = director.get("critical_correct")
    if isinstance(cc, dict) and cc.get("on"):
        from . import critical_correct as CC
        CC.apply_critical_correct(proj, cc, rng=random.Random(seed + 707))
    # --- wewnętrzny recenzent / dyskryminator zakresów i parametrów (bez raportu) ---
    # tryb symbolic = bez renderu; audio = miks w pamięci + self-listen (bez wav/mp3)
    try:
        from . import musicality_reviewer as MR
        from . import user_rules as _URmr
        mr_cfg = None
        try:
            mr_cfg = (_URmr.get() or {}).get("musicality")
        except Exception:
            mr_cfg = None
        if mr_cfg is None and isinstance(d, dict):
            mr_cfg = d.get("musicality")
        if mr_cfg is None:
            mr_cfg = proj.get("musicality")
        MR.review_and_apply(proj, cfg=mr_cfg, rng=random.Random(seed + 909))
    except Exception:
        pass
    UR.finalize(proj)                                     # mowa → grupy bezwzględnie → strażnik norm gatunku (po wszystkich krokach)
    sanitize_notes(proj)
    return proj


def reroll_track(proj, tname, new_seed=None, sound=False):
    """Przelosowuje wzór jednej ścieżki (harmonia/sekcje zostają). Szanuje lock_notes / lock_sound."""
    cfg = STYLES[proj["style"]]
    proj["seed"] = int(new_seed if new_seed is not None else random.randrange(1000000))
    c = Ctx(proj, cfg); tr = track_of(proj, tname)
    if not tr.get("lock_notes"):
        GEN[tr["type"]](c, tr)
        mutate_track(proj, cfg, tr, random.Random(f"{proj['seed']}-mut-{tname}"))
        from . import user_rules as _UR
        _UR.enforce_track(proj, tr)
    if sound:
        randomize_sound(proj, tr, random.Random(proj["seed"] + 1))
    if proj.get("uniq") and not tr.get("lock_notes"):
        from . import uniq as UNIQ
        UNIQ.apply_track(proj, tr, strength=float(proj.get("uniq_strength") or 0.6),
                         rng=random.Random(proj["seed"] + 56))
    if tr["type"] == "wobble" and cfg["wob"] == "riddim":
        sub = first_of_type(proj, "sub")
        if sub:
            GEN["sub"](c, sub)
    sanitize_notes(proj)
    return proj


def add_instance(proj, ttype):
    """Dodaje kolejną instancję wtyczki do projektu (losowe brzmienie + wzór + linki ducking)."""
    tr = new_track(unique_name(proj, ttype), ttype)
    proj["tracks"].append(tr); proj["tracks"] = _order_tracks(proj["tracks"])
    c = Ctx(proj, STYLES[proj["style"]])
    randomize_sound(proj, tr, random.Random(f"{proj['seed']}-snd-{tr['name']}"))
    GEN[ttype](c, tr)
    mutate_track(proj, STYLES[proj["style"]], tr, random.Random(f"{proj['seed']}-mut-{tr['name']}"))
    if ttype in DUCK and first_of_type(proj, "kick"):
        proj["links"].append(duck_link(tr, proj["style"]))
    return tr


def remove_track(proj, name):
    proj["tracks"] = [t for t in proj["tracks"] if t["name"] != name]
    proj["links"] = [l for l in proj["links"] if l["dst"] != name]

# --- instrumenty użytkownika (karta „Modelowanie CLAP”): dopisanie zatwierdzonych typów do tabel tego modułu
from . import userinst as _userinst  # noqa: E402
_userinst.apply_module("generator")
