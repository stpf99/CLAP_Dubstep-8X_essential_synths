"""tv_gui.py — podkarta „TV 8-bit (M3U)” w zakładce Live: playlista M3U (URL / plik), lista kanałów z logo,
odtwarzanie przez silnik tv.TvStream z filtrem retro pixel 8-bit (palety NES / Game Boy / PICO-8 / C64 / CGA / terminal),
częściowo reaktywnym na dźwięk (piksel pulsuje z basem) oraz przycisk nasłuchu → SZABLON TYMCZASOWY (bez zapisu do config.txt).
RTMP bierze URL i klucz z podkarty „RTMP + wideo” (jedno wspólne nadawanie).

Pre-analiza stylu kanału: 🎼 analizuje ~30 s audio kanału pełnym analizatorem Studia (listen.py) → raport
(styl/BPM/tonacja/energia…). Opcja „▶ Start Live: graj muzykę z tej pre-analizy” sprawia, że Start Live w Live
aplikuje ten raport jako preset Generatora (NOWY strumień muzyki w stylu kanału), a źródło dźwięku TV przełącza
się na ten strumień — obraz 8-bit reaguje na generowaną muzykę i to ją nadaje (RTMP/odsłuch) zamiast kanału."""
from __future__ import annotations

import os
import threading

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import tv as TV

LOGO_CACHE: dict = {}          # url → QIcon (pamięć sesji)


class TvBridge(QtCore.QObject):
    ev = QtCore.pyqtSignal(str, object)


class TvPanel(W.QWidget):
    """Panel podkarty. Rodzic = LiveTab (dostęp do conf, pól RTMP i statusu okna głównego)."""

    def __init__(self, tab):
        super().__init__()
        self.tab = tab
        self.channels: list[dict] = []
        self.current: dict | None = None          # wybrany kanał (dict z parse_m3u)
        self.stream: TV.TvStream | None = None
        self._last_file = ""
        self._last_style: dict | None = None       # ostatni raport pre-analizy stylu (przeżywa Stop kanału)
        self.bridge = TvBridge(); self.bridge.ev.connect(self._on_ev)
        self._logo_gen = 0
        self._pv_last = -1
        v = W.QVBoxLayout(self)

        # ---------------- playlista
        pg = W.QGroupBox("Playlista M3U (TVHeadend / IPTV)")
        pr = W.QHBoxLayout(pg)
        self.src_url = W.QLineEdit(); self.src_url.setPlaceholderText("URL playlisty M3U, np. http://192.168.1.242:9981/playlists/…/channels.m3u")
        self.b_load_url = W.QPushButton("Wczytaj z URL"); self.b_load_file = W.QPushButton("Z pliku…"); self.b_reload = W.QPushButton("Odśwież")
        for b, fn in ((self.b_load_url, self.load_url), (self.b_load_file, self.load_file), (self.b_reload, self.reload_playlist)):
            b.clicked.connect(fn); pr.addWidget(b)
        pr.insertWidget(1, self.src_url, 1)
        self.pl_status = W.QLabel("brak playlisty")
        pr.addWidget(self.pl_status)
        v.addWidget(pg)

        # ---------------- lista kanałów + panel efektu
        split = W.QHBoxLayout()
        left = W.QVBoxLayout()
        self.search = W.QLineEdit(); self.search.setPlaceholderText("Szukaj kanału…"); self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._fill_list)
        left.addWidget(self.search)
        self.tree = W.QTreeWidget()
        self.tree.setHeaderLabels(["#", "Kanał", "Grupa"])
        self.tree.setRootIsDecorated(False)
        self.tree.setUniformRowHeights(True)
        self.tree.setIconSize(QtCore.QSize(24, 24))
        self.tree.setColumnWidth(0, 42); self.tree.setColumnWidth(1, 260)
        self.tree.itemDoubleClicked.connect(self._on_dbl)
        self.tree.itemSelectionChanged.connect(self._on_sel)
        left.addWidget(self.tree, 1)
        self.ch_info = W.QLabel("Wybierz kanał i kliknij „▶ Odtwarzaj 8-bit” (dwuklik = start).")
        self.ch_info.setWordWrap(True)
        left.addWidget(self.ch_info)
        split.addLayout(left, 6)

        # --- prawa kolumna: filtr + wyjścia
        right = W.QVBoxLayout()
        fg = W.QGroupBox("Filtr retro pixel (8-bit) — zmiany działają na żywo")
        fgr = W.QGridLayout(fg)
        self.tpl = W.QComboBox()
        for tid, (title, _pal) in TV.PALETTES_TV.items():
            self.tpl.addItem(title, tid)
        self.tpl.insertItem(0, "auto — szablon z nasłuchu / NES", "auto")
        self.tpl.setToolTip("Paleta 8-bit. „auto” = szablon dobierany nasłuchem (przycisk 🎧) albo NES do momentu nasłuchu.\n"
                            "Szablon z nasłuchu jest TYMCZASOWY — działa do Stop i nie zapisuje się do config.txt.")
        self.pixel = W.QSpinBox(); self.pixel.setRange(2, 24); self.pixel.setSuffix(" px")
        self.pixel.setToolTip("Boczny rozmiar „wielkiego piksela”. Mniejszy = więcej detalu, większy = bardziej retro.")
        self.react = W.QSlider(Qt.Orientation.Horizontal); self.react.setRange(0, 100); self.react.setValue(40)
        self.react_lbl = W.QLabel("40 %")
        self.react.valueChanged.connect(lambda val: self.react_lbl.setText(f"{val} %"))
        self.react.setToolTip("Reaktywność na muzykę: na uderzeniach basu bloki pikseli chwilowo rosną (puls obrazu).")
        self.dither = W.QCheckBox("Dithering Bayer"); self.dither.setChecked(True)
        self.dither.setToolTip("Klasyczny wzorek ditheringowy 8-bit — płynne przejścia na małej palecie.")
        self.scan = W.QCheckBox("Scanlines (CRT)"); self.scan.setChecked(False)
        fgr.addWidget(W.QLabel("Paleta:"), 0, 0); fgr.addWidget(self.tpl, 0, 1, 1, 3)
        fgr.addWidget(W.QLabel("Piksel:"), 1, 0); fgr.addWidget(self.pixel, 1, 1)
        fgr.addWidget(W.QLabel("Reakcja na bas:"), 2, 0); fgr.addWidget(self.react, 2, 1); fgr.addWidget(self.react_lbl, 2, 2)
        fgr.addWidget(self.dither, 3, 0, 1, 2); fgr.addWidget(self.scan, 3, 2, 1, 2)
        right.addWidget(fg)

        og = W.QGroupBox("Wyjście")
        ogr = W.QGridLayout(og)
        self.local_audio = W.QCheckBox("Graj lokalnie (odsłuch jak przy Live)")
        self.local_audio.setToolTip("Dźwięk kanału do głośników tym samym odtwarzaczem co Live (pw-cat/aplay…).")
        self.rtmp_on = W.QCheckBox("Nadawaj RTMP (URL i klucz z podkarty „RTMP + wideo”)")
        self.rtmp_on.setToolTip("Obraz 8-bit + dźwięk kanału idą na ten sam adres RTMP, co strumień Live.\n"
                                "Uwaga: nie nadawaj jednocześnie Live i TV na ten sam adres — serwer przyjmie tylko jedno.")
        self.vbr = W.QSpinBox(); self.vbr.setRange(200, 20000); self.vbr.setSingleStep(100); self.vbr.setSuffix(" kbps")
        self.preview = W.QComboBox(); self.preview.addItem("podgląd wyłączony", "off")
        self.preview.addItem("w oknie programu (niżej)", "gui"); self.preview.addItem("osobne okno (ffplay)", "window")
        self.size = W.QComboBox(); self.size.setEditable(True)
        self.size.addItems(["426x240", "640x360", "854x480"])
        self.fps = W.QComboBox(); self.fps.addItems(["15", "20", "25", "30"])
        self.ausrc = W.QComboBox()
        self.ausrc.addItem("dźwięk kanału (jak dotąd)", "channel")
        self.ausrc.addItem("muzyka Live — nowy strumień dla TV 8-bit", "live")
        self.ausrc.setToolTip("Skąd TV 8-bit bierze dźwięk do reaktywności i nadawania:\n"
                              "• dźwięk kanału — zachowanie dotychczasowe;\n"
                              "• muzyka Live — po „▶ Start Live” obraz reaguje na muzykę generowaną przez studio\n"
                              "  (styl z pre-analizy kanału), a RTMP/odsłuch TV nadają ten nowy strumień zamiast kanału.\n"
                              "Uwaga: wyłącz „Graj też lokalnie” w Live albo „Graj lokalnie” tutaj — inaczej usłyszysz podwójnie.")
        ogr.addWidget(self.local_audio, 0, 0, 1, 3); ogr.addWidget(self.rtmp_on, 1, 0, 1, 3)
        ogr.addWidget(W.QLabel("Bitrate wideo:"), 2, 0); ogr.addWidget(self.vbr, 2, 1)
        ogr.addWidget(W.QLabel("Podgląd:"), 3, 0); ogr.addWidget(self.preview, 3, 1)
        ogr.addWidget(W.QLabel("Rozmiar:"), 4, 0); ogr.addWidget(self.size, 4, 1)
        ogr.addWidget(W.QLabel("Klatki/s:"), 5, 0); ogr.addWidget(self.fps, 5, 1)
        ogr.addWidget(W.QLabel("Źródło dźwięku:"), 6, 0); ogr.addWidget(self.ausrc, 6, 1, 1, 2)
        right.addWidget(og)

        sg = W.QGroupBox("Pre-analiza stylu kanału → muzyka Live")
        sgr = W.QVBoxLayout(sg)
        self.b_style = W.QPushButton("🎼 Analizuj styl kanału (30 s) → preset dla Start Live")
        self.b_style.setToolTip("Słucha ~30 s dźwięku KANAŁU i liczy pełny raport stylu Studia (listen.py): BPM, tonacja/skala,\n"
                                "wagi wszystkich stylów, energia/gęstość, instrumenty. Wynik tymczasowy (do Stop programu/kanału).\n"
                                "Zaznacz poniższą opcję, a „▶ Start Live” wygeneruje muzykę w tym stylu jako nowy strumień dla TV 8-bit.")
        self.style_lbl = W.QLabel("—"); self.style_lbl.setWordWrap(True)
        self.style_live = W.QCheckBox("▶ Start Live: graj muzykę z tej pre-analizy (nowy strumień dla TV 8-bit)")
        self.style_live.setToolTip("Po naciśnięciu „▶ Start Live” w Live: preset z pre-analizy jest nakładany na Generator\n"
                                   "(styl, BPM, tonacja, energia, instrumenty…), silnik gra muzykę w stylu kanału,\n"
                                   "a TV 8-bit automatycznie przełącza źródło dźwięku na ten nowy strumień.")
        sgr.addWidget(self.b_style); sgr.addWidget(self.style_lbl); sgr.addWidget(self.style_live)
        right.addWidget(sg)

        cr = W.QHBoxLayout()
        self.b_play = W.QPushButton("▶ Odtwarzaj 8-bit"); self.b_play.clicked.connect(self.play)
        self.b_stop = W.QPushButton("■ Stop"); self.b_stop.clicked.connect(self.stop)
        self.b_listen = W.QPushButton("🎧 Nasłuchuj 8 s → szablon tymczasowy"); self.b_listen.clicked.connect(self.listen)
        self.b_listen.setToolTip("Słucha dźwięku kanału przez 8 s i dobiera paletę/piksel/reakcję do charakteru audycji.\n"
                                 "Wynik jest tymczasowy: działa do Stop („na potrzeby tymczasowe”), config.txt bez zmian.")
        cr.addWidget(self.b_play); cr.addWidget(self.b_stop); cr.addWidget(self.b_listen, 1)
        right.addLayout(cr)
        self.status = W.QLabel("TV: zatrzymana")
        self.status.setWordWrap(True)
        right.addWidget(self.status)
        self.pv_label = W.QLabel("podgląd wyłączony")
        self.pv_label.setAlignment(Qt.AlignmentFlag.AlignCenter); self.pv_label.setMinimumSize(320, 180)
        self.pv_label.setSizePolicy(W.QSizePolicy.Policy.Expanding, W.QSizePolicy.Policy.Expanding)
        self.pv_label.setStyleSheet("background:#0f1115;color:#6b7280;border:1px solid #1f2937")
        right.addWidget(self.pv_label, 1)
        split.addLayout(right, 5)
        v.addLayout(split, 1)

        # sygnały → na żywo do silnika (każda kontrolka swoim sygnałem)
        self.tpl.currentIndexChanged.connect(self._live_param)
        self.pixel.valueChanged.connect(self._live_param)
        self.react.valueChanged.connect(self._live_param)
        self.dither.toggled.connect(self._live_param); self.scan.toggled.connect(self._live_param)
        self.local_audio.toggled.connect(self._outputs); self.rtmp_on.toggled.connect(self._outputs)
        self.preview.currentIndexChanged.connect(self._preview_changed)
        self.ausrc.currentIndexChanged.connect(self._audio_src_changed)
        self.b_style.clicked.connect(self.style_listen)
        self.b_stop.setEnabled(False); self.b_listen.setEnabled(False); self.b_style.setEnabled(False)

        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(500)
        self.pv_timer = QtCore.QTimer(self); self.pv_timer.timeout.connect(self._preview_tick); self.pv_timer.start(80)

    # ---------------------------------------------------------------- playlista
    def load_url(self):
        self._fetch_job(self.src_url.text().strip())

    def load_file(self):
        path, _ = W.QFileDialog.getOpenFileName(self, "Playlista M3U", str(self.src_url.text().strip() or os.path.expanduser("~")),
                                                "Playlista M3U (*.m3u *.m3u8);;Wszystkie pliki (*)")
        if not path:
            return
        self._last_file = path
        self.src_url.setText(path)
        self._fetch_job(path)

    def reload_playlist(self):
        self._fetch_job(self.src_url.text().strip())

    def _fetch_job(self, src):
        """Pobranie/parsowanie playlisty w wątku demona (nie blokuje globalnego workera okna), wynik przez bridge."""
        src = str(src).strip()
        if not src:
            self.pl_status.setText("podaj URL playlisty albo wybierz plik"); return
        self.pl_status.setText("pobieram…")

        def work():
            try:
                return (True, TV.parse_m3u(TV.fetch_m3u(src)), "")
            except Exception as e:
                return (False, None, str(e))

        threading.Thread(target=lambda: self.bridge.ev.emit("playlist", work()), daemon=True).start()

    def _apply_channels(self, chans, note=""):
        self.channels = chans
        self._fill_list()
        self.pl_status.setText(f"{len(chans)} kanałów" + (f" · {note}" if note else ""))
        self.tab.main.status.setText(f"TV: wczytano playlistę — {len(chans)} kanałów")

    def _fill_list(self):
        q = self.search.text().strip().lower()
        self.tree.clear()
        for ch in self.channels:
            if q and q not in ch["name"].lower() and q not in ch["group"].lower():
                continue
            it = W.QTreeWidgetItem([str(ch["chno"]) if ch.get("chno") else "", ch["name"], ch.get("group", "")])
            it.setData(0, Qt.ItemDataRole.UserRole, ch)
            it.setToolTip(1, ch["url"])
            icon = LOGO_CACHE.get(ch.get("logo"))
            if icon:
                it.setIcon(1, icon)
            self.tree.addTopLevelItem(it)
        if self.current:
            self._mark_current()

    def _fetch_logos(self):
        """Loga w tle (wątki demony) — ikonki do listy; wyniki przez bridge."""
        gen = self._logo_gen + 1; self._logo_gen = gen
        for ch in self.channels[:120]:                    # rozsądny limit — listy bywają długie
            if ch.get("logo") in LOGO_CACHE:
                continue

            def work(c=ch):
                return c.get("logo"), TV.channel_logo(c)

            threading.Thread(target=lambda fn=work: self.bridge.ev.emit("logo", (*fn(), gen)), daemon=True).start()

    def _on_ev(self, kind, kw):
        if kind == "playlist":
            ok, res, err = kw
            if not ok:
                self.pl_status.setText(f"błąd: {err}")
                W.QMessageBox.critical(self, "TV 8-bit", f"Nie udało się wczytać playlisty:\n{err}")
                return
            self._apply_channels(res)
            self._fetch_logos()
        elif kind == "logo":
            url, data, gen = kw
            if gen != self._logo_gen or not data:
                return
            pm = QtGui.QPixmap()
            if pm.loadFromData(data):
                LOGO_CACHE[url] = QtGui.QIcon(pm)
                for i in range(self.tree.topLevelItemCount()):
                    it = self.tree.topLevelItem(i)
                    ch = it.data(0, Qt.ItemDataRole.UserRole)
                    if ch and ch.get("logo") == url:
                        it.setIcon(1, LOGO_CACHE[url])
        elif kind == "style":
            rep, err = kw
            if rep is None:
                self.style_lbl.setText(f"analiza nieudana: {err or 'brak wyniku'}")
                self.status.setText("Pre-analiza stylu nieudana — " + (err or "spróbuj ponownie."))
            else:
                self._last_style = rep
                self.style_lbl.setText(TV.style_label(rep) + "  — gotowe do „▶ Start Live”")
                self.status.setText("Pre-analiza stylu gotowa: " + TV.style_label(rep))

    # ---------------------------------------------------------------- kanał
    def _on_sel(self):
        items = self.tree.selectedItems()
        if items:
            self.current = items[0].data(0, Qt.ItemDataRole.UserRole)
            self._mark_current()

    def _on_dbl(self, item, _col):
        self.current = item.data(0, Qt.ItemDataRole.UserRole)
        self.play()

    def _mark_current(self):
        if not self.current:
            return
        c = self.current
        extra = ""
        if self.stream is not None and self.stream.run:
            extra = "  ·  ● odtwarzanie"
        self.ch_info.setText(f"Zaznaczony: {c['name']}{extra}\n{c['url']}")

    # ---------------------------------------------------------------- sterowanie
    def _params(self):
        return dict(template=self.tpl.currentData() or "auto", pixel=self.pixel.value(), react=self.react.value(),
                    dither=self.dither.isChecked(), scanlines=self.scan.isChecked(),
                    local_audio=self.local_audio.isChecked(), preview=self.preview.currentData() or "off",
                    audio_source=self.ausrc.currentData() or "channel")

    def _rtmp_cfg(self):
        tab = self.tab
        base = tab.conf["rtmp"]
        try:
            w, h = TV.parse_size(self.size.currentText(), (640, 360))
        except Exception:
            w, h = 640, 360
        return dict(base, enabled=self.rtmp_on.isChecked(), url=tab.rt_url.text().strip(), key=tab.rt_key.text().strip(),
                    v_bitrate=self.vbr.value(), width=w, height=h, fps=int(self.fps.currentText() or 25))

    def play(self):
        if not self.current:
            self.status.setText("Najpierw wybierz kanał z listy."); return
        if self.stream is not None and self.stream.run:
            self.stream.stop(); self.stream = None
        p = self._params()
        url = self.current["url"]
        self.stream = TV.TvStream(url, p, self._rtmp_cfg(), out_size=TV.parse_size(self.size.currentText(), (640, 360)),
                                  fps=int(self.fps.currentText() or 25), title=self.current["name"],
                                  log=lambda m: self.tab.main.status.setText("TV: " + m))
        self.stream.on_style = lambda rep, err: self.bridge.ev.emit("style", (rep, err))
        self.stream.start()
        if self.rtmp_on.isChecked() and self.tab.rt_on.isChecked() and self.tab.eng.running:
            self.status.setText("Uwaga: Live też nadaje na ten adres RTMP — włącz tylko jedno nadawanie naraz.")
        self._pv_last = -1
        self._sync_tap()
        self._mark_current()

    def stop(self):
        if self.stream is not None:
            self.stream.stop(); self.stream = None
        self._sync_tap()
        self.pv_label.clear(); self.pv_label.setText("podgląd wyłączony")
        self._pv_last = -1
        self.status.setText("TV: zatrzymana")
        self._mark_current()

    def listen(self):
        if self.stream is None or not self.stream.run:
            self.status.setText("Nasłuch działa podczas odtwarzania — najpierw ▶ Odtwarzaj 8-bit."); return
        self.stream.start_listen(8)
        self.status.setText("🎧 Słucham kanału (8 s)… po analizie ustawię szablon tymczasowo.")

    # ---------------------------------------------------------------- pre-analiza stylu → muzyka Live
    def style_listen(self):
        if self.stream is None or not self.stream.run:
            self.status.setText("Pre-analiza działa podczas odtwarzania — najpierw ▶ Odtwarzaj 8-bit."); return
        self.b_style.setEnabled(False)
        self.stream.start_style_listen(30)
        self.style_lbl.setText("słucham kanału i liczę pełną analizę stylu (30 s + kilka s liczenia)…")
        self.status.setText("🎼 Pre-analiza stylu kanału (30 s) — po analizie zaznacz opcję i naciśnij „▶ Start Live”.")

    def live_preset(self):
        """Preset muzyki z pre-analizy kanału dla „▶ Start Live” (None gdy opcja wyłączona albo brak analizy)."""
        if not self.style_live.isChecked() or self._last_style is None:
            return None
        try:
            return TV.style_preset(self._last_style)
        except Exception:
            return None

    def style_text(self):
        return TV.style_label(self._last_style) if self._last_style else ""

    def notify_live_started(self):
        """Start Live ruszył na muzyce z pre-analizy: TV 8-bit przełącza dźwięk/reaktywność na ten nowy strumień."""
        if self.stream is None or not self.stream.run:
            return
        if self.ausrc.currentData() != "live":
            i = self.ausrc.findData("live")
            if i >= 0:
                self.ausrc.setCurrentIndex(i)          # wyzwala _audio_src_changed → silnik ustawia źródło + tap

    def _audio_src_changed(self, *_):
        if self.stream is not None:
            self.stream.set_audio_source(self.ausrc.currentData() or "channel")
        self._sync_tap()

    def _push_pcm(self, b):
        """Tap: kawałek PCM miksowanej muzyki Live → TV (reaktywność + RTMP/odsłuch, gdy źródło = live)."""
        s = self.stream
        if s is not None:
            s.external_audio(b)

    def _sync_tap(self):
        """Podłącz/odłącz tap pod wyjściem silnika Live (tylko gdy TV gra i źródło dźwięku = muzyka Live)."""
        out = getattr(self.tab.eng, "out", None)
        if out is None:
            return
        want = self.stream is not None and self.stream.run and (self.ausrc.currentData() == "live")
        if want:
            out.add_tap(self._push_pcm)
        else:
            out.remove_tap(self._push_pcm)

    def _live_param(self, *_):
        """Zmiana parametrów filtra na żywo (params to ten sam dict, który czyta RetroFilter)."""
        if self.stream is None:
            return
        self.stream.params.update(template=self.tpl.currentData() or "auto", pixel=self.pixel.value(),
                                  react=self.react.value(), dither=self.dither.isChecked(), scanlines=self.scan.isChecked())
        if self.stream.params.get("temp") and self.tpl.currentData() != "auto":
            self.stream.params.pop("temp", None); self.stream.temp_label = ""     # ręczny wybór anuluje szablon tymczasowy

    def _outputs(self, *_):
        if self.stream is None:
            return
        self.stream.set_outputs(self._rtmp_cfg(), self.local_audio.isChecked())

    def _preview_changed(self, *_):
        if self.stream is not None:
            self.stream.params["preview"] = self.preview.currentData() or "off"
            self.stream._sync_preview()

    # ---------------------------------------------------------------- ticki
    def _tick(self):
        s = self.stream
        self.b_stop.setEnabled(s is not None)
        self.b_listen.setEnabled(s is not None and s.run)
        self.b_style.setEnabled(s is not None and s.run and s.style_until <= 0.0 and not s.style_busy)
        if s is None or not s.run:
            return
        self.status.setText(s.status)

    def _preview_tick(self):
        if (self.preview.currentData() or "off") != "gui":
            if self._pv_last != -2:
                self._pv_last = -2
                self.pv_label.clear()
                self.pv_label.setText("podgląd wyłączony" if self.preview.currentData() == "off" else "podgląd w osobnym oknie (ffplay)")
            return
        s = self.stream
        if s is None or not s.run:
            if self._pv_last != -3:
                self._pv_last = -3; self.pv_label.clear(); self.pv_label.setText("podgląd: wybierz kanał i ▶ Odtwarzaj 8-bit")
            return
        fr = s.latest_frame()
        if fr is None:
            return
        data, w, h, k = fr
        if k == self._pv_last:
            return
        self._pv_last = k
        img = QtGui.QImage(data, w, h, w * 3, QtGui.QImage.Format.Format_RGB888).copy()
        self.pv_label.setPixmap(QtGui.QPixmap.fromImage(img).scaled(
            self.pv_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.FastTransformation))

    # ---------------------------------------------------------------- config
    def apply_conf(self, conf):
        tv = conf["tv"]
        self._last_file = tv["playlist_file"]
        i = self.tpl.findData(tv["template"])
        self.tpl.setCurrentIndex(max(0, i))
        self.pixel.setValue(tv["pixel"]); self.react.setValue(tv["react"])
        self.dither.setChecked(tv["dither"]); self.scan.setChecked(tv["scanlines"])
        self.local_audio.setChecked(tv["local_audio"]); self.rtmp_on.setChecked(tv["rtmp"])
        self.vbr.setValue(tv["v_bitrate"])
        self.preview.setCurrentIndex(max(0, self.preview.findData(tv["preview"])))
        self.size.setCurrentText(f"{tv['width']}x{tv['height']}"); self.fps.setCurrentText(str(tv["fps"]))
        self.style_live.setChecked(bool(tv.get("style_for_live")))
        j = self.ausrc.findData(tv.get("audio_source") or "channel")
        self.ausrc.setCurrentIndex(max(0, j))
        if tv["playlist_url"] or tv["playlist_file"]:
            self.src_url.setText(tv["playlist_url"] or tv["playlist_file"])
            QtCore.QTimer.singleShot(300, self.reload_playlist)

    def collect_conf(self):
        try:
            w, h = TV.parse_size(self.size.currentText(), (640, 360))
        except Exception:
            w, h = 640, 360
        return {("tv", "playlist_url"): self.src_url.text().strip(),
                ("tv", "playlist_file"): self._last_file,
                ("tv", "template"): self.tpl.currentData() or "auto",
                ("tv", "pixel"): self.pixel.value(), ("tv", "react"): self.react.value(),
                ("tv", "dither"): "yes" if self.dither.isChecked() else "no",
                ("tv", "scanlines"): "yes" if self.scan.isChecked() else "no",
                ("tv", "local_audio"): "yes" if self.local_audio.isChecked() else "no",
                ("tv", "rtmp"): "yes" if self.rtmp_on.isChecked() else "no",
                ("tv", "v_bitrate"): self.vbr.value(), ("tv", "preview"): self.preview.currentData() or "off",
                ("tv", "size"): f"{w}x{h}", ("tv", "fps"): int(self.fps.currentText() or 25),
                ("tv", "style_for_live"): "yes" if self.style_live.isChecked() else "no",
                ("tv", "audio_source"): self.ausrc.currentData() or "channel"}

    def shutdown(self):
        self.timer.stop(); self.pv_timer.stop()
        if self.stream is not None:
            self.stream.stop(); self.stream = None
        self._sync_tap()
