## TV 8-bit: pre-analiza stylu kanału → muzyka Start Live jako nowy strumień dla TV

Rozbudowa podkarty „TV 8-bit (M3U)" (`tv.py`, `tv_gui.py`, `live.py`, `live_gui.py`, szczegóły: `RETRO_TV.md`):

- **Pre-analiza stylu kanału (🎼)**: `TvStream.start_style_listen(30)` zbiera ~30 s PCM **kanału** i liczy pełny
  raport stylu Studia (`listen.analyze_stream`: BPM, tonacja/skala, wagi wszystkich stylów, energia/gęstość,
  instrumenty) w wątku tła; wynik przez `on_style` → bridge → panel (etykieta + status). Tymczasowy (pamięć).
- **„▶ Start Live" gra muzykę z pre-analizy**: opcja w TV 8-bit (`[tv] style_for_live`); `LiveTab.start()`
  przed startem silnika nakłada preset z raportu (`listen.preset_data` → `apply_preset` grupy
  generator/board/live/director/flags) — Live generuje **nowy strumień muzyki w stylu zbadanego kanału**.
- **TV 8-bit reaguje i nadaje ten nowy strumień**: `TvStream.set_audio_source("channel"|"live")` +
  `external_audio(PCM)`; nowy tap `Output.add_tap/remove_tap` (live.py) oddaje każdy kawałek miksowanego
  audio Live → analiza reaktywności + RTMP + odsłuch TV biorą muzykę zamiast dźwięku kanału
  (`[tv] audio_source`, przełącznik ręczny w „Wyjście"; Start Live przełącza automatycznie).
- Testy: pre-analiza na syntetycznym sygnale 128 BPM (raport → preset z pełnymi grupami), external_audio
  tylko przy źródle „live" (i po stop), tap Output (dodawanie/usuwanie/odporność na wyjątki), nowe klucze
  `[tv]` w config (defaulty dla starych configów, zapis).

## TV 8-bit (M3U) — retro pixel filter na strumieniu IPTV/TVHeadend

Nowa podkarta **„TV 8-bit (M3U)"** w zakładce **Live** (`tv_gui.py` + silnik `tv.py`, opis: `RETRO_TV.md`):

- **Playlista M3U** przez URL (TVHeadend / IPTV) albo upload pliku; lista kanałów z logo, numerami i grupami,
  szukajka, ostatnia lista wraca po starcie (`[tv] playlist_url/playlist_file`). Parser: `#EXTINF` z `tvg-logo` /
  `tvg-id` / `tvg-chno` / `group-title` + zwykłe listy.
- **Filtr retro pixel 8-bit** na oryginalnym wideo kanału: pikselizacja (2–24 px), dithering Bayera 8×8,
  kwantyzacja do palety (NES 54, Game Boy DMG, PICO-8, C64, CGA, terminal amber/zielony), scanlines, OSD
  z nazwą kanału (czcionka 5×7, polskie znaki składane). Zmiany parametrów działają na żywo.
- **Częściowa reaktywność na muzykę**: rozmiar bloku pulsuje z uderzeniami basu (punch z `Analyzer` — ten sam
  analizator PCM co w `vid/livefx.py`), siła 0–100 %.
- **Wyjścia**: odsłuch lokalny (checkbox, ten sam `StreamPlayer` co Live), RTMP (wspólne URL/klucz z podkarty
  „RTMP + wideo", osobny bitrate; pilnuje, by Live i TV nie nadawały naraz na ten sam adres), podgląd
  wyłączony / w oknie programu / ffplay. Rozmiar 426×240…854×480, 15–30 fps.
- **Nasłuch 8 s → szablon tymczasowy** (`listen_template`): muzyka z basem → NES, jasna → PICO-8, mowa →
  terminal amber, ambient → C64, uniwersalnie → Game Boy. Wynik tylko w pamięci (do Stop), nie zapisuje
  się do config.txt — zgodnie z „tylko na potrzeby tymczasowe".
- Dekoder: jedno ffmpeg z dwiema rurami wyjściowymi (rgb24 + s16le 48 kHz); `pass_fds` z prawdziwymi numerami
  fd, opcje HTTP (`-reconnect`, `-user_agent`) tylko dla http/https, `-rw_timeout` na zrywanie połączeń,
  reconnect RTMP jak w zwykłym nadawaniu. Auto-skip klatek gdy filtr nie nadąża.
- `[tv]` w config.txt + `config.py` (SECTIONS_ORDER z „tv"); stary config.txt bez sekcji dostaje defaulty.
- Testy: `tests/test_tv.py` — M3U (atrybuty i zwykłe listy), palety/kwantyzacja, puls reaktywności, nasłuch,
  `[tv]` config (clampy, zapis), end-to-end `TvStream` na pliku testowym ffmpeg (klatki 8-bit + probe).

## Render wideo 2,3× szybszy bez zmiany obrazu (1280×720@30, pełna jakość)

Profil (cProfile + czas każdej wtyczki) pokazał nadmiarową pracę na pełnej klatce 11 MB, a nie wolny algorytm. Naprawione (różnica obrazu ≤ 1/255, `tests/test_render_fast.py`):

- **Alokacje**: kilkadziesiąt tymczasowych tablic na klatkę było oddawanych i zdobywanych od systemu (page fault). `vid/__init__.py` ustawia `mallopt` (próg mmap/trim); wyłączenie: `DS_NO_MALLOC_TUNE=1`. ≈ −18% czasu.
- **Bloom** (w każdym szablonie): średnia bloków 4×4 po osiach nieciągłych (21 ms) → sumy ciągłych pasów (6 ms), bez `np.repeat`×2 i bez kopii klatki, pomijany przy ciemnej klatce.
- **Glow**: gauss rozdzielny (2 małe `exp` 1-D zamiast `exp` na całym polu (2r+1)²).
- **Tło**: gradient w cache, brak zbędnego zerowania bufora przed pokojem, który i tak zamalowuje klatkę.
- **Zoom kamery**: kadrowanie do próbkowanego okna + `take` zamiast podwójnego fancy-indexu. **Mgła** sceny (`room_stage`): `sin(A+B)` rozdzielone na funkcje 1-D. **Wiązki**: 4 pasy z ciasnym oknem kolumn i indeks płaski. **Scanlines/Mirror**: w miejscu, bez kopii.
- **Konwersja do uint8**: bufor roboczy używany ponownie. **`export_mp4`**: render i zapis do ffmpeg w osobnych wątkach, klatka jako widok pamięci (bez `.tobytes()`).

Pomiar (1 rdzeń, 1280×720): średnio 127 → 55 ms/klatkę; kraftwerk_robots 160→67, single_track_mv 111→40, live_show 166→83, led_wall 99→46, tunnel_trip 98→40.

## Szablony MIDI w RTMP/Live działają jak reszta listy + paleta = tylko kolorystyka

Skarga: w „Wideo / RTMP” i w Live → „RTMP + wideo” nie dało się realnie użyć szablonów typu MIDI, a „Paleta” zachowywała się inaczej niż w scenach reaktywnych. Dwie przyczyny:

- **Paleta była nadpisywana przez plan utworu.** `vid.plan.apply_to_projvideo` zawsze wpisywał do szablonu paletę z planu, więc wybór w polu „Paleta” działał tylko w scenach `rx:*`. Teraz wybrana paleta wygrywa w każdym szablonie `tpl:*`; „auto” = paleta z planu utworu (tak samo jak w silniku reaktywnym). Lista palet jest jedna (`auto` + 6 z `PALETTES`) i nie zawiera żadnych dubli scen reaktywnych.
- **Live bez RTMP (sam podgląd) po cichu zamieniał szablon MIDI na scenę reaktywną**, a silnik szablonowy (`AvSink`) w ogóle nie miał podglądu. `AvSink` ma teraz tryb bez sieci (`NullStreamer`), `latest_frame()` i okno ffplay, więc podgląd „w oknie programu” / „osobne okno” pokazuje dokładnie wybrany szablon; `Output._sync_av` nie wymusza już `engine = reactive`.
- Testy: `tests/test_looks.py` (paleta jako kolorystyka dla wszystkich szablonów, jedna lista palet), `tests/test_local_preview.py` (podgląd szablonu MIDI bez RTMP, scena reaktywna nadal przez `LiveAV`).

## Wspólna grupa szablonów (okno główne ↔ Live)

- Jeden katalog wyglądów `vid/looks.py`: `tpl:<szablon>` (silnik MIDI) i `rx:<scena>` (silnik reaktywny) + wspólne palety. Obie zakładki wypełniają combo z tego samego miejsca i synchronizują wybór (`LiveTab.link_main`).
- Live: jedno pole „Szablon” zamiast „Wizualizacja” + „Scena”; palety działają także dla szablonów MIDI; `[video] template = …` w `config.txt`.
- Okno główne: nowe pole „Paleta”; Render MP4 / Eksport AV / RTMP obsługują też wygląd `rx:*` (`render_reactive_video`, `stream_reactive`).
- CLI: `video templates` pokazuje wspólny katalog; `--template` przyjmuje stare id oraz `tpl:`/`rx:`.

## Podgląd lokalny wideo + diagnostyka RTMP

- **Podgląd lokalny** nie wymaga serwera RTMP ani sieci: `[video] preview = gui|window` (zakładka „RTMP + wideo”, `live --preview`, „Tylko podgląd” w głównym oknie). Silnik wideo działa wtedy bez enkodera (`NullStreamer`).
- **Dlaczego `rtmp://localhost/video` nie startował**: ffmpeg jest klientem RTMP, a na `localhost:1935` nic nie nasłuchiwało (`Connection refused`). Powód (brak serwera / nieznany host / timeout / URL bez nazwy strumienia) jest teraz pokazany w statusie i logu.
- **Poprawka**: `RtmpStreamer.stop()` zawieszał się na `stdin.close()`, gdy ffmpeg jeszcze się łączył (np. niedostępny serwer).

# RTMP obok Icecast2 + lekkie wideo na żywo reagujące na dźwięk (z automatycznym doborem jakości)

RTMP jest teraz pełnoprawnym wyjściem Live/Endless: **do wyboru obok Icecast2, można włączyć oba naraz** (zakładka „RTMP + wideo” obok „Icecast2 / config.txt”, albo `[rtmp]` i `[video]` w `config.txt`).
Generator działa jak dotąd — track po tracku. Po wygenerowaniu tracka, w czasie rzeczywistym, pod audio które właśnie idzie na antenę, liczone jest lekkie wideo i nadawane razem z nim jako jeden strumień AV.

- **Nowy moduł `vid/livefx.py`**: analiza dźwięku z nadawanego PCM (widmo 40 pasm, głośność, „punch” stopy/basu; AGC — wygląd nie zależy od głośności utworu) + sceny rysowane samym numpy w małej rozdzielczości
  (ffmpeg skaluje do rozmiaru streamu). Sceny: **morph** (agenci z `wolumencja.py`: blob → gwiazda, bez hybrydyzacji, ochrona mniejszości i zimnych barw — tu każdy agent „słucha” swojego pasma widma,
  stopa pulsuje rozmiarem i rodzi nowych, wysokie tony zaostrzają kształt, populacja ewoluuje przez cały stream), **ring** (pierścień widma), **tunnel**, **bars**, **scope**. `scene = auto` zmienia scenę wg sekcji utworu
  (build → tunel, drop → morph/pierścień, przerwy → spokojniej), paleta wg stylu.
- **Automatyczny dobór jakości (`AutoTune`)**: co sekundę patrzy na czas renderu, zajętość CPU całego komputera (/proc/stat), wolny RAM, zaległość i gubienie klatek, i po drabince 7 poziomów
  (rozdzielczość renderu ÷1…÷4, co którą klatkę liczyć, efekty) schodzi od razu tyle, ile trzeba (wg przewidywanego kosztu), a wraca po 20 s spokoju — z blokadą poziomu, który się nie sprawdził.
  Gdy generator liczy kolejny track, próg CPU jest o 10 pkt ostrzejszy i powrót w górę jest wstrzymany. Audio nigdy nie czeka na wideo (osobny wątek; gdy wideo nie nadąża — powtarza klatkę).
- **Lekkie kodowanie**: x264 `ultrafast` + `zerolatency`, bez B-klatek, 1 ref, GOP 2 s, 2 wątki, niski priorytet (`nice`), domyślnie 854x480@25, 1500 kbps; render jest 2x mniejszy niż stream (skaluje ffmpeg).
  Kodek można zmienić na sprzętowy (`v_codec = h264_nvenc|h264_qsv|h264_vaapi|h264_v4l2m2m`).
- **Samo RTMP działa**: gdy Icecast jest wyłączony, a `local_playback = no`, silnik nie wymaga odtwarzacza lokalnego, pilnuje tempa i nadaje ciszę w przerwach (wcześniej wyłączony Icecast zawsze włączał odsłuch lokalny).
  Zmiana URL/klucza/rozmiaru/jakości w trakcie nadawania restartuje tylko sink wideo.
- **CLI**: `./ds-studio live --rtmp [--rtmp-url URL --rtmp-key KLUCZ] [--no-local]`, to samo dla `air` (pliki z preroll też dostają wideo); `./ds-studio video preview --audio PLIK --out podglad.mp4 [--scene morph --quality balanced --width 854 --height 480]`
  renderuje ten sam silnik offline — do strojenia wyglądu i pomiaru kosztu (wypisuje ms/klatkę).
- Dawne wideo z szablonu teledysku (zdarzenia MIDI) zostaje jako `engine = template` ([video] / lista „Wizualizacja”).
- Testy: `tests/test_live_av.py` (27) — analiza, ewolucja, sceny na wszystkich poziomach, regulator, LiveAV z atrapą streamera, Output (samo RTMP, oba wyjścia, restart sinka), config, koder.
  Sprawdzone też na żywo: Output → LiveAV → ffmpeg → lokalny serwer RTMP (`ffmpeg -listen 1`): H.264 854x480@25 + AAC, A/V zgodne co do 10 ms; pod obciążeniem CPU regulator zszedł z poziomu 3 na 6 bez dziur w audio.

# Reguły użytkownika: mowa (4 poziomy), własne grupy wtyczek, tryb „bezwzględnie"

Nowy moduł `user_rules.py` + panel **Reguły użytkownika** w Generatorze (ten sam stan dla Generatora, Live, CLI i trybu bez GUI — plik `user_rules.json`: `$DS_USER_RULES`, obok `ds-studio` albo `~/DubstepStudio/`).

- **Bez syntezy mowy** (checkbox) i **Poziom mowy** (Wcale · Min · Średnio · Max = jak przewiduje generator). Grupa mowy = `speak`, `vox`, `growl`.
  Wcale = grupa pomijana w całości — także gdy dołożyłby ją aranżer, zamiana instrumentów, wielogłos stylu albo tekst Speak. Min = 1 ścieżka, gain ×0,55; Średnio = do 2 ścieżek, gain ×0,8;
  przy Min/Średnio zostają ścieżki wg priorytetu growl → vox → speak. Z drzewa instrumentów znikają zaznaczenia grupy (🔒 zostają).
- **Grupy wtyczek…** — przenosisz wtyczki do swoich grup (perkusja / bas / lead / pad / FX / akustyczne). Od razu zmienia to: losowanie smart, reżysera, aranżera, role i drzewo instrumentów.
- **Grupy bezwzględnie nadrzędne** (checkbox) — PO całej generacji (role, aranżer, niuanse, zamiany…) ścieżka typu przeniesionego do bass/lead/pad jest składana do rejestru swojej grupy
  (mediana oktawami + zawinięcie skrajnych nut), dostaje retune barwy, a zamiany ról sekcji jej nie cofają. Działa też po „losuj wzór nut" ścieżki.
- Zmienne środowiskowe: `DS_VOICE_LEVEL=0..3`, `DS_GROUPS_ABSOLUTE=0/1` (np. dla `./ds-studio live` na serwerze).
- Przy domyślnych regułach (poziom 3, brak grup) wynik generatora jest identyczny co do nuty, gainu i parametru jak wcześniej (45 projektów porównanych z poprzednią wersją).
- Testy: `python3 -m unittest tests.test_user_rules -v` (8). Wtyczki bez zmian — przebudowa `make` niepotrzebna.

**Zakładka „Normalizacja / Dynamics" (profile zawsze stosowane).** Profil limitera / normalizera 3-pasmowego (tryb, preset, siła, krzywa, detektor) wybierasz raz: domyślny, per grupa (perkusja / bas / lead / pad / FX / akustyczne — wg Twoich grup) albo per typ wtyczki.
Priorytet: typ > grupa > domyślny. Z zaznaczonym „Stosuj profile zawsze" profil jest nakładany w każdym renderze Studio (Generator, Live, auto-remix, biblioteka, MP3, tryb bez GUI) i wchodzi do klucza cache,
więc nie zależy od ustawień ani trybu losowania. Panele Dynamics na ścieżkach są wtedy nieaktywne (podpis „NADPISANE profilem"). Zapis: `user_rules.json` (klucz `dyn`). Wtyczki w Bitwigu mają własny stan — profil dotyczy renderu w Studio.

Pomiar „norm" (bez zmian w kodzie): niezmienniki gatunku (stopa/werbel w dropie) trzymają się przy wszystkich opcjach; rozjazdy w checkerze pochodzą z fillów przy predict < 1 (świadome „stop"),
z zamiany werbel↔clap reżysera i z humanizacji niuansów (hit ~0,03 beatu przed taktem). Głośność miksu między losowymi projektami: rozrzut RMS ≈ 3,3 dB, w obrębie utworu p90–p10 do ~16 dB (intro/break vs drop).

---

# Style podstawowe: nieprzewidywalność w granicach gatunku („Zmienność stylu")

Skarga: podstawowe style (nie albumy) były zbyt przewidywalne. Przyczyna: większość miała jeden wzór stopy, stały werbel i hat, 1–5 wzorów basu, a wybór zapadał raz na sekcję — po dwóch utworach było wiadomo, co zagra bit. Zamiast losować wszystko (co niszczy gatunek), dodałem **gramatykę gatunku** (`style_variants.py`, 30 stylów):

- **Niezmienniki** — nigdy nie łamane: four-on-the-floor (EDM, techno, house, trance, psytrance), werbel na 4 i 12 (DnB, drumstep, electro, techno…), half-time na 8 (dubstep, riddim, trap, brostep…), stopa na 1 tam, gdzie gatunek tego wymaga.
- **Dozwolone warianty**: dodatkowe wzory stopy (dla stylów bez four-on-the-floor), alternatywne układy werbla (Experimental, Raw Synthesis), tryby hatu per sekcja (np. brostep 16 ↔ 8, techno offbeat ↔ 16, trap ↔ 8), dodatkowe wzory basu i growlu, progresje, komping, podziały LFO oraz tempo z zakresu gatunku (tylko gdy BPM nie jest podany ręcznie).
- **Embellishmenty** na końcach fraz (co 2 / 4 / 8 taktów), tylko w miejscach, gdzie gatunek je dopuszcza: pickupy stopy, ghost-snare, dodatkowe nuty hatu. W taktach z fillem ustępują planowi fillów (nic nie gra w ciszy „stop").
- Wzór stopy w dropie wybierany jest teraz co 8 taktów, nie raz na 32.
- **Nowy parametr `variety` / suwak „Zmienność stylu"** (Generator, domyślnie 50 %; zapisuje się w presetach i projekcie). **0 % = dokładnie dawne zachowanie** (sprawdzone: 180 porównań 30 stylów × 3 ziarna × 2 wartości predict, 0 różnic nut). Losowania wzorów mają własne strumienie zależne od (styl, variety, seed), więc reroll jednej ścieżki nie zmienia „osobowości" projektu.
- Hybrydy używają gramatyki składnika dominującego (z pominięciem tego, co kłóci się z ich rytmem lub biblioteką basu); albumy bez zmian.
- Live (tryb losowy): zmienność rośnie ze złożonością (easy 0,45–0,60 … chaos 0,75–0,95); wartość z Generatora jest dolną granicą.

Pomiar (24 projekty na styl, drop): różne wzory stopy — DnB 11 → 41 (przy 100 %: 53), Brostep 14 → 36, Drumstep 10 → 35, Trap 12 → 28; różne układy werbla w Drumstep 2 → 13, DnB 8 → 25; różne wzory basu w Brostep 5 → 9, Riddim 4 → 7. Niezmienniki: 0 naruszeń w 1 400+ projektach.
Dodatkowo: naprawiony błąd z oryginału w `collect_preset` — zmienna pętli `key` nadpisywała tonację, więc preset zapisywał w polu tonacji tekst (np. `health_mode`), a jego wczytanie rzucało ValueError.
Testy: `python3 -m unittest tests.test_style_variants -v` (13).

---

# Live (losowanie): jaśniejszy nastrój, groove i porządek warstw

Skarga: w trybie Live → losowanie dobór ścieżek i instrumentów był melancholijny i bez rytmu, a wyższe tryby (energetyczny, intensywny) zagmatwane. Przyczyny siedziały w planerze `live.py`, nie w samym generatorze:

- **Skale.** Losowanie znało tylko minor / frygijską / harmoniczną molową (100 % wyników). Teraz `_pick_scale()` waży skale wg nastroju i ostrości stylu: dorycka i miksolidyjska są pełnoprawne, dur i lidyjska wchodzą częściej przy jaśniejszym nastroju i łagodniejszym stylu (frygijska i harmoniczna — głównie przy ostrych stylach).
- **Nastrój.** Easy listening miał nastrój od −0,6 do −0,15, czyli włączał „mrocznego” reżysera (ponure skale i progresje, ciemne leady). Wszystkie tryby mają teraz nastrój lekko dodatni; nowy suwak **Jasność nastroju** (−0,5…+0,5) przesuwa go w obie strony.
- **Epoka.** Easy listening / chill dostawały epokę „minimal 70s” (6 ścieżek, gęstość ×0,55 — prawie bez perkusji i pulsu). Teraz analog 80s / digital 90s.
- **Rytm (checkbox Groove, domyślnie włączony).** Włącza „Rytmy taneczne melodii” (siła 0,45–0,90 rosnąca z intensywnością), dokłada 1–2 perkusjonalia (shaker, rim, clap, conga, cowbell, openhat, ride) i podnosi **Przewidywalność perkusji** (0,60–0,92), żeby bit był regularny. Ustawienia Generatora są dolną granicą — losowanie ich nie obniża.
- **Instrumenty.** Dodatkowy instrument akustyczny losowany jest z przewagą handpanu / tongue / marimby / vibes / dzwonka (theremin i flet Pana rzadziej); rzadziej dochodzą pady, drony, chóry, smyczki i organy.
- **Porządek warstw (suwak Porządek warstw, domyślnie 0,70; 0 = jak dawniej).** Limit leadów i długich warstw spoza rdzenia stylu (rdzeń nigdy nie jest ruszany), arpeggiator rzadszy zamiast częstszy na wysokiej intensywności, od 0,5 bez zamian ról instrumentów w trakcie utworu (dawniej reżyser dostawał je zawsze). Profile intensywny/energetyczny mają niższe pułapy niuansów i „uniq”, spektakl „vivid” zamiast „anthem” i epokę modern 10s zamiast „maximal now” (maksimum zostaje w trybie Chaos).
- Nowe pokrętła zapisują się w presetach (grupa Live) i działają tylko w trybie losowym; tryb „styl z Generatora” bez zmian.

Pomiar na tych samych ziarnach (25 projektów na tryb, takty dropów): tryb intensywny — melodyczne ścieżki grające naraz 4,6 → 1,9, nut melodycznych na takt 74 → 21; easy listening — nut perkusji na takt 12,5 → 22,4, balanced 22,9 → 27,4. Skale spoza molowych: 0 % → 60–75 %.
Testy: `python3 -m unittest tests.test_live_mood -v` (11). Wymaga przebudowy tylko GUI (bez `make` — wtyczki bez zmian).

---

# Rytmy taneczne melodii („kroki stylu → ekspresja pod vibe")

Opcjonalne (Generator: pole **Rytmy taneczne melodii** + suwak siły 0–100 %, domyślnie wyłączone; `generate(dance=True, dance_strength=0.6)`; działa też w Live i w presetach). Moduł `dance_rhythm.py`, dwa etapy w tej kolejności:

1. **Kroki (klimat, liczone raz na projekt, zamrożone w `proj["climate"]["dance"]`).** Siatka wag 16 kroków (albo 2 takty — clave) z tego, co styl już gra w perkusji (pule stopy, werbel, ghost, tryb hatu),
   zmieszana z nazwanymi krokami tanecznymi dobranymi do stylu: offbeat house, pulse techno, trance gate, 3-3-2 / tresillo, son clave 3-2, dembow, 2-step DnB, half-time, shuffle, bossa, funk 16.
   Hybrydy („Techno 60% + DnB 40%") mieszają kroki składników wg procentów; style artystów i eksperymentalne biorą kroki z własnej perkusji.
2. **Ekspresja (vibe).** Z siatki + rodziny klimatu (hard / dark / bright / organic / acid / space), mood, energii, gęstości i przewidywalności perkusji liczone są: akcenty głośności, długość nut (staccato ↔ legato),
   synkopy (słabe nuty przesuwane na najbliższy mocny krok o ≤ 2/16, albo zostawiane), antycypacje (pchnięcie mocnej doby o 1/16), cichy ghost (ta sama wysokość co poprzednia nuta), pauzy, lekki laid-back.

**Tam gdzie ma sens:** tylko rytmiczne partie melodyczne (pluck, stab, piano, epiano, clav, flet, handpan, marimba, wibrafon, acid, hoover, screech…), nie pady / drony / sustained / basy / mowa;
sekcje: drop 100 %, intro / outro 70 %, break 50 %, build bez zmian; takty z długimi nutami (mediana ≥ 2 ćwierćnuty) bez zmian; ścieżki akordowe (jednoczesne nuty) pomijane;
brak perkusji w projekcie = brak zmian. Pauzy najwyżej ~25 % nut taktu, nigdy nie zmienia wysokości (poza ghostami), nie dodaje nakładań ani duplikatów onsetu. Raport: `proj["dance"]`.
Testy: `python3 -m unittest tests.test_dance_rhythm -v` (5).

---

# Reguły perkusji: narastanie, fille i „przewidywalność"

Dotąd każdy build narastał tak samo (werbel: 2 → 4 → 8 → 16 uderzeń, cztery równe stopnie), hat grał stałe ósemki, a fille przychodziły zawsze co 8 taktów w jednej postaci.
Teraz jest jedno pokrętło **Przewidywalność perkusji** (Generator, suwak 0–100 %, domyślnie 60 %; `generate(predict=…)`, `proj["predict"]`; w Live bierze się z Generatora).

- **100 %** = dawne reguły, wynik identyczny co do nuty (sprawdzone na 30 projektach × wszystkie ścieżki). Stare projekty bez klucza `predict` też działają jak dawniej.
- **niżej** = nowy moduł `drum_rules.py`. Reguła dobierana jest do suwaka (im niższy, tym bardziej „zaskakujące" reguły), z wagami stylu (trap → triole i rolki 1/32, techno/trance → równe stopnie, jazz/ride → prawie bez fillów, DnB → backbeat + plateau).

**Narastanie (build)** — 8 reguł: `classic` (dawna), `halving` (ćwierć→ósemki→16→32), `dosed` (te same poziomy, ale dozowane nierówno: długo wolno albo szybki finisz),
`plateau` (pomija poziomy, długo trzyma jeden), `smooth` (accelerando z krzywej, granice poziomów na ćwierćnutach), `triplet` (triole), `late` (długo tylko podkład, potem szybki finisz),
`backbeat` (4/12 prawie do końca, rolka dopiero na ostatnich taktach). Do tego: oddech co 4 takty, losowe wypadnięcia słabych uderzeń, krzywa głośności (liniowa / szybki start / późny skok),
miejsce końca rolki w ostatnim takcie (8 / 12 / 14 / 16), **hat** (ósemki / offbeat gdy werbel gęsty / 16 na ostatnich 2 taktach / cisza w ostatnim takcie / późne wejście),
**stopa** (jak dawniej / ćwierćnuty z narastaniem / pół-takt / cisza w ostatnim takcie), **tomy** w ostatnim takcie (6 uderzeń / w górę / triola / 4 uderzenia) — werbel kończy rolkę tam, gdzie zaczynają tomy.

**Fille w dropie** — 12 rodzajów (ghost, drag, rolka hatu 1/32, werbel 1/16 w ostatniej ćwiartce / połowie taktu, werbel 1/32, synkopa, tomy w dół / w górę / triolowe,
dialog werbel→tomy, „stop" = cichną stopa i hat, crash wpada w następnym takcie). Poziomy: co 4 takty (mały), co 8 (średni), koniec sekcji (duży, zawsze).
Wysoka przewidywalność = fraza wraca tym samym fillem; niska = fille wypadają także poza regularnymi miejscami. Crash: start dropu zawsze, dalsze akcenty co 8/16 taktów z prawdopodobieństwem.

**Strażnicy (przy każdej wartości suwaka):** odstępy w buildzie nigdy nie rosną, głośność narasta, siatka 1/16–1/32 albo triole, fill tylko z instrumentów obecnych w projekcie,
wspólny plan na takt (werbel / tomy / hat / stopa / crash nie robią tego samego jednocześnie). Wynik deterministyczny (seed + sekcja; przy `section_motif_reuse` — typ sekcji).
Podgląd wylosowanych reguł: `proj["drum_plan"]` (build → reguła, takt → fill).

Testy: `python3 -m unittest tests.test_drum_rules -v` (7). Znane ograniczenie: ride / shaker / rim / clap nie reagują na „stop" (grają dalej).

---

# Style specjalne (artysta / album) zamiast mieszanek gatunków

`build_pack.py` składał presety artystów jako hybrydy gatunków („House 50% + Acid Techno 32% + …”) — czyli uśredniał gotowe wzory. Teraz każdy z 33 presetów
ma **własny styl** w `dubstep_studio/special_styles.py`: własne wzory stopy / werbla / ghost-nut / hatu, swing, tryb suba, **własne wzory basu**
(WOB pod kluczem `sp:<nazwa>`), progresje, skale, szablon formy, paletę instrumentów (core/extras/głosy) i **nastawy brzmień per instrument** (SOUND_STYLE),
a także epokę, motyw mowy, klasę ostrości, ducking i scenę. Preset wskazuje ten styl (`style == style_base`).

- Style są rejestrowane jako czyste (`generator.py`, po `DUCK_BASE`): działają w presetach, Live, remiksie i jako składnik hybryd („Kraftwerk - Autobahn (1974) 60% + Techno 40%”).
  Nie trafiają do `ST.ORDER` — pole szachowe i losowanie Live są bez zmian; w liście stylów Generatora są na końcu. Wyłączenie: `DS_NO_SPECIAL=1`.
- Nowy zapis wzorów tekstem: `"0r2 3r1 6o1"` (krok + znacznik r/o/f/t/b/p/u + długość) i brzmień: `"Decay: 170 250; Drive: .3 .55; Waveform = 2 3"`.
- `era_profiles.BIAS_EXEMPT`: dla stylu specjalnego bias epoki nie rusza parametrów, które styl ma jawnie w SOUND_STYLE. Bez tego bias (w ułamku skali parametru)
  wypychał ok. 15 % wartości poza okna — np. `Glide` 0–10 ms kończył jako ok. 150 ms. Style wbudowane i hybrydy działają jak dawniej.
- `build_pack.py` waliduje każdy styl: czysty (nie hybryda), era „auto” = zamierzona, limit ścieżek epoki, typy w `core.TYPES`, **istnienie każdego parametru we wtyczce**
  (nieznany byłby po cichu pomijany), poprawność wzorów, determinizm `generate()`, stopa i wobble w dropach faktycznie z pul stylu. Błąd = nic się nie zapisuje.
- Zachowane do porównania: `presets_artists_hybrid.json` (poprzedni pakiet hybryd).
- Znane ograniczenie: parametry mowy `Intonation` / `Letter Pitch Range` / `Formant Shift` są losowo nadpisywane przez efekt theremin na głosie (generator.py), więc
  styl ustawia tylko `Dialect`.

Testy: `python3 -m unittest tests.test_special_styles -v` (9). Przebudowa paczki: `python3 build_pack.py`.

---

# Dynamics w GUI: limiter / normalizer 3-pasmowy z presetami

Zakładka **Ścieżki / parametry** → panel **Dynamics** na górze parametrów każdej ścieżki:
- **Tryb**: Wyłączony / Limiter 3-pasmowy / Normalizer 3-pasmowy. **Domyślnie włączony: Limiter 3-pasmowy.**
- **Preset**: Transparent, Bass Tight, Punchy, Loud, Bright Lead, Warm Pad, Sub Focus, **Less Bass** (domyślny: pasmo < ok. 150 Hz stale przycięte o ok. 5 dB + niższy sufit dołu; ściszane suwakiem Siła). Opis w podpowiedzi i pod listą.
- **Siła** 0–100%.
- **Zastosuj do wszystkich ścieżek** / **Wyłącz na wszystkich**.

To opcja instrumentu: działa w samej wtyczce (końcówka toru instrumentu), a nie w renderze/masteringu miksu. Parametry zapisują się w projekcie jak każde inne (`Dynamics`, `Dyn Preset`, `Dyn Amount`, ID 61–63), działają też w Bitwigu i w presetach.
Domyślne wartości siedzą w silniku (`PI` w `src/ds_engine.h`), więc dotyczą każdej nowej ścieżki i każdego projektu, który nie ma tych parametrów zapisanych jawnie — stare projekty zagrają z mniejszą ilością basu; żeby wrócić do poprzedniego brzmienia ustaw Tryb = Wyłączony („Wyłącz na wszystkich”).
Procesor nie liczy się w ciszy (po ogonie ostatniej nuty jest pomijany), więc domyślne włączenie prawie nie zwiększa czasu renderu.
Silnik: `src/ds_engine.h` (`DYN_PRE`, `dynProcess`), podział Linkwitz-Riley 4. rzędu, detektor sprzężony L/R, miękki sufit ok. −0,3 dBFS. Test: `tests/test_dynamics.py`. Po aktualizacji przebuduj wtyczki (`make`).

---

# Autolevels bez dodatkowego gainu

`autolevel_heuristic` (generator, Director, krytyczna autokorekta) i `autolevel` (pomiar RMS, przycisk Autolevels) nie podbijają już żadnej ścieżki powyżej 1.0 (`core.GAIN_MAX_AUTO`).
Wcześniej heurystyka sięgała 1.6, a pomiar RMS 1.8, więc ścieżki dostawały dodatkowy gain (np. kick 1.16, riser 1.27). Teraz proporcje między torami zostają, a całość jest skalowana tak, żeby najgłośniejszy tor miał 1.0.
Suwak Gain ścieżki nadal sięga 1.5 ręcznie; zapisane projekty się nie zmieniają.

---

# Autokorekta krytyczna (profile płynności)

Nowy tryb przy **Reżyserze**: checkbox **Autokorekta krytyczna** + profil (Auto / Ambient / Minimal / Soft / Aggressive) + suwak intensywności + przycisk **Zastosuj na projekcie**.

- Trigger: preset (profil) **lub** suwak **lub** oba; działa przy generacji (gdy włączone) i osobno na gotowym projekcie.
- Zakres: **cały utwór** — instrumenty (avoid→prefer), zakresy nut na sztywno, okna parametrów, automacje wielu parametrów w czasie sekcji (Cutoff, Wave Morph, Glide, LFO>Cutoff…), forma (dłuższe intro/break, łagodniejsze dropy), autolevel.
- Cel: płynniejsze brzmienia (długie Attack/Release, glide, wolne LFO, krzywe automacji), nie tylko pozycje nut + jeden oscylator.
- Profile `ambient` / `minimal` / `soft` / `aggressive` w `critical_correct.py`; mapowanie stylów (Space Electronica → ambient, Brostep → aggressive, …).
- Szanuje `lock_notes` / `lock_sound` / `locked_params`.
- Raport w `proj["critical_correct_report"]` (stats + log); status GUI po generacji / zastosowaniu.

Pliki: `dubstep_studio/critical_correct.py` (nowy), `director.py` (DEFAULT + normalize), `generator.py` (post-pass), `gui.py` (UI + `apply_critical_correct_now`).

---

# Karta „Modelowanie CLAP” (instrumenty użytkownika bez wychodzenia z GUI)

Nowa zakładka **Modelowanie CLAP**: projektowanie własnych wtyczek na silniku DS (te same 61 parametrów co wbudowane typy):
- szablon z dowolnego istniejącego typu, tabela parametrów (— / jawny / ukryty, wartość, zakres losowania generatora), flagi one-shot/retrigger, częstotliwość odniesienia,
  banki modalne (Handpan/Tongue/Vibes/Marimba/Bell lub **własny** — do 6 składowych: stosunek f, amplituda, zanik);
- klasyfikacja dla generatora: grupa, wzór nut (`GEN`), rola, ducking, gain, agresja, pasma, **dodanie do `extras` wybranych stylów** (hybrydy dziedziczą) i do `prefer` epok;
- **Odsłuch**: kompiluje tymczasową wtyczkę (`build/preview/`, bez zmian w bibliotece), renderuje frazę testową i odtwarza ją;
- **Zatwierdź do biblioteki**: zapis `user_instruments/<id>.json` → generowanie `src/user/<id>.inc`, `src/ds_user_types.inc`, `user_types.mk` (dopisuje nazwę do `NAMES` w Makefile) →
  `make` kompiluje **tylko nową wtyczkę** (typy użytkownika są dopisywane na końcu, indeksy dotychczasowych się nie zmieniają) + paczkę DubstepKit.clap →
  typ jest rejestrowany w aplikacji bez restartu (core.TYPES/GROUPS, tabele generatora, dyrektora, niuansów, aranżera, instrument_replace, epok, Live; drzewo instrumentów i listy wyboru w GUI);
- przy starcie wszystkie zatwierdzone specyfikacje są rozpoznawane automatycznie (typ jest dostępny, gdy znaleziono jego .clap); „Skanuj ponownie” rozpoznaje nowe pliki .json w locie;
- edycja zatwierdzonego instrumentu = „Zatwierdź zmiany” (przebudowa wtyczki); „Wyłącz / włącz” ukrywa typ, zostawiając definicję C++ (stałe indeksy).

Pliki: `dubstep_studio/userinst.py` (backend), `dubstep_studio/modeling_gui.py` (karta), `host/dstypes.cpp` (zrzut tabeli parametrów/typów z silnika → JSON),
hooki w `ds_engine.h` (`DS_USER_TYPES_INC`, `DS_USER_MODAL_INC`), `Makefile` (`-include user_types.mk`, cel `build/dstypes`), testy: `tests/test_userinst.py`.

---

# Rozszerzona baza instrumentów CLAP (v6): 32 → 51 typów

Nowe wtyczki (ten sam silnik `ds_engine.h`, nowe `TypeDef` + 3 nowe banki modalne; `make` buduje `DS-<Nazwa>.clap`, wszystkie opcjonalne):
- klawisze/organy: **Organ, E-Piano, Harpsichord**; dęte/smyczki/głosy: **Flute, Brass, Cello, Choir**; perkusyjne melodyczne (modalne): **Vibes, Marimba, Bell**
- synth/bas: **Hoover, 808 Bass, Upright, Drone**; perkusja: **Open Hat, Ride, Cowbell, Conga**; fx: **Glitch**

Integracja ze stylami i hybrydami:
- `styles.py` / `generator.py`: charakterystyczne typy trafiają do `extras` stylów (Jazz: epiano/upright/ride/vibes, Baroque: harpsichord/organ/flute/cello,
  Trance: choir/bell, Electro/Trap: 808, Techno: hoover/openhat, Space/Berlin: drone/choir/bell…); hybrydy dziedziczą sumę `extras` składników.
- `era_profiles.py`: nowe typy w listach `prefer` epok; hybryda dostaje epokę o największym limicie ścieżek spośród składników (wcześniej tylko pierwszego).
- `generator.py`: wzory (`GEN`), kolejność, role (`NATIVE_ROLE`), ducking, zakresy brzmień (`SOUND`), agresja/pasma (`INST_AGG`, `INST_BANDS`), grupy losowania; nowe generatory perkusyjne `gen_openhat/ride/perc`.
- `core.py` (typy, grupy, gain, poziomy), `director.py`, `niuanse.py`, `arranger.py`, `instrument_replace.py`, `live.py` (Live losuje też nowe typy).

---

# Live: „Losuj nowe hybrydy”

Nowa opcja w zakładce Live (tryb losowy; `config.txt`: `[live] new_hybrids = yes`; w presetach `live.new_hybrids`). Każda aranżacja dostaje świeżą hybrydę
2–3 stylów z dowolnych grup (losowe proporcje, min. 12 %, bez powtórek z ostatnich 20). Składnikiem zostaje styl wylosowany kaskadą nastroju/pory dnia.
Ma pierwszeństwo przed „Mutacjami” i polem szachowym; nie działa przy zablokowanym stylu. W logu Live hybryda oznaczona ★.

---

# Aranżer (barwy · extras · kreator · nowe ad hoc · efekty WYSIWYG)

Nowy moduł `dubstep_studio/arranger.py`, włączany: GUI (Generator → „Aranżer”), `config.txt` (`arranger = yes`, `arranger_*`),
CLI (`gen --arranger [--arranger-amount X --arranger-adhoc X --arranger-persist]`), Live (bierze flagę z Generatora/configu).
Przy aranżacji sam nakłada barwy z banku, dokłada extras FX wg struktury (riser w buildzie, uderzenie na dropie, tekstury w
break/intro/outro), korzysta z `scenario_creator.auto_choice`, a gdy trzeba tworzy nowe barwy/extras ad hoc (zapis w projekcie
`proj["adhoc"]`, opcjonalnie `~/DubstepStudio/adhoc_bank.json`, nadpisanie: `DS_ADHOC_BANK`). Efekty ustala figurami WYSIWYG
(`proj["geometry_doc"]`, widoczne i edytowalne w zakładce „Edytor WYSIWYG”). Ten sam seed → ten sam projekt.

## Poprawki znalezione przy okazji
- `extras_fx`: 15 przepisów miało nazwy parametrów nieistniejące we wtyczce (host je pomijał) — `fix_params` + `PARAM_ALIASES`.
  Cztery (`fx_room_tone`, `fx_static`, `fx_wind`, `fx_whisper_pad`) nie mają odpowiednika `Noise` na pad/zap.
- `geometry_editor`: intensywność oceniana na y=0.5 i jedną liczbą na tor (przycisk „Auto” nic nie zmieniał) — teraz na wysokości
  figury, jako przebieg w czasie (velocity + automatyzacja Cutoff/Drive/Resonance); ponowne „Zastosuj” nie kumuluje (`geo_vel0`).
- `timbre_bank.spawn_timbre`: `Fine` zapisywany na typach, które go nie mają → rozstrojenie przez `Tune`.
- `timbre_bank.apply_timbre_to_track`: ADSR tylko dla parametrów, które wtyczka ma.
- `list_timbres` / `weighted_extras_for_style` pomijają wpisy ad hoc (losowania wbudowane nie zależą od historii).

Testy: `python3 -m unittest tests.test_arranger tests.test_fixes -v` (35, w tym fuzz 60 projektów).

# DS Dubstep Studio AV — poprawki 1–9 z przeglądu kodu (już naniesione)

To jest pełna paczka projektu z poprawkami naniesionymi. Zmienione pliki: `dubstep_studio/{arp_engine,core,director,eco,generator,gui,live,niuanse,remix}.py`;
nowy plik: `tests/test_fixes.py`. Pozostałe pliki, w tym `build/` (kod C++ nie był ruszany), są identyczne jak w wersji wyjściowej;
pominięto tylko katalogi `__pycache__` (Python odtworzy je przy pierwszym uruchomieniu).

Testy (czysta logika działa bez hosta; reszta wymaga `make`, test GUI także PyQt6):

    python3 -m unittest tests.test_fixes -v

## Co zmieniono

1. **gui.py `_preview_extra_or_timbre`** — `render_stems` zwraca słownik tablic numpy, a funkcja traktowała je jak ścieżki plików
   (`ValueError`, podsłuch extras/barw nigdy nie grał). Teraz: `mix_stems` → `ds_studio_sample.wav` → `player.play`.
2. **Klucze MIDI poza 0..127** — przyczyna: `niuanse._snap` przy przejściu B→C przesuwał nutę o −11 zamiast +1 (trzy kroki = −36,
   stąd nuta −12 i `ValueError` w `write_midi`). Poprawiony `_snap`; dodatkowo `core.fold_key/clamp_vel/sanitize_notes`
   (zawijanie o oktawy, velocity 1..127) w `_write_job`, `write_midi` oraz na końcu `generate`, `reroll_track`, `remix`.
3. **arp_engine.structural_inject** — `hash(nazwa)` zastąpione `zlib.crc32`; ten sam seed daje teraz ten sam projekt
   niezależnie od `PYTHONHASHSEED` (przed: 25 z 90 projektów różniło się między uruchomieniami).
4. **live.plan_next** — `randint(2, 1)` przy dokładnie jednym dostępnym extra → `min(len(ex), …)`.
5. **director.apply_roles / _retune** — ścieżki z `lock_notes` nie biorą udziału w zamianach ról, a `lock_sound` / `locked_params["Cutoff"]`
   blokuje retuning barwy (tak jak w `generator.apply_role_swaps`). Usunięte puste wywołania `_put(…, bn_[:0], …)`.
6. **live._gen_extras_from_base** — pakiet złożoności może tylko podnieść siłę niuansów/uniq ustawioną w Generatorze (`max`),
   nie nadpisuje jej; `autolevels` bez klucza w base domyślnie `False` (jak w config.txt i `generate`).
7. **eco.py** — `_next_no`: `flock` + zapis atomowy (8 procesów × 300 wywołań: 70 → 2400 unikalnych numerów);
   `_encode`: brak osieroconych `.part` i czytelny błąd przy zerwanym potoku do ffmpeg; `preroll`: jedna instancja na katalog
   (drugi proces kończy z wynikiem 0) i sprzątanie starych `.part`. W katalogu preroll pojawiają się pliki `.counter.lock` i `.preroll.lock`.
8. **core.cleanup_stale_work** — usuwa wyłącznie katalogi o nazwie z `mkdtemp` (`dsr<pid>_xxxxxxxx`, `dsr_xxxxxxxx`);
   cudze, np. `dsrender-build`, zostają. Dowiązania symboliczne są pomijane.
9. **core.render_stems** — po renderze cache przycinany do kluczy bieżącego stanu (przed: +~100 MB na każdą edycję przy 144 taktach);
   niezmienione ścieżki nadal nie są renderowane ponownie.

## Zmiany zachowania, o których warto wiedzieć

- Projekty z włączonymi niuansami lub arp-inject będą dla tego samego seeda inne niż przed poprawką (naprawione źródła błędów); zapisane projekty bez zmian.
- `--preset` (Live/ECO) nie włącza już domyślnie autolevels — preset ich nie przechowuje (pozycja 10 z przeglądu, poza tą paczką).
- Po edycji ścieżki powrót do jej wcześniejszego stanu (undo) renderuje ją ponownie.

## Weryfikacja

16 testów: na kodzie oryginalnym 15 pada, po poprawkach wszystkie przechodzą. Fuzzing 150 + 240 projektów (30 stylów, losowe opcje):
0 wyjątków, 0 naruszeń zakresu MIDI. Podsłuch GUI sprawdzony na prawdziwym `MainWindow` (offscreen). Przebieg `preroll` end-to-end (2 pliki WAV) działa.

## Poza tą paczką (pozycje 10–17 z przeglądu)

Kompletność presetów / `GenOptions`, SIGHUP + `--preset`, utwardzenie config/Icecast, diagnostyka `Meta`, rozbicie `generate()`,
martwy kod w generator.py, `timeout` dla dsrender, aktualizacja README (32 wtyczki).
