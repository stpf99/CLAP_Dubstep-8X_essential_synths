# Retro TV 8-bit — dodatek do DS-Studio-7

Podkarta **„TV 8-bit (M3U)"** w zakładce **Live / Endless**: playlista M3U (TVHeadend / IPTV) → lista kanałów
z logo → wybrany kanał odtwarzany przez **filtr retro pixel 8-bit** (Nintendo-vibe), **częściowo reaktywny
na dźwięk** kanału. Silnik jest niezależny od Live — Live działa jak dotąd, to osobny nadajnik.

## Playlista (M3U / M3U8)

* **Wczytaj z URL** — np. `http://192.168.1.242:9981/playlists/id/88/channels.m3u` (TVHeadend) albo dowolny IPTV M3U.
* **Z pliku…** — upload listy z dysku (zostaje zapamiętany i wraca po starcie).
* **Odśwież** — pobiera listę ponownie; **Szukaj…** filtruje po nazwie i grupie.
* Parser rozumie `#EXTM3U`, `#EXTINF` z atrybutami `tvg-logo`, `tvg-id`, `tvg-chno`, `group-title`
  oraz zwykłe listy (same adresy). Logo pobierane w tle (ikony na liście).
* Ostatni URL / plik i wybór szablonu zapisuje `[tv]` w config.txt (przycisk „Zapisz config.txt").

## Odtwarzanie z filtrem 8-bit

Dwuklik na kanale (albo zaznacz + **▶ Odtwarzaj 8-bit**): ffmpeg dekoduje strumień (HTTP / HLS / TS)
na wideo w małym rozmiarze + audio 48 kHz; `RetroFilter` (numpy) liczy klatkę:

| Krok | Opis |
|------|------|
| Pikselizacja | średnia po blokach; boczny rozmiar „wielkiego piksela" 2–24 px |
| **Reakcja na bas** | na uderzeniach (punch z analizatora PCM) blok chwilowo rośnie — obraz pulsuje z muzyką, obraz zostaje czytelny; siła 0–100 % |
| Nasycenie/contr. | podbicie przed kwantyzacją (8-bit gry miały jędrne kolory) |
| Dithering | wzorek Bayera 8×8 przed kwantyzacją (wyłączalny) |
| Kwantyzacja | najbliższy kolor palety |
| Scanlines | co druga linia przyciemniona (CRT, opcjonalnie) |
| OSD | nazwa kanału pikselową czcionką u dołu (polskie znaki składane do ASCII) |

### Palety (szablony)

`auto` (nasłuch / do momentu nasłuchu NES), **NES** (54 kolory), **Game Boy DMG** (4 odcienie zieleni),
**PICO-8** (16), **Commodore 64** (16), **IBM CGA** (16), **Terminal amber**, **Terminal zielony**.
Zmiana palety / piksela / reakcji / ditheringu / scanlines działa **na żywo** podczas odtwarzania.

## Wyjścia

* **Graj lokalnie** — dźwięk kanału przez ten sam odtwarzacz co Live (pw-cat / paplay / aplay / mpv / ffplay).
* **Nadawaj RTMP** — obraz 8-bit + dźwięk kanału na URL i klucz z podkarty „RTMP + wideo" (jedno wspólne
  nadawanie; nie nadawaj Live i TV naraz na ten sam adres). Bitrate wideo do wyboru; ponawianie połączenia
  jak w zwykłym RTMP.
* **Podgląd** — wyłączony / w oknie programu / osobne okno ffplay (bez serwera RTMP i bez sieci).
  Rozmiar 426×240 / 640×360 / 854×480, klatki 15–30.

## 🎧 Nasłuch → SZABLON TYMCZASOWY

Przycisk **„Nasłuchuj 8 s"** słucha dźwięku kanału przez 8 s i dobiera szablon do charakteru audycji:

* mocny bas + wyraźny bit → **NES**, mniejszy piksel, reakcja 65 %,
* jasne rytmiczne brzmienie → **PICO-8**, reakcja 55 %,
* dominująca mowa (wiadomości/rozmowy) → **Terminal amber**, duży piksel, mała reakcja,
* spokój/ambient → **C64**,
* środek / uniwersalnie → **Game Boy**.

Wynik jest **tymczasowy** („na potrzeby tymczasowe"): działa do Stop, pokazywany w statusie jako
„szablon tymczasowy: …", **nie zapisuje się do config.txt**. Ręczny wybór palety z listy anuluje go od razu.

## 🎼 Pre-analiza stylu kanału → muzyka Live (nowy strumień dla TV 8-bit)

Przycisk **„Analizuj styl kanału (30 s)"** słucha ~30 s **dźwięku kanału** i liczy **pełny raport stylu Studia**
(ten sam analizator co zakładka „Nasłuch"): BPM, tonacja/skala, wagi WSZYSTKICH stylów, energia/gęstość,
propozycja instrumentów. Wynik pokazuje się pod przyciskiem i jest **tymczasowy** (pamięć sesji, bez config.txt).

Opcja **„▶ Start Live: graj muzykę z tej pre-analizy"** zmienia zachowanie przycisku **▶ Start Live** w Live:

1. raport z pre-analizy jest nakładany na Studio (styl/hybryda, BPM, tonacja, energia/gęstość, instrumenty,
   pole stylów, Reżyser — tak samo jak „Zastosuj" w Nasłuchu),
2. silnik Live generuje muzykę **w stylu zbadanego kanału** — to jest **nowy strumień**,
3. TV 8-bit (jeśli kanał gra) automatycznie przełącza **Źródło dźwięku** na ten nowy strumień:
   piksele reagują na generowaną muzykę, a RTMP/odsłuch TV nadają ją **zamiast** dźwięku kanału.

Efekt: kanał TVHeadend jako obraz retro 8-bit + muzyka generowana przez studio w stylu tej audycji.

* **Źródło dźwięku** w „Wyjście" przełącza to też ręcznie, w dowolnym momencie:
  `dźwięk kanału` (zachowanie dotychczasowe) ↔ `muzyka Live` (nowy strumień). Zapisywane w `[tv] audio_source`.
* PCM muzyki Live pochodzi z nowego tapu `Output.add_tap` (live.py) → `TvStream.external_audio`
  (reaktywność + RTMP + odsłuch TV); przy `audio_source = channel` zewnętrzne PCM jest ignorowane.
* Uwaga na podwójny odsłuch: gdy TV gra „muzykę Live", wyłącz „Graj też lokalnie" w Live **albo**
  „Graj lokalnie" w TV (ten sam dźwięk z dwóch odtwarzaczy = echo).
* Bez uruchomionego Live źródło „muzyka Live" daje ciszę do wyjść TV (obraz działa, piksele nie pulsują).
* `[tv] style_for_live` — zapamiętuje zaznaczenie opcji Start Live.

## Moduły

* `dubstep_studio/tv.py` — `parse_m3u` / `fetch_m3u`, palety `PALETTES_TV`, `RetroFilter`
  (pikselizacja + dithering + kwantyzacja + scanlines + OSD), `listen_template` (nasłuch 8 s),
  `build_style_report` / `style_preset` / `style_label` (pre-analiza stylu → preset Start Live),
  `TvStream` (dekodek ffmpeg na 2 rury → Analyzer → filtr → `RtmpStreamer` / odsłuch / podgląd;
  `set_audio_source` / `external_audio` / `start_style_listen`),
  `probe_channel` (ffprobe — szybki test kanału).
* `dubstep_studio/tv_gui.py` — panel podkarty (lista kanałów z logo, kontrolki, podgląd, nasłuch,
  pre-analiza stylu, źródło dźwięku + tap pod silnik Live).
* `dubstep_studio/live.py` — `Output.add_tap` / `remove_tap` (wyciek PCM miksowanej muzyki do TV).
* `dubstep_studio/vid/livefx.py` — współdzielony `Analyzer` PCM; `vid/host.py` — `RtmpStreamer`, `LocalPreview`.
* `[tv]` w config.txt (`dubstep_studio/config.py`).
* Testy: `tests/test_tv.py` (M3U, palety/kwantyzacja, reaktywność, nasłuch, pre-analiza stylu → preset,
  audio_source/external_audio, tap Output, config, end-to-end na pliku testowym).

## Wydajność

Filtr to kilka operacji numpy na małej siatce (klatka 320×180 przy px=6 → ~3200 bloków) — koszt pomijalny
wobec dekodera; gdy mimo to render nie nadąża, co druga klatka jest powtarzana (auto-skip). Loga listy
pobierane asynchronicznie, limit 120 pozycji na start.
