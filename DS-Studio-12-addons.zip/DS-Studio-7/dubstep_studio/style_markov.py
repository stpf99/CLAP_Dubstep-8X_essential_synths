"""style_markov.py — model n-gramowy (Markov) rytmu perkusji uczony z korpusu: Twoja biblioteka projektów albo pliki MIDI.

Dlaczego tak: przy 8 torach i małym korpusie model krokowy (kontekst = ostatnie `order` kroków 1/16 + pozycja w takcie)
uczy się „idiomu” (gdzie stopa, gdzie hat-owe ghost-noty) znacznie stabilniej niż sieć. Czysty numpy/stdlib; `mido` tylko do MIDI,
`miditok` tylko do eksportu tokenów pod własny model (tokens_for_training) — oba opcjonalne.

Zakres: role perkusyjne o stałym klawiszu (kick, snare, hat, clap, rim, openhat, ride, shaker, tom…). Basu/melodii NIE generuje.
Symbole kroku: 0 = cisza, 1 = cicha nuta (vel < 0,55·127), 2 = głośna. Velocity przy próbkowaniu: mediana z korpusu dla symbolu i roli.

CLI:  python3 -m dubstep_studio markov train --role hat [--library | --midi KATALOG] --out hat.json
      python3 -m dubstep_studio markov show hat.json
"""
from __future__ import annotations

import json
import random
from collections import defaultdict
from pathlib import Path

import numpy as np

from . import optional_deps as OD

STEPS = 16                       # kroków 1/16 na takt 4/4
GM = {"kick": (35, 36), "snare": (38, 40), "clap": (39,), "rim": (37,), "hat": (42, 44), "openhat": (46,), "ride": (51, 59),
      "tom": (41, 43, 45, 47, 48, 50), "crash": (49, 57), "shaker": (70,), "cowbell": (56,)}
DRUM_ROLES = tuple(GM)


def _sym(vel: float) -> int:
    return 2 if vel >= 0.55 * 127 else 1


def _bars_from_notes(notes, nbars: int) -> list[list[int]]:
    """Nuty [on_w_ćwierćnutach, dur, key, vel] → tablica taktów po 16 symboli (kwantyzacja do 1/16; zderzenia: głośniejszy wygrywa)."""
    bars = [[0] * STEPS for _ in range(nbars)]
    vels: list[float] = []
    for n in notes:
        st = int(round(float(n[0]) * 4))
        b, s = divmod(st, STEPS)
        if 0 <= b < nbars:
            sym = _sym(float(n[3])); vels.append(float(n[3]))
            bars[b][s] = max(bars[b][s], sym)
    return bars


def _train_sequences(seqs: list[list[int]], order: int) -> dict:
    cnt: dict[str, list[int]] = defaultdict(lambda: [0, 0, 0])
    for seq in seqs:
        pad = [0] * order + seq
        for i, sym in enumerate(seq):
            ctx = pad[i:i + order]
            cnt[f"{'.'.join(map(str, ctx))}|{i % STEPS}"][sym] += 1
    return cnt


def from_projects(projs: list[dict], role: str, order: int = 3) -> dict:
    """Uczy model roli z projektów Studia (tory danego typu; wyciszone pomijane)."""
    seqs, vels, keys = [], [], []
    for p in projs:
        nb = int(p.get("bars") or 0)
        for t in p.get("tracks") or []:
            if t.get("type") != role or t.get("mute") or not t.get("notes"):
                continue
            bars = _bars_from_notes(t["notes"], nb)
            seqs.append([s for b in bars for s in b])
            vels += [float(n[3]) for n in t["notes"]]
            keys += [int(n[2]) for n in t["notes"]]
    return _finish(role, order, seqs, vels, keys)


def _finish(role, order, seqs, vels, keys) -> dict:
    if not seqs:
        raise ValueError(f"brak nut roli „{role}” w korpusie")
    cnt = _train_sequences(seqs, order)
    soft = [v for v in vels if v < 0.55 * 127] or [60]; loud = [v for v in vels if v >= 0.55 * 127] or [100]
    return {"version": 1, "role": role, "order": order, "steps": STEPS, "counts": {k: v for k, v in cnt.items()},
            "vel": {"1": float(np.median(soft)), "2": float(np.median(loud))},
            "key": int(np.bincount(keys).argmax()) if keys else 36, "n_bars": int(sum(len(s) for s in seqs) // STEPS)}


def from_midi(paths: list[str | Path], role: str, order: int = 3) -> dict:
    """Uczy z plików MIDI (kanał perkusyjny GM — nuty przypisane do `role` wg tabeli GM; wymaga mido)."""
    mido = OD.load("mido")
    if mido is None:
        raise RuntimeError("from_midi wymaga pakietu mido (pip install mido)")
    seqs, vels, keys = [], [], []
    for pth in paths:
        try:
            mf = mido.MidiFile(str(pth))
        except Exception:
            continue
        tpb = mf.ticks_per_beat or 480
        notes = []
        for tr in mf.tracks:
            tick = 0
            for msg in tr:
                tick += msg.time
                if msg.type == "note_on" and msg.velocity > 0 and msg.note in GM[role]:
                    notes.append([tick / tpb, 0.1, msg.note, msg.velocity])
        if not notes:
            continue
        nb = int(max(n[0] for n in notes) // 4) + 1
        bars = _bars_from_notes(notes, nb)
        seqs.append([s for b in bars for s in b]); vels += [n[3] for n in notes]; keys += [n[2] for n in notes]
    return _finish(role, order, seqs, vels, keys)


def from_library(role: str, order: int = 3, limit: int = 200) -> dict:
    from . import core
    projs = []
    for e in core.list_library()[:limit]:
        try:
            projs.append(core.load_project(e["path"]))
        except Exception:
            continue
    return from_projects(projs, role, order)


def sample(model: dict, bars: int, rng: random.Random | None = None, temperature: float = 1.0) -> list[list[float]]:
    """-> nuty [on, 0.1, key, vel] na `bars` taktów. temperature <1 = bliżej korpusu, >1 = śmielej."""
    rng = rng or random.Random(0)
    order, notes = int(model["order"]), []
    seq = [0] * order
    for i in range(bars * STEPS):
        key = f"{'.'.join(map(str, seq[-order:]))}|{i % STEPS}"
        c = model["counts"].get(key)
        if not c:                                          # nieznany kontekst: cofnij się do samej pozycji
            c = [0, 0, 0]
            for k, v in model["counts"].items():
                if k.endswith(f"|{i % STEPS}"):
                    c = [a + b for a, b in zip(c, v)]
        w = np.array(c, dtype=float) + 1e-6
        w = w ** (1.0 / max(temperature, 0.05)); w /= w.sum()
        sym = int(rng.choices([0, 1, 2], weights=w.tolist())[0])
        seq.append(sym)
        if sym:
            vel = max(1, min(127, int(model["vel"][str(sym)] + rng.randint(-6, 6))))
            notes.append([i / 4.0, 0.1, int(model["key"]), vel])
    return notes


def apply(proj: dict, model: dict, strength: float = 0.5, section_types=("drop",), rng: random.Random | None = None,
          temperature: float = 0.9) -> dict:
    """Podmienia takty toru (typ = model['role']) w sekcjach `section_types` wzorcem z modelu z prawdopodobieństwem `strength` na takt.
    Szanuje lock_notes; nie rusza nut spoza podmienianych taktów. -> raport {'bars_replaced', 'tracks'}."""
    rng = rng or random.Random(int(proj.get("seed") or 0) ^ 0x4D4B)
    role = model["role"]; rep = {"bars_replaced": 0, "tracks": 0}
    for t in proj.get("tracks") or []:
        if t.get("type") != role or t.get("lock_notes"):
            continue
        rep["tracks"] += 1
        keep = list(t.get("notes") or [])
        for s in proj.get("sections") or []:
            if s.get("type") not in section_types:
                continue
            for b in range(int(s["start"]), int(s["start"]) + int(s["bars"])):
                if rng.random() >= strength:
                    continue
                lo, hi = b * 4.0, b * 4.0 + 4.0
                keep = [n for n in keep if not (lo <= float(n[0]) < hi)]
                new = sample(model, 1, rng, temperature)
                keep += [[lo + n[0], n[1], t["notes"][0][2] if t.get("notes") else n[2], n[3]] for n in new]
                rep["bars_replaced"] += 1
        t["notes"] = sorted(keep, key=lambda n: float(n[0]))
    proj["markov_report"] = rep
    return rep


def tokens_for_training(midi_path: str | Path):
    """Tokeny REMI (miditok) pod własny model sekwencyjny — tylko eksport; Studio nie trenuje transformerów. None bez miditok."""
    mt = OD.load("miditok")
    if mt is None:
        return None
    tok = mt.REMI()
    out = tok(Path(midi_path))
    return out


def save(model: dict, path: str | Path) -> None:
    Path(path).write_text(json.dumps(model, separators=(",", ":")), encoding="utf-8")


def load(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="dubstep_studio markov")
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("train"); t.add_argument("--role", required=True, choices=DRUM_ROLES)
    t.add_argument("--library", action="store_true"); t.add_argument("--midi", help="katalog z plikami .mid")
    t.add_argument("--order", type=int, default=3); t.add_argument("--out", required=True)
    s = sub.add_parser("show"); s.add_argument("model")
    ap_ = sub.add_parser("apply", help="podmień takty toru w projekcie JSON/.dsproj wzorcami z modelu")
    ap_.add_argument("project"); ap_.add_argument("model"); ap_.add_argument("--strength", type=float, default=0.5)
    ap_.add_argument("--sections", nargs="+", default=["drop"]); ap_.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "train":
        if a.midi:
            m = from_midi(sorted(Path(a.midi).rglob("*.mid")), a.role, a.order)
        else:
            m = from_library(a.role, a.order)
        save(m, a.out); print(f"model {a.role}: {m['n_bars']} taktów, {len(m['counts'])} kontekstów → {a.out}")
    elif a.cmd == "apply":
        from . import core
        p = core.load_project(a.project); r = apply(p, load(a.model), a.strength, tuple(a.sections))
        core.save_project(p, a.out); print(f"podmieniono {r['bars_replaced']} taktów na {r['tracks']} torze(ach) → {a.out}")
    else:
        m = load(a.model); print(f"rola {m['role']}, rząd {m['order']}, taktów {m['n_bars']}, klawisz {m['key']}, velocity {m['vel']}")
        for l in _ascii(sample(m, 2, random.Random(1))):
            print(l)
    return 0


def _ascii(notes) -> list[str]:
    out = []
    for b in range(int(max((n[0] for n in notes), default=0) // 4) + 1):
        row = ["."] * STEPS
        for n in notes:
            if int(n[0] // 4) == b:
                row[int(round((n[0] - 4 * b) * 4)) % STEPS] = "X" if n[3] >= 70 else "x"
        out.append("".join(row))
    return out


if __name__ == "__main__":
    raise SystemExit(main())
