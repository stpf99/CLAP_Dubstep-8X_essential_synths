"""constraints.py — rozwiązywanie kolizji kick/bas jako problemu z ograniczeniami (ortools CP-SAT; zapas: zachłanny).

Problem: nuta basu zaczyna się równo ze stopą i trwa długo, a tor basu NIE jest tłumiony sidechainem kick→Level
(patrz symbolic_backend.duck_residual). Dla każdej takiej nuty rozwiązanie wybiera: zostaw / skróć (punch) / opóźnij za ogon stopy.
Ograniczenia: najwyżej jedna zmiana na nutę, brak nakładania się z następną nutą toru (bas monofoniczny),
łącznie zmieniamy najwyżej `max_changed` nut toru (nie przepisujemy basu). Cel: usunąć jak najwięcej kolizji ważonych velocity,
najtaniej (opóźnienie > skrócenie > zostawienie).

Domyślnie WYŁĄCZONE w pipeline (musicality cfg „constraints”: True włącza je w apply_symbolic). Tory tłumione sidechainem
(typowe wyjście generatora) są pomijane — wtedy to no-op, co jest zamierzone.
"""
from __future__ import annotations

import math

import numpy as np

from . import optional_deps as OD
from . import symbolic_backend as SB

TRIM_TO = 0.375        # = 1,5 · win domyślnego okna kolizji w SB.kick_bass_clash
DELAY_AFTER = 0.5      # opóźnij do 0,5 ćwierćnuty po stopie (ósemka) — za ogon uderzenia
GRID = 0.25


def _kicks(proj: dict) -> np.ndarray:
    return np.array(sorted(float(n[0]) for t in SB._tracks(proj, only={"kick"}) for n in (t.get("notes") or [])))


def _candidates(proj: dict, ka: np.ndarray, win: float, min_residual: float):
    """-> lista dict(track=tr, i=indeks_nuty, k=czas_stopy, trim=bool, delay=bool, w=waga) + mapa torów -> liczba nut."""
    out, sizes = [], {}
    for t in SB._tracks(proj, only=SB.BASS):
        if t.get("lock_notes") or SB.duck_residual(proj, t) < min_residual:
            continue
        notes = t.get("notes") or []
        order = sorted(range(len(notes)), key=lambda j: float(notes[j][0]))
        sizes[id(t)] = len(notes)
        for pos, j in enumerate(order):
            on, dur, _key, vel = float(notes[j][0]), float(notes[j][1]), notes[j][2], float(notes[j][3])
            a = int(np.searchsorted(ka, on - win))
            if not (a < len(ka) and ka[a] <= on + win and dur > win * 1.5):
                continue
            k = float(ka[a])
            nxt = float(notes[order[pos + 1]][0]) if pos + 1 < len(order) else math.inf
            new_on = math.ceil((k + DELAY_AFTER) / GRID - 1e-9) * GRID
            can_delay = new_on > on and new_on + 0.125 <= nxt - 1e-9
            out.append({"track": t, "i": j, "k": k, "on": on, "dur": dur, "nxt": nxt, "new_on": new_on,
                        "trim": True, "delay": can_delay, "w": vel / 127.0})
    return out, sizes


def _solve_cpsat(cands: list[dict], budget: dict) -> dict[int, str]:
    from ortools.sat.python import cp_model
    m = cp_model.CpModel()
    xt = [m.NewBoolVar(f"t{n}") for n in range(len(cands))]
    xd = [m.NewBoolVar(f"d{n}") for n in range(len(cands))]
    obj = []
    by_track: dict[int, list[int]] = {}
    for n, c in enumerate(cands):
        m.Add(xt[n] + xd[n] <= 1)
        if not c["trim"]:
            m.Add(xt[n] == 0)
        if not c["delay"]:
            m.Add(xd[n] == 0)
        by_track.setdefault(id(c["track"]), []).append(n)
        gain = int(round(1000 * (0.4 + c["w"])))
        obj.append(xt[n] * (gain - 150))          # skrócenie: tańsze dla brzmienia niż przesunięcie rytmiczne…
        obj.append(xd[n] * (gain - 300))          # …przesunięcie droższe (zmienia groove)
    for tid, idx in by_track.items():
        m.Add(sum(xt[n] + xd[n] for n in idx) <= budget[tid])
    m.Maximize(sum(obj))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 5.0; s.parameters.num_workers = 1
    st = s.Solve(m)
    if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {}
    return {n: ("trim" if s.Value(xt[n]) else "delay") for n in range(len(cands)) if s.Value(xt[n]) or s.Value(xd[n])}


def _solve_greedy(cands: list[dict], budget: dict) -> dict[int, str]:
    used: dict[int, int] = {}
    pick: dict[int, str] = {}
    for n in sorted(range(len(cands)), key=lambda n: -cands[n]["w"]):
        c = cands[n]; tid = id(c["track"])
        if used.get(tid, 0) >= budget[tid]:
            continue
        pick[n] = "trim" if c["trim"] else "delay"
        used[tid] = used.get(tid, 0) + 1
    return pick


def apply(proj: dict, win: float = 0.25, max_changed: float = 0.35, min_residual: float = 0.3, solver: str = "auto") -> dict:
    """Zmienia nuty basu in-place. -> raport {'solver', 'candidates', 'trimmed', 'delayed', 'clash_before', 'clash_after'} (także w proj['constraints_report'])."""
    ka = _kicks(proj)
    before = SB.kick_bass_clash(proj, win)
    rep = {"solver": "none", "candidates": 0, "trimmed": 0, "delayed": 0, "clash_before": before, "clash_after": before}
    if len(ka) == 0:
        proj["constraints_report"] = rep
        return rep
    cands, sizes = _candidates(proj, ka, win, min_residual)
    rep["candidates"] = len(cands)
    if cands:
        budget = {tid: max(1, math.ceil(max_changed * n)) for tid, n in sizes.items()}
        pick: dict[int, str] = {}
        use = solver
        if use == "auto":
            use = "cpsat" if OD.have("ortools") else "greedy"
        if use == "cpsat" and OD.have("ortools"):
            try:
                pick = _solve_cpsat(cands, budget); rep["solver"] = "cpsat"
            except Exception:
                pick = {}
        if not pick and rep["solver"] != "cpsat":
            pick = _solve_greedy(cands, budget); rep["solver"] = "greedy"
        for n, how in pick.items():
            c = cands[n]; note = c["track"]["notes"][c["i"]]
            if how == "delay":
                new_on = c["new_on"]; nd = min(float(note[1]), max(0.125, c["nxt"] - new_on - 0.0625))
                c["track"]["notes"][c["i"]] = [new_on, nd, *note[2:]]; rep["delayed"] += 1
            else:
                c["track"]["notes"][c["i"]] = [note[0], min(float(note[1]), TRIM_TO), *note[2:]]; rep["trimmed"] += 1
    rep["clash_after"] = SB.kick_bass_clash(proj, win)
    proj["constraints_report"] = rep
    return rep
