"""symbolic_backend.py — metryki symboliczne projektu (bez renderu): tonacja, zgodność ze skalą, kolizje kick/bas, powtarzalność.

Czysty numpy; `pretty_midi`, `music21`, `symusic` służą tylko do KRZYŻOWEJ weryfikacji (key_crosscheck) — bez nich wszystko działa.
Używane przez optimize.py jako składniki funkcji celu oraz przez testy. Nuty: [on_w_ćwierćnutach, dur, klawisz_MIDI, velocity].
"""
from __future__ import annotations

import math
import os
import tempfile

import numpy as np

from . import optional_deps as OD

UNPITCHED = frozenset({"kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "openhat", "ride", "cowbell", "conga"})
BASS = frozenset({"sub", "wobble", "reese", "neuro", "fmbass", "hollow", "growl", "bass808", "upright"})
NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

_KS_MAJ = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
_KS_MIN = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])


def _tracks(proj: dict, pitched: bool | None = None, only=None):
    for t in proj.get("tracks") or []:
        if t.get("mute"):
            continue
        tt = t.get("type") or ""
        if pitched is True and tt in UNPITCHED:
            continue
        if pitched is False and tt not in UNPITCHED:
            continue
        if only is not None and tt not in only:
            continue
        yield t


def pc_hist(proj: dict, types=None) -> np.ndarray:
    """Histogram 12 klas wysokości ważony dur·velocity (tory melodyczne). Znormalizowany do sumy 1 (albo same zera)."""
    h = np.zeros(12)
    for t in _tracks(proj, pitched=True, only=types):
        for n in t.get("notes") or []:
            h[int(n[2]) % 12] += max(float(n[1]), 0.05) * float(n[3])
    s = h.sum()
    return h / s if s > 0 else h


def key_estimate(proj: dict) -> dict:
    """Krumhansl–Schmuckler na histogramie nut. -> {'key': 0..11|None, 'mode': 'major'|'minor', 'conf': 0..1}."""
    h = pc_hist(proj)
    if h.sum() <= 0:
        return {"key": None, "mode": "minor", "conf": 0.0}
    best = (-2.0, 0, "minor"); second = -2.0
    for r in range(12):
        for prof, mode in ((_KS_MAJ, "major"), (_KS_MIN, "minor")):
            c = float(np.corrcoef(h, np.roll(prof, r))[0, 1])
            if c > best[0]:
                second = best[0]; best = (c, r, mode)
            elif c > second:
                second = c
    return {"key": best[1], "mode": best[2], "conf": float(max(0.0, min(1.0, best[0] - max(second, 0.0) + 0.5 * best[0])))}


def scale_conformity(proj: dict) -> float:
    """Udział (ważony dur·vel) nut melodycznych w skali projektu 0..1. Brak nut ⇒ 1.0 (nic nie łamie skali)."""
    from . import core
    iv = core.SCALES.get(proj.get("scale") or "minor") or core.SCALES["minor"]
    root = int(proj.get("key") or 0)
    ok = {(root + i) % 12 for i in iv}
    tot = hit = 0.0
    for t in _tracks(proj, pitched=True):
        for n in t.get("notes") or []:
            w = max(float(n[1]), 0.05) * float(n[3]); tot += w
            if int(n[2]) % 12 in ok:
                hit += w
    return hit / tot if tot > 0 else 1.0


def duck_residual(proj: dict, tr: dict) -> float:
    """1.0 = tor nie jest tłumiony przez kick (brak linku kick→Level), ~0 = mocny sidechain. Heurystyka: głębokość 0,6 ≈ pełne tłumienie."""
    deep = 0.0
    for L in proj.get("links") or []:
        if L.get("src") == "kick" and L.get("dst") in (tr.get("name"), tr.get("type")) and str(L.get("param", "")).lower() in ("level", "gain", "volume"):
            deep = max(deep, -float(L.get("amount") or 0.0))
    return float(1.0 - min(1.0, max(0.0, deep) / 0.6))


def kick_bass_clash(proj: dict, win: float = 0.25) -> float:
    """Ważony udział nut basu zaczynających się w oknie `win` ćwierćnuty od uderzenia kicka i trwających dłużej niż 1,5·win,
    z wagą = duck_residual (bas tłumiony sidechainem kick→Level się nie „zderza”). 0 = czysto; 1 = każda nuta bez ducku koliduje."""
    kicks = sorted(float(n[0]) for t in _tracks(proj, only={"kick"}) for n in (t.get("notes") or []))
    if not kicks:
        return 0.0
    ka = np.array(kicks)
    clash = tot = 0.0
    for t in _tracks(proj, only=BASS):
        res = duck_residual(proj, t)
        for n in t.get("notes") or []:
            tot += 1
            on, dur = float(n[0]), float(n[1])
            i = int(np.searchsorted(ka, on - win))
            if i < len(ka) and ka[i] <= on + win and dur > win * 1.5:
                clash += res
    return clash / tot if tot else 0.0


def bar_variety(proj: dict, beats_per_bar: int = 4) -> float:
    """Średnia po torach: unikalne takty / niepuste takty (0..1). ~0 = pętla w kółko, ~1 = każdy takt inny."""
    vals = []
    for t in _tracks(proj):
        bars: dict[int, list] = {}
        for n in t.get("notes") or []:
            b = int(float(n[0]) // beats_per_bar)
            bars.setdefault(b, []).append((round((float(n[0]) - b * beats_per_bar) * 4) / 4, int(n[2]) % 12))
        if len(bars) >= 4:
            sig = {tuple(sorted(v)) for v in bars.values()}
            vals.append(len(sig) / len(bars))
    return float(np.mean(vals)) if vals else 0.5


def velocity_spread(proj: dict) -> float:
    """Średnie odchylenie velocity w torach perkusyjnych, znormalizowane (0 = maszyna, ~0.15 = „żywe”)."""
    sd = []
    for t in _tracks(proj, pitched=False):
        v = [float(n[3]) for n in (t.get("notes") or [])]
        if len(v) >= 8:
            sd.append(np.std(v) / 127.0)
    return float(np.mean(sd)) if sd else 0.0


def metrics(proj: dict) -> dict:
    return {
        "scale_conf": scale_conformity(proj),
        "clash": kick_bass_clash(proj),
        "variety": bar_variety(proj),
        "vel_spread": velocity_spread(proj),
        "key_est": key_estimate(proj),
    }


# ------------------------------------------------------------------ krzyżowa weryfikacja tonacji (opcjonalne biblioteki)
def _to_midi_file(proj: dict) -> str | None:
    """Zapis MIDI przez core.write_midi (stdlib, bez mido) do pliku tymczasowego. None gdy się nie da."""
    try:
        from . import core
        fd, path = tempfile.mkstemp(suffix=".mid"); os.close(fd)
        core.write_midi(proj, path)
        return path
    except Exception:
        return None


def key_crosscheck(proj: dict) -> dict:
    """Porównuje własną estymację tonacji z pretty_midi (histogram) i music21 (analiza tonacji). Wolne (music21) — tylko do diagnostyki/testów."""
    out = {"own": key_estimate(proj), "declared": {"key": proj.get("key"), "scale": proj.get("scale")}}
    path = _to_midi_file(proj)
    if not path:
        return out
    try:
        pm = OD.load("pretty_midi")
        if pm is not None:
            try:
                m = pm.PrettyMIDI(path)
                h = np.array(m.get_pitch_class_histogram(use_duration=True, use_velocity=True, normalize=True))
                out["pretty_midi_top_pc"] = [NAMES[i] for i in np.argsort(-h)[:3]]
            except Exception:
                pass
        m21 = OD.load("music21")
        if m21 is not None:
            try:
                k = m21.converter.parse(path).analyze("key")
                out["music21"] = {"tonic": k.tonic.name, "mode": k.mode, "conf": round(float(k.correlationCoefficient), 3)}
            except Exception:
                pass
        sy = OD.load("symusic")
        if sy is not None:
            try:
                sc = sy.Score(path)
                out["symusic_notes"] = int(sum(len(t.notes) for t in sc.tracks))
            except Exception:
                pass
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return out
