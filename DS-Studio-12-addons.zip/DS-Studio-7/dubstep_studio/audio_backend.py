"""audio_backend.py — opcjonalne, lepsze pomiary audio dla listen.analyze_audio (librosa / pyloudnorm / aubio / essentia).

Zasada: własna analiza w numpy (listen.py) zostaje punktem wyjścia. Ten moduł
  • DODAJE pola:  F["lufs"], F["lufs_src"], F["tempo_lib"], F["key_lib"], F["backends"] (lista użytych źródeł),
  • ZMIENIA bpm / tonację tylko gdy własna pewność jest niska, a zewnętrzna wysoka (albo podbija pewność, gdy się zgadzają).
Brak bibliotek ⇒ `enhance()` nic nie robi (poza przybliżonym LUFS z numpy/scipy). Wyłączenie: DS_AUDIO_BACKEND=off.

Koszt: librosa.chroma_cqt + beat_track na oknie ~20 s to rząd 0,3–1 s na słabszym CPU; dlatego `fast=True`
(domyślnie w Live) tnie okno do ostatnich 12 s i pomija CQT, gdy tonacja własna jest już pewna.
"""
from __future__ import annotations

import math
import os

import numpy as np

from . import optional_deps as OD

MODE_ENV = "DS_AUDIO_BACKEND"          # off | fuse (domyślnie)


def _mode() -> str:
    return os.environ.get(MODE_ENV, "fuse").strip().lower()


def _fold_bpm(b: float) -> float:
    """Jak w listen.analyze_audio: BPM „przyjazny Studiu” 90–180."""
    while 0 < b < 90:
        b *= 2
    while b > 180:
        b /= 2
    return float(b)


def _mono(st: np.ndarray) -> np.ndarray:
    st = np.asarray(st, dtype=np.float32)
    return st if st.ndim == 1 else st.mean(axis=1).astype(np.float32)


def _resample(x: np.ndarray, rate: int, target: int) -> np.ndarray:
    if rate == target:
        return x
    sp = OD.load("scipy.signal")
    if sp is None and OD.have("scipy"):
        import scipy.signal as sp  # type: ignore
    if sp is not None:
        g = math.gcd(int(rate), int(target))
        return sp.resample_poly(x, target // g, rate // g).astype(np.float32)
    n = int(len(x) * target / rate)                                   # zapas: interpolacja liniowa
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)


# ------------------------------------------------------------------ LUFS
def _k_weight(x: np.ndarray, rate: int) -> np.ndarray | None:
    """K-weighting z BS.1770 (dwa biquady) — tylko gdy jest scipy; współczynniki przeliczane dla dowolnego `rate`."""
    if not OD.have("scipy"):
        return None
    import scipy.signal as ss
    # stage 1: high-shelf (+4 dB, ~1.68 kHz), stage 2: RLB high-pass (~38 Hz) — wzory z BS.1770 / pyloudnorm
    G, Q, fc = 3.999843853973347, 0.7071752369554196, 1681.9744509555319
    K = math.tan(math.pi * fc / rate); Vh = 10 ** (G / 20); Vb = Vh ** 0.4996667741545416
    a0 = 1 + K / Q + K * K
    b1 = [(Vh + Vb * K / Q + K * K) / a0, 2 * (K * K - Vh) / a0, (Vh - Vb * K / Q + K * K) / a0]
    a1 = [1, 2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0]
    Q2, fc2 = 0.5003270373253953, 38.13547087613982
    K2 = math.tan(math.pi * fc2 / rate)
    a02 = 1 + K2 / Q2 + K2 * K2
    b2 = [1, -2, 1]; a2 = [1, 2 * (K2 * K2 - 1) / a02, (1 - K2 / Q2 + K2 * K2) / a02]
    return ss.lfilter(b2, a2, ss.lfilter(b1, a1, x, axis=0), axis=0)


def lufs(st: np.ndarray, rate: int) -> tuple[float, str]:
    """-> (LUFS zintegrowane, źródło: 'pyloudnorm' | 'numpy-k' | 'rms-approx'). Cisza ⇒ -70."""
    x = np.asarray(st, dtype=np.float64)
    if x.ndim == 1:
        x = x[:, None]
    if len(x) < int(0.4 * rate) or float(np.abs(x).max()) < 1e-6:
        return -70.0, "silent"
    pl = OD.load("pyloudnorm")
    if pl is not None:
        try:
            v = float(pl.Meter(int(rate)).integrated_loudness(x))
            if math.isfinite(v):
                return v, "pyloudnorm"
        except Exception:
            pass
    y = _k_weight(x, int(rate))
    src = "numpy-k"
    if y is None:
        y, src = x, "rms-approx"
    # blokowo (400 ms, 75 % zakładki) + bramki absolutna -70 i względna -10 LU — jak w BS.1770-4
    blk, hop = int(0.4 * rate), int(0.1 * rate)
    ms = np.array([np.mean(y[i:i + blk] ** 2, axis=0).sum() for i in range(0, len(y) - blk + 1, hop)])
    if len(ms) == 0:
        return -70.0, "silent"
    l = -0.691 + 10 * np.log10(ms + 1e-12)
    keep = l > -70
    if not keep.any():
        return -70.0, "silent"
    rel = -0.691 + 10 * np.log10(ms[keep].mean() + 1e-12) - 10
    keep &= l > rel
    return float(-0.691 + 10 * np.log10(ms[keep].mean() + 1e-12)), src


# ------------------------------------------------------------------ tempo
def tempo_librosa(mono: np.ndarray, rate: int) -> tuple[float, float] | None:
    """-> (bpm, pewność 0..1) albo None. Pewność = regularność odstępów między uderzeniami."""
    lb = OD.load("librosa")
    if lb is None:
        return None
    try:
        y = _resample(mono, rate, 22050)
        env = lb.onset.onset_strength(y=y, sr=22050)
        tempo, beats = lb.beat.beat_track(onset_envelope=env, sr=22050, units="time")
        bpm = float(np.atleast_1d(tempo)[0])
        if bpm <= 0 or len(beats) < 6:
            return None
        d = np.diff(beats)
        conf = float(max(0.0, min(1.0, 1.0 - np.std(d) / (np.mean(d) + 1e-9) * 2.5)))
        return bpm, conf
    except Exception:
        return None


def tempo_aubio(mono: np.ndarray, rate: int) -> tuple[float, float] | None:
    ab = OD.load("aubio")
    if ab is None:
        return None
    try:
        hop = 512
        t = ab.tempo("default", 1024, hop, int(rate))
        bpms, confs = [], []
        x = np.asarray(mono, dtype=np.float32)
        for i in range(0, len(x) - hop, hop):
            if t(x[i:i + hop])[0]:
                bpms.append(t.get_bpm()); confs.append(t.get_confidence())
        if len(bpms) < 6:
            return None
        return float(np.median(bpms)), float(max(0.0, min(1.0, np.mean(confs))))
    except Exception:
        return None


def tempo_essentia(mono: np.ndarray, rate: int) -> tuple[float, float] | None:
    es = OD.load("essentia.standard")
    if es is None:
        return None
    try:
        y = _resample(mono, rate, 44100)
        bpm, _beats, conf, _est, _iv = es.RhythmExtractor2013(method="multifeature")(y.astype(np.float32))
        return float(bpm), float(max(0.0, min(1.0, conf / 5.32)))        # skala „confidence” multifeature to ok. 0..5.3
    except Exception:
        return None


# ------------------------------------------------------------------ chroma / tonacja
def chroma_librosa(mono: np.ndarray, rate: int) -> np.ndarray | None:
    lb = OD.load("librosa")
    if lb is None:
        return None
    try:
        y = _resample(mono, rate, 22050)
        ch = lb.feature.chroma_cqt(y=y, sr=22050, fmin=65.4, n_octaves=5).mean(axis=1)
        s = float(ch.sum())
        # librosa: indeks 0 = C — tak samo jak _chroma() w listen.py (pc względem C4)
        return (ch / s) if s > 1e-9 else None
    except Exception:
        return None


def key_essentia(mono: np.ndarray, rate: int) -> tuple[int, str, float] | None:
    es = OD.load("essentia.standard")
    if es is None:
        return None
    try:
        y = _resample(mono, rate, 44100).astype(np.float32)
        key, scale, strength = es.KeyExtractor(profileType="edma")(y)       # edma = profil pod muzykę elektroniczną
        names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        flat = {"Db": "C#", "Eb": "D#", "Gb": "F#", "Ab": "G#", "Bb": "A#"}
        k = flat.get(key, key)
        return names.index(k), str(scale), float(max(0.0, min(1.0, strength)))
    except Exception:
        return None


# ------------------------------------------------------------------ fuzja z listen.analyze_audio
def _same_tempo(a: float, b: float, tol: float = 0.03) -> bool:
    return any(abs(a - b * m) / max(a, 1e-9) <= tol for m in (1.0, 2.0, 0.5))


def enhance(F: dict, st: np.ndarray, rate: int, fast: bool = False) -> dict:
    """Dopisuje do słownika cech z analyze_audio dane z zewnętrznych bibliotek. Zwraca F (in-place)."""
    if F.get("silent") or _mode() == "off":
        return F
    used: list[str] = []
    try:
        v, src = lufs(st, rate)
        F["lufs"], F["lufs_src"] = v, src
        used.append(src)
    except Exception:
        pass

    mono = _mono(st)
    if fast and len(mono) > 12 * rate:
        mono = mono[-12 * rate:]

    # --- tempo: własne vs librosa / aubio / essentia
    cands: list[tuple[str, float, float]] = []
    for name, fn in (("librosa", tempo_librosa), ("aubio", tempo_aubio), ("essentia", tempo_essentia)):
        if fast and name == "essentia":
            continue
        r = fn(mono, rate)
        if r:
            cands.append((name, r[0], r[1]))
    if cands:
        F["tempo_lib"] = {n: {"bpm": round(b, 2), "conf": round(c, 3)} for n, b, c in cands}
        used += [n for n, _, _ in cands]
        own_b, own_c = float(F.get("bpm") or 0.0), float(F.get("tempo_conf") or 0.0)
        best = max(cands, key=lambda t: t[2])
        agree = [c for c in cands if own_b > 0 and _same_tempo(own_b, c[1])]
        if own_b > 0 and agree:
            F["tempo_conf"] = float(max(own_c, min(0.95, 0.6 + 0.3 * max(c[2] for c in agree))))
            F["tempo_src"] = "numpy+" + "+".join(c[0] for c in agree)
        elif best[2] >= 0.6 and own_c < 0.55:
            F["tempo_own"] = {"bpm": own_b, "conf": own_c}
            F["tempo_raw"], F["tempo_conf"], F["tempo_src"] = float(best[1]), float(best[2]), best[0]
            F["bpm"] = _fold_bpm(best[1])

    # --- tonacja: własna vs chroma_cqt (librosa) / KeyExtractor (essentia)
    try:
        from . import listen as L
        own_kc = float(F.get("key_conf") or 0.0)
        if not (fast and own_kc >= 0.6):
            ch = chroma_librosa(mono, rate)
            if ch is not None:
                root, scale, kc, mode = L._key_scale(ch)
                F["key_lib"] = {"key": root, "scale": scale, "conf": round(kc, 3), "mode": mode}
                used.append("librosa-cqt")
                if root is not None:
                    if F.get("key") == root:
                        F["key_conf"] = float(max(own_kc, min(0.95, 0.5 + 0.5 * kc)))
                    elif kc >= 0.65 and own_kc < 0.45:
                        F["key_own"] = {"key": F.get("key"), "scale": F.get("scale"), "conf": own_kc}
                        F["key"], F["scale"], F["key_conf"], F["mode"] = root, scale, kc, mode
                        F["chroma"] = [float(x) for x in ch]
            if not fast:
                ke = key_essentia(mono, rate)
                if ke:
                    F["key_essentia"] = {"key": ke[0], "mode": ke[1], "strength": round(ke[2], 3)}
                    used.append("essentia-key")
    except Exception:
        pass
    F["backends"] = used
    return F


_warm = {"started": False}


def warmup() -> None:
    """Rozgrzewka w tle: pierwszy import librosa/numba/essentia trwa kilkanaście sekund, kolejne wywołania ~0,5 s.
    Wołane przy starcie Listenera, żeby pierwsza analiza Live nie zawisła."""
    if _warm["started"] or _mode() == "off":
        return
    _warm["started"] = True
    import threading

    def _go():
        try:
            x = (np.random.default_rng(0).standard_normal(48000 * 5) * 0.1).astype(np.float32)
            lufs(np.stack([x, x], 1), 48000)
            tempo_librosa(x, 48000); chroma_librosa(x, 48000); tempo_aubio(x, 48000)
        except Exception:
            pass
    threading.Thread(target=_go, daemon=True, name="ds-audio-warmup").start()
