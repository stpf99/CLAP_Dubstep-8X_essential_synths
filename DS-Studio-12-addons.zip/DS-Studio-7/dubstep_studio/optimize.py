"""optimize.py — zamknięta pętla: generuj → oceń → dobierz parametry generatora (optuna; zapas: losowanie).

Zamiast „losuj i poprawiaj” szukamy GAŁEK generate() (energy, density, variety, predict, dance/uniq strength), które dają
najlepszą średnią ocenę na kilku ziarnach. Ocena = `objective()`:
    magic_noum.score_project (okna parametrów, zakresy, gainy)  +  symbolic_backend (zgodność ze skalą, kolizje kick/bas,
    zróżnicowanie taktów, „żywość” velocity)  [+ opcjonalnie audio: LUFS/crest/pasma po renderze — wolne, domyślnie wyłączone].

Gwarancje: pierwszą próbą są wartości domyślne generate(), więc wynik NIGDY nie jest gorszy od domyślnych wg tej samej oceny.
Uwaga (prawo Goodharta): ocena jest heurystyką z tego samego repo, więc „najlepszy” = najlepszy wg niej, nie wg ucha.
Różne ziarna w jednej próbie (domyślnie 3) ograniczają dopasowanie do jednego losowania.

API:   optimize(style, trials=30, seeds=(1,2,3), **gen_kw) -> dict      generate_optimized(style, **opt_kw) -> proj
CLI:   python3 -m dubstep_studio optimize --style Brostep --trials 30 [--bars 64] [--audio] [--sampler tpe|cmaes|random] [--save PLIK.json]
"""
from __future__ import annotations

import json
import math
import random
import statistics
from typing import Callable

from . import optional_deps as OD

# nazwa -> (domyślna z generate(), min, max)
SPACE: dict[str, tuple[float, float, float]] = {
    "energy": (0.7, 0.35, 0.98),
    "density": (0.6, 0.3, 0.9),
    "variety": (0.5, 0.0, 1.0),
    "predict": (0.6, 0.0, 1.0),
    "dance_strength": (0.6, 0.0, 1.0),
    "uniq_strength": (0.6, 0.2, 1.0),
}
# gałki włączające funkcje, których siła jest w SPACE (bez nich strojenie siły nic by nie zmieniało)
FORCE_ON = {"dance_strength": {"dance": True}, "uniq_strength": {"uniq": True}}

WEIGHTS = {"quality": 0.35, "scale": 0.20, "clash": 0.15, "variety": 0.15, "vel": 0.15}


def _tri(x: float, peak: float, width: float) -> float:
    return max(0.0, 1.0 - abs(x - peak) / width)


def audio_score(proj: dict, max_sec: float = 10.0) -> float:
    """0..1 z renderu: bliskość LUFS ~ -16 (miks przed masteringiem), crest 8–14 dB i dystans pasm do BAND_TARGETS reviewera. Wolne (render)."""
    from . import core, listen as L, musicality_reviewer as MR
    mix = core.render_mix(proj, workers=1)
    if mix is None or len(mix) < 4096:
        return 0.0
    n = int(max_sec * core.SR)
    if len(mix) > n:
        s = (len(mix) - n) // 2; mix = mix[s:s + n]
    F = L.analyze_audio(mix, rate=core.SR, fast=True)
    if F.get("silent"):
        return 0.0
    lu = F.get("lufs", F.get("rms_db", -20.0) - 3.0)
    s_lufs = _tri(lu, -16.0, 8.0)
    s_crest = 1.0 if 8 <= F["crest_db"] <= 14 else _tri(F["crest_db"], 11.0, 8.0)
    fam = MR._climate_family(proj)
    tgt = MR.BAND_TARGETS.get(fam, MR.BAND_TARGETS["default"])
    bands = F.get("bands") or {}
    tot = sum(bands.values()) or 1.0
    dist = sum(abs(bands.get(k, 0) / tot - tgt.get(k, 0)) for k in tgt)
    return float(0.4 * s_lufs + 0.3 * s_crest + 0.3 * max(0.0, 1.0 - dist))


def objective(proj: dict, audio: bool = False, weights: dict | None = None) -> tuple[float, dict]:
    """-> (ocena 0..1, składniki). Czysta funkcja projektu — można jej użyć poza optymalizatorem (np. do porównania presetów)."""
    from . import magic_noum as MN, symbolic_backend as SB
    w = dict(WEIGHTS); w.update(weights or {})
    parts = {
        "quality": MN.score_project(proj),
        "scale": SB.scale_conformity(proj),
        "clash": 1.0 - SB.kick_bass_clash(proj),
        "variety": _tri(SB.bar_variety(proj), 0.45, 0.45),
        "vel": _tri(SB.velocity_spread(proj), 0.14, 0.14),
    }
    tot = sum(w[k] * parts[k] for k in parts) / (sum(w[k] for k in parts) or 1.0)
    if audio:
        parts["audio"] = audio_score(proj)
        tot = 0.7 * tot + 0.3 * parts["audio"]
    return float(tot), parts


def _space_for(fixed: dict, tune: list[str] | None) -> dict:
    names = tune or list(SPACE)
    return {k: SPACE[k] for k in names if k in SPACE and k not in fixed}


def _evaluate(style: str, knobs: dict, seeds, gen_kw: dict, audio: bool, gen_fn: Callable | None = None):
    from . import generator as G
    gen = gen_fn or G.generate
    sc, parts_acc = [], []
    kw = dict(gen_kw)
    for k in knobs:
        kw.update(FORCE_ON.get(k, {}))
    for sd in seeds:
        proj = gen(style, seed=sd, **{**kw, **knobs})
        s, parts = objective(proj, audio=audio)
        sc.append(s); parts_acc.append(parts)
    keys = parts_acc[0].keys()
    return statistics.fmean(sc), {k: statistics.fmean(p[k] for p in parts_acc) for k in keys}


def optimize(style: str = "Brostep", trials: int = 30, seeds=(1, 2, 3), tune: list[str] | None = None,
             sampler: str = "tpe", audio: bool = False, rng_seed: int = 0, gen_fn: Callable | None = None,
             on_trial: Callable | None = None, **gen_kw) -> dict:
    """Szuka gałek generatora. gen_kw = stałe argumenty generate() (bars, key, scale, instruments…), pomijane w przestrzeni poszukiwań.

    -> {'best_params', 'best_score', 'baseline_score', 'baseline_parts', 'best_parts', 'trials', 'backend', 'history', 'space'}"""
    seeds = tuple(seeds) or (1,)
    space = _space_for(gen_kw, tune)
    base = {k: v[0] for k, v in space.items()}
    history: list[dict] = []

    def run(knobs: dict):
        s, parts = _evaluate(style, knobs, seeds, gen_kw, audio, gen_fn)
        history.append({"params": dict(knobs), "score": s})
        if on_trial:
            on_trial(len(history), knobs, s)
        return s, parts

    base_score, base_parts = run(base)                       # próba 0: domyślne — gwarancja „nie gorzej”
    best = (base_score, dict(base), base_parts)
    backend = "random"
    optuna = OD.load("optuna") if sampler != "random" else None

    if optuna is not None and space and trials > 1:
        backend = "optuna"
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        if sampler == "cmaes" and OD.have("cmaes"):
            smp = optuna.samplers.CmaEsSampler(seed=rng_seed, x0=base)
            backend = "optuna-cmaes"
        else:
            smp = optuna.samplers.TPESampler(seed=rng_seed, n_startup_trials=min(8, max(3, trials // 4)))
        study = optuna.create_study(direction="maximize", sampler=smp)
        cache: dict[int, tuple] = {}

        def obj(tr):
            knobs = {k: tr.suggest_float(k, lo, hi) for k, (_, lo, hi) in space.items()}
            s, parts = run(knobs)
            cache[tr.number] = (s, knobs, parts)
            return s
        study.optimize(obj, n_trials=trials - 1, show_progress_bar=False)
        for s, knobs, parts in cache.values():
            if s > best[0]:
                best = (s, knobs, parts)
    else:
        rng = random.Random(rng_seed)
        for _ in range(max(0, trials - 1)):
            knobs = {k: rng.uniform(lo, hi) for k, (_, lo, hi) in space.items()}
            s, parts = run(knobs)
            if s > best[0]:
                best = (s, knobs, parts)

    spread = statistics.pstdev([h["score"] for h in history]) if len(history) > 1 else 0.0
    note = ""
    if spread < 0.01 and not audio:
        note = (f"Ocena symboliczna jest nasycona (odchylenie między próbami {spread:.4f}) — generator już mieści się w oknach, "
                "które sprawdza ocena, więc optymalizator nie ma czego poprawiać. Użyj audio=True (--audio): ocena z renderu rozróżnia próby ~10× lepiej.")
    return {"note": note, "spread": spread,
            "best_params": {k: round(v, 4) for k, v in best[1].items()}, "best_score": best[0], "best_parts": best[2],
            "baseline_score": base_score, "baseline_parts": base_parts, "trials": len(history), "backend": backend,
            "history": history, "space": {k: list(v) for k, v in space.items()}, "seeds": list(seeds), "style": style,
            "fixed": {k: v for k, v in gen_kw.items() if isinstance(v, (int, float, str, bool, type(None)))}}


def generate_optimized(style: str = "Brostep", seed: int | None = None, trials: int = 30, **kw) -> dict:
    """optimize() + jeden końcowy projekt z najlepszymi gałkami i podanym `seed` (domyślnie pierwsze ziarno optymalizacji).
    Wynik opisany w proj['optimize'] (parametry, ocena bazowa vs najlepsza, backend)."""
    from . import generator as G
    gen_kw = {k: v for k, v in kw.items() if k not in ("seeds", "tune", "sampler", "audio", "rng_seed", "gen_fn", "on_trial")}
    opt_kw = {k: v for k, v in kw.items() if k in ("seeds", "tune", "sampler", "audio", "rng_seed", "gen_fn", "on_trial")}
    r = optimize(style, trials=trials, **opt_kw, **gen_kw)
    final = dict(gen_kw)
    for k in r["best_params"]:
        final.update(FORCE_ON.get(k, {}))
    final.update(r["best_params"])
    proj = G.generate(style, seed=seed if seed is not None else r["seeds"][0], **final)
    proj["optimize"] = {"params": r["best_params"], "score": r["best_score"], "baseline": r["baseline_score"],
                        "backend": r["backend"], "trials": r["trials"]}
    return proj


def pareto(style: str = "Brostep", trials: int = 40, seeds=(1, 2, 3), rng_seed: int = 0, **gen_kw) -> list[dict]:
    """Wielokryterialnie (NSGA-II): maksymalizuj (jakość, zróżnicowanie taktów). Wymaga optuny; bez niej ValueError."""
    optuna = OD.load("optuna")
    if optuna is None:
        raise ValueError("pareto() wymaga pakietu optuna (pip install optuna)")
    from . import symbolic_backend as SB, generator as G
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    space = _space_for(gen_kw, None)
    study = optuna.create_study(directions=["maximize", "maximize"], sampler=optuna.samplers.NSGAIISampler(seed=rng_seed))

    def obj(tr):
        knobs = {k: tr.suggest_float(k, lo, hi) for k, (_, lo, hi) in space.items()}
        kw = dict(gen_kw)
        for k in knobs:
            kw.update(FORCE_ON.get(k, {}))
        q, v = [], []
        for sd in seeds:
            p = G.generate(style, seed=sd, **{**kw, **knobs})
            q.append(objective(p)[0]); v.append(SB.bar_variety(p))
        return statistics.fmean(q), statistics.fmean(v)
    study.optimize(obj, n_trials=trials, show_progress_bar=False)
    return [{"params": {k: round(v, 4) for k, v in t.params.items()}, "quality": t.values[0], "variety": t.values[1]}
            for t in study.best_trials]


def main(argv: list[str] | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="dubstep_studio optimize", description="Dobór gałek generatora (optuna / losowanie).")
    ap.add_argument("--style", default="Brostep"); ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--bars", type=int, default=64); ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--sampler", choices=["tpe", "cmaes", "random"], default="tpe")
    ap.add_argument("--audio", action="store_true", help="dodaj ocenę z renderu (wolne: ~sekundy na próbę)")
    ap.add_argument("--rng-seed", type=int, default=0); ap.add_argument("--save", help="zapisz najlepszy projekt (JSON)")
    a = ap.parse_args(argv)
    r = optimize(a.style, trials=a.trials, seeds=a.seeds, sampler=a.sampler, audio=a.audio, rng_seed=a.rng_seed, bars=a.bars,
                 on_trial=lambda i, k, s: print(f"  próba {i:3d}  ocena {s:.4f}", flush=True) if i % 5 == 0 else None)
    print(f"\nbackend: {r['backend']}  prób: {r['trials']}")
    print(f"ocena domyślnych: {r['baseline_score']:.4f}   najlepsza: {r['best_score']:.4f}   (+{r['best_score'] - r['baseline_score']:.4f})")
    if r["note"]:
        print("UWAGA:", r["note"])
    print("najlepsze parametry:", json.dumps(r["best_params"], ensure_ascii=False))
    print("składniki (domyślne → najlepsze):")
    for k in r["best_parts"]:
        print(f"  {k:8s} {r['baseline_parts'][k]:.3f} → {r['best_parts'][k]:.3f}")
    if a.save:
        from . import generator as G
        kw = {"bars": a.bars}
        for k in r["best_params"]:
            kw.update(FORCE_ON.get(k, {}))
        kw.update(r["best_params"])
        p = G.generate(a.style, seed=a.seeds[0], **kw); p["optimize"] = {"params": r["best_params"], "score": r["best_score"]}
        with open(a.save, "w", encoding="utf-8") as f:
            json.dump(p, f, ensure_ascii=False)
        print("zapisano:", a.save)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
