"""timbre_fit.py — dopasowanie parametrów instrumentu CLAP do docelowego dźwięku (optymalizacja CMA-ES; zapas: (1+1)-ES w numpy).

Wejście: plik WAV/audio (albo tablica) z jedną nutą/krótkim dźwiękiem, typ instrumentu Studia i wysokość nuty.
Pętla: parametry (ułamki 0..1) → render jednej nuty przez dsrender → cechy widmowe → odległość do celu → CMA-ES.
Cechy: widmo log-pasmowe (32 pasma, średnia i odchylenie w czasie) + obwiednia głośności; z `librosa` dodatkowo MFCC (13).
Wynik to propozycja parametrów, nie gwarancja podobieństwa: instrument ma ograniczone możliwości, a odległość widmowa ≠ „brzmi tak samo”.

API:   fit(type, target, key=36, budget=80, tune=None, seed=0) -> {'params', 'distance', 'start_distance', 'evals', 'backend'}
CLI:   python3 -m dubstep_studio timbre --type wobble --target cel.wav [--key 36] [--budget 80] [--out params.json]
"""
from __future__ import annotations

import json
import math
import random

import numpy as np

from . import optional_deps as OD

SKIP = {"Level", "Input Mix", "Pan", "Volume", "Gain"}
NB = 32


def _mono(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    return x if x.ndim == 1 else x.mean(axis=1)


def features(x: np.ndarray, sr: int) -> np.ndarray:
    """Wektor cech (znormalizowany do poziomu: obie strony skalowane do RMS=0,1 przed analizą)."""
    x = _mono(x)
    if len(x) < 2048:
        x = np.pad(x, (0, 2048 - len(x)))
    r = float(np.sqrt(np.mean(x ** 2))) or 1.0
    x = x * (0.1 / r)
    n, hop = 2048, 512
    nfr = 1 + (len(x) - n) // hop
    idx = np.arange(n)[None, :] + hop * np.arange(nfr)[:, None]
    mag = np.abs(np.fft.rfft(x[idx] * np.hanning(n), axis=1))
    fq = np.fft.rfftfreq(n, 1.0 / sr)
    edges = np.geomspace(40, min(16000, sr / 2 - 1), NB + 1)
    bands = np.stack([np.log10(mag[:, (fq >= edges[i]) & (fq < edges[i + 1])].sum(axis=1) + 1e-6) for i in range(NB)], axis=1)
    env = np.log10(np.sqrt(np.mean(x[: nfr * hop].reshape(nfr, hop) ** 2, axis=1)) + 1e-6)
    ev = np.interp(np.linspace(0, len(env) - 1, 16), np.arange(len(env)), env)
    f = [bands.mean(axis=0), bands.std(axis=0), ev - ev.mean()]
    lb = OD.load("librosa")
    if lb is not None:
        try:
            mf = lb.feature.mfcc(y=x.astype(np.float32), sr=sr, n_mfcc=13)
            f += [mf.mean(axis=1) / 20.0, mf.std(axis=1) / 20.0]
        except Exception:
            pass
    return np.concatenate(f)


def _dist(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.sqrt(np.mean((a - b) ** 2)))


def render_note(ttype: str, params: dict, key: int = 36, dur_beats: float = 2.0, bpm: int = 120, vel: int = 100) -> np.ndarray:
    """Jedna nuta przez dsrender (ścieżka jednego toru, 1 takt). -> (n,2) float32 @ core.SR."""
    from . import core
    p = core.new_project(bpm=bpm, bars=1)
    t = core.new_track(ttype)
    t["params"] = dict(params); t["notes"] = [[0.0, dur_beats, int(key), int(vel)]]; t["gain"] = 1.0
    p["tracks"] = [t]
    return core.render_stems(p, workers=1)[ttype]


def load_target(path) -> tuple[np.ndarray, int]:
    """WAV 16/24/32-bit lub float przez stdlib/numpy; inne formaty przez librosa (jeśli jest)."""
    import wave
    try:
        with wave.open(str(path), "rb") as w:
            sr, ch, sw, n = w.getframerate(), w.getnchannels(), w.getsampwidth(), w.getnframes()
            raw = w.readframes(n)
        if sw == 2:
            x = np.frombuffer(raw, "<i2").astype(np.float32) / 32768
        elif sw == 4:
            x = np.frombuffer(raw, "<i4").astype(np.float32) / 2147483648
        elif sw == 3:
            b = np.frombuffer(raw, np.uint8).reshape(-1, 3)
            v = (b[:, 0].astype(np.int32) | (b[:, 1].astype(np.int32) << 8) | (b[:, 2].astype(np.int32) << 16))
            x = np.where(v & 0x800000, v - 0x1000000, v).astype(np.float32) / 8388608
        else:
            raise ValueError("sampwidth")
        return x.reshape(-1, ch), sr
    except Exception:
        lb = OD.load("librosa")
        if lb is None:
            raise
        y, sr = lb.load(str(path), sr=None, mono=False)
        return (y.T if y.ndim > 1 else y[:, None]), int(sr)


def fit(ttype: str, target, key: int = 36, budget: int = 80, tune: list[str] | None = None, seed: int = 0,
        sr: int | None = None, dur_beats: float = 2.0, on_eval=None) -> dict:
    from . import core
    if isinstance(target, (str, bytes)) or hasattr(target, "__fspath__"):
        target, sr = load_target(target)
    sr = sr or core.SR
    ft = features(np.asarray(target), sr)
    m = core.meta()
    pm = m.plugins[core.PLUGIN_ID[ttype]]["params"]
    names = [n for n in (tune or list(pm)) if n in pm and n not in SKIP]
    x0 = np.array([m.def_frac(ttype, n) for n in names])
    evals = [0]

    def f(x):
        x = np.clip(x, 0.0, 1.0)
        a = render_note(ttype, {n: float(v) for n, v in zip(names, x)}, key, dur_beats)
        evals[0] += 1
        d = _dist(features(a, core.SR), ft)
        if on_eval:
            on_eval(evals[0], d)
        return d

    d0 = f(x0); best = (d0, x0.copy()); backend = "es"
    cma = OD.load("cma")
    if cma is not None and len(names) > 1:
        backend = "cma"
        es = cma.CMAEvolutionStrategy(x0.tolist(), 0.25, {"bounds": [0, 1], "seed": seed + 1, "maxfevals": budget, "verbose": -9,
                                                        "popsize": min(12, max(6, budget // 8))})
        while not es.stop() and evals[0] < budget:
            xs = es.ask(); ys = [f(np.array(x)) for x in xs]
            es.tell(xs, ys)
            i = int(np.argmin(ys))
            if ys[i] < best[0]:
                best = (ys[i], np.clip(np.array(xs[i]), 0, 1))
    else:                                                      # (1+1)-ES ze zmniejszanym krokiem
        rng = np.random.default_rng(seed); sig = 0.2
        while evals[0] < budget:
            y = np.clip(best[1] + rng.normal(0, sig, len(names)), 0, 1)
            d = f(y)
            if d < best[0]:
                best = (d, y); sig = min(0.4, sig * 1.3)
            else:
                sig = max(0.02, sig * 0.9)
    return {"params": {n: round(float(v), 5) for n, v in zip(names, best[1])}, "distance": best[0], "start_distance": d0,
            "evals": evals[0], "backend": backend, "type": ttype, "key": key}


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="dubstep_studio timbre")
    ap.add_argument("--type", required=True); ap.add_argument("--target", required=True)
    ap.add_argument("--key", type=int, default=36); ap.add_argument("--budget", type=int, default=80)
    ap.add_argument("--out"); a = ap.parse_args(argv)
    r = fit(a.type, a.target, key=a.key, budget=a.budget,
            on_eval=lambda i, d: print(f"  ocena {i:3d}  odległość {d:.4f}", flush=True) if i % 10 == 0 else None)
    print(f"\n{r['backend']}: odległość {r['start_distance']:.4f} → {r['distance']:.4f} w {r['evals']} renderach")
    print(json.dumps(r["params"], ensure_ascii=False))
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump(r, f, ensure_ascii=False, indent=1)
        print("zapisano:", a.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
