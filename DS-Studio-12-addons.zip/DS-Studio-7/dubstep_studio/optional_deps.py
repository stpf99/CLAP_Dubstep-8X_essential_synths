"""optional_deps.py — jedno miejsce, które mówi, które opcjonalne biblioteki pip są dostępne.

Rdzeń Studia (numpy + PyQt6 + opcjonalnie mido) działa bez niczego stąd. Moduły `audio_backend`, `symbolic_backend`,
`optimize`, `constraints`, `style_markov`, `timbre_fit` używają tych bibliotek TYLKO jeśli są zainstalowane i zawsze
mają wersję zapasową (numpy / losowanie), więc brak pakietu nigdy nie przerywa generacji.

CLI:  python3 -m dubstep_studio deps
"""
from __future__ import annotations

import importlib
import importlib.util

# nazwa_importu -> (pakiet pip, do czego)
OPTIONAL = {
    "librosa":           ("librosa",           "beat tracking, chroma_cqt, MFCC (audio_backend, timbre_fit)"),
    "pyloudnorm":        ("pyloudnorm",        "pomiar LUFS wg ITU BS.1770 (audio_backend, autolevel)"),
    "aubio":             ("aubio",             "tempo/onsety o niskim opóźnieniu (audio_backend, tryb Live)"),
    "essentia":          ("essentia",          "BPM / tonacja / danceability (audio_backend)"),
    "pretty_midi":       ("pretty_midi",       "histogram klas wysokości, eksport PrettyMIDI (symbolic_backend)"),
    "symusic":           ("symusic",           "szybki eksport/odczyt MIDI (symbolic_backend)"),
    "music21":           ("music21",           "niezależna estymacja tonacji (symbolic_backend, ciężka)"),
    "mir_eval":          ("mir_eval",          "metryki beat/melodia w testach (tests/test_ai_addons.py)"),
    "optuna":            ("optuna",            "optymalizacja parametrów generatora (optimize)"),
    "cmaes":             ("cmaes",             "sampler CMA-ES dla optuny (optimize)"),
    "cma":               ("cma",               "CMA-ES do dopasowania barwy (timbre_fit)"),
    "ortools":           ("ortools",           "CP-SAT — rozwiązywanie kolizji kick/bas (constraints)"),
    "miditok":           ("miditok",           "tokenizacja MIDI pod własny model (style_markov — tylko eksport tokenów)"),
    "hypothesis":        ("hypothesis",        "testy własności generatora (tests/test_ai_addons.py)"),
    "mido":              ("mido",              "odczyt/zapis MIDI (midi_import, style_markov, symbolic_backend)"),
    "scipy":             ("scipy",             "filtry K-weighting dla zapasowego LUFS (audio_backend)"),
}

_cache: dict[str, bool] = {}


def have(mod: str) -> bool:
    """True, jeśli moduł da się znaleźć (bez importowania — szybko, bez efektów ubocznych)."""
    if mod not in _cache:
        try:
            _cache[mod] = importlib.util.find_spec(mod) is not None
        except (ImportError, ValueError):
            _cache[mod] = False
    return _cache[mod]


def load(mod: str):
    """Importuje moduł albo zwraca None (także gdy import się wysypuje, np. zła wersja numpy)."""
    if not have(mod):
        return None
    try:
        return importlib.import_module(mod)
    except Exception:
        _cache[mod] = False
        return None


def status() -> dict[str, dict]:
    out = {}
    for mod, (pip, why) in OPTIONAL.items():
        out[mod] = {"pip": pip, "available": have(mod), "why": why}
    return out


def report() -> str:
    lines = []
    for mod, d in status().items():
        mark = "tak " if d["available"] else "brak"
        lines.append(f"  [{mark}] {mod:<12} pip install {d['pip']:<18} {d['why']}")
    n = sum(1 for d in status().values() if d["available"])
    return f"Opcjonalne zależności: {n}/{len(OPTIONAL)} dostępnych\n" + "\n".join(lines)


if __name__ == "__main__":
    print(report())
