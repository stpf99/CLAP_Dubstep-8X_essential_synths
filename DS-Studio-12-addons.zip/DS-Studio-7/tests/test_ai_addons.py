"""Testy dodatków pip (audio_backend, symbolic_backend, optimize, constraints, style_markov, timbre_fit) + testy własności generatora.

Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_ai_addons -v
Testy wymagające hosta (`make` → build/dsrender + wtyczki) i/lub opcjonalnych pakietów są pomijane, gdy ich brak;
czysta logika (zapasowe ścieżki bez pakietów) wykonuje się zawsze.
"""
import copy
import math
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import core, optional_deps as OD  # noqa: E402


def _host_ok():
    try:
        core.meta()
        return True
    except Exception:
        return False


HOST = _host_ok()
needs_host = unittest.skipUnless(HOST, "brak zbudowanego hosta (uruchom `make`)")


def needs(*mods):
    return unittest.skipUnless(all(OD.have(m) for m in mods), "brak pakietu: " + ", ".join(m for m in mods if not OD.have(m)))


def _gen(style="Brostep", bars=32, seed=3, **kw):
    from dubstep_studio import generator as G
    return G.generate(style, bars=bars, seed=seed, **kw)


def _pulse_train(bpm=128.0, dur=16.0, sr=48000):
    t = np.arange(int(dur * sr)) / sr
    x = np.zeros_like(t)
    beat = 60.0 / bpm
    for i in range(int(dur / beat)):
        s = int(i * beat * sr); n = int(0.15 * sr); tt = np.arange(n) / sr
        x[s:s + n] += np.sin(2 * np.pi * (50 + 90 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 18)
    for f in (220.0, 261.63, 329.63):
        x += 0.08 * np.sin(2 * np.pi * f * t)
    x = (x / np.abs(x).max() * 0.5).astype(np.float32)
    return np.stack([x, x], 1), sr


# ------------------------------------------------------------------ optional_deps
class TestOptionalDeps(unittest.TestCase):
    def test_report_lists_every_package(self):
        r = OD.report()
        for mod in OD.OPTIONAL:
            self.assertIn(mod, r)

    def test_missing_module_loads_as_none(self):
        self.assertIsNone(OD.load("ds_no_such_module_xyz"))
        self.assertFalse(OD.have("ds_no_such_module_xyz"))


# ------------------------------------------------------------------ audio_backend
class TestAudioBackend(unittest.TestCase):
    def setUp(self):
        from dubstep_studio import audio_backend as AB
        self.AB = AB
        self._saved = dict(OD._cache)

    def tearDown(self):
        OD._cache.clear(); OD._cache.update(self._saved)
        os.environ.pop("DS_AUDIO_BACKEND", None)

    def _sine(self, amp=0.5, f=1000.0, sec=3.0, sr=48000):
        t = np.arange(int(sec * sr)) / sr
        x = (amp * np.sin(2 * np.pi * f * t)).astype(np.float32)
        return np.stack([x, x], 1), sr

    def test_lufs_of_reference_sine_numpy_fallback(self):
        # sinus 1 kHz o amplitudzie A w obu kanałach: LUFS ≈ 20·log10(A/√2) − 0,691 + 10·log10(2) + K-waga(1 kHz ≈ +0,69) ≈ −6,0 dla A=0,5
        for mod in ("pyloudnorm",):
            OD._cache[mod] = False                       # wymuś zapas numpy/scipy
        st, sr = self._sine()
        v, src = self.AB.lufs(st, sr)
        self.assertIn(src, ("numpy-k", "rms-approx"))
        self.assertAlmostEqual(v, -6.0, delta=0.6)

    @needs("pyloudnorm")
    def test_lufs_pyloudnorm_agrees_with_fallback(self):
        st, sr = _pulse_train(dur=6.0)
        a, sa = self.AB.lufs(st, sr)
        OD._cache["pyloudnorm"] = False
        b, sb = self.AB.lufs(st, sr)
        self.assertEqual(sa, "pyloudnorm")
        if sb == "numpy-k":
            self.assertLess(abs(a - b), 0.5)

    def test_silence_is_minus_70(self):
        v, src = self.AB.lufs(np.zeros((48000, 2), np.float32), 48000)
        self.assertEqual((v, src), (-70.0, "silent"))

    def test_off_mode_leaves_features_untouched(self):
        from dubstep_studio import listen as L
        st, sr = _pulse_train(dur=8.0)
        os.environ["DS_AUDIO_BACKEND"] = "off"
        F = L.analyze_audio(st, sr)
        self.assertNotIn("lufs", F); self.assertNotIn("backends", F)

    def test_enhance_adds_lufs_and_keeps_core_keys(self):
        from dubstep_studio import listen as L
        st, sr = _pulse_train(dur=8.0)
        F = L.analyze_audio(st, sr)
        for k in ("bpm", "key", "bands", "energy", "lufs", "lufs_src"):
            self.assertIn(k, F)
        self.assertLess(F["lufs"], 0.0)

    @needs("librosa")
    def test_tempo_librosa_within_octave_tolerance(self):
        st, sr = _pulse_train(bpm=128.0, dur=16.0)
        r = self.AB.tempo_librosa(st.mean(axis=1), sr)
        self.assertIsNotNone(r)
        self.assertTrue(self.AB._same_tempo(128.0, r[0], tol=0.04), r)

    @needs("librosa")
    def test_fusion_never_lowers_a_confident_own_estimate(self):
        from dubstep_studio import listen as L
        st, sr = _pulse_train(bpm=128.0, dur=16.0)
        os.environ["DS_AUDIO_BACKEND"] = "off"
        own = L.analyze_audio(st, sr)
        del os.environ["DS_AUDIO_BACKEND"]
        fused = L.analyze_audio(st, sr)
        self.assertGreaterEqual(fused["tempo_conf"], own["tempo_conf"] - 1e-9)
        self.assertLess(abs(fused["bpm"] - 128.0) / 128.0, 0.04)


# ------------------------------------------------------------------ symbolic_backend
@needs_host
class TestSymbolicBackend(unittest.TestCase):
    def test_scale_conformity_high_for_generated(self):
        from dubstep_studio import symbolic_backend as SB
        for st in ("Brostep", "Riddim"):
            self.assertGreater(SB.scale_conformity(_gen(st, seed=2)), 0.85, st)

    def test_scale_conformity_detects_out_of_scale(self):
        from dubstep_studio import symbolic_backend as SB
        p = _gen(seed=2)
        for t in p["tracks"]:
            if t["type"] not in SB.UNPITCHED:
                t["notes"] = [[n[0], n[1], (n[2] // 12) * 12 + ((p["key"] + 1) % 12), n[3]] for n in t["notes"]]   # same półton nad tonika
        self.assertLess(SB.scale_conformity(p), 0.7)

    def test_key_estimate_finds_a_minor(self):
        from dubstep_studio import symbolic_backend as SB
        notes = []
        for i, k in enumerate([57, 60, 64, 57, 60, 64, 62, 65, 69, 55, 59, 62] * 3):
            notes.append([i * 0.5, 0.5, k, 90])
        proj = {"tracks": [{"type": "pluck", "notes": notes, "name": "p"}]}
        e = SB.key_estimate(proj)
        self.assertEqual((e["key"], e["mode"]), (9, "minor"))

    def test_sidechain_removes_clash(self):
        from dubstep_studio import symbolic_backend as SB
        p = _gen(seed=3, bars=64)
        with_links = SB.kick_bass_clash(p)
        q = copy.deepcopy(p); q["links"] = [l for l in q["links"] if l.get("src") != "kick"]
        self.assertLess(with_links, SB.kick_bass_clash(q))

    @needs("pretty_midi")
    def test_crosscheck_runs_with_pretty_midi(self):
        from dubstep_studio import symbolic_backend as SB
        r = SB.key_crosscheck(_gen(seed=3, bars=16))
        self.assertIn("pretty_midi_top_pc", r)


# ------------------------------------------------------------------ optimize
@needs_host
class TestOptimize(unittest.TestCase):
    def test_result_never_worse_than_defaults_random(self):
        from dubstep_studio import optimize as O
        r = O.optimize("Brostep", trials=4, seeds=(1,), sampler="random", bars=16)
        self.assertEqual(r["backend"], "random")
        self.assertGreaterEqual(r["best_score"], r["baseline_score"])
        self.assertEqual(r["trials"], 4)

    @needs("optuna")
    def test_result_never_worse_than_defaults_optuna(self):
        from dubstep_studio import optimize as O
        r = O.optimize("Brostep", trials=6, seeds=(1,), bars=16)
        self.assertTrue(r["backend"].startswith("optuna"))
        self.assertGreaterEqual(r["best_score"], r["baseline_score"])

    def test_fixed_kwargs_are_removed_from_search_space(self):
        from dubstep_studio import optimize as O
        r = O.optimize("Brostep", trials=2, seeds=(1,), sampler="random", bars=16, energy=0.9)
        self.assertNotIn("energy", r["best_params"])

    def test_objective_is_bounded_and_deterministic(self):
        from dubstep_studio import optimize as O
        a, _ = O.objective(_gen(seed=7)); b, _ = O.objective(_gen(seed=7))
        self.assertEqual(a, b); self.assertTrue(0.0 <= a <= 1.0)

    def test_generate_optimized_records_report(self):
        from dubstep_studio import optimize as O
        p = O.generate_optimized("Brostep", trials=3, seeds=(1,), sampler="random", bars=16, seed=5)
        self.assertIn("optimize", p); self.assertEqual(p["seed"], 5)

    def test_saturated_objective_is_reported(self):
        from dubstep_studio import optimize as O
        r = O.optimize("Brostep", trials=6, seeds=(1,), sampler="random", bars=32)
        if r["spread"] < 0.01:
            self.assertIn("nasycona", r["note"])


# ------------------------------------------------------------------ constraints
@needs_host
class TestConstraints(unittest.TestCase):
    def _unducked(self):
        p = _gen(seed=3, bars=64)
        p["links"] = [l for l in p["links"] if l.get("src") != "kick"]
        return p

    def _overlaps(self, p):
        n = 0
        for t in p["tracks"]:
            if t["type"] in ("sub", "wobble", "reese", "growl", "neuro"):
                ns = sorted(t["notes"], key=lambda x: x[0])
                n += sum(1 for a, b in zip(ns, ns[1:]) if a[0] + a[1] > b[0] + 1e-6)
        return n

    def test_reduces_clash_without_changing_note_count_or_adding_overlaps(self):
        from dubstep_studio import constraints as C
        p = self._unducked(); counts = {t["name"]: len(t["notes"]) for t in p["tracks"]}; ov0 = self._overlaps(p)
        r = C.apply(p, solver="greedy")
        self.assertLess(r["clash_after"], r["clash_before"])
        self.assertEqual(counts, {t["name"]: len(t["notes"]) for t in p["tracks"]})
        self.assertLessEqual(self._overlaps(p), ov0)

    @needs("ortools")
    def test_cpsat_matches_or_beats_greedy(self):
        from dubstep_studio import constraints as C
        a = C.apply(self._unducked(), solver="cpsat"); b = C.apply(self._unducked(), solver="greedy")
        self.assertEqual(a["solver"], "cpsat")
        self.assertLessEqual(a["clash_after"], b["clash_after"] + 1e-9)

    def test_budget_limits_number_of_changes(self):
        from dubstep_studio import constraints as C
        p = self._unducked(); n_bass = sum(len(t["notes"]) for t in p["tracks"] if t["type"] in C.SB.BASS)
        r = C.apply(p, max_changed=0.10, solver="greedy")
        self.assertLessEqual(r["trimmed"] + r["delayed"], math.ceil(0.10 * n_bass) + 8)     # +8: ceil per tor (≤ liczba torów basowych)

    def test_locked_track_untouched(self):
        from dubstep_studio import constraints as C
        p = self._unducked()
        for t in p["tracks"]:
            t["lock_notes"] = True
        before = copy.deepcopy([t["notes"] for t in p["tracks"]])
        C.apply(p)
        self.assertEqual(before, [t["notes"] for t in p["tracks"]])

    def test_reviewer_flag_is_opt_in(self):
        from dubstep_studio import musicality_reviewer as MR
        self.assertFalse(MR.DEFAULT_CFG["constraints"])
        p = _gen(seed=3, bars=32)
        MR.apply_symbolic(p, {"on": True, "mode": "symbolic", "intensity": 0.5, "constraints": True})
        self.assertIn("constraints_report", p)


# ------------------------------------------------------------------ style_markov
@needs_host
class TestStyleMarkov(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from dubstep_studio import style_markov as SM
        cls.SM = SM
        cls.corpus = [_gen(seed=s, bars=32) for s in range(8)]
        cls.model = SM.from_projects(cls.corpus, "hat")

    def test_sample_is_deterministic_and_in_range(self):
        a = self.SM.sample(self.model, 4, random.Random(1)); b = self.SM.sample(self.model, 4, random.Random(1))
        self.assertEqual(a, b)
        self.assertTrue(all(0 <= n[0] < 16 and 1 <= n[3] <= 127 and n[2] == self.model["key"] for n in a))

    def test_low_temperature_is_closer_to_corpus_density(self):
        dens = lambda ns, bars: len(ns) / bars
        corpus_d = np.mean([dens([n for t in p["tracks"] if t["type"] == "hat" for n in t["notes"]], p["bars"]) for p in self.corpus])
        cold = np.mean([dens(self.SM.sample(self.model, 16, random.Random(s), 0.5), 16) for s in range(6)])
        self.assertLess(abs(cold - corpus_d), corpus_d * 0.6)

    def test_apply_respects_lock_and_sections(self):
        p = _gen(seed=99, bars=32)
        hat = next(t for t in p["tracks"] if t["type"] == "hat")
        hat["lock_notes"] = True; before = copy.deepcopy(hat["notes"])
        self.SM.apply(p, self.model, strength=1.0)
        self.assertEqual(before, hat["notes"])

    def test_apply_only_touches_chosen_sections(self):
        p = _gen(seed=99, bars=32)
        hat = next(t for t in p["tracks"] if t["type"] == "hat"); before = copy.deepcopy(hat["notes"])
        r = self.SM.apply(p, self.model, strength=1.0, section_types=("drop",))
        drop = [(s["start"] * 4.0, (s["start"] + s["bars"]) * 4.0) for s in p["sections"] if s["type"] == "drop"]
        inside = lambda x: any(a <= x < b for a, b in drop)
        self.assertEqual([n for n in before if not inside(n[0])], [n for n in hat["notes"] if not inside(n[0])])
        self.assertGreater(r["bars_replaced"], 0)

    def test_empty_corpus_raises(self):
        with self.assertRaises(ValueError):
            self.SM.from_projects(self.corpus, "no_such_role")

    @needs("mido")
    def test_midi_roundtrip_training(self):
        p = self.corpus[0]
        with tempfile.TemporaryDirectory() as d:
            core.write_midi(p, d + "/a.mid")
            m = self.SM.from_midi([d + "/a.mid"], "hat")
        self.assertGreater(m["n_bars"], 0)


# ------------------------------------------------------------------ timbre_fit
@needs_host
class TestTimbreFit(unittest.TestCase):
    def test_fit_reduces_distance_to_known_target(self):
        from dubstep_studio import timbre_fit as TF
        m = core.meta(); tt = "wobble"
        names = [n for n in m.plugins[core.PLUGIN_ID[tt]]["params"] if n not in TF.SKIP]
        rng = random.Random(4)
        target = TF.render_note(tt, {n: rng.random() for n in names}, 36)
        r = TF.fit(tt, target, key=36, budget=40, seed=0)
        self.assertLess(r["distance"], 0.6 * r["start_distance"])
        self.assertLessEqual(r["evals"], 40 + 12)                          # budżet + ostatnia populacja CMA

    def test_features_are_level_invariant(self):
        from dubstep_studio import timbre_fit as TF
        a = TF.render_note("sub", {}, 36)
        self.assertLess(TF._dist(TF.features(a, core.SR), TF.features(a * 0.25, core.SR)), 0.02)


# ------------------------------------------------------------------ testy własności generatora (hypothesis)
if OD.have("hypothesis") and HOST:
    from hypothesis import HealthCheck, given, settings, strategies as st

    from dubstep_studio import generator as _G
    STYLES = list(_G.STYLES)                    # wszystkie style generatora (63 w tej wersji)

    class TestGeneratorProperties(unittest.TestCase):
        @settings(max_examples=25, deadline=None, suppress_health_check=list(HealthCheck))
        @given(style=st.sampled_from(STYLES), seed=st.integers(0, 10_000), bars=st.sampled_from([16, 32]),
               energy=st.floats(0.3, 1.0), density=st.floats(0.3, 0.9))
        def test_notes_are_valid(self, style, seed, bars, energy, density):
            from dubstep_studio import generator as G
            p = G.generate(style, bars=bars, seed=seed, energy=energy, density=density)
            self.assertTrue(p["tracks"])
            for t in p["tracks"]:
                for n in t["notes"]:
                    self.assertGreaterEqual(len(n), 4, (t["name"], n))
                    self.assertGreaterEqual(n[0], 0.0, (t["name"], n)); self.assertGreater(n[1], 0.0, (t["name"], n))
                    self.assertTrue(0 <= int(n[2]) <= 127, (t["name"], n)); self.assertTrue(1 <= int(n[3]) <= 127, (t["name"], n))
            self.assertEqual(core.sanitize_notes(p), 0, "generate() zostawił nuty, które sanitize_notes musiał poprawiać")

        @settings(max_examples=10, deadline=None, suppress_health_check=list(HealthCheck))
        @given(seed=st.integers(0, 10_000))
        def test_same_seed_same_project(self, seed):
            a = _gen(seed=seed, bars=16); b = _gen(seed=seed, bars=16)
            self.assertEqual([t["notes"] for t in a["tracks"]], [t["notes"] for t in b["tracks"]])


# ------------------------------------------------------------------ audio-level: beat tracking vs siatka (mir_eval)
@needs_host
@needs("librosa", "mir_eval")
class TestRenderedBeatGrid(unittest.TestCase):
    def test_rendered_kick_grid_matches_detected_beats(self):
        import mir_eval
        import librosa
        bpm, bars = 128, 8
        p = core.new_project(bpm=bpm, bars=bars)
        k = core.new_track("kick"); k["notes"] = [[float(b), 0.1, 36, 110] for b in range(bars * 4)]; k["gain"] = 1.0
        h = core.new_track("hat"); h["notes"] = [[b + 0.5, 0.05, 42, 70] for b in range(bars * 4)]; h["gain"] = 0.5
        p["tracks"] = [k, h]
        mix = core.render_mix(p, workers=1)
        y = mix.mean(axis=1).astype(np.float32)
        _, beats = librosa.beat.beat_track(y=librosa.resample(y, orig_sr=core.SR, target_sr=22050), sr=22050, units="time")
        ref = np.arange(bars * 4) * 60.0 / bpm
        beats = np.asarray(beats)
        f = max(mir_eval.beat.f_measure(ref, beats), mir_eval.beat.f_measure(ref, beats[1:]) if len(beats) > 1 else 0.0)
        self.assertGreater(f, 0.6, f"F-measure beatów {f:.2f}")


if __name__ == "__main__":
    unittest.main()
