"""python3 -m dubstep_studio            -> GUI
   python3 -m dubstep_studio gen ...   -> generuj z CLI (--style --bpm --bars --seed --key --save)
   python3 -m dubstep_studio list      -> lista biblioteki
   python3 -m dubstep_studio remix A B C [--bpm N] [--key 0-11]  (ID folderów z biblioteki; pierwszy = master)
   python3 -m dubstep_studio live [--config PLIK] [--random] [--no-local]   -> strumień Live/Endless bez GUI (np. na serwerze, nadawanie do Icecast2 wg config.txt)"""
import argparse
import os
import random
import signal
import sys
import time

from . import config as CF, core, generator as G, live as L, remix as R


def run_live(a):
    conf = CF.load(); cfg = CF.to_live_cfg(conf, L.DEFAULT_CFG)
    if a.random:
        cfg["mode"] = "random"
    ice = conf["icecast"]; local = (ice["local_playback"] and not a.no_local) or not ice["enabled"]
    stop = []

    def on_event(kind, **kw):
        if kind == "planning":
            print(f"[plan] #{kw['idx'] + 1}: {kw['plan']['desc']}", flush=True)
        elif kind == "playing":
            print(f"[play] {eng.arrs[kw['idx']].label()}", flush=True)
        elif kind == "error":
            print(kw["msg"], file=sys.stderr, flush=True)
    eng = L.LiveEngine(on_event)
    eng.set_cfg(cfg); eng.set_base(CF.to_base(conf)); eng.set_output(ice, local)

    def reload(*_):                      # SIGHUP: ponownie wczytaj config.txt (bez przerywania strumienia)
        c = CF.load(conf["path"]); eng.set_cfg(CF.to_live_cfg(c, L.DEFAULT_CFG)); eng.set_base(CF.to_base(c))
        eng.set_output(c["icecast"], (c["icecast"]["local_playback"] and not a.no_local) or not c["icecast"]["enabled"]); print("[config] przeładowano", flush=True)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, reload)
    signal.signal(signal.SIGTERM, lambda *_: stop.append(1))
    print(f"Live: config={conf['path']} tryb={cfg['mode']} icecast={'tak → ' + ice['host'] + ':' + str(ice['port']) + ice['mount'] if ice['enabled'] else 'nie'} lokalnie={'tak' if local else 'nie'}", flush=True)
    eng.start(); last = ""; interrupted = False
    try:
        while eng.running and not stop:
            time.sleep(1.0)
            st = eng.out_status()["icecast"]
            if ice["enabled"] and st != last:
                print(f"[icecast] {st}", flush=True); last = st
    except KeyboardInterrupt:
        interrupted = True
    failed = not eng.running and not stop and not interrupted      # silnik sam się zatrzymał (np. brak odtwarzacza)
    eng.stop(); print("Zatrzymano. Magazyn:", eng.session)
    return 1 if failed else 0


def main():
    for i, x in enumerate(sys.argv):         # --config PLIK działa też przed wczytaniem ustawień
        if x == "--config" and i + 1 < len(sys.argv):
            os.environ["DS_CONFIG"] = sys.argv[i + 1]
    CF.apply_env(CF.load())
    if len(sys.argv) < 2 or sys.argv[1] == "gui":
        from .gui import main as gui_main
        return gui_main()
    ap = argparse.ArgumentParser(prog="dubstep_studio")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("gen"); g.add_argument("--style", default="Brostep", choices=list(G.STYLES)); g.add_argument("--bpm", type=int)
    g.add_argument("--bars", type=int, default=144); g.add_argument("--seed", type=int); g.add_argument("--key", type=int)
    g.add_argument("--instruments", default="style", help="style | core8 | all | lista,po,przecinku"); g.add_argument("--scale", default="minor", choices=list(core.SCALES)); g.add_argument("--save", action="store_true")
    g.add_argument("--speak-text", default=None, help="ręczny tekst DS Speak (włącz instrument: --instruments style,speak lub ...,speak)")
    g.add_argument("--speak-theme", default=None, choices=list(G.SPEAK_THEMES), help="motyw tekstu auto")
    sub.add_parser("list")
    lv = sub.add_parser("live"); lv.add_argument("--config"); lv.add_argument("--random", action="store_true", help="wymuś tryb losowania kaskadowego"); lv.add_argument("--no-local", action="store_true", help="nie graj lokalnie, tylko nadawaj")
    r = sub.add_parser("remix"); r.add_argument("ids", nargs="+"); r.add_argument("--bpm", type=int); r.add_argument("--key", type=int)
    r.add_argument("--seed", type=int)
    a = ap.parse_args(sys.argv[1:])
    if a.cmd == "live":
        return run_live(a)
    if a.cmd == "gen":
        inst = {"style": None, "core8": core.CORE8, "all": core.available_types()}.get(a.instruments) or a.instruments.split(",")
        if a.instruments == "style" and (a.speak_text or a.speak_theme):
            inst = G.default_instruments(a.style) + ["speak"]       # podanie tekstu włącza mowę
        p = G.generate(a.style, bpm=a.bpm, key=a.key, scale=a.scale, bars=a.bars, seed=a.seed, instruments=inst,
                       speak_text=a.speak_text, speak_theme=a.speak_theme)
        print(f"{p['name']}: {core.key_name(p)} {p['bpm']} BPM {p['bars']} taktów")
        if a.save:
            print(core.save_to_library(p))
    elif a.cmd == "list":
        for e in core.list_library():
            print(f"{e['path'].name}\t{e['style']}\t{e['bpm']}\t{e['key']}\t{e['bars']}")
    elif a.cmd == "remix":
        projs = []
        for i in a.ids:
            p = core.load_project(core.lib_dir() / i); p["id"] = i; projs.append(p)
        master = projs[0]
        if len(projs) > 1:
            _, assign = R.auto_assign(projs, random.Random(a.seed))
        else:
            assign = {t["name"]: master for t in master["tracks"]}
        out = R.remix(assign, master, bpm=a.bpm, key=a.key, seed=a.seed or 0)
        print({t: (x["id"] if x else None) for t, x in assign.items()}); print(core.save_to_library(out))


if __name__ == "__main__":
    sys.exit(main() or 0)
