"""presets.py — GLOBALNE presety (domyślnie puste): jeden plik JSON współdzielony przez GUI i tryb bez GUI.

Preset zapamiętuje: ustawienia zakładki Generator (styl — także hybrydę, BPM, tonacja, skala, takty, energia, gęstość, swing, instrumenty, Speak),
pole szachowe (komórki + siła mutacji) oraz tryb auto Live (tryb, blokady, pory dnia, takty, wyprzedzenie, mutacje).
Preset NIE zawiera ustawień Icecast (hasła zostają tylko w config.txt).

Plik: $DS_PRESETS albo [paths] presets z config.txt albo ~/DubstepStudio/presets.json. Nie istnieje, dopóki nie zapiszesz pierwszego presetu.
"""
from __future__ import annotations

import datetime
import json
import os
from pathlib import Path


def path() -> Path:
    return Path(os.environ["DS_PRESETS"]) if os.environ.get("DS_PRESETS") else Path.home() / "DubstepStudio" / "presets.json"


def load_all() -> dict:
    p = path()
    if not p.exists():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_all(d: dict):
    p = path(); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp"); tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8"); tmp.replace(p)


def names() -> list:
    return sorted(load_all(), key=str.lower)


def get(name):
    return load_all().get(name, {}).get("data")


def put(name, data):
    d = load_all(); d[name] = {"saved": datetime.datetime.now().isoformat(timespec="seconds"), "data": data}; save_all(d)


def delete(name):
    d = load_all()
    if d.pop(name, None) is not None:
        save_all(d)


def export_file(name, out):
    d = load_all()
    Path(out).write_text(json.dumps({name: d[name]}, ensure_ascii=False, indent=1), encoding="utf-8")


def import_file(src) -> list:
    """Dołącza presety z pliku (istniejące o tej samej nazwie są zastępowane). -> lista nazw."""
    inc = json.loads(Path(src).read_text(encoding="utf-8"))
    inc = {k: v for k, v in inc.items() if isinstance(v, dict) and isinstance(v.get("data"), dict)}
    d = load_all(); d.update(inc); save_all(d)
    return list(inc)


def to_engine(data):
    """Preset -> (baza generatora, nadpisania Live). Pełne flagi przez GenOptions."""
    from .gen_options import GenOptions
    g = dict(data.get("generator") or {})
    live = dict(data.get("live") or {})
    board = data.get("board") or {}
    live["board"] = board.get("cells", [])
    live["board_strength"] = board.get("strength", 0.4)
    live["use_board"] = bool(live.get("use_board"))
    if "mutate_p" in live:
        live["mutate_p"] = float(live["mutate_p"])
    if g.get("speak_manual") is False:
        g["speak_text"] = None
    base = GenOptions.from_dict(g).to_base_dict()
    if base.get("instruments") == []:
        base["instruments"] = None
    return base, live
