"""gen_options.py — jedna definicja opcji Generatora (GUI / Live / preset / config / CLI).

Zamiast kopiować listy pól w 5 miejscach: GenOptions.from_dict / to_kwargs / to_base_dict.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from typing import Any, Optional


# Pola przekazywane do generator.generate(**kwargs) — bez style/bpm/… podstawowych,
# które też tu są, żeby z jednego miejsca zbierać pełny snapshot.
_GENERATE_KEYS = (
    "style", "bpm", "key", "scale", "bars", "energy", "swing", "density", "seed", "name",
    "instruments", "speak_text", "speak_theme",
    "smart_instruments", "autolevels", "role_swap", "scenarios", "character", "director",
    "niuanse", "niuanse_strength", "spectacle", "era",
    "uniq", "uniq_strength", "uniq_drops",
    "replace_rules", "replace_on", "replace_policy",
    "health", "arp", "structure_affinity", "affinity_passes",
)


@dataclass
class GenOptions:
    style: str = "Brostep"
    bpm: Optional[int] = None
    key: Optional[int] = None
    scale: str = "minor"
    bars: int = 144
    energy: float = 0.7
    swing: Optional[float] = None
    density: float = 0.6
    seed: Optional[int] = None
    name: Optional[str] = None
    instruments: Any = None
    speak_text: Optional[str] = None
    speak_theme: Optional[str] = None
    smart_instruments: bool = False
    autolevels: bool = False
    role_swap: bool = False
    scenarios: bool = False
    character: str = "balanced"
    director: Any = None
    niuanse: bool = False
    niuanse_strength: float = 0.0
    spectacle: str = "balanced"
    era: str = "auto"
    uniq: bool = False
    uniq_strength: float = 0.6
    uniq_drops: bool = False
    replace_rules: Any = None
    replace_on: bool = False
    replace_policy: Any = None
    health: Any = None
    arp: Any = None
    structure_affinity: bool = False
    affinity_passes: int = 2
    # pola tylko snapshot (preset GUI), nie idą do generate()
    style_base: Optional[str] = None
    speak_manual: bool = False

    def to_kwargs(self) -> dict:
        """Argumenty pod generator.generate(**kwargs)."""
        d = asdict(self)
        return {k: d[k] for k in _GENERATE_KEYS if k in d}

    def to_base_dict(self) -> dict:
        """Baza Live / plan_next (bez seed/name/bars opcjonalnie pełne)."""
        return self.to_kwargs()

    def to_preset_generator(self) -> dict:
        """Sekcja generator w JSON presetu."""
        d = asdict(self)
        # usuń None zbędne
        return {k: v for k, v in d.items() if k != "seed"}

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "GenOptions":
        if not d:
            return cls()
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})

    def merge(self, other: Optional[dict]) -> "GenOptions":
        """Nadpisz polami z other (np. bundle złożoności)."""
        if not other:
            return self
        base = asdict(self)
        known = {f.name for f in fields(self)}
        for k, v in other.items():
            if k in known and v is not None:
                base[k] = v
        return GenOptions(**base)
