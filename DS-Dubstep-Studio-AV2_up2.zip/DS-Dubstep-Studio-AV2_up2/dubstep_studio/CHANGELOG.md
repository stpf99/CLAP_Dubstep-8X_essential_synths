# DS Dubstep Studio — poprawki (rundy 1–3)

## Runda 1 — błędy z testów
- gui preview extras/timbre: miks stemów → WAV
- clamp MIDI 0..127 (generate + write_midi)
- arp_engine: zlib.crc32 zamiast hash()
- live.plan_next: brak empty range przy 1 extra
- director.apply_roles: lock_notes / lock_sound
- live._gen_extras_from_base: max() siły, autolevels default False
- eco._next_no: flock
- cleanup_stale_work: glob dsr[0-9]*_*
- render_stems: eviction cache + timeout 120s

## Runda 2 — założenia
- Presety: pełny zestaw flag Generatora
- SIGHUP: zachowuje --preset; apply_env(force=True)
- config: atomowy zapis 600, aliasy Bb/Db, błąd przy duplikacie klucza
- Icecast log: maskowanie URL-encoded hasła
- Meta: błędy dsrender --dump w komunikacie
- available_types NameError; role_swap z reżysera
- README: 32 wtyczki

## Runda 3 — uporządkowanie
- **GenOptions** (`gen_options.py`): jedna dataclass; `to_kwargs` / `from_dict` / `to_base_dict`
  - użyte w: presets.to_engine, live_gui.collect_base, config.to_base
  - `generate()` → `generate_opts(GenOptions)` (też `generate(GenOptions(...))`)
- **Martwy kod scenario** w generator.py usunięty (~246 linii: mutate/analyze/correct/build_scenario);
  logika scenariusza: `scenario.py`
- **live.py**: logging; `_emit`, AV begin/stop, begin_av — `log.exception` zamiast cichego `pass`
  (pozostałe except przy cleanup stdin/kill zostawione świadomie)

## Świadomie nadal otwarte
- Hasło Icecast w argv ffmpeg (ograniczenie narzędzia)
- Prebuilt build/*.clap w źródłach
- Pełne rozbicie generate_opts na osobne pliki etapów (body wciąż monolityczne, ale wejście przez GenOptions)
- Część except przy zamykaniu pipe/process (BrokenPipe / cleanup) — celowo ciche
