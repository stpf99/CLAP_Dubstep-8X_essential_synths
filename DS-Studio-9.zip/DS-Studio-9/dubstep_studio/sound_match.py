"""sound_match.py — dopasowanie brzmienia DS-* do wzorcowego sampla (cma + odległość MFCC).

Cel: mieć sample-owy punkt odniesienia (np. wobble z konkretnej płyty) i dobrać
parametry wtyczki DS-<Typ> tak, by odległość MFCC(renderowanego toru, wzorca)
była minimalna. Optymalizatorzy (wszyscy opcjonalni):

  cma (CMA-ES)  — gradient-free, dobrze radzi sobie z tym właśnie typu zadaniem
  optuna (TPE)  — gdy brak cma
  random search — zawsze dostępny (bez zależności), wolniejszy

MFCC: librosa (jeśli jest) — w przeciwnym razie własna implementacja numpy
(mel-pasma + log + DCT), więc moduł działa bez librosa.

Użycie:
  python3 -m dubstep_studio soundmatch --type wobble --target wzor.wav --out params.json
  (params.json → tr['params'] w GUI/CLI; patrz apply_match)

Wymaga zbudowanego hosta (render w pamięci). Nie modyfikuje projektów użytkownika.
"""
from __future__ import annotations

import copy
import math
import random

import numpy as np

try:  # opcjonalnie
    import cma
except ImportError:  # pragma: no cover
    cma = None

try:  # opcjonalnie
    import librosa
except ImportError:  # pragma: no cover
    librosa = None


# ---------------------------------------------------------------------------
# Wektory cech (MFCC + centroid) — librosa albo numpy
# ---------------------------------------------------------------------------
def mfcc_vector(mono: np.ndarray, sr: int) -> tuple[np.ndarray, float]:
    """(13-wsp. średni MFCC, centroid Hz) — deterministycznie, bez zależności."""
    if mono.ndim != 1:
        mono = mono.mean(axis=1)
    mono = np.asarray(mono, dtype=np.float32)
    if len(mono) < sr // 8:
        raise ValueError("sygnał zbyt krótki do analizy")
    if librosa is not None:
        try:
            M = librosa.feature.mfcc(y=mono, sr=sr, n_mfcc=13)
            c = float(librosa.feature.spectral_centroid(y=mono, sr=sr).mean())
            return M.mean(axis=1).astype(np.float64), c
        except Exception:
            pass
    return _mfcc_numpy(mono, sr)


def _mfcc_numpy(mono: np.ndarray, sr: int) -> tuple[np.ndarray, float]:
    n, hop = 2048, 512
    nfr = 1 + max(0, (len(mono) - n)) // hop
    idx = np.arange(n)[None, :] + hop * np.arange(nfr)[:, None]
    frames = mono[idx] * np.hanning(n).astype(np.float32)
    mag = np.abs(np.fft.rfft(frames, axis=1))
    fq = np.fft.rfftfreq(n, 1.0 / sr)
    centroid = float((fq * mag).sum(axis=1).mean() / (mag.sum() + 1e-12))
    # mel-pasma 26
    def hz2mel(f):
        return 2595.0 * math.log10(1.0 + f / 700.0)

    def mel2hz(m):
        return 700.0 * (10.0 ** (m / 2595.0) - 1.0)

    mlo, mhi = hz2mel(40.0), hz2mel(min(16000.0, sr / 2 - 100))
    centers = np.array([mel2hz(mlo + (mhi - mlo) * (i + 0.5) / 26) for i in range(26)])
    bins = np.clip(np.searchsorted(fq, centers), 1, len(fq) - 1)
    P = (mag ** 2)
    bands = np.stack([P[:, b - 1: b + 2].sum(axis=1) for b in bins], axis=1)
    L = np.log10(bands + 1e-10)
    # DCT-II (13 pierwszych współczynników)
    K = 13
    k = np.arange(K)[:, None]
    nn = np.arange(26)[None, :]
    dct = np.cos(math.pi * k * (nn + 0.5) / 26) * math.sqrt(2.0 / 26)
    return (dct @ L.T).mean(axis=1).astype(np.float64), centroid


def feature_distance(a: tuple[np.ndarray, float], b: tuple[np.ndarray, float]) -> float:
    """0 = identyczne; kosinus MFCC + względna różnica centroidu."""
    x, y = a[0], b[0]
    d = 1.0 - float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y) + 1e-12))
    dc = abs(a[1] - b[1]) / max(400.0, min(a[1], b[1]))
    return max(0.0, 0.75 * d + 0.25 * min(1.0, dc))


# ---------------------------------------------------------------------------
# Sonda: projekt z jednym torem + render
# ---------------------------------------------------------------------------
def _probe_project(ttype: str, style: str, bars: int, seed: int):
    from . import generator as G
    style = style if style in G.STYLES else "Brostep"
    proj = G.generate(style=style, bars=bars, instruments=[ttype], seed=seed,
                      energy=0.7, density=0.6, autolevels=False)
    # zostaw tylko tor docelowy (mowa/extras niepotrzebne tu)
    keep = [t for t in proj["tracks"] if t.get("type") == ttype]
    if not keep:
        raise RuntimeError(f"Nie udało się wygenerować toru typu {ttype}")
    proj["tracks"] = keep
    proj["links"] = []
    return proj


def _render_stem_mono(proj: dict, track_name: str) -> np.ndarray:
    from . import core
    stems = core.render_stems(proj, workers=1)
    a = stems.get(track_name)
    if a is None or len(a) < 1024:
        raise RuntimeError("Render toru nie dał sygnału")
    return np.asarray(a, dtype=np.float32).mean(axis=1)


def _target_mono(target, sr: int) -> np.ndarray:
    if isinstance(target, np.ndarray):
        mono = target.mean(axis=1) if target.ndim == 2 else target
        return np.asarray(mono, np.float32)
    from . import listen as L
    st = L.load_audio_file(str(target), rate=sr, max_sec=30.0)
    return st.mean(axis=1)


# ---------------------------------------------------------------------------
# Dopasowanie
# ---------------------------------------------------------------------------
def match_track(ttype: str, target, style: str | None = None, trials: int = 60,
                seed: int | None = None, bars: int = 8, verbose: bool = False) -> dict:
    """Optymalizuje parametry SOUND[ttype] pod minimalną odległość MFCC do `target`.

    target: ścieżka pliku audio (ffmpeg) albo ndarray (mono/stereo, core.SR).
    Zwraca {"params": {nazwa: frac 0..1}, "score": dystans, "similarity": 0..1,
            "backend": "cma"|"optuna"|"random", "type": ttype}.
    `params` są gotowe do tr["params"].update(...) — jednostki ułamkowe jak w Studio."""
    from . import core
    from . import generator as G
    m = core.meta()
    seed = int(seed if seed is not None else random.randrange(1000000))
    rng = random.Random(seed)

    spec = {p[0]: p for p in G.SOUND.get(ttype, [])}
    _style = style if style in G.STYLES else "Brostep"
    for p in G.style_sound({"style": _style, "seed": seed}, {"type": ttype, "name": ttype}):
        spec[p[0]] = p
    keys, los, his = [], [], []
    for name, sp in spec.items():
        if sp[1] == "r" and m.has(ttype, name):
            keys.append(name)
            los.append(float(sp[2]))
            his.append(float(sp[3]))
    if not keys:
        raise RuntimeError(f"Brak parametrów ciągłych dla typu {ttype}")

    tgt_feat = mfcc_vector(_target_mono(target, core.SR), core.SR)
    base = _probe_project(ttype, style or "Brostep", bars, seed)
    track_name = base["tracks"][0]["name"]

    def dist_of(vec01: list[float]) -> float:
        proj = copy.deepcopy(base)
        tr = proj["tracks"][0]
        tr.setdefault("params", {})
        for k, t, lo, hi in zip(keys, vec01, los, his):
            eng = lo + (hi - lo) * max(0.0, min(1.0, t))
            tr["params"][k] = m.eng2frac(ttype, k, eng)
        try:
            mono = _render_stem_mono(proj, track_name)
            feat = mfcc_vector(mono, core.SR)
            return feature_distance(feat, tgt_feat)
        except Exception as ex:
            if verbose:
                print(f"  pomiar nieudany ({ex}); duża kara")
            return 10.0

    x0 = [0.5] * len(keys)
    backend = "random"
    if cma is not None:
        backend = "cma"
        try:
            es = cma.CMAEvolutionStrategy(x0, 0.25, {"bounds": [0.0, 1.0], "seed": seed,
                                                      "verbose": -9, "maxfevals": max(8, trials)})
            while not es.stop():
                xs = es.ask()
                es.tell(xs, [dist_of(x) for x in xs])
            best = list(es.result.xbest)
            best_d = float(es.result.fbest)
        except Exception:
            backend = "random"
            best, best_d = None, None
    if best is None:
        try:  # optuna, gdy cma nieosiągalne
            from . import optimizer as OPT
            if OPT.optuna is not None:
                backend = "optuna"
                import optuna as _o
                _o.logging.set_verbosity(_o.logging.WARNING)
                study = _o.create_study(direction="minimize",
                                         sampler=_o.samplers.TPESampler(seed=seed))
                study.optimize(lambda t: dist_of([t.suggest_float(k, 0.0, 1.0) for k in keys]),
                               n_trials=max(8, trials))
                best = [study.best_params[k] for k in keys]
                best_d = float(study.best_value)
            else:
                raise ImportError
        except Exception:
            backend = "random"
            best, best_d = None, None
    if best is None:  # random search — zawsze działa
        best, best_d = None, 1e9
        for _ in range(max(8, trials)):
            x = [rng.random() for _ in keys]
            d = dist_of(x)
            if d < best_d:
                best, best_d = x, d

    params = {}
    for k, t, lo, hi in zip(keys, best, los, his):
        eng = lo + (hi - lo) * max(0.0, min(1.0, t))
        params[k] = m.eng2frac(ttype, k, eng)
    return {"type": ttype, "params": params, "score": round(float(best_d), 4),
            "similarity": round(max(0.0, min(1.0, 1.0 / (1.0 + float(best_d)))), 3),
            "backend": backend, "engine": {"style": style or "Brostep", "bars": bars, "seed": seed}}


def apply_match(proj: dict, track_name: str, result: dict, lock: bool = False) -> dict:
    """Nakłada wynik match_track na tor projektu (in-place). Zwraca proj."""
    from . import core
    tr = core.find_track(proj, track_name)
    if tr is None:
        raise KeyError(f"Nie ma toru {track_name}")
    tr.setdefault("params", {}).update(result.get("params") or {})
    if lock:
        tr["lock_sound"] = True
    return proj
