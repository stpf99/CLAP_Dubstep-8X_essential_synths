"""tests/test_property.py — testy własności generatora (hypothesis, opcjonalnie).

Zwykłe testy przy losowym generatorze łapią tylko to, co trafi się przy danym seedzie.
Tu sprawdzamy NIESKONCZONĄ rodzinę wejść: zakresy nut, velocity, idempotencję
sanitize_notes, okna smart_param_window, własności fold_key/_clamp_notes, normy
scenariusza (analyze/correct) i twarde ograniczenia (solve_register).

Uruchomienie:  python3 -m unittest tests.test_property -v
Bez hypothesis: testy są pomijane (pakiety opcjonalne — rdzeń działa bez nich).
Bez hosta: tylko testy czystej logiki (jak w test_fixes).
"""
import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import core, generator as G, musicality_reviewer as MR  # noqa: E402
from dubstep_studio import constraint_solver as CS  # noqa: E402

try:
    from hypothesis import given, settings, strategies as st, HealthCheck
    HAS_HYP = True
except ImportError:  # pragma: no cover
    HAS_HYP = False

needs_hyp = unittest.skipUnless(HAS_HYP, "brak hypothesis (pip install hypothesis)")


def _host_ok():
    try:
        core.meta()
        return True
    except Exception:
        return False


HOST = _host_ok()
needs_host = unittest.skipUnless(HOST, "brak zbudowanego hosta (uruchom `make`)")

_SUPPRESS = [HealthCheck.too_slow] if HAS_HYP else []
_FAST = settings(max_examples=80, suppress_health_check=_SUPPRESS) if HAS_HYP else None
_ROLES = ["kick", "snare", "hat", "clap", "sub", "bass", "lead", "pad", "perc"]


def _synth_proj(notes_by_type=None, seed=1):
    p = core.new_project(bars=16, seed=seed, style="Brostep", energy=0.7, density=0.6)
    p["tracks"] = []
    for tt, notes in (notes_by_type or {}).items():
        p["tracks"].append(dict(name=tt, type=tt, notes=[list(n) for n in notes],
                                 params={}, gain=0.5, mute=False, solo=False))
    return p


# ---------------------------------------------------------------- czysta logika
@needs_hyp
class TestNoteBasics(unittest.TestCase):

    @_FAST
    @given(st.integers(-(10 ** 6), 10 ** 6))
    def test_fold_key_zakres_i_klasa_wysokosci(self, k):
        k2 = core.fold_key(k)
        self.assertTrue(0 <= k2 <= 127)
        self.assertEqual(k2 % 12, k % 12)          # klasa wysokości zachowana

    @_FAST
    @given(st.integers(-10 ** 6, 10 ** 6))
    def test_clamp_vel_zakres(self, v):
        v2 = core.clamp_vel(v)
        self.assertTrue(1 <= v2 <= 127)

    @_FAST
    @given(st.lists(st.tuples(st.floats(0.0, 400.0, allow_nan=False, allow_infinity=False),
                              st.floats(0.01, 8.0, allow_nan=False, allow_infinity=False),
                              st.integers(-260, 390), st.integers(-60, 300)), max_size=40))
    def test_sanitize_idempotent_w_zakresie(self, notes):
        proj = _synth_proj({"sub": notes})
        fixed1 = core.sanitize_notes(proj)
        fixed2 = core.sanitize_notes(proj)
        self.assertEqual(fixed2, 0)               # idempotentne
        for n in proj["tracks"][0]["notes"]:
            self.assertTrue(0 <= int(n[2]) <= 127)
            self.assertTrue(1 <= int(n[3]) <= 127)
        self.assertGreaterEqual(fixed1, 0)

    @_FAST
    @given(st.sampled_from(sorted(MR.NOTE_RANGES)),
           st.lists(st.integers(-260, 390), max_size=25))
    def test_solve_register_zakres_i_klasa(self, tt, keys):
        tr = dict(name=tt, type=tt, notes=[[float(i), 0.5, k, 90] for i, k in enumerate(keys)], params={})
        lo, hi = MR._note_range_for(tt)
        CS.solve_register(tr, lo, hi)
        for n in tr["notes"]:
            self.assertTrue(lo <= n[2] <= hi)
            self.assertEqual(n[2] % 12, core.fold_key(n[2]) % 12)   # klasa wysokości zachowana
        # idempotentne: drugie przejście nic nie zmienia
        notes_before = [n[2] for n in tr["notes"]]
        self.assertEqual(CS.solve_register(tr, lo, hi), 0)
        self.assertEqual(notes_before, [n[2] for n in tr["notes"]])

    @_FAST
    @given(st.floats(1.0, 127.0, allow_nan=False, allow_infinity=False),
           st.sampled_from(["intro", "build", "drop", "break", "outro", "other"]),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
           st.integers(0, 31), st.sampled_from(_ROLES),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
           st.floats(-1.0, 1.0, allow_nan=False, allow_infinity=False),
           st.booleans())
    def test_structure_vel_zakres_i_determinizm(self, base, sec, prog, step, role, energy, dens, mood, human):
        kw = dict(progress=prog, step=step, role=role, energy=energy, dens=dens,
                  accent=(step % 4 == 0), human=human, mood=mood)
        v1 = G.structure_vel(base, sec, rng=random.Random(9), **kw)
        v2 = G.structure_vel(base, sec, rng=random.Random(9), **kw)
        self.assertTrue(1 <= v1 <= 127)
        self.assertEqual(v1, v2)                  # deterministyczne przy podanym rng

    @_FAST
    @given(st.sampled_from(sorted(G.PARAM_DIR)),
           st.floats(0.0, 100.0, allow_nan=False, allow_infinity=False),
           st.floats(0.0, 100.0, allow_nan=False, allow_infinity=False),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
           st.sampled_from(["sub", "kick", "wobble", "pad", "pluck", "hat"]))
    def test_smart_param_window_podzbiór(self, name, lo, hi, A, o, tt):
        lo, hi = min(lo, hi), max(lo, hi) + 0.01   # zakres niepusty
        a, b = G.smart_param_window(name, lo, hi, A, o, tt)
        self.assertLessEqual(lo, a)
        self.assertLessEqual(a, b)
        self.assertLessEqual(b, hi)
        self.assertGreaterEqual(b - a, 0.1 * (hi - lo) - 1e-9)


@needs_hyp
class TestScenario(unittest.TestCase):

    @_FAST
    @given(st.lists(st.tuples(st.sampled_from(["intro", "build", "drop", "break", "outro"]),
                              st.integers(4, 48)), min_size=1, max_size=10),
           st.sampled_from(list(G.SCENARIO_CHARS)), st.floats(0.05, 1.0, allow_nan=False))
    def test_analyze_znane_kody(self, tpl, char, energy):
        sections, start, ord_ = [], 0, {}
        for t, b in tpl:
            ord_[t] = ord_.get(t, 0) + 1
            e0, e1 = G.scenario_section_energy(t, char, energy)
            sections.append(dict(name=f"{t}{ord_[t]}", type=t, k=ord_[t], start=start,
                                 bars=b, e0=e0, e1=e1))
            start += b
        issues = G.analyze_scenario(sections, char, energy, 0.5)
        known = {"empty", "no_drop", "drop_short", "drop_overlong", "intro_long",
                 "peak_not_drop", "optimistic_dip", "dark_needs_break", "too_few_sections"}
        for x in issues:
            self.assertTrue(x in known or (x.startswith("run_")
                                           and x[4:] in ("intro", "build", "drop", "break", "outro")),
                            msg=f"nieznany kod problemu: {x}")

    @_FAST
    @given(st.lists(st.tuples(st.sampled_from(["intro", "build", "drop", "break", "outro"]),
                              st.integers(4, 48)), min_size=1, max_size=10),
           st.sampled_from(list(G.SCENARIO_CHARS)), st.floats(0.05, 1.0, allow_nan=False))
    def test_correct_scenariusza_nie_psuje_struktury(self, tpl, char, energy):
        sections, start, ord_ = [], 0, {}
        for t, b in tpl:
            ord_[t] = ord_.get(t, 0) + 1
            e0, e1 = G.scenario_section_energy(t, char, energy)
            sections.append(dict(name=f"{t}{ord_[t]}", type=t, k=ord_[t], start=start,
                                 bars=b, e0=e0, e1=e1))
            start += b
        issues = G.analyze_scenario(sections, char, energy, 0.5)
        out = G.correct_scenario(sections, issues, char, energy, random.Random(3))
        # renumeracja spójna: start narasta o bars, nazwa = typ + k
        pos = 0
        for s in out:
            self.assertGreater(s["bars"], 0)
            self.assertEqual(s["start"], pos)
            self.assertTrue(s["name"].startswith(s["type"]))
            self.assertEqual(s["name"], f"{s['type']}{s['k']}")
            self.assertTrue(0.0 <= s["e0"] <= 1.2 and 0.0 <= s["e1"] <= 1.2)
            pos += s["bars"]
        # „no_drop”/„too_few_sections” ⇒ korekta dokłada dropa
        if "no_drop" in issues or "too_few_sections" in issues:
            self.assertTrue(any(s["type"] == "drop" for s in out))


@needs_hyp
class TestReviewerParams(unittest.TestCase):

    @_FAST
    @given(st.sampled_from(sorted(MR.PARAM_WINDOWS)),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
           st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False))
    def test_pull_param_w_oknie_nie_rusza(self, pname, v, intensity):
        lo, hi = MR.PARAM_WINDOWS[pname]
        v = lo + (hi - lo) * v                     # wartość wewnątrz okna
        tr = dict(name="t", type="pad", params={pname: v}, notes=[])
        rng = random.Random(5)
        self.assertFalse(MR._pull_param(tr, pname, lo, hi, intensity, rng))
        self.assertEqual(tr["params"][pname], v)

    @_FAST
    @given(st.sampled_from(sorted(MR.PARAM_WINDOWS)),
           st.floats(-0.5, 1.5, allow_nan=False, allow_infinity=False),
           st.floats(0.05, 1.0, allow_nan=False, allow_infinity=False))
    def test_pull_param_zawsze_w_0_1(self, pname, v, intensity):
        lo, hi = MR.PARAM_WINDOWS[pname]
        tr = dict(name="t", type="pad", params={pname: v}, notes=[])
        MR._pull_param(tr, pname, lo, hi, intensity, random.Random(5))
        self.assertTrue(0.0 <= tr["params"][pname] <= 1.0)


# ---------------------------------------------------------------- z hostem (generate)
@needs_hyp
class TestGenerateProperties(unittest.TestCase):

    @settings(max_examples=3, suppress_health_check=_SUPPRESS, deadline=None)
    @given(st.integers(0, 999_999))
    def test_generate_nuty_w_zakresie_i_determinizm(self, seed):
        if not HOST:
            self.skipTest("brak hosta")
        p1 = G.generate("Brostep", bars=16, seed=seed, energy=0.6, density=0.5)
        notes1 = [[t["name"], t["notes"]] for t in p1["tracks"]]
        for t in p1["tracks"]:
            for n in t["notes"]:
                self.assertTrue(0 <= int(n[2]) <= 127)
                self.assertTrue(1 <= int(n[3]) <= 127)
        # determinizm: ten sam seed ⇒ identyczne nuty
        p2 = G.generate("Brostep", bars=16, seed=seed, energy=0.6, density=0.5)
        self.assertEqual(notes1, [[t["name"], t["notes"]] for t in p2["tracks"]])


if __name__ == "__main__":
    unittest.main()
