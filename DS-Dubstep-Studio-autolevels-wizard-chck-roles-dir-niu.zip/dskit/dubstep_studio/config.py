"""config.py — config.txt (format INI: [sekcje], `klucz = wartość`, komentarze # lub ; tylko w osobnej linii).

Szukany w kolejności: $DS_CONFIG, ./config.txt (katalog projektu, obok ds-studio), ~/DubstepStudio/config.txt.
Jeśli żadnego nie ma, zostaje utworzony domyślny (z komentarzami) w katalogu projektu (chmod 600 — zawiera hasła).
Zapis z GUI podmienia tylko wartości, komentarze i kolejność zostają.
"""
from __future__ import annotations

import configparser
import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent

DEFAULT_TEXT = """\
# DS Dubstep Studio — config.txt
# Format: [sekcja] i `klucz = wartość`. Komentarze: linia zaczynająca się od # lub ;  (nie dopisuj komentarzy w tej samej linii co wartość —
# hasło może zawierać znak #). Tak/nie: yes/no, true/false, 1/0.
# Plik zawiera hasła: ma uprawnienia 600. Zmiany z GUI (Live → „Zapisz config.txt") podmieniają tylko wartości.

[icecast]
# Nadawanie strumienia Live do serwera Icecast2 (przez ffmpeg: PCM -> MP3/Ogg -> icecast://).
enabled = no
host = localhost
port = 8000
# punkt montowania; rozszerzenie dla wygody: .mp3 (format mp3) / .ogg (ogg, opus)
mount = /dubstep.mp3
source_user = source
# hasło źródła (<source-password> w icecast.xml)
password = hackme
# tls = yes dla https/icecast za proxy TLS (ffmpeg: -tls 1)
tls = no
# legacy = yes tylko dla Icecast < 2.4 (metoda SOURCE)
legacy = no
# format: mp3 | ogg (Vorbis) | opus
format = mp3
# bitrate w kbps
bitrate = 192
name = DS Dubstep Studio Live
description = Endless generative dubstep
genre = Dubstep
url =
# public = yes ogłasza stream w katalogu serwera (jeśli serwer ma <directory> włączone)
public = no
# Aktualizacja tytułu utworu (styl / BPM / tonacja) przez /admin/metadata — wymaga konta admina z icecast.xml.
metadata = yes
admin_user = admin
admin_password =
# grać też lokalnie na głośnikach (no = tylko nadawanie, np. na serwerze bez audio)
local_playback = yes
# po zerwaniu połączenia (restart serwera) ponów próbę co tyle sekund
reconnect_sec = 5

[live]
# current = styl i ustawienia z [generator] / zakładki Generator;  random = losowanie kaskadowe
mode = current
# takty na aranżację (min. 4 x liczba sekcji szablonu stylu)
arr_bars = 32
# --- miejsce na dysku / karcie SD ---
# ile folderów sesji Live zostawić (1 = tylko bieżąca; starsze są kasowane przy starcie). Zapisane utwory biblioteki nie są ruszane.
keep_sessions = 1
# yes = po zatrzymaniu skasuj wav niezapiętych aranżacji (zostają małe projekty)
clean_on_exit = no
# --- wyjście audio i pamięć (SBC z 512 MB RAM) ---
# player: auto | aplay | pw-cat | paplay | mpv | ffplay. auto pomija pw-cat/paplay, gdy nie działa serwer dźwięku (wtedy gra przez ALSA: aplay)
player = auto
# urządzenie wyjściowe (puste = domyślne). aplay: plughw:1,0 albo plughw:CARD=Device,DEV=0 (lista: python3 -m dubstep_studio devices);
# paplay/pw-cat: nazwa sinka z `pactl list short sinks`; mpv: alsa/plughw:1,0
audio_device =
# równoległe procesy renderu (0 = auto z wolnego RAM; na 512 MB użyj 1)
render_workers = 0
# mutacje (tylko mode = random): % aranżacji, w których wylosowany styl jest mutowany w hybrydę (0 = wył.)
mutate = 0
# ile aranżacji generować z wyprzedzeniem
lookahead = 1
# maks. aranżacji w magazynie (przypięte nie są usuwane)
max_store = 60
# po odsłuchu z osi czasu wróć na żywo
return_live = yes
# tempo/energia wg pory dnia (tylko mode = random)
tod_on = yes
# auto = zegar systemowy, albo: Rano | Popołudnie | Wieczór | Noc
tod_force = auto
# mnożniki BPM stylu w procentach (60-130)
tod_rano = 88
tod_popoludnie = 100
tod_wieczor = 106
tod_noc = 90
# „na sztywno" (nie losowane, wartość z [generator]): lista po przecinku z: style,bpm,key,scale,energy,density,swing,bars,instruments
lock =
# GUI: rozpocznij strumień od razu po uruchomieniu
auto_start = no

[generator]
# Ustawienia bazowe (tryb bez GUI: ./ds-studio live). W GUI baza to zakładka Generator.
style = Brostep
# 0 = BPM stylu
bpm = 0
# auto | 0-11 | C C# D D# E F F# G G# A A# B
key = auto
# minor | phrygian | "harmonic minor"
scale = minor
energy = 0.7
density = 0.6
# -1 = swing stylu
swing = -1
# style | core8 | all | lista po przecinku, np. kick,snare,hat,sub,wobble
instruments = style
# yes = wagowy dobór instrumentów (perkusja/bas/lead) wg charakteru gatunku + zawężone zakresy parametrów
smart_instruments = no
# yes = heurystyczne autolevels gainów po generate (TARGET_REL × gęstość nut; pełny RMS: GUI Autolevels)
autolevels = no
# yes = naprzemienna zamiana ról bass↔lead↔pad w sekcjach + retune barwy
role_swap = no
# yes = nadrzędne scenariusze (mutacja template + post-analiza)
scenarios = no
# very_optimistic | optimistic | balanced | restrained | dark
character = balanced
# niuanse artykulacji (yes/no) i siła -1..1; spektakularność: monotone|plain|balanced|vivid|anthem
niuanse = no
niuanse_strength = 0
spectacle = balanced
# reżyser: yes = nadrzędny tryb (mood, scenariusz, instrumenty, okna, role, autolevel)
director = no
director_mood = 0
director_variety = 0.6
director_scenario_strength = 0.5
director_role_amount = 0.5
# tekst DS Speak (puste = auto), działa gdy w instruments jest speak
speak_text =

[paths]
# puste = domyślne. Biblioteka i magazyn Live (library/../live), katalog wtyczek .clap.
library =
plugin_dir =
# plik presetów (puste = ~/DubstepStudio/presets.json; domyślnie nie istnieje, dopóki nie zapiszesz presetu)
presets =
# magazyn sesji Live (puste = <biblioteka>/../live) i katalog tymczasowy renderu (puste = /tmp) — np. na dysku USB zamiast karty SD
live_dir =
tmp_dir =
# katalog trybu ECO (preroll/air; puste = ~/DubstepStudio/preroll)
preroll_dir =
"""

SECTIONS_ORDER = ["icecast", "live", "generator", "paths"]
NOTE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def find_path(create=True) -> Path:
    cands = ([Path(os.environ["DS_CONFIG"])] if os.environ.get("DS_CONFIG") else []) + [APP_DIR / "config.txt", Path.home() / "DubstepStudio" / "config.txt"]
    for c in cands:
        if c.exists():
            return c
    p = cands[0] if os.environ.get("DS_CONFIG") else APP_DIR / "config.txt"
    if create:
        try:
            p.parent.mkdir(parents=True, exist_ok=True); p.write_text(DEFAULT_TEXT, encoding="utf-8"); os.chmod(p, 0o600)
        except OSError:
            p = Path.home() / "DubstepStudio" / "config.txt"; p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(DEFAULT_TEXT, encoding="utf-8"); os.chmod(p, 0o600)
    return p


def _parser(text=None):
    cp = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=None, comment_prefixes=("#", ";"), empty_lines_in_values=False)
    cp.optionxform = str.lower
    cp.read_string(DEFAULT_TEXT)                       # defaulty
    if text is not None:
        cp.read_string(text)
    return cp


def _b(v):
    return str(v).strip().lower() in ("1", "yes", "true", "tak", "on", "y")


def _int(v, d):
    try:
        return int(float(str(v).strip()))
    except ValueError:
        return d


def _float(v, d):
    try:
        return float(str(v).strip().replace(",", "."))
    except ValueError:
        return d


def load(path=None) -> dict:
    """-> {"path", "icecast": {...}, "live": {...}, "generator": {...}, "paths": {...}} z typami Pythona i walidacją."""
    path = Path(path) if path else find_path()
    cp = _parser(path.read_text(encoding="utf-8", errors="replace"))
    ic, lv, ge, pa = (cp[s] for s in SECTIONS_ORDER)
    fmt = ic["format"].strip().lower()
    icecast = dict(enabled=_b(ic["enabled"]), host=ic["host"].strip() or "localhost", port=_int(ic["port"], 8000), mount=ic["mount"].strip() or "/stream",
                   source_user=ic["source_user"].strip() or "source", password=ic["password"].strip(), tls=_b(ic["tls"]), legacy=_b(ic["legacy"]),
                   format=fmt if fmt in ("mp3", "ogg", "opus") else "mp3", bitrate=max(32, min(320, _int(ic["bitrate"], 192))), name=ic["name"].strip(),
                   description=ic["description"].strip(), genre=ic["genre"].strip(), url=ic["url"].strip(), public=_b(ic["public"]), metadata=_b(ic["metadata"]),
                   admin_user=ic["admin_user"].strip() or "admin", admin_password=ic["admin_password"].strip(), local_playback=_b(ic["local_playback"]),
                   reconnect_sec=max(1, _int(ic["reconnect_sec"], 5)))
    if not icecast["mount"].startswith("/"):
        icecast["mount"] = "/" + icecast["mount"]
    tf = lv["tod_force"].strip()
    locks = [x.strip() for x in lv["lock"].split(",") if x.strip()]
    live = dict(mode="random" if lv["mode"].strip().lower() == "random" else "current", arr_bars=max(16, _int(lv["arr_bars"], 32)),
                lookahead=max(1, min(4, _int(lv["lookahead"], 1))), max_store=max(2, _int(lv["max_store"], 60)), keep_sessions=max(1, _int(lv["keep_sessions"], 1)), clean_on_exit=_b(lv["clean_on_exit"]), return_live=_b(lv["return_live"]),
                tod_on=_b(lv["tod_on"]), tod_force=None if tf.lower() in ("", "auto") else tf,
                tod_factors={"Rano": _int(lv["tod_rano"], 88) / 100, "Popołudnie": _int(lv["tod_popoludnie"], 100) / 100,
                             "Wieczór": _int(lv["tod_wieczor"], 106) / 100, "Noc": _int(lv["tod_noc"], 90) / 100},
                locks=locks, auto_start=_b(lv["auto_start"]), player=lv["player"].strip().lower() or "auto", audio_device=lv["audio_device"].strip(),
                workers=max(0, _int(lv["render_workers"], 0)), mutate_p=max(0, min(100, _int(lv["mutate"], 0))) / 100)
    k = ge["key"].strip()
    key = None if k.lower() in ("", "auto") else (NOTE.index(k.upper()) if k.upper() in NOTE else _int(k, 0) % 12)
    gen = dict(style=ge["style"].strip() or "Brostep", bpm=_int(ge["bpm"], 0), key=key, scale=ge["scale"].strip().strip('"') or "minor",
               energy=_float(ge["energy"], 0.7), density=_float(ge["density"], 0.6), swing=_float(ge["swing"], -1), instruments=ge["instruments"].strip() or "style",
               smart_instruments=_b(ge["smart_instruments"]) if "smart_instruments" in ge else False,
               autolevels=_b(ge["autolevels"]) if "autolevels" in ge else False,
               role_swap=_b(ge["role_swap"]) if "role_swap" in ge else False,
               scenarios=_b(ge["scenarios"]) if "scenarios" in ge else False,
               character=(ge["character"].strip() if "character" in ge else "balanced") or "balanced",
               niuanse=_b(ge["niuanse"]) if "niuanse" in ge else False,
               niuanse_strength=_float(ge["niuanse_strength"], 0.0) if "niuanse_strength" in ge else 0.0,
               spectacle=(ge["spectacle"].strip() if "spectacle" in ge else "balanced") or "balanced",
               director=_b(ge["director"]) if "director" in ge else False,
               director_mood=_float(ge["director_mood"], 0.0) if "director_mood" in ge else 0.0,
               director_variety=_float(ge["director_variety"], 0.6) if "director_variety" in ge else 0.6,
               director_scenario_strength=_float(ge["director_scenario_strength"], 0.5) if "director_scenario_strength" in ge else 0.5,
               director_role_amount=_float(ge["director_role_amount"], 0.5) if "director_role_amount" in ge else 0.5,
               speak_text=ge["speak_text"].strip() or None)
    paths = dict(library=pa["library"].strip(), plugin_dir=pa["plugin_dir"].strip(), presets=pa["presets"].strip(), live_dir=pa["live_dir"].strip(), preroll_dir=pa["preroll_dir"].strip(), tmp_dir=pa["tmp_dir"].strip())
    return dict(path=path, icecast=icecast, live=live, generator=gen, paths=paths)


def apply_env(conf):
    """[paths] -> zmienne środowiskowe (jeśli nie ustawione przez użytkownika w powłoce)."""
    if conf["paths"]["library"]:
        os.environ.setdefault("DS_LIBRARY", os.path.expanduser(conf["paths"]["library"]))
    if conf["paths"]["presets"]:
        os.environ.setdefault("DS_PRESETS", os.path.expanduser(conf["paths"]["presets"]))
    if conf["paths"]["live_dir"]:
        os.environ.setdefault("DS_LIVE_DIR", os.path.expanduser(conf["paths"]["live_dir"]))
    if conf["paths"]["preroll_dir"]:
        os.environ.setdefault("DS_PREROLL", os.path.expanduser(conf["paths"]["preroll_dir"]))
    if conf["paths"]["tmp_dir"]:
        os.environ.setdefault("DS_TMP", os.path.expanduser(conf["paths"]["tmp_dir"]))
    lv = conf["live"]
    if lv["player"] not in ("", "auto"):
        os.environ.setdefault("DS_LIVE_PLAYER", lv["player"])
    if lv["audio_device"]:
        os.environ.setdefault("DS_AUDIO_DEVICE", lv["audio_device"])
    if lv["workers"]:
        os.environ.setdefault("DS_WORKERS", str(lv["workers"]))
    if conf["paths"]["plugin_dir"]:
        os.environ.setdefault("DS_PLUGIN_DIR", os.path.expanduser(conf["paths"]["plugin_dir"]))


def save_values(path, updates: dict):
    """updates = {("icecast","host"): "x", ...}. Podmienia wartości w miejscu (komentarze zostają), brakujące klucze dopisuje na końcu sekcji."""
    path = Path(path)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else DEFAULT_TEXT.splitlines()
    for (sec, key), val in updates.items():
        val = str(val).replace("\n", " ")
        cur, done, last = None, False, None
        for i, ln in enumerate(lines):
            s = ln.strip()
            if s.startswith("[") and s.endswith("]"):
                if cur == sec and not done:
                    break
                cur = s[1:-1].strip().lower(); last = i if cur == sec else last; continue
            if cur == sec:
                last = i
                if s and not s.startswith(("#", ";")) and "=" in s and s.split("=", 1)[0].strip().lower() == key:
                    lines[i] = f"{key} = {val}"; done = True; break
        if done:
            continue
        if last is None:                                   # brak sekcji
            lines += ["", f"[{sec}]", f"{key} = {val}"]
        else:
            lines.insert(last + 1, f"{key} = {val}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def to_live_cfg(conf, base_cfg):
    """Nakłada [live] na DEFAULT_CFG-podobny słownik silnika."""
    import copy
    from . import live as L
    c = copy.deepcopy(base_cfg); lv = conf["live"]
    c.update(mode=lv["mode"], arr_bars=lv["arr_bars"], lookahead=lv["lookahead"], max_store=lv["max_store"], return_live=lv["return_live"],
             tod_on=lv["tod_on"], tod_force=lv["tod_force"], tod_factors=dict(lv["tod_factors"]), mutate_p=lv["mutate_p"],
             keep_sessions=lv["keep_sessions"], clean_on_exit=lv["clean_on_exit"])
    c["locks"] = {k: (k in lv["locks"]) for k in L.LOCK_KEYS}
    return c


def to_base(conf):
    """Baza generatora z [generator] (tryb bez GUI)."""
    from . import core, generator as G
    g = conf["generator"]; style = g["style"] if g["style"] in G.STYLES else "Brostep"
    ins = g["instruments"]
    smart = bool(g.get("smart_instruments"))
    if ins == "style" and smart:
        inst = None  # generate() sam dobierze wagowo
    elif ins == "style":
        inst = G.default_instruments(style)
    elif ins == "core8":
        inst = list(core.CORE8)
    elif ins == "all":
        inst = core.available_types()
    else:
        inst = [t.strip() for t in ins.split(",") if t.strip() in core.TYPES]
    return dict(style=style, bpm=g["bpm"] or G.STYLES[style]["bpm"], key=g["key"], scale=g["scale"] if g["scale"] in core.SCALES else "minor",
                energy=g["energy"], density=g["density"], swing=G.STYLES[style]["swing"] if g["swing"] < 0 else g["swing"],
                instruments=inst if inst is not None else None,
                smart_instruments=smart,
                autolevels=bool(g.get("autolevels")),
                role_swap=bool(g.get("role_swap")),
                scenarios=bool(g.get("scenarios")),
                character=g.get("character") or "balanced",
                director=dict(on=bool(g.get("director")), mood=float(g.get("director_mood") or 0),
                              variety=float(g.get("director_variety") or 0.6),
                              scenario_strength=float(g.get("director_scenario_strength") or 0.5),
                              role_amount=float(g.get("director_role_amount") or 0.5)) if g.get("director") else None,
                niuanse=bool(g.get("niuanse")),
                niuanse_strength=float(g.get("niuanse_strength") or 0),
                spectacle=g.get("spectacle") or "balanced",
                speak_text=g["speak_text"], speak_theme=None)
