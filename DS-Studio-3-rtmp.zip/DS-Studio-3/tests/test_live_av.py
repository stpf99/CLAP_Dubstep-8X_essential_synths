"""Lekkie wideo na żywo (vid.livefx) + RTMP jako wyjście obok Icecast: analiza dźwięku, ewolucja agentów, sceny, regulator jakości, LiveAV, Output, config."""
import os
import tempfile
import unittest
from pathlib import Path

import numpy as np

from dubstep_studio import config as CF, core, live as L
from dubstep_studio.vid import host as VH, livefx as F

SR = core.SR


def pcm(x):
    x = np.clip(x, -1, 1)
    return (np.stack([x, x], 1) * 32767).astype("<i2").tobytes()


def synth(seconds=3.0, kick=True):
    t = np.arange(int(SR * seconds)) / SR
    x = 0.2 * np.sin(2 * np.pi * 440 * t) * 0.1
    if kick:
        for k in np.arange(0, seconds, 0.43):
            m = (t >= k) & (t < k + 0.25); tt = t[m] - k
            x[m] += np.sin(2 * np.pi * (120 * np.exp(-tt * 18) + 40) * tt) * np.exp(-tt * 9) * 0.9
    return x


def feed(an, raw, upto):
    pos = an.total
    while pos < upto:
        c = raw[pos * 4:(pos + 2048) * 4]; an.push(c); pos += len(c) // 4


class TestAnalyzer(unittest.TestCase):
    def test_kick_gives_punch_and_low_band(self):
        raw = pcm(synth(3.0)); an = F.Analyzer(); peaks = []
        for k in range(75):
            pos = int(k / 25 * SR) + 1; feed(an, raw, pos); A = an.feat(pos); peaks.append((A["punch"], A["low"], A["high"]))
        self.assertGreater(max(p for p, _, _ in peaks), 0.5)             # uderzenie jest wykrywane
        self.assertGreater(max(l for _, l, _ in peaks), max(h for _, _, h in peaks))   # stopa = dół widma

    def test_silence_is_dark(self):
        raw = pcm(np.zeros(SR * 2)); an = F.Analyzer()
        for k in range(30):
            pos = int(k / 25 * SR) + 1; feed(an, raw, pos); A = an.feat(pos)
        self.assertLess(A["spec"].max(), 0.05); self.assertEqual(A["punch"], 0.0)

    def test_agc_independent_of_volume(self):
        res = []
        for gain in (0.05, 0.9):
            raw = pcm(synth(3.0) * gain); an = F.Analyzer(); m = 0
            for k in range(75):
                pos = int(k / 25 * SR) + 1; feed(an, raw, pos); m = max(m, an.feat(pos)["spec"].max())
            res.append(m)
        self.assertGreater(res[1], 0.5); self.assertGreater(res[0], 0.12 * res[1])   # cichy utwór nadal coś pokazuje


class TestEvolution(unittest.TestCase):
    def test_population_bounded_and_finite(self):
        raw = pcm(synth(6.0)); an = F.Analyzer(); evo = F.Evolution(24, seed=1); ns = []
        for k in range(150):
            pos = int(k / 25 * SR) + 1; feed(an, raw, pos); evo.update(an.feat(pos), 3); ns.append(evo.n)
        self.assertTrue(all(8 <= n <= 24 for n in ns), (min(ns), max(ns)))
        for k in evo.KEYS:
            self.assertTrue(np.isfinite(evo.g[k][evo.alive]).all(), k)
        self.assertTrue(((evo.g["x"][evo.alive] >= 27) & (evo.g["x"][evo.alive] <= evo.W - 27)).all())   # w granicach kadru

    def test_children_are_mutated_copies_not_hybrids(self):
        evo = F.Evolution(12, seed=2); p = int(np.nonzero(evo.alive)[0][0]); keys0 = {k: float(evo.g[k][p]) for k in ("attr", "speed")}
        c = evo._spawn(parent=p)
        self.assertIsNotNone(c)
        self.assertAlmostEqual(evo.g["energy"][c], evo.g["energy"][p], places=5)          # energia dzielona po równo
        self.assertTrue(abs(evo.g["attr"][c] - keys0["attr"]) < 1.0)


class TestScenes(unittest.TestCase):
    def test_all_scenes_and_levels_render(self):
        raw = pcm(synth(2.0)); pw, ph = 214, 120
        for scene in F.SCENES:
            eng = F.Engine(pw, ph, 25, dict(scene=scene)); eng.begin(dict(bpm=140, style="Brostep", sections=[dict(type="drop", start=0, bars=8)]), "TEST", 0.0)
            for li, lv in enumerate(F.LEVELS):
                for k in range(li * 3, li * 3 + 3):
                    feed(eng.an, raw, int(k / 25 * SR) + 1)
                    b = eng.frame(k, lv)
                    self.assertEqual(len(b), pw * ph * 3, (scene, li))
        a = np.frombuffer(b, np.uint8); self.assertGreater(a.max(), 0)

    def test_auto_scene_follows_sections(self):
        eng = F.Engine(100, 60, 25, dict(scene="auto")); eng.begin(dict(bpm=120, style="x", sections=[dict(type="build", start=0, bars=2), dict(type="drop", start=2, bars=4)]), "T", 0.0)
        self.assertEqual(eng._scene(0.5)[0], "tunnel")
        sc, drop = eng._scene(5.0); self.assertTrue(drop); self.assertIn(sc, ("morph", "ring"))

    def test_no_track_idle(self):
        eng = F.Engine(100, 60, 25, {}); feed(eng.an, pcm(np.zeros(SR)), SR // 2)
        self.assertEqual(len(eng.frame(5, F.LEVELS[2])), 100 * 60 * 3)


class TestAutoTune(unittest.TestCase):
    def test_heavy_render_jumps_down_several_levels(self):
        t = F.AutoTune("auto", ncpu=4, start=0); t.update(0.0, 0.1); lvl = t.update(10.0, 3.0)
        self.assertGreaterEqual(lvl, 3)
        t = F.AutoTune("auto", ncpu=4, start=0); t.update(0.0, 0.1)
        lvl = t.update(10.0, 1.2); self.assertEqual(lvl, 2)               # div=2 jest 4x tańszy: przewidywane 26% rdzenia — wystarczy, nie schodzimy niżej niż trzeba

    def test_calm_goes_up_after_20s_only(self):
        t = F.AutoTune("auto", ncpu=4, start=4); now = 0.0
        for _ in range(15):
            now += 1.0; t.update(now, 0.02, cpu=0.2)
        self.assertEqual(t.level, 4)
        for _ in range(15):
            now += 1.0; t.update(now, 0.02, cpu=0.2)
        self.assertLess(t.level, 4)

    def test_failed_upgrade_is_blocked(self):
        t = F.AutoTune("auto", ncpu=4, start=3); now = 0.0
        for _ in range(45):
            now += 1.0; t.update(now, 0.02, cpu=0.2)
        up = t.level; self.assertLess(up, 3)
        now += 3.0; t.update(now, 0.02, cpu=0.99)                       # zaraz po wejściu CPU wystrzeliło
        self.assertGreater(t.level, up)
        down = t.level
        for _ in range(60):                                              # 60 s spokoju < blokada 90 s
            now += 1.0; t.update(now, 0.02, cpu=0.2)
        self.assertGreater(t.level, up)                                  # na poziom, który zawiódł, nie wracamy przez 90 s (pośredni wolno)
        self.assertGreaterEqual(t.level, down - 1)

    def test_low_memory_emergency(self):
        t = F.AutoTune("auto", ncpu=4, start=0, min_free_mb=300); self.assertGreaterEqual(t.update(1.0, 0.0, mem_mb=100), 5)

    def test_cpu_over_target_degrades_and_busy_is_stricter(self):
        t = F.AutoTune("auto", ncpu=4, start=1, cpu_target=0.85); t.update(0.0, 0.1, cpu=0.5); self.assertEqual(t.update(5.0, 0.1, cpu=0.9), 2)
        t2 = F.AutoTune("auto", ncpu=4, start=1, cpu_target=0.85); t2.update(0.0, 0.1, cpu=0.5)
        self.assertEqual(t2.update(5.0, 0.1, cpu=0.78, busy=True), 2)    # 78% jeszcze OK, ale gdy generator liczy track — już za dużo

    def test_fixed_quality_never_changes(self):
        t = F.AutoTune("low"); self.assertEqual(t.level, 4)
        for i in range(30):
            t.update(float(i), 5.0, cpu=1.0, mem_mb=10)
        self.assertEqual(t.level, 4)
        self.assertEqual(F.AutoTune("max").level, 0); self.assertEqual(F.AutoTune("3").level, 3)

    def test_rel_cost_monotonic(self):
        c = [F.rel_cost(l) for l in F.LEVELS]; self.assertEqual(c, sorted(c, reverse=True))


class FakeStreamer:
    def __init__(self):
        self.frames = 0; self.status = "nadaje"; self.dropped_v = 0; self.vid = []; self.aud = 0

    def start(self): pass
    def stop(self): pass
    def maintain(self): pass
    def write_audio(self, b): self.aud += len(b); return True
    def write_frame(self, b): self.vid.append(len(b)); self.frames += 1; return True


class FakeProbe:
    def __init__(self, cpu=0.1, mem=2000): self.c, self.m = cpu, mem
    def cpu(self): return self.c
    def mem_mb(self): return self.m


class TestLiveAV(unittest.TestCase):
    def _run(self, quality="max", seconds=3.0, cpu=0.1, fps=25):
        fs = FakeStreamer(); av = F.LiveAV(dict(quality=quality, width=214, height=120, fps=fps, pipe_div=1), dict(enabled=True), streamer=fs, probe=FakeProbe(cpu))
        raw = pcm(synth(seconds)); av.run = True
        av.begin(dict(bpm=140, style="Brostep", sections=[dict(type="drop", start=0, bars=8)]), title="T #1")
        for i in range(0, len(raw), 2048 * 4):
            av.audio(raw[i:i + 2048 * 4])
        while not av.q.empty():
            it = av.q.get_nowait()
            if it[0] == "begin":
                av.eng.begin(it[1], it[2] or "", av.samples / SR)
            else:
                b = it[1]; av.st.write_audio(b); av.eng.push(b); av.samples += len(b) // 4; av._frames_due()
        return av, fs

    def test_frames_match_audio_clock(self):
        av, fs = self._run(seconds=3.0)
        self.assertEqual(fs.frames, int(3.0 * 25)); self.assertEqual(set(fs.vid), {av.pipe[0] * av.pipe[1] * 3})
        self.assertEqual(fs.aud, int(SR * 3.0) * 4)                       # całe audio przeszło bez zmian

    def test_skip_levels_repeat_frames_but_keep_clock(self):
        av, fs = self._run(quality="minimal", seconds=2.0)                # poziom 5: skip=3
        self.assertEqual(fs.frames, 50); self.assertLess(av.rendered, 50 // 2)

    def test_status_and_stats(self):
        av, fs = self._run(seconds=1.0); st = av.stats()
        self.assertEqual(st["fps"], 25); self.assertIn("poziom", av.status)

    def test_busy_hint_and_tick_degrades_on_cpu(self):
        av, fs = self._run(quality="auto", seconds=1.0, cpu=0.99)
        lvl0 = av.tune.level; av.hint_busy(True); av.tune.t_change = -1e9; av._t_tick = 0.0; av._tick()
        self.assertGreater(av.tune.level, lvl0)

    def test_render_error_does_not_break_audio(self):
        av, fs = self._run(seconds=0.5)
        av.eng.frame = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        av.samples += SR; av._frames_due()
        self.assertGreater(fs.frames, int(0.5 * 25))


class FakeAv:
    def __init__(self): self.audio_n = 0; self.begun = []; self.busy = None; self.status = "RTMP: nadaje"
    def start(self): pass
    def stop(self): pass
    def audio(self, b): self.audio_n += len(b)
    def begin(self, proj, feat=None, pv=None, title=None): self.begun.append(title)
    def hint_busy(self, f): self.busy = f


class TestOutput(unittest.TestCase):
    def setUp(self):
        import dubstep_studio.video_render as VR
        self.VR = VR; self._orig = VR.make_av_sink; self.fake = FakeAv(); VR.make_av_sink = lambda av, rt, log=None: self.fake
        self.conf = CF.load(Path(__file__).resolve().parent.parent / "config.txt")

    def tearDown(self):
        self.VR.make_av_sink = self._orig

    def test_rtmp_only_is_a_network_output(self):
        ice = dict(self.conf["icecast"], enabled=False); out = L.Output()
        out.configure(ice, False, rtmp_cfg=dict(enabled=True, url="rtmp://x/live"), av_cfg={})
        self.assertTrue(out.net_on()); self.assertFalse(out.use_local())      # samo RTMP + bez odsłuchu: nie wymaga odtwarzacza lokalnego
        out.start(); out.set_busy(True); out.begin_av({"bpm": 140}, title="A #1")
        out.write(bytes(2048 * 4)); out.fill_silence()
        self.assertGreater(self.fake.audio_n, 2048 * 4); self.assertEqual(self.fake.begun, ["A #1"]); self.assertTrue(self.fake.busy)
        out.stop()

    def test_no_outputs_falls_back_to_local(self):
        out = L.Output(); out.configure(dict(self.conf["icecast"], enabled=False), False, rtmp_cfg=dict(enabled=False))
        self.assertFalse(out.net_on()); self.assertTrue(out.use_local())

    def test_changing_rtmp_url_restarts_sink(self):
        made = []
        self.VR.make_av_sink = lambda av, rt, log=None: made.append(rt["url"]) or FakeAv()
        out = L.Output(); ice = dict(self.conf["icecast"], enabled=False)
        out.configure(ice, False, rtmp_cfg=dict(enabled=True, url="rtmp://a/live"), av_cfg={}); out.start()
        out.configure(ice, False, rtmp_cfg=dict(enabled=True, url="rtmp://b/live"), av_cfg={})
        self.assertEqual(made, ["rtmp://a/live", "rtmp://b/live"]); out.stop()

    def test_both_icecast_and_rtmp(self):
        ice = dict(self.conf["icecast"], enabled=True); out = L.Output()
        out.configure(ice, False, rtmp_cfg=dict(enabled=True, url="rtmp://x/live"), av_cfg={})
        self.assertTrue(out.ice_on() and out.rtmp_on() and not out.use_local())
        self.assertIn("rtmp", out.status())


class TestConfigAndEncoder(unittest.TestCase):
    def test_sections_load_validate_and_save_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "c.txt"; p.write_text("[icecast]\nlocal_playback = no\n[rtmp]\nenabled = yes\nurl = rtmp://a/b\nkey = k#1\n[video]\nsize = 640x360\nquality = 3\nfps = 999\n", encoding="utf-8")
            c = CF.load(p)
            self.assertTrue(c["rtmp"]["enabled"]); self.assertEqual(c["rtmp"]["key"], "k#1")
            self.assertEqual((c["video"]["width"], c["video"]["height"], c["video"]["fps"], c["video"]["quality"]), (640, 360, 60, "3"))
            self.assertTrue(CF.net_on(c)); self.assertFalse(CF.local_on(c)); self.assertTrue(CF.local_on(dict(c, rtmp=dict(c["rtmp"], enabled=False))))
            CF.save_values(p, {("video", "scene"): "ring", ("rtmp", "url"): "rtmp://z/y"}); c2 = CF.load(p)
            self.assertEqual((c2["video"]["scene"], c2["rtmp"]["url"], c2["video"]["size"]), ("ring", "rtmp://z/y", "640x360"))

    def test_bad_values_fall_back(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "c.txt"; p.write_text("[video]\nsize = abc\nquality = ???\ncpu_target = 5\n", encoding="utf-8"); c = CF.load(p)
            self.assertEqual((c["video"]["width"], c["video"]["quality"], c["video"]["cpu_target"]), (854, "auto", 30))

    def test_lite_encoder_and_scale(self):
        a = VH.encoder_args(dict(v_codec="libx264", fps=25, v_bitrate=1500, lite=True, threads=2), stream=True)
        for x in ("ultrafast", "zerolatency", "-bf", "-threads"):
            self.assertIn(x, a)
        heavy = VH.encoder_args(dict(v_codec="libx264", fps=25, v_bitrate=1500), stream=True); self.assertIn("veryfast", heavy); self.assertNotIn("-threads", heavy)
        st = VH.RtmpStreamer(dict(url="rtmp://x/y", out_w=854, out_h=480, v_bitrate=1500, lite=True, threads=2), (426, 240), 25)
        cmd = st._cmd(5)
        self.assertIn("scale=854:480:flags=bilinear", cmd); self.assertIn("426x240", cmd)
        same = VH.RtmpStreamer(dict(url="rtmp://x/y", out_w=426, out_h=240), (426, 240), 25)._cmd(5); self.assertFalse(any(str(x).startswith("scale=") for x in same))


if __name__ == "__main__":
    unittest.main()
