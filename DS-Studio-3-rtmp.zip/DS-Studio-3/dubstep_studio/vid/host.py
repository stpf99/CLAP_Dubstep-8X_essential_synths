"""host.py — HOST renderu wideo (odpowiednik hosta CLAP dla audio): składa warstwy z projvideo w klatki, eksportuje MP4 z dźwiękiem (ffmpeg),
nadaje RTMP (z ponawianiem połączenia) i zasila nadawanie na żywo (AvSink: audio z silnika Live + klatki zsynchronizowane z zegarem audio)."""
from __future__ import annotations

import copy
import math
import os
import queue
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path

import numpy as np

from .. import core, rcore
from . import plugins as _plugins  # noqa: F401
from .canvas import Canvas
from .plugins import PALETTES, VREG
from .signals import Signals, audio_features

SR = core.SR
KIND_ORDER = ("room", "performer", "brush", "camera", "fx", "overlay")


class _Ctx:
    pass


class VideoJob:
    """Zadanie renderu klatek: projekt audio + projvideo (+ cechy audio) → klatki uint8 (h, w, 3)."""

    def __init__(self, proj, pv, feat=None, n=None):
        self.proj, self.pv = proj, pv
        self.w, self.h = int(pv["size"][0]) // 2 * 2, int(pv["size"][1]) // 2 * 2
        self.fps = int(pv["fps"])
        self.scale = 2 if float(pv.get("render_scale", 1.0)) <= 0.5 else 1          # render_scale 0.5: liczone w połowie rozdzielczości i powiększane (4× szybciej)
        self.rw, self.rh = self.w // self.scale, self.h // self.scale
        self.sig = Signals(proj, self.fps, feat, n)
        self.n = self.sig.n
        self.canvas = Canvas(self.rw, self.rh)
        self._buf = np.zeros((self.rh, self.rw, 3), np.float32)
        self.layers = []                                      # (layer_dict, plugin)
        for L in pv["layers"]:
            if L["plugin"] not in VREG:
                continue
            pl = VREG.make(L["plugin"], **(L.get("params") or {}))
            pl.layer = L
            self.layers.append((L, pl))
        self.base = {L["id"]: dict(pl.p) for L, pl in self.layers}
        self.specs = {L["id"]: pl.specs() for L, pl in self.layers}
        self.links = [l for l in pv.get("links", []) if l["dst"] in self.base]
        self.cues = {c["section"]: c for c in pv.get("cues", [])}
        self.ctx = _Ctx()
        c = self.ctx
        c.canvas, c.w, c.h, c.fps, c.sig = self.canvas, self.rw, self.rh, self.fps, self.sig
        c.pal = PALETTES.get(pv.get("palette"), PALETTES["kraftwerk"]); c.meta = pv.get("meta", {}); c.state = {}
        self.by_kind = {k: [(L, pl) for L, pl in self.layers if pl.kind == k] for k in KIND_ORDER}
        self.perf_x = [pl.p["x"] for L, pl in self.by_kind["performer"]]
        self.sec_start = [s["start"] * 4 * 60.0 / float(proj["bpm"]) for s in proj["sections"]]

    # ---- parametry w klatce: baza szablonu → cue sekcji (płynnie) → linki sygnał→parametr
    def params_at(self, i):
        sg = self.sig; k = int(sg.sec[i]); t = float(sg.t[i])
        base = {lid: dict(p) for lid, p in self.base.items()}
        cur = (self.cues.get(k) or {}).get("mods", {}); prev = (self.cues.get(k - 1) or {}).get("mods", cur) if k > 0 else cur
        w = rcore.smooth_step((t - self.sec_start[k]) / 0.9) if k < len(self.sec_start) else 1.0
        for lid, mods in cur.items():
            if lid not in base:
                continue
            for pn, v in mods.items():
                sp = self.specs[lid].get(pn)
                if sp is None or sp.kind in ("choice", "bool"):
                    continue
                pv_ = (prev.get(lid) or {}).get(pn, base[lid].get(pn, v))
                base[lid][pn] = sp.clamp(rcore.lerp(float(pv_), float(v), w))
        return rcore.apply_links(self.links, lambda name: self.sig.value(name, i), base, lambda lid: self.specs[lid])

    def frame_f(self, i):
        """Klatka jako float32 (h, w, 3) 0..1."""
        i = min(max(0, int(i)), self.n - 1)
        st = self.params_at(i)
        for L, pl in self.layers:
            pl.p = st[L["id"]]
        c, ctx = self.canvas, self.ctx
        self._buf[:] = 0; c.img = self._buf
        ctx.i = i; ctx.rng = np.random.default_rng((i * 2654435761) % (2 ** 32)); ctx.extras = {"perf_x": self.perf_x}
        for L, pl in self.by_kind["room"]:
            pl.render(ctx, i)
        for L, pl in self.by_kind["performer"]:
            pl.render(ctx, i)
        for L, pl in self.by_kind.get("brush", []):
            pl.render(ctx, i)
        img = c.img
        for L, pl in self.by_kind["camera"]:
            img = pl.apply(ctx, img, i)
        fade = None
        for L, pl in self.by_kind["fx"]:
            if pl.id == "fx_fade":
                fade = pl; continue
            img = pl.apply(ctx, img, i)
        c.img = img if img.flags.writeable else img.copy()
        for L, pl in self.by_kind["overlay"]:
            pl.render(ctx, i)
        img = c.img
        if fade is not None:
            img = fade.apply(ctx, img, i)
        return img

    def frame(self, i):
        a = (np.clip(self.frame_f(i), 0, 1) * 255.0 + 0.5).astype(np.uint8)
        if self.scale == 2:
            a = np.repeat(np.repeat(a, 2, 0), 2, 1)
        return a


# ------------------------------------------------------------------ ffmpeg
def ffmpeg_bin():
    return shutil.which("ffmpeg")


def encoder_args(cfg, stream=False):
    """Argumenty kodera wideo z konfiguracji (v_codec, v_preset, crf albo v_bitrate [kb/s], gop_sec, fps)."""
    codec = (cfg.get("v_codec") or "libx264").strip()
    fps = int(cfg.get("fps") or 25); gop = max(1, int(float(cfg.get("gop_sec", 2)) * fps))
    br = int(cfg.get("v_bitrate") or 0)
    a = ["-c:v", codec]
    if codec in ("libx264", "libx265"):
        lite = bool(cfg.get("lite")) and stream
        a += ["-preset", (cfg.get("v_preset") or "ultrafast") if lite else (cfg.get("v_preset") or "veryfast"), "-pix_fmt", "yuv420p"]
        if stream or not cfg.get("crf"):
            br = br or 2500
            a += ["-b:v", f"{br}k", "-maxrate", f"{int(br * 1.2)}k", "-bufsize", f"{br * 2}k"]
        else:
            a += ["-crf", str(int(cfg["crf"]))]
        if stream:
            a += ["-tune", "zerolatency"]
        if lite:                                              # tryb lekki: bez B-klatek, 1 ref, stałe GOP (YouTube), ograniczona liczba wątków
            a += ["-bf", "0", "-refs", "1", "-sc_threshold", "0"]
            if int(cfg.get("threads") or 0) > 0:
                a += ["-threads", str(int(cfg["threads"]))]
    else:                                                      # sprzętowe (h264_v4l2m2m, nvenc, qsv…): bitrate + yuv420p
        a += ["-pix_fmt", "yuv420p", "-b:v", f"{br or 2500}k"]
    return a + ["-g", str(gop), "-keyint_min", str(gop)]


def _fit_encoder_size(w, h):
    return (w // 2 * 2, h // 2 * 2)


def export_mp4(proj, pv, out, mix=None, audio_wav=None, enc=None, progress=None, feat=None):
    """Renderuje MP4 z dźwiękiem (jedno przejście ffmpeg: klatki rawvideo z pipe + audio WAV). -> ścieżka."""
    ff = ffmpeg_bin()
    if not ff:
        raise RuntimeError("Brak ffmpeg w PATH — zainstaluj ffmpeg do renderu wideo.")
    enc = dict(enc or {}); fps = int(pv["fps"]); w, h = _fit_encoder_size(*pv["size"]); pv = copy.deepcopy(pv); pv["size"] = [w, h]
    tmp_wav = None
    if audio_wav is None:
        if mix is None:
            mix = core.render_mix(proj, progress=None)
        fd, tmp_wav = tempfile.mkstemp(suffix=".wav"); os.close(fd); core.write_wav(tmp_wav, mix); audio_wav = tmp_wav
    if feat is None and mix is not None:
        feat = audio_features(mix, fps)
    n_audio = int(len(mix) / SR * fps) + 1 if mix is not None else None
    job = VideoJob(proj, pv, feat, n=max(n_audio or 0, int(math.ceil(proj["bars"] * 4 * 60.0 / float(proj["bpm"]) * fps)) + 1))
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [ff, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps), "-i", "-", "-i", str(audio_wav),
           "-map", "0:v:0", "-map", "1:a:0"] + encoder_args(dict(enc, fps=fps)) + ["-c:a", "aac", "-b:a", f"{int(enc.get('a_bitrate', 192))}k", "-shortest", "-movflags", "+faststart", str(out)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        for i in range(job.n):
            try:
                proc.stdin.write(job.frame(i).tobytes())
            except (BrokenPipeError, OSError):
                break
            if progress and i % max(1, job.n // 50) == 0:
                progress(i / job.n)
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        err = proc.stderr.read().decode("utf-8", "replace") if proc.stderr else ""
        proc.wait()
        if tmp_wav:
            Path(tmp_wav).unlink(missing_ok=True)
    if proc.returncode != 0 or not out.exists() or out.stat().st_size < 1000:
        raise RuntimeError(f"ffmpeg: {err[-400:]}")
    if progress:
        progress(1.0)
    return str(out)


def frame_png(proj, pv, t_sec, out, feat=None):
    """Pojedyncza klatka do PNG (przez ffmpeg — bez PIL)."""
    job = VideoJob(proj, pv, feat)
    fr = job.frame(int(t_sec * job.fps))
    ff = ffmpeg_bin()
    if not ff:
        raise RuntimeError("Brak ffmpeg.")
    p = subprocess.run([ff, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{job.w}x{job.h}", "-i", "-", "-frames:v", "1", str(out)],
                       input=fr.tobytes(), capture_output=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.decode("utf-8", "replace")[-300:])
    return str(out)


# ------------------------------------------------------------------ RTMP
def rtmp_target(cfg):
    url = (cfg.get("url") or "").strip(); key = (cfg.get("key") or "").strip()
    return url.rstrip("/") + "/" + key if key else url


def mask_url(u, key=""):
    return u.replace(key, "***") if key else u


class RtmpStreamer:
    """Jedno trwałe połączenie ffmpeg → RTMP: wideo (rawvideo, stdin) + audio (s16le 48 kHz, pipe fd). Ponawia połączenie po awarii (reconnect/reconnect_sec/retries),
    nie blokuje wątku nadającego, gdy serwer jest niedostępny (w tym czasie dane są porzucane)."""

    def __init__(self, cfg, size, fps, log=None):
        self.cfg = dict(cfg); self.size = _fit_encoder_size(*size); self.fps = int(fps); self.log = log or (lambda m: None)
        self.proc = None; self.aw = None; self.status = "rozłączony"; self.retries = 0; self.retry_at = 0.0; self.err_tail = ""; self.frames = 0; self.up_since = None
        self._lock = threading.Lock(); self.stopped = False; self.started_at = None
        self._aq = queue.Queue(maxsize=400); self._vq = queue.Queue(maxsize=10); self._gen = 0; self.dropped_a = 0; self.dropped_v = 0

    def _cmd(self, ra):
        c = self.cfg; ff = ffmpeg_bin(); w, h = self.size
        cmd = [ff, "-loglevel", "warning", "-fflags", "+genpts", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(self.fps), "-thread_queue_size", "512", "-i", "pipe:0",
               "-f", "s16le", "-ar", str(SR), "-ac", "2", "-thread_queue_size", "1024", "-i", f"pipe:{ra}"]
        ow, oh = int(c.get("out_w") or 0), int(c.get("out_h") or 0)
        if ow and oh and (ow // 2 * 2, oh // 2 * 2) != (w, h):          # render w małym rozmiarze, skalowanie robi ffmpeg (tanio)
            cmd += ["-vf", f"scale={ow // 2 * 2}:{oh // 2 * 2}:flags=bilinear"]
        cmd += encoder_args(dict(c, fps=self.fps), stream=True) + ["-c:a", "aac", "-b:a", f"{int(c.get('a_bitrate', 128))}k", "-ar", str(SR)]
        cmd += ["-f", "flv", "-flvflags", "no_duration_filesize"]
        if int(c.get("timeout_sec", 10)) > 0:
            cmd += ["-rw_timeout", str(int(c.get("timeout_sec", 10)) * 1000000)]
        if c.get("live", True):
            cmd += ["-rtmp_live", "live"]
        if int(c.get("buffer_ms", 0)) > 0:
            cmd += ["-rtmp_buffer", str(int(c["buffer_ms"]))]
        return cmd + [rtmp_target(c)]

    def start(self):
        self.stopped = False; self.started_at = time.time()
        return self._spawn()

    def _spawn(self):
        if not ffmpeg_bin():
            self.status = "brak ffmpeg"; return False
        self._close()
        ra, wa = os.pipe()
        try:
            cmd = self._cmd(ra)
            nv = int(self.cfg.get("nice") or 0)
            if nv > 0 and shutil.which("nice"):                    # koder z niższym priorytetem: audio i generator mają pierwszeństwo
                cmd = ["nice", "-n", str(nv)] + cmd
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, pass_fds=(ra,))
        except OSError as e:
            os.close(ra); os.close(wa); self.status = f"błąd uruchomienia: {e}"; return False
        os.close(ra); self.aw = wa; self._gen += 1
        for q in (self._aq, self._vq):                       # kolejki zapisu: audio i wideo nie blokują się nawzajem ani wątku nadającego (ffmpeg sonduje wejścia po kolei)
            while not q.empty():
                try:
                    q.get_nowait()
                except queue.Empty:
                    break
        threading.Thread(target=self._writer, args=(self._gen, self._aq, "a"), daemon=True).start()
        threading.Thread(target=self._writer, args=(self._gen, self._vq, "v"), daemon=True).start()
        threading.Thread(target=self._read_err, args=(self.proc,), daemon=True).start()
        self.status = "łączenie…"; self.up_since = time.time()
        return True

    def _read_err(self, proc):
        try:
            for ln in proc.stderr:
                s = ln.decode("utf-8", "replace").strip()
                if s:
                    self.err_tail = (self.err_tail + "\n" + s)[-600:]
        except Exception:
            pass

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def _close(self):
        for f in (getattr(self.proc, "stdin", None),):
            try:
                if f:
                    f.close()
            except OSError:
                pass
        if self.aw is not None:
            try:
                os.close(self.aw)
            except OSError:
                pass
            self.aw = None
        if self.proc is not None:
            try:
                self.proc.terminate(); self.proc.wait(timeout=3)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            self.proc = None

    def maintain(self):
        """Wywoływać okresowo: wykrywa zerwanie i ponawia połączenie wg [rtmp] reconnect*."""
        if self.stopped or self.alive():
            if self.alive() and self.up_since and time.time() - self.up_since > 3:
                self.status = "nadaje"
            return
        if self.status not in ("rozłączony", "czekam na ponowienie"):
            self.log(f"RTMP: połączenie zerwane. {self.err_tail.strip().splitlines()[-1] if self.err_tail.strip() else ''}")
        c = self.cfg
        if not c.get("reconnect", True):
            self.status = "rozłączony"; return
        mx = int(c.get("retries", 0))
        if mx and self.retries >= mx:
            self.status = "porzucono (limit prób)"; return
        now = time.time()
        if self.retry_at == 0.0 or self.status != "czekam na ponowienie":
            self.retry_at = now + int(c.get("reconnect_sec", 5)); self.status = "czekam na ponowienie"; return
        if now >= self.retry_at:
            self.retries += 1; self.retry_at = 0.0; self.log(f"RTMP: ponawiam połączenie (próba {self.retries})")
            self._spawn()

    def _writer(self, gen, q, kind):
        while gen == self._gen and not self.stopped:
            try:
                b = q.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                if gen != self._gen or not self.alive():
                    continue
                if kind == "a":
                    mv = memoryview(b)
                    while mv and gen == self._gen:
                        n = os.write(self.aw, mv); mv = mv[n:]
                else:
                    self.proc.stdin.write(b); self.proc.stdin.flush(); self.frames += 1
            except (OSError, ValueError, TypeError):
                pass

    @staticmethod
    def _put(q, b):
        while True:
            try:
                q.put_nowait(b); return True
            except queue.Full:
                try:
                    q.get_nowait()                            # zachowaj czas rzeczywisty: porzuć najstarsze
                except queue.Empty:
                    pass

    def write_audio(self, b):
        if not self.alive():
            return False
        if self._aq.full():
            self.dropped_a += 1
        self._put(self._aq, bytes(b)); return True

    def write_frame(self, b):
        if not self.alive():
            return False
        if self._vq.full():
            self.dropped_v += 1
        self._put(self._vq, b); return True

    def stop(self):
        self.stopped = True; self._gen += 1; self._close(); self.status = "rozłączony"


def stream_project(proj, pv, rtmp_cfg, enc=None, mix=None, progress=None, stop=lambda: False, log=print):
    """Nadaje gotowy projekt (audio + wideo) na RTMP w czasie rzeczywistym. Klatki liczone tak szybko, jak się da; gdy render nie nadąża, powtarzana jest ostatnia klatka."""
    if mix is None:
        mix = core.render_mix(proj, progress=None)
    fps = int(pv["fps"]); feat = audio_features(mix, fps)
    job = VideoJob(proj, pv, feat, n=int(len(mix) / SR * fps) + 1)
    st = RtmpStreamer(dict(rtmp_cfg, **(enc or {})), (job.w, job.h), fps, log)
    st.start()
    pcm = (np.clip(mix, -1, 1) * 32767).astype("<i2").tobytes()
    chunk = 2048 * 4; t0 = time.time(); sent_v = 0; sent_a = 0; last = None
    try:
        while sent_a < len(pcm) and not stop():
            st.maintain()
            target_a = min(len(pcm), int(((time.time() - t0) + 0.35) * SR) * 4)
            while sent_a < target_a:
                n = min(chunk, len(pcm) - sent_a); st.write_audio(pcm[sent_a: sent_a + n]); sent_a += n
            due = int((time.time() - t0) * fps) + 1
            while sent_v < due:
                late = (time.time() - t0) - sent_v / fps
                if last is not None and late > 0.25:
                    st.write_frame(last)                 # nie nadążamy — powtórz klatkę
                else:
                    last = job.frame(min(sent_v, job.n - 1)).tobytes(); st.write_frame(last)
                sent_v += 1
            if progress:
                progress(sent_a / max(1, len(pcm)))
            time.sleep(0.01)
        time.sleep(1.0)
    finally:
        st.stop()
    return st.status


# ------------------------------------------------------------------ nadawanie na żywo (silnik Live)
class AvSink:
    """Odbiera PCM z Output (audio silnika Live) i begin(proj, feat) przy starcie każdej aranżacji; wysyła do RTMP dźwięk i klatki zsynchronizowane z zegarem audio.
    Wątek własny: render wideo nigdy nie opóźnia dźwięku (gdy nie nadąża, powtarza klatkę)."""

    def __init__(self, av_cfg, rtmp_cfg, log=None):
        self.av, self.rt = dict(av_cfg), dict(rtmp_cfg)
        self.log = log or (lambda m: None)
        w = int(self.rt.get("width") or self.av.get("width") or 854); h = int(self.rt.get("height") or self.av.get("height") or 480)
        self.fps = int(self.rt.get("fps") or self.av.get("fps") or 25); self.size = (w, h)
        self.st = RtmpStreamer(self.rt, self.size, self.fps, self.log)
        self.q = queue.Queue(maxsize=400); self.job = None; self.t_arr0 = 0.0; self.audio_clock = 0.0; self.sent_v = 0; self.last = None; self.wall0 = None
        self.th = None; self.run = False; self.idle = Canvas(*self.st.size); self.late_frames = 0

    @property
    def status(self):
        return f"RTMP: {self.st.status}" + (f" ({self.st.frames} kl., powtórzone {self.late_frames})" if self.st.frames else "")

    def start(self):
        self.run = True
        self.st.start()
        self.th = threading.Thread(target=self._loop, daemon=True); self.th.start()

    def stop(self):
        self.run = False
        if self.th:
            self.th.join(timeout=3)
        self.st.stop()

    def audio(self, b):
        try:
            self.q.put_nowait(("pcm", b))
        except queue.Full:
            try:
                self.q.get_nowait()                         # zachowaj czas rzeczywisty: porzuć najstarszy kawałek
            except queue.Empty:
                pass

    def hint_busy(self, flag):
        pass

    def begin(self, proj, feat=None, pv=None, title=None):
        try:
            self.q.put_nowait(("begin", proj, feat, pv))
        except queue.Full:
            pass

    def _idle_frame(self):
        c = self.idle; w, h = c.w, c.h
        c.gradient_v((0.02, 0.02, 0.05), (0.1, 0.02, 0.05)); t = time.time()
        c.text(w / 2, h * 0.42, "DS LIVE", max(2, h // 80), (0.9, 0.9, 0.95), 0.9, "center")
        c.text(w / 2, h * 0.55, "STAND BY" if int(t * 2) % 2 == 0 else "", max(1, h // 160), (0.9, 0.1, 0.12), 0.9, "center")
        return c.to_uint8().tobytes()

    def _build_job(self, proj, feat, pv):
        from . import templates as TP
        pv = copy.deepcopy(pv) if pv else TP.build_projvideo(proj, self.av.get("template", "kraftwerk_robots"), size=self.size, fps=self.fps, palette=self.av.get("palette") or None)
        pv["size"] = list(self.st.size); pv["fps"] = self.fps
        return VideoJob(proj, pv, feat)

    def _loop(self):
        while self.run:
            try:
                it = self.q.get(timeout=0.1)
            except queue.Empty:
                self.st.maintain(); continue
            try:
                if it[0] == "begin":
                    self.job = self._build_job(it[1], it[2], it[3]); self.t_arr0 = self.audio_clock
                    continue
                b = it[1]
                self.st.maintain()
                self.st.write_audio(b)
                if self.wall0 is None:
                    self.wall0 = time.time()
                self.audio_clock += len(b) / 4.0 / SR
                while self.sent_v < int(self.audio_clock * self.fps):
                    backlog = self.q.qsize() * len(b) / 4.0 / SR           # ile audio czeka w kolejce = jak bardzo nie nadążamy (niezależnie od przerw w dźwięku)
                    if self.job is None:
                        fr = self._idle_frame()
                    elif self.last is not None and backlog > 0.6:
                        fr = self.last; self.late_frames += 1
                    else:
                        i = int((self.sent_v / self.fps - self.t_arr0) * self.fps)
                        fr = self.job.frame(min(max(0, i), self.job.n - 1)).tobytes()
                    self.last = fr; self.st.write_frame(fr); self.sent_v += 1
            except Exception as e:                           # render wideo nie może zatrzymać nadawania audio
                self.log(f"wideo: {e}")
                self.job = None
