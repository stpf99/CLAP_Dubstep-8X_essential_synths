"""python3 -m dubstep_studio            -> GUI
   python3 -m dubstep_studio gen ...   -> generuj z CLI (--style --bpm --bars --seed --key --save)
   python3 -m dubstep_studio list      -> lista biblioteki
   python3 -m dubstep_studio remix A B C [--bpm N] [--key 0-11]  (ID folderów z biblioteki; pierwszy = master)
   python3 -m dubstep_studio preroll [--fill N|--count N|--minutes M] [--keep N] [--format mp3|flac|wav] [--preset NAZWA]   -> tryb ECO: render do plików
   python3 -m dubstep_studio air [--shuffle] [--consume] [--no-local]                     -> tryb ECO: nadawanie plików (Icecast2/odtwarzacz)
   python3 -m dubstep_studio devices   -> urządzenia wyjściowe do [live] audio_device
   python3 -m dubstep_studio presets list|show NAZWA|delete NAZWA|export NAZWA PLIK|import PLIK   -> globalne presety (domyślnie puste)
   python3 -m dubstep_studio gen --preset NAZWA / live --preset NAZWA   -> ustawienia z presetu
   python3 -m dubstep_studio live [--config PLIK] [--random] [--no-local]   -> strumień Live/Endless bez GUI (np. na serwerze, nadawanie do Icecast2 wg config.txt)
   python3 -m dubstep_studio video templates|render|rtmp|export  -> wideo/RTMP (vid.host)"""
import argparse
import os
import random
import signal
import sys
import time

from . import config as CF, core, eco, generator as G, live as L, presets as PR, remix as R


def _preset_or_exit(name):
    d = PR.get(name)
    if d is None:
        sys.exit(f"Brak presetu „{name}”. Dostępne: {', '.join(PR.names()) or '(brak — zapisz pierwszy w GUI)'}")
    return d


def _setup(a):
    conf = CF.load(); cfg = CF.to_live_cfg(conf, L.DEFAULT_CFG); pbase = None
    if a.preset:
        pbase, plive = PR.to_engine(_preset_or_exit(a.preset))
        for k, v in plive.items():
            if k == "locks" and isinstance(v, dict):
                cfg["locks"].update({kk: bool(vv) for kk, vv in v.items() if kk in cfg["locks"]})
            elif k == "tod_factors" and isinstance(v, dict):
                cfg["tod_factors"].update(v)
            elif k in cfg:
                cfg[k] = v
        if cfg.get("use_board") and cfg.get("board"):          # styl z pola szachowego jako baza
            from . import styles as ST
            pbase["style"] = ST.board_name([tuple(x) for x in cfg["board"]], cfg["board_strength"]) or pbase["style"]
        pbase["instruments"] = pbase["instruments"] or G.default_instruments(pbase["style"])
        if pbase.get("key") is not None:
            pbase["key"] = int(pbase["key"])
    if getattr(a, "random", False):
        cfg["mode"] = "random"
    return conf, cfg, pbase


def _rtmp_flags(a, conf):
    """--rtmp / --no-rtmp nadpisują [rtmp] enabled z config.txt (URL i klucz zostają z pliku albo z --rtmp-url / --rtmp-key)."""
    if getattr(a, "rtmp", False):
        conf["rtmp"]["enabled"] = True
    if getattr(a, "no_rtmp", False):
        conf["rtmp"]["enabled"] = False
    if getattr(a, "rtmp_url", None):
        conf["rtmp"]["url"] = a.rtmp_url
    if getattr(a, "rtmp_key", None):
        conf["rtmp"]["key"] = a.rtmp_key


def run_live(a):
    conf, cfg, pbase = _setup(a)
    _rtmp_flags(a, conf)
    ice = conf["icecast"]; local = CF.local_on(conf, a.no_local)
    stop = []

    def on_event(kind, **kw):
        if kind == "planning":
            print(f"[plan] #{kw['idx'] + 1}: {kw['plan']['desc']}", flush=True)
        elif kind == "playing":
            print(f"[play] {eng.arrs[kw['idx']].label()}  (RAM procesu: {core.rss_mb()} MB)", flush=True)
        elif kind == "error":
            print(kw["msg"], file=sys.stderr, flush=True)
    eng = L.LiveEngine(on_event)
    eng.set_cfg(cfg); eng.set_base(pbase or CF.to_base(conf)); eng.set_output(ice, local, rtmp_cfg=conf["rtmp"], av_cfg=conf["video"])

    def reload(*_):                      # SIGHUP: ponownie wczytaj config.txt (bez przerywania strumienia)
        c = CF.load(conf["path"]); eng.set_cfg(CF.to_live_cfg(c, L.DEFAULT_CFG)); eng.set_base(CF.to_base(c))
        _rtmp_flags(a, c); eng.set_output(c["icecast"], CF.local_on(c, a.no_local), rtmp_cfg=c["rtmp"], av_cfg=c["video"]); print("[config] przeładowano", flush=True)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, reload)
    signal.signal(signal.SIGTERM, lambda *_: stop.append(1))
    print(f"Live: config={conf['path']} tryb={cfg['mode']} icecast={'tak → ' + ice['host'] + ':' + str(ice['port']) + ice['mount'] if ice['enabled'] else 'nie'} lokalnie={'tak' if local else 'nie'} rtmp={'tak → ' + conf['rtmp']['url'] if conf['rtmp']['enabled'] else 'nie'}", flush=True)
    eng.start(); last = ""; last_r = ""; interrupted = False
    try:
        while eng.running and not stop:
            time.sleep(1.0)
            st = eng.out_status()["icecast"]
            if ice["enabled"] and st != last:
                print(f"[icecast] {st}", flush=True); last = st
            sr = eng.out_status().get("rtmp", "")
            if conf["rtmp"]["enabled"] and sr.split(" · ")[0] != last_r:
                print(f"[rtmp] {sr}", flush=True); last_r = sr.split(" · ")[0]
    except KeyboardInterrupt:
        interrupted = True
    failed = not eng.running and not stop and not interrupted      # silnik sam się zatrzymał (np. brak odtwarzacza)
    eng.stop(); print("Zatrzymano. Magazyn:", eng.session)
    return 1 if failed else 0


def run_eco(a):
    import signal
    stop = []
    signal.signal(signal.SIGTERM, lambda *_: stop.append(1))
    if a.cmd == "preroll":
        conf, cfg, pbase = _setup(a); base = pbase or CF.to_base(conf)
        if not base.get("instruments"):
            base["instruments"] = G.default_instruments(base["style"])
        try:
            n = eco.preroll(cfg, base, a.dir or eco.preroll_dir(), count=a.count, fill=a.fill, minutes=a.minutes, keep=a.keep, fmt=a.format, log=lambda m: print(m, flush=True), stop=lambda: bool(stop))
        except (RuntimeError, KeyboardInterrupt) as ex:
            sys.exit(str(ex) or "przerwano")
        print(f"Gotowe: {n} nowych plików w {a.dir or eco.preroll_dir()}")
        return 0
    conf = CF.load(); ice = conf["icecast"]; _rtmp_flags(a, conf); local = CF.local_on(conf, a.no_local)
    print(f"Air: {a.dir or eco.preroll_dir()}  icecast={'tak → ' + ice['host'] + ':' + str(ice['port']) + ice['mount'] if ice['enabled'] else 'nie'}  lokalnie={'tak' if local else 'nie'}", flush=True)
    try:
        eco.air(ice, local, a.dir or eco.preroll_dir(), rtmp_cfg=conf["rtmp"], av_cfg=conf["video"], shuffle=a.shuffle, once=a.once, consume=a.consume, log=lambda m: print(m, flush=True), stop=lambda: bool(stop))
    except KeyboardInterrupt:
        pass
    except RuntimeError as ex:
        sys.exit(str(ex))
    print("Zatrzymano.")
    return 0


def run_presets(a):
    op, xs = a.op, a.args
    if op == "list":
        for n in PR.names():
            print(n)
        if not PR.names():
            print(f"(brak presetów — plik {PR.path()} powstanie po zapisaniu pierwszego)")
    elif op == "show" and xs:
        import json
        print(json.dumps(_preset_or_exit(xs[0]), ensure_ascii=False, indent=1))
    elif op == "delete" and xs:
        _preset_or_exit(xs[0]); PR.delete(xs[0]); print("usunięto", xs[0])
    elif op == "export" and len(xs) == 2:
        _preset_or_exit(xs[0]); PR.export_file(xs[0], xs[1]); print("zapisano", xs[1])
    elif op == "import" and xs:
        print("zaimportowano:", ", ".join(PR.import_file(xs[0])) or "(nic)")
    else:
        sys.exit("użycie: presets list | show NAZWA | delete NAZWA | export NAZWA PLIK | import PLIK")
    return 0


def run_video(a):
    """CLI: templates | render | rtmp | export — warstwa nad video_render / vid.host."""
    from . import video_render as VR
    from pathlib import Path as P
    if a.video_cmd == "templates":
        for t in VR.list_templates():
            print(f"{t['id']:20} {t['title']}  ({t.get('palette','')})")
            if t.get("desc"):
                print(f"  {t['desc']}")
        return 0
    if a.video_cmd == "preview":                  # lekki wizualizator na pliku audio — podgląd wyglądu i pomiar kosztu (ten sam silnik co live)
        from .vid import livefx
        if not a.audio:
            raise SystemExit("Podaj --audio PLIK (wav/mp3/…)")
        r = livefx.export_preview(a.audio, a.out or "preview.mp4", seconds=a.seconds, size=(a.width, a.height), fps=a.fps, quality=a.quality, scene=a.scene or "auto",
                                  progress=lambda x: print(f"\rpodgląd {100*x:5.1f}%", end="", flush=True))
        print(f"\n{r}")
        return 0
    # projekt
    if not a.project:
        raise SystemExit("Podaj --project ŚCIEŻKA (proj.json z biblioteki lub eksportu)")
    proj = core.load_project(a.project) if hasattr(core, "load_project") else None
    if proj is None:
        import json
        proj = json.loads(P(a.project).read_text(encoding="utf-8"))
    tpl = a.template or "live_show"
    av = dict(width=a.width, height=a.height, fps=a.fps,
              video_bitrate=a.vbr or "4M", audio_bitrate=a.abr or "192k")
    if a.video_cmd == "render":
        out = a.out or "video.mp4"
        def prog(x):
            print(f"\rrender {100*x:5.1f}%", end="", flush=True)
        path = VR.render_video(proj, tpl, av, out, progress=prog)
        print(f"\n{path}")
        return 0
    if a.video_cmd == "export":
        d = a.out or "av_export"
        meta = VR.export_project_av(proj, d, tpl, av)
        print(meta)
        return 0
    if a.video_cmd == "rtmp":
        rtmp = dict(
            enabled=True, url=a.url or "rtmp://localhost/live/stream",
            key=a.key or "", video_bitrate=a.vbr or "2500k",
            width=a.width, height=a.height, fps=a.fps, reconnect=True,
        )
        def prog(x):
            print(f"\rstream {100*x:5.1f}%", end="", flush=True)
        info = VR.stream_rtmp(proj, tpl, rtmp, progress=prog, log=print)
        print(f"\n{info}")
        return 0
    raise SystemExit(f"Nieznana komenda video: {a.video_cmd}")



def main():
    for i, x in enumerate(sys.argv):         # --config PLIK działa też przed wczytaniem ustawień
        if x == "--config" and i + 1 < len(sys.argv):
            os.environ["DS_CONFIG"] = sys.argv[i + 1]
    CF.apply_env(CF.load())
    if len(sys.argv) < 2 or sys.argv[1] == "gui":
        from .gui import main as gui_main
        return gui_main()
    ap = argparse.ArgumentParser(prog="dubstep_studio")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("gen"); g.add_argument("--style", default="Brostep", help="styl albo hybryda, np. \"Techno 60%% + DnB 40%%\""); g.add_argument("--preset", help="nazwa presetu (nadpisuje pozostałe ustawienia)"); g.add_argument("--bpm", type=int)
    g.add_argument("--bars", type=int, default=144); g.add_argument("--seed", type=int); g.add_argument("--key", type=int)
    g.add_argument("--instruments", default="style", help="style | core8 | all | lista,po,przecinku"); g.add_argument("--scale", default="minor", choices=list(core.SCALES)); g.add_argument("--save", action="store_true")
    g.add_argument("--smart-instruments", action="store_true", help="wagowy dobór instrumentów wg charakteru gatunku + zawężone zakresy parametrów")
    g.add_argument("--autolevels", action="store_true", help="heurystyczne gainy (TARGET_REL × gęstość nut) po generate")
    g.add_argument("--role-swap", action="store_true", help="naprzemienna zamiana ról bass/lead/pad w sekcjach + retune barwy")
    g.add_argument("--scenarios", action="store_true", help="nadrzędne scenariusze: mutacja struktury + post-analiza")
    g.add_argument("--character", default="balanced", choices=["very_optimistic","optimistic","balanced","restrained","dark"], help="charakter scenariusza (legacy)")
    g.add_argument("--director", action="store_true", help="włącz reżysera (nadrzędny tryb)")
    g.add_argument("--arranger", action="store_true", help="aranżer: barwy/extras/kreator + nowe ad hoc + efekty WYSIWYG")
    g.add_argument("--arranger-amount", type=float, default=0.5, help="0..1: ile torów/extras (domyślnie 0.5)")
    g.add_argument("--arranger-adhoc", type=float, default=0.4, help="0..1: szansa nowej barwy/extra ad hoc zamiast banku")
    g.add_argument("--arranger-persist", action="store_true", help="zapisz nowe ad hoc do adhoc_bank.json")
    g.add_argument("--mood", type=float, default=0.0, help="nastrój reżysera -1..+1")
    g.add_argument("--niuanse", action="store_true", help="reguły artykulacji partii nut")
    g.add_argument("--niuanse-strength", type=float, default=0.0, help="siła niuansów -1..+1")
    g.add_argument("--spectacle", default="balanced", choices=["monotone","plain","balanced","vivid","anthem"], help="spektakularność aranżacji")
    g.add_argument("--uniq", action="store_true", help="niepowtarzalność segmentów (receptury + mikro-wariacje)")
    g.add_argument("--uniq-strength", type=float, default=0.6, help="siła uniq 0..1")
    g.add_argument("--uniq-drops", action="store_true", help="uniq także na dropach")
    g.add_argument("--era", default="auto",
                   choices=["auto","minimal_70s","analog_80s","digital_90s","rave_00s","modern_10s","maximal_now"],
                   help="zasób epoki (liczba/rodzaj instrumentów, nie marki)")
    g.add_argument("--speak-text", default=None, help="ręczny tekst DS Speak (włącz instrument: --instruments style,speak lub ...,speak)")
    g.add_argument("--speak-theme", default=None, choices=list(G.SPEAK_THEMES), help="motyw tekstu auto")
    sub.add_parser("list")
    li = sub.add_parser("listen", help="nasłuch wyjścia pulpitu lub analiza pliku audio → preset")
    li.add_argument("--file", help="plik audio zamiast live capture (mp3/wav/flac…)")
    li.add_argument("--seconds", type=float, default=30.0, help="czas nasłuchu live (domyślnie 30s)")
    li.add_argument("--save", metavar="NAZWA", help="zapisz wynik jako preset o podanej nazwie")
    li.add_argument("--json", action="store_true", help="wypisz pełny raport JSON na stdout")
    sub.add_parser("devices")
    pr = sub.add_parser("presets"); pr.add_argument("op", choices=["list", "show", "delete", "export", "import"]); pr.add_argument("args", nargs="*")
    lv = sub.add_parser("live"); lv.add_argument("--config"); lv.add_argument("--preset", help="nazwa presetu: baza Generatora + tryb auto + pole szachowe"); lv.add_argument("--random", action="store_true", help="wymuś tryb losowania kaskadowego"); lv.add_argument("--no-local", action="store_true", help="nie graj lokalnie, tylko nadawaj")
    for _p in (lv,):
        _p.add_argument("--rtmp", action="store_true", help="włącz nadawanie RTMP (audio + lekkie wideo reagujące na dźwięk) niezależnie od [rtmp] enabled")
        _p.add_argument("--no-rtmp", action="store_true"); _p.add_argument("--rtmp-url"); _p.add_argument("--rtmp-key")
    pf = sub.add_parser("preroll", help="ECO: wyrenderuj aranżacje do plików (offline, niski priorytet)")
    pf.add_argument("--config"); pf.add_argument("--preset"); pf.add_argument("--random", action="store_true"); pf.add_argument("--dir", help="katalog (domyślnie ~/DubstepStudio/preroll albo [paths] preroll_dir)")
    pf.add_argument("--count", type=int, help="ile nowych aranżacji"); pf.add_argument("--fill", type=int, help="dopełnij katalog do N plików"); pf.add_argument("--minutes", type=float, help="renderuj, aż nazbiera się tyle minut")
    pf.add_argument("--keep", type=int, help="maks. liczba plików w katalogu (najstarsze są kasowane)"); pf.add_argument("--format", choices=["mp3", "flac", "wav"], help="domyślnie mp3 (jest ffmpeg) albo wav")
    ai = sub.add_parser("air", help="ECO: nadawaj gotowe pliki do Icecast2/odtwarzacza (bez generatora i renderu)")
    ai.add_argument("--config"); ai.add_argument("--dir"); ai.add_argument("--no-local", action="store_true"); ai.add_argument("--shuffle", action="store_true")
    ai.add_argument("--rtmp", action="store_true"); ai.add_argument("--no-rtmp", action="store_true"); ai.add_argument("--rtmp-url"); ai.add_argument("--rtmp-key")
    ai.add_argument("--once", action="store_true", help="jeden przebieg i koniec"); ai.add_argument("--consume", action="store_true", help="kasuj plik po odegraniu (katalog jako kolejka)")
    vd = sub.add_parser("video", help="wideo/RTMP (vid.host: export MP4, stream RTMP z reconnect)")
    vd.add_argument("video_cmd", choices=["templates", "render", "rtmp", "export", "preview"])
    vd.add_argument("--project", help="ścieżka do proj.json")
    vd.add_argument("--template", default="live_show")
    vd.add_argument("--out", help="plik MP4 albo katalog eksportu")
    vd.add_argument("--width", type=int, default=1280); vd.add_argument("--height", type=int, default=720)
    vd.add_argument("--fps", type=int, default=30)
    vd.add_argument("--vbr", help="bitrate wideo (np. 2500k / 4M)"); vd.add_argument("--abr", help="bitrate audio")
    vd.add_argument("--url", help="RTMP URL"); vd.add_argument("--key", help="RTMP stream key")
    vd.add_argument("--audio", help="preview: plik audio"); vd.add_argument("--seconds", type=int, default=20); vd.add_argument("--quality", default="max", help="preview: auto|max|balanced|low|minimal|0-6")
    vd.add_argument("--scene", help="preview: morph|ring|tunnel|bars|scope")
    r = sub.add_parser("remix"); r.add_argument("ids", nargs="+"); r.add_argument("--bpm", type=int); r.add_argument("--key", type=int)
    r.add_argument("--seed", type=int)
    a = ap.parse_args(sys.argv[1:])
    if a.cmd == "video":
        return run_video(a)
    if a.cmd == "live":
        return run_live(a)
    if a.cmd in ("preroll", "air"):
        return run_eco(a)
    if a.cmd == "presets":
        return run_presets(a)
    if a.cmd == "devices":
        ds = L.list_devices()
        for pl, did, desc in ds:
            print(f"{pl:14} {did:40} {desc}")
        print("\nWpisz wybrane id w config.txt: [live] audio_device = ...  (aplay: najlepiej plughw:..., ono samo konwertuje format/częstotliwość)" if ds else "Nie znaleziono urządzeń (brak aplay/pactl).")
        return 0
    if a.cmd == "gen":
        if a.style not in G.STYLES:
            sys.exit(f"Nieznany styl: {a.style}")
        if a.preset:
            from . import styles as ST
            d = _preset_or_exit(a.preset); b, lv_ = PR.to_engine(d); bd = d.get("board", {})
            if lv_.get("use_board") and bd.get("cells"):
                b["style"] = ST.board_name([tuple(x) for x in bd["cells"]], bd.get("strength", 0.4)) or b["style"]
            p = G.generate(b["style"], bpm=b["bpm"], key=b["key"], scale=b["scale"], bars=d.get("generator", {}).get("bars", a.bars), energy=b["energy"], density=b["density"],
                           swing=b["swing"], seed=a.seed, instruments=b["instruments"], speak_text=b["speak_text"], speak_theme=b["speak_theme"],
                           smart_instruments=b.get("smart_instruments", False),
                           autolevels=b.get("autolevels", False),
                           role_swap=b.get("role_swap", False),
                           scenarios=b.get("scenarios", False),
                           character=b.get("character", "balanced"),
                           director=b.get("director"), arranger=b.get("arranger"))
            print(f"{p['name']}: {core.key_name(p)} {p['bpm']} BPM {p['bars']} taktów")
            if a.save:
                print(core.save_to_library(p))
            return 0
        toks = [x.strip() for x in a.instruments.split(",") if x.strip()]; inst = []
        for x in toks:                                   # style | core8 | all rozwijają się do list; reszta to nazwy typów
            inst += G.default_instruments(a.style) if x == "style" else list(core.CORE8) if x == "core8" else core.available_types() if x == "all" else [x]
        if a.smart_instruments and a.instruments.strip() in ("style", ""):
            inst = None                                  # generate() dobierze wagowo
        elif (a.speak_text or a.speak_theme) and inst is not None and "speak" not in inst:
            inst.append("speak")                         # podanie tekstu włącza mowę
        p = G.generate(a.style, bpm=a.bpm, key=a.key, scale=a.scale, bars=a.bars, seed=a.seed, instruments=inst,
                       speak_text=a.speak_text, speak_theme=a.speak_theme, smart_instruments=a.smart_instruments,
                       autolevels=a.autolevels, role_swap=a.role_swap,
                       scenarios=a.scenarios, character=a.character,
                       director=dict(on=True, mood=a.mood) if a.director else None,
                       niuanse=a.niuanse, niuanse_strength=a.niuanse_strength, spectacle=a.spectacle, era=a.era,
                       uniq=a.uniq, uniq_strength=a.uniq_strength, uniq_drops=a.uniq_drops,
                       arranger=dict(on=True, amount=a.arranger_amount, adhoc_amount=a.arranger_adhoc, persist=a.arranger_persist) if a.arranger else None)
        print(f"{p['name']}: {core.key_name(p)} {p['bpm']} BPM {p['bars']} taktów")
        if a.save:
            print(core.save_to_library(p))
    elif a.cmd == "list":
        for e in core.list_library():
            print(f"{e['path'].name}\t{e['style']}\t{e['bpm']}\t{e['key']}\t{e['bars']}")
    elif a.cmd == "listen":
        from . import listen as LS
        from . import presets as PR
        import json as _json
        if a.file:
            st = LS.load_audio_file(a.file, max_sec=min(120.0, max(20.0, a.seconds)))
            rep = LS.analyze_stream(st, window=20.0, step=2.0)
        else:
            done = {"rep": None}
            def _cb(rep, new_song, msg):
                if rep:
                    done["rep"] = rep
                print(msg, flush=True)
            listener = LS.Listener(on_report=_cb, interval=2.0, auto_reset=True)
            listener.start()
            import time as _time
            t0 = _time.time()
            while _time.time() - t0 < float(a.seconds):
                _time.sleep(0.5)
                if listener.error:
                    print("błąd:", listener.error); break
            listener.stop()
            rep = done["rep"]
        if not rep:
            print("Brak raportu (cisza / za krótko)."); return 1
        data = LS.preset_data(rep)
        g = data["generator"]
        print(f"styl={g['style']}  BPM={g['bpm']}  {g.get('scale')}  E={g['energy']} D={g['density']}")
        print("inst:", ", ".join(g.get("instruments") or []))
        if a.save:
            PR.put(a.save, data)
            print(f"zapisano preset „{a.save}” → {PR.path()}")
        if a.json:
            print(_json.dumps(rep, ensure_ascii=False, indent=1, default=str))
    elif a.cmd == "remix":
        projs = []
        for i in a.ids:
            p = core.load_project(core.lib_dir() / i); p["id"] = i; projs.append(p)
        master = projs[0]
        if len(projs) > 1:
            _, assign = R.auto_assign(projs, random.Random(a.seed))
        else:
            assign = {t["name"]: master for t in master["tracks"]}
        out = R.remix(assign, master, bpm=a.bpm, key=a.key, seed=a.seed or 0)
        print({t: (x["id"] if x else None) for t, x in assign.items()}); print(core.save_to_library(out))


if __name__ == "__main__":
    sys.exit(main() or 0)
