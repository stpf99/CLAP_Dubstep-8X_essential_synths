# Nasłuch (listen) + paleta klimatu

## 1. Integracja listen.py

### GUI — zakładka **Nasłuch**
- Start / Stop przechwytywania wyjścia pulpitu (PipeWire `pw-record` / `parec`)
- Analiza pliku audio (ffmpeg → f32)
- Ranking stylów, cechy (tempo, skala, 4/4, hat, swing, wobble…)
- **Zastosuj jako preset…** — dialog grup (generator / board / live / director / flags)
- **Zapisz preset…**

### CLI
```bash
python3 -m dubstep_studio listen --seconds 25
python3 -m dubstep_studio listen --file track.mp3 --save "Nasłuch House"
python3 -m dubstep_studio listen --file track.mp3 --json
```

Rdzeń: `dubstep_studio/listen.py` (bez Qt). GUI: `listen_gui.py`.

## 2. Paleta klimatu (spójność w czasie)

Problem: zależności między trackami były OK, ale **w rozciągłości czasu** klimat gatunku się rozjeżdżał (inne gęstości/motywy w kolejnych dropach, losowe progresje).

Rozwiązanie — **raz na generację** `build_climate(...)` zapisuje w `proj["climate"]`:

| pole | sens |
|------|------|
| `family` | dark / acid / organic / bright / hard / space |
| `motif_seed` | wspólny seed motywów |
| `section_motif_reuse` | drop1 ≈ drop2 (ten sam RNG dla typu sekcji) |
| `density_curve` | mnożniki gęstości per intro/build/drop/break/outro |
| `energy_curve` | łuk energii sekcji (e0/e1) |
| `bass_role` / `lead_role` / `pad_role` | role instrumentów spójne z klimatem |
| `harmony_lock` | jedna progresja na cały utwór |
| `phrase_len`, `space`, `drum_tight`, `timbre_bias` | dalsze wskazówki |

`Ctx` używa:
- `c.dens(B)` zamiast globalnego `density` w pętlach taktów
- `rng(track)` zakotwiczony w `motif_seed` przy reuse

Efekt: od intro do outro ten sam klimat i specyfika gatunku, przy zachowaniu lokalnych zależności między ścieżkami.
