#!/usr/bin/env python3
"""build_pack.py — składa presets_artists.json ze STYLÓW SPECJALNYCH (dubstep_studio/special_styles.py).

Wcześniej każdy preset był tylko hybrydą gatunków („House 50% + Acid Techno 32% + …"), czyli uśrednieniem gotowych wzorów.
Teraz każdy artysta/album ma własny styl: własne wzory stopy/werbla/ghost-nut/hatu, własne wzory basu, progresje, szablon formy,
paletę instrumentów i nastawy brzmień per instrument (SOUND_STYLE). Preset wskazuje ten styl (style == style_base == nazwa presetu),
a dane presetu (BPM, skala, energia, gęstość, swing, instrumenty, tekst Speak) pochodzą z tej samej specyfikacji.

Dla każdego presetu skrypt sprawdza:
  1. styl jest zarejestrowany jako czysty (nie hybryda) i może być składnikiem hybryd,
  2. epoka „auto" == zamierzona, a liczba instrumentów mieści się w limicie ścieżek epoki,
  3. wszystkie typy istnieją w core.TYPES, a każdy parametr z nastaw brzmień istnieje we wtyczce danego typu (nieznany byłby po cichu pomijany),
  4. wzory basu mają poprawne znaczniki/kroki,
  5. generate() z danymi presetu działa, jest deterministyczny i faktycznie używa własnych wzorów stylu (stopa w dropach ∈ pulom stylu).

Użycie:  python3 build_pack.py           (DS_PROJECT=ścieżka do projektu; domyślnie katalog tego pliku)
"""
from __future__ import annotations

import datetime
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = Path(os.environ.get("DS_PROJECT", HERE if (HERE / "dubstep_studio").is_dir() else "/home/claude/work/v8/DS-Dubstep-Studio-v8"))
sys.path.insert(0, str(PROJECT))
os.environ.setdefault("DS_CUSTOM_STYLES", "/tmp/none_custom_styles.json")     # bez stylów użytkownika — czysty test
os.environ.pop("DS_NO_SPECIAL", None)

from dubstep_studio import core, era_profiles as ERA, generator as G, live as L, special_styles as SP, styles as ST   # noqa: E402

OUT = HERE / "presets_artists.json"


def make_preset(name: str, sp: dict) -> dict:
    cfg = G.STYLES[name]
    tpl_bars = sum(b for _, b in cfg["template"])
    bars = max(32, int(round(tpl_bars / 8.0)) * 8)
    live = dict(mode="current", locks={k: False for k in L.LOCK_KEYS}, tod_on=True, tod_force=None, tod_factors=dict(L.TOD_DEFAULT),
                arr_bars=max(32, min(80, int(round(bars / 2 / 8.0)) * 8)), lookahead=1, max_store=60, return_live=True,
                mutate_p=0.0, use_board=False, new_hybrids=False)
    gen = dict(style=name, style_base=name, bpm=int(sp["bpm"]), key=None, scale=sp["scale"], bars=bars,
               energy=float(sp["energy"]), density=float(sp["density"]), swing=float(sp["swing"]),
               instruments=list(sp["inst"]), speak_manual=bool(sp.get("speak")), speak_text=sp.get("speak", ""), speak_theme=None)
    return dict(saved=datetime.datetime.now().isoformat(timespec="seconds"),
                data=dict(generator=gen, board=dict(cells=[], strength=0.4), live=live))


def check(name: str, sp: dict) -> list:
    """Zwraca listę błędów (pusta = OK)."""
    err = []
    if not dict.__contains__(G.STYLES, name):
        return [f"styl nie jest zarejestrowany jako czysty"]
    if ST.parse_hybrid(f"{name} 60% + Techno 40%", G.STYLES) is None:
        err.append("nie działa jako składnik hybrydy")
    era = ERA.resolve_era("auto", name)
    if era != sp["era"]:
        err.append(f"era auto={era}, zamierzona={sp['era']}")
    mx = ERA.ERA[era]["max_tracks"]
    if len(sp["inst"]) > mx:
        err.append(f"{len(sp['inst'])} instrumentów > limit {mx} ({era})")
    bad = [t for t in sp["inst"] if t not in core.TYPES]
    if bad:
        err.append(f"nieznane typy {bad}")
    m = core.meta()
    for t, rows in G.SOUND_STYLE[name].items():
        if t not in core.TYPES:
            err.append(f"brzmienie dla nieznanego typu {t}")
            continue
        for r in rows:
            if not m.has(t, r[0]):
                err.append(f"typ {t} nie ma parametru „{r[0]}”")
    for pat in G.WOB[SP.wob_key(name)]:
        if not pat or any(not (0 <= s < 16 and ln >= 1 and s + ln <= 16 + 8 and tk in "rofbtpu") for s, tk, ln in pat):
            err.append(f"zły wzór basu {pat}")
    return err


def smoke(name: str, sp: dict, preset: dict) -> list:
    """generate() z danymi presetu: działa, deterministyczny, stopa w dropach zgodna z pulą stylu, bas gra własnymi wzorami."""
    g = preset["data"]["generator"]; err = []
    kw = dict(style=g["style"], bpm=g["bpm"], key=None, scale=g["scale"], bars=g["bars"], energy=g["energy"], density=g["density"], swing=g["swing"],
              seed=11, instruments=g["instruments"], speak_text=g["speak_text"] if g["speak_manual"] else None)
    try:
        p1, p2 = G.generate(**kw), G.generate(**kw)
    except Exception as e:                                                          # noqa: BLE001
        return [f"generate() rzuca {type(e).__name__}: {e}"]
    if json.dumps(p1["tracks"], sort_keys=True, default=str) != json.dumps(p2["tracks"], sort_keys=True, default=str):
        err.append("generate() niedeterministyczny dla tego samego seedu")
    types = [t["type"] for t in p1["tracks"]]
    missing = [t for t in g["instruments"] if t not in types]
    if missing:
        err.append(f"brak ścieżek {missing} w projekcie")
    cfg = G.STYLES[name]
    drops = [(sec["start"], sec["start"] + sec["bars"]) for sec in p1["sections"] if sec["type"] == "drop"]

    def steps_in_drops(track):
        out = []
        for n in track["notes"]:
            bar = int(n[0] // 4)
            if any(a <= bar < b for a, b in drops):
                out.append(int(round((n[0] % 4) * 4)) % 16)
        return out

    def frac_in(steps, allowed):
        return sum(1 for s in steps if s in allowed) / len(steps) if steps else 0.0

    kick = next((t for t in p1["tracks"] if t["type"] == "kick"), None)
    if kick is not None:
        ks = steps_in_drops(kick)
        allowed = {s for pl in cfg["kick"] for s in pl}
        if not ks:
            err.append("stopa nie gra w dropach")
        elif frac_in(ks, allowed) < (0.97 if cfg.get("fourfloor") else 0.75):
            err.append(f"stopa w dropach poza pulą stylu ({frac_in(ks, allowed):.0%} w puli)")
    wob = next((t for t in p1["tracks"] if t["type"] == "wobble"), None)
    if wob is not None:
        ws = steps_in_drops(wob)
        allowed = {s for pat in G.WOB[SP.wob_key(name)] for s, _, _ in pat}
        if not ws:
            err.append("wobble nie gra w dropach (wzór basu nie zagrał)")
        elif frac_in(ws, allowed) < 0.85:
            err.append(f"wobble w dropach poza własnymi wzorami stylu ({frac_in(ws, allowed):.0%})")
    return err


def main():
    pack, bad_total = {}, 0
    for name, sp in SP.SPECIAL.items():
        preset = make_preset(name, sp)
        errs = check(name, sp) + smoke(name, sp, preset)
        if errs:
            bad_total += 1
            print(f"!! {name}:\n   " + "\n   ".join(errs), file=sys.stderr)
            continue
        pack[name] = preset
        cfg = G.STYLES[name]
        print(f"{name:46} {sp['base']:18} bpm={sp['bpm']:3} bass-wzory={len(G.WOB[SP.wob_key(name)])} brzmienia={len(G.SOUND_STYLE[name])} "
              f"stopa={len(cfg['kick'])} era={sp['era']}")
    if bad_total:
        print(f"\nBŁĘDY w {bad_total} stylach — nic nie zapisano.", file=sys.stderr)
        sys.exit(2)
    OUT.write_text(json.dumps(pack, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"\nZapisano {len(pack)} presetów (style specjalne) -> {OUT}")


if __name__ == "__main__":
    main()
