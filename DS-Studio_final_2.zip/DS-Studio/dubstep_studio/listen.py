"""listen.py — nasłuch wyjścia pulpitu (PipeWire) → cechy dźwięku → wagi stylów / preset Generatora.

Przepływ:
  Capture      pw-record (lub parec) czyta monitor domyślnego wyjścia audio (to, co gra Firefox/YouTube/cokolwiek) jako surowe f32 stereo.
  Analyzer     numpy: poziom/dynamika, pasma (sub…high), jasność, tempo (autokorelacja onsetów), puls stopy (4/4?), hi-haty (8/16, offbeat),
               swing, tonacja + skala (chroma → SCALES Studia), „wobble" (modulacja basu), szerokość stereo, tonalność.
  Session      zbiera kolejne migawki, wygładza (mediana), wykrywa zmianę utworu i liczy:
               • wagi WSZYSTKICH stylów Studia (z ich własnych konfiguracji w generator.STYLES — BPM, 4/4, hi-hat, swing, skale, klasa ostrości),
               • hybrydę „A 55% + B 30% + C 15%" (ST.hybrid_name), komórki pola stylów, dobór instrumentów,
               • pełny szkielet presetu (generator + board + live + director + flags) w formacie jak midi_import.analysis_to_preset_data.
  Nic tu nie importuje Qt — GUI (listen_gui.py) i CLI (`python3 -m dubstep_studio listen`) używają tych samych klas.

Uwaga: to analiza heurystyczna (bez uczenia maszynowego) — daje szkielet wytycznych, nie odtworzenie utworu.
"""
from __future__ import annotations

import collections
import datetime
import math
import os
import select
import shutil
import subprocess
import threading
import time

import numpy as np

RATE = 44100
HOP = 512
NFFT = 2048
BANDS = (("sub", 20, 60), ("bass", 60, 250), ("lowmid", 250, 500), ("mid", 500, 2000), ("himid", 2000, 6000), ("high", 6000, 16000))
BAND_PL = {"sub": "sub 20–60 Hz", "bass": "bas 60–250", "lowmid": "dół-środek 250–500", "mid": "środek 0,5–2 kHz", "himid": "góra-środek 2–6 kHz", "high": "góra 6–16 kHz"}

# profile Krumhansl–Schmuckler (tonacja z chromy)
_KS_MAJ = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
_KS_MIN = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])


# ====================================================================== przechwytywanie (PipeWire)
def capture_commands(target: str | None = None, rate: int = RATE) -> list[list[str]]:
    """Kolejne polecenia do wypróbowania. Wyjście: surowe f32le, 2 kanały, stdout.
    pw-record + stream.capture.sink=true = monitor domyślnego wyjścia (cały pulpit); parec przez pipewire-pulse jako zapas."""
    cmds = []
    if shutil.which("pw-record"):
        c = ["pw-record", "--raw", "--rate", str(rate), "--channels", "2", "--format", "f32", "-P", "stream.capture.sink=true"]
        if target:
            c += ["--target", target]
        cmds.append(c + ["-"])
    if shutil.which("parec"):
        cmds.append(["parec", "--format=float32le", f"--rate={rate}", "--channels=2", "-d", target or "@DEFAULT_MONITOR@"])
    if shutil.which("parecord"):
        cmds.append(["parecord", "--raw", "--format=float32le", f"--rate={rate}", "--channels=2", "-d", target or "@DEFAULT_MONITOR@"])
    return cmds


def list_targets() -> list[tuple[str, str]]:
    """[(nazwa węzła/źródła, opis)] — monitory wyjść na górze; pierwszy wpis = domyślne wyjście pulpitu (target pusty)."""
    out = [("", "domyślne wyjście pulpitu (monitor) — Firefox, YouTube, wszystko")]
    if shutil.which("pactl"):
        try:
            txt = subprocess.run(["pactl", "list", "short", "sources"], capture_output=True, text=True, timeout=4).stdout
            mon, oth = [], []
            for ln in txt.splitlines():
                p = ln.split("\t")
                if len(p) >= 2:
                    (mon if p[1].endswith(".monitor") else oth).append((p[1], ("monitor: " if p[1].endswith(".monitor") else "wejście: ") + p[1]))
            out += mon + oth
        except (OSError, subprocess.SubprocessError):
            pass
    return out


class Capture:
    """Czyta PCM z monitora wyjścia w wątku; dane trafiają do on_block(np.ndarray (n,2) float32)."""

    def __init__(self, on_block, target: str | None = None, rate: int = RATE):
        self.on_block, self.target, self.rate = on_block, target or None, rate
        self.state, self.error, self.cmd = "idle", "", None     # idle | starting | ok | error
        self.bytes_total = 0
        self._proc, self._th, self._stop = None, None, threading.Event()

    def start(self):
        self._stop.clear(); self.state = "starting"; self.error = ""
        self._th = threading.Thread(target=self._run, daemon=True, name="ds-capture"); self._th.start()

    def stop(self):
        self._stop.set()
        p = self._proc
        if p and p.poll() is None:
            try:
                p.terminate()
            except OSError:
                pass
        self.state = "idle"

    def _run(self):
        cmds = capture_commands(self.target, self.rate); tried = []
        if not cmds:
            self.state, self.error = "error", "Brak pw-record / parec — zainstaluj pipewire-utils (pw-record) albo pulseaudio-utils (parec)."
            return
        for cmd in cmds:
            if self._stop.is_set():
                return
            try:
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
            except OSError as ex:
                tried.append(f"{cmd[0]}: {ex}"); continue
            self._proc = p; t0 = time.time(); got = False; buf = b""
            fd = p.stdout.fileno()
            while not self._stop.is_set():
                r, _, _ = select.select([fd], [], [], 0.25)
                if r:
                    chunk = os.read(fd, 65536)
                    if not chunk:
                        break
                    got = True; self.cmd = cmd; self.state = "ok"; self.bytes_total += len(chunk)
                    buf += chunk; n = (len(buf) // 8) * 8
                    if n:
                        self.on_block(np.frombuffer(buf[:n], dtype="<f4").reshape(-1, 2).copy()); buf = buf[n:]
                elif p.poll() is not None:
                    break
                elif not got and time.time() - t0 > 1.5 and self.state == "starting":
                    self.cmd = cmd; self.state = "ok"      # proces żyje, ale nic nie gra (monitor milczy do pierwszego dźwięku)
            rc = p.poll()
            if self._stop.is_set():
                return
            err = b""
            try:
                err = p.stderr.read(400) if p.poll() is not None else b""
            except OSError:
                pass
            tried.append(f"{cmd[0]} (kod {rc}): {err.decode(errors='replace').strip()[:160]}")
            self.state = "starting"
        self.state, self.error = "error", "Nie udało się uruchomić przechwytywania:\n" + "\n".join(tried)


# ====================================================================== analiza sygnału
def _stft_mag(x: np.ndarray, n: int = NFFT, hop: int = HOP) -> np.ndarray:
    nfr = 1 + (len(x) - n) // hop
    idx = np.arange(n)[None, :] + hop * np.arange(nfr)[:, None]
    return np.abs(np.fft.rfft(x[idx] * np.hanning(n).astype(np.float32), axis=1)).astype(np.float32)


def _flux(lm: np.ndarray, idx) -> np.ndarray:
    return np.maximum(np.diff(lm[:, idx], axis=0), 0).sum(axis=1)


def _fold(env: np.ndarray, period: float, nb: int) -> np.ndarray:
    b = (((np.arange(len(env)) % period) / period) * nb).astype(int) % nb
    return np.bincount(b, weights=env, minlength=nb) / np.maximum(np.bincount(b, minlength=nb), 1)


def _tempo(env: np.ndarray, fps: float):
    """-> (bpm, pewność 0..1, kandydaci [(bpm, score)]). Autokorelacja onsetów z grzebieniem harmonicznych i łagodnym priorem ~125 BPM."""
    e = env - env.mean(); n = len(e)
    if n < fps * 4 or e.std() < 1e-6:
        return 0.0, 0.0, []
    f = np.fft.rfft(e, 2 * n); ac = np.fft.irfft(f * np.conj(f))[:n]
    ac = ac / (ac[0] + 1e-9) * (n / np.maximum(n - np.arange(n), 1))        # kompensacja malejącego zakładania
    def at(l):
        return float(np.interp(l, np.arange(n), ac)) if l < n - 1 else 0.0
    bpms = np.arange(60, 200.01, 0.25); sc = []
    for b in bpms:
        l = fps * 60.0 / b
        s = at(l) + 0.5 * at(2 * l) + 0.25 * at(4 * l) + 0.2 * at(l / 2)
        sc.append(s * math.exp(-0.5 * (math.log2(b / 125.0) / 1.3) ** 2))
    sc = np.array(sc); pk = [i for i in range(1, len(sc) - 1) if sc[i] >= sc[i - 1] and sc[i] > sc[i + 1]]
    pk = sorted(pk, key=lambda i: -sc[i])[:4]
    if not pk:
        return 0.0, 0.0, []
    best = pk[0]; conf = float(max(0.0, min(1.0, sc[best] / 1.4)))
    return float(bpms[best]), conf, [(float(bpms[i]), float(sc[i])) for i in pk]


def _chroma(mono: np.ndarray, rate: int) -> np.ndarray:
    """Chroma z długich okien (8192) tylko ze szczytów widma 65–2000 Hz; ramki o najmniejszej zmienności (harmoniczne) mają największą wagę."""
    n = 8192
    if len(mono) < n:
        return np.zeros(12)
    hops = np.arange(0, len(mono) - n, n // 2)
    fr = np.stack([mono[h:h + n] for h in hops]) * np.hanning(n).astype(np.float32)
    mag = np.abs(np.fft.rfft(fr, axis=1)); fq = np.fft.rfftfreq(n, 1.0 / rate)
    sel = np.where((fq >= 65) & (fq <= 2000))[0]
    pc = (np.round(12 * np.log2(fq[sel] / 261.6256)).astype(int)) % 12
    ch = np.zeros(12)
    for m in mag:
        s = m[sel]; pk = (s > np.roll(s, 1)) & (s > np.roll(s, -1)) & (s > s.max() * 0.08)
        np.add.at(ch, pc[pk], s[pk])
    return ch / (ch.sum() + 1e-9)


def _key_scale(ch: np.ndarray):
    """-> (root 0..11, nazwa skali z core.SCALES, pewność 0..1, mode 'major'|'minor'). Najpierw KS (tonika), potem dopasowanie skali Studia."""
    from . import core
    if ch.sum() < 1e-6:
        return None, "minor", 0.0, "minor"
    best = (-2, 0, "minor")
    for r in range(12):
        for prof, mode in ((_KS_MAJ, "major"), (_KS_MIN, "minor")):
            c = float(np.corrcoef(ch, np.roll(prof, r))[0, 1])
            if c > best[0]:
                best = (c, r, mode)
    corr, root, mode = best
    bs, bn = -1.0, "minor"
    for name, iv in core.SCALES.items():
        s = sum(ch[(root + i) % 12] for i in iv) + 0.25 * ch[root] - (0.12 if (mode == "major") != (name in ("major", "lydian", "mixolydian")) else 0.0)
        if s > bs:
            bs, bn = s, name
    return root, bn, float(max(0.0, min(1.0, (corr + 0.2) / 1.0))), mode


def analyze_audio(st: np.ndarray, rate: int = RATE) -> dict:
    """st: (n,2) float32. Zwraca słownik cech (patrz kluczowe pola poniżej); przy ciszy {'silent': True}."""
    F: dict = {"dur": len(st) / rate}
    mono = ((st[:, 0] + st[:, 1]) * 0.5).astype(np.float32); side = ((st[:, 0] - st[:, 1]) * 0.5).astype(np.float32)
    rms = float(np.sqrt(np.mean(mono ** 2))); F["rms_db"] = 20 * math.log10(rms + 1e-9); F["peak_db"] = 20 * math.log10(float(np.abs(st).max()) + 1e-9)
    F["crest_db"] = F["peak_db"] - F["rms_db"]
    blk = int(0.4 * rate); nb = len(mono) // blk
    if nb >= 2:
        r = np.sqrt(np.mean(mono[:nb * blk].reshape(nb, blk) ** 2, axis=1)); db = 20 * np.log10(r + 1e-9)
        F["dyn_db"] = float(np.percentile(db, 95) - np.percentile(db, 10)); F["silence"] = float(np.mean(db < -60))
    else:
        F["dyn_db"], F["silence"] = 0.0, 0.0
    if rms < 1e-4 or len(mono) < rate * 4:
        F["silent"] = True; return F
    F["silent"] = False
    F["width"] = float(np.sqrt(np.mean(side ** 2)) / (np.sqrt(np.mean(mono ** 2)) + np.sqrt(np.mean(side ** 2)) + 1e-9))

    mag = _stft_mag(mono); fq = np.fft.rfftfreq(NFFT, 1.0 / rate); fps = rate / HOP
    P = (mag ** 2)
    tot = float(P[:, (fq >= 20) & (fq < 16000)].sum()) + 1e-12
    F["bands"] = {n: float(P[:, (fq >= lo) & (fq < hi)].sum() / tot) for n, lo, hi in BANDS}
    ms = P.mean(axis=0); F["centroid"] = float((fq * ms).sum() / (ms.sum() + 1e-12))
    cs = np.cumsum(ms); F["rolloff"] = float(fq[min(len(fq) - 1, int(np.searchsorted(cs, 0.85 * cs[-1])))])
    sel = (fq >= 100) & (fq < 8000); m = mag[:, sel] + 1e-9
    F["flat"] = float(np.mean(np.exp(np.mean(np.log(m), axis=1)) / np.mean(m, axis=1)))   # 0 tonalny … 1 szumowy

    lm = np.log1p(mag)
    lo_i, mi_i, hi_i = np.where((fq >= 30) & (fq < 200))[0], np.where((fq >= 200) & (fq < 2500))[0], np.where((fq >= 4000) & (fq < 14000))[0]
    all_i = np.where((fq >= 30) & (fq < 14000))[0]
    f_all, f_lo, f_mi, f_hi = _flux(lm, all_i), _flux(lm, lo_i), _flux(lm, mi_i), _flux(lm, hi_i)
    loc = np.convolve(f_all, np.ones(43) / 43, mode="same")
    e_all = np.maximum(f_all - 0.8 * loc, 0)
    F["hat_share"] = float(f_hi.mean() / (f_all.mean() + 1e-9)); F["kick_share"] = float(f_lo.mean() / (f_all.mean() + 1e-9))

    bpm, conf, cands = _tempo(e_all, fps)
    F["tempo_raw"], F["tempo_conf"], F["tempo_cands"] = bpm, conf, cands
    # BPM „przyjazny" Studiu: 90–180 (połówka/dwukrotność gdy poza zakresem)
    b = bpm
    while 0 < b < 90:
        b *= 2
    while b > 180:
        b /= 2
    F["bpm"] = float(b)
    pulse = hat16 = offb = swing = 0.0; sym = 0.0
    if b > 0:
        p = fps * 60.0 / b
        base = _fold(f_lo if f_lo.std() > 0 else e_all, p, 24)
        sh = int(np.argmax(np.convolve(np.r_[base[-1:], base, base[:1]], np.ones(3) / 3, mode="valid")))
        roll = lambda a, k=24: np.roll(a, -sh * k // 24)
        lo_p = roll(base)
        on = lo_p[[-1, 0, 1]].mean(); mean = lo_p.mean()
        pulse = float((on - mean) / (on + mean + 1e-9))
        lo2 = np.roll(_fold(f_lo, 2 * p, 48), -sh * 2)
        a_, b_ = lo2[[-1, 0, 1]].mean(), lo2[[23, 24, 25]].mean()
        sym = float(min(a_, b_) / (max(a_, b_) + 1e-9))
        hp = roll(_fold(f_hi, p, 24))
        hat16 = float(hp[[5, 6, 7, 17, 18, 19]].mean() / (hp[[-1, 0, 1, 11, 12, 13]].mean() + 1e-9))
        offb = float((hp[11:14].mean() - hp[[-1, 0, 1]].mean()) / (hp[11:14].mean() + hp[[-1, 0, 1]].mean() + 1e-9))
        ap = roll(_fold(e_all, p, 24)); seg = ap[8:20]; c = float((np.arange(8, 20) * seg).sum() / (seg.sum() + 1e-9)) / 24.0
        swing = float(max(0.0, min(1.0, (c - 0.5) / 0.1667)))
        # onsety na sekundę (szczyty e_all)
        thr = e_all.mean() + 0.9 * e_all.std(); pk = (e_all > np.roll(e_all, 1)) & (e_all >= np.roll(e_all, -1)) & (e_all > thr)
        F["onsets_s"] = float(pk.sum() / (len(e_all) / fps)); F["onsets_beat"] = F["onsets_s"] / (b / 60.0)
    else:
        F["onsets_s"] = F["onsets_beat"] = 0.0
    pn = max(0.0, min(1.0, (pulse - 0.25) / 0.45))
    F["kick_pulse"] = pn; F["kick_sym"] = sym; F["fourfloor"] = float(pn * (0.25 + 0.75 * sym)) if b else 0.0
    F["hat16"], F["hat_offbeat"], F["swing"] = max(0.0, hat16), offb, swing

    # wobble: modulacja obwiedni pasma 200–1200 Hz w zakresie 0,7–10 Hz
    wi = np.where((fq >= 200) & (fq < 1200))[0]; env = np.sqrt(P[:, wi].sum(axis=1)); env = env / (env.mean() + 1e-9)
    X = np.abs(np.fft.rfft((env - env.mean()) * np.hanning(len(env)))) * 2 / (len(env) * 0.5); mf = np.fft.rfftfreq(len(env), 1.0 / fps)
    mk = np.where((mf >= 0.7) & (mf <= 10))[0]
    if len(mk):
        j = mk[int(np.argmax(X[mk]))]; F["wob_hz"] = float(mf[j]); wd = float(X[j])
    else:
        F["wob_hz"], wd = 0.0, 0.0
    F["wobble"] = float(max(0.0, min(1.0, wd * 1.6)) * (1.0 - 0.6 * pn))

    # harmonika
    ch = _chroma(mono, rate); root, scale, kc, mode = _key_scale(ch)
    F["chroma"] = [float(x) for x in ch]; F["key"], F["scale"], F["key_conf"], F["mode"] = root, scale, kc, mode
    F["tonal"] = float(max(0.0, min(1.0, 1.0 - 1.6 * F["flat"])))
    # „energia" i „gęstość" Studia (0..1) — heurystyki
    loud = max(0.0, min(1.0, (F["rms_db"] + 32) / 22)); bright = max(0.0, min(1.0, math.log2(max(F["centroid"], 100) / 300) / 3.7))
    tempo_n = max(0.0, min(1.0, (b - 70) / 110)) if b else 0.4
    F["brightness"] = bright
    F["energy"] = float(max(0.2, min(0.97, 0.15 + 0.32 * loud + 0.2 * bright + 0.18 * tempo_n + 0.2 * min(1.0, F["onsets_beat"] / 3.0))))
    F["density"] = float(max(0.2, min(0.9, 0.2 + 0.6 * math.log2(1 + F["onsets_beat"]) / math.log2(7))))
    F["aggr"] = float(5.0 * max(0.0, min(1.0, 0.42 * F["energy"] + 0.18 * F["flat"] * 2 + 0.2 * (F["bands"]["sub"] + F["bands"]["bass"]) + 0.2 * (1 - F["crest_db"] / 20.0))))
    F["sustained"] = float(max(0.0, min(1.0, 1.0 - F["onsets_beat"] / 3.0)))
    F["fingerprint"] = [F["bands"][n] ** 0.5 for n, _, _ in BANDS] + [x ** 0.5 for x in ch]
    return F


# ====================================================================== style: profile z konfiguracji Studia + wagi
_STYLE_INFO: dict | None = None
_HAT_EXP = {"16": 1.0, "trap": 1.0, "8": 0.45, "offbeat": 0.3, "ride": 0.4, "off": 0.0, "none": 0.0}


def style_infos() -> dict:
    """Profil każdego stylu wyprowadzony z jego konfiguracji (generator.STYLES) — te same liczby, których używa generator."""
    global _STYLE_INFO
    if _STYLE_INFO is not None:
        return _STYLE_INFO
    from . import generator as G, styles as ST
    dub = set(dict(ST.GROUPS)["Dubstep"]); amb = set(dict(ST.GROUPS)["Space / ambient"]) | set(dict(ST.GROUPS)["Klasyka / jazz"])
    out = {}
    for n in ST.ORDER:
        c = G.STYLES[n]; core_l = c.get("core")
        out[n] = dict(bpm=float(c.get("bpm", 130)), ff=bool(c.get("fourfloor")), hat=str(c.get("hat", "16")), swing=float(c.get("swing", 0.0) or 0.0),
                      drums=("kick" in core_l) if core_l else True, scales=list(c.get("scales") or []), cls=float(ST.STYLE_CLASS.get(n, 2.5)),
                      wob=1.0 if n in dub and n not in ("EDM", "Deep") else (0.5 if n in ("Neurofunk", "Deep", "Acid Techno") else 0.0),
                      bassmusic=n in dub or n in ("DnB", "Liquid DnB", "Neurofunk"), quiet=n in amb,
                      template=c.get("template"), group=next(g for g, ss in ST.GROUPS if n in ss))
    _STYLE_INFO = out
    return out


def style_weights(F: dict, sharp: float = 9.0) -> tuple[dict, dict]:
    """-> (wagi stylów sumujące się do 1, wyniki dopasowania 0..1). Każdy człon to dopasowanie cechy do profilu stylu, z wagą ważności."""
    infos = style_infos(); sc = {}
    bpm = F.get("bpm") or 0.0; raw = F.get("tempo_raw") or bpm
    bm = F["bands"]["sub"] + F["bands"]["bass"]
    perc = max(F.get("kick_pulse", 0.0), min(1.0, F.get("onsets_beat", 0.0) / 1.5))
    for n, I in infos.items():
        tot = w = 0.0
        def add(v, wt):
            nonlocal tot, w
            tot += max(0.0, min(1.0, v)) * wt; w += wt
        if bpm > 0:
            t = 0.0
            for cand, pen in ((bpm, 1.0), (bpm * 2, 0.8), (bpm / 2, 0.8), (raw, 0.9)):
                if cand > 0:
                    t = max(t, pen * math.exp(-0.5 * (math.log(cand / I["bpm"]) / 0.06) ** 2))
            add(t, 3.0)
        add(1.0 - abs(F["fourfloor"] - (1.0 if I["ff"] else 0.2)), 1.6)
        add((1.0 - perc) if not I["drums"] else (0.35 + 0.65 * perc), 2.0)
        add(1.0 - abs(F["aggr"] - I["cls"]) / 5.0, 1.5)
        exp_h = _HAT_EXP.get(I["hat"], 0.5)
        h16 = max(0.0, min(1.0, F["hat16"] / 1.2))
        add(1.0 - abs(h16 - exp_h) if I["drums"] else 1.0 - h16, 0.7)
        if I["hat"] == "offbeat":
            add(0.5 + 0.5 * max(-1.0, min(1.0, F["hat_offbeat"] * 2)), 0.5)
        add(1.0 - abs(F["swing"] * 0.15 - I["swing"]) / 0.15, 0.4)
        if I["scales"]:
            add(1.0 if F["scale"] == I["scales"][0] else (0.75 if F["scale"] in I["scales"] else 0.25), 0.6)
        add(1.0 - abs(F["wobble"] - I["wob"]), 0.9)
        if I["bassmusic"]:
            add(min(1.0, bm / 0.35), 0.7)
        if I["quiet"]:
            add(F["tonal"], 0.8 if not I["drums"] else 0.4)
        sc[n] = tot / w if w else 0.0
    mx = max(sc.values()); ex = {k: math.exp((v - mx) * sharp) for k, v in sc.items()}; z = sum(ex.values())
    return {k: v / z for k, v in ex.items()}, sc


def infer_instruments(F: dict, weights: dict) -> list[str]:
    """Typy DS, których cechy słychać w sygnale (heurystyka) + rdzeń dominującego stylu, żeby zestaw nie był pusty."""
    from . import core, generator as G
    bm = F["bands"]; ins: list[str] = []
    def add(t):
        if t in core.TYPES and t not in ins:
            ins.append(t)
    if F["kick_pulse"] > 0.35:
        add("kick")
    if F["bands"]["mid"] + F["bands"]["himid"] > 0.12 and F["onsets_beat"] > 1.2 and F["kick_pulse"] > 0.2:
        add("snare"); add("clap") if F["kick_pulse"] > 0.5 and F["hat_share"] < 0.25 else None
    if F["hat_share"] > 0.12:
        add("hat")
    if F["hat_offbeat"] > 0.3 and F["hat_share"] > 0.1:
        add("openhat")
    if bm["sub"] > 0.12:
        add("sub")
    if bm["bass"] + bm["sub"] > 0.30:
        add("bass808" if F["sustained"] > 0.45 else "fmbass")
    if F["wobble"] > 0.35:
        add("wobble")
    if F["wobble"] > 0.5 and F["flat"] > 0.12:
        add("growl")
    if F["sustained"] > 0.55 and bm["mid"] + bm["lowmid"] > 0.18 and F["tonal"] > 0.3:
        add("pad")
    if F["tonal"] > 0.45 and 0.25 < F["sustained"] < 0.8 and bm["mid"] + bm["himid"] > 0.2:
        add("epiano" if F["brightness"] < 0.5 else "pluck")
    if F["brightness"] > 0.6 and F["tonal"] > 0.3 and bm["himid"] > 0.12:
        add("supersaw")
    top = max(weights, key=weights.get)
    for t in (G.STYLES[top].get("core") or []):
        if len(ins) >= 4:
            break
        add(t)
    return ins[:14]


# ====================================================================== sesja: wygładzanie, raport, preset
class Session:
    """Zbiera migawki cech z kolejnych okien analizy i buduje raport (wagi stylów, preset). Wątek-niezależna, bez Qt."""

    def __init__(self, keep: int = 8):
        self.snaps: collections.deque = collections.deque(maxlen=keep); self.listened = 0.0; self.songs = 1
        self._fp = None; self._off = 0

    def reset(self):
        self.snaps.clear(); self.listened = 0.0; self._fp = None; self.songs += 1

    def add(self, F: dict, step_sec: float = 2.0, auto_reset: bool = True) -> bool:
        """Zwraca True gdy wykryto nowy utwór (sesja została wyzerowana przed dodaniem)."""
        if F.get("silent"):
            return False
        new = False
        fp = np.array(F["fingerprint"])
        if self._fp is not None and auto_reset:
            sim = float(np.dot(fp, self._fp) / (np.linalg.norm(fp) * np.linalg.norm(self._fp) + 1e-9))
            self._off = self._off + 1 if sim < 0.82 else 0
            if self._off >= 2 and len(self.snaps) >= 3:
                self.reset(); new = True; self._off = 0
        self._fp = fp if self._fp is None else 0.7 * self._fp + 0.3 * fp
        self.snaps.append(F); self.listened += step_sec
        return new

    def aggregate(self) -> dict | None:
        S = list(self.snaps)
        if not S:
            return None
        med = lambda k: float(np.median([s[k] for s in S]))
        A = {k: med(k) for k in ("rms_db", "peak_db", "crest_db", "dyn_db", "silence", "width", "centroid", "rolloff", "flat", "hat_share", "kick_share", "kick_pulse",
                                   "kick_sym", "fourfloor", "hat16", "hat_offbeat", "swing", "onsets_beat", "onsets_s", "wobble", "wob_hz", "tonal", "brightness",
                                   "energy", "density", "aggr", "sustained", "tempo_conf", "tempo_raw", "key_conf")}
        A["bands"] = {n: float(np.median([s["bands"][n] for s in S])) for n, _, _ in BANDS}
        # BPM: mediana, z ważeniem pewnością; zaokrąglenie gdy blisko całkowitej
        bs = [(s["bpm"], s["tempo_conf"]) for s in S if s["bpm"] > 0]
        A["bpm"] = float(np.median([b for b, _ in bs])) if bs else 0.0
        if abs(A["bpm"] - round(A["bpm"])) < 0.18:
            A["bpm"] = float(round(A["bpm"]))
        ch = np.mean([s["chroma"] for s in S], axis=0); root, scale, kc, mode = _key_scale(ch)
        A["key"], A["scale"], A["key_conf"], A["mode"], A["chroma"] = root, scale, kc, mode, [float(x) for x in ch]
        A["dur"] = sum(s["dur"] for s in S[-1:])
        return A

    def report(self) -> dict | None:
        A = self.aggregate()
        if A is None:
            return None
        from . import core, generator as G, styles as ST
        w, sc = style_weights(A)
        name = ST.hybrid_name({k: v for k, v in w.items() if v >= 0.05}, min_share=0.08) or max(w, key=w.get)
        if not ST.parse_hybrid(name, G.STYLES) and name not in G.STYLES:
            name = max(w, key=w.get)
        ranked = sorted(w.items(), key=lambda kv: -kv[1])
        top = ranked[0][0]; infos = style_infos()
        inst = infer_instruments(A, w)
        confidence = float(max(0.0, min(1.0, (self.listened / 30.0) * (0.35 + 0.65 * A["tempo_conf"]))))
        mood = max(-1.0, min(1.0, (0.45 if A["mode"] == "major" else -0.45) + (A["brightness"] - 0.5) * 0.9))
        bars = 64 if A["energy"] < 0.5 else 96 if A["energy"] < 0.75 else 144
        gen = dict(style=name, style_base=top, bpm=int(round(A["bpm"])) if A["bpm"] else 128, key=A["key"], scale=A["scale"], bars=bars,
                   energy=round(A["energy"], 2), density=round(A["density"], 2), swing=round(A["swing"] * 0.15, 3), instruments=inst,
                   speak_manual=False, speak_text="", speak_theme=None)
        cells = []
        for k, v in ranked[:3]:
            lv = max(1, min(3, int(round(3 * v / ranked[0][1]))))
            if v >= 0.08:
                cells.append([k, k, lv])
        tpl = infos[top].get("template") or []
        live = dict(mode="current", locks={k: False for k in ("style", "bpm", "key", "scale", "energy", "density", "swing", "bars", "instruments")}, tod_on=True,
                    tod_force=None, tod_factors={"Rano": 0.88, "Popołudnie": 1.0, "Wieczór": 1.06, "Noc": 0.9},
                    arr_bars=max(32, min(80, int(round(bars / 2 / 8.0)) * 8)), lookahead=1, max_store=60, return_live=True, mutate_p=0.0,
                    use_board=len(cells) > 1, new_hybrids=False, complexity="balanced", complexity_intensity=round(A["density"], 2), complexity_follow_tod=True)
        director = dict(on=True, mood=round(mood, 2), scenario=True, pick_instruments=False, instruments_locked=False)
        flags = dict(scene_apply=False, arp=bool(A["hat16"] > 0.8 and A["tonal"] > 0.5 and A["brightness"] > 0.45), niuanse=A["dyn_db"] > 6.0)
        preset_name = f"Nasłuch — {top} {gen['bpm']} BPM {core.NOTE_NAMES[A['key']] if A['key'] is not None else '?'} {A['scale']} {datetime.datetime.now():%d.%m %H:%M}"
        rep = dict(features=A, weights=w, scores=sc, ranked=ranked, style=name, top=top, confidence=confidence, listened=self.listened, songs=self.songs,
                   generator=gen, board=dict(cells=cells, strength=0.4), live=live, director=director, flags=flags, preset_name=preset_name,
                   template=dict(style=top, sections=tpl, bars=sum(b for _, b in tpl) if tpl else None), group=infos[top]["group"])
        rep["will_add"] = will_add_rows(rep)
        return rep


def preset_data(rep: dict, style_override: str | None = None) -> dict:
    """Raport → dane presetu (format jak collect_preset / midi_import.analysis_to_preset_data); style_override = ręcznie wybrany styl/hybryda."""
    gen = dict(rep["generator"])
    if style_override:
        gen["style"] = style_override; gen["style_base"] = style_override.split(" ")[0] if "%" not in style_override else rep["top"]
    return dict(generator=gen, board=dict(rep["board"]), live=dict(rep["live"]), director=dict(rep["director"]), flags=dict(rep["flags"]),
                analysis=dict(source="nasłuch pulpitu (PipeWire)", bpm=rep["features"]["bpm"], listened_s=round(rep["listened"], 1), confidence=round(rep["confidence"], 2),
                              weights={k: round(v, 3) for k, v in rep["ranked"][:8]}))


def will_add_rows(rep: dict) -> list[tuple[str, str, str]]:
    """Tabela „co zostanie dodane": (grupa, ustawienie, wartość) — to samo, co trafi do presetu po „Zastosuj"."""
    from . import core
    g, A = rep["generator"], rep["features"]; rows = []
    k = core.NOTE_NAMES[g["key"]] if g["key"] is not None else "losowa"
    rows += [("generator", "Styl (hybryda wg wag)", g["style"]), ("generator", "BPM", str(g["bpm"])), ("generator", "Tonacja / skala", f"{k} {g['scale']}"),
             ("generator", "Energia", f"{g['energy']:.2f}"), ("generator", "Gęstość", f"{g['density']:.2f}"), ("generator", "Swing", f"{g['swing']:.3f}"),
             ("generator", "Długość", f"{g['bars']} taktów"), ("generator", "Instrumenty", ", ".join(g["instruments"]))]
    rows.append(("board", "Pole stylów", "  ".join(f"{b}×{lv}" for b, _, lv in rep["board"]["cells"]) or "—"))
    t = rep["template"]
    rows.append(("szablon", f"Struktura ({t['style']})", " → ".join(f"{s} {b}" for s, b in t["sections"]) if t["sections"] else "domyślna"))
    L = rep["live"]
    rows += [("live", "Tryb / takty na aranżację", f"{L['mode']} / {L['arr_bars']}"), ("live", "Pole stylów w Live", "tak" if L["use_board"] else "nie"),
             ("live", "Complexity", f"{L['complexity']} ({L['complexity_intensity']})")]
    D = rep["director"]
    rows.append(("director", "Reżyser: charakter (mood)", f"{D['mood']:+.2f}"))
    F = rep["flags"]
    rows += [("flags", "Komplet sceny stylu", "wyłączony (zostają zmierzone energia/gęstość)"), ("flags", "Arp", "tak" if F["arp"] else "nie"), ("flags", "Niuanse", "tak" if F["niuanse"] else "nie")]
    rows.append(("preset", "Nazwa presetu", rep["preset_name"]))
    return rows


def characteristics_rows(rep: dict) -> list[tuple[str, str]]:
    """Wykryte cechy (do okna charakterystyki)."""
    from . import core
    A = rep["features"]; b = A["bands"]
    k = f"{core.NOTE_NAMES[A['key']]} {A['scale']} (pewność {A['key_conf']:.0%})" if A["key"] is not None else "—"
    return [("Tempo", f"{A['bpm']:.1f} BPM (pewność {A['tempo_conf']:.0%}; surowe {A['tempo_raw']:.1f})"), ("Tonacja / skala", k),
            ("Głośność / dynamika", f"{A['rms_db']:.1f} dBFS RMS, crest {A['crest_db']:.1f} dB, rozstrzał {A['dyn_db']:.1f} dB"),
            ("Jasność", f"środek ciężkości {A['centroid']:.0f} Hz, 85% energii < {A['rolloff']:.0f} Hz"),
            ("Puls stopy / 4-on-the-floor", f"puls {A['kick_pulse']:.0%}, symetria {A['kick_sym']:.0%} → 4/4: {A['fourfloor']:.0%}"),
            ("Hi-haty", f"16-tki {min(1.0, A['hat16'] / 1.2):.0%}, offbeat {max(0.0, A['hat_offbeat']):.0%}, udział góry {A['hat_share']:.0%}"),
            ("Swing", f"{A['swing']:.0%}"), ("Wobble (modulacja basu)", f"{A['wobble']:.0%} @ {A['wob_hz']:.1f} Hz"),
            ("Tonalność / sustain", f"{A['tonal']:.0%} / {A['sustained']:.0%}"), ("Stereo", f"szerokość {A['width']:.0%}"),
            ("Onsety", f"{A['onsets_beat']:.1f} na ćwierćnutę"),
            ("Energia / gęstość / ostrość", f"{A['energy']:.2f} / {A['density']:.2f} / {A['aggr']:.1f} (skala 0–5 jak klasa stylu)")] + \
           [(BAND_PL[n], f"{b[n]:.0%}") for n, _, _ in BANDS]


# ====================================================================== nasłuchiwacz: capture + okno kroczące + okresowy raport
class Listener:
    """Capture → bufor kroczący (window s) → co interval s analiza → Session → callback(report, new_song, status)."""

    def __init__(self, on_report, target: str | None = None, window: float = 20.0, interval: float = 2.0, auto_reset: bool = True, rate: int = RATE):
        self.on_report, self.window, self.interval, self.auto_reset, self.rate = on_report, window, interval, auto_reset, rate
        self.session = Session(); self.cap = Capture(self._feed, target, rate)
        self._chunks: collections.deque = collections.deque(); self._n = 0; self._lock = threading.Lock()
        self._stop = threading.Event(); self._th = None; self.level_db = -120.0; self.error = ""

    def _feed(self, blk: np.ndarray):
        with self._lock:
            self._chunks.append(blk); self._n += len(blk)
            cap = int(self.window * self.rate)
            while self._n - len(self._chunks[0]) >= cap:
                self._n -= len(self._chunks.popleft())
        self.level_db = 20 * math.log10(float(np.sqrt(np.mean(blk ** 2))) + 1e-9)

    def window_audio(self) -> np.ndarray:
        with self._lock:
            return np.concatenate(list(self._chunks)) if self._chunks else np.zeros((0, 2), np.float32)

    def start(self):
        self._stop.clear(); self.cap.start()
        self._th = threading.Thread(target=self._loop, daemon=True, name="ds-listen"); self._th.start()

    def stop(self):
        self._stop.set(); self.cap.stop()

    def _loop(self):
        last = 0
        while not self._stop.wait(0.3):
            if self.cap.state == "error":
                self.error = self.cap.error; self.on_report(None, False, f"błąd: {self.cap.error}"); return
            if self._n < self.rate * 6 or time.time() - last < self.interval:
                if self._n < self.rate * 6:
                    self.on_report(None, False, f"zbieram dźwięk… {self._n / self.rate:.0f}/6 s ({self.cap.state}, poziom {self.level_db:.0f} dB)")
                continue
            last = time.time()
            try:
                F = analyze_audio(self.window_audio(), self.rate)
                if F.get("silent"):
                    self.on_report(None, False, "cisza na wyjściu — włącz utwór (Firefox/YouTube…)"); continue
                new = self.session.add(F, self.interval, self.auto_reset)
                self.on_report(self.session.report(), new, "słucham")
            except Exception as ex:     # analiza nie może zabić wątku
                self.on_report(None, False, f"błąd analizy: {ex}")


# ====================================================================== pliki (test / tryb offline)
def load_audio_file(path: str, rate: int = RATE, max_sec: float | None = None) -> np.ndarray:
    """Dekoduje dowolny plik przez ffmpeg do f32 stereo (n,2)."""
    cmd = ["ffmpeg", "-v", "error", "-i", str(path), "-f", "f32le", "-ac", "2", "-ar", str(rate)]
    if max_sec:
        cmd += ["-t", str(max_sec)]
    raw = subprocess.run(cmd + ["-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, dtype="<f4").reshape(-1, 2).copy()


def analyze_stream(st: np.ndarray, rate: int = RATE, window: float = 20.0, step: float = 2.0) -> dict | None:
    """Odtwarza sesję na gotowym sygnale: okno kroczące co `step` s — dokładnie jak na żywo. -> ostatni raport."""
    s = Session(); rep = None; w = int(window * rate); n = len(st)
    t = int(min(n, 6 * rate))
    while t <= n:
        F = analyze_audio(st[max(0, t - w):t], rate); s.add(F, step); rep = s.report() or rep
        t += int(step * rate)
    return rep
