"""listen_gui.py — zakładka „Nasłuch": przechwytywanie wyjścia pulpitu → cechy → preset Generatora.

Używa listen.Listener / Session (bez zależności od Qt w rdzeniu).
"""
from __future__ import annotations

from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import listen as LS
from . import presets as PR
from . import styles as ST


class ListenTab(W.QWidget):
    """Panel nasłuchu: start/stop, status, ranking stylów, cechy, zastosuj jako preset."""

    # sygnał z wątku roboczego → GUI (rep dict | None, new_song, msg)
    reportReady = QtCore.pyqtSignal(object, bool, str)

    def __init__(self, main):
        super().__init__()
        self.main = main
        self.listener: LS.Listener | None = None
        self._last_rep: dict | None = None
        self.reportReady.connect(self._on_report)
        self._build()

    def _build(self):
        v = W.QVBoxLayout(self)

        # --- sterowanie ---
        row = W.QHBoxLayout()
        self.btn_start = W.QPushButton("Start nasłuchu")
        self.btn_stop = W.QPushButton("Stop")
        self.btn_stop.setEnabled(False)
        self.btn_file = W.QPushButton("Analizuj plik audio…")
        self.btn_apply = W.QPushButton("Zastosuj jako preset…")
        self.btn_apply.setEnabled(False)
        self.btn_save = W.QPushButton("Zapisz preset…")
        self.btn_save.setEnabled(False)
        for b in (self.btn_start, self.btn_stop, self.btn_file, self.btn_apply, self.btn_save):
            row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)

        self.btn_start.clicked.connect(self._start)
        self.btn_stop.clicked.connect(self._stop)
        self.btn_file.clicked.connect(self._analyze_file)
        self.btn_apply.clicked.connect(self._apply)
        self.btn_save.clicked.connect(self._save)

        # opcje
        opt = W.QHBoxLayout()
        self.auto_reset = W.QCheckBox("Auto-reset przy zmianie utworu")
        self.auto_reset.setChecked(True)
        self.interval = W.QDoubleSpinBox()
        self.interval.setRange(0.5, 10.0)
        self.interval.setSingleStep(0.5)
        self.interval.setValue(2.0)
        self.interval.setSuffix(" s")
        opt.addWidget(self.auto_reset)
        opt.addWidget(W.QLabel("Interwał:"))
        opt.addWidget(self.interval)
        opt.addStretch(1)
        v.addLayout(opt)

        self.status = W.QLabel("Gotowy — uruchom nasłuch albo wskaż plik audio (mp3/wav/flac…).")
        self.status.setWordWrap(True)
        v.addWidget(self.status)

        # poziom
        self.level = W.QProgressBar()
        self.level.setRange(-60, 0)
        self.level.setValue(-60)
        self.level.setFormat("poziom %v dB")
        v.addWidget(self.level)

        # split: ranking stylów | cechy
        split = W.QSplitter(Qt.Orientation.Horizontal)

        left = W.QWidget()
        lv = W.QVBoxLayout(left)
        lv.addWidget(W.QLabel("Ranking stylów (wagi):"))
        self.rank = W.QListWidget()
        lv.addWidget(self.rank, 1)
        split.addWidget(left)

        right = W.QWidget()
        rv = W.QVBoxLayout(right)
        rv.addWidget(W.QLabel("Cechy / propozycja Generatora:"))
        self.feat = W.QPlainTextEdit()
        self.feat.setReadOnly(True)
        self.feat.setMaximumBlockCount(200)
        rv.addWidget(self.feat, 1)
        split.addWidget(right)
        split.setSizes([280, 420])
        v.addWidget(split, 1)

        # styl override
        srow = W.QHBoxLayout()
        srow.addWidget(W.QLabel("Styl do zastosowania:"))
        self.style_cb = W.QComboBox()
        self.style_cb.setEditable(True)
        self.style_cb.setMinimumWidth(280)
        srow.addWidget(self.style_cb, 1)
        v.addLayout(srow)

        # timer UI (odświeżanie poziomu)
        self._ui_timer = QtCore.QTimer(self)
        self._ui_timer.timeout.connect(self._tick_ui)
        self._ui_timer.start(200)

    # ------------------------------------------------------------------ nasłuch
    def _start(self):
        self._stop()
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.status.setText("Uruchamiam przechwytywanie wyjścia pulpitu…")

        def on_report(rep, new_song, msg):
            self.reportReady.emit(rep, bool(new_song), str(msg or ""))

        try:
            self.listener = LS.Listener(
                on_report=on_report,
                interval=float(self.interval.value()),
                auto_reset=self.auto_reset.isChecked(),
            )
            self.listener.start()
        except Exception as ex:
            self.status.setText(f"Błąd startu: {ex}")
            self.btn_start.setEnabled(True)
            self.btn_stop.setEnabled(False)
            self.listener = None

    def _stop(self):
        if self.listener:
            try:
                self.listener.stop()
            except Exception:
                pass
            self.listener = None
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)

    def _on_report(self, rep, new_song, msg):
        if rep is None:
            self.status.setText(msg or "—")
            return
        self._last_rep = rep
        self.btn_apply.setEnabled(True)
        self.btn_save.setEnabled(True)
        tag = " ● nowy utwór" if new_song else ""
        self.status.setText(f"{msg}{tag}  |  słuchano {rep.get('listened', 0):.0f}s  |  pewność {rep.get('confidence', 0):.0%}")
        self._fill_rank(rep)
        self._fill_feat(rep)
        self._fill_styles(rep)

    def _tick_ui(self):
        if self.listener:
            try:
                db = float(getattr(self.listener, "level_db", -60))
                self.level.setValue(int(max(-60, min(0, db))))
            except Exception:
                pass

    def _fill_rank(self, rep):
        self.rank.clear()
        for name, w in (rep.get("ranked") or [])[:12]:
            self.rank.addItem(f"{w:5.1%}  {name}")

    def _fill_feat(self, rep):
        lines = []
        try:
            for label, val in LS.characteristics_rows(rep):
                lines.append(f"{label}: {val}")
            lines.append("")
            for group, label, val in LS.will_add_rows(rep):
                lines.append(f"[{group}] {label}: {val}")
        except Exception:
            g = rep.get("generator") or {}
            lines.append(f"styl={g.get('style')} BPM={g.get('bpm')} scale={g.get('scale')}")
            lines.append(f"E={g.get('energy')} D={g.get('density')} inst={g.get('instruments')}")
        self.feat.setPlainText("\n".join(lines))

    def _fill_styles(self, rep):
        self.style_cb.clear()
        ranked = rep.get("ranked") or []
        for name, w in ranked[:6]:
            self.style_cb.addItem(f"{name}  ({w:.0%})", name)
        # hybryda z raportu
        st = (rep.get("generator") or {}).get("style")
        if st:
            self.style_cb.insertItem(0, st, st)
            self.style_cb.setCurrentIndex(0)
        self.style_cb.insertSeparator(self.style_cb.count())
        for s in ST.ORDER:
            self.style_cb.addItem(s, s)

    # ------------------------------------------------------------------ plik offline
    def _analyze_file(self):
        path, _ = W.QFileDialog.getOpenFileName(
            self, "Analizuj plik audio",
            str(Path.home()),
            "Audio (*.mp3 *.wav *.flac *.ogg *.m4a);;Wszystkie (*)",
        )
        if not path:
            return
        self.status.setText(f"Analizuję plik… {Path(path).name}")
        W.QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            st = LS.load_audio_file(path, max_sec=90.0)
            rep = LS.analyze_stream(st, window=20.0, step=2.0)
        except Exception as ex:
            W.QApplication.restoreOverrideCursor()
            W.QMessageBox.critical(self, "Nasłuch", f"Nie udało się przeanalizować:\n{ex}")
            return
        finally:
            W.QApplication.restoreOverrideCursor()
        if not rep:
            self.status.setText("Brak wyniku analizy (za krótki sygnał?).")
            return
        self._last_rep = rep
        self.btn_apply.setEnabled(True)
        self.btn_save.setEnabled(True)
        self.status.setText(f"Plik: {Path(path).name} — analiza OK")
        self._fill_rank(rep)
        self._fill_feat(rep)
        self._fill_styles(rep)

    # ------------------------------------------------------------------ apply / save
    def _preset_data(self):
        if not self._last_rep:
            return None
        override = self.style_cb.currentData() or self.style_cb.currentText().split("  (")[0].strip()
        return LS.preset_data(self._last_rep, style_override=override or None)

    def _apply(self):
        data = self._preset_data()
        if not data:
            return
        groups = self.main._preset_groups_dialog(data, title="Zastosuj wynik nasłuchu")
        if not groups:
            return
        self.main.apply_preset(data, groups=groups)
        self.main.status.setText(
            f"Nasłuch → zastosowano {', '.join(sorted(groups))}  |  styl={data['generator'].get('style')}"
        )

    def _save(self):
        data = self._preset_data()
        if not data:
            return
        default = (self._last_rep or {}).get("preset_name") or "Nasłuch"
        name, ok = W.QInputDialog.getText(self, "Zapisz preset z nasłuchu", "Nazwa:", text=default)
        if not ok or not name.strip():
            return
        PR.put(name.strip(), data)
        self.main.refresh_presets(name.strip())
        self.main.status.setText(f"Zapisano preset „{name.strip()}” z nasłuchu")

    def closeEvent(self, e):
        self._stop()
        super().closeEvent(e)
