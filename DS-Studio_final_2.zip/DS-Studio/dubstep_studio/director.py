"""director.py — REŻYSER: opcjonalny, nadrzędny tryb generowania. Gdy włączony, generate() pyta go o: skalę/progresje (charakter), układ w czasie (scenariusze),
dobór instrumentów, okna parametrów brzmienia, zamiany ról i autolevel. Blokady (pomiń instrument, zablokowany parametr) działają niezależnie od `on`.

CHARAKTER (mood) −1 … +1:  −1 mroczny · −0.5 ponury · 0 wyważony · +0.5 optymistyczny · +1 bardzo optymistyczny. Razem z klasą stylu i energią daje AGRESJĘ A (0..1)
i OPTYMIZM o (0..1), z których wynikają: wagi doboru instrumentów (łagodne ↔ agresywne), środek i szerokość okna każdego parametru brzmienia (nie zawsze min…max),
skala/progresja, energie sekcji, mutacje scenariusza."""
from __future__ import annotations

import copy
import math
import random

from . import core, styles as ST

DEFAULT = dict(
    on=False, mood=0.0, mood_jitter=0.0, mood_scale=True, variety=0.6, pick_instruments=True, instruments_locked=False,
    roles=True, role_amount=0.5, windows=True, autolevel=True, scenario=True, scenario_strength=0.5,
    rules=dict(proporcje=True, sekwencja=True, energia=True),
    skip=[],                      # typy instrumentów pomijane zawsze (blokada „pomiń")
    param_locks={},               # {typ: {parametr: wartość w jednostkach silnika}} — wymuszane przy losowaniu brzmienia
    # Autokorekta krytyczna (profile płynności) — może też iść poza director.on
    critical_correct=dict(on=False, intensity=0.65, profile="auto",
                          change_instruments=True, change_form=True, change_ranges=True,
                          change_params=True, change_automation=True, change_levels=True, passes=2),
)
MOOD_NAMES = [(-0.75, "mroczny"), (-0.25, "ponury"), (0.25, "wyważony"), (0.75, "optymistyczny"), (1.01, "bardzo optymistyczny")]

BASS_T = ("wobble", "reese", "neuro", "fmbass", "hollow", "growl", "bass808", "upright")
LEAD_T = ("screech", "supersaw", "pluck", "stab", "theremin", "panflute", "vox", "handpan", "tongue", "zap",
          "epiano", "harpsichord", "flute", "brass", "hoover", "vibes", "marimba", "bell")
BRIGHT_LEADS = {"supersaw", "pluck", "panflute", "handpan", "tongue", "stab", "bell", "vibes", "harpsichord", "flute", "marimba", "hoover"}
DARK_LEADS = {"screech", "zap", "vox", "theremin", "growl"}
SOFT = {"pad", "handpan", "tongue", "panflute", "theremin", "pluck", "choir", "drone", "cello", "flute", "vibes", "marimba", "bell", "epiano"}
HARSH = {"riser", "boom", "zap", "crash", "neuro", "growl"}
LEAD_RANGE = {"pluck": (60, 84), "supersaw": (55, 80), "screech": (48, 76), "stab": (55, 76), "theremin": (60, 84), "panflute": (64, 88), "vox": (55, 76),
              "handpan": (50, 76), "tongue": (55, 80), "zap": (48, 84),
              "epiano": (52, 80), "harpsichord": (55, 84), "flute": (67, 91), "brass": (55, 79), "hoover": (50, 76), "vibes": (55, 84), "marimba": (48, 79), "bell": (67, 96)}
BASS_RANGE = {"wobble": (28, 55), "reese": (28, 55), "neuro": (30, 58), "fmbass": (30, 58), "hollow": (32, 58), "growl": (30, 60), "bass808": (26, 50), "upright": (30, 55)}
LEADLIKE_BASS = (45, 69)               # zakres, gdy instrument basowy przejmuje linię leadu

AGG_P = {"Drive", "FM Amount", "Resonance", "LFO > Cutoff", "LFO > FM", "LFO > Vowel", "LFO > Pitch", "Pitch Env Amt", "Noise", "Unison Detune", "Filter Env Amt",
         "Ramp > Cutoff", "Formant Mix"}
BRIGHT_P = {"Cutoff", "Noise Highpass", "Noise Lowpass", "Strike Brightness", "Wave Morph"}
TIME_P = {"Decay", "Release", "Noise Decay", "Ring Time", "Pitch Env Decay"}


def normalize(d):
    out = copy.deepcopy(DEFAULT)
    for k, v in (d or {}).items():
        if k == "rules":
            out["rules"].update(v)
        elif k == "critical_correct" and isinstance(v, dict):
            out["critical_correct"].update(v)
        else:
            out[k] = copy.deepcopy(v)
    out["mood"] = max(-1.0, min(1.0, float(out["mood"])))
    return out


def mood_name(m):
    return next(n for lim, n in MOOD_NAMES if m < lim)


def aggression(style, energy, mood):
    """-> (A agresja 0..1, o optymizm 0..1): A = 0.55·klasa stylu/5 + 0.25·energia + 0.20·(1−o)."""
    from . import generator as G
    sa = sum(ST.STYLE_CLASS.get(n, 2.5) * w for n, w in G.STYLES.parts(style).items()) / 5.0
    o = (mood + 1) / 2
    return max(0.0, min(1.0, 0.55 * sa + 0.25 * energy + 0.20 * (1 - o))), o


# ------------------------------------------------------------------ okna parametrów brzmienia
def window(name, sp, A, o, rng, width=0.38):
    """Wartość parametru z okna wokół środka wynikającego z agresji/optymizmu (zamiast całego zakresu min…max)."""
    lo, hi = sp[2], sp[3]
    if name in AGG_P:
        c = 0.15 + 0.70 * A
    elif name in BRIGHT_P:
        c = 0.25 + 0.45 * o + 0.25 * A
    elif name in TIME_P:
        c = 0.55 - 0.30 * (A - 0.5) + 0.25 * (o - 0.5)
    elif name == "Attack":
        c = 0.5 - 0.35 * (A - 0.5)
    else:
        return rng.uniform(lo, hi)
    c = max(0.0, min(1.0, c + rng.uniform(-0.08, 0.08))); a = max(0.0, c - width / 2); b = min(1.0, c + width / 2)
    return lo + (hi - lo) * rng.uniform(a, b)


# ------------------------------------------------------------------ dobór instrumentów
def pick_instruments(style, A, o, variety, rng, avail, skip=()):
    """Zróżnicowany zestaw: rdzeń stylu + (czasem zamieniony bas/lead) + ważone losowanie dodatków wg agresji i optymizmu + domieszka spoza stylu."""
    from . import generator as G
    cfg = G.STYLES[style]; avail = [t for t in avail if t not in skip]
    chosen = [t for t in cfg.get("core", core.CORE8) if t in avail]
    extras = [t for t in cfg.get("extras", []) if t in avail and t not in chosen]
    bc = [t for t in chosen if t in BASS_T]                          # 1) alternatywny instrument basowy zamiast jednego z rdzenia
    if bc and rng.random() < 0.6 * variety:
        alts = [t for t in BASS_T if t not in chosen and t in avail]
        if alts:
            w = [1 + 2 * A if t in ("neuro", "growl") else 1 + (1 - A) for t in alts]
            chosen[chosen.index(rng.choice(bc))] = rng.choices(alts, w)[0]
    lc = [t for t in chosen if t in LEAD_T]                          # 2) lead wg nastroju
    if lc and rng.random() < 0.55 * variety:
        alts = [t for t in LEAD_T if t not in chosen and t in avail]
        if alts:
            w = [(0.4 + 1.4 * o) if t in BRIGHT_LEADS else (0.4 + 1.4 * (1 - o)) if t in DARK_LEADS else 0.7 for t in alts]
            chosen[chosen.index(rng.choice(lc))] = rng.choices(alts, w)[0]
    n = int(round(len(extras) * (0.30 + 0.45 * variety + 0.25 * A) + rng.uniform(-1, 1)))      # 3) dodatki
    pool = list(extras); w = []
    for t in pool:
        x = 1.0
        if t in BRIGHT_LEADS:
            x *= 0.4 + 1.2 * o
        if t in DARK_LEADS:
            x *= 0.4 + 1.2 * (1 - o)
        if t in SOFT:
            x *= 1.4 - 0.9 * A
        if t in HARSH:
            x *= 0.5 + A
        w.append(x)
    for _ in range(max(0, min(n, len(pool)))):
        i = rng.choices(range(len(pool)), w)[0]; chosen.append(pool.pop(i)); w.pop(i)
    if "snare" in chosen and "clap" in avail and "clap" not in chosen and rng.random() < 0.35 * variety:   # 4) perkusja: dodatkowe warstwy
        chosen.append("clap")
    for t in ("rim", "shaker", "tom"):
        if t in avail and t not in chosen and "kick" in chosen and rng.random() < 0.2 * variety:
            chosen.append(t)
    outside = [t for t in avail if t not in chosen and t not in ("speak",)]          # 5) domieszka spoza stylu
    if outside and rng.random() < 0.25 * variety:
        chosen.append(rng.choice(outside))
    # bez duplikatów, zachowaj kolejność
    seen, out = set(), []
    for t in chosen:
        if t not in seen:
            seen.add(t); out.append(t)
    return out


# ------------------------------------------------------------------ charakter -> skala / progresja
_BRIGHT_PROGS = [[0, 3, 4, 0], [0, 5, 3, 4], [5, 3, 0, 4], [0, 4, 5, 3], [0, 2, 3, 4]]
_BRIGHT_MINOR = [[0, 2, 5, 6], [0, 5, 2, 6], [0, 3, 6, 5]]
_DARK_PROGS = [[0, 1, 0, 6], [0, 5, 0, 6], [0, 0, 1, 0]]
_MAJORISH = ("major", "lydian", "mixolydian")


def mood_scale(cfg, mood, rng, current):
    cand = (["phrygian", "harmonic minor", "minor"] if mood < -0.3 else ["major", "lydian"] if mood > 0.7 else ["major", "lydian", "mixolydian", "dorian"] if mood > 0.3
            else ["minor", "dorian", "harmonic minor"])
    pref = [s for s in cfg.get("scales", []) if s in cand]
    return rng.choice(pref or cand) if (pref or abs(mood) > 0.3) else current


def mood_progs(scale, mood, base, rng):
    if rng.random() > min(1.0, abs(mood) * 1.4):
        return rng.choice(base)
    if mood > 0:
        return rng.choice(_BRIGHT_PROGS if scale in _MAJORISH else _BRIGHT_MINOR)
    return rng.choice(_DARK_PROGS)


# ------------------------------------------------------------------ zamiany ról
def _fold(k, lo, hi):
    while k < lo:
        k += 12
    while k > hi:
        k -= 12
    return k


def _take(tr, b0, b1):
    a, b = b0 * 4.0, b1 * 4.0
    inn = [n for n in tr["notes"] if a <= n[0] < b]
    tr["notes"] = [n for n in tr["notes"] if not (a <= n[0] < b)]
    return inn


def _put(tr, notes, lo, hi):
    tr["notes"] += [[n[0], n[1], _fold(int(n[2]), lo, hi), n[3]] for n in notes]
    tr["notes"].sort(key=lambda n: (n[0], n[2]))


def _count(tr, b0, b1):
    return sum(1 for n in tr["notes"] if b0 * 4.0 <= n[0] < b1 * 4.0)


def _retune(proj, tr, b0, b1, semis):
    """Barwa dopasowana do nowej roli/rejestru: w oknie Cutoff podąża za zmianą rejestru (log), poza oknem wraca do ustawienia ścieżki."""
    m = core.meta(); tt = tr["type"]
    if tr.get("lock_sound") or "Cutoff" in (tr.get("locked_params") or ()):
        return
    if not m.has(tt, "Cutoff") or "Cutoff" not in tr["params"]:
        return
    base = tr["params"]["Cutoff"]; eng = m.frac2eng(tt, "Cutoff", base)
    new = m.eng2frac(tt, "Cutoff", eng * 2 ** (semis / 12.0 * 0.9))
    pts = [p for p in tr["auto"].get("Cutoff", []) if not (b0 * 4 <= p[0] <= b1 * 4)]
    tr["auto"]["Cutoff"] = sorted(pts + [[b0 * 4.0, new], [b1 * 4.0, base]])


def apply_roles(proj, d, rng, A, o):
    """Zamienia role instrumentów NA OKRESY (nie na stałe): 1–8 okien po 2–8 taktów w dropach/breakach/buildach. -> lista opisów zdarzeń."""
    ev = []
    free = [t for t in proj["tracks"] if not t.get("lock_notes")]      # zablokowane nuty = ścieżka poza zamianami
    bass = [t for t in free if t["type"] in BASS_T and t["notes"]]
    lead = [t for t in free if t["type"] in LEAD_T and t["notes"]]
    perc = {(a, b): (next((t for t in free if t["type"] == a), None), next((t for t in free if t["type"] == b), None))
            for a, b in (("snare", "clap"), ("hat", "shaker"), ("snare", "rim"))}
    perc = {k: v for k, v in perc.items() if v[0] and v[1]}
    if not (bass and lead) and len(lead) < 2 and len(bass) < 2 and not perc:
        return ev
    amount = float(d.get("role_amount", 0.5)); n = int(round((1 + amount * 4) * math.sqrt(max(0.5, proj["bars"] / 96)))) if amount > 0 else 0
    cands = []                                                    # kandydackie okna: parzyste takty, nie pierwsze 4 takty dropu
    for s in proj["sections"]:
        wgt = {"drop": 0.6, "break": 0.25 + 0.2 * o, "build": 0.15}.get(s["type"], 0)
        if not wgt:
            continue
        lo = s["start"] + (4 if s["type"] == "drop" else 0)
        for b in range(lo - lo % 2, s["start"] + s["bars"] - 1, 2):
            if b >= s["start"]:
                cands.append((b, wgt, s))
    used = []
    for _ in range(n * 3):
        if len(used) >= n or not cands:
            break
        b0, _, s = rng.choices(cands, [c[1] for c in cands])[0]
        ln = rng.choice([2, 4, 4, 8]); b1 = min(b0 + ln, s["start"] + s["bars"])
        if b1 - b0 < 2 or any(not (b1 <= u0 or b0 >= u1) for u0, u1 in used):
            continue
        kinds = []
        if bass and lead:
            kinds += [("swap", 3), ("take", 2 * (1 - o) + 0.5), ("double", 1.5 + o), ("lead_bass", 1 + o)]
        if len(lead) >= 2:
            kinds.append(("lead_lead", 1.5))
        if len(bass) >= 2:
            kinds.append(("bass_bass", 1.2))
        if perc:
            kinds.append(("perc", 1.5))
        k = rng.choices([x for x, _ in kinds], [w for _, w in kinds])[0]
        if k in ("swap", "take", "double", "lead_bass"):
            B, L = rng.choice([t for t in bass if _count(t, b0, b1)] or bass), rng.choice([t for t in lead if _count(t, b0, b1)] or lead)
            if not _count(B, b0, b1) or not _count(L, b0, b1):
                continue
            ln_, bn_ = _take(L, b0, b1), _take(B, b0, b1)
            lo, hi = LEADLIKE_BASS if o < 0.6 else (LEADLIKE_BASS[0] + 7, LEADLIKE_BASS[1] + 7)
            if k == "swap":
                _put(B, ln_, lo, hi); _put(L, bn_, *LEAD_RANGE[L["type"]]); txt = f"{B['type']} ↔ {L['type']} wymieniają się rolami"
                _retune(proj, B, b0, b1, (lo + hi) / 2 - sum(BASS_RANGE[B["type"]]) / 2); _retune(proj, L, b0, b1, -12)
            elif k == "take":
                _put(B, ln_, lo, hi); txt = f"{B['type']} przejmuje linię leadu ({L['type']} milknie)"
                _retune(proj, B, b0, b1, (lo + hi) / 2 - sum(BASS_RANGE[B["type"]]) / 2)
            elif k == "double":
                _put(L, ln_, *LEAD_RANGE[L["type"]]); _put(B, ln_, lo, hi); txt = f"{B['type']} dubluje linię leadu ({L['type']})"
                _retune(proj, B, b0, b1, (lo + hi) / 2 - sum(BASS_RANGE[B["type"]]) / 2)
            else:
                _put(L, bn_, *LEAD_RANGE[L["type"]]); txt = f"{L['type']} gra linię basu ({B['type']} milknie)"
                _retune(proj, L, b0, b1, -10)
        elif k == "lead_lead":
            a, b = rng.sample(lead, 2)
            if not (_count(a, b0, b1) and _count(b, b0, b1)):
                continue
            na, nb = _take(a, b0, b1), _take(b, b0, b1); _put(a, nb, *LEAD_RANGE[a["type"]]); _put(b, na, *LEAD_RANGE[b["type"]]); txt = f"{a['type']} ↔ {b['type']} zamieniają partie"
        elif k == "bass_bass":
            a, b = rng.sample(bass, 2)
            if not (_count(a, b0, b1) and _count(b, b0, b1)):
                continue
            na, nb = _take(a, b0, b1), _take(b, b0, b1); _put(a, nb, *BASS_RANGE[a["type"]]); _put(b, na, *BASS_RANGE[b["type"]]); txt = f"{a['type']} ↔ {b['type']} zamieniają partie basowe"
        else:
            (x, y) = rng.choice(list(perc.values()))
            if not (_count(x, b0, b1) or _count(y, b0, b1)):
                continue
            nx, ny = _take(x, b0, b1), _take(y, b0, b1); x["notes"] += ny; y["notes"] += nx; x["notes"].sort(); y["notes"].sort(); txt = f"perkusja: {x['type']} ↔ {y['type']}"
        used.append((b0, b1)); ev.append(f"takty {b0 + 1}–{b1}: {txt}")
    return ev

# --- instrumenty użytkownika (karta „Modelowanie CLAP”): dopisanie zatwierdzonych typów do tabel tego modułu
from . import userinst as _userinst  # noqa: E402
_userinst.apply_module("director")
