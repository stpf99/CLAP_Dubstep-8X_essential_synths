"""Karta „Modelowanie CLAP” — projektowanie nowych instrumentów (wtyczek CLAP) bez opuszczania GUI.

Szkic → odsłuch (tymczasowa kompilacja) → „Zatwierdź do biblioteki”: zapis specyfikacji, dopisanie do Makefile (user_types.mk),
kompilacja make tylko nowej wtyczki i natychmiastowa rejestracja typu w aplikacji (listy instrumentów, generator, style, epoki).
"""
from __future__ import annotations

import re
import traceback

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import core, generator as G, styles as ST, userinst as U


class _Job(QtCore.QThread):
    line = QtCore.pyqtSignal(str)
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(str)

    def __init__(self, fn):
        super().__init__(); self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(self.line.emit))
        except Exception:
            self.fail.emit(traceback.format_exc())


def _spin(lo, hi, val, decimals=None, step=None):
    sp = W.QDoubleSpinBox()
    sp.setRange(lo, hi)
    span = hi - lo
    sp.setDecimals(decimals if decimals is not None else (3 if span <= 2 else 2 if span <= 200 else 1))
    sp.setSingleStep(step if step is not None else max(span / 200.0, 10 ** -sp.decimals()))
    sp.setValue(min(hi, max(lo, val)))
    sp.setKeyboardTracking(False)
    return sp


class ModelTab(W.QWidget):
    MODES = ["—", "jawny", "ukryty"]          # nieużywany (domyślna wartość silnika) / jawny parametr wtyczki / stała wartość

    def __init__(self, mw):
        super().__init__()
        self.mw = mw
        self.job = None
        self.rows = {}               # indeks parametru -> dict(widgets)
        self._loading = False
        self.cur_status = "draft"
        outer = W.QVBoxLayout(self)
        outer.addWidget(W.QLabel("Modelowanie nowych instrumentów CLAP: ustaw parametry silnika, sklasyfikuj dla generatora, odsłuchaj, a po „Zatwierdź do biblioteki” "
                                 "wtyczka zostanie dopisana do Makefile, skompilowana i od razu dostępna w aplikacji."))
        split = W.QSplitter(Qt.Orientation.Horizontal)
        outer.addWidget(split, 1)
        split.addWidget(self._build_list())
        split.addWidget(self._build_center())
        split.addWidget(self._build_right())
        split.setSizes([210, 640, 330])
        # --- dół: akcje + log
        bar = W.QHBoxLayout()
        self.b_prev = W.QPushButton("▶ Odsłuch (kompiluj podgląd)"); self.b_prev.clicked.connect(self.do_preview)
        self.b_save = W.QPushButton("Zapisz szkic"); self.b_save.clicked.connect(self.do_save)
        self.b_ok = W.QPushButton("✔ Zatwierdź do biblioteki (kompiluj)"); self.b_ok.clicked.connect(self.do_approve)
        self.b_ok.setStyleSheet("font-weight:bold")
        self.b_stop = W.QPushButton("■ Stop"); self.b_stop.clicked.connect(lambda: self.mw.player.stop())
        for b in (self.b_prev, self.b_stop, self.b_save, self.b_ok):
            bar.addWidget(b)
        self.busy = W.QProgressBar(); self.busy.setRange(0, 1); self.busy.setMaximumWidth(160); self.busy.setTextVisible(False)
        bar.addWidget(self.busy); bar.addStretch(1)
        outer.addLayout(bar)
        self.log = W.QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumBlockCount(2000); self.log.setMaximumHeight(130)
        self.log.setPlaceholderText("Log kompilacji…")
        outer.addWidget(self.log)
        self.refresh_list()
        self.new_draft()

    # ------------------------------------------------------------------ budowa UI
    def _build_list(self):
        w = W.QWidget(); v = W.QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(W.QLabel("Biblioteka użytkownika"))
        self.lst = W.QListWidget(); self.lst.itemSelectionChanged.connect(self._on_pick)
        v.addWidget(self.lst, 1)
        for txt, fn, tip in (("Nowy", self.new_draft, "Pusty szkic (domyślnie z szablonu pluck)"),
                             ("Wyłącz / włącz", self.toggle_disabled, "Ukrywa instrument w aplikacji; definicja C++ zostaje (stałe indeksy typów)"),
                             ("Skanuj ponownie", self.rescan, "Rozpoznaje nowe specyfikacje z user_instruments/ i odświeża wtyczki")):
            b = W.QPushButton(txt); b.setToolTip(tip); b.clicked.connect(fn); v.addWidget(b)
        return w

    def _build_center(self):
        w = W.QWidget(); v = W.QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0)
        f = W.QFormLayout()
        self.e_name = W.QLineEdit(); self.e_name.setPlaceholderText("np. Glass Pluck")
        self.e_name.editingFinished.connect(self._auto_id)
        self.e_id = W.QLineEdit(); self.e_id.setPlaceholderText("np. glasspl  (2–16 znaków a–z0–9, nazwa pliku: DS-<Id>.clap)")
        self.e_id.setValidator(QtGui.QRegularExpressionValidator(QtCore.QRegularExpression(r"[a-z][a-z0-9]{0,15}")))
        self.e_desc = W.QLineEdit()
        f.addRow("Nazwa", self.e_name); f.addRow("Identyfikator", self.e_id); f.addRow("Opis", self.e_desc)
        tr = W.QHBoxLayout()
        self.c_tpl = W.QComboBox(); self.c_tpl.addItems(sorted(core.TYPES))
        b = W.QPushButton("Wczytaj parametry z szablonu"); b.clicked.connect(self.load_template)
        tr.addWidget(self.c_tpl, 1); tr.addWidget(b)
        f.addRow("Szablon", tr)
        fl = W.QHBoxLayout()
        self.k_one = W.QCheckBox("one-shot (perkusyjny, bez sustain)"); self.k_ret = W.QCheckBox("retrigger"); self.k_ret.setToolTip("Każda nuta restartuje głos (typowe dla pluck/perkusji)")
        self.sp_ref = _spin(20, 4000, 261.6256, 3, 1.0); self.sp_ref.setSuffix(" Hz")
        self.sp_ref.setToolTip("Częstotliwość odniesienia (nuta 60); dla perkusji bez key-trackingu — wysokość bazowa")
        fl.addWidget(self.k_one); fl.addWidget(self.k_ret); fl.addWidget(W.QLabel("ref:")); fl.addWidget(self.sp_ref); fl.addStretch(1)
        f.addRow("Flagi", fl)
        self.c_modal = W.QComboBox(); self.c_modal.addItems(U.MODAL_BUILTIN + ["Własny…"])
        self.c_modal.setToolTip("Tryb modalny: bank częściowych (sztabki/dzwony). Wymaga parametrów Ring Time / Strike Brightness.")
        self.c_modal.currentIndexChanged.connect(self._modal_changed)
        f.addRow("Bank modalny", self.c_modal)
        v.addLayout(f)
        self.t_modal = W.QTableWidget(6, 3); self.t_modal.setHorizontalHeaderLabels(["stosunek f", "amplituda", "zanik ×"])
        self.t_modal.setMaximumHeight(170)
        for r in range(6):
            for c, (lo, hi, d) in enumerate(((0.0, 30.0, 1.0), (0.0, 2.0, 1.0 if r == 0 else 0.0), (0.05, 4.0, 1.0))):
                sp = _spin(lo, hi, d, 3, 0.01); self.t_modal.setCellWidget(r, c, sp)
        self.t_modal.setVisible(False)
        v.addWidget(self.t_modal)
        # tabela parametrów
        fr = W.QHBoxLayout()
        self.e_filter = W.QLineEdit(); self.e_filter.setPlaceholderText("Filtruj parametry…"); self.e_filter.textChanged.connect(self._filter)
        self.k_used = W.QCheckBox("tylko używane"); self.k_used.toggled.connect(self._filter)
        fr.addWidget(self.e_filter, 1); fr.addWidget(self.k_used)
        v.addLayout(fr)
        P = U.params()
        self.tbl = W.QTableWidget(len(P), 5)
        self.tbl.setHorizontalHeaderLabels(["Parametr", "Tryb", "Wartość", "losuj od", "losuj do"])
        self.tbl.verticalHeader().setVisible(False)
        hh = self.tbl.horizontalHeader(); hh.setSectionResizeMode(0, W.QHeaderView.ResizeMode.Stretch)
        for c in (1, 2, 3, 4):
            hh.setSectionResizeMode(c, W.QHeaderView.ResizeMode.ResizeToContents)
        for r, p in enumerate(P):
            unit = f" [{p['unit']}]" if p["unit"] else ""
            it = W.QTableWidgetItem(f"{p['group']} · {p['name']}{unit}"); it.setFlags(Qt.ItemFlag.ItemIsEnabled)
            self.tbl.setItem(r, 0, it)
            mode = W.QComboBox(); mode.addItems(self.MODES)
            mode.setToolTip("— = wartość domyślna silnika · jawny = parametr wtyczki (host + losowanie generatora) · ukryty = stała wartość")
            if p["kind"] == "int" and p["names"]:
                val = W.QComboBox(); val.addItems(p["names"]); val.setCurrentIndex(max(0, int(round(p["def"] - p["lo"]))))
            else:
                val = _spin(p["lo"], p["hi"], p["def"], 0 if p["kind"] == "int" else None, 1.0 if p["kind"] == "int" else None)
            lo_w = _spin(p["lo"], p["hi"], p["lo"]) if p["kind"] != "int" else None
            hi_w = _spin(p["lo"], p["hi"], p["hi"]) if p["kind"] != "int" else None
            self.tbl.setCellWidget(r, 1, mode); self.tbl.setCellWidget(r, 2, val)
            if lo_w:
                self.tbl.setCellWidget(r, 3, lo_w); self.tbl.setCellWidget(r, 4, hi_w)
            mode.currentIndexChanged.connect(lambda _i, rr=r: self._mode_changed(rr))
            self.rows[p["i"]] = dict(row=r, p=p, mode=mode, val=val, lo=lo_w, hi=hi_w)
            self._mode_changed(r)
        v.addWidget(self.tbl, 1)
        return w

    def _build_right(self):
        w = W.QWidget(); v = W.QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0)
        g = W.QGroupBox("Klasyfikacja dla generatora"); f = W.QFormLayout(g)
        self.c_group = W.QComboBox(); self.c_group.addItems(U.GROUPS)
        self.c_gen = W.QComboBox(); self.c_gen.addItems(sorted(G.GEN))
        self.c_gen.setToolTip("Wzór nut, który zagra ten instrument (np. stab, pad, pluck, piano, sub, hat…)")
        self.c_role = W.QComboBox(); self.c_role.addItems(["(brak)", "bass", "lead", "pad"])
        self.k_mel = W.QCheckBox("melodyczny (strojony do tonacji)"); self.k_sus = W.QCheckBox("długie nuty (bez swingu)")
        self.sp_duck = _spin(0, 1, 0.3, 2, 0.05); self.sp_gain = _spin(0, 1.5, 0.6, 2, 0.05); self.sp_rel = _spin(0, 1, 0.5, 2, 0.05)
        self.sp_agg = _spin(0, 5, 2.0, 1, 0.5)
        self.sp_duck.setToolTip("Głębokość ducking-u (sidechain) pod kick/sub"); self.sp_rel.setToolTip("Docelowa głośność względem reszty (autolevels)")
        self.sp_agg.setToolTip("Agresja barwy 0–5 (wpływa na dobór instrumentów reżysera/nastroju)")
        self.sp_b = [_spin(0, 1, d, 2, 0.05) for d in (0.05, 0.2, 0.45, 0.3)]
        br = W.QHBoxLayout()
        for lab, sp in zip(("sub", "low", "mid", "high"), self.sp_b):
            br.addWidget(W.QLabel(lab)); br.addWidget(sp)
        for lab, wd in (("Grupa", self.c_group), ("Wzór nut", self.c_gen), ("Rola", self.c_role), ("", self.k_mel), ("", self.k_sus),
                        ("Ducking", self.sp_duck), ("Gain startowy", self.sp_gain), ("Cel autolevel", self.sp_rel), ("Agresja", self.sp_agg), ("Pasma", br)):
            f.addRow(lab, wd)
        v.addWidget(g)
        gs = W.QGroupBox("Dodaj do extras stylów (hybrydy dziedziczą)"); vs = W.QVBoxLayout(gs)
        self.l_styles = W.QListWidget(); self.l_styles.setMinimumHeight(150)
        names = [s for s in ST.ORDER if s in G.STYLES] + [s for s in G.STYLES if s not in ST.ORDER]
        for n in names:
            it = W.QListWidgetItem(n); it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable); it.setCheckState(Qt.CheckState.Unchecked)
            self.l_styles.addItem(it)
        self.k_front = W.QCheckBox("na początku listy extras (mniejsza szansa odcięcia przez limit ścieżek epoki)")
        vs.addWidget(self.l_styles); vs.addWidget(self.k_front)
        v.addWidget(gs, 1)
        ge = W.QGroupBox("Epoki (lista „prefer”)"); ve = W.QVBoxLayout(ge)
        self.l_eras = W.QListWidget(); self.l_eras.setMaximumHeight(100)
        for e in U.ERAS:
            it = W.QListWidgetItem(e); it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable); it.setCheckState(Qt.CheckState.Unchecked)
            self.l_eras.addItem(it)
        ve.addWidget(self.l_eras)
        v.addWidget(ge)
        return w

    # ------------------------------------------------------------------ stan formularza <-> specyfikacja
    def _mode_changed(self, r):
        p = next(x for x in self.rows.values() if x["row"] == r)
        m = p["mode"].currentIndex()
        p["val"].setEnabled(m != 0)
        for k in ("lo", "hi"):
            if p[k]:
                p[k].setEnabled(m == 1)
        if self.k_used.isChecked() and not self._loading:
            self._filter()

    def _filter(self, *_):
        t = self.e_filter.text().strip().lower(); only = self.k_used.isChecked()
        for p in self.rows.values():
            txt = self.tbl.item(p["row"], 0).text().lower()
            self.tbl.setRowHidden(p["row"], bool((t and t not in txt) or (only and p["mode"].currentIndex() == 0)))

    def _modal_changed(self, i):
        self.t_modal.setVisible(i == len(U.MODAL_BUILTIN))

    def _auto_id(self):
        if not self.e_id.text().strip() and self.e_name.text().strip():
            slug = re.sub(r"[^a-z0-9]", "", self.e_name.text().lower())[:16]
            if slug and not slug[0].isalpha():
                slug = "i" + slug
            self.e_id.setText(slug[:16])

    @staticmethod
    def _val(wd, p):
        if isinstance(wd, W.QComboBox):
            return float(p["lo"] + wd.currentIndex())
        return float(wd.value())

    def collect(self):
        s = U.new_spec()
        s.update(id=self.e_id.text().strip(), name=self.e_name.text().strip(), desc=self.e_desc.text().strip(),
                 oneshot=self.k_one.isChecked(), retrig=self.k_ret.isChecked(), ref=self.sp_ref.value())
        mi = self.c_modal.currentIndex()
        if mi == len(U.MODAL_BUILTIN):
            mc = []
            for r in range(6):
                ratio, amp, dec = (self.t_modal.cellWidget(r, c).value() for c in range(3))
                if ratio > 0 and amp > 0:
                    mc.append({"ratio": ratio, "amp": amp, "decay": dec})
            s["modal"], s["modal_custom"] = 0, mc or None
        else:
            s["modal"], s["modal_custom"] = mi, None
        ex, hid, sound = [], [], []
        for i, p in sorted(self.rows.items(), key=lambda kv: kv[1]["row"]):
            m = p["mode"].currentIndex()
            if m == 0:
                continue
            v = self._val(p["val"], p["p"])
            (ex if m == 1 else hid).append([i, v])
            if m == 1 and p["lo"] and p["hi"].value() > p["lo"].value() + 1e-9:
                sound.append([p["p"]["name"], "r", round(p["lo"].value(), 4), round(p["hi"].value(), 4)])
        s["ex"], s["hid"], s["sound"] = ex, hid, sound
        s.update(group=self.c_group.currentText(), gen=self.c_gen.currentText(), role="" if self.c_role.currentIndex() == 0 else self.c_role.currentText(),
                 melodic=self.k_mel.isChecked(), sustained=self.k_sus.isChecked(), duck=self.sp_duck.value(), gain=self.sp_gain.value(),
                 target_rel=self.sp_rel.value(), agg=self.sp_agg.value(), bands=[sp.value() for sp in self.sp_b],
                 styles=[self.l_styles.item(k).text() for k in range(self.l_styles.count()) if self.l_styles.item(k).checkState() == Qt.CheckState.Checked],
                 style_front=self.k_front.isChecked(),
                 eras=[self.l_eras.item(k).text() for k in range(self.l_eras.count()) if self.l_eras.item(k).checkState() == Qt.CheckState.Checked])
        old = U.get_spec(s["id"]) if s["id"] else None
        if old:
            s["seq"], s["status"], s["disabled"] = old.get("seq", 0), old.get("status", "draft"), old.get("disabled", False)
        return s

    def load(self, s):
        self._loading = True
        try:
            self.e_name.setText(s.get("name", "")); self.e_id.setText(s.get("id", "")); self.e_desc.setText(s.get("desc", ""))
            self.e_id.setReadOnly(s.get("status") == "approved")      # id zatwierdzonego instrumentu jest stały (nazwa pliku, indeks typu)
            self.k_one.setChecked(bool(s.get("oneshot"))); self.k_ret.setChecked(bool(s.get("retrig"))); self.sp_ref.setValue(float(s.get("ref", 261.6256)))
            mc = s.get("modal_custom")
            self.c_modal.setCurrentIndex(len(U.MODAL_BUILTIN) if mc else int(s.get("modal", 0)))
            for r in range(6):
                x = mc[r] if mc and r < len(mc) else {"ratio": 1.0 if r == 0 else 0.0, "amp": 1.0 if r == 0 else 0.0, "decay": 1.0}
                for c, k in enumerate(("ratio", "amp", "decay")):
                    self.t_modal.cellWidget(r, c).setValue(float(x[k]))
            ex = {int(i): float(v) for i, v in s.get("ex", [])}; hid = {int(i): float(v) for i, v in s.get("hid", [])}
            rng = {n: (lo, hi) for n, _k, lo, hi in s.get("sound", [])}
            for i, p in self.rows.items():
                pi = p["p"]
                m = 1 if i in ex else 2 if i in hid else 0
                v = ex.get(i, hid.get(i, pi["def"]))
                p["mode"].setCurrentIndex(m)
                if isinstance(p["val"], W.QComboBox):
                    p["val"].setCurrentIndex(max(0, min(p["val"].count() - 1, int(round(v - pi["lo"])))))
                else:
                    p["val"].setValue(v)
                if p["lo"]:
                    lo, hi = rng.get(pi["name"], (pi["lo"], pi["hi"]))
                    p["lo"].setValue(lo); p["hi"].setValue(hi)
                self._mode_changed(p["row"])
            self.c_group.setCurrentText(s.get("group", "Synth / lead")); self.c_gen.setCurrentText(s.get("gen", "stab"))
            self.c_role.setCurrentIndex(max(0, U.ROLES.index(s.get("role", ""))) if s.get("role", "") in U.ROLES else 0)
            self.k_mel.setChecked(bool(s.get("melodic", True))); self.k_sus.setChecked(bool(s.get("sustained")))
            self.sp_duck.setValue(float(s.get("duck", 0.3))); self.sp_gain.setValue(float(s.get("gain", 0.6)))
            self.sp_rel.setValue(float(s.get("target_rel", 0.5))); self.sp_agg.setValue(float(s.get("agg", 2.0)))
            for sp, v in zip(self.sp_b, s.get("bands", [0.05, 0.2, 0.45, 0.3])):
                sp.setValue(float(v))
            for k in range(self.l_styles.count()):
                it = self.l_styles.item(k); it.setCheckState(Qt.CheckState.Checked if it.text() in s.get("styles", []) else Qt.CheckState.Unchecked)
            for k in range(self.l_eras.count()):
                it = self.l_eras.item(k); it.setCheckState(Qt.CheckState.Checked if it.text() in s.get("eras", []) else Qt.CheckState.Unchecked)
            self.k_front.setChecked(bool(s.get("style_front")))
            self.cur_status = s.get("status", "draft")
        finally:
            self._loading = False
        self._filter()
        approved = self.cur_status == "approved"
        self.b_save.setEnabled(not approved)
        self.b_save.setToolTip("Zatwierdzony instrument zmieniasz przez „Zatwierdź do biblioteki” (przebudowa wtyczki)." if approved else "")
        self.b_ok.setText("✔ Zatwierdź zmiany (przebuduj wtyczkę)" if approved else "✔ Zatwierdź do biblioteki (kompiluj)")

    # ------------------------------------------------------------------ lista / akcje
    def new_draft(self):
        s = U.new_spec("pluck")
        self.load(s)
        self.lst.clearSelection()

    def refresh_list(self):
        self.lst.blockSignals(True)
        self.lst.clear()
        for s in U.list_specs():
            tag = ("wyłączony" if s.get("disabled") else "✔ zbudowany" if s.get("status") == "approved" and U.is_built(s["id"])
                   else "zatwierdzony (brak .clap)" if s.get("status") == "approved" else "szkic")
            it = W.QListWidgetItem(f"{s['name'] or s['id']}  [{s['id']}] — {tag}"); it.setData(Qt.ItemDataRole.UserRole, s["id"])
            self.lst.addItem(it)
        self.lst.blockSignals(False)

    def _on_pick(self):
        its = self.lst.selectedItems()
        if its:
            s = U.get_spec(its[0].data(Qt.ItemDataRole.UserRole))
            if s:
                self.load(s)

    def toggle_disabled(self):
        its = self.lst.selectedItems()
        if not its:
            return
        iid = its[0].data(Qt.ItemDataRole.UserRole)
        s = U.get_spec(iid)
        U.set_disabled(iid, not s.get("disabled"))
        self._say("Zmiana wyłączenia zadziała po ponownym uruchomieniu aplikacji (typ jest już zarejestrowany w tej sesji)." if not s.get("disabled")
                  else "Instrument włączony — zostanie zarejestrowany po „Skanuj ponownie”.")
        self.refresh_list()

    def rescan(self):
        try:
            new = U.rescan()
        except Exception as e:
            self._say(f"Błąd skanowania: {e}"); return
        self._say("Rozpoznano nowe instrumenty: " + ", ".join(new) if new else "Brak nowych specyfikacji do zarejestrowania.")
        self.refresh_list()
        self.mw.refresh_instrument_lists()

    def load_template(self):
        s = self.collect()
        U.apply_template(s, self.c_tpl.currentText())
        for k in ("id", "name", "desc"):
            pass
        keep = {k: s[k] for k in ("id", "name", "desc", "group", "gen", "role", "melodic", "sustained", "duck", "gain", "target_rel", "agg", "bands", "styles", "style_front", "eras")}
        s.update(keep); s["status"] = self.cur_status
        self.load(s)
        self._say(f"Wczytano parametry z szablonu „{self.c_tpl.currentText()}”.")

    def _say(self, m):
        self.log.appendPlainText(m)

    def _busy(self, on):
        self.busy.setRange(0, 0 if on else 1)
        for b in (self.b_prev, self.b_save, self.b_ok):
            b.setEnabled(not on)
        if not on:
            self.b_save.setEnabled(self.cur_status != "approved")

    def _start(self, fn, done):
        if self.job and self.job.isRunning():
            return
        self._busy(True)
        self.job = _Job(fn)
        self.job.line.connect(self._say)
        self.job.done.connect(lambda r: (self._busy(False), done(r)))
        self.job.fail.connect(lambda e: (self._busy(False), self._say(e), W.QMessageBox.critical(self, "Błąd", e[-1200:])))
        self.job.start()

    def do_save(self):
        s = self.collect()
        if not U.ID_RE.match(s["id"]):
            W.QMessageBox.warning(self, "Modelowanie", "Podaj poprawny identyfikator (2–16 znaków, a–z0–9)."); return
        if s.get("status") == "approved":
            return
        s["status"] = "draft"
        U.save_spec(s)
        self._say(f"Zapisano szkic: {s['id']}")
        self.refresh_list()

    def do_preview(self):
        s = self.collect()
        errs = U.validate(s)
        if errs:
            W.QMessageBox.warning(self, "Modelowanie", "\n".join(errs)); return
        if self.mw.live.eng.running:
            self.mw.live.stop()
        self._start(lambda log: U.preview(s, log), lambda wav: (self.mw._play_path(wav), self._say("Odtwarzanie podglądu…")))

    def do_approve(self):
        s = self.collect()
        errs = U.validate(s)
        if errs:
            W.QMessageBox.warning(self, "Modelowanie", "\n".join(errs)); return
        if W.QMessageBox.question(self, "Zatwierdź do biblioteki",
                                  f"Dopisać „{s['name']}” ({s['id']}) do biblioteki?\n\nWtyczka DS-{U.plugin_name(s['id'])}.clap zostanie dopisana do Makefile "
                                  "(user_types.mk), skompilowana i zarejestrowana w aplikacji.") != W.QMessageBox.StandardButton.Yes:
            return
        self._start(lambda log: U.approve(s, log), self._approved)

    def _approved(self, res):
        ok, msg = res
        self._say(msg)
        self.refresh_list()
        if ok:
            self.mw.refresh_instrument_lists()
            self.c_tpl.clear(); self.c_tpl.addItems(sorted(core.TYPES))
            s = U.get_spec(self.e_id.text().strip())
            if s:
                self.load(s)
            self.mw.status.setText(msg)
        else:
            W.QMessageBox.warning(self, "Modelowanie", msg)
