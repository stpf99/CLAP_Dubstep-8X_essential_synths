"""critical_correct.py — Autokorekta krytyczna / profile płynności.

Trigger: preset (profil) i/lub suwak intensywności (albo oba).
Zakres: cały utwór — wolno zmienić instrumenty, zakresy nut, parametry,
automatyzacje, formę sekcji i poziomy, z szacunkiem dla lock_notes / lock_sound /
locked_params.

Cel: płynniejsze brzmienia (długie envelope, glide, wolne LFO, automacje wielu
parametrów w czasie), a nie tylko pozycje nut + jeden oscylator.
"""
from __future__ import annotations

import copy
import math
import random
from typing import Any

from . import core
from .core import meta, autolevel_heuristic, first_of_type

# ---------------------------------------------------------------------------
# Profile płynności (sztywne zakresy + okna parametrów + automacje)
# Wartości param_windows są ułamkami 0..1 zakresu silnika (jak tr["params"]).
# ---------------------------------------------------------------------------

FLUID_PROFILES: dict[str, dict[str, Any]] = {
    "ambient": {
        "label": "Ambient / Space",
        "prefer": [
            "pad", "drone", "sub", "hollow", "vox", "choir", "strings", "cello",
            "flute", "theremin", "handpan", "tongue", "panflute", "epiano", "bell",
        ],
        "avoid": [
            "screech", "growl", "glitch", "zap", "neuro", "riser", "boom", "crash",
            "hoover", "stab",
        ],
        "note_ranges": {
            "pad": (48, 72), "drone": (36, 55), "sub": (28, 43), "hollow": (32, 52),
            "vox": (52, 72), "choir": (48, 70), "strings": (48, 72), "cello": (36, 60),
            "flute": (64, 84), "theremin": (55, 76), "handpan": (50, 70),
            "tongue": (55, 74), "panflute": (60, 80), "epiano": (48, 72),
            "bell": (60, 84), "pluck": (55, 76), "wobble": (30, 48), "reese": (28, 48),
            "fmbass": (30, 50), "bass808": (26, 42), "upright": (30, 50),
        },
        "param_windows": {
            "Attack": (0.45, 0.92),
            "Release": (0.55, 0.95),
            "Decay": (0.45, 0.90),
            "Glide": (0.18, 0.55),
            "Drive": (0.00, 0.22),
            "Resonance": (0.08, 0.38),
            "Cutoff": (0.25, 0.55),
            "LFO Rate": (0.04, 0.22),
            "LFO > Cutoff": (0.15, 0.55),
            "LFO > Pitch": (0.00, 0.18),
            "LFO > FM": (0.00, 0.20),
            "FM Amount": (0.00, 0.25),
            "Unison Detune": (0.15, 0.45),
            "Wave Morph": (0.10, 0.55),
            "Filter Env Amt": (0.05, 0.40),
            "Noise": (0.00, 0.18),
            "Formant Mix": (0.30, 0.85),
        },
        "automation": ["Cutoff", "Wave Morph", "LFO > Cutoff", "Formant Mix", "Glide"],
        "density_cap": 0.42,
        "energy_cap": 0.45,
        "soft_form": True,
    },
    "minimal": {
        "label": "Minimal",
        "prefer": [
            "sub", "pad", "pluck", "hat", "kick", "rim", "shaker", "epiano",
            "marimba", "vibes", "handpan", "bell", "hollow",
        ],
        "avoid": [
            "screech", "growl", "neuro", "glitch", "zap", "riser", "boom", "crash",
            "hoover", "choir", "drone",
        ],
        "note_ranges": {
            "sub": (28, 45), "pad": (52, 70), "pluck": (58, 78), "hollow": (32, 52),
            "epiano": (50, 72), "marimba": (55, 79), "vibes": (55, 80),
            "handpan": (52, 72), "bell": (64, 88), "wobble": (30, 50),
            "reese": (28, 50), "stab": (55, 72),
        },
        "param_windows": {
            "Attack": (0.20, 0.55),
            "Release": (0.25, 0.65),
            "Decay": (0.20, 0.55),
            "Glide": (0.00, 0.25),
            "Drive": (0.00, 0.28),
            "Resonance": (0.10, 0.40),
            "Cutoff": (0.30, 0.62),
            "LFO Rate": (0.08, 0.35),
            "LFO > Cutoff": (0.10, 0.40),
            "FM Amount": (0.00, 0.30),
            "Unison Detune": (0.05, 0.30),
            "Wave Morph": (0.05, 0.40),
            "Filter Env Amt": (0.10, 0.45),
            "Noise": (0.00, 0.15),
        },
        "automation": ["Cutoff", "Wave Morph", "LFO > Cutoff"],
        "density_cap": 0.38,
        "energy_cap": 0.48,
        "soft_form": True,
    },
    "soft": {
        "label": "Soft / restrained",
        "prefer": [
            "pad", "sub", "pluck", "hollow", "epiano", "flute", "strings", "cello",
            "handpan", "tongue", "theremin", "vibes", "marimba", "choir",
        ],
        "avoid": ["screech", "growl", "glitch", "zap", "neuro", "hoover", "boom"],
        "note_ranges": {
            "pad": (48, 74), "sub": (28, 46), "pluck": (55, 78), "hollow": (32, 54),
            "epiano": (50, 74), "flute": (64, 88), "strings": (48, 72),
            "cello": (36, 60), "handpan": (50, 72), "wobble": (30, 52),
            "reese": (28, 52), "vox": (52, 74),
        },
        "param_windows": {
            "Attack": (0.30, 0.75),
            "Release": (0.40, 0.85),
            "Decay": (0.35, 0.80),
            "Glide": (0.10, 0.40),
            "Drive": (0.00, 0.30),
            "Resonance": (0.10, 0.42),
            "Cutoff": (0.28, 0.60),
            "LFO Rate": (0.06, 0.28),
            "LFO > Cutoff": (0.12, 0.48),
            "FM Amount": (0.00, 0.28),
            "Unison Detune": (0.10, 0.40),
            "Wave Morph": (0.08, 0.50),
            "Filter Env Amt": (0.08, 0.45),
            "Noise": (0.00, 0.20),
        },
        "automation": ["Cutoff", "Wave Morph", "LFO > Cutoff", "Glide"],
        "density_cap": 0.50,
        "energy_cap": 0.55,
        "soft_form": True,
    },
    "aggressive": {
        "label": "Aggressive (kontrast)",
        "prefer": [
            "wobble", "reese", "neuro", "growl", "screech", "kick", "snare", "hat",
            "stab", "hoover", "fmbass", "zap",
        ],
        "avoid": ["drone", "choir", "theremin", "panflute", "handpan"],
        "note_ranges": {},  # użyj domyślnych LEAD/BASS z director
        "param_windows": {
            "Attack": (0.02, 0.25),
            "Release": (0.10, 0.45),
            "Decay": (0.10, 0.40),
            "Glide": (0.00, 0.20),
            "Drive": (0.35, 0.85),
            "Resonance": (0.30, 0.75),
            "Cutoff": (0.35, 0.80),
            "LFO Rate": (0.30, 0.85),
            "LFO > Cutoff": (0.40, 0.95),
            "FM Amount": (0.25, 0.80),
            "Unison Detune": (0.25, 0.70),
            "Filter Env Amt": (0.35, 0.90),
            "Noise": (0.10, 0.45),
        },
        "automation": ["Cutoff", "LFO > Cutoff", "Drive", "FM Amount"],
        "density_cap": 0.95,
        "energy_cap": 0.95,
        "soft_form": False,
    },
}

# Mapowanie stylów → profil (gdy preset="auto")
STYLE_TO_PROFILE = {
    "Space Electronica": "ambient",
    "Berlin School": "ambient",
    "Minimal Classical": "minimal",
    "Ambient": "ambient",
    "Chillout": "ambient",
    "Downtempo": "ambient",
    "Baroque": "soft",
    "Romantic": "soft",
    "Jazz": "soft",
    "House": "soft",
    "Brostep": "aggressive",
    "Riddim": "aggressive",
    "Tearout": "aggressive",
    "Drumstep": "aggressive",
    "Neuro": "aggressive",
    "Psytrance": "aggressive",
    "Techno Trax": "aggressive",
    "Tunnel Trance": "aggressive",
    "Raw Synthesis": "aggressive",
    "Experimental": "aggressive",
}

PROFILE_ORDER = ["auto", "ambient", "minimal", "soft", "aggressive"]
PROFILE_LABELS = {
    "auto": "Auto (ze stylu)",
    "ambient": "Ambient / Space",
    "minimal": "Minimal",
    "soft": "Soft / restrained",
    "aggressive": "Aggressive",
}

DEFAULT_CC = dict(
    on=False,
    intensity=0.65,
    profile="auto",           # auto | ambient | minimal | soft | aggressive
    change_instruments=True,
    change_form=True,
    change_ranges=True,
    change_params=True,
    change_automation=True,
    change_levels=True,
    passes=2,
)


def normalize_cc(d) -> dict:
    out = copy.deepcopy(DEFAULT_CC)
    if not d:
        return out
    for k, v in d.items():
        if k in out:
            out[k] = copy.deepcopy(v)
    out["intensity"] = max(0.0, min(1.0, float(out["intensity"])))
    out["passes"] = max(1, min(3, int(out["passes"])))
    if out["profile"] not in PROFILE_ORDER:
        out["profile"] = "auto"
    return out


def resolve_profile(name: str | None, style: str | None) -> str:
    if name and name != "auto" and name in FLUID_PROFILES:
        return name
    if not style:
        return "soft"
    # hybryda "A 60% + B 40%" → pierwszy składnik
    base = str(style).split("%")[0].split("+")[0].strip()
    if base in STYLE_TO_PROFILE:
        return STYLE_TO_PROFILE[base]
    # heurystyka z energy/density nie tu — style bez mapowania → soft
    try:
        from . import styles as ST
        sc = float(ST.STYLE_CLASS.get(base, 2.5))
        if sc <= 1.2:
            return "ambient"
        if sc <= 2.0:
            return "minimal"
        if sc <= 3.0:
            return "soft"
        return "aggressive"
    except Exception:
        return "soft"


def _sections(proj):
    secs = proj.get("sections") or []
    out = []
    for s in secs:
        if isinstance(s, dict):
            out.append(s)
        elif isinstance(s, (list, tuple)) and len(s) >= 2:
            out.append({"type": s[0], "bars": s[1], "start": s[2] if len(s) > 2 else 0})
    # uzupełnij start jeśli brak
    t = 0
    for s in out:
        if "start" not in s:
            s["start"] = t
        t = s.get("start", t) + int(s.get("bars") or 0)
    return out


def _clamp_note_key(key: int, lo: int, hi: int) -> int:
    if lo > hi:
        lo, hi = hi, lo
    if key < lo:
        # podnieś o oktawy
        while key < lo:
            key += 12
        if key > hi:
            key = lo + (key - lo) % max(1, (hi - lo + 1))
            while key > hi:
                key -= 12
            if key < lo:
                key = lo
    elif key > hi:
        while key > hi:
            key -= 12
        if key < lo:
            key = hi - (hi - key) % max(1, (hi - lo + 1))
            while key < lo:
                key += 12
            if key > hi:
                key = hi
    return int(max(lo, min(hi, key)))


def _apply_note_ranges(tr, lo: int, hi: int, intensity: float, rng: random.Random):
    if tr.get("lock_notes"):
        return 0
    notes = tr.get("notes") or []
    if not notes:
        return 0
    n_change = 0
    new = []
    for on, dur, key, vel in notes:
        k2 = _clamp_note_key(int(key), lo, hi)
        if k2 != int(key) and rng.random() < (0.35 + 0.65 * intensity):
            new.append([on, dur, k2, vel])
            n_change += 1
        else:
            # i tak clamp na sztywno przy wysokiej intensywności
            if intensity >= 0.75:
                new.append([on, dur, k2, vel])
                if k2 != int(key):
                    n_change += 1
            else:
                new.append([on, dur, key, vel])
    tr["notes"] = new
    return n_change


def _blend_param(cur: float, lo: float, hi: float, intensity: float, rng: random.Random) -> float:
    """Przesuń wartość w stronę okna [lo,hi]; przy intensity=1 wylosuj w oknie."""
    target = rng.uniform(lo, hi)
    if cur < lo or cur > hi:
        # poza oknem — mocniej wciągaj
        return cur + (target - cur) * min(1.0, 0.45 + 0.55 * intensity)
    # w oknie — delikatny drift
    return cur + (target - cur) * (0.15 + 0.50 * intensity)


def _apply_param_windows(proj, tr, windows: dict, intensity: float, rng: random.Random) -> int:
    if tr.get("lock_sound"):
        return 0
    m = meta()
    tt = tr["type"]
    locked = set(tr.get("locked_params") or [])
    n = 0
    params = tr.setdefault("params", {})
    for name, (lo, hi) in windows.items():
        if name in locked:
            continue
        if not m.has(tt, name):
            continue
        cur = float(params.get(name, m.def_frac(tt, name)))
        new = _blend_param(cur, lo, hi, intensity, rng)
        new = max(0.0, min(1.0, new))
        if abs(new - cur) > 1e-4:
            params[name] = new
            n += 1
    return n


def _section_points(secs, bars_total: int, pname: str, base: float, depth: float, rng: random.Random):
    """Krzywa automacji: punkty [beat, value] na granicach sekcji + lekki ruch w środku."""
    pts = [[0.0, max(0.0, min(1.0, base + rng.uniform(-0.05, 0.05)))]]
    if not secs:
        # równomierne 4 punkty
        for i in range(1, 5):
            b = (bars_total * i / 4.0) * 4.0
            v = base + depth * math.sin(i * 0.9 + rng.random()) * 0.5
            pts.append([b, max(0.0, min(1.0, v))])
        return pts
    for s in secs:
        start = float(s.get("start") or 0)
        nb = float(s.get("bars") or 4)
        typ = s.get("type") or "drop"
        # ambient: build/drop delikatnie jaśniej, break/outro ciemniej
        bias = {
            "intro": -0.08, "build": 0.06, "drop": 0.10, "break": -0.12, "outro": -0.15,
        }.get(typ, 0.0)
        if pname in ("Drive", "FM Amount", "Resonance"):
            bias *= 0.6
        if pname == "Glide":
            bias = abs(bias) * 0.5
        v0 = base + bias * depth + rng.uniform(-0.04, 0.04) * depth
        v1 = base + bias * depth * 0.5 + depth * 0.15 * math.sin(start + rng.random())
        pts.append([start * 4.0, max(0.0, min(1.0, v0))])
        mid = start + nb * 0.5
        pts.append([mid * 4.0, max(0.0, min(1.0, v1))])
    end_b = max(bars_total, 1) * 4.0
    if pts[-1][0] < end_b - 0.5:
        pts.append([end_b, pts[-1][1]])
    pts.sort(key=lambda p: p[0])
    # dedup przybliżony
    out = [pts[0]]
    for p in pts[1:]:
        if abs(p[0] - out[-1][0]) < 0.25:
            out[-1] = p
        else:
            out.append(p)
    return out


def _apply_automation(proj, tr, auto_names: list, intensity: float, rng: random.Random) -> int:
    if tr.get("lock_sound"):
        return 0
    m = meta()
    tt = tr["type"]
    locked = set(tr.get("locked_params") or [])
    secs = _sections(proj)
    bars = int(proj.get("bars") or 32)
    auto = tr.setdefault("auto", {})
    params = tr.get("params") or {}
    n = 0
    depth = 0.15 + 0.55 * intensity
    for pname in auto_names:
        if pname in locked:
            continue
        if not m.has(tt, pname):
            continue
        # nie nadpisuj istniejącej bogatej automacji przy niskiej intensywności
        existing = auto.get(pname) or []
        if len(existing) >= 4 and intensity < 0.4:
            continue
        base = float(params.get(pname, m.def_frac(tt, pname)))
        auto[pname] = _section_points(secs, bars, pname, base, depth, rng)
        n += 1
    return n


def _soften_form(proj, intensity: float, rng: random.Random) -> list[str]:
    """Wydłuż intro/break/outro, skróć lub złagodź dropy — dla profili soft_form."""
    log = []
    secs = proj.get("sections")
    if not secs or intensity < 0.25:
        return log
    # normalizuj do list [type, bars] lub dict
    changed = False
    new_secs = []
    for s in secs:
        if isinstance(s, dict):
            typ, bars = s.get("type", "drop"), int(s.get("bars") or 8)
            entry = dict(s)
        else:
            typ, bars = s[0], int(s[1])
            entry = [typ, bars]
        if typ == "drop" and bars >= 16 and rng.random() < 0.35 * intensity:
            nb = max(8, int(bars * (0.75 - 0.15 * intensity)))
            nb = nb - (nb % 4) or 8
            if isinstance(entry, dict):
                entry["bars"] = nb
            else:
                entry[1] = nb
            log.append(f"drop {bars}→{nb} t.")
            changed = True
        elif typ in ("intro", "break", "outro") and rng.random() < 0.40 * intensity:
            nb = min(32, int(bars * (1.15 + 0.25 * intensity)))
            nb = nb + (4 - nb % 4) % 4
            if nb != bars:
                if isinstance(entry, dict):
                    entry["bars"] = nb
                else:
                    entry[1] = nb
                log.append(f"{typ} {bars}→{nb} t.")
                changed = True
        new_secs.append(entry)
    if changed:
        proj["sections"] = new_secs
        # przebuduj start
        t = 0
        for s in new_secs:
            if isinstance(s, dict):
                s["start"] = t
                t += int(s.get("bars") or 0)
    return log


def _pick_replacements(proj, profile: dict, intensity: float, rng: random.Random) -> list[str]:
    """Zamień tory z avoid na prefer (gdy wolne sloty / podobna grupa)."""
    from . import generator as G
    log = []
    prefer = list(profile.get("prefer") or [])
    avoid = set(profile.get("avoid") or [])
    if not prefer or intensity < 0.35:
        return log
    avail = set(core.available_types()) if hasattr(core, "available_types") else set(core.TYPES)
    prefer = [p for p in prefer if p in avail]
    if not prefer:
        return log
    # grupy z core.GROUPS jeśli są
    groups = getattr(core, "GROUPS", {}) or {}
    type_group = {}
    for g, ts in groups.items():
        for t in ts:
            type_group[t] = g

    for tr in list(proj.get("tracks") or []):
        tt = tr.get("type")
        if not tt or tt not in avoid:
            continue
        if tr.get("lock_sound") or tr.get("lock_notes"):
            continue
        if rng.random() > (0.25 + 0.55 * intensity):
            continue
        g = type_group.get(tt)
        candidates = [p for p in prefer if type_group.get(p) == g] or prefer
        # unikaj duplikatów jeśli dużo
        have = {t["type"] for t in proj["tracks"]}
        cand2 = [c for c in candidates if c not in have] or candidates
        new_t = rng.choice(cand2)
        if new_t == tt:
            continue
        old = tt
        tr["type"] = new_t
        if hasattr(core, "PLUGIN_ID") and new_t in getattr(core, "PLUGIN_ID", {}):
            tr["plugin"] = core.PLUGIN_ID[new_t]
        # wyczyść parametry niepasujące — randomize później
        tr["params"] = {}
        tr["auto"] = {}
        log.append(f"{tr.get('name', old)}: {old} → {new_t}")
    return log


def apply_critical_correct(proj: dict, cc=None, rng: random.Random | None = None) -> dict:
    """Główna autokorekta krytyczna na projekcie (in-place + zwrot).

    cc: dict z normalize_cc (on, intensity, profile, flagi change_*).
    Zwraca proj; dopisuje proj['critical_correct_report'].
    """
    cfg = normalize_cc(cc if cc is not None else proj.get("critical_correct"))
    report = {
        "on": cfg["on"],
        "intensity": cfg["intensity"],
        "profile": cfg["profile"],
        "resolved_profile": None,
        "log": [],
        "stats": {},
    }
    if not cfg["on"] or cfg["intensity"] <= 0.0:
        report["log"].append("wyłączone lub intensity=0")
        proj["critical_correct_report"] = report
        proj["critical_correct"] = cfg
        return proj

    rng = rng or random.Random(int(proj.get("seed") or 0) ^ 0xC0FFEE)
    style = proj.get("style") or ""
    pid = resolve_profile(cfg["profile"], style)
    profile = FLUID_PROFILES[pid]
    report["resolved_profile"] = pid
    report["log"].append(f"profil={pid} ({profile.get('label', pid)}), intensity={cfg['intensity']:.2f}")

    intensity = float(cfg["intensity"])
    passes = int(cfg["passes"])
    stats = dict(params=0, notes=0, auto=0, replaced=0, form=0)

    # Ogranicz energy/density w meta projektu (dla spójności z profilem)
    if profile.get("density_cap") is not None and intensity > 0.3:
        d0 = float(proj.get("density") or 0.5)
        cap = float(profile["density_cap"])
        if d0 > cap:
            proj["density"] = d0 + (cap - d0) * intensity
            report["log"].append(f"density {d0:.2f}→{proj['density']:.2f}")
    if profile.get("energy_cap") is not None and intensity > 0.3:
        e0 = float(proj.get("energy") or 0.5)
        cap = float(profile["energy_cap"])
        if e0 > cap:
            proj["energy"] = e0 + (cap - e0) * intensity
            report["log"].append(f"energy {e0:.2f}→{proj['energy']:.2f}")

    for pno in range(passes):
        step_i = intensity * (1.0 - 0.35 * pno)  # malejący krok
        if step_i < 0.08:
            break
        report["log"].append(f"— przebieg {pno + 1}/{passes} (step={step_i:.2f})")

        # 1) instrumenty
        if cfg["change_instruments"]:
            logs = _pick_replacements(proj, profile, step_i, rng)
            stats["replaced"] += len(logs)
            report["log"].extend(logs)

        # 2) forma
        if cfg["change_form"] and profile.get("soft_form"):
            fl = _soften_form(proj, step_i, rng)
            stats["form"] += len(fl)
            report["log"].extend(fl)

        ranges = profile.get("note_ranges") or {}
        windows = profile.get("param_windows") or {}
        auto_names = list(profile.get("automation") or [])

        for tr in proj.get("tracks") or []:
            tt = tr.get("type")
            if not tt:
                continue

            # 3) zakresy nut
            if cfg["change_ranges"] and tt in ranges:
                lo, hi = ranges[tt]
                n = _apply_note_ranges(tr, lo, hi, step_i, rng)
                stats["notes"] += n

            # 4) parametry w oknach profilu
            if cfg["change_params"] and windows:
                # jeśli params puste (po replace) — pełny blend od def
                if not tr.get("params"):
                    try:
                        from . import generator as G
                        G.randomize_sound(proj, tr, rng, use_windows=False)
                    except Exception:
                        pass
                n = _apply_param_windows(proj, tr, windows, step_i, rng)
                stats["params"] += n

            # 5) automacje płynące
            if cfg["change_automation"] and auto_names:
                n = _apply_automation(proj, tr, auto_names, step_i, rng)
                stats["auto"] += n

    # 6) poziomy
    if cfg["change_levels"] and intensity >= 0.2:
        try:
            autolevel_heuristic(proj)
            report["log"].append("autolevel")
            stats["levels"] = 1
        except Exception as ex:
            report["log"].append(f"autolevel skip: {ex}")

    report["stats"] = stats
    report["log"].append(
        f"suma: params={stats['params']} notes={stats['notes']} auto={stats['auto']} "
        f"replace={stats['replaced']} form={stats['form']}"
    )
    proj["critical_correct"] = cfg
    proj["critical_correct_report"] = report
    try:
        core.sanitize_notes(proj)
    except Exception:
        pass
    return proj


def profile_for_style(style: str) -> str:
    return resolve_profile("auto", style)
