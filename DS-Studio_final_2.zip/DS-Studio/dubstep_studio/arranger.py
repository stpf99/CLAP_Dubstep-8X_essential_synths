"""arranger.py — ARANŻER: samodzielnie korzysta przy aranżacji z zasobów (barwy, extras FX, kreator),
a gdy ich brakuje (lub z ustawionym prawdopodobieństwem) TWORZY NOWE „ad hoc” i ustala efekty w edytorze WYSIWYG.

Wywoływany z generate() po rolach/autolevelu, przed niuansami (opcja `arranger=`), a przez Live — przy każdej nowej aranżacji.

Co robi (każdy krok osobno wyłączalny):
  1. BARWY   — na torach melodycznych/basowych nakłada barwę z timbre_bank (wg typu wtyczki), albo nową ad hoc.
  2. LAYERY  — barwa stereo (dual) jako warstwa grająca nuty istniejącego toru (notes_from), bez kopiowania nut.
  3. EXTRAS  — FX z extras_fx w sensownych miejscach struktury: riser na końcu buildu, uderzenie na starcie dropu,
               tekstury w break/intro/outro, foley rzadko; nowe extras ad hoc, gdy kategoria nie ma przepisu.
  4. KREATOR — typy/extras proponuje scenario_creator.auto_choice (ten sam zasób co kreator w GUI).
  5. WYSIWYG — dokument figur (geometry_editor): rosnąca figura w buildzie, wzgórze w dropie, miękkie wgłębienie w break;
               stosowany na projekt (velocity + automatyzacja Cutoff/Drive/Resonance) i zapisany w proj["geometry_doc"],
               więc po wczytaniu projektu widać go i można edytować w zakładce „Edytor WYSIWYG”.

Nowe barwy/extras trafiają do rejestrów TB.TIMBRES / FX.EXTRAS, do proj["adhoc"] (projekt jest samowystarczalny)
i — gdy persist=True — do ~/DubstepStudio/adhoc_bank.json (DS_ADHOC_BANK nadpisuje ścieżkę), skąd GUI je wczytuje.
Wszystkie losowania idą z przekazanego rng, więc ten sam seed daje ten sam projekt niezależnie od banku na dysku.
"""
from __future__ import annotations

import copy
import json
import os
import random
import zlib
from pathlib import Path

DEFAULT = dict(
    on=False,
    use_timbres=True,       # nakładaj barwy z banku
    use_extras=True,        # dokładaj extras FX
    use_creator=True,       # dobór także przez scenario_creator.auto_choice
    adhoc=True,             # twórz nowe barwy/extras ad hoc
    wysiwyg=True,           # ustal efekty figurami WYSIWYG i zastosuj
    layers=True,            # warstwa stereo z barwy dual
    contour=False,          # figury „kontur” na leadach (przesuwają wysokości nut — domyślnie wyłączone)
    amount=0.5,             # 0..1: ile torów dostaje barwę / ile extras
    adhoc_amount=0.4,       # 0..1: szansa, że zamiast banku powstanie nowa barwa/extra
    wysiwyg_strength=0.6,   # 0..1: siła figur
    max_extra_tracks=4,     # twardy limit nowych torów extras
    persist=False,          # zapisuj nowe ad hoc do adhoc_bank.json
)

DRUMS = {"kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "openhat", "ride", "cowbell", "conga"}
BASS = {"sub", "wobble", "reese", "neuro", "fmbass", "hollow", "growl", "bass808", "upright"}
LEAD = {"screech", "supersaw", "pluck", "stab", "theremin", "panflute", "vox", "handpan", "tongue", "zap", "piano", "acid", "strings",
        "epiano", "harpsichord", "flute", "brass", "hoover", "vibes", "marimba", "bell", "organ", "cello"}
PAD = {"pad", "choir", "drone"}

# kategorie extras wg wzoru nut (_pattern_notes); nieznane → tekstura
CAT = {
    "riser": {"riser_bar", "riser_long", "swell", "whoosh", "tape_stop"},
    "impact": {"hit", "stabs", "glitch"},
    "texture": {"drone", "long_noise", "rain", "crackle", "breath", "birds", "creak", "scrape", "modem"},
    "foley": {"ticks", "sparse_ticks", "typewriter", "gravel", "steps", "clock", "gears"},
}
# co ad hoc może zbudować dla kategorii: (typ wtyczki, wzór nut)
ADHOC_RECIPES = {
    "riser": [("riser", "riser_bar"), ("riser", "riser_long"), ("riser", "whoosh"), ("zap", "tape_stop")],
    "impact": [("boom", "hit"), ("crash", "hit"), ("zap", "hit")],
    "texture": [("shaker", "long_noise"), ("shaker", "rain"), ("pad", "drone"), ("shaker", "crackle")],
    "foley": [("rim", "ticks"), ("hat", "sparse_ticks"), ("shaker", "gravel")],
}
CHAR_PARAMS = ("Cutoff", "Resonance", "Drive", "FM Amount", "Unison Detune", "Noise", "Wave Morph", "LFO > Cutoff",
               "Formant Mix", "Decay", "Release", "Attack", "Stereo Width", "Sub Osc", "Pitch Env Amt")
FX_PARAMS = ("Noise", "Noise Decay", "Noise Highpass", "Noise Lowpass", "Cutoff", "Decay", "Release", "Attack", "Tune",
             "Ramp Time", "Ramp > Cutoff", "Ramp > Level", "Drive", "Resonance", "Pitch Env Amt", "Pitch Env Decay")


def normalize(d):
    out = copy.deepcopy(DEFAULT)
    if d is True:
        out["on"] = True
    elif isinstance(d, dict):
        for k, v in d.items():
            out[k] = copy.deepcopy(v)
    for k in ("amount", "adhoc_amount", "wysiwyg_strength"):
        out[k] = max(0.0, min(1.0, float(out[k])))
    out["max_extra_tracks"] = max(0, min(12, int(out["max_extra_tracks"])))
    return out


# ------------------------------------------------------------------ bank ad hoc (rejestry + dysk)
def bank_path():
    return Path(os.environ.get("DS_ADHOC_BANK") or (Path.home() / "DubstepStudio" / "adhoc_bank.json"))


MAX_ADHOC_REGISTRY = 200


def _register(kind, sid, spec):
    """Wpis do rejestru (GUI listuje TB.TIMBRES / FX.EXTRAS). Rejestr ad hoc jest przycinany — Live działa godzinami."""
    from . import extras_fx as FX, timbre_bank as TB
    reg = TB.TIMBRES if kind == "timbres" else FX.EXTRAS
    spec.setdefault("adhoc", True)
    reg.pop(sid, None)
    reg[sid] = spec
    ah = [k for k, v in reg.items() if v.get("adhoc")]
    for k in ah[:max(0, len(ah) - MAX_ADHOC_REGISTRY)]:
        reg.pop(k, None)


def restore(proj):
    """Rejestruje barwy/extras ad hoc zapisane w projekcie (projekt otwarty na innej maszynie / po restarcie)."""
    n = 0
    for kind in ("timbres", "extras"):
        for sid, spec in ((proj.get("adhoc") or {}).get(kind) or {}).items():
            _register(kind, sid, copy.deepcopy(spec)); n += 1
    return n


def load_bank():
    """Wczytuje zapisany bank ad hoc do rejestrów. Zwraca liczbę wpisów; brak/uszkodzony plik → 0."""
    try:
        data = json.loads(bank_path().read_text(encoding="utf-8"))
    except Exception:
        return 0
    n = 0
    for kind in ("timbres", "extras"):
        for sid, spec in (data.get(kind) or {}).items():
            if isinstance(spec, dict):
                _register(kind, sid, spec); n += 1
    return n


def save_bank(new, keep=200):
    """Dopisuje nowe wpisy do banku (zapis atomowy). new = {"timbres": {...}, "extras": {...}}."""
    p = bank_path()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    for kind in ("timbres", "extras"):
        cur = data.setdefault(kind, {})
        cur.update(new.get(kind) or {})
        while len(cur) > keep:                       # najstarsze wypadają (kolejność wstawiania)
            cur.pop(next(iter(cur)))
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)


# ------------------------------------------------------------------ tworzenie ad hoc
def _ao(proj):
    if proj.get("A") is not None:
        return float(proj["A"]), float(proj.get("o", 0.5))
    from . import director as DIR
    try:
        return DIR.aggression(proj.get("style") or "Brostep", float(proj.get("energy", 0.7)), float(proj.get("mood") or 0.0))
    except Exception:
        return 0.5, 0.5


def _plugin_params(ttype):
    from . import core
    return core.meta().plugins[core.PLUGIN_ID[ttype]]["params"]


def _crc(obj):
    return zlib.crc32(json.dumps(obj, sort_keys=True, default=str).encode()) & 0xFFFFFF


def _window_params(ttype, names, A, o, rng, k_lo, k_hi, half=0.07):
    """Okna wartości (frakcje 0..1) dla losowego podzbioru parametrów, które ISTNIEJĄ w wtyczce i nie są schodkowe."""
    from . import director as DIR
    valid = _plugin_params(ttype)
    pool = [n for n in names if n in valid and not valid[n].get("stepped")]
    if not pool:
        return {}
    chosen = rng.sample(pool, min(len(pool), rng.randint(k_lo, k_hi)))
    out = {}
    for n in sorted(chosen):
        v = DIR.window(n, (None, None, 0.0, 1.0), A, o, rng, width=0.3)
        out[n] = (round(max(0.0, v - half), 4), round(min(1.0, v + half), 4))
    return out


def make_adhoc_timbre(base, A, o, rng, stereo=None):
    """Nowa barwa na typie `base`: okna parametrów wokół agresji A / optymizmu o (a nie całe min…max)."""
    params = _window_params(base, CHAR_PARAMS, A, o, rng, 3, 6)
    role = "bass" if base in BASS else "pad" if base in PAD else "lead"
    if stereo is None:
        stereo = base in ("supersaw", "pad", "reese", "strings") and rng.random() < 0.5
    adsr = (round(0.005 + 0.25 * (1 - A) * (1.0 if role != "bass" else 0.2), 3), round(0.2 + 0.4 * (1 - A), 3),
            round(0.5 + 0.3 * (1 - A), 3), round(0.15 + 0.35 * (1 - A), 3))
    sid = f"adhoc_{base}_{_crc([base, params, adsr, stereo]):06x}"
    return sid, dict(base=base, params=params, adsr=adsr, stereo=bool(stereo), stereo_detune=0.025 if stereo else 0.0,
                     tags=[role, "adhoc"] + (["stereo"] if stereo else []), adhoc=True,
                     desc=f"ad hoc {base}: agresja {A:.2f}, optymizm {o:.2f}")


def make_adhoc_extra(cat, A, o, rng):
    """Nowy extra dla kategorii (riser/impact/texture/foley): typ + wzór z ADHOC_RECIPES, parametry w oknach."""
    from . import extras_fx as FX
    ttype, pattern = rng.choice(ADHOC_RECIPES[cat])
    params = {n: (lo + hi) / 2 for n, (lo, hi) in
              _window_params(ttype, FX_PARAMS, A, o, rng, 2, 4, half=0.0).items()}
    params = FX.fix_params(ttype, params)
    valid = _plugin_params(ttype)
    if "Level" in valid:
        params["Level"] = round(0.55 + 0.25 * rng.random(), 3)
    gain = {"riser": 0.55, "impact": 0.7, "texture": 0.4, "foley": 0.45}[cat]
    sid = f"fx_adhoc_{cat}_{_crc([ttype, pattern, params]):06x}"
    return sid, dict(type=ttype, gain=gain, pattern=pattern, params={k: round(float(v), 4) for k, v in params.items()},
                     adhoc=True, desc=f"ad hoc {cat}: {ttype}/{pattern}")


def _category(spec):
    pat = spec.get("pattern") or "hit"
    for cat, pats in CAT.items():
        if pat in pats:
            return cat
    return "texture"


# ------------------------------------------------------------------ rozmieszczenie extras w strukturze
def _placements(cat, sections, bars):
    """-> lista (start_bar, bars) dla kategorii extras wg typów sekcji."""
    out = []
    for i, s in enumerate(sections):
        t, st, nb = s.get("type"), int(s.get("start", 0)), int(s.get("bars", 0))
        if nb <= 0:
            continue
        if cat == "riser" and t == "build":
            n = min(nb, 4 if nb >= 8 else 2)
            out.append((st + nb - n, n))
        elif cat == "impact" and t == "drop":
            out.append((st, 1))
        elif cat == "texture" and t in ("intro", "break", "outro"):
            out.append((st, min(nb, 8)))
        elif cat == "foley" and t in ("break", "intro"):
            out.append((st, min(nb, 4)))
    return [(a, max(1, min(b, bars - a))) for a, b in out if a < bars]


def _role_of(tr):
    t = tr["type"]
    return "bass" if t in BASS else "pad" if t in PAD else "lead" if t in LEAD else "drum" if t in DRUMS else "fx"


def _note_count(tr):
    return len(tr.get("notes") or [])


# ------------------------------------------------------------------ kroki
def _step_timbres(proj, o_, rng, A, o, rep, new):
    from . import timbre_bank as TB
    lock_map = ((proj.get("director") or {}).get("param_locks") or {})
    candidates = [t for t in proj["tracks"] if _role_of(t) in ("bass", "lead", "pad") and not t.get("lock_sound")
                  and not t.get("timbre_id") and _note_count(t) > 0]
    for tr in candidates:
        if rng.random() > o_["amount"] * 0.9:
            continue
        base = tr["type"]
        pool = [k for k, s in TB.TIMBRES.items() if s["base"] == base and not s.get("adhoc")]
        spec, sid, adhoc = None, None, False
        if o_["adhoc"] and (not pool or rng.random() < o_["adhoc_amount"]):
            sid, spec = make_adhoc_timbre(base, A, o, rng, stereo=False)       # na istniejącym torze: mono
            adhoc = True
        elif pool:
            sid = rng.choice(pool)
        if not sid:
            continue
        keep = {k: v for k, v in (tr.get("params") or {}).items()
                if k in (tr.get("locked_params") or {}) or k in (lock_map.get(base) or {})}
        if not TB.apply_timbre_to_track(tr, sid, rng, custom_spec=spec):
            continue
        tr["params"].update(keep)
        tr["timbre_id"] = sid
        if adhoc:
            new["timbres"][sid] = spec
            _register("timbres", sid, spec)
        rep["timbres"].append(dict(track=tr["name"], id=sid, adhoc=adhoc))


def _step_layers(proj, o_, rng, A, o, rep, new, creator_timbres):
    from . import timbre_bank as TB
    if rng.random() > 0.35 + 0.6 * o_["amount"]:
        return
    stereo = [k for k in creator_timbres if TB.TIMBRES.get(k, {}).get("stereo")]
    stereo += [k for k, s in TB.TIMBRES.items() if s.get("stereo") and not s.get("adhoc") and k not in stereo]
    sid, spec, adhoc = None, None, False
    srcs = [t for t in proj["tracks"] if _role_of(t) in ("lead", "pad") and _note_count(t) > 8 and not t.get("extra_id")]
    if not srcs:
        return
    src = max(srcs, key=_note_count)
    if o_["adhoc"] and (not stereo or rng.random() < o_["adhoc_amount"]):
        base = src["type"] if src["type"] in ("supersaw", "pad", "strings", "reese") else rng.choice(("supersaw", "pad"))
        sid, spec = make_adhoc_timbre(base, A, o, rng, stereo=True); adhoc = True
    elif stereo:
        sid = rng.choice(stereo)
    if not sid:
        return
    if adhoc:
        _register("timbres", sid, spec)
    made = TB.spawn_timbre(proj, sid, rng)
    for tr in made:
        tr["notes_from"] = src["name"]
        tr["notes_transpose"] = 0
        tr["gain"] = round(float(src.get("gain", 0.6)) * 0.7, 3)
        tr["layer_of"] = src["name"]
    if made:
        if adhoc:
            new["timbres"][sid] = spec
        rep["layers"].append(dict(id=sid, adhoc=adhoc, source=src["name"], tracks=[t["name"] for t in made]))


def _step_extras(proj, o_, rng, A, o, rep, new, picks):
    from . import extras_fx as FX, core
    sections, bars = proj.get("sections") or [], int(proj.get("bars") or 0)
    limit = o_["max_extra_tracks"]
    if limit <= 0 or not sections:
        return
    want = {"riser": any(s["type"] == "build" for s in sections), "impact": any(s["type"] == "drop" for s in sections),
            "texture": any(s["type"] in ("intro", "break", "outro") for s in sections), "foley": False}
    chosen, seen_cat = [], set()
    for sid in picks:
        spec = FX.EXTRAS.get(sid)
        if spec and not spec.get("adhoc"):
            c = _category(spec)
            if c in seen_cat and rng.random() < 0.6:
                continue
            seen_cat.add(c); chosen.append((sid, spec, False))
    # kategorie, które struktura potrzebuje, a nic z banku ich nie pokrywa → przepis z banku albo ad hoc
    for cat, need in want.items():
        if not need or cat in seen_cat or len(chosen) >= limit:
            continue
        if rng.random() > 0.35 + 0.65 * o_["amount"]:
            continue
        pool = [k for k, s in FX.EXTRAS.items() if not s.get("adhoc") and _category(s) == cat]
        if o_["adhoc"] and (not pool or rng.random() < o_["adhoc_amount"]):
            sid, spec = make_adhoc_extra(cat, A, o, rng)
            chosen.append((sid, spec, True))
        elif pool:
            sid = rng.choice(pool)
            chosen.append((sid, FX.EXTRAS[sid], False))
        seen_cat.add(cat)
    avail = set(core.available_types())
    for sid, spec, adhoc in chosen[:limit]:
        if spec["type"] not in avail:
            continue
        spots = _placements(_category(spec), sections, bars)
        if not spots:
            continue
        if adhoc:
            _register("extras", sid, spec)
        tr = FX.spawn_extra(proj, sid, start_bar=spots[0][0], bars=spots[0][1], rng=rng)
        if tr is None:
            continue
        for a, b in spots[1:]:
            tr["notes"] += FX._pattern_notes(spec.get("pattern") or "hit", a * 4.0, b, rng)
        tr["notes"] = sorted(tr["notes"], key=lambda n: (n[0], n[2]))
        if adhoc:
            new["extras"][sid] = spec
        rep["extras"].append(dict(id=sid, adhoc=adhoc, category=_category(spec), track=tr["name"], at=[a for a, _ in spots]))


def build_wysiwyg(proj, o_, rng, A):
    """Dokument figur intensywności, po jednym pasie na tor (bas/lead/pad): build → elipsa ze szczytem na końcu sekcji
    (narastanie), drop → elipsa/trapez ze szczytem w pierwszej ćwiartce (akcent uderzenia i zanik), break/intro/outro →
    niska elipsa (wygaszenie). Opcjonalnie figury „kontur” na leadach."""
    from . import geometry_editor as GE
    bars = max(1, int(proj.get("bars") or 1))
    doc = GE.default_document(bars)
    tracks = [t for t in proj["tracks"] if _role_of(t) in ("bass", "lead", "pad") and not t.get("lock_sound")
              and not t.get("extra_id") and _note_count(t) > 0]
    # Pole figury (środek 1 → brzeg 0, liczone na linii środka) daje efekt (f − 0.5)·zasięg: f > 0.5 otwiera/wzmacnia,
    # f < 0.5 przycina. amp skaluje rozstrzał: szczyty → 0.5 + 0.5·amp, wygaszenia → 0.5 − 0.45·amp.
    amp = 0.4 + 0.6 * o_["wysiwyg_strength"] * (0.8 + 0.2 * A)
    peak, dip = min(1.0, 0.5 + 0.5 * amp), max(0.0, 0.5 - 0.45 * amp)
    shapes, n = [], max(1, len(tracks))
    for i, tr in enumerate(tracks):
        y, h = i / n + 0.06 / n, 0.88 / n
        for si, sec in enumerate(proj.get("sections") or []):
            sx, sw, t = sec["start"] / bars, sec["bars"] / bars, sec["type"]
            if sw <= 0:
                continue
            if t == "build":          # narastanie: szczyt dokładnie na końcu buildu (= start dropu)
                kind, x, w, st = "ellipse", sx, 2 * sw, peak
            elif t == "drop":         # szczyt w pierwszej ćwiartce dropu, potem zanik — akcent uderzenia
                kind, x, w, st = rng.choice(("ellipse", "trapezoid")), sx - 0.5 * sw, 1.5 * sw, peak
            elif t in ("break", "intro", "outro"):
                kind, x, w, st = "ellipse", sx, sw, dip
            else:
                continue
            x = max(0.0, x); w = max(0.02, min(w, 1.0 - x))
            sh = GE.new_shape(kind, x=x, y=y, w=w, h=h, channel="intensity", track=tr["name"])
            sh["strength"] = round(st, 3)
            sh["fill_mode"] = "manual"
            sh["id"] = f"ar{_crc([tr['name'], si, kind]):06x}"[:10]
            sh["z"] = len(shapes)
            shapes.append(sh)
        if o_["contour"] and _role_of(tr) == "lead":
            for si, sec in enumerate(proj.get("sections") or []):
                if sec["type"] != "drop":
                    continue
                sh = GE.new_shape("ellipse", x=sec["start"] / bars, y=y, w=sec["bars"] / bars, h=h, channel="contour", track=tr["name"])
                sh["strength"] = round(0.35 * o_["wysiwyg_strength"], 3); sh["fill_mode"] = "manual"
                sh["id"] = f"ac{_crc([tr['name'], si, 'c']):06x}"[:10]
                sh["z"] = len(shapes)
                shapes.append(sh)
    doc["shapes"] = shapes
    return doc


# ------------------------------------------------------------------ wejście
def apply(proj, opts=None, rng=None):
    """Główny punkt wejścia. Zwraca raport (zapisany też w proj["arranger_report"]); nic nie robi gdy opts["on"] = False."""
    o_ = normalize(opts)
    if not o_["on"] or not proj.get("tracks"):
        return {}
    rng = rng or random.Random(int(proj.get("seed", 0)) + 131)
    A, o = _ao(proj)
    rep = dict(timbres=[], layers=[], extras=[], wysiwyg={}, creator={}, A=round(A, 3), o=round(o, 3))
    new = {"timbres": {}, "extras": {}}
    restore(proj)
    style = str(proj.get("style") or "Brostep")
    picks, creator_timbres = [], []
    from . import extras_fx as FX
    if o_["use_extras"]:
        k = 1 + int(round(2 * o_["amount"]))
        picks += FX.weighted_extras_for_style(style, n=k, rng=rng)[0]
    if o_["use_creator"]:
        try:
            from . import scenario_creator as SC
            sess = {"style": style.split("%")[0].split("+")[0].strip(), "bars": int(proj.get("bars") or 64)}
            cx = SC.auto_choice("extras", sess, rng)
            ct = SC.auto_choice("timbres", sess, rng)
            if o_["use_extras"]:
                picks += [x for x in cx.get("extras", []) if x not in picks]
            creator_timbres = list(ct.get("timbres") or [])
            rep["creator"] = dict(extras=list(cx.get("extras", [])), timbres=creator_timbres)
        except Exception as e:          # kreator jest dodatkiem — jego błąd nie może zatrzymać generowania
            rep["creator"] = dict(error=str(e)[:120])
    if o_["use_timbres"]:
        _step_timbres(proj, o_, rng, A, o, rep, new)
        if o_["layers"]:
            _step_layers(proj, o_, rng, A, o, rep, new, creator_timbres)
    if o_["use_extras"]:
        _step_extras(proj, o_, rng, A, o, rep, new, picks)
    if o_["wysiwyg"]:
        from . import geometry_editor as GE
        doc = build_wysiwyg(proj, o_, rng, A)
        out = GE.apply_to_project(proj, doc, random.Random(int(proj.get("seed", 0)) + 61))
        rep["wysiwyg"] = dict(shapes=len(doc["shapes"]), tracks=len(out.get("intensity") or []))
    if new["timbres"] or new["extras"]:
        proj.setdefault("adhoc", {"timbres": {}, "extras": {}})
        for kind in ("timbres", "extras"):
            proj["adhoc"].setdefault(kind, {}).update(new[kind])
        if o_["persist"]:
            try:
                save_bank(new)
            except OSError as e:
                rep["persist_error"] = str(e)[:120]
    proj["arranger"] = o_
    proj["arranger_report"] = rep
    return rep

# --- instrumenty użytkownika (karta „Modelowanie CLAP”): dopisanie zatwierdzonych typów do tabel tego modułu
from . import userinst as _userinst  # noqa: E402
_userinst.apply_module("arranger")
