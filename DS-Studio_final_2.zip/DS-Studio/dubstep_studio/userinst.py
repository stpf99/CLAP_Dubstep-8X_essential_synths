"""userinst.py — instrumenty CLAP użytkownika (karta „Modelowanie CLAP”).

Przepływ:
  1. Szkic instrumentu = JSON w `user_instruments/<id>.json` (parametry silnika, flagi, klasyfikacja dla generatora, style/epoki).
  2. „Zatwierdź do biblioteki” → generujemy `src/user/<id>.inc` (definicja `TypeDef` w C++), agregaty `src/ds_user_types.inc`,
     `src/ds_user_modal.inc` i `user_types.mk` (dopisuje nazwę do `NAMES` w Makefile), po czym budujemy `make build/DS-<Nazwa>.clap`
     (+ paczkę DubstepKit.clap). Typy użytkownika są dopisywane NA KOŃCU listy, więc indeksy wbudowanych (i starszych użytkownika) się nie zmieniają
     i make przebudowuje tylko nową wtyczkę.
  3. Po udanej kompilacji typ jest rejestrowany w kodzie aplikacji (core.TYPES/GROUPS/…, tabele generatora, dyrektora, niuansów, epok, stylów),
     a meta-dane wtyczek są odświeżane — bez restartu GUI. Przy starcie aplikacji wszystkie zatwierdzone specyfikacje są rejestrowane automatycznie
     (typ jest „dostępny”, gdy znaleziono jego .clap — jak dla pozostałych opcjonalnych wtyczek).

Podgląd (odsłuch) kompiluje tymczasową wtyczkę do `build/preview/` z osobnym zestawem agregatów (-DDS_USER_TYPES_INC=…), niczego nie zmieniając w bibliotece.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent
SPEC_DIR = APP_DIR / "user_instruments"
SRC = APP_DIR / "src"
USER_SRC = SRC / "user"
MK = APP_DIR / "user_types.mk"
PREFIX = "stpf99.dubstep."

ID_RE = re.compile(r"^[a-z][a-z0-9]{1,15}$")
GROUPS = ["Perkusja", "Bas", "Synth / lead", "FX", "Akustyczne"]
GROUP_TO_INST = {"Perkusja": "drums", "Bas": "bass", "Synth / lead": "lead", "FX": "fx", "Akustyczne": "acoustic"}
ROLES = ["", "bass", "lead", "pad"]
ERAS = ["minimal_70s", "analog_80s", "digital_90s", "rave_00s", "modern_10s"]
MODAL_BUILTIN = ["Brak", "Handpan", "Tongue drum", "Vibes", "Marimba", "Bell"]      # indeks = wartość pola modal (1..5)
CUSTOM_MODAL_FIRST = 6                                                               # własne banki: 6, 7, …
SKIP_PARAM_GROUPS = {"Speech"}                                                       # parametry DS Speak nie mają sensu w nowych instrumentach

REGISTRY: dict = {}          # id -> spec zarejestrowane w tej sesji
_INFO = None                 # cache zrzutu build/dstypes


# ------------------------------------------------------------------ narzędzia
def plugin_name(iid):
    return iid[:1].upper() + iid[1:]


def clap_path(iid, base="build"):
    return APP_DIR / base / f"DS-{plugin_name(iid)}.clap"


def is_built(iid):
    return clap_path(iid).exists()


def _write_if_changed(path, text):
    path = Path(path)
    try:
        if path.exists() and path.read_text(encoding="utf-8") == text:
            return False
    except OSError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return True


def _f(v):
    v = float(v)
    s = f"{v:.7g}"
    if "e" not in s and "." not in s:
        s += ".0"
    return s + "f"


# ------------------------------------------------------------------ informacje o silniku (build/dstypes)
def engine_info(refresh=False, log=None):
    """Tabela parametrów i definicje typów z silnika C++ (JSON). Buduje build/dstypes, jeśli go brak."""
    global _INFO
    if _INFO is not None and not refresh:
        return _INFO
    exe = APP_DIR / "build" / "dstypes"
    if refresh or not exe.exists():
        r = subprocess.run(["make", "-C", str(APP_DIR), "build/dstypes"], capture_output=True, text=True)
        if log:
            log(r.stdout + r.stderr)
        if r.returncode != 0 or not exe.exists():
            raise RuntimeError("Nie udało się zbudować build/dstypes (make):\n" + (r.stderr or r.stdout)[-600:])
    out = subprocess.run([str(exe)], capture_output=True, text=True, timeout=30)
    _INFO = json.loads(out.stdout)
    return _INFO


def params():
    """Parametry silnika dostępne dla nowych instrumentów (bez grupy Speech)."""
    return [p for p in engine_info()["params"] if p["group"] not in SKIP_PARAM_GROUPS]


def builtin_type_ids():
    ids = {t["id"][len(PREFIX):] for t in engine_info()["types"]}
    user = {s["id"] for s in list_specs() if s.get("status") == "approved"}
    return ids - user


def type_template(tid):
    """Definicja istniejącego typu (do klonowania) — ex/hid/flagi."""
    for t in engine_info()["types"]:
        if t["id"] == PREFIX + tid:
            return t
    return None


# ------------------------------------------------------------------ specyfikacje
def new_spec(base=None):
    """Nowa specyfikacja; `base` = id istniejącego typu do sklonowania parametrów."""
    spec = {
        "id": "", "name": "", "desc": "", "status": "draft", "seq": 0,
        "oneshot": False, "retrig": False, "ref": 261.6256, "modal": 0, "modal_custom": None,
        "ex": [], "hid": [],
        "group": "Synth / lead", "gen": "stab", "role": "lead", "melodic": True, "sustained": False,
        "duck": 0.3, "gain": 0.6, "target_rel": 0.5, "agg": 2.0, "bands": [0.05, 0.2, 0.45, 0.3],
        "sound": [], "styles": [], "style_front": False, "eras": ["digital_90s", "rave_00s", "modern_10s"],
        "disabled": False,
    }
    if base:
        apply_template(spec, base)
    return spec


def apply_template(spec, base):
    t = type_template(base)
    if not t:
        return
    spec["oneshot"], spec["retrig"], spec["ref"] = t["oneshot"], t["retrig"], t["ref"]
    spec["modal"] = t["modal"] if t["modal"] <= 5 else 0
    spec["ex"] = [[int(i), float(v)] for i, v in t["ex"]]
    spec["hid"] = [[int(i), float(v)] for i, v in t["hid"]]
    spec["sound"] = auto_sound(spec)


def auto_sound(spec, spread=0.35):
    """Domyślne zakresy losowania brzmienia generatora: wokół wartości parametrów jawnych (LOG: mnożnikowo, LIN: proporcjonalnie do zakresu)."""
    P = {p["i"]: p for p in params()}
    out = []
    for i, v in spec.get("ex", []):
        p = P.get(i)
        if not p or p["kind"] == "int" or p["name"] in ("Level", "Key Track", "Tune", "Fine"):
            continue
        lo, hi = p["lo"], p["hi"]
        if p["kind"] == "log":
            a, b = max(lo, v / (1 + spread * 2)), min(hi, v * (1 + spread * 2))
        else:
            w = (hi - lo) * spread * 0.5
            a, b = max(lo, v - w), min(hi, v + w)
        if b - a > 1e-6:
            out.append([p["name"], "r", round(a, 4), round(b, 4)])
    return out


def list_specs():
    out = []
    if SPEC_DIR.exists():
        for f in sorted(SPEC_DIR.glob("*.json")):
            try:
                s = json.loads(f.read_text(encoding="utf-8"))
                if isinstance(s, dict) and ID_RE.match(str(s.get("id", ""))):
                    out.append(s)
            except Exception:
                continue
    return sorted(out, key=lambda s: (s.get("seq", 0), s["id"]))


def save_spec(spec):
    SPEC_DIR.mkdir(parents=True, exist_ok=True)
    (SPEC_DIR / f"{spec['id']}.json").write_text(json.dumps(spec, ensure_ascii=False, indent=1), encoding="utf-8")


def get_spec(iid):
    f = SPEC_DIR / f"{iid}.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None


def validate(spec, editing=False):
    errs = []
    iid = spec.get("id", "")
    if not ID_RE.match(iid):
        errs.append("Identyfikator: 2–16 znaków, małe litery/cyfry, zaczyna się literą (np. „glassbell”).")
    else:
        taken = builtin_type_ids()
        if iid in taken:
            errs.append(f"Identyfikator „{iid}” jest zajęty przez wbudowany instrument.")
        other = [s for s in list_specs() if s["id"] != iid]
        if any(plugin_name(s["id"]).lower() == plugin_name(iid).lower() for s in other):
            errs.append("Nazwa pliku wtyczki koliduje z innym instrumentem użytkownika.")
    if not str(spec.get("name", "")).strip():
        errs.append("Podaj nazwę wyświetlaną.")
    if not spec.get("ex"):
        errs.append("Włącz co najmniej jeden parametr jawny (to, co zobaczy host i generator).")
    P = {p["i"]: p for p in engine_info()["params"]}
    for i, v in list(spec.get("ex", [])) + list(spec.get("hid", [])):
        if i not in P:
            errs.append(f"Nieznany parametr #{i}.")
    ex_ids = [i for i, _ in spec.get("ex", [])]
    if len(set(ex_ids)) != len(ex_ids):
        errs.append("Parametr jawny występuje dwukrotnie.")
    if spec.get("modal") == "custom" or spec.get("modal_custom"):
        mc = spec.get("modal_custom") or []
        if not (1 <= len(mc) <= 6):
            errs.append("Własny bank modalny: 1–6 składowych.")
        elif any(float(x["ratio"]) <= 0 for x in mc):
            errs.append("Własny bank modalny: stosunki częstotliwości muszą być > 0.")
    if spec.get("group") not in GROUPS:
        errs.append("Wybierz grupę instrumentu.")
    try:
        from . import generator as G
        if spec.get("gen") not in G.GEN:
            errs.append("Wybierz wzór nut (generator).")
    except Exception:
        pass
    return errs


# ------------------------------------------------------------------ generowanie C++
def _layout(specs):
    """Zatwierdzone specyfikacje w kolejności seq + przydział banków modalnych (6, 7, …)."""
    ap = sorted([s for s in specs if s.get("status") == "approved"], key=lambda s: (s.get("seq", 0), s["id"]))
    banks, bank_of = [], {}
    for s in ap:
        if s.get("modal_custom"):
            bank_of[s["id"]] = CUSTOM_MODAL_FIRST + len(banks)
            banks.append(s)
    return ap, bank_of


def _modal_value(spec, bank_of):
    if spec.get("modal_custom"):
        return bank_of[spec["id"]]
    m = spec.get("modal", 0)
    return int(m) if isinstance(m, (int, float)) and 0 <= int(m) <= 5 else 0


def emit_type(spec, modal_value):
    ex = ",".join(f"{{{int(i)},{_f(v)}}}" for i, v in spec["ex"])
    hid = ",".join(f"{{{int(i)},{_f(v)}}}" for i, v in spec["hid"])
    esc = lambda s: str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")  # noqa: E731
    return (f"    // ---- użytkownik: {spec['id']} (seq {spec.get('seq', 0)}) — generowane przez userinst.py\n"
            f"    {{\"{PREFIX}{spec['id']}\", \"{esc(spec['name'])}\", \"{esc(spec.get('desc', ''))}\", {'true' if spec.get('oneshot') else 'false'}, {_f(spec.get('ref', 261.6256))},\n"
            f"     {{{ex}}},\n     {{{hid}}}, {'true' if spec.get('retrig') else 'false'}, false, {int(modal_value)}}},\n")


def emit_modal(spec):
    mc = list(spec["modal_custom"])[:6]
    n = len(mc)
    pad = lambda key, d: ", ".join(_f(float(x.get(key, d))) for x in mc) + (", 0" * (6 - n))  # noqa: E731
    return f"      {{{n}, {{{pad('ratio', 1)}}}, {{{pad('amp', 1)}}}, {{{pad('decay', 1)}}}}},   // {spec['id']}\n"


def write_aggregates(specs=None):
    """Zapisuje src/user/*.inc, agregaty i user_types.mk (tylko gdy treść się zmieniła — make nie przebudowuje niepotrzebnie)."""
    specs = list_specs() if specs is None else specs
    ap, bank_of = _layout(specs)
    USER_SRC.mkdir(parents=True, exist_ok=True)
    for s in ap:
        _write_if_changed(USER_SRC / f"{s['id']}.inc", emit_type(s, _modal_value(s, bank_of)))
        if s.get("modal_custom"):
            _write_if_changed(USER_SRC / f"{s['id']}.modal.inc", emit_modal(s))
    keep = {f"{s['id']}.inc" for s in ap} | {f"{s['id']}.modal.inc" for s in ap if s.get("modal_custom")}
    for f in USER_SRC.glob("*.inc"):
        if f.name not in keep:
            f.unlink()
    _write_if_changed(SRC / "ds_user_types.inc", "// generowane przez userinst.py — instrumenty użytkownika (nie edytuj ręcznie)\n"
                      + "".join(f'#include "user/{s["id"]}.inc"\n' for s in ap))
    _write_if_changed(SRC / "ds_user_modal.inc", "// generowane przez userinst.py — własne banki modalne (nie edytuj ręcznie)\n"
                      + "".join(f'#include "user/{s["id"]}.modal.inc"\n' for s in ap if s.get("modal_custom")))
    mk = ["# generowane przez userinst.py — instrumenty użytkownika dopisywane do NAMES w Makefile (kolejność = indeks typu)",
          "USER_NAMES := " + " ".join(plugin_name(s["id"]) for s in ap)]
    for s in ap:
        deps = f"src/user/{s['id']}.inc" + (" src/ds_user_modal.inc" if s.get("modal_custom") else "")
        mk.append(f"build/DS-{plugin_name(s['id'])}.clap: {deps}")
    _write_if_changed(MK, "\n".join(mk) + "\n")
    return ap, bank_of


# ------------------------------------------------------------------ kompilacja
def _run(cmd, log, cwd=None, env=None):
    log("$ " + " ".join(str(c) for c in cmd))
    p = subprocess.Popen([str(c) for c in cmd], cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in p.stdout:
        log(line.rstrip())
    return p.wait()


def build_library(log, jobs=None):
    """make: nowa wtyczka (przebudowuje się tylko ona, jej .inc jest jedynym nowym wymaganiem) + paczka DubstepKit.clap + dstypes."""
    jobs = jobs or max(1, min(8, os.cpu_count() or 2))
    ap = [s for s in list_specs() if s.get("status") == "approved"]
    targets = [f"build/DS-{plugin_name(s['id'])}.clap" for s in ap] + ["build/DubstepKit.clap", "build/dstypes"]
    return _run(["make", "-C", APP_DIR, f"-j{jobs}"] + targets, log)


def approve(spec, log):
    """Zatwierdź do biblioteki: zapis → agregaty/Makefile → kompilacja → rejestracja w aplikacji. Zwraca (ok, komunikat)."""
    errs = validate(spec)
    if errs:
        return False, "\n".join(errs)
    old = get_spec(spec["id"])
    prev_status = old.get("status") if old else None
    spec = dict(spec)
    if old and prev_status == "approved":
        spec["seq"] = old.get("seq", 1)
    else:
        spec["seq"] = max([s.get("seq", 0) for s in list_specs()] + [0]) + 1
    spec["status"] = "approved"
    save_spec(spec)
    write_aggregates()
    log(f"== Kompilacja DS-{plugin_name(spec['id'])}.clap ==")
    rc = build_library(log)
    if rc != 0:
        spec["status"] = prev_status or "draft"
        if prev_status == "approved":
            spec = old
        save_spec(spec)
        write_aggregates()
        return False, "Kompilacja nie powiodła się (szczegóły w logu). Instrument pozostaje szkicem."
    try:
        engine_info(refresh=True)
    except Exception as e:
        log(f"(uwaga) odświeżenie dstypes: {e}")
    reload_meta()
    register(spec)
    return True, f"Zatwierdzono: {spec['name']} ({spec['id']}) — wtyczka zbudowana, instrument dostępny w aplikacji."


def set_disabled(iid, disabled=True):
    """Wyłącza/włącza instrument w aplikacji. Definicja C++ zostaje (stałe indeksy typów), więc make nic nie przebudowuje."""
    s = get_spec(iid)
    if not s:
        return False
    s["disabled"] = bool(disabled)
    save_spec(s)
    return True


def reload_meta():
    """Odświeża meta-dane wtyczek w miejscu (obiekt Meta zostaje ten sam, więc referencje GUI/Live pozostają ważne)."""
    from . import core
    m = core.meta()
    m.__init__()
    return m


# ------------------------------------------------------------------ podgląd
def preview(spec, log, phrase=None):
    """Kompiluje tymczasową wtyczkę z tego szkicu (bez zmian w bibliotece), renderuje krótką frazę i zwraca ścieżkę WAV."""
    import numpy as np
    from . import core
    errs = validate(spec)
    if errs:
        raise RuntimeError("\n".join(errs))
    specs = [s for s in list_specs() if s["id"] != spec["id"]]
    probe = dict(spec); probe["status"] = "approved"; probe["seq"] = 10 ** 6
    ap, bank_of = _layout(specs + [probe])
    types_before = [s for s in ap if s["id"] != spec["id"]]
    idx = len(builtin_type_ids()) + len(types_before)            # indeks typu = wbudowane + wcześniejsze użytkownika
    if len(builtin_type_ids()) == 0:
        raise RuntimeError("Brak informacji o silniku (build/dstypes).")
    pdir = APP_DIR / "build" / "preview"
    pdir.mkdir(parents=True, exist_ok=True)
    for f in pdir.glob("*"):
        if f.is_file():
            f.unlink()
    inc_t, inc_m = pdir / "types.inc", pdir / "modal.inc"
    lines_t, lines_m = [], []
    for s in ap:
        pth = pdir / f"{s['id']}.inc"
        pth.write_text(emit_type(s, _modal_value(s, bank_of)), encoding="utf-8")
        lines_t.append(f'#include "{pth}"')
        if s.get("modal_custom"):
            mp = pdir / f"{s['id']}.modal.inc"
            mp.write_text(emit_modal(s), encoding="utf-8")
            lines_m.append(f'#include "{mp}"')
    inc_t.write_text("\n".join(lines_t) + "\n", encoding="utf-8")
    inc_m.write_text("\n".join(lines_m) + "\n", encoding="utf-8")
    out = pdir / f"DS-{plugin_name(spec['id'])}.clap"
    cxx = os.environ.get("CXX", "g++")
    cmd = [cxx, "-std=c++17", "-O2", "-fPIC", "-fvisibility=hidden", "-Wno-unused-parameter", f"-I{APP_DIR / 'clap' / 'include'}", f"-I{SRC}",
           "-shared", f"-DDS_ONLY_TYPE={idx}", f'-DDS_USER_TYPES_INC="{inc_t}"', f'-DDS_USER_MODAL_INC="{inc_m}"', str(SRC / "ds_plugin.cpp"), "-o", str(out)]
    log("== Podgląd: kompilacja tymczasowej wtyczki ==")
    if _run(cmd, log) != 0 or not out.exists():
        raise RuntimeError("Kompilacja podglądu nie powiodła się.")
    notes = phrase or default_phrase(spec)
    job = pdir / "job.txt"
    rawp = pdir / "out.f32"
    length = max(a + b for a, b, _, _ in notes) + 0.2
    job.write_text(f"sr {core.SR}\nbpm 120\nlen {length:.3f}\ntail 1.6\nplugin {out} {PREFIX}{spec['id']}\nout {rawp}\n"
                   + "".join(f"n {a:.4f} {b:.4f} {k} {v:.2f}\n" for a, b, k, v in notes), encoding="utf-8")
    rc = _run([core.meta().render, job], log)
    if rc != 0 or not rawp.exists():
        raise RuntimeError("Render podglądu nie powiódł się (dsrender).")
    x = np.fromfile(rawp, dtype=np.float32).reshape(-1, 2)
    pk = float(np.abs(x).max()) if x.size else 0.0
    if pk > 1e-6:
        x = x * (min(1.0, 0.85 / pk) if pk > 0.85 else 1.0)
    wav = pdir / "preview.wav"
    core.write_wav(wav, x)
    log(f"Podgląd gotowy ({len(x) / core.SR:.1f} s, peak {pk:.2f}).")
    return wav


def default_phrase(spec):
    """Krótka fraza testowa: perkusjonalia — uderzenia na kilku wysokościach; reszta — arpeggio + dłuższy akord-nuta."""
    if spec.get("oneshot") and not spec.get("modal") and not spec.get("modal_custom"):
        return [(i * 0.45, 0.1, k, 0.9 if i % 2 == 0 else 0.7) for i, k in enumerate([48, 55, 48, 60, 48, 55, 60, 64])]
    if spec.get("modal") or spec.get("modal_custom"):
        return [(i * 0.5, 0.3, k, 0.85) for i, k in enumerate([60, 64, 67, 72, 67, 64, 60, 55])]
    seq = [48, 55, 60, 64, 67, 60, 55, 48]
    notes = [(i * 0.55, 0.5, k, 0.9) for i, k in enumerate(seq)]
    notes.append((len(seq) * 0.55 + 0.1, 1.6, 52, 0.9))
    return notes


# ------------------------------------------------------------------ rejestracja w aplikacji
def _mod(name):
    return sys.modules.get(f"{__package__}.{name}")


def _append(lst, v, front=False):
    if v not in lst:
        (lst.insert(0, v) if front else lst.append(v))


def _rebind_tuple(mod, attr, v):
    cur = getattr(mod, attr, None)
    if isinstance(cur, tuple) and v not in cur:
        setattr(mod, attr, cur + (v,))
    elif isinstance(cur, frozenset) and v not in cur:
        setattr(mod, attr, cur | {v})
    elif isinstance(cur, set):
        cur.add(v)
    elif isinstance(cur, list):
        _append(cur, v)


def _apply_core(s):
    m = _mod("core")
    i = s["id"]
    _append(m.TYPES, i)
    m.OPTIONAL.add(i)
    m.PLUGIN_ID[i] = PREFIX + i
    _append(m.GROUPS.setdefault(s["group"], []), i)
    if s.get("melodic", True):
        m.MELODIC.add(i)
    m.DEFAULT_GAIN[i] = float(s.get("gain", 0.6))
    m.TARGET_REL[i] = float(s.get("target_rel", 0.5))


def _apply_generator(s):
    m = _mod("generator")
    i = s["id"]
    m.SOUND[i] = [tuple(x) for x in s.get("sound", [])]
    m.INST_AGG[i] = float(s.get("agg", 2.0))
    m.INST_BANDS[i] = tuple(float(x) for x in s.get("bands", [0.05, 0.2, 0.45, 0.3]))
    key = GROUP_TO_INST.get(s["group"])
    if key:
        _append(m.INST_GROUPS.setdefault(key, []), i)
    if s.get("gen") in m.GEN:
        m.GEN[i] = m.GEN[s["gen"]]
    _append(m.ORDER, i)
    if s.get("role") in ("bass", "lead", "pad"):
        m.NATIVE_ROLE[i] = s["role"]
    if float(s.get("duck", 0)) > 0:
        m.DUCK[i] = float(s["duck"])
    if s.get("sustained"):
        _rebind_tuple(m, "SUSTAINED", i)
    st = getattr(m, "STYLES", None)
    if st is not None:
        for name in s.get("styles", []):
            cfg = dict.get(st, name)                     # tylko czyste style (hybrydy składają się z nich)
            if cfg is not None:
                _append(cfg.setdefault("extras", []), i, front=bool(s.get("style_front")))
        if hasattr(st, "_hyb"):
            st._hyb.clear()                              # hybrydy zbudowane wcześniej nie znają nowego typu


def _apply_director(s):
    m = _mod("director")
    i, role = s["id"], s.get("role")
    if role == "lead":
        _rebind_tuple(m, "LEAD_T", i)
        m.LEAD_RANGE.setdefault(i, (55, 80))
        if s.get("bands", [0, 0, 0, 0])[3] >= 0.3:
            _rebind_tuple(m, "BRIGHT_LEADS", i)
    if role == "bass":
        _rebind_tuple(m, "BASS_T", i)
        m.BASS_RANGE.setdefault(i, (28, 55))
    if float(s.get("agg", 2)) <= 1.5 and role in ("lead", "pad"):
        _rebind_tuple(m, "SOFT", i)
    if float(s.get("agg", 2)) >= 4:
        _rebind_tuple(m, "HARSH", i)


def _apply_niuanse(s):
    m = _mod("niuanse")
    i, role = s["id"], s.get("role")
    if s.get("melodic", True):
        _rebind_tuple(m, "MELODIC_T", i)
    if role == "bass":
        _rebind_tuple(m, "BASS_T", i)
    elif role == "lead":
        _rebind_tuple(m, "LEAD_T", i); _rebind_tuple(m, "ARP_T", i)
    elif role == "pad":
        _rebind_tuple(m, "PAD_T", i)
    if s["group"] == "Perkusja":
        _rebind_tuple(m, "DRUM_T", i)


def _apply_arranger(s):
    m = _mod("arranger")
    i, g, role = s["id"], s["group"], s.get("role")
    if g == "Perkusja":
        m.DRUMS.add(i)
    elif role == "bass":
        m.BASS.add(i)
    elif role == "pad":
        m.PAD.add(i)
    elif role == "lead" or g in ("Synth / lead", "Akustyczne"):
        m.LEAD.add(i)


def _apply_instrument_replace(s):
    m = _mod("instrument_replace")
    i, g, role = s["id"], s["group"], s.get("role")
    pools = m.ROLE_POOLS
    if g == "Perkusja":
        _append(pools["drums"], i)
    if g == "FX":
        _append(pools["fx"], i)
    if role in ("bass", "lead", "pad"):
        _append(pools[role], i)


def _apply_era(s):
    m = _mod("era_profiles")
    for e in s.get("eras", []):
        cfg = m.ERA.get(e)
        if cfg and cfg.get("prefer") is not None:
            _append(cfg["prefer"], s["id"])
            av = cfg.get("avoid")
            if av and s["id"] in av:
                av.remove(s["id"])


def _apply_live(s):
    m = _mod("live")
    if s["group"] == "Akustyczne":
        _append(m.ACOUSTIC, s["id"])


_APPLY = {"core": _apply_core, "generator": _apply_generator, "director": _apply_director, "niuanse": _apply_niuanse,
          "arranger": _apply_arranger, "instrument_replace": _apply_instrument_replace, "era_profiles": _apply_era, "live": _apply_live}


def apply_module(name):
    """Dopisuje wszystkie zarejestrowane typy użytkownika do tabel modułu `name` (wołane na końcu modułu i przy rejestracji w locie)."""
    fn = _APPLY.get(name)
    if not fn or _mod(name) is None:
        return
    for s in list(REGISTRY.values()):
        try:
            fn(s)
        except Exception as e:                      # uszkodzona specyfikacja nie może wyłożyć aplikacji
            print(f"[userinst] {name}: {s.get('id')}: {e}", file=sys.stderr)


def register(spec):
    """Rejestracja jednego instrumentu w już załadowanych modułach aplikacji (bez restartu)."""
    if spec.get("disabled") or spec.get("status") != "approved":
        return False
    REGISTRY[spec["id"]] = spec
    for name, fn in _APPLY.items():
        if _mod(name) is not None:
            try:
                fn(spec)
            except Exception as e:
                print(f"[userinst] {name}: {spec['id']}: {e}", file=sys.stderr)
    return True


def load_all():
    """Wczytuje zatwierdzone specyfikacje z user_instruments/ (start aplikacji / „Skanuj ponownie”). Zwraca listę nowo zarejestrowanych id."""
    new = []
    for s in list_specs():
        if s.get("status") == "approved" and not s.get("disabled") and s["id"] not in REGISTRY:
            REGISTRY[s["id"]] = s
            new.append(s["id"])
    return new


def rescan():
    """Rozpoznanie typów po fakcie: nowe specyfikacje (np. skopiowane do user_instruments/) + odświeżenie meta wtyczek."""
    new = []
    for s in list_specs():
        if s.get("status") == "approved" and not s.get("disabled") and s["id"] not in REGISTRY:
            if register(s):
                new.append(s["id"])
    if new:
        reload_meta()
    return new
