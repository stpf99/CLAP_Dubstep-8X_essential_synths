"""special_styles.py — style SPECJALNE (artysta / album), nie mieszanki gatunków.

Hybryda „House 50% + Acid Techno 30% + …" tylko uśrednia gotowe wzory gatunków. Styl specjalny ma WŁASNE:
  • wzory stopy / werbla / ghost-nut / hatu, swing, tryb suba, progresje, skale, szablon formy,
  • własne wzory basu (rejestrowane w WOB pod kluczem „sp:<nazwa>"),
  • paletę instrumentów (core / extras / głosy),
  • nastawy brzmień per instrument (SOUND_STYLE — te same okna parametrów, co w stylach wbudowanych, ale wąskie i charakterystyczne),
  • epokę, motyw mowy, klasę ostrości, ducking, scenę.

Style rejestrowane są jako czyste (StyleDict), więc działają wszędzie jak „Techno": w presetach, Live, remiksie, a także jako składnik hybryd.
NIE trafiają do ST.ORDER (pole szachowe i losowanie Live zostają jak były) — w liście stylów Generatora są na końcu.
Wyłączenie: DS_NO_SPECIAL=1.

Zapis wzorów (tekst): „krok+znacznik+długość", np. "0r2 3r1 6o1" = (0,'r',2) (3,'r',1) (6,'o',1); znaczniki jak w generator.tok():
r=pryma o=oktawa f=kwinta t=tercja b=septyma p=tercja+oktawa u=nona.
Zapis brzmień: "Parametr: lo hi; Parametr = a b" (zakres losowania / wybór z listy), jednostki jak w silniku (ms, Hz, st…).
"""
from __future__ import annotations

import copy
import os
import re

from . import styles as ST

T_CLUB, T_TRANCE, T_AMB, T_MIN, T_FUSION, T_ROMANTIC, T_EXP, T_DNB = ST.T_CLUB, ST.T_TRANCE, ST.T_AMB, ST.T_MIN, ST.T_FUSION, ST.T_ROMANTIC, ST.T_EXP, ST.T_DNB
T_LONGBUILD = [("intro", 16), ("build", 16), ("drop", 32), ("break", 8), ("build", 16), ("drop", 32), ("drop", 16), ("outro", 8)]
T_PROG = [("intro", 32), ("build", 16), ("drop", 32), ("break", 32), ("build", 16), ("drop", 32), ("outro", 32)]
T_SONG = [("intro", 16), ("drop", 32), ("break", 8), ("drop", 32), ("outro", 8)]
NO_KICK = [[0]]

_PAT = re.compile(r"^(\d{1,2})([rofbtpu])(\d{1,2})$")


def P(txt: str) -> list:
    """„0r2 3r1 6o1" -> [(0,'r',2), (3,'r',1), (6,'o',1)]; błędny zapis = ValueError (wyłapie to test)."""
    out = []
    for tk in txt.split():
        m = _PAT.match(tk)
        if not m:
            raise ValueError(f"zły token wzoru: {tk!r}")
        s, t, ln = int(m.group(1)), m.group(2), int(m.group(3))
        if not (0 <= s <= 15 and 1 <= ln <= 16):
            raise ValueError(f"krok/długość poza zakresem: {tk!r}")
        out.append((s, t, ln))
    return out


def SND(txt: str) -> list:
    """„Decay: 170 250; Drive: .3 .55; Waveform = 2 3" -> [("Decay",'r',170,250), ("Drive",'r',.3,.55), ("Waveform",'c',[2,3])]."""
    out = []
    for cl in filter(None, (c.strip() for c in txt.split(";"))):
        if ":" in cl:
            name, rest = cl.split(":", 1); lo, hi = rest.split()
            out.append((name.strip(), "r", float(lo), float(hi)))
        elif "=" in cl:
            name, rest = cl.split("=", 1)
            out.append((name.strip(), "c", [int(x) for x in rest.split()]))
        else:
            raise ValueError(f"zły zapis brzmienia: {cl!r}")
    return out


S = lambda s: s.split()

# ======================================================================================================================
# SPECIAL[nazwa] = dict(
#   base      czysty styl, z którego kopiowana jest konfiguracja wyjściowa (reszta poniżej nadpisuje; wartość None = usuń klucz)
#   era / theme / cls / color / duck / profile      tabele per styl (epoka, motyw Speak, klasa ostrości 0..5, kolor, ducking, profil autokorekty)
#   bpm scale energy density swing speak note       dane presetu (build_pack.py)
#   inst      DOKŁADNA lista instrumentów presetu (kolejność = priorytet) — z niej powstaje też core/extras stylu
#   bass / growl   własne wzory basu; sound   nastawy brzmień per typ;   pozostałe klucze = pola cfg stylu (kick, snare, hat, …)
# )
# ======================================================================================================================
SPECIAL = {
    # ------------------------------------------------------------------------------------------------ DAFT PUNK
    "Daft Punk - Homework (1997)": dict(
        base="House", era="digital_90s", theme="Hype", cls=3.0, color="#f97316", duck=0.80, profile="aggressive",
        bpm=124, scale="minor", energy=0.78, density=0.58, swing=0.05,
        inst=S("kick clap hat openhat sub wobble acid stab pad riser zap vox"),
        note="Surowy house/acid z początku French touch: 4/4, klaps na 2 i 4, otwarty hat na offbeat, zapętlona linia acid ze ślizgami i stabowe pętle.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.02, sub_mode="offbeat", lead="rare", wob_div=[9, 10], chord_len=2,
        comp=[[2, 6, 10, 14], [3, 7, 11, 15], [0, 3, 6, 10]], voices=dict(stab=3), progs=[[0], [0, 0, 3, 0], [0, 0, 0, 5]], scales=["minor", "dorian"], template=T_CLUB,
        bass=["0r2 3r1 5r1 6o1 8r2 11f1 13r1 14b1", "0r1 2r1 3o1 5r1 6b1 8r2 10f1 11r1 13o1 14r1", "0r2 3r1 4o1 6r1 8b2 11r1 12f1 14o1"],
        sound=dict(wobble="Cutoff: 500 1600; Resonance: .6 .85; Drive: .35 .6; Glide: 40 100", acid="Cutoff: 450 1500; Resonance: .65 .88; Glide: 50 110; Filter Env Amt: 1.5 3.5",
                   kick="Decay: 170 250; Drive: .3 .55", hat="Decay: 25 60; Noise: .5 .8", stab="Decay: 120 260; Drive: .25 .5")),
    "Daft Punk - Discovery (2001)": dict(
        base="House", era="digital_90s", theme="Hype", cls=2.5, color="#fbbf24", duck=0.90, profile="soft",
        bpm=123, scale="dorian", energy=0.72, density=0.68, swing=0.08,
        inst=S("kick clap hat openhat sub wobble stab epiano pad supersaw pluck vox"),
        note="Filtrowany disco-house z mocnym pompowaniem (sidechain): swingowany groove, funkujący bas, akordy ze stabów/epiano, arpeggio i supersaw jak w syntezatorowych solówkach.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.06, sub_mode="funk", lead="melodic", chord_len=2,
        arp=dict(step=2, pattern="updown", prob=0.85), comp=[[2, 6, 10, 14], [0, 3, 6, 10, 14], [3, 7, 11, 15]], voices=dict(stab=3, pad=2, supersaw=2),
        progs=[[1, 4, 0, 5], [0, 3, 0, 4], [0, 5, 3, 4]], scales=["dorian", "minor"], template=T_FUSION,
        bass=["0r2 3r1 6o1 8r2 10f1 12r2 15b1", "0r1 2r1 4o1 7r1 8f2 11t1 12r2 14b2", "2r2 6r2 8f2 12r2"],
        sound=dict(stab="Cutoff: 1300 3200; Drive: .2 .45; Decay: 140 280", supersaw="Unison Detune: 18 38; Cutoff: 3500 9000; Attack: 5 25",
                   pad="Attack: 100 400; Cutoff: 1500 3500", kick="Decay: 190 290; Drive: .15 .35", sub="Glide: 10 35; Drive: .1 .3", epiano="Decay: 400 900")),
    "Daft Punk - Human After All (2005)": dict(
        base="Raw Synthesis", era="rave_00s", theme="Dark", cls=3.5, color="#94a3b8", duck=0.55, profile="aggressive",
        bpm=112, scale="minor", energy=0.80, density=0.50, swing=0.0, speak="Systems online. Repeat. Overdrive. Again.",
        inst=S("kick snare clap hat sub wobble reese screech hoover glitch zap boom speak crash"),
        note="Zgrzytliwy, powtarzalny robot-rock: jeden riff w pętli, twardy backbeat, przesterowany lead i mowa syntetyczna (DS Speak, dialekt Robot).",
        fourfloor=False, kick=[[0, 8], [0, 6, 8], [0, 8, 10]], snare=[4, 12], ghost=[], hat="8", swing8=0.0, sub_mode="pulse8", lead="accent", wob_div=[10, 11], chord_len=4,
        progs=[[0], [0, 0, 5, 0]], scales=["minor", "phrygian"], mutate=None, template=[("intro", 16), ("drop", 32), ("break", 8), ("drop", 32), ("outro", 8)],
        bass=["0r2 2r1 3r1 4r2 8r2 10f1 11r1 12b2", "0r2 2r1 3r1 4r2 8r2 10r1 11r1 12o2"],
        sound=dict(wobble="Drive: .7 1.0; Resonance: .35 .6; Cutoff: 700 2500", screech="Drive: .6 .95; FM Amount: .3 .6", hoover="Drive: .6 .95",
                   snare="Decay: 90 170; Drive: .4 .7; Noise: .6 .9", kick="Drive: .5 .8; Decay: 120 200", speak="Dialect = 4")),      # tylko dialekt Robot: Intonation / Letter Pitch Range / Formant Shift są losowo nadpisywane przez efekt theremin na głosie (generator.py)
    "Daft Punk - Alive 2007": dict(
        base="Techno", era="rave_00s", theme="Hype", cls=4.0, color="#e5e7eb", duck=0.70, profile="aggressive",
        bpm=128, scale="minor", energy=0.92, density=0.72, swing=0.02,
        inst=S("kick snare clap hat openhat sub wobble acid stab hoover screech riser boom zap"),
        note="Koncertowa energia: techno/house w twardszym wydaniu, staby i hoover jako motywy, bardzo długie narastania przed dropami.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.0, sub_mode="offbeat", lead="accent", wob_div=[10, 11], chord_len=2,
        comp=[[2, 6, 10, 14], [3, 10], [0, 6, 12]], voices=dict(stab=3), progs=[[0], [0, 0, 3, 0], [0, 5, 3, 4]], scales=["minor", "phrygian"], template=T_LONGBUILD,
        bass=["2r2 6r2 10r2 14r2", "2r1 3r1 6r2 10r1 11r1 14r2", "2r2 6r2 10r1 11o1 14f2"],
        sound=dict(hoover="Drive: .5 .8; Release: 120 300", stab="Drive: .4 .7; Decay: 100 220", riser="Ramp Time: 4000 12000", kick="Drive: .4 .7; Decay: 150 230",
                   screech="Drive: .4 .75; Cutoff: 3000 8000")),
    "Daft Punk - Tron Legacy (2010)": dict(
        base="Berlin School", era="modern_10s", theme="Countdown", cls=1.5, color="#22d3ee", duck=0.30, profile="soft",
        bpm=100, scale="minor", energy=0.62, density=0.55, swing=0.0,
        inst=S("kick tom hat sub wobble pluck pad strings cello brass choir piano bell drone riser"),
        note="Kinowy układ: smyczki, blachy, chór i fortepian na pulsującym sekwencerze (ósemki) z rzadką, tomową perkusją.",
        fourfloor=False, kick=[[0, 8], [0, 6, 8]], snare=[], hat="offbeat", swing8=0.0, sub_mode="pulse8", lead="melodic", melody="romantic",
        arp=dict(step=1, pattern="up", prob=1.0, phase=True), pad_mode="drop", voices=dict(pluck=2, pad=2, strings=3, brass=2), chord_len=2,
        progs=[[0, 5, 2, 6], [0, 5, 3, 4], [0, 3, 5, 6]], scales=["minor", "harmonic minor"], template=[("intro", 16), ("drop", 24), ("break", 12), ("build", 8), ("drop", 32), ("outro", 12)],
        bass=["0r2 2r2 4o2 6r2 8f2 10r2 12o2 14t2", "0r2 2r2 4r2 6o2 8r2 10r2 12f2 14o2"],
        sound=dict(strings="Attack: 150 500; Release: 700 1800; Cutoff: 3500 9000", brass="Attack: 40 120; Cutoff: 2500 6000", choir="Attack: 300 900; Release: 800 2000",
                   pad="Attack: 700 1800; Release: 1500 3200", tom="Decay: 350 650", kick="Decay: 120 220; Drive: .1 .3", pluck="Decay: 90 200; Cutoff: 1500 3500")),
    "Daft Punk - Random Access Memories (2013)": dict(
        base="Jazz Rock", era="modern_10s", theme="Hype", cls=1.5, color="#facc15", duck=0.50, profile="soft",
        bpm=116, scale="dorian", energy=0.60, density=0.70, swing=0.03, speak="Memory. Groove. Tonight. Again.",
        inst=S("kick snare clap hat openhat shaker conga sub epiano piano strings brass stab speak choir vox"),
        note="Żywy disco-funk: groove 4/4 z perkusjonaliami i ghost-notes, funkujący bas w stylu Jamersona, epiano, smyczki i blachy, vocoder (DS Speak).",
        fourfloor=True, kick=[[0, 4, 8, 12], [0, 4, 8, 10, 12]], snare=[4, 12], ghost=[(3, 40), (7, 44), (11, 40), (15, 48)], hat="16", swing8=0.07, sub_mode="funk",
        lead="melodic", melody="jazz", comp=[[0, 3, 6, 10], [2, 6, 10, 14], [3, 7, 14]], voices=dict(epiano=2, stab=2, strings=2), chord_len=2,
        progs=[[1, 4, 0, 5], [0, 3, 1, 4], [2, 5, 1, 4], [0, 6, 5, 6]], scales=["dorian", "minor", "mixolydian"], template=T_FUSION,
        bass=["0r1 3r1 6o1 8r1 10f1 11r1 12o2 15b1", "0r2 3o1 5r1 8t1 10r1 13f1 14b2", "0r1 2r1 4o1 7f1 8r2 11t1 12r1 14o1"],
        sound=dict(kick="Decay: 120 220; Drive: .05 .2", snare="Decay: 90 170; Drive: 0 .15", epiano="Decay: 400 900", strings="Attack: 120 380; Release: 500 1200",
                   brass="Attack: 25 70; Cutoff: 2200 5000", sub="Drive: .05 .25; Glide: 0 25; Cutoff: 500 1100", conga="Decay: 90 220")),
    # ------------------------------------------------------------------------------------------------ KRAFTWERK
    "Kraftwerk - Autobahn (1974)": dict(
        base="Berlin School", era="minimal_70s", theme="Countdown", cls=0.8, color="#38bdf8", duck=0.25, profile="minimal",
        bpm=104, scale="major", energy=0.50, density=0.55, swing=0.0,
        inst=S("kick hat wobble pluck pad flute"),
        note="Jazda bez pośpiechu: sekwencerowy bas, arpeggia, pad i fletowa melodia; miękka, minimalna perkusja (era 70s: 6 ścieżek).",
        fourfloor=False, kick=[[0, 8]], snare=[], hat="offbeat", swing8=0.0, sub_mode="pulse8", lead="melodic", melody="romantic",
        arp=dict(step=2, pattern="updown", prob=0.9), pad_mode="drop", chord_len=4, progs=[[0, 5], [0, 3, 0, 4], [0, 4, 5, 3]], scales=["major", "dorian"], template=T_AMB,
        bass=["0r2 2r2 4f2 6r2 8o2 10f2 12r2 14f2", "0r2 2f2 4r2 6o2 8r2 10f2 12o2 14f2"],
        sound=dict(pad="Attack: 500 1400; Release: 900 2200", flute="Attack: 40 120; Release: 150 450", pluck="Decay: 120 260; Cutoff: 1200 3000", hat="Decay: 30 70; Noise: .4 .7")),
    "Kraftwerk - Radio-Activity (1975)": dict(
        base="Space Electronica", era="minimal_70s", theme="Countdown", cls=0.3, color="#a5b4fc", duck=0.25, profile="minimal",
        bpm=116, scale="minor", energy=0.45, density=0.45, swing=0.0,
        inst=S("kick hat sub pluck drone bell"),
        note="Zimny, oszczędny nastrój: bas na ósemkach, dzwonki i dron nad sztywnym pulsem.",
        fourfloor=False, kick=[[0, 8]], snare=[], hat="offbeat", swing8=0.0, sub_mode="pulse8", lead="melodic", melody="space",
        arp=dict(step=2, pattern="up", prob=0.7), pad_mode="drop", chord_len=4, progs=[[0, 5], [0, 3], [0, 6, 5, 6]], scales=["minor"], template=T_AMB,
        bass=["0r2 2r2 4r2 6r2 8r2 10r2 12o2 14r2", "0r2 2r2 4r2 6f2 8r2 10r2 12r2 14o2"],
        sound=dict(bell="Ring Time: 1200 2600; Strike Brightness: .5 .8", drone="Attack: 1200 2800; Release: 2000 4000", hat="Decay: 30 70; Noise: .5 .8", kick="Decay: 180 280; Drive: 0 .1")),
    "Kraftwerk - Trans-Europe Express (1977)": dict(
        base="Berlin School", era="minimal_70s", theme="Countdown", cls=1.2, color="#7dd3fc", duck=0.40, profile="minimal",
        bpm=112, scale="minor", energy=0.62, density=0.55, swing=0.0,
        inst=S("kick snare hat sub pluck choir"),
        note="Równy „kołowy” puls pociągu: szesnastkowy bas-chug, sekwencerowe arpeggio i chórek w miejscu vocodera.",
        fourfloor=False, kick=[[0, 8], [0, 4, 8, 12]], snare=[4, 12], hat="8", swing8=0.0, sub_mode="pulse8", lead="melodic",
        arp=dict(step=1, pattern="up", prob=1.0, phase=True), pad_mode="drop", chord_len=4, progs=[[0, 5], [0], [0, 3]], scales=["minor"], template=T_AMB,
        bass=["0r1 1r1 2r1 3o1 4r1 5r1 6r1 7o1 8r1 9r1 10r1 11o1 12r1 13r1 14r1 15o1", "0r1 1r1 2r1 3r1 4r1 5r1 6r1 7f1 8r1 9r1 10r1 11r1 12r1 13r1 14r1 15o1"],
        sound=dict(choir="Attack: 200 500; Release: 500 1200; Formant Mix: .5 .9", pluck="Decay: 80 180; Cutoff: 1500 3500", snare="Decay: 90 160", hat="Decay: 20 50", kick="Decay: 160 240")),
    "Kraftwerk - The Man-Machine (1978)": dict(
        base="Raw Synthesis", era="minimal_70s", theme="Countdown", cls=1.2, color="#f87171", duck=0.40, profile="minimal",
        bpm=108, scale="minor", energy=0.62, density=0.55, swing=0.0,
        inst=S("kick snare hat sub pluck organ"),
        note="Czysty, mechaniczny groove: prosty beat, powtarzalne frazy na pluck i organach.",
        fourfloor=False, kick=[[0, 8]], snare=[12], ghost=[], hat="8", swing8=0.0, sub_mode="pulse8", lead="melodic", melody="classic",
        arp=dict(step=2, pattern="up", prob=1.0, phase=True), pad_mode="drop", chord_len=4, progs=[[0, 5], [0, 3, 5, 4]], scales=["minor"], mutate=None, template=T_MIN,
        bass=["0r2 2r2 4r2 6r2 8o2 10r2 12r2 14f2", "0r2 2r2 4f2 6r2 8o2 10r2 12f2 14r2"],
        sound=dict(organ="Attack: 5 30; Cutoff: 2500 5500; Drive: 0 .1", pluck="Decay: 100 220", kick="Drive: 0 .1; Decay: 160 240", snare="Decay: 90 150")),
    "Kraftwerk - Computer World (1981)": dict(
        base="Electro", era="analog_80s", theme="Hype", cls=2.0, color="#34d399", duck=0.50, profile="minimal",
        bpm=118, scale="minor", energy=0.66, density=0.60, swing=0.02,
        inst=S("kick snare clap hat bass808 pluck pad bell marimba"),
        note="Elektro-pop z wczesnych lat 80.: perkusja w stylu 808, syntetyczny bas, „zabawkowe” dzwonki i marimba.",
        fourfloor=False, kick=[[0, 6, 10], [0, 3, 10], [0, 10]], snare=[4, 12], ghost=[(7, 36), (15, 44)], hat="16", swing8=0.0, sub_mode="funk", lead="rare", melody="classic",
        progs=[[0, 0, 5, 0], [0, 3, 0, 6]], scales=["minor"], template=T_SONG,
        bass=["0r2 3r1 7r1 8o2 11r1 14f1", "0r1 2r1 6r1 8r2 10o1 13r1", "0r1 3r1 6o1 8r1 11f1 14r1"],
        sound=dict(bass808="Decay: 400 900; Drive: .1 .3", kick="Decay: 140 230; Drive: 0 .15", snare="Decay: 100 180", hat="Decay: 20 45", marimba="Ring Time: 400 1200", bell="Ring Time: 600 1600")),
    "Kraftwerk - Electric Cafe (1986)": dict(
        base="Electro", era="analog_80s", theme="Hype", cls=2.5, color="#2dd4bf", duck=0.60, profile="soft",
        bpm=120, scale="minor", energy=0.72, density=0.62, swing=0.03,
        inst=S("kick snare clap hat openhat bass808 stab pluck vox"),
        note="Techno-pop: tanecznie prosty beat 4/4, cyfrowa perkusja z długim werblem, stab i syntetyczny „głos” (vox).",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], ghost=[], hat="offbeat", swing8=0.03, sub_mode="offbeat", lead="rare", voices=dict(stab=2),
        progs=[[0, 5, 3, 4], [0, 3, 0, 4]], scales=["minor", "dorian"], template=T_SONG,
        bass=["2r2 6r2 10r2 14f2", "2r1 3o1 6r2 10r1 11o1 14r2"],
        sound=dict(snare="Decay: 100 170; Drive: .2 .4", stab="Decay: 120 260; Drive: .1 .3; Cutoff: 2000 5000", bass808="Decay: 250 600", kick="Decay: 150 240")),
    # ------------------------------------------------------------------------------------------------ VITALIC
    "Vitalic - OK Cowboy (2005)": dict(
        base="Acid Techno", era="rave_00s", theme="Dark", cls=4.0, color="#a3e635", duck=0.70, profile="aggressive",
        bpm=130, scale="minor", energy=0.86, density=0.70, swing=0.03,
        inst=S("kick snare clap hat openhat sub wobble acid screech supersaw hoover pluck riser zap"),
        note="Agresywny electro/acid: piła, hoover, arpeggia i filtrowane lead'y na twardym 4/4.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="16", sub_mode="offbeat", lead="accent", wob_div=[10, 11], voices=dict(supersaw=2),
        arp=dict(step=1, pattern="trance", prob=0.75), progs=[[0], [0, 0, 5, 0], [0, 0, 0, 6]], scales=["minor", "phrygian"], template=T_LONGBUILD,
        bass=["0r1 1r1 3o1 4r1 6b1 7r1 8r1 10f1 11o1 13r1 14b1", "0r1 2r1 3r1 5o1 6r1 8r1 9r1 11o1 12f1 14r1"],
        sound=dict(wobble="Drive: .6 .9; Resonance: .5 .8; Cutoff: 500 1800", screech="Cutoff: 3500 9000; Drive: .5 .85; FM Amount: .35 .7", hoover="Drive: .6 .9",
                   kick="Drive: .4 .7; Decay: 130 210", supersaw="Unison Detune: 30 60")),
    "Vitalic - Flashmob (2009)": dict(
        base="Trance", era="modern_10s", theme="Hype", cls=3.0, color="#c084fc", duck=0.65, profile="aggressive",
        bpm=128, scale="minor", energy=0.78, density=0.68, swing=0.0,
        inst=S("kick snare clap hat openhat sub wobble supersaw pad choir pluck strings bell riser boom stab"),
        note="Melodyjny, filmowy electro-trance: szerokie pady, chór i smyczki, bramkowane supersaw i długie narastania.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", sub_mode="offbeat", lead="melodic", voices=dict(supersaw=3, pad=2, strings=2),
        arp=dict(step=2, pattern="trance", prob=0.9), gate=[0, 2, 3, 5, 6, 8, 10, 11, 13, 14], progs=[[0, 5, 2, 6], [0, 2, 5, 6], [0, 3, 5, 6]], scales=["minor"], template=T_TRANCE,
        bass=["2r2 6r2 10r2 14r2", "2r1 3r1 6r1 7r1 10r1 11r1 14r1 15r1"],
        sound=dict(supersaw="Attack: 8 30; Release: 300 900; Cutoff: 6000 12000; Unison Detune: 25 45", choir="Attack: 200 600; Release: 600 1500",
                   strings="Attack: 120 380", riser="Ramp Time: 6000 14000", kick="Decay: 170 270")),
    "Vitalic - Voyager (2011)": dict(
        base="House", era="modern_10s", theme="Hype", cls=2.5, color="#fb7185", duck=0.75, profile="soft",
        bpm=124, scale="minor", energy=0.70, density=0.64, swing=0.05,
        inst=S("kick clap hat openhat shaker sub wobble stab pluck pad supersaw vox epiano riser strings bell"),
        note="Syntezatorowy disco-electro: groove 4/4 z shakerem, offbeatowy bas, melodyjne arpeggia i warstwy supersaw.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.04, sub_mode="offbeat", lead="rare", voices=dict(stab=2, pad=2, supersaw=2),
        arp=dict(step=2, pattern="updown", prob=0.9), progs=[[0, 5, 3, 4], [0, 3, 5, 4], [1, 4, 0, 5]], scales=["minor"], template=T_CLUB,
        bass=["2r2 6r2 10r2 14r2", "2r1 3o1 6r1 7o1 10r1 11o1 14r1 15o1"],
        sound=dict(pluck="Decay: 120 260; Cutoff: 1800 4500", supersaw="Cutoff: 4000 9500; Unison Detune: 15 35", kick="Decay: 190 290; Drive: .1 .3", epiano="Decay: 400 900")),
    "Vitalic - Rave Age (2017)": dict(
        base="Hard Techno", era="rave_00s", theme="Dark", cls=4.5, color="#ef4444", duck=0.75, profile="aggressive",
        bpm=134, scale="phrygian", energy=0.93, density=0.75, swing=0.0,
        inst=S("kick snare clap hat openhat sub wobble reese acid hoover screech stab riser zap"),
        note="Rave'owa ściana: hoover i stab na szybkim, twardym 4/4, frygijska skala.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="16", sub_mode="roll", lead="accent", progs=[[0], [0, 0, 1, 0], [0, 0, 5, 6]], scales=["phrygian", "minor"], template=T_LONGBUILD,
        bass=["0r2 3r1 4r2 7r1 8r2 10f1 11r1 12b2 15r1", "2r1 3r1 6b1 7r1 10r1 11o1 14b1 15r1"],
        sound=dict(hoover="Drive: .6 .95; Release: 100 260", kick="Drive: .6 .9; Decay: 100 170", reese="Drive: .5 .8", screech="Drive: .5 .85; Cutoff: 3500 9000")),
    # ------------------------------------------------------------------------------------------------ INNI
    "Justice - Cross (2007)": dict(
        base="Electro", era="rave_00s", theme="Hype", cls=3.5, color="#f43f5e", duck=0.85, profile="aggressive",
        bpm=120, scale="minor", energy=0.86, density=0.70, swing=0.04,
        inst=S("kick snare clap hat openhat sub wobble fmbass hoover stab organ choir brass riser"),
        note="Przesterowany disco-electro: ciężki, zniszczony bas FM, organy, chóralne stabu i blachy, mocny sidechain.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], ghost=[], hat="offbeat", swing8=0.04, sub_mode="funk", lead="accent", voices=dict(stab=2),
        progs=[[0, 3, 0, 4], [0, 6, 5, 6], [1, 4, 0, 5]], scales=["minor", "dorian"], template=T_CLUB,
        bass=["0r1 3r1 6o1 8r1 10f1 12r2 15b1", "0r2 2r1 3o1 6r1 8r2 10b1 12r2"],
        sound=dict(fmbass="Drive: .6 .95; FM Amount: .35 .7", kick="Drive: .6 .9; Decay: 130 210", snare="Drive: .5 .8; Decay: 100 180", organ="Drive: .3 .6", brass="Drive: .3 .6; Attack: 20 60")),
    "Justice - Audio Video Disco (2011)": dict(
        base="Jazz Rock", era="modern_10s", theme="Hype", cls=2.5, color="#fb923c", duck=0.70, profile="soft",
        bpm=120, scale="dorian", energy=0.75, density=0.65, swing=0.03,
        inst=S("kick snare clap hat openhat sub fmbass supersaw organ strings choir pluck brass stab riser boom"),
        note="Bardziej melodyjna, „rockowa” strona disco: organy, smyczki, harmonizowane arpeggia i funkujący bas.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], ghost=[(7, 40), (15, 48)], hat="offbeat", swing8=0.04, sub_mode="funk", lead="melodic", melody="classic",
        arp=dict(step=2, pattern="updown", prob=0.9), voices=dict(supersaw=2, strings=2, organ=1), progs=[[0, 5, 2, 6], [0, 3, 5, 4], [0, 6, 5, 6]], scales=["dorian", "minor"], template=T_FUSION,
        bass=["0r2 3r1 6o1 8r2 10f1 12r2 14o1", "0r1 2r1 4o1 7r1 8f2 11t1 12r2"],
        sound=dict(organ="Cutoff: 2500 6000; Attack: 5 25", strings="Attack: 100 300", supersaw="Unison Detune: 15 30; Cutoff: 4500 9000", brass="Attack: 25 70; Cutoff: 2200 5500", kick="Decay: 140 230; Drive: .15 .35")),
    "Jean-Michel Jarre - Oxygene (1976)": dict(
        base="Space Electronica", era="minimal_70s", theme="Countdown", cls=0.2, color="#818cf8", duck=0.20, profile="ambient",
        bpm=110, scale="dorian", energy=0.42, density=0.45, swing=0.0,
        inst=S("kick hat sub pluck pad theremin"),
        note="Kosmiczne pady, bulgoczące szesnastkowe sekwencje i glissandujący lead (theremin) nad miękkim pulsem.",
        fourfloor=False, kick=[[0, 8]], snare=[], hat="offbeat", swing8=0.0, sub_mode="hold", lead="melodic", melody="space",
        arp=dict(step=1, pattern="up", prob=1.0, phase=True), pad_mode="drop", voices=dict(pluck=2, pad=2), chord_len=4,
        progs=[[0, 5, 3, 4], [0, 3], [0, 6, 5, 6]], scales=["dorian", "lydian", "minor"], template=T_AMB,
        bass=["0r1 1f1 2r1 3o1 4r1 5f1 6r1 7o1 8r1 9f1 10r1 11o1 12r1 13f1 14r1 15o1", "0r1 1r1 2f1 3r1 4o1 5r1 6f1 7r1 8r1 9r1 10f1 11r1 12o1 13r1 14f1 15r1"],
        sound=dict(pluck="Decay: 60 140; Cutoff: 1500 4000; Filter Env Amt: 1.5 3", pad="Attack: 1500 3000; Release: 2000 4000; Cutoff: 1500 3500",
                   theremin="Glide: 100 300; LFO > Pitch: .2 .5", kick="Decay: 250 400; Drive: 0 .12", hat="Decay: 40 90; Noise: .15 .35")),
    "Jean-Michel Jarre - Equinoxe (1978)": dict(
        base="Berlin School", era="minimal_70s", theme="Countdown", cls=1.0, color="#60a5fa", duck=0.35, profile="minimal",
        bpm=122, scale="dorian", energy=0.58, density=0.55, swing=0.0,
        inst=S("kick snare hat sub pluck pad"),
        note="Bardziej rytmiczna odsłona: wyraźna perkusja, szybkie sekwencje i pad.",
        fourfloor=False, kick=[[0, 8], [0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.0, sub_mode="pulse8", lead="melodic",
        arp=dict(step=1, pattern="updown", prob=0.95), pad_mode="drop", chord_len=4, progs=[[0, 5], [0, 3, 0, 4]], scales=["dorian"], template=T_AMB,
        bass=["0r2 2r2 4f2 6r2 8o2 10f2 12r2 14t2", "0r2 2f2 4o2 6f2 8r2 10f2 12o2 14r2"],
        sound=dict(pluck="Decay: 70 160; Cutoff: 1800 4500", pad="Attack: 800 1800", snare="Decay: 80 150", kick="Decay: 150 240")),
    "Tangerine Dream - Phaedra (1974)": dict(
        base="Berlin School", era="minimal_70s", theme="Countdown", cls=0.3, color="#0ea5e9", duck=0.10, profile="ambient",
        bpm=120, scale="minor", energy=0.45, density=0.55, swing=0.0,
        inst=S("sub wobble pluck pad drone choir"),
        note="Szkoła berlińska bez perkusji: sekwencery, pady, dron i chór.",
        core=S("sub wobble pluck pad drone choir"), fourfloor=False, kick=NO_KICK, snare=[], hat="none", swing8=0.0, sub_mode="pulse8", lead="melodic", melody="space",
        arp=dict(step=1, pattern="up", prob=1.0, phase=True), pad_mode="drop", voices=dict(pluck=2, pad=3), chord_len=4,
        progs=[[0, 5], [0, 0, 3, 3], [0, 5, 3, 4]], scales=["minor", "phrygian"], template=T_AMB,
        bass=["0r2 2r2 4o2 6r2 8f2 10r2 12o2 14t2", "0r2 2f2 4r2 6o2 8r2 10f2 12r2 14o2"],
        sound=dict(pluck="Decay: 80 200; Cutoff: 1200 3500; Filter Env Amt: 1.5 3.5", pad="Attack: 1500 3000; Release: 2500 4500", drone="Attack: 1500 3500", choir="Attack: 900 2200; Release: 1500 3500",
                   sub="Glide: 40 120")),
    "Giorgio Moroder - Euro Disco (1977)": dict(
        base="House", era="analog_80s", theme="Hype", cls=2.5, color="#e879f9", duck=0.70, profile="soft",
        bpm=126, scale="minor", energy=0.72, density=0.62, swing=0.0,
        inst=S("kick clap hat openhat sub wobble pluck pad stab"),
        note="Euro-disco: 4/4, pulsujący sekwencerowy bas na ósemkach z przeskokami oktaw, arpeggio i pady.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="16", swing8=0.0, sub_mode="pulse8", lead="rare", voices=dict(pad=2, stab=2),
        arp=dict(step=1, pattern="updown", prob=0.9), progs=[[0], [0, 5], [0, 0, 3, 4]], scales=["minor"], template=T_CLUB,
        bass=["0r2 2o2 4r2 6o2 8r2 10o2 12r2 14o2", "0r1 1r1 2o1 3r1 4r1 5r1 6o1 7r1 8r1 9r1 10o1 11r1 12r1 13r1 14o1 15r1"],
        sound=dict(wobble="Resonance: .3 .5; Cutoff: 900 2200; Waveform = 2 3", sub="Glide: 0 10", clap="Noise Decay: 150 250", hat="Decay: 25 70", pluck="Decay: 80 180")),
    "Depeche Mode - Violator (1990)": dict(
        base="Electro", era="digital_90s", theme="Dark", cls=2.0, color="#9ca3af", duck=0.50, profile="soft",
        bpm=113, scale="minor", energy=0.60, density=0.55, swing=0.02,
        inst=S("kick snare clap hat rim sub pluck pad stab piano bell organ"),
        note="Mroczny synth-pop: elektroniczna perkusja z cichymi ghost-notami, sekwencerowy bas, fortepian, dzwonki i organy.",
        fourfloor=False, kick=[[0, 6, 8], [0, 8], [0, 6, 10]], snare=[4, 12], ghost=[(7, 30), (15, 36)], hat="8", swing8=0.0, sub_mode="pulse8", lead="melodic", melody="classic",
        progs=[[0, 5, 3, 4], [0, 3, 5, 4], [0, 6, 5, 6]], scales=["minor"], chord_len=2, template=T_SONG,
        bass=["0r2 2r2 4r2 6o2 8r2 10r2 12r2 14f2", "0r2 3r1 4r2 7r1 8r2 11r1 12r2 15r1"],
        sound=dict(piano="Decay: 500 1100", bell="Ring Time: 800 2000", sub="Drive: .1 .3", snare="Decay: 100 180; Drive: .1 .3", organ="Attack: 10 40; Cutoff: 2000 4500")),
    "The Chemical Brothers - Big Beat (1997)": dict(
        base="Electro", era="digital_90s", theme="Hype", cls=3.5, color="#f59e0b", duck=0.55, profile="aggressive",
        bpm=120, scale="minor", energy=0.86, density=0.72, swing=0.03,
        inst=S("kick snare clap hat openhat conga cowbell sub wobble acid screech zap"),
        note="Big beat: łamany beat z ghost-snare'ami, perkusjonalia, squelchujący acid i sirenowe zap-y.",
        fourfloor=False, kick=[[0, 5, 10], [0, 3, 10, 13], [0, 10, 14]], snare=[4, 12], ghost=[(7, 50), (9, 44), (15, 52)], hat="16", swing8=0.04, sub_mode="funk", lead="accent",
        progs=[[0], [0, 0, 5, 0]], scales=["minor", "phrygian"], template=T_CLUB,
        bass=["0r2 3r1 4o1 6r1 8b2 11r1 12f1 14o1", "0r1 2r1 3o1 5r1 6b1 8r1 10f1 11r1 13o1"],
        sound=dict(acid="Resonance: .65 .9; Cutoff: 450 1600; Drive: .5 .8", wobble="Drive: .4 .7; Resonance: .5 .8", snare="Decay: 90 170; Drive: .4 .7", kick="Decay: 120 200; Drive: .3 .6",
                   cowbell="Decay: 80 200", conga="Decay: 90 220")),
    "The Prodigy - Breakbeat Rave (1997)": dict(
        base="DnB", era="rave_00s", theme="Dark", cls=4.5, color="#dc2626", duck=0.55, profile="aggressive",
        bpm=140, scale="phrygian", energy=0.94, density=0.76, swing=0.02,
        inst=S("kick snare clap hat openhat sub wobble reese hoover screech acid riser zap boom"),
        note="Breakbeat-rave: łamany kick/snare z drum'n'bassu przy 140 BPM, hoover-riffy i acid.",
        fourfloor=False, kick=[[0, 10], [0, 6, 10], [0, 10, 13]], snare=[4, 12], ghost=[(7, 40), (14, 48), (15, 40)], hat="16", swing8=0.02, sub_mode="roll", lead="accent", reese="late",
        progs=[[0], [0, 0, 1, 0], [0, 0, 5, 6]], scales=["phrygian", "minor"], template=T_DNB,
        bass=["0r2 2r1 3r1 4o2 8r2 10b1 11r1 12f2", "0r1 2r1 3o1 4r1 6b1 8r2 10f1 12r2 14o1"],
        sound=dict(hoover="Drive: .55 .9", reese="Drive: .5 .85; Cutoff: 900 2400", snare="Decay: 80 150; Drive: .4 .7", kick="Decay: 90 170; Drive: .3 .6", zap="Decay: 200 500")),
    "Aphex Twin - IDM (1995)": dict(
        base="Experimental", era="digital_90s", theme="Dark", cls=2.5, color="#f472b6", duck=0.40, profile="auto",
        bpm=130, scale="phrygian", energy=0.70, density=0.72, swing=0.05,
        inst=S("kick snare hat rim sub wobble fmbass pluck pad piano bell marimba"),
        note="IDM: łamane, mutujące rytmy, pulsujący bas FM i kruche melodie (piano, bell, marimba).",
        fourfloor=False, kick=[[0, 7, 11], [0, 5, 9, 14], [3, 10, 13], [0, 4, 13]], snare=[6, 13], ghost=[(2, 40), (9, 44), (11, 40), (15, 48)], hat="16", swing8=0.05, sub_mode="funk",
        lead="accent", chord_len=1, mutate=dict(drop=0.18, jitter=0.30, octave=0.10, shift=0.30), progs=[[0, 1, 6, 3], [0, 6, 1, 5]], scales=["phrygian", "harmonic minor", "dorian"], template=T_EXP,
        bass=["0r1 3b1 5o2 9f1 11u1 14t2", "0r5 5u3 10b1 13o3", "1r1 2r1 6p2 7r1 12b4"],
        sound=dict(fmbass="FM Amount: .4 .85; Resonance: .2 .5", bell="Ring Time: 500 1500", marimba="Ring Time: 300 900", piano="Decay: 300 800", kick="Decay: 70 150; Drive: .1 .4", snare="Decay: 60 140")),
    "Aphex Twin - Ambient Works (1993)": dict(
        base="Space Electronica", era="minimal_70s", theme="Countdown", cls=0.0, color="#c7d2fe", duck=0.0, profile="ambient",
        bpm=100, scale="dorian", energy=0.30, density=0.35, swing=0.0,
        inst=S("pad drone bell pluck vibes marimba"),
        note="Ambient bez perkusji: długie pady, dron i szkliste brzmienia perkusyjne w wolnym tempie.",
        core=S("pad drone bell pluck vibes marimba"), fourfloor=False, kick=NO_KICK, snare=[], hat="none", swing8=0.0, sub_mode="off", lead="melodic", melody="space",
        arp=dict(step=2, pattern="updown", prob=0.7), pad_mode="drop", voices=dict(pad=3), chord_len=4, progs=[[0, 5, 3, 4], [0, 3], [0, 2, 5, 6]], scales=["dorian", "minor"], template=T_AMB,
        bass=["0r16", "0r8 8f8"],
        sound=dict(pad="Attack: 1500 3200; Release: 2500 4500; Cutoff: 1200 3000", bell="Ring Time: 1500 3500", vibes="Ring Time: 1200 3000", drone="Attack: 2000 4000",
                   marimba="Ring Time: 500 1500", pluck="Decay: 200 500")),
    "Boards of Canada - Warm Downtempo (1998)": dict(
        base="Jazz", era="analog_80s", theme="Countdown", cls=0.6, color="#d6a86b", duck=0.20, profile="ambient",
        bpm=88, scale="dorian", energy=0.35, density=0.45, swing=0.06,
        inst=S("kick snare hat sub pad epiano vibes marimba bell"),
        note="Ciepłe, spowolnione downtempo: leniwy beat ze swingiem boom-bap, rozstrojone pady i miękkie klawisze.",
        fourfloor=False, kick=[[0, 10], [0, 7, 10], [0, 10, 14]], snare=[4, 12], ghost=[(7, 30), (15, 34)], hat="8", swing8=0.10, sub_mode="hold", lead="melodic", melody="jazz",
        voices=dict(pad=2, epiano=1), chord_len=2, progs=[[1, 4, 0, 5], [0, 5, 3, 4], [0, 3, 1, 4]], scales=["dorian", "major"], template=T_MIN,
        bass=["0r4 4f4 8o4 12f4", "0r6 6t2 8r4 12f4"],
        sound=dict(pad="Attack: 600 1500; Unison Detune: 25 55; Cutoff: 1200 3000", epiano="Decay: 500 1200; Cutoff: 1500 3500", vibes="Ring Time: 800 1800",
                   kick="Decay: 140 240; Drive: 0 .12", snare="Decay: 100 200; Noise: .5 .8", hat="Decay: 30 70; Noise: .3 .6", sub="Glide: 10 40")),
    "Orbital - Techno Rave (1993)": dict(
        base="Tunnel Trance", era="digital_90s", theme="Hype", cls=3.0, color="#6366f1", duck=0.65, profile="aggressive",
        bpm=128, scale="minor", energy=0.80, density=0.68, swing=0.02,
        inst=S("kick snare clap hat openhat sub wobble acid supersaw pluck pad riser"),
        note="Brytyjski rave/techno: acid na 4/4, bramkowane supersaw i melodyjne arpeggia.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", sub_mode="offbeat", lead="melodic", voices=dict(supersaw=2, pluck=2, pad=2),
        arp=dict(step=1, pattern="trance", prob=0.85), gate=[0, 2, 3, 5, 6, 8, 10, 11, 13, 14], progs=[[0, 5, 2, 6], [0, 3, 5, 4]], scales=["minor", "harmonic minor"], template=T_TRANCE,
        bass=["0r2 2r1 3r1 4o2 8r2 10f1 11r1 12b2", "0r1 2r1 3o1 5r1 6b1 8r1 10f1 11r1 13o1 14r1"],
        sound=dict(supersaw="Cutoff: 3000 8000; Attack: 5 20", acid="Resonance: .6 .85; Cutoff: 500 1800", pluck="Decay: 100 240", kick="Decay: 180 280")),
    "deadmau5 - Progressive House (2010)": dict(
        base="House", era="modern_10s", theme="Hype", cls=2.5, color="#a78bfa", duck=0.75, profile="soft",
        bpm=128, scale="minor", energy=0.72, density=0.62, swing=0.02,
        inst=S("kick clap hat openhat shaker sub wobble pluck supersaw pad stab vox riser boom piano bell"),
        note="Progressive house: bardzo długie narastania, offbeatowy bas, arpeggia pluck i warstwy supersaw.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.0, sub_mode="offbeat", lead="rare", voices=dict(pluck=2, pad=3, supersaw=2),
        arp=dict(step=2, pattern="updown", prob=0.9), progs=[[0, 5, 3, 4], [0, 3, 5, 4], [0, 5, 2, 6]], scales=["minor"], template=T_PROG,
        bass=["2r2 6r2 10r2 14r2", "2r1 3o1 6r1 10r1 11o1 14r2"],
        sound=dict(pluck="Decay: 130 320; Cutoff: 1500 4500; Filter Env Amt: 1.5 3.5", pad="Attack: 600 1600; Release: 1200 3000", kick="Decay: 190 300; Drive: .1 .3", supersaw="Release: 300 900")),
    "Kavinsky - Outrun Synthwave (2010)": dict(
        base="Electro", era="modern_10s", theme="Hype", cls=2.5, color="#ec4899", duck=0.60, profile="soft",
        bpm=108, scale="minor", energy=0.68, density=0.60, swing=0.0,
        inst=S("kick snare clap hat sub wobble supersaw pluck pad strings brass stab riser boom zap bell"),
        note="Synthwave/outrun: bas na ósemkach, gigantyczny werbel z długim ogonem, szerokie supersaw, arpeggia i stabowe blachy.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], ghost=[], hat="8", swing8=0.0, sub_mode="pulse8", lead="melodic", voices=dict(supersaw=2, strings=1, brass=1),
        arp=dict(step=2, pattern="updown", prob=0.9), progs=[[0, 5, 2, 6], [0, 3, 5, 6], [0, 5, 3, 4]], scales=["minor"], template=T_CLUB,
        bass=["0r2 2r2 4r2 6o2 8r2 10r2 12r2 14f2", "0r2 2r2 4r2 6r2 8r2 10o2 12r2 14f2"],
        sound=dict(snare="Decay: 220 420; Noise: .7 .95; Drive: .2 .4", supersaw="Unison Detune: 20 40; Cutoff: 4000 9000", brass="Attack: 30 90; Cutoff: 2500 5500", kick="Decay: 150 240", strings="Attack: 100 300")),
    "Gesaffelstein - Dark Techno (2013)": dict(
        base="Techno", era="rave_00s", theme="Dark", cls=4.0, color="#475569", duck=0.60, profile="aggressive",
        bpm=126, scale="phrygian", energy=0.86, density=0.52, swing=0.01,
        inst=S("kick snare clap hat sub wobble reese acid hoover drone boom riser zap glitch"),
        note="Mroczne, oszczędne techno: ciężka stopa, rzadkie uderzenia basu, dron i glitch w frygijskiej skali.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="offbeat", swing8=0.0, sub_mode="offbeat", lead="rare", progs=[[0], [0, 0, 0, 1]], scales=["phrygian", "minor"], template=T_CLUB,
        bass=["0r4 6r2 8r4 14r2", "0r2 3r1 8r2 11r1", "0r4 4r2 8b2 12r4"],
        sound=dict(kick="Decay: 200 330; Drive: .5 .85", reese="Drive: .5 .85; Cutoff: 500 1600", wobble="Drive: .6 .9; Resonance: .4 .7", hoover="Drive: .5 .85", drone="Attack: 800 2000")),
    "Front 242 - EBM (1988)": dict(
        base="Acid Techno", era="analog_80s", theme="Dark", cls=3.5, color="#7f1d1d", duck=0.60, profile="aggressive",
        bpm=124, scale="phrygian", energy=0.84, density=0.60, swing=0.0,
        inst=S("kick snare clap hat tom cowbell sub wobble stab"),
        note="EBM: sztywny 4/4, szesnastkowy sekwencerowy bas z oktawowymi akcentami, tomy i cowbell.",
        fourfloor=True, kick=[[0, 4, 8, 12]], snare=[4, 12], hat="16", swing8=0.0, sub_mode="pulse8", lead="rare", progs=[[0], [0, 0, 5, 0]], scales=["phrygian", "minor"], template=T_CLUB,
        bass=["0r1 1r1 2r1 3o1 4r1 5r1 6r1 7o1 8r1 9r1 10r1 11o1 12r1 13r1 14r1 15f1"],
        sound=dict(kick="Drive: .4 .7; Decay: 120 200", snare="Decay: 90 150; Drive: .4 .7", stab="Drive: .5 .8", wobble="Drive: .5 .8; Resonance: .3 .55", tom="Decay: 200 450", cowbell="Decay: 100 240")),
}

_CFG_META = {"base", "era", "theme", "cls", "color", "duck", "profile", "bpm", "scale", "energy", "density", "swing", "speak", "inst", "note", "bass", "growl", "sound"}
_PALETTE_DRUMS_BASS = ("kick", "snare", "clap", "hat", "openhat", "rim", "tom", "sub", "wobble", "reese", "growl", "acid", "fmbass", "bass808", "hollow", "neuro")


def names() -> list:
    return list(SPECIAL)


def wob_key(name: str) -> str:
    return "sp:" + name


def build_cfg(styles_dict, name: str) -> dict:
    """Pełna konfiguracja stylu specjalnego: kopia bazy + nadpisania ze specyfikacji."""
    sp = SPECIAL[name]
    cfg = copy.deepcopy(dict.__getitem__(styles_dict, sp["base"]))
    for k, v in sp.items():
        if k in _CFG_META:
            continue
        if v is None:
            cfg.pop(k, None)
        else:
            cfg[k] = copy.deepcopy(v)
    cfg["bpm"] = int(sp["bpm"]); cfg["swing"] = float(sp["swing"])
    cfg["wob"] = wob_key(name)
    inst = list(sp["inst"])
    core = list(sp.get("core") or [t for t in inst if t in _PALETTE_DRUMS_BASS])
    cfg["core"] = core
    cfg["extras"] = [t for t in inst if t not in core] + [t for t in cfg.get("extras", []) if t not in core and t not in inst]
    cfg["_class"] = float(sp["cls"]); cfg["_color"] = sp["color"]; cfg["_special"] = True
    return cfg


def register(styles_dict, WOB, GROWL, SOUND_STYLE, STYLE_THEME, DUCK_BASE):
    """Wstawia style specjalne do StyleDict + tabel per styl. Wywoływane z generator.py po zdefiniowaniu tabel (nie dodaje do ST.ORDER)."""
    if os.environ.get("DS_NO_SPECIAL"):
        return []
    from . import era_profiles as ERA
    try:
        from . import critical_correct as CC
    except Exception:                                    # pragma: no cover
        CC = None
    done = []
    for name, sp in SPECIAL.items():
        cfg = build_cfg(styles_dict, name)
        styles_dict[name] = cfg
        WOB[wob_key(name)] = [P(t) for t in sp["bass"]]
        if sp.get("growl"):
            GROWL[wob_key(name)] = [P(t) for t in sp["growl"]]
            cfg["growl"] = wob_key(name)
        SOUND_STYLE[name] = {t: SND(s) for t, s in sp["sound"].items()}
        ERA.BIAS_EXEMPT[name] = {t: {r[0] for r in rows} for t, rows in SOUND_STYLE[name].items()}
        STYLE_THEME[name] = sp["theme"]
        DUCK_BASE[name] = float(sp["duck"])
        ST.STYLE_CLASS[name] = float(sp["cls"]); ST.STYLE_COL[name] = sp["color"]
        ERA.STYLE_ERA[name] = sp["era"]
        if CC is not None and sp.get("profile") and sp["profile"] != "auto":
            CC.STYLE_TO_PROFILE[name] = sp["profile"]
        ST._SCENE_OVERRIDES.setdefault(name, dict(energy=float(sp["energy"]), density=float(sp["density"]), era=sp["era"]))
        done.append(name)
    return done
