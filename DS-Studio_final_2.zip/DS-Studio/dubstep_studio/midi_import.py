"""midi_import.py — analiza pliku MIDI → propozycja ustawień Generatora / instrumentów / gęstości.

Cel: z zewnętrznego MIDI (np. Daft Punk – Veridis Quo) wyciągnąć:
  • BPM / długość w taktach
  • przybliżoną tonację i skalę
  • gęstość i energię (z liczby nut / occupancy)
  • mapowanie ścieżek MIDI → typy instrumentów DS
  • propozycję stylu (hybryda lub baza) albo „auto” wg profilu

Wynik to słownik w formacie zbliżonym do preset["generator"] + metadane analizy,
gotowy do selective-apply w GUI.
"""
from __future__ import annotations

import collections
import math
import statistics
from pathlib import Path

try:
    import mido
except ImportError:  # pragma: no cover
    mido = None

from . import core, styles as ST

# Mapowanie nazw ścieżek / zakresów wysokości → typy DS (kolejność priorytetu)
NAME_HINTS = [
    (["kick", "bd", "bass drum", "bassdrum"], "kick"),
    (["snare", "sd", "snr"], "snare"),
    (["clap", "claps", "handclap"], "clap"),
    (["hat", "hh", "hihat", "hi-hat", "openhat", "oh"], "hat"),
    (["open hat", "openhat", "ohh"], "openhat"),
    (["ride", "cymbal"], "ride"),
    (["tom", "toms"], "tom"),
    (["crash", "cym"], "crash"),
    (["conga", "bongo", "perc"], "conga"),
    (["cowbell", "cow"], "cowbell"),
    (["shaker", "tamb"], "shaker"),
    (["rim", "rimshot", "stick"], "rim"),
    (["sub", "subbass", "sub-bass"], "sub"),
    (["bass", "bassline", "808"], "bass808"),
    (["wobble", "wub"], "wobble"),
    (["reese", "neuro"], "reese"),
    (["acid", "303", "tb303"], "acid"),
    (["organ"], "organ"),
    (["epiano", "e-piano", "rhodes", "keys", "key", "piano"], "epiano"),
    (["piano"], "piano"),
    (["pad", "strings", "string", "atmosphere", "atmos"], "pad"),
    (["choir", "vox", "voice", "vocal"], "choir"),
    (["brass", "horn"], "brass"),
    (["pluck", "arp", "arpeggio"], "pluck"),
    (["lead", "synth", "supersaw", "saw"], "supersaw"),
    (["stab", "stabs"], "stab"),
    (["bell", "chime"], "bell"),
    (["marimba", "vibes", "xyl"], "marimba"),
    (["flute", "woodwind"], "flute"),
    (["drone", "fx", "effect", "effects", "sfx"], "drone"),
    (["riser", "sweep", "whoosh"], "riser"),
    (["zap", "hit", "impact"], "zap"),
    (["boom", "drop"], "boom"),
    (["glitch", "noise"], "glitch"),
    (["hoover", "hoover"], "hoover"),
    (["screech"], "screech"),
    (["theremin"], "theremin"),
    (["percussion", "drums", "drum"], "kick"),  # fallback – later refined by pitch
]

# GM drum map (channel 9/10) → DS types
GM_DRUM = {
    35: "kick", 36: "kick",
    37: "rim", 38: "snare", 39: "clap", 40: "snare",
    41: "tom", 43: "tom", 45: "tom", 47: "tom", 48: "tom", 50: "tom",
    42: "hat", 44: "hat", 46: "openhat",
    49: "crash", 51: "ride", 52: "crash", 55: "crash", 57: "crash",
    54: "shaker", 56: "cowbell", 58: "conga", 62: "conga", 63: "conga", 64: "conga",
    69: "shaker", 70: "shaker", 75: "claves", 76: "woodblock",
}

# Preferowane mapowanie wysokości (melodia / bas) gdy brak nazwy
def _pitch_to_type(avg_pitch: float, is_perc: bool) -> str:
    if is_perc:
        return "hat"
    if avg_pitch < 40:
        return "sub"
    if avg_pitch < 52:
        return "bass808"
    if avg_pitch < 60:
        return "organ"
    if avg_pitch < 72:
        return "epiano"
    if avg_pitch < 84:
        return "pluck"
    return "supersaw"


def _guess_type_from_name(name: str) -> str | None:
    n = (name or "").lower().strip()
    if not n:
        return None
    for keys, typ in NAME_HINTS:
        for k in keys:
            if k in n:
                return typ
    return None


def _scale_fit(pcs: list[int]) -> tuple[str, float]:
    """Najlepsza skala (nazwa, score 0..1) dla zbioru klas wysokości."""
    if not pcs:
        return "minor", 0.0
    cnt = collections.Counter(pcs)
    total = sum(cnt.values())
    best_name, best_sc = "minor", -1.0
    for name, intervals in core.SCALES.items():
        # spróbuj wszystkich 12 tonik
        for root in range(12):
            scale_set = {(root + i) % 12 for i in intervals}
            in_scale = sum(v for pc, v in cnt.items() if pc in scale_set)
            sc = in_scale / total
            if sc > best_sc:
                best_sc = sc
                best_name = name
                best_root = root
    return best_name, best_sc


def _estimate_key(pcs: list[int]) -> int | None:
    if not pcs:
        return None
    # prosta heurystyka: najczęstsza klasa wysokości + kwinta / tercja
    cnt = collections.Counter(pcs)
    # score dla każdej możliwej toniki: waga toniki + kwinty + tercji
    best_r, best_s = 0, -1
    for r in range(12):
        s = cnt.get(r, 0) * 3 + cnt.get((r + 7) % 12, 0) * 2
        s += cnt.get((r + 3) % 12, 0) + cnt.get((r + 4) % 12, 0)
        if s > best_s:
            best_s, best_r = s, r
    return best_r


def analyze_midi(path: str | Path) -> dict:
    """Zwraca dict z polami generator + report analizy.

    Struktura:
      {
        "generator": { style, style_base, bpm, key, scale, bars, energy, density, swing,
                       instruments, speak_manual, speak_text, speak_theme },
        "analysis": {
          "tracks": [...], "bpm", "bars", "length_sec", "note_count",
          "suggested_styles": [(name, score), ...],
          "density_mod": "up"|"down"|"keep",
          "energy_mod": "up"|"down"|"keep",
        }
      }
    """
    if mido is None:
        raise RuntimeError("Brak biblioteki mido — zainstaluj: pip install mido")

    path = Path(path)
    mid = mido.MidiFile(str(path))
    tpb = mid.ticks_per_beat or 480

    # --- tempo (pierwsze set_tempo) ---
    tempo_us = 500000  # 120 BPM default
    for tr in mid.tracks:
        for msg in tr:
            if msg.type == "set_tempo":
                tempo_us = msg.tempo
                break
        else:
            continue
        break
    bpm = round(60_000_000 / tempo_us, 2)
    bpm_int = int(round(bpm))

    # --- zbierz nuty per track ---
    track_infos = []
    all_pcs = []
    total_notes = 0
    max_tick = 0

    for i, tr in enumerate(mid.tracks):
        name = (tr.name or f"Track {i}").strip()
        abs_tick = 0
        notes_on = {}  # (ch, note) -> start_tick
        events = []  # (start, end, note, vel, ch)
        is_drum_ch = False
        for msg in tr:
            abs_tick += msg.time
            if msg.type == "note_on" and msg.velocity > 0:
                notes_on[(msg.channel, msg.note)] = (abs_tick, msg.velocity)
                if msg.channel == 9:
                    is_drum_ch = True
            elif msg.type in ("note_off", "note_on"):  # note_on vel=0 = off
                key = (getattr(msg, "channel", 0), getattr(msg, "note", 0))
                if key in notes_on:
                    st, vel = notes_on.pop(key)
                    end = abs_tick
                    events.append((st, end, key[1], vel, key[0]))
                    max_tick = max(max_tick, end)
        # zamknij wiszące
        for (ch, note), (st, vel) in notes_on.items():
            events.append((st, abs_tick, note, vel, ch))
            max_tick = max(max_tick, abs_tick)
            if ch == 9:
                is_drum_ch = True

        if not events:
            continue

        pitches = [e[2] for e in events]
        avg_p = statistics.mean(pitches)
        dens = len(events) / max(1.0, (max_tick / tpb) / 4.0)  # nuty na takt (przybliż.)

        # typ
        typ = _guess_type_from_name(name)
        if typ is None and is_drum_ch:
            # większość nut z GM map
            mapped = [GM_DRUM.get(p) for p in pitches if p in GM_DRUM]
            if mapped:
                typ = collections.Counter(mapped).most_common(1)[0][0]
            else:
                typ = "hat"
        if typ is None:
            typ = _pitch_to_type(avg_p, is_drum_ch)

        # dla bębnów zbierz wszystkie użyte typy
        sub_types = []
        if is_drum_ch or typ in ("kick", "snare", "hat", "clap", "tom", "crash", "openhat", "ride", "conga", "cowbell", "shaker", "rim"):
            for p in pitches:
                t = GM_DRUM.get(p)
                if t and t not in sub_types:
                    sub_types.append(t)

        pcs = [p % 12 for p in pitches if not is_drum_ch]
        all_pcs.extend(pcs)
        total_notes += len(events)

        track_infos.append(dict(
            index=i, name=name, type=typ, sub_types=sub_types,
            n_notes=len(events), avg_pitch=round(avg_p, 1),
            density_per_bar=round(dens, 2), is_drum=is_drum_ch,
            pitch_min=min(pitches), pitch_max=max(pitches),
        ))

    length_beats = max_tick / tpb if tpb else 0
    bars = max(8, int(round(length_beats / 4.0 / 8.0)) * 8)  # wielokrotność 8
    length_sec = mid.length if hasattr(mid, "length") else (length_beats * 60.0 / max(bpm, 1))

    # --- skala / tonacja ---
    scale_name, scale_score = _scale_fit(all_pcs)
    key = _estimate_key(all_pcs)

    # --- gęstość / energia ---
    # occupancy: średnia nut na takt względem typowego 8–16
    notes_per_bar = total_notes / max(1, length_beats / 4.0)
    if notes_per_bar < 6:
        density = 0.35
        dens_mod = "down"
    elif notes_per_bar < 12:
        density = 0.50
        dens_mod = "keep"
    elif notes_per_bar < 20:
        density = 0.65
        dens_mod = "keep"
    else:
        density = 0.78
        dens_mod = "up"

    # energia z BPM + gęstości + zakresu wysokości
    e = 0.4
    if bpm_int >= 128:
        e += 0.2
    elif bpm_int >= 118:
        e += 0.1
    e += (density - 0.4) * 0.5
    energy = max(0.25, min(0.95, e))
    if energy > 0.75:
        energy_mod = "up"
    elif energy < 0.45:
        energy_mod = "down"
    else:
        energy_mod = "keep"

    # --- instrumenty (unikalne, w sensownej kolejności) ---
    order = list(core.TYPES) if hasattr(core, "TYPES") else []
    seen = set()
    instruments = []
    # najpierw z sub_types perkusji
    for ti in track_infos:
        for t in ti.get("sub_types") or [ti["type"]]:
            if t not in seen and t in (order or [t]):
                seen.add(t)
                instruments.append(t)
    if not instruments:
        instruments = ["kick", "hat", "sub", "pad"]

    # limit ~12–16 typów
    instruments = instruments[:16]

    # --- propozycja stylu ---
    suggested = _suggest_styles(bpm_int, scale_name, energy, density, instruments)

    style_base = suggested[0][0] if suggested else "House"
    # prosta hybryda 2-składnikowa gdy jest drugi blisko
    if len(suggested) >= 2 and suggested[1][1] > 0.55:
        a, b = suggested[0][0], suggested[1][0]
        style = f"{a} 55% + {b} 45%"
        # sprawdź czy parse_hybrid to łyknie
        try:
            if ST.parse_hybrid(style, getattr(__import__("dubstep_studio.generator", fromlist=["STYLES"]), "STYLES", {})) is None:
                style = style_base
        except Exception:
            style = style_base
    else:
        style = style_base

    gen = dict(
        style=style,
        style_base=style_base,
        bpm=bpm_int,
        key=key,
        scale=scale_name,
        bars=bars,
        energy=round(energy, 2),
        density=round(density, 2),
        swing=0.0,
        instruments=instruments,
        speak_manual=False,
        speak_text="",
        speak_theme=None,
    )

    return dict(
        generator=gen,
        analysis=dict(
            source=str(path),
            tracks=track_infos,
            bpm=bpm,
            bpm_int=bpm_int,
            bars=bars,
            length_sec=round(length_sec, 1),
            note_count=total_notes,
            scale_score=round(scale_score, 3),
            suggested_styles=suggested[:6],
            density_mod=dens_mod,
            energy_mod=energy_mod,
            notes_per_bar=round(notes_per_bar, 1),
        ),
    )


def _suggest_styles(bpm: int, scale: str, energy: float, density: float, instruments: list) -> list[tuple[str, float]]:
    """Proste reguły dopasowania stylu DS do cech MIDI."""
    scores: dict[str, float] = collections.defaultdict(float)

    # BPM bands
    if 100 <= bpm <= 115:
        for s, w in (("Berlin School", 0.9), ("Space Electronica", 0.7), ("Romantic", 0.5), ("Electro", 0.4)):
            scores[s] += w
    elif 116 <= bpm <= 124:
        for s, w in (("House", 0.85), ("Electro", 0.7), ("Jazz Rock", 0.5), ("Techno Trax", 0.4)):
            scores[s] += w
    elif 125 <= bpm <= 132:
        for s, w in (("Techno", 0.8), ("House", 0.7), ("Trance", 0.6), ("Acid Techno", 0.5)):
            scores[s] += w
    elif bpm >= 133:
        for s, w in (("Hard Techno", 0.85), ("DnB", 0.6), ("Psytrance", 0.5), ("Techno Trax", 0.4)):
            scores[s] += w
    else:
        for s, w in (("Space Electronica", 0.7), ("Minimal Classical", 0.6), ("Berlin School", 0.5)):
            scores[s] += w

    # skala
    if scale in ("phrygian", "harmonic minor"):
        scores["Hard Techno"] += 0.3
        scores["Raw Synthesis"] += 0.3
        scores["Gesaffelstein"]  # ignore
        scores["Acid Techno"] += 0.25
    elif scale == "dorian":
        scores["Jazz Rock"] += 0.4
        scores["House"] += 0.25
        scores["Space Electronica"] += 0.2
    elif scale == "major":
        scores["Berlin School"] += 0.3
        scores["Romantic"] += 0.25

    # energia / gęstość
    if energy > 0.75:
        scores["Hard Techno"] += 0.35
        scores["Techno"] += 0.25
        scores["Electro"] += 0.2
    elif energy < 0.45:
        scores["Space Electronica"] += 0.4
        scores["Minimal Classical"] += 0.3
        scores["Berlin School"] += 0.25

    if density > 0.7:
        scores["Techno Trax"] += 0.2
        scores["House"] += 0.15
    elif density < 0.4:
        scores["Minimal Classical"] += 0.25

    # instrumenty
    inst = set(instruments)
    if "organ" in inst or "epiano" in inst:
        scores["House"] += 0.3
        scores["Jazz Rock"] += 0.25
        scores["Electro"] += 0.15
    if "acid" in inst:
        scores["Acid Techno"] += 0.5
    if "hoover" in inst or "screech" in inst:
        scores["Hard Techno"] += 0.35
        scores["Raw Synthesis"] += 0.2
    if "pad" in inst and "pluck" in inst and not ({"kick", "snare"} & inst):
        scores["Berlin School"] += 0.4
        scores["Space Electronica"] += 0.3
    if "choir" in inst or "strings" in inst:
        scores["Romantic"] += 0.3
        scores["Trance"] += 0.2

    # normalizuj i posortuj
    if not scores:
        return [("House", 0.5)]
    mx = max(scores.values()) or 1.0
    ranked = sorted(((n, round(v / mx, 3)) for n, v in scores.items()), key=lambda x: -x[1])
    return ranked


def analysis_to_preset_data(analysis_result: dict, style_override: str | None = None) -> dict:
    """Buduje pełny szkielet presetu (generator + puste board/live) z wyniku analyze_midi."""
    gen = dict(analysis_result["generator"])
    if style_override:
        gen["style"] = style_override
        # style_base = pierwszy składnik lub całość
        if "%" in style_override:
            gen["style_base"] = style_override.split("%")[0].rsplit(" ", 1)[0].strip()
        else:
            gen["style_base"] = style_override

    live = dict(
        mode="current",
        locks={k: False for k in ("style", "bpm", "key", "scale", "energy", "density", "swing", "bars", "instruments")},
        tod_on=True,
        tod_force=None,
        tod_factors={"Rano": 0.88, "Popołudnie": 1.0, "Wieczór": 1.06, "Noc": 0.9},
        arr_bars=max(32, min(80, int(round(gen["bars"] / 2 / 8.0)) * 8)),
        lookahead=1,
        max_store=60,
        return_live=True,
        mutate_p=0.0,
        use_board=False,
        new_hybrids=False,
        complexity="balanced",
        complexity_intensity=0.5,
        complexity_follow_tod=True,
    )
    return dict(
        generator=gen,
        board=dict(cells=[], strength=0.4),
        live=live,
        analysis=analysis_result.get("analysis"),
    )
