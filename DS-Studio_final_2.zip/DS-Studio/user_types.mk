# generowane przez userinst.py — instrumenty użytkownika dopisywane do NAMES w Makefile (kolejność = indeks typu)
USER_NAMES := 
