# Rozszerzony import presetów + Import MIDI

## Selektywne stosowanie (checkboxy)

Przy **Wczytaj** oraz po **Importuj…** pojawia się dialog z grupami:

| Grupa | Zawartość |
|-------|-----------|
| **generator** | styl/hybryda, BPM, tonacja, skala, takty, energia, gęstość, swing, instrumenty, Speak |
| **board** | komórki pola stylów + siła |
| **live** | tryb, blokady, pory dnia, complexity, mutacje, arr_bars, lookahead, new_hybrids… |
| **director** | mood, scenariusze, role, autolevel, critical correct |
| **arranger** | amount, WYSIWYG, warstwy, kreator |
| **flags** | smart instruments, niuanse, uniq, health, arp, scenariusze legacy… |

Można zaznaczyć tylko to, co ma nadpisać bieżące ustawienia (np. sam Live bez riania Generatora).

`collect_preset()` zapisuje teraz wszystkie powyższe grupy — stare presety (tylko generator/board/live) nadal działają.

## Import MIDI…

Przycisk **Import MIDI…** obok Importuj:

1. Wybierz plik `.mid` / `.midi` (np. `examples/daft_punk-veridis_quo.mid`).
2. Analiza (`midi_import.analyze_midi`):
   - BPM, długość w taktach
   - skala + tonacja (fit do SCALES)
   - gęstość / energia + mod (up/down/keep)
   - mapowanie ścieżek → typy DS (nazwa, GM drum map, zakres wysokości)
   - propozycja stylów (reguły BPM × skala × instrumenty)
3. Dialog: wybór stylu (propozycje na górze, edytowalna hybryda), checkboxy Generator / Live.
4. Opcjonalny zapis jako named preset.

**Uwaga:** wynik nie odtworzy utworu 1:1 — to szkielet wytycznych (BPM, skala, gęstość, zestaw instrumentów, styl), z którego generator zbuduje zauważalnie podobny klimat.

### Przykład: Veridis Quo

```
BPM ≈ 100, bars ≈ 64, skala minor
style ≈ Berlin School 55% + Space Electronica 45%
instruments ≈ epiano, organ, hat, kick, snare, drone
```

## Pliki

- `dubstep_studio/midi_import.py` — analiza
- `dubstep_studio/gui.py` — dialogi, `apply_preset(..., groups=)`, przycisk Import MIDI
- `dubstep_studio/presets.py` — rozszerzony schemat + `to_engine`
- `presets_artists.json` — gotowy pack artystów (Daft Punk, Kraftwerk, Vitalic…)
