// dstypes.cpp — zrzut tabeli parametrów silnika i definicji typów do JSON (dla karty „Modelowanie CLAP”)
//   dstypes > types.json
#include <cstdio>
#include <string>

#include "ds_engine.h"

static std::string esc(const char* s) {
  std::string o;
  for (; s && *s; s++) { if (*s == '"' || *s == '\\') o += '\\'; o += (*s == '\n') ? ' ' : *s; }
  return o;
}

int main() {
  using namespace ds;
  const char* K[] = {"lin", "log", "int"};
  std::printf("{\"params\":[");
  for (int i = 0; i < NP; i++) {
    const ParamInfo& p = PI[i];
    std::printf("%s{\"i\":%d,\"name\":\"%s\",\"group\":\"%s\",\"kind\":\"%s\",\"lo\":%.9g,\"hi\":%.9g,\"def\":%.9g,\"unit\":\"%s\",\"names\":[",
                i ? "," : "", i, esc(p.name).c_str(), esc(p.group).c_str(), K[p.kind], p.lo, p.hi, p.def, esc(p.unit).c_str());
    if (p.names && p.kind == INT)
      for (int k = 0; k <= (int)(p.hi - p.lo + 0.5f); k++) std::printf("%s\"%s\"", k ? "," : "", esc(p.names[k]).c_str());
    std::printf("]}");
  }
  std::printf("],\"types\":[");
  const auto& T = types();
  for (size_t t = 0; t < T.size(); t++) {
    const TypeDef& d = T[t];
    std::printf("%s{\"id\":\"%s\",\"name\":\"%s\",\"desc\":\"%s\",\"oneshot\":%s,\"ref\":%.9g,\"retrig\":%s,\"speech\":%s,\"modal\":%d,\"ex\":[",
                t ? "," : "", esc(d.id).c_str(), esc(d.name).c_str(), esc(d.desc).c_str(), d.oneshot ? "true" : "false", d.ref,
                d.retrig ? "true" : "false", d.speech ? "true" : "false", d.modal);
    for (size_t k = 0; k < d.ex.size(); k++) std::printf("%s[%d,%.9g]", k ? "," : "", d.ex[k].p, d.ex[k].v);
    std::printf("],\"hid\":[");
    for (size_t k = 0; k < d.hid.size(); k++) std::printf("%s[%d,%.9g]", k ? "," : "", d.hid[k].p, d.hid[k].v);
    std::printf("]}");
  }
  std::printf("]}\n");
  return 0;
}
