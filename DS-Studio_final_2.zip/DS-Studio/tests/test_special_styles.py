"""Testy stylów specjalnych (artysta/album): rejestracja, poprawność wzorów/brzmień, determinizm, odrębność od gatunku bazowego."""
import json
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("DS_CUSTOM_STYLES", "/tmp/none_custom_styles.json")
os.environ.pop("DS_NO_SPECIAL", None)

from dubstep_studio import core, era_profiles as ERA, generator as G, special_styles as SP, styles as ST   # noqa: E402


class SpecialStyles(unittest.TestCase):
    def test_registered_as_pure_and_outside_order(self):
        for n in SP.names():
            self.assertTrue(dict.__contains__(G.STYLES, n), n)
            self.assertNotIn(n, ST.ORDER, "style specjalne nie mogą wchodzić do pola szachowego / losowania Live")
            self.assertEqual(G.STYLES[n]["wob"], SP.wob_key(n))
            self.assertIn(SP.wob_key(n), G.WOB)

    def test_usable_as_hybrid_component(self):
        for n in SP.names():
            h = f"{n} 60% + Techno 40%"
            self.assertIsNotNone(ST.parse_hybrid(h, G.STYLES), n)
            self.assertEqual(G.STYLES[h]["parts"][n], 0.6)

    def test_pattern_and_sound_parsers_reject_garbage(self):
        with self.assertRaises(ValueError):
            SP.P("0x2")
        with self.assertRaises(ValueError):
            SP.P("16r1")
        with self.assertRaises(ValueError):
            SP.SND("Decay 100 200")
        self.assertEqual(SP.P("0r2 3o1"), [(0, "r", 2), (3, "o", 1)])
        self.assertEqual(SP.SND("Decay: 1 2; Waveform = 2 3"), [("Decay", "r", 1.0, 2.0), ("Waveform", "c", [2, 3])])

    def test_era_instruments_and_params_valid(self):
        m = core.meta()
        for n, sp in SP.SPECIAL.items():
            era = ERA.resolve_era("auto", n)
            self.assertEqual(era, sp["era"], n)
            self.assertLessEqual(len(sp["inst"]), ERA.ERA[era]["max_tracks"], n)
            self.assertTrue(all(t in core.TYPES for t in sp["inst"]), n)
            for t, rows in G.SOUND_STYLE[n].items():
                self.assertIn(t, core.TYPES, (n, t))
                for r in rows:
                    self.assertTrue(m.has(t, r[0]), f"{n}: {t} nie ma „{r[0]}”")

    def test_generate_deterministic_and_own_patterns(self):
        for n in ("Daft Punk - Homework (1997)", "Kraftwerk - Trans-Europe Express (1977)", "Tangerine Dream - Phaedra (1974)"):
            sp = SP.SPECIAL[n]
            kw = dict(style=n, bpm=sp["bpm"], scale=sp["scale"], bars=48, seed=5, instruments=sp["inst"])
            a, b = G.generate(**kw), G.generate(**kw)
            self.assertEqual(json.dumps(a["tracks"], default=str), json.dumps(b["tracks"], default=str), n)
            self.assertTrue(all(any(t["type"] == i for t in a["tracks"]) for i in sp["inst"]), n)

    def test_phaedra_has_no_drums(self):
        n = "Tangerine Dream - Phaedra (1974)"
        p = G.generate(style=n, bpm=120, scale="minor", bars=48, seed=2, instruments=SP.SPECIAL[n]["inst"])
        for t in p["tracks"]:
            if t["type"] in ("kick", "snare", "hat"):
                self.assertEqual(t["notes"], [], t["type"])

    def test_sound_overrides_actually_applied(self):
        """Nastawy brzmień stylu realnie trafiają do ścieżek: <3 % próbek poza oknem (±2 %) i żadna mediana poza oknem.
        (Bez wyjątku z era_profiles.BIAS_EXEMPT bias epoki wypychał ~15 % próbek poza okna, np. Glide 0–10 ms → ~150 ms.)"""
        import statistics
        m = core.meta(); total = outside = 0
        for n in ("Daft Punk - Homework (1997)", "Giorgio Moroder - Euro Disco (1977)", "Vitalic - Flashmob (2009)", "Boards of Canada - Warm Downtempo (1998)"):
            sp = SP.SPECIAL[n]
            win = {(t, r[0]): (r[2], r[3]) for t, rows in G.SOUND_STYLE[n].items() for r in rows if r[1] == "r"}
            vals = {k: [] for k in win}
            for seed in range(6):
                p = G.generate(style=n, bpm=sp["bpm"], scale=sp["scale"], bars=48, seed=seed, instruments=sp["inst"])
                for t in p["tracks"]:
                    for (ty, name) in win:
                        if t["type"] == ty and name in t["params"]:
                            vals[(ty, name)].append(m.frac2eng(ty, name, t["params"][name]))
            for (ty, name), v in vals.items():
                lo, hi = win[(ty, name)]
                total += len(v); outside += sum(1 for e in v if e > hi * 1.02 + 1e-6 or e < lo * 0.98 - 1e-6)
                if v:
                    self.assertTrue(lo * 0.98 <= statistics.median(v) <= hi * 1.02 + 1e-6, (n, ty, name, statistics.median(v), lo, hi))
        self.assertGreater(total, 300)
        self.assertLess(outside / total, 0.03, (outside, total))

    def test_builtin_styles_keep_era_bias(self):
        """Wyjątek od biasu epoki dotyczy wyłącznie stylów specjalnych: dla wbudowanego i hybrydy bias działa jak dawniej."""
        self.assertNotIn("House", ERA.BIAS_EXEMPT)
        self.assertNotIn("House 60% + Techno 40%", ERA.BIAS_EXEMPT)
        tr = dict(type="sub", params={"Glide": 0.0}); ERA.apply_param_bias(tr, "analog_80s", "House", __import__("random").Random(1))
        self.assertGreater(tr["params"]["Glide"], 0.05)

    def test_disable_switch(self):
        import subprocess
        code = "import os; os.environ['DS_NO_SPECIAL']='1'; os.environ['DS_CUSTOM_STYLES']='/tmp/none.json'; from dubstep_studio import generator as G; print(dict.__contains__(G.STYLES, 'Daft Punk - Homework (1997)'))"
        out = subprocess.run([sys.executable, "-c", code], cwd=str(Path(__file__).resolve().parent.parent), capture_output=True, text=True)
        self.assertEqual(out.stdout.strip(), "False", out.stderr)


if __name__ == "__main__":
    unittest.main()
