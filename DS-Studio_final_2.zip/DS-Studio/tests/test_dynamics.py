"""Testy opcji instrumentu „Dynamics” (3-pasmowy limiter / normalizer z presetami).

Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_dynamics -v
Wymaga zbudowanego hosta (`make` -> build/dsrender + wtyczki .clap); bez niego testy są pomijane.
"""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import core  # noqa: E402

try:
    META = core.meta()
except Exception:  # brak hosta / wtyczek
    META = None

PID = "stpf99.dubstep.wobble"
NOTES = [(0.0, 1.5, 36, 1.0), (2.0, 1.5, 48, 0.5)]


def _render(params, notes=NOTES, length=4.0):
    pl = META.plugins[PID]
    pm = pl["params"]
    with tempfile.TemporaryDirectory() as td:
        out, job = Path(td) / "o.f32", Path(td) / "job.txt"
        L = ["sr 48000", "bpm 140", f"len {length}", "tail 1.0", f"plugin {pl['file']} {pl['id']}", f"out {out}"]
        for k, v in params.items():
            L.append(f"p {pm[k]['id']} {v}")
        for t, l, key, vel in notes:
            L.append(f"n {t} {l} {key} {vel}")
        job.write_text("\n".join(L) + "\n")
        subprocess.run([str(ROOT / "build" / "dsrender"), str(job)], check=True)
        return np.fromfile(out, dtype=np.float32).reshape(-1, 2)


@unittest.skipIf(META is None, "brak zbudowanego hosta (make)")
class DynamicsTests(unittest.TestCase):
    def test_every_plugin_exposes_dynamics_on_by_default(self):
        for pid, pl in META.plugins.items():
            for name in ("Dynamics", "Dyn Preset", "Dyn Amount"):
                self.assertIn(name, pl["params"], f"{pid}: brak {name}")
            self.assertEqual(pl["params"]["Dynamics"]["def"], 1, pid)          # domyślnie Limiter 3-Band
            self.assertEqual(pl["params"]["Dyn Preset"]["def"], 7, pid)        # preset „Less Bass”

    def test_default_is_limiter_less_bass_and_off_ignores_preset(self):
        d = _render({})
        self.assertTrue(np.array_equal(d, _render({"Dynamics": 1, "Dyn Preset": 7, "Dyn Amount": 1.0})))
        a = _render({"Dynamics": 0})
        b = _render({"Dynamics": 0, "Dyn Preset": 3, "Dyn Amount": 0.3})   # Off ignoruje preset i amount
        self.assertTrue(np.array_equal(a, b))
        self.assertFalse(np.array_equal(a, d))

    def test_less_bass_reduces_low_band_only(self):
        a, d = _render({"Dynamics": 0, "Level": 0.3}), _render({"Level": 0.3})   # cicho: limiter nie rusza szczytów, działa tylko przycięcie basu
        def band(x, lo, hi):
            f = np.fft.rfftfreq(len(x), 1 / 48000); m = np.abs(np.fft.rfft(x[:, 0])); return float(m[(f >= lo) & (f < hi)].sum())
        self.assertLess(band(d, 20, 120) / band(a, 20, 120), 0.75)
        self.assertGreater(band(d, 600, 4000) / band(a, 600, 4000), 0.8)

    def test_limiter_respects_ceiling_on_all_presets(self):
        for pre in range(8):
            y = _render({"Dynamics": 1, "Dyn Preset": pre})
            self.assertLessEqual(float(np.abs(y).max()), 0.9661, f"preset {pre}")
            self.assertTrue(np.isfinite(y).all())

    def test_normalizer_lifts_quiet_and_quiets_loud(self):
        a = slice(int(0.3 * 48000), int(1.4 * 48000))
        rms = lambda x: float(np.sqrt((x[a] ** 2).mean()))
        quiet = _render({"Level": 0.1, "Dynamics": 0})
        self.assertGreater(rms(_render({"Level": 0.1, "Dynamics": 2, "Dyn Preset": 3})), 1.5 * rms(quiet))
        loud = _render({"Level": 0.8, "Dynamics": 0})
        self.assertLess(rms(_render({"Level": 0.8, "Dynamics": 2, "Dyn Preset": 0})), 0.6 * rms(loud))

    def test_normalizer_does_not_boost_silence_between_notes(self):
        y = _render({"Dynamics": 2, "Dyn Preset": 0}, notes=[(0, 0.5, 36, 1.0), (3.0, 0.5, 36, 1.0)])
        self.assertLessEqual(float(np.abs(y[3 * 48000:3 * 48000 + 24000]).max()), 0.9661)
        self.assertLess(float(np.abs(y[int(2.2 * 48000):int(2.9 * 48000)]).max()), 1e-3)


if __name__ == "__main__":
    unittest.main()
