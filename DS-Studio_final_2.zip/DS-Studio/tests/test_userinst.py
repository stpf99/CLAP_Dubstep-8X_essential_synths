"""Testy backendu instrumentów użytkownika (bez kompilacji): walidacja, emisja C++, układ banków modalnych, rejestracja w tabelach aplikacji."""
import copy
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dubstep_studio import core, generator as G, userinst as U  # noqa: E402

HAVE_INFO = (U.APP_DIR / "build" / "dstypes").exists()


@unittest.skipUnless(HAVE_INFO, "brak build/dstypes (uruchom `make`)")
class TestUserInst(unittest.TestCase):
    def spec(self, **kw):
        s = U.new_spec("pluck")
        s.update(id="tstinst", name="Test Inst", gen="pluck", status="approved", seq=900)
        s.update(kw)
        return s

    def test_validate(self):
        self.assertEqual(U.validate(self.spec()), [])
        self.assertTrue(U.validate(self.spec(id="Bad Id")))
        self.assertTrue(U.validate(self.spec(id="kick")))           # kolizja z wbudowanym
        self.assertTrue(U.validate(self.spec(ex=[])))               # brak parametrów jawnych
        self.assertTrue(U.validate(self.spec(gen="nie_ma")))

    def test_emit_type_and_modal_layout(self):
        a = self.spec(id="aaa")
        b = self.spec(id="bbb", seq=901, modal_custom=[{"ratio": 1, "amp": 1, "decay": 1}, {"ratio": 2.5, "amp": .5, "decay": .6}])
        ap, bank_of = U._layout([a, b])
        self.assertEqual([s["id"] for s in ap], ["aaa", "bbb"])
        self.assertEqual(bank_of, {"bbb": U.CUSTOM_MODAL_FIRST})
        txt = U.emit_type(b, U._modal_value(b, bank_of))
        self.assertIn('"stpf99.dubstep.bbb"', txt)
        self.assertTrue(txt.rstrip().endswith(f"{U.CUSTOM_MODAL_FIRST}}},"))
        self.assertIn("{2, {1.0f, 2.5f, 0, 0, 0, 0}", U.emit_modal(b))

    def test_write_aggregates_in_temp_dir(self):
        with tempfile.TemporaryDirectory() as d:
            old = (U.SRC, U.USER_SRC, U.MK)
            try:
                U.SRC = Path(d); U.USER_SRC = Path(d) / "user"; U.MK = Path(d) / "user_types.mk"
                U.write_aggregates([self.spec(id="aaa"), self.spec(id="bbb", seq=901, status="draft")])
                self.assertIn("USER_NAMES := Aaa", U.MK.read_text())
                self.assertNotIn("Bbb", U.MK.read_text())             # szkic nie trafia do Makefile
                self.assertIn('#include "user/aaa.inc"', (Path(d) / "ds_user_types.inc").read_text())
            finally:
                U.SRC, U.USER_SRC, U.MK = old

    def test_register_updates_app_tables(self):
        s = self.spec(id="regtest", group="Akustyczne", gen="tongue", role="pad", styles=["Jazz"], eras=["modern_10s"], duck=0.2)
        snap = copy.copy(core.TYPES)
        try:
            self.assertTrue(U.register(s))
            self.assertIn("regtest", core.TYPES)
            self.assertIn("regtest", core.GROUPS["Akustyczne"])
            self.assertIs(G.GEN["regtest"], G.GEN["tongue"])
            self.assertIn("regtest", G.STYLES["Jazz"]["extras"])
            self.assertIn("regtest", G.STYLES["Jazz 50% + Techno 50%"]["extras"])   # hybrydy dziedziczą
            self.assertEqual(G.NATIVE_ROLE["regtest"], "pad")
        finally:
            U.REGISTRY.pop("regtest", None)
            if "regtest" in core.TYPES:
                core.TYPES.remove("regtest")
            core.GROUPS["Akustyczne"].remove("regtest"); G.ORDER.remove("regtest")
            G.STYLES["Jazz"]["extras"].remove("regtest"); G.STYLES._hyb.clear()
            self.assertEqual(core.TYPES, snap)


if __name__ == "__main__":
    unittest.main()
