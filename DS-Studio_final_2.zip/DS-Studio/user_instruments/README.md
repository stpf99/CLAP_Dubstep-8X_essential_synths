Tu zapisują się instrumenty z karty „Modelowanie CLAP” (`<id>.json`).
Szkic (`status: draft`) żyje tylko tutaj; po „Zatwierdź do biblioteki” (`status: approved`) generowane są
`src/user/<id>.inc`, `src/ds_user_types.inc`, `user_types.mk` (→ NAMES w Makefile) i buduje się `build/DS-<Id>.clap`.
Skopiowany tu zatwierdzony plik .json zostanie rozpoznany przy starcie aplikacji lub przez „Skanuj ponownie”.
