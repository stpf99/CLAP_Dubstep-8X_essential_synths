"""keywords.py — wybór parametrów Generatora przez SŁOWA KLUCZOWE (polskie i angielskie, bez ogonków).

Cel: zamiast szukać suwaków, użytkownik pisze np.
    „baza dnb · nastrój relaxing · mod · barwa midtones · energia średnia · 174 bpm · epoka 90s”
    albo swobodnie: „dnb relaxing midtones”.

Parser jest czystym Pythonem (bez Qt / bez zależności) — używa go GUI (karta Generator),
Live (pole „Słowa kluczowe losowania”) i może użyć CLI. Diakrytyki, przecinki, „:”, „=”,
spójniki („z”, „typem”, „w”…) i odmiany („bazy”, „nastroju”, „barwie”…) są rozpoznawane.

Wynik parse() → dict:
  scene  — klucze zrozumiałe dla apply_style_scene()/generate() (style, bpm, bars, swing,
           energy, density, scale, spectacle, era, niuanse…, uniq…, dance…, director_on, director_mood)
  extra  — pola spoza sceny: key, predict, variety, arp, timbre_pref, strict
  hits   — czytelna lista „co zostało ustawione” (pasek statusu / raport)
  unknown— tokeny niezrozumiałe (ostrzeżenie; nie blokują pozostałych słów)

Kolejność dopasowania: fraza stylu (2–3 słowa) → styl → nastrój → skala → tonacja → barwa →
epoka → spektakl → swing → przewidywalność/zmienność → flagi → liczba (z kontekstem) →
przedrostek kategorii („baza…”, „nastrój…”, „barwa…”) → poziomy bez kontekstu → nieznane.

Wieloznaczności: „acid”/„hard”/… jako ZWYKŁE słowo = styl; pod własną kategorią = znaczenie
kategorii („barwa acid” = barwa). „sztywno”/„zawsze” → strict=True (w Live pola ze słów
nie są losowane). „bez X” wyłącza flagę („bez niuansów”).
"""
from __future__ import annotations

import re

# ------------------------------------------------------------------ pomocnicze
_FOLD = str.maketrans("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ", "acelnoszzacelnoszz")


def fold(s) -> str:
    """małe litery + ogonki bez diakrytyków („nastroju” == „nastrój”)."""
    return str(s or "").translate(_FOLD).lower().strip()


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ------------------------------------------------------------------ słowniki
# style: alias (po fold) → nazwa; pełne nazwy z ORDER też działają (dopasowanie od PREFIKSU)
STYLE_PREFIXES = {
    "brostep": "Brostep", "riddim": "Riddim", "tearout": "Tearout",
    "melodic": "Melodic", "melodyjn": "Melodic",
    "deep": "Deep", "dubstep": "Dubstep", "dub": "Dubstep",
    "drumstep": "Drumstep", "trap": "Trap", "edm": "EDM",
    "techno": "Techno", "hard techno": "Hard Techno", "hard": "Hard Techno", "tward": "Hard Techno",
    "acid techno": "Acid Techno", "acid": "Acid Techno", "kwas": "Acid Techno",
    "house": "House", "electro": "Electro", "techno trax": "Techno Trax", "trax": "Techno Trax",
    "tunnel trance": "Tunnel Trance", "tunnel": "Tunnel Trance",
    "trance": "Trance", "psytrance": "Psytrance", "psytr": "Psytrance", "psy": "Psytrance",
    "space electronica": "Space Electronica", "space": "Space Electronica", "kosm": "Space Electronica",
    "berlin school": "Berlin School", "berlin": "Berlin School",
    "baroqu": "Baroque", "barok": "Baroque",
    "romantic": "Romantic", "romant": "Romantic",
    "minimal classical": "Minimal Classical", "classical": "Minimal Classical", "klasyk": "Minimal Classical",
    "jazz rock": "Jazz Rock", "jazz": "Jazz",
    "experiment": "Experimental", "eksperyment": "Experimental",
    "raw synthesis": "Raw Synthesis", "raw": "Raw Synthesis", "surow": "Raw Synthesis",
    "dnb": "DnB", "drum and bass": "DnB", "drum n bass": "DnB", "drumandbass": "DnB",
    "liquid dnb": "Liquid DnB", "liquid": "Liquid DnB",
    "neurofunk": "Neurofunk", "neuro": "Neurofunk",
}

# nastrój: słowo → (mood −1..+1, podsugerowana energia −0.3..+0.3)
MOOD_WORDS = {
    "relaxing": (0.30, -0.20), "relaks": (0.30, -0.20), "spokojn": (0.35, -0.25),
    "chill": (0.30, -0.30), "lagodn": (0.40, -0.20), "uspokajan": (0.30, -0.25), "wyciszon": (0.25, -0.30), "wyciszaj": (0.25, -0.30),
    "dreamy": (0.50, -0.15), "marzenio": (0.50, -0.15), "marzen": (0.50, -0.15),
    "bajko": (0.55, -0.10), "eterycz": (0.45, -0.20),
    "melanchol": (-0.35, -0.10), "tesk": (-0.40, -0.15), "smutn": (-0.50, -0.15), "posępn": (-0.70, 0.0), "posepn": (-0.70, 0.0),
    "dark": (-0.80, 0.0), "ciemn": (-0.80, 0.0), "mroczn": (-0.85, 0.05), "ponur": (-0.85, 0.05),
    "agresywn": (-0.60, 0.25), "aggressive": (-0.60, 0.25), "ostr": (-0.55, 0.20),
    "brutal": (-0.90, 0.30), "zabojc": (-0.85, 0.30),
    "powazn": (-0.40, 0.0), "serious": (-0.40, 0.0), "dramatyczn": (-0.45, 0.10),
    "neutral": (0.0, 0.0), "wywazon": (0.0, 0.0),
    "optymistyczn": (0.70, 0.05), "optimistic": (0.70, 0.05), "radosn": (0.70, 0.05), "wesol": (0.70, 0.05),
    "happy": (0.70, 0.05), "sunn": (0.65, 0.05), "sloneczn": (0.65, 0.05),
    "euforicz": (0.90, 0.15), "euphoric": (0.90, 0.15), "eufori": (0.90, 0.15), "upajaja": (0.85, 0.10),
    "epic": (0.30, 0.10), "epick": (0.30, 0.10), "heroicz": (0.35, 0.10), "uroczyst": (0.30, 0.05),
    "zwaw": (0.60, 0.20), "upbeat": (0.60, 0.20), "zyw": (0.55, 0.15), "zyzn": (0.55, 0.15), "energicz": (0.60, 0.20),
}

# skala / modus (klucze dopasowywane od prefiksu, żeby łapać odmiany)
SCALE_PREFIXES = {
    "mod": "minor", "moll": "minor", "minor": "minor", "molowa": "minor", "molow": "minor",
    "dur": "major", "major": "major", "durow": "major",
    "dorian": "dorian", "dor": "dorian", "doryck": "dorian", "doryjsk": "dorian",
    "phrygian": "phrygian", "frygijsk": "phrygian", "fryg": "phrygian",
    "lydian": "lydian", "lidyjsk": "lydian", "lid": "lydian",
    "mixolyd": "mixolydian", "miksolidyjsk": "mixolydian", "mikso": "mixolydian",
    "harmoniczna": "harmonic minor", "harmonic": "harmonic minor", "harmoni": "harmonic minor",
    "harmonic minor": "harmonic minor", "harmoniczna molowa": "harmonic minor", "harmoniczna moll": "harmonic minor",
}

# tonacja (NOTE_NAMES: C, C#, D, D#, E, F, F#, G, G#, A, A#, B)
_KEY_PL = {"c": 0, "cis": 1, "d": 2, "dis": 3, "e": 4, "f": 5, "fis": 6,
           "g": 7, "gis": 8, "a": 9, "ais": 10, "h": 11, "b": 11, "bes": 10}
_KEY_GLUED = {}
for _k, _i in (("c", 0), ("d", 2), ("e", 4), ("f", 5), ("g", 7), ("a", 9), ("h", 11), ("b", 11),
               ("cis", 1), ("dis", 3), ("fis", 6), ("gis", 8), ("ais", 10)):
    _KEY_GLUED[_k + "moll"] = (_i, "minor")
    _KEY_GLUED[_k + "m"] = (_i, "minor")
    _KEY_GLUED[_k + "dur"] = (_i, "major")
    if _k in ("c", "d", "e", "f", "g", "a", "h", "b"):
        _KEY_GLUED[_k + "maj"] = (_i, "major")

# barwa → preferowane barwy z timbre_bank (kolejność = priorytet)
TIMBRE_WORDS = {
    "midtones": ["pad_warm", "lead_soft_key", "stab_tight", "bass_reese_wide"],
    "mid": ["pad_warm", "lead_soft_key", "stab_tight", "bass_reese_wide"],
    "posrednie pasmo": ["pad_warm", "lead_soft_key", "stab_tight", "bass_reese_wide"],
    "bright": ["lead_glass", "keys_bell", "fx_bright_zap", "lead_supersaw_wide"],
    "jasn": ["lead_glass", "keys_bell", "fx_bright_zap", "lead_supersaw_wide"],
    "jaskraw": ["lead_glass", "keys_bell", "fx_bright_zap", "lead_supersaw_wide"],
    "dark": ["bass_wobble_dark", "bass_deep_sub", "pad_hollow_space", "bass_growl_vowel"],
    "ciemn": ["bass_wobble_dark", "bass_deep_sub", "pad_hollow_space", "bass_growl_vowel"],
    "mroczn": ["bass_wobble_dark", "bass_deep_sub", "pad_hollow_space", "bass_growl_vowel"],
    "warm": ["pad_warm", "pad_strings_lush", "bass_deep_sub", "lead_soft_key"],
    "ciepl": ["pad_warm", "pad_strings_lush", "bass_deep_sub", "lead_soft_key"],
    "glass": ["lead_glass"], "szklan": ["lead_glass"], "krysztal": ["lead_glass"],
    "bell": ["keys_bell"], "dzwonk": ["keys_bell"], "dzwoneczk": ["keys_bell"],
    "hollow": ["pad_hollow_space"], "przestrzenn": ["pad_hollow_space"], "pust": ["pad_hollow_space"],
    "airy": ["lead_theremin_airy"], "powietrz": ["lead_theremin_airy"], "wietrz": ["lead_theremin_airy"],
    "sub": ["bass_deep_sub"], "glebok": ["bass_deep_sub"], "gleboki": ["bass_deep_sub"],
    "wobbl": ["bass_wobble_dark"], "wob": ["bass_wobble_dark"],
    "reese": ["bass_reese_wide"],
    "acid": ["bass_acid_squelch"], "squelch": ["bass_acid_squelch"],
    "growl": ["bass_growl_vowel"], "warcz": ["bass_growl_vowel"],
    "nasal": ["lead_nasal"], "nosow": ["lead_nasal"],
    "supersaw": ["lead_supersaw_wide"], "szerok": ["lead_supersaw_wide"],
    "strings": ["pad_strings_lush"], "smyczk": ["pad_strings_lush"],
    "choir": ["vox_choirish"], "choraln": ["vox_choirish"], "wokaln": ["vox_choirish"],
    "soft": ["lead_soft_key"], "miekk": ["lead_soft_key"],
    "zap": ["fx_bright_zap"], "stab": ["stab_tight"],
    "pad": ["pad_warm", "pad_strings_lush", "pad_hollow_space"], "padow": ["pad_warm", "pad_strings_lush", "pad_hollow_space"],
    "lush": ["pad_strings_lush"], "bujn": ["pad_strings_lush"],
}

# epoka (klucze-prefiksy)
ERA_PREFIXES = {
    "70s": "minimal_70s", "70": "minimal_70s", "lata70": "minimal_70s",
    "80s": "analog_80s", "80": "analog_80s", "lata80": "analog_80s", "retro": "analog_80s", "vintage": "analog_80s",
    "90s": "digital_90s", "90": "digital_90s", "lata90": "digital_90s",
    "2000s": "rave_00s", "2000": "rave_00s", "rave": "rave_00s", "raveow": "rave_00s",
    "2010s": "modern_10s", "2010": "modern_10s", "modern": "modern_10s", "nowoczesn": "modern_10s",
    "maximal": "maximal_now", "teraz": "maximal_now", "now": "maximal_now",
}

# spektakularność
SPECT_WORDS = {
    "monotonn": "monotone", "monotoniczn": "monotone", "monotone": "monotone",
    "prost": "plain", "plain": "plain", "skromn": "plain",
    "zbalansowan": "balanced", "balanced": "balanced",
    "barwn": "vivid", "vivid": "vivid", "koloro": "vivid",
    "anthem": "anthem", "spektakularn": "anthem", "hymn": "anthem",
}

# swing / przewidywalność / zmienność
SWING_WORDS = {"swing": 0.08, "swinguja": 0.10, "swinguje": 0.08, "shuffle": 0.12,
               "prosto": 0.0, "straight": 0.0, "rowno": 0.0}
PREDICT_PREFIXES = {"przewidywaln": 0.9, "predict": 0.9, "regularn": 0.85,
                    "nieprzewidywaln": 0.25, "surprise": 0.2, "niespodziank": 0.25}
VARIETY_PREFIXES = {"zmienn": 0.85, "odmienn": 0.8, "rozn": 0.75, "urozn": 0.75,
                    "stabiln": 0.2, "jednolit": 0.25, "powtarzaln": 0.3, "stal": 0.25}

ENERGY_LEVELS = {"nisk": 0.25, "lekk": 0.3, "leniw": 0.25, "slab": 0.25,
                 "sredni": 0.5, "umarkowan": 0.45,
                 "wysok": 0.85, "mocn": 0.8, "maksymaln": 1.0, "max": 1.0}
DENSITY_LEVELS = {"rzadk": 0.3, "sparse": 0.3, "przerzedzon": 0.35, "minimaln": 0.3, "minimalistyczn": 0.3,
                  "sredni": 0.55,
                  "gest": 0.8, "dense": 0.8, "pelna": 0.85, "full": 0.85}
TEMPO_WORDS = {"woln": 100, "slow": 100, "powoln": 90, "leniw": 95,
               "sredni": 130,
               "szybk": 160, "fast": 160, "bystr": 165, "rapid": 170}
LENGTH_WORDS = {"krotk": 64, "short": 64, "mini": 48,
                "sredni": 144,
                "dluzsz": 240, "dlug": 208, "long": 208}

# przedrostki kategorii (odmiany łapie startswith); dokładne słowa słowników mają pierwszeństwo
CATEGORY_PREFIX = [
    ("baza", "style"), ("baz", "style"), ("styl", "style"), ("gatunek", "style"), ("base", "style"),
    ("nastroj", "mood"), ("mood", "mood"), ("klimat", "mood"),
    ("skal", "scale"), ("modus", "scale"),
    ("tonacj", "key"), ("tona", "key"), ("key", "key"), ("tonik", "key"),
    ("barw", "timbre"), ("timbre", "timbre"), ("timbr", "timbre"), ("kolor", "timbre"),
    ("energi", "energy"), ("energy", "energy"), ("sil", "energy"),
    ("gestosc", "density"), ("density", "density"), ("zageszcz", "density"),
    ("tempo", "bpm"), ("bpm", "bpm"),
    ("dlugosc", "bars"), ("dlugosci", "bars"), ("takt", "bars"), ("bars", "bars"),
    ("epoka", "era"), ("era", "era"), ("epok", "era"),
    ("spekt", "spectacle"),
    ("swing", "swing"),
]
# dopasowanie kategorii od 4 znaków tokena (wyjątki krótszych rdzeni niżej)
_PREFIX_SHORT = {"baz", "mod", "sil", "bpm", "era", "epa", "kej"}

FILLERS = {"z", "typem", "typu", "typ", "w", "i", "oraz", "na", "pod", "jako", "dla", "o", "jest",
           "ma", "miec", "maja", "wybieram", "wybor", "przez", "slowo", "slowa", "kluczowe",
           "ustaw", "ustawia", "ustawic", "nastepnie", "paremetry", "parametry", "generator",
           "generatora", "live", "daj", "dac", "se", "so", "the", "with", "and", "of", "a"}

# flagi (przełączniki generate) — prefiksy
FLAG_PREFIXES = {
    "niuanse": ("niuanse", True), "niuans": ("niuanse", True),
    "uniq": ("uniq", True), "unikat": ("uniq", True), "unikalnosc": ("uniq", True), "unikatowosc": ("uniq", True),
    "niepowtarzalnosc": ("uniq", True), "niepowtarzaln": ("uniq", True),
    "drop": ("uniq_drops", True),
    "taneczn": ("dance", True), "dance": ("dance", True), "groove": ("dance", True), "groovey": ("dance", True),
    "tanczn": ("dance", True),
    "arp": ("arp", True), "arpeggio": ("arp", True), "arpeggi": ("arp", True),
    "sztywn": ("strict", True), "zawsze": ("strict", True), "trzymaj": ("strict", True),
}
_NEGATE = {"bez"}
_NEXT_BPM = {"bpm", "tempo"}
_NEXT_BARS = {"takty", "taktow", "takt", "barow", "bars", "taktych"}

_NUM_RE = re.compile(r"^\d+(?:[.,]\d+)?$")
_KEY_RE = re.compile(r"^([a-g])(is|es|#|b|sharp)?(m|moll|dur|maj)?$")


def _match_key(tok):
    """tonacja: „a”, „cis”, „h”, „am”, „cmoll”, „adur”, „f#”… → (index 0-11, skala|None) albo None."""
    if tok in _KEY_PL:
        return _KEY_PL[tok], None
    if tok in _KEY_GLUED:
        return _KEY_GLUED[tok]
    m = _KEY_RE.match(tok)
    if m:
        base = {"a": 9, "c": 0, "d": 2, "e": 4, "f": 5, "g": 7}[m.group(1)]
        acc = m.group(2)
        idx = base + (1 if acc in ("is", "#", "sharp") else (-1 if acc in ("es", "b") else 0))
        idx %= 12
        suf = m.group(3)
        if suf in ("m", "moll"):
            return idx, "minor"
        if suf in ("dur", "maj"):
            return idx, "major"
        return idx, None
    return None


def _prefix_match(tok, table):
    """dokładne lub przedrostkowe dopasowanie tokenu; → wartość albo None."""
    if tok in table:
        return table[tok]
    for k, v in table.items():
        if len(k) >= 4 and tok.startswith(k):
            return v
    return None


def _phrase_prefix_match(tokens, i, table):
    """najdłuższa fraza (do 3 tokenów) — dokładna albo przedrostkowa; → (wartość, długość)."""
    for n in (3, 2, 1):
        ph = " ".join(tokens[i:i + n])
        if ph in table:
            return table[ph], n
    # przedrostki tylko dla pojedynczych tokenów (frazy w stylach są krótkie i pełne)
    v = _prefix_match(tokens[i], table)
    if v is not None:
        return v, 1
    return None, 0


def _tokenize(text):
    """tokeny ZE spójnikami (żeby frazy „drum and bass” się sklejały); spójniki pomija pętla parse()."""
    t = fold(text)
    t = t.replace("-", "").replace(":", " ").replace("=", " ").replace("%", " ")
    return [x for x in re.split(r"[·•,;/()\[\]\s]+", t) if x]


def _num(tok):
    try:
        return float(tok.replace(",", "."))
    except (ValueError, AttributeError):
        return None


def parse(text) -> dict:
    """Słowa kluczowe → {'scene': {...}, 'extra': {...}, 'hits': [...], 'unknown': [...]}. Góra tego pliku."""
    tokens = _tokenize(text)
    scene: dict = {}
    extra: dict = {}
    hits: list = []
    unknown: list = []
    cat = None            # aktywna kategoria (baza/nastrój/barwa/energia…)
    negate_next = False
    energy_set = False

    i, n = 0, len(tokens)
    while i < n:
        tok = tokens[i]

        if tok in FILLERS and not (cat == "key" and tok in _KEY_PL):   # spójniki do sklejania fraz;
            i += 1                                                     # pod „tonacja/…": „a”/„h” = nuta, nie spójnik
            continue

        if tok in _NEGATE:                                   # „bez niuansów” → wyłącz
            negate_next = True
            i += 1
            continue

        # --- liczby z kontekstem -------------------------------------------------
        if _NUM_RE.match(tok):
            v = _num(tok)
            nxt = tokens[i + 1] if i + 1 < n else ""
            if cat == "era":                                # „epoka 90” → 90s
                ev = _prefix_match(str(int(v)), ERA_PREFIXES) or _prefix_match(tok, ERA_PREFIXES)
                if ev is not None:
                    scene["era"] = ev
                    hits.append(f"epoka {ev}")
                    i += 1
                    cat = None
                    continue
            used_nxt = (nxt in _NEXT_BPM or nxt in _NEXT_BARS) and cat not in ("energy", "density")
            if cat == "bpm" or nxt in _NEXT_BPM:            # „172 bpm” albo „bpm 172” (kategoria przed liczbą)
                scene["bpm"] = int(_clamp(v, 60, 200))
                hits.append(f"bpm {scene['bpm']}")
            elif cat == "bars" or nxt in _NEXT_BARS:
                scene["bars"] = int(_clamp(round(v / 8) * 8, 32, 256))
                hits.append(f"{scene['bars']} taktów")
            elif cat == "energy":
                scene["energy"] = _clamp(v / 100.0, 0.0, 1.0)
                energy_set = True
                hits.append(f"energia {scene['energy']:.2f}")
            elif cat == "density":
                scene["density"] = _clamp(v / 100.0, 0.0, 1.0)
                hits.append(f"gęstość {scene['density']:.2f}")
            elif 60 <= v <= 200:
                scene["bpm"] = int(v)
                hits.append(f"bpm {scene['bpm']}")
            elif 32 <= v <= 256 and v % 8 == 0:
                scene["bars"] = int(v)
                hits.append(f"{scene['bars']} taktów")
            else:
                unknown.append(tok)
            i += 2 if used_nxt else 1                        # znacznik jednostki za liczbą też skonsumowany
            cat = None
            continue

        # --- styl (fraza 2–3 słowa / alias / pełna nazwa z ORDER) ----------------
        val, ln = _phrase_prefix_match(tokens, i, STYLE_PREFIXES)
        if val is not None and cat in (None, "style"):
            scene["style"] = val
            hits.append(f"baza → {val}")
            i += ln
            cat = None
            continue
        if cat == "style":
            v2 = _match_style_name(tokens, i)
            if v2 is not None:
                scene["style"] = v2[0]
                hits.append(f"baza → {v2[0]}")
                i += v2[1]
                cat = None
                continue

        # --- nastrój --------------------------------------------------------------
        mv = _prefix_match(tok, MOOD_WORDS)
        if mv is not None and cat in (None, "mood"):
            m, eh = mv
            scene["director_on"] = True
            scene["director_mood"] = m
            hits.append(f"nastrój → {m:+.2f}")
            if eh and not energy_set:
                scene.setdefault("energy", _clamp(0.6 + eh, 0.05, 1.0))
                energy_set = True
            i += 1
            cat = None
            continue

        # --- skala / modus --------------------------------------------------------
        if cat in (None, "scale", "mood", "key"):
            sv, sln = _phrase_prefix_match(tokens, i, SCALE_PREFIXES)
            if sv is not None:
                scene["scale"] = sv
                hits.append(f"skala {sv}")
                i += sln
                cat = None
                continue

        # --- tonacja --------------------------------------------------------------
        if cat in ("key", None, "mood"):
            km = _match_key(tok)
            if km is not None and (cat == "key" or _KEY_RE.match(tok)):
                extra["key"] = km[0]
                hits.append(f"tonacja {note_name(km[0])}")
                if km[1]:
                    scene["scale"] = km[1]
                i += 1
                cat = None
                continue

        # --- barwa ----------------------------------------------------------------
        tv = _prefix_match(tok, TIMBRE_WORDS)
        if tv is not None and cat in (None, "timbre"):
            ids = list(tv)
            extra.setdefault("timbre_pref", [])
            extra["timbre_pref"] += [x for x in ids if x not in extra["timbre_pref"]]
            hits.append(f"barwa → {ids[0]}" + (f" (+{len(ids) - 1})" if len(ids) > 1 else ""))
            i += 1
            cat = None
            continue

        # --- epoka ----------------------------------------------------------------
        ev = _prefix_match(tok, ERA_PREFIXES)
        if ev is not None:
            scene["era"] = ev
            hits.append(f"epoka {ev}")
            i += 1
            cat = None
            continue

        # --- spektakularność ------------------------------------------------------
        spv = _prefix_match(tok, SPECT_WORDS)
        if spv is not None:
            scene["spectacle"] = spv
            hits.append(f"spektakl {spv}")
            i += 1
            cat = None
            continue

        # --- swing ----------------------------------------------------------------
        if tok in SWING_WORDS:
            scene["swing"] = SWING_WORDS[tok]
            hits.append(f"swing {scene['swing']:.2f}")
            i += 1
            cat = None
            continue

        # --- przewidywalność / zmienność ------------------------------------------
        pv = _prefix_match(tok, PREDICT_PREFIXES)
        if pv is not None:
            extra["predict"] = pv
            hits.append(f"przewidywalność {pv:.2f}")
            i += 1
            cat = None
            continue
        vv = _prefix_match(tok, VARIETY_PREFIXES)
        if vv is not None:
            extra["variety"] = vv
            hits.append(f"zmienność {vv:.2f}")
            i += 1
            cat = None
            continue

        # --- flagi (z opcjonalną siłą liczbową) -----------------------------------
        fv = _prefix_match(tok, FLAG_PREFIXES)
        if fv is not None:
            key, on = fv
            if negate_next:
                on = False
                negate_next = False
            strength = None
            if i + 1 < n and _NUM_RE.match(tokens[i + 1]) and _num(tokens[i + 1]) is not None and _num(tokens[i + 1]) <= 100:
                # „niuanse 96 taktów” — liczba z jednostką za nią to NIE siła flagi, tylko wartość (takty/bpm)
                nxt2 = tokens[i + 2] if i + 2 < n else ""
                if nxt2 not in (_NEXT_BARS | _NEXT_BPM):
                    strength = _clamp(_num(tokens[i + 1]) / 100.0, 0.0, 1.0)
                    i += 1
            if key == "niuanse":
                scene["niuanse"] = on
                scene["niuanse_strength"] = strength if strength is not None else (0.5 if on else 0.0)
                hits.append("niuanse włączone" if on else "niuanse wyłączone")
            elif key == "uniq":
                scene["uniq"] = on
                if on:
                    scene["uniq_strength"] = strength if strength is not None else 0.6
                hits.append("niepowtarzalność włączona" if on else "niepowtarzalność wyłączona")
            elif key == "uniq_drops":
                scene["uniq_drops"] = on
                if on:
                    hits.append("unikalne także dropy")
            elif key == "dance":
                scene["dance"] = on
                scene["dance_strength"] = strength if strength is not None else 0.6
                hits.append("rytmy taneczne włączone" if on else "rytmy taneczne wyłączone")
            elif key == "arp":
                extra["arp"] = on
                hits.append("arp włączony" if on else "arp wyłączony")
            elif key == "strict":
                extra["strict"] = bool(on)
                hits.append("sztywno (Live: nie losuj tych pól)")
            i += 1
            continue

        # --- poziomy z kontekstem kategorii ---------------------------------------
        if cat == "energy":
            lv = _prefix_match(tok, ENERGY_LEVELS)
            if lv is not None:
                scene["energy"] = lv
                energy_set = True
                hits.append(f"energia {lv:.2f}")
                i += 1
                continue
        if cat == "density":
            lv = _prefix_match(tok, DENSITY_LEVELS)
            if lv is not None:
                scene["density"] = lv
                hits.append(f"gęstość {lv:.2f}")
                i += 1
                continue
        if cat == "bpm":
            lv = _prefix_match(tok, TEMPO_WORDS)
            if lv is not None:
                scene["bpm"] = lv
                hits.append(f"bpm {lv}")
                i += 1
                continue
        if cat == "bars":
            lv = _prefix_match(tok, LENGTH_WORDS)
            if lv is not None:
                scene["bars"] = lv
                hits.append(f"{lv} taktów")
                i += 1
                continue
        if cat == "mood":
            lv = _prefix_match(tok, ENERGY_LEVELS)      # „nastrój łagodny/żwawy”
            if lv is not None:
                m = _clamp((lv - 0.5) * 1.6, -1.0, 1.0)
                scene["director_on"] = True
                scene["director_mood"] = m
                hits.append(f"nastrój → {m:+.2f}")
                i += 1
                continue

        # --- przedrostek kategorii — PRZED poziomami bez kontekstu, żeby rzeczowniki
        # kategorii („gęstość”, „energia”, „długość”) nie były brane za poziom --------
        hit_cat = None
        for pref, cname in CATEGORY_PREFIX:
            if tok.startswith(pref) and (len(tok) >= 4 or pref in _PREFIX_SHORT):
                hit_cat = cname
                break
        if hit_cat is not None:
            cat = hit_cat
            i += 1
            continue

        # --- przymiotnik + rzeczownik kategorii („średnia gęstość”, „wolne tempo”) ----
        if i + 1 < n:
            nxt_cat = None
            for pref, cname in CATEGORY_PREFIX:
                if tokens[i + 1].startswith(pref) and (len(tokens[i + 1]) >= 4 or pref in _PREFIX_SHORT):
                    nxt_cat = cname
                    break
            if nxt_cat in ("energy", "density", "bpm", "bars"):
                lv2 = _level_for(nxt_cat, tok)
                if lv2 is not None:
                    kk = {"energy": "energy", "density": "density", "bpm": "bpm", "bars": "bars"}[nxt_cat]
                    scene[kk] = lv2
                    if kk == "energy":
                        energy_set = True
                    hits.append(f"{ {'energy': 'energia', 'density': 'gęstość', 'bpm': 'bpm', 'bars': 'takty'}[kk] } {lv2}{'' if kk != 'bars' else ''}")
                    i += 2                                       # poziom + rzeczownik kategorii
                    continue

        # --- poziomy bez kontekstu (energia → gęstość → tempo → długość) -----------
        lv = _prefix_match(tok, ENERGY_LEVELS)
        if lv is not None:
            scene["energy"] = lv
            energy_set = True
            hits.append(f"energia {lv:.2f}")
            i += 1
            continue
        lv = _prefix_match(tok, DENSITY_LEVELS)
        if lv is not None:
            scene["density"] = lv
            hits.append(f"gęstość {lv:.2f}")
            i += 1
            continue
        lv = _prefix_match(tok, TEMPO_WORDS)
        if lv is not None:
            scene["bpm"] = lv
            hits.append(f"bpm {lv}")
            i += 1
            continue
        lv = _prefix_match(tok, LENGTH_WORDS)
        if lv is not None:
            scene["bars"] = lv
            hits.append(f"{lv} taktów")
            i += 1
            continue

        unknown.append(tok)
        i += 1

    # domknięcie spójności
    if scene.get("uniq"):
        scene.setdefault("uniq_drops", False)
    return dict(scene=scene, extra=extra, hits=[h for h in hits if h], unknown=unknown)


def _level_for(cat, tok):
    """poziom dla kategorii: najpierw jej własna tabela, potem generyczne niski/średni/wysoki."""
    tables = {"energy": ENERGY_LEVELS, "density": DENSITY_LEVELS, "bpm": TEMPO_WORDS, "bars": LENGTH_WORDS}
    t = tables.get(cat)
    if not t:
        return None
    v = _prefix_match(tok, t)
    if v is not None:
        return v
    g = _prefix_match(tok, ENERGY_LEVELS)            # generyczne: niski/średni/wysoki/max
    if g is None:
        return None
    gen = {"energy": g,
           "density": {0.25: 0.3, 0.3: 0.35, 0.5: 0.55, 0.8: 0.8, 0.85: 0.85, 1.0: 0.85}.get(g, 0.55),
           "bpm": {0.25: 100, 0.3: 105, 0.5: 130, 0.8: 155, 0.85: 160, 1.0: 165}.get(g, 130),
           "bars": {0.25: 64, 0.3: 72, 0.5: 144, 0.8: 200, 0.85: 208, 1.0: 224}.get(g, 144)}
    return gen.get(cat)


def _match_style_name(tokens, i):
    """pełna nazwa stylu z ORDER napisana słowami (np. „Space Electronica”) po fold; → (nazwa, liczba tokenów)."""
    try:
        from . import styles as ST
        names = {fold(x): x for x in ST.ORDER}
    except Exception:
        names = {}
    for ntok in (3, 2, 1):
        ph = " ".join(tokens[i:i + ntok])
        if ph in names:
            return names[ph], ntok
    return None


def note_name(idx):
    return ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"][int(_clamp(idx, 0, 11))]


# ------------------------------------------------------------------ pomoc (GUI / CLI)
def help_text() -> str:
    try:
        from . import styles as ST
        order = ", ".join(ST.ORDER)
    except Exception:
        order = "(lista stylów niedostępna)"
    return f"""SŁOWA KLUCZOWE — szybkie ustawianie parametrów Generatora

Forma: swobodna (rozdzielacz dowolny: spacja, przecinek, „·”) albo „kategoria wartość”.
Ogonki nie mają znaczenia; odmiany słów są rozpoznawane (bazy/nastroju/barwie…).

KATEGORIE (słowo przed wartością):
  baza / styl / gatunek — jeden z 30 stylów:
      {order}
  nastrój / mood — relaxing, chill, spokojny, dreamy, melancholijny, ciemny/mroczny,
      agresywny, brutalny, poważny, optymistyczny/radosny, euforiczny, epicki, zwawy…
      (ustawia też Reżysera i sugeruje energię)
  skala / modus — mod/moll, dur/major, dorycka, frygijska, lidyjska, miksolidyjska, harmoniczna
  tonacja / key — c, cis, d, dis, e, f, fis, g, gis, a, ais, h/b; też „am”, „cmoll”, „adur”, „f#”
  barwa / timbre — midtones, jasna/bright, ciemna/dark, ciepła/warm, szklana, dzwonkowa,
      przestrzenna, powietrzna, sub/głęboki, wobble, reese, acid, growl, nosowa, supersaw,
      smyczki, chóralna, miękka, pad, bujna… (preferuje je Aranżer — włącza się sam)
  energia — niska/średnia/wysoka/max albo liczba 0–100
  gęstość — rzadka/średnia/gęsta/pełna
  tempo / bpm — wolne/średnie/szybkie albo liczba 60–200
  długość / takty — krótka/średnia/długa albo liczba (np. „96 taktów”)
  epoka / era — 70s, 80s/retro, 90s, 2000s/rave, 2010s, teraz/maximal
  spektakl — monotonna, prosta, zbalansowana, barwna/vivid, anthem
  swing — swing / prosto

FLAGI: niuanse [0–100], uniq/niepowtarzalność, dropy (unikalne dropy), taneczne/dance [0–100],
  arp, sztywno/zawsze (Live: pola ze słów nie są losowane), przewidywalne/nieprzewidywalne,
  zmienne/stabilne. „bez X” wyłącza flagę (np. „bez niuansów”).

PRZYKŁADY:
  baza dnb · nastrój relaxing · mod · barwa midtones · energia średnia · 174 bpm
  liquid neuro bez niuansów, 96 taktów, epoka 90s, barwa ciepła
  techno ciemny sztywno · gesta · barwa acid · uniq
  am · epicki · anthem · dluga · bright        (swobodnie, bez kategorii)

Nierozpoznane słowa są pokazywane w statusie (nie blokują pozostałych)."""
