"""tests/test_keywords.py — wybór parametrów Generatora przez słowa kluczowe.

Sprawdza przykład z review („baza dnb · nastrój relaxing · mod · barwa midtones”),
swobodny zapis bez kategorii, odmiany/ogonki, frazy stylów i skal, flagi z „bez X”,
„sztywno”, liczby z jednostkami, preferencje barw w Aranżerze oraz integrację generate().

Uruchomienie:  python3 -m unittest tests.test_keywords -v
"""
import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import keywords as KW  # noqa: E402
from dubstep_studio import arranger as ARR  # noqa: E402
from dubstep_studio import timbre_bank as TB  # noqa: E402

try:                                                           # integracja wymaga meta wtyczek (host)
    from dubstep_studio import core  # noqa: E402
    core.meta()
    HOST = True
except Exception:
    HOST = False


class TestParse(unittest.TestCase):

    def test_user_example_full_phrase(self):
        """Dokładny przykład: „baza dnb z typem nastroju relaxing w barwie midtones”."""
        r = KW.parse("baza dnb z typem nastroju relaxing w barwie midtones")
        self.assertEqual(r["scene"]["style"], "DnB")
        self.assertEqual(r["scene"]["director_mood"], 0.30)
        self.assertTrue(r["scene"]["director_on"])
        self.assertEqual(r["extra"]["timbre_pref"],
                         ["pad_warm", "lead_soft_key", "stab_tight", "bass_reese_wide"])
        self.assertEqual(r["unknown"], [])

    def test_free_form_without_categories(self):
        r = KW.parse("dnb relaxing midtones, mod, 174 bpm, energia srednia, 96 taktow")
        self.assertEqual(r["scene"]["style"], "DnB")
        self.assertEqual(r["scene"]["bpm"], 174)
        self.assertEqual(r["scene"]["bars"], 96)
        self.assertEqual(r["scene"]["scale"], "minor")
        self.assertAlmostEqual(r["scene"]["energy"], 0.5, places=9)
        self.assertTrue(r["extra"]["timbre_pref"])

    def test_diakrytyki_i_odmiany(self):
        r1 = KW.parse("baza dnb, nastrój mroczny, barwa ciepła, gęstość rzadka")
        r2 = KW.parse("baza dnb, nastroju mrocznego, barwie cieplejszej, gestosc rzadka")
        for r in (r1, r2):
            self.assertEqual(r["scene"]["style"], "DnB")
            self.assertLess(r["scene"]["director_mood"], -0.7)
            self.assertEqual(r["scene"]["density"], 0.3)
            self.assertEqual(r["extra"]["timbre_pref"][0], "pad_warm")

    def test_style_phrases_and_prefixes(self):
        for text, name in (("drum and bass", "DnB"), ("liquid dnb", "Liquid DnB"),
                           ("techno", "Techno"), ("acid", "Acid Techno"), ("psy", "Psytrance")):
            self.assertEqual(KW.parse(text)["scene"]["style"], name, text)

    def test_scale_phrases(self):
        self.assertEqual(KW.parse("skala harmonic minor")["scene"]["scale"], "harmonic minor")
        self.assertEqual(KW.parse("harmoniczna molowa")["scene"]["scale"], "harmonic minor")
        self.assertEqual(KW.parse("mod")["scene"]["scale"], "minor")
        self.assertEqual(KW.parse("dur")["scene"]["scale"], "major")

    def test_keys(self):
        self.assertEqual(KW.parse("tonacja a")["extra"]["key"], 9)
        self.assertEqual(KW.parse("am")["extra"]["key"], 9)
        self.assertEqual(KW.parse("cmoll")["extra"]["key"], 0)
        self.assertEqual(KW.parse("fis")["extra"]["key"], 6)
        self.assertEqual(KW.parse("am")["scene"]["scale"], "minor")

    def test_flags_negation_strict_strength(self):
        r = KW.parse("liquid dnb sztywno bez niuansów am epoka 90s uniq 80")
        self.assertEqual(r["scene"]["style"], "Liquid DnB")
        self.assertTrue(r["extra"]["strict"])
        self.assertFalse(r["scene"]["niuanse"])
        self.assertEqual(r["scene"]["era"], "digital_90s")
        self.assertAlmostEqual(r["scene"]["uniq_strength"], 0.8, places=9)

    def test_numbers_with_units(self):
        r = KW.parse("dnb 172 bpm 64 taktów")
        self.assertEqual(r["scene"]["bpm"], 172)
        self.assertEqual(r["scene"]["bars"], 64)
        r2 = KW.parse("dnb niuanse 96 taktów")             # liczba z jednostką ≠ siła flagi
        self.assertEqual(r2["scene"]["bars"], 96)
        self.assertTrue(r2["scene"]["niuanse"])

    def test_unknown_reported_not_blocking(self):
        r = KW.parse("dnb kwarcintone relaxing")
        self.assertEqual(r["scene"]["style"], "DnB")
        self.assertIn("kwarcintone", r["unknown"])
        self.assertEqual(r["scene"]["director_mood"], 0.30)

    def test_help_text_lists_vocabulary(self):
        h = KW.help_text()
        for w in ("dnb", "midtones", "relaxing", "energia", "epoka", "sztywno"):
            self.assertIn(w, h.lower())


class TestTimbrePrefArranger(unittest.TestCase):

    def test_normalize_filters_unknown_ids(self):
        o = ARR.normalize({"on": True, "timbre_pref": ["nie_ma_takiego", "pad_warm", 42]})
        self.assertEqual(o["timbre_pref"], ["pad_warm"])

    def test_normalize_default_empty(self):
        self.assertEqual(ARR.normalize({})["timbre_pref"], [])

    def test_step_timbres_prefers_keyword_timbre(self):
        proj = {"tracks": [{"name": "sub1", "type": "sub", "plugin": "p",
                            "notes": [{"n": 40, "t": 0, "d": 1, "v": 90}], "params": {}, "gain": 0.6}]}
        o_ = ARR.normalize({"on": True, "use_timbres": True, "adhoc": False,
                            "timbre_pref": ["bass_deep_sub"]})
        rep = {"timbres": [], "layers": [], "extras": [], "wysiwyg": {}, "creator": {}}
        ARR._step_timbres(proj, o_, random.Random(7), 0.5, 0.5, rep, {"timbres": {}})
        self.assertEqual(proj["tracks"][0].get("timbre_id"), "bass_deep_sub")
        self.assertEqual(rep["timbres"][0]["id"], "bass_deep_sub")

    def test_step_timbres_without_pref_still_random(self):
        proj = {"tracks": [{"name": "sub1", "type": "sub", "plugin": "p",
                            "notes": [{"n": 40, "t": 0, "d": 1, "v": 90}], "params": {}, "gain": 0.6}]}
        o_ = ARR.normalize({"on": True, "use_timbres": True, "adhoc": False})
        rep = {"timbres": [], "layers": [], "extras": [], "wysiwyg": {}, "creator": {}}
        ARR._step_timbres(proj, o_, random.Random(7), 1.0, 0.5, rep, {"timbres": {}})
        pool = [k for k, s in TB.TIMBRES.items() if s["base"] == "sub"]
        self.assertIn(proj["tracks"][0].get("timbre_id"), pool)


@unittest.skipUnless(HOST, "brak meta wtyczek (host) — pomijam integrację")
class TestGeneratorIntegration(unittest.TestCase):

    def test_generate_with_timbre_pref_enables_timbres(self):
        """„barwa …” sama włącza barwy aranżera (bez extras/kreatora/WYSIWYG)."""
        from dubstep_studio import generator as G
        inst = ["kick", "snare", "hat", "sub", "wobble", "pad", "piano"]
        p = G.generate("DnB", bars=32, seed=99, instruments=inst,
                       arranger={"on": False, "amount": 1.0},   # słowa „barwa …” mają samo włączyć barwy
                       timbre_pref=["pad_warm", "lead_soft_key"])
        self.assertEqual((p.get("arranger") or {}).get("timbre_pref"), ["pad_warm", "lead_soft_key"])
        self.assertTrue((p.get("arranger") or {}).get("on"))
        self.assertFalse((p.get("arranger") or {}).get("use_extras"))
        ids = [t.get("timbre_id") for t in p["tracks"]]
        self.assertTrue(any(i in ("pad_warm", "lead_soft_key") for i in ids),
                        f"brak barwy ze słów na torach: {ids}")
        self.assertIn("arranger_report", p)

    def test_generate_without_words_unchanged(self):
        from dubstep_studio import generator as G
        p = G.generate("Brostep", bars=32, seed=11)
        self.assertNotIn("timbre_pref", (p.get("arranger") or {}))


if __name__ == "__main__":
    unittest.main()
