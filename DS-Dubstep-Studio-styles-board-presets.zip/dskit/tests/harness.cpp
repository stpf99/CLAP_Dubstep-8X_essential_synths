// harness.cpp — mini-host: ładuje .clap, gra nuty, sprawdza NaN/peak/RMS, zapisuje demo WAV
#include <clap/clap.h>
#include <dlfcn.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>

static const void* h_ext(const clap_host_t*, const char*) { return nullptr; }
static void h_noop(const clap_host_t*) {}
static clap_host_t HOST = {CLAP_VERSION_INIT, nullptr, "harness", "t", "", "1", h_ext, h_noop, h_noop, h_noop};

struct EvList { std::vector<clap_event_note_t> v; };
static uint32_t ev_size(const clap_input_events_t* l) { return (uint32_t)((EvList*)l->ctx)->v.size(); }
static const clap_event_header_t* ev_get(const clap_input_events_t* l, uint32_t i) { return &((EvList*)l->ctx)->v[i].header; }
static bool out_push(const clap_output_events_t*, const clap_event_header_t*) { return true; }

static void wav(const char* path, const std::vector<float>& L, const std::vector<float>& R, int sr) {
  FILE* f = fopen(path, "wb"); uint32_t n = (uint32_t)L.size(), dl = n * 4, rl = 36 + dl, sr32 = sr, br = sr * 4;
  uint16_t fmt = 1, ch = 2, ba = 4, bps = 16; uint32_t fl = 16;
  fwrite("RIFF", 1, 4, f); fwrite(&rl, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); fwrite(&fl, 4, 1, f);
  fwrite(&fmt, 2, 1, f); fwrite(&ch, 2, 1, f); fwrite(&sr32, 4, 1, f); fwrite(&br, 4, 1, f);
  fwrite(&ba, 2, 1, f); fwrite(&bps, 2, 1, f); fwrite("data", 1, 4, f); fwrite(&dl, 4, 1, f);
  for (uint32_t i = 0; i < n; i++) {
    int16_t a = (int16_t)std::lround(std::max(-1.f, std::min(1.f, L[i])) * 32767);
    int16_t b = (int16_t)std::lround(std::max(-1.f, std::min(1.f, R[i])) * 32767);
    fwrite(&a, 2, 1, f); fwrite(&b, 2, 1, f);
  }
  fclose(f);
}

int main(int argc, char** argv) {
  const char* so = argv[1]; const char* outdir = argc > 2 ? argv[2] : nullptr;
  void* h = dlopen(so, RTLD_NOW); if (!h) { printf("dlopen fail %s\n", dlerror()); return 1; }
  auto* entry = (const clap_plugin_entry_t*)dlsym(h, "clap_entry"); if (!entry) { puts("no clap_entry"); return 1; }
  entry->init(so);
  auto* fac = (const clap_plugin_factory_t*)entry->get_factory(CLAP_PLUGIN_FACTORY_ID);
  int bad = 0;
  for (uint32_t k = 0; k < fac->get_plugin_count(fac); k++) {
    auto* d = fac->get_plugin_descriptor(fac, k);
    auto* p = fac->create_plugin(fac, &HOST, d->id);
    if (!p || !p->init(p)) { printf("create fail %s\n", d->id); return 1; }
    auto* pr = (const clap_plugin_params_t*)p->get_extension(p, CLAP_EXT_PARAMS);
    uint32_t np = pr->count(p);
    // sanity parametrów: info/text roundtrip
    for (uint32_t i = 0; i < np; i++) {
      clap_param_info_t in; if (!pr->get_info(p, i, &in)) { puts("get_info fail"); return 1; }
      char t[64]; double v; pr->get_value(p, in.id, &v);
      if (!pr->value_to_text(p, in.id, v, t, 64)) { puts("v2t fail"); return 1; }
      double back; if (!pr->text_to_value(p, in.id, t, &back)) { printf("t2v fail %s '%s'\n", in.name, t); bad++; }
    }
    const double sr = 48000; p->activate(p, sr, 32, 512);
    p->start_processing(p);
    // wzorzec: 2 takty 140 BPM (1 takt = 1.714 s) -> gramy 3.4 s
    int total = (int)(sr * 3.4); std::vector<float> L(total), R(total);
    std::vector<std::pair<double,std::pair<int,double>>> notes; // start s, (key, len s)
    bool drum = strstr(d->id, "kick") || strstr(d->id, "snare") || strstr(d->id, "hat");
    if (strstr(d->id, "kick")) notes = {{0,{36,0.2}},{0.857,{36,0.2}},{1.714,{36,0.2}},{2.571,{36,0.2}}};
    else if (strstr(d->id, "snare")) notes = {{0.857,{38,0.2}},{2.571,{38,0.2}}};
    else if (strstr(d->id, "hat")) notes = {{0,{42,0.05}},{0.4285,{42,0.05}},{0.857,{42,0.05}},{1.2855,{42,0.05}},{1.714,{42,0.05}},{2.14,{42,0.05}}};
    else notes = {{0,{36,0.8}},{0.857,{36,0.3}},{1.2,{39,0.3}},{1.714,{41,0.8}},{2.4,{34,0.8}}};
    if (strstr(d->id, "screech")) for (auto& n : notes) n.second.first += 24;
    if (strstr(d->id, "sub")) {}
    int B = 512; double bpm = 140; bool failed = false; double peak = 0, rms = 0;
    for (int pos = 0; pos < total; pos += B) {
      int n = std::min(B, total - pos); EvList el;
      for (auto& nt : notes) {
        int on = (int)(nt.first * sr), off = (int)((nt.first + nt.second.second) * sr);
        for (int w = 0; w < 2; w++) {
          int t = w ? off : on; if (t < pos || t >= pos + n) continue;
          clap_event_note_t e{}; e.header.size = sizeof(e); e.header.time = t - pos; e.header.space_id = CLAP_CORE_EVENT_SPACE_ID;
          e.header.type = w ? CLAP_EVENT_NOTE_OFF : CLAP_EVENT_NOTE_ON; e.note_id = -1; e.port_index = 0; e.channel = 0;
          e.key = nt.second.first; e.velocity = 0.9; el.v.push_back(e);
        }
      }
      std::sort(el.v.begin(), el.v.end(), [](auto& a, auto& b) { return a.header.time < b.header.time; });
      clap_input_events_t in{&el, ev_size, ev_get}; clap_output_events_t out{nullptr, out_push};
      float* chans[2] = {L.data() + pos, R.data() + pos};
      clap_audio_buffer_t ab{}; ab.data32 = chans; ab.channel_count = 2;
      clap_event_transport_t tr{}; tr.header.size = sizeof(tr); tr.flags = CLAP_TRANSPORT_HAS_TEMPO; tr.tempo = bpm;
      clap_process_t proc{}; proc.frames_count = n; proc.transport = &tr; proc.audio_outputs = &ab; proc.audio_outputs_count = 1;
      proc.in_events = &in; proc.out_events = &out;
      p->process(p, &proc);
    }
    for (int i = 0; i < total; i++) {
      if (!std::isfinite(L[i]) || !std::isfinite(R[i])) failed = true;
      peak = std::max({peak, (double)std::fabs(L[i]), (double)std::fabs(R[i])}); rms += L[i] * L[i];
    }
    rms = std::sqrt(rms / total);
    // state roundtrip
    printf("%-24s params=%2u peak=%.3f rms=%.3f %s\n", d->name, np, peak, rms, failed ? "NaN/Inf!" : (peak < 0.01 ? "SILENT!" : (peak > 1.0 ? "CLIP>1" : "ok")));
    if (failed || peak < 0.01) bad++;
    if (outdir) { std::string path = std::string(outdir) + "/" + d->name + ".wav"; for (auto& c : path) if (c == ' ') c = '_'; wav(path.c_str(), L, R, 48000); }
    p->stop_processing(p); p->deactivate(p); p->destroy(p);
    (void)drum;
  }
  entry->deinit();
  return bad;
}
