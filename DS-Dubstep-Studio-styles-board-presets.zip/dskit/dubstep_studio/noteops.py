"""noteops.py — operacje na zaznaczonej partii nut (grupa nut w oknie taktów): skala, góra/dół, przetasowanie,
odwrócenie w czasie itd. Funkcje nie mutują wejścia: zwracają nową listę nut [on, dur, key, vel] (beaty)."""
from __future__ import annotations

import random

from .core import NOTE_NAMES

# skale do przyciągania/przesuwania po stopniach (dowolna długość; niezależne od SCALES generatora, które muszą mieć 7 stopni)
NOTE_SCALES = {
    "projektu": None,                              # skala projektu (key + scale)
    "moll": [0, 2, 3, 5, 7, 8, 10], "dur": [0, 2, 4, 5, 7, 9, 11], "frygijska": [0, 1, 3, 5, 7, 8, 10],
    "moll harm.": [0, 2, 3, 5, 7, 8, 11], "dorycka": [0, 2, 3, 5, 7, 9, 10],
    "pentatonika moll": [0, 3, 5, 7, 10], "pentatonika dur": [0, 2, 4, 7, 9], "blues": [0, 3, 5, 6, 7, 10],
    "chromatyczna": list(range(12)),
}

# klucz, etykieta, etykieta parametru (None = bez parametru), domyślny parametr
OPS = [
    ("transpose", "Transpozycja (półtony)", "półtony", 12),
    ("oct_up", "Oktawa w górę", None, 0),
    ("oct_down", "Oktawa w dół", None, 0),
    ("scale_up", "W górę po stopniach skali", "stopnie", 1),
    ("scale_down", "W dół po stopniach skali", "stopnie", 1),
    ("snap", "Przyciągnij do skali", None, 0),
    ("random_scale", "Losowe wysokości w skali", "rozpiętość (półtony)", 12),
    ("reverse", "Odwróć w czasie (backward)", None, 0),
    ("invert", "Odwróć wysokości (lustro)", None, 0),
    ("sort_up", "Wysokości rosnąco (up)", None, 0),
    ("sort_down", "Wysokości malejąco (down)", None, 0),
    ("shuffle_pitch", "Przetasuj wysokości", None, 0),
    ("shuffle_rhythm", "Przetasuj rytm", None, 0),
    ("shuffle_all", "Przetasuj wszystko", None, 0),
    ("rotate", "Rotuj w czasie (kroki 1/16)", "kroki", 2),
    ("stretch", "Rozciągnij / ściśnij (×)", "mnożnik", 2.0),
    ("humanize", "Humanizacja (czas i velocity)", "siła 0-1", 0.5),
    ("thin", "Przerzedź (usuń %)", "%", 30),
    ("repeat", "Powtórz zaznaczenie w kolejnym oknie", None, 0),
]
OP_KEYS = [o[0] for o in OPS]


def scale_pcs(proj, name):
    """Klasy wysokości (0-11) wybranej skali; 'projektu' = key + scale projektu."""
    from .core import SCALES
    if name in (None, "projektu"):
        return sorted((proj["key"] + d) % 12 for d in SCALES[proj["scale"]])
    return sorted((proj["key"] + d) % 12 for d in NOTE_SCALES[name])


def _snap(key, pcs):
    best, bd = key, 99
    for k in range(key - 6, key + 7):
        if k % 12 in pcs and abs(k - key) < bd:
            best, bd = k, abs(k - key)
    return best


def _step(key, pcs, n):
    """Przesuń o n stopni skali (n może być ujemne); najpierw przyciąga nutę do skali."""
    k = _snap(key, pcs)
    d = 1 if n > 0 else -1
    for _ in range(abs(int(n))):
        k += d
        while k % 12 not in pcs:
            k += d
    return k


def select(notes, bar_a, bar_b):
    """Indeksy nut, których początek leży w oknie taktów [bar_a, bar_b) (takt = 4 beaty)."""
    a, b = bar_a * 4 - 1e-6, bar_b * 4 - 1e-6
    return [i for i, n in enumerate(notes) if a <= n[0] < b]


def apply_op(proj, notes, op, bar_a, bar_b, amount=None, scale="projektu", seed=None):
    """-> nowa lista nut z zastosowaną operacją na nutach w oknie [bar_a, bar_b)."""
    rng = random.Random(seed if seed is not None else random.randrange(10 ** 9))
    out = [list(n) for n in notes]
    sel = select(out, bar_a, bar_b)
    if not sel:
        return out
    a, b = bar_a * 4.0, bar_b * 4.0
    pcs = scale_pcs(proj, scale)
    clampk = lambda k: max(0, min(127, int(round(k))))
    amt = amount if amount is not None else next(o[3] for o in OPS if o[0] == op)
    S = [out[i] for i in sel]

    if op == "transpose":
        for n in S: n[2] = clampk(n[2] + amt)
    elif op == "oct_up":
        for n in S: n[2] = clampk(n[2] + 12)
    elif op == "oct_down":
        for n in S: n[2] = clampk(n[2] - 12)
    elif op in ("scale_up", "scale_down"):
        st = abs(int(amt)) * (1 if op == "scale_up" else -1)
        for n in S: n[2] = clampk(_step(n[2], pcs, st))
    elif op == "snap":
        for n in S: n[2] = clampk(_snap(n[2], pcs))
    elif op == "random_scale":
        lo, hi = min(n[2] for n in S), max(n[2] for n in S)
        hi = max(hi, lo + int(amt))
        pool = [k for k in range(lo, hi + 1) if k % 12 in pcs] or [lo]
        for n in S: n[2] = rng.choice(pool)
    elif op == "reverse":                                   # lustrzane odbicie czasu w oknie zaznaczenia
        for n in S:
            n[0] = round(a + b - (n[0] + n[1]), 4)
            if n[0] < a: n[0] = a
    elif op == "invert":
        mid = (min(n[2] for n in S) + max(n[2] for n in S)) / 2.0
        for n in S: n[2] = clampk(2 * mid - n[2])
    elif op in ("sort_up", "sort_down"):
        S.sort(key=lambda n: n[0])
        ks = sorted((n[2] for n in S), reverse=(op == "sort_down"))
        for n, k in zip(S, ks): n[2] = k
    elif op in ("shuffle_pitch", "shuffle_all"):
        S.sort(key=lambda n: n[0])
        ks = [n[2] for n in S]; rng.shuffle(ks)
        for n, k in zip(S, ks): n[2] = k
        if op == "shuffle_all":
            _shuffle_rhythm(S, rng)
    elif op == "shuffle_rhythm":
        S.sort(key=lambda n: n[0]); _shuffle_rhythm(S, rng)
    elif op == "rotate":
        span = b - a; sh = amt * 0.25
        for n in S: n[0] = round(a + ((n[0] - a + sh) % span), 4)
    elif op == "stretch":
        f = float(amt) if amt else 1.0
        for n in S:
            n[0] = round(a + (n[0] - a) * f, 4); n[1] = round(n[1] * f, 4)
    elif op == "humanize":
        k = max(0.0, min(1.0, float(amt)))
        for n in S:
            n[0] = round(max(a, n[0] + rng.uniform(-0.06, 0.06) * k), 4)
            n[3] = max(1, min(127, int(n[3] + rng.randint(-int(14 * k), int(14 * k)))))
    elif op == "thin":
        p = max(0.0, min(100.0, float(amt))) / 100.0
        keep = {id(n) for n in S if rng.random() >= p} or {id(S[0])}
        out = [n for n in out if id(n) in keep or not (a - 1e-6 <= n[0] < b - 1e-6)]
    elif op == "repeat":                                    # kopia okna zaraz za nim (okno x2)
        span = b - a
        out += [[round(n[0] + span, 4), n[1], n[2], n[3]] for n in S]
    else:
        raise ValueError(op)
    out.sort(key=lambda n: (n[0], n[2]))
    return out


def _shuffle_rhythm(S, rng):
    """Permutuje pary (początek, długość) między nutami, wysokości zostają przypisane kolejności."""
    slots = [(n[0], n[1]) for n in S]; rng.shuffle(slots)
    for n, (on, dur) in zip(S, slots):
        n[0], n[1] = on, dur


def describe(proj):
    return f"{NOTE_NAMES[proj['key'] % 12]} {proj['scale']}"
