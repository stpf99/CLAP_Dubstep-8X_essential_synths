"""live.py — tryb Live / Endless: nieskończony strumień bez wstępnego renderowania całości.

Jak to działa:
  * producent (wątek) generuje i renderuje KOLEJNE aranżacje „z wyprzedzeniem" (lookahead) przez wtyczki CLAP,
    dokładnie tyle, ile trzeba, żeby odtwarzanie nigdy nie czekało (render jest kilka razy szybszy niż czas rzeczywisty);
  * odtwarzacz (wątek) wysyła PCM do zewnętrznego odtwarzacza przez stdin (pw-cat/paplay/aplay/ffplay/mpv) — bez plików tymczasowych
    do odsłuchu; ogon (release/reverb-tail) poprzedniej aranżacji nakłada się na początek następnej;
  * każda aranżacja trafia do MAGAZYNU (folder sesji: wav + projekt JSON), można ją przypiąć, wrócić do niej z osi czasu,
    odsłuchać od punktu startowego, wczytać do edytora, zapisać do biblioteki, a zakres zrzucić do MP3;
  * planer następnej aranżacji: tryb „current" (styl i ustawienia z zakładki Generator) albo „random" (losowanie kaskadowe:
    pora dnia -> styl -> wariacja palety/skali/tonacji -> BPM/energia/gęstość/swing/długość), z blokadami „na sztywno".
"""
from __future__ import annotations

import copy
import datetime
import json
import os
import queue
import random
import re
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
import urllib.parse
import urllib.request
import wave
from pathlib import Path

import numpy as np

from . import core, generator as G, styles as ST

SR = core.SR
LATENCY = 0.30            # przybliżone opóźnienie rury+odtwarzacza (s) — tylko do pozycji playheada
CHUNK = 2048              # ramki na zapis do odtwarzacza (~43 ms)

# ------------------------------------------------------------------ pora dnia
TOD_SLOTS = [("Rano", 6, 12), ("Popołudnie", 12, 18), ("Wieczór", 18, 23), ("Noc", 23, 6)]
TOD_DEFAULT = {"Rano": 0.88, "Popołudnie": 1.00, "Wieczór": 1.06, "Noc": 0.90}   # mnożnik BPM stylu
# „klasa tempa/ostrości" stylu: 0 = najspokojniejszy … 5 = najostrzejszy (do ważenia losowania wg pory dnia)
STYLE_CLASS = ST.STYLE_CLASS
ACOUSTIC = ["theremin", "panflute", "handpan", "tongue"]
SCALE_W = {"minor": 0.5, "phrygian": 0.3, "harmonic minor": 0.2}
LOCK_KEYS = ["style", "bpm", "key", "scale", "energy", "density", "swing", "bars", "instruments"]

DEFAULT_CFG = dict(
    mode="current",                       # "current" | "random"
    locks={k: False for k in LOCK_KEYS},  # w trybie random: True = wartość z zakładki Generator, nie jest losowana
    tod_on=True, tod_force=None, tod_factors=dict(TOD_DEFAULT),
    arr_bars=32, lookahead=1, max_store=60, return_live=True,
    use_board=False, board=[], board_strength=0.4,   # pole szachowe (styl multihybrydowy)
    mutate_p=0.0,                                    # random: szansa (0..1), że wylosowany styl zostanie zmutowany (hybryda)
)


def tod_slot(hour=None):
    h = datetime.datetime.now().hour if hour is None else hour
    for n, a, b in TOD_SLOTS:
        if (a <= h < b) if a < b else (h >= a or h < b):
            return n
    return "Noc"


def _wchoice(rng, items, weights):
    r = rng.uniform(0, sum(weights)); acc = 0.0
    for it, w in zip(items, weights):
        acc += w
        if r <= acc:
            return it
    return items[-1]


# ------------------------------------------------------------------ planer
def _min_bars(style, bars):
    """Generator daje każdej sekcji szablonu min. 4 takty — krótsza aranżacja niż 4×(liczba sekcji) nie istnieje."""
    return max(int(bars), 4 * len(G.STYLES[style]["template"]))


def style_class(style):
    pts = G.STYLES.parts(style)
    return sum(STYLE_CLASS.get(n, 2.5) * w for n, w in pts.items())


def _board_style(cfg):
    cells = [tuple(x) for x in cfg.get("board") or []]
    return ST.board_name(cells, float(cfg.get("board_strength", 0.4))) if cells else None


def _mutate_style(style, rng):
    """Losowa mutacja: styl + partner z innej grupy w proporcji 15–45 %."""
    grp = next((i for i, (_, ss) in enumerate(ST.GROUPS) if style in ss), None)
    pool = [s_ for i, (_, ss) in enumerate(ST.GROUPS) if i != grp for s_ in ss]
    if style not in G.STYLES or not pool:
        return style
    sh = rng.uniform(0.15, 0.45)
    return ST.hybrid_name({style: 1 - sh, rng.choice(pool): sh}) or style


def plan_next(cfg, base, rng, avail, hour=None):
    """-> {"kw": argumenty generate(), "slot", "factor", "desc"}.
    base = bieżące ustawienia zakładki Generator: style,bpm,key(None=losowa),scale,energy,density,swing,instruments,speak_text,speak_theme."""
    slot = cfg.get("tod_force") or tod_slot(hour)
    f = float(cfg["tod_factors"].get(slot, 1.0)) if cfg.get("tod_on") else 1.0
    L = cfg["locks"]; avail = set(avail)
    speak = dict(speak_text=base.get("speak_text"), speak_theme=base.get("speak_theme"))
    if cfg["mode"] != "random":      # styl i ustawienia dokładnie jak w Generatorze; zmienia się tylko seed (i tonacja przy „auto")
        bs = _board_style(cfg) if cfg.get("use_board") else None
        sty = bs or base["style"]
        kw = dict(style=sty, bpm=base["bpm"], key=base["key"], scale=base["scale"], bars=_min_bars(sty, cfg["arr_bars"]), energy=base["energy"],
                  density=base["density"], swing=base["swing"], instruments=[t for t in base["instruments"] if t in avail], **speak)
        return dict(kw=kw, slot=slot, factor=1.0, desc="pole szachowe → " + sty if bs else "styl z Generatora")

    # --- kaskada: (1) pora dnia -> (2) styl -> (3) wariacja -> (4) tempo/energia -> (5) reszta
    styles = list(G.STYLES)
    if L["style"]:
        style = base["style"]
    elif cfg.get("tod_on"):
        target = max(0.0, min(5.0, 1.0 + (f - 0.88) / 0.20 * 4.0))      # wolna pora -> spokojne style, szybka -> ostre
        style = _wchoice(rng, styles, [2.718 ** (-((style_class(s) - target) ** 2) / (2 * 1.8 ** 2)) for s in styles])
    else:
        style = rng.choice(styles)
    if not L["style"] and rng.random() < float(cfg.get("mutate_p", 0.0)):      # mutacja: pole szachowe użytkownika albo losowy partner
        style = (_board_style(cfg) if cfg.get("use_board") else None) or _mutate_style(style, rng)
    cs = G.STYLES[style]
    # wariacja palety instrumentów stylu
    if L["instruments"]:
        inst = [t for t in base["instruments"] if t in avail]
    else:
        ex = [t for t in cs.get("extras", []) if t in avail]
        k = rng.randint(max(2, len(ex) // 2), len(ex)) if ex else 0
        inst = list(cs.get("core", core.CORE8)) + rng.sample(ex, k)
        ac = [t for t in ACOUSTIC if t in avail]
        if ac and rng.random() < 0.2:
            inst.append(rng.choice(ac))
    # tempo: bazowe BPM stylu * rozrzut * pora dnia, w widełkach 0.80–1.08 BPM stylu
    if L["bpm"]:
        bpm = base["bpm"]
    else:
        b0 = cs["bpm"]
        bpm = int(round(max(0.80 * b0, min(1.08 * b0, b0 * rng.uniform(0.95, 1.04) * f))))
    # energia: zakres stylu, lekko skalowana porą dnia
    sc_ = style_class(style); e_lo, e_hi = (0.30, 0.65) if sc_ < 1.0 else (0.40, 0.80) if sc_ < 2.0 else (0.55, 0.95)
    energy = base["energy"] if L["energy"] else max(0.2, min(1.0, rng.uniform(e_lo, e_hi) * (f ** 1.5 if cfg.get("tod_on") else 1.0)))
    key = base["key"] if L["key"] else rng.randrange(12)
    scale = base["scale"] if L["scale"] else _wchoice(rng, list(SCALE_W), list(SCALE_W.values()))
    density = base["density"] if L["density"] else round(rng.uniform(0.40, 0.85), 2)
    swing = base["swing"] if L["swing"] else round(max(0.0, min(0.15, cs["swing"] + rng.uniform(-0.02, 0.05))), 3)
    ab = int(cfg["arr_bars"])
    bars = ab if L["bars"] else max(16, rng.choice(range(max(16, int(ab * 0.75) // 8 * 8), int(ab * 1.5) + 8, 8)))
    kw = dict(style=style, bpm=bpm, key=key, scale=scale, bars=_min_bars(style, bars), energy=round(energy, 3), density=density, swing=swing, instruments=inst, **speak)
    desc = f"{slot}" + (f" ×{f:.2f}" if cfg.get("tod_on") else "") + f" → {style} {bpm} BPM"
    return dict(kw=kw, slot=slot, factor=f, desc=desc)


# ------------------------------------------------------------------ magazyn
class Arr:
    """Jedna wygenerowana aranżacja w magazynie."""

    def __init__(self, idx, proj, plan, wav, main_frames, start_sec):
        self.idx, self.proj, self.plan, self.wav = idx, proj, plan, Path(wav)
        self.main_frames, self.start_sec = main_frames, start_sec
        self.dur = main_frames / SR
        self.pinned = False; self.evicted = False; self.created = time.time()

    @property
    def style(self):
        return self.proj["style"]

    def label(self):
        p = self.proj
        return f"#{self.idx + 1} {p['style']} {p['bpm']} BPM {core.key_name(p)} {p['bars']}t"

    def load(self):
        with wave.open(str(self.wav), "rb") as w:
            return np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").reshape(-1, 2)


# ------------------------------------------------------------------ strumień do zewnętrznego odtwarzacza
class StreamPlayer:
    """Rura PCM s16le/48k/stereo do pw-cat / paplay / aplay / ffplay / mpv. DS_LIVE_PLAYER=<nazwa|null> wymusza wybór."""

    def __init__(self):
        self.proc = None; self.name = None; self.null_speed = float(os.environ.get("DS_LIVE_NULL_SPEED", "1"))

    @staticmethod
    def _cmds():
        r = str(SR)
        return {
            "pw-cat": ["--playback", "--rate", r, "--channels", "2", "--format", "s16", "-"],
            "paplay": ["--raw", f"--rate={r}", "--channels=2", "--format=s16le"],
            "aplay": ["-q", "-t", "raw", "-f", "S16_LE", "-r", r, "-c", "2"],
            "ffplay": ["-nodisp", "-loglevel", "quiet", "-f", "s16le", "-ar", r, "-ac", "2", "-i", "-"],
            "mpv": ["--no-video", "--really-quiet", "--demuxer=rawaudio", "--demuxer-rawaudio-format=s16le",
                    f"--demuxer-rawaudio-rate={r}", "--demuxer-rawaudio-channels=2", "-"],
        }

    def start(self):
        self.stop()
        want = os.environ.get("DS_LIVE_PLAYER")
        if want == "null":
            self.name = "null"; return True
        cmds = self._cmds()
        for c in ([want] if want in cmds else []) + ["pw-cat", "paplay", "aplay", "ffplay", "mpv"]:
            exe = shutil.which(c)
            if exe and c in cmds:
                self.proc = subprocess.Popen([exe] + cmds[c], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.name = c
                return True
        return False

    def alive(self):
        return self.name == "null" or (self.proc is not None and self.proc.poll() is None)

    def write(self, b):
        if self.name == "null":
            time.sleep(len(b) / 4 / SR / max(self.null_speed, 1e-3)); return True
        try:
            self.proc.stdin.write(b); self.proc.stdin.flush(); return True
        except (BrokenPipeError, OSError, ValueError, AttributeError):
            return False

    def stop(self):
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.stdin.close()
            except Exception:
                pass
            try:
                p.kill(); p.wait(timeout=2)
            except Exception:
                pass



# ------------------------------------------------------------------ Icecast2
class IcecastSink:
    """ffmpeg: PCM s16le z stdin -> MP3/Ogg -> icecast://. Własny wątek + kolejka (zerwane łącze nie blokuje odsłuchu lokalnego),
    automatyczne ponawianie połączenia co `reconnect_sec`."""

    def __init__(self):
        self.cfg = None; self.q = queue.Queue(maxsize=700); self.th = None; self.proc = None; self.run = False
        self.status = "wyłączony"; self.lastlog = ""; self.spawned = 0.0; self.key = None

    @staticmethod
    def url(c, hide=False):
        pw = "***" if hide else urllib.parse.quote(c["password"], safe="")
        return f"icecast://{urllib.parse.quote(c['source_user'], safe='')}:{pw}@{c['host']}:{c['port']}{c['mount']}"

    def cmd(self, c):
        ff = shutil.which("ffmpeg")
        if not ff:
            raise RuntimeError("Icecast: brak ffmpeg w systemie.")
        codec = {"mp3": ["-c:a", "libmp3lame", "-f", "mp3", "-content_type", "audio/mpeg"],
                 "ogg": ["-c:a", "libvorbis", "-f", "ogg", "-content_type", "application/ogg"],
                 "opus": ["-c:a", "libopus", "-f", "ogg", "-content_type", "application/ogg"]}[c["format"]]
        a = [ff, "-hide_banner", "-loglevel", "warning", "-nostdin", "-f", "s16le", "-ar", str(SR), "-ac", "2", "-i", "-", "-b:a", f"{c['bitrate']}k"] + codec
        a += ["-ice_name", c["name"] or "DS Dubstep Studio", "-ice_description", c["description"], "-ice_genre", c["genre"], "-ice_public", "1" if c["public"] else "0"]
        if c["url"]:
            a += ["-ice_url", c["url"]]
        if c["tls"]:
            a += ["-tls", "1"]
        if c["legacy"]:
            a += ["-legacy_icecast", "1"]
        return a + [self.url(c)]

    def configure(self, cfg):
        """Wołane z silnika; restartuje nadawanie tylko gdy zmienił się któryś parametr połączenia/kodowania."""
        key = None if not cfg or not cfg["enabled"] else json.dumps({k: cfg[k] for k in (
            "host", "port", "mount", "source_user", "password", "tls", "legacy", "format", "bitrate", "name", "description", "genre", "url", "public")}, sort_keys=True)
        self.cfg = cfg
        if key != self.key and self.run:
            self.stop(); self.key = key; self.start() if key else None
        else:
            self.key = key

    def start(self):
        if not (self.cfg and self.cfg["enabled"]) or self.run:
            return
        self.key = self.key or "on"; self.run = True; self.status = "łączę…"
        while not self.q.empty():
            try:
                self.q.get_nowait()
            except queue.Empty:
                break
        self.th = threading.Thread(target=self._loop, daemon=True); self.th.start()

    def stop(self):
        self.run = False
        p, self.proc = self.proc, None
        if p is not None:
            for fn in (lambda: p.stdin.close(), p.kill, lambda: p.wait(timeout=2)):
                try:
                    fn()
                except Exception:
                    pass
        if self.th is not None and self.th is not threading.current_thread():
            self.th.join(timeout=3)
        self.th = None; self.status = "wyłączony"

    def flush(self):
        while True:
            try:
                self.q.get_nowait()
            except queue.Empty:
                return

    def write(self, b):
        if not self.run:
            return
        try:
            self.q.put_nowait(b)
        except queue.Full:                      # serwer/sieć stoi: gubimy najstarsze, nie blokujemy odsłuchu
            try:
                self.q.get_nowait(); self.q.put_nowait(b)
            except (queue.Empty, queue.Full):
                pass

    def _spawn(self):
        c = self.cfg
        self.proc = subprocess.Popen(self.cmd(c), stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        self.spawned = time.time(); self.lastlog = ""
        threading.Thread(target=self._drain_err, args=(self.proc,), daemon=True).start()

    def _drain_err(self, p):
        try:
            for raw in p.stderr:
                ln = raw.decode("utf-8", "replace").strip()
                if ln:
                    self.lastlog = ln.replace(self.cfg["password"], "***") if self.cfg and self.cfg["password"] else ln
        except Exception:
            pass

    def _loop(self):
        while self.run:
            c = self.cfg
            try:
                if self.proc is None or self.proc.poll() is not None:
                    if self.proc is not None:                       # padł: pokaż powód i poczekaj
                        self.status = f"błąd: {self.lastlog or 'ffmpeg zakończył pracę'} — ponawiam za {c['reconnect_sec']} s"
                        self.proc = None; self.flush()
                        t = time.time() + c["reconnect_sec"]
                        while self.run and time.time() < t:
                            time.sleep(0.1)
                        if not self.run:
                            break
                    self.status = "łączę…"; self._spawn()
                if self.status == "łączę…" and time.time() - self.spawned > 2.0 and self.proc.poll() is None:
                    self.status = f"nadaje → {self.url(c, hide=True).split('@', 1)[1]} ({c['format']} {c['bitrate']} kbps)"
                try:
                    b = self.q.get(timeout=0.3)
                except queue.Empty:
                    continue
                self.proc.stdin.write(b); self.proc.stdin.flush()
            except (BrokenPipeError, OSError, ValueError, AttributeError):
                time.sleep(0.1)                                      # pętla wykryje poll() != None i ponowi
            except Exception as ex:
                self.status = f"błąd: {ex}"; time.sleep(1.0)

    def set_title(self, title):
        """Tytuł utworu przez /admin/metadata (MP3; Ogg niesie metadane w strumieniu). Wymaga admin_password."""
        c = self.cfg
        if not (self.run and c and c["metadata"] and c["admin_password"] and c["format"] == "mp3"):
            return

        def go():
            try:
                q = urllib.parse.urlencode({"mount": c["mount"], "mode": "updinfo", "song": title, "charset": "UTF-8"})
                req = urllib.request.Request(f"{'https' if c['tls'] else 'http'}://{c['host']}:{c['port']}/admin/metadata?{q}")
                import base64
                req.add_header("Authorization", "Basic " + base64.b64encode(f"{c['admin_user']}:{c['admin_password']}".encode()).decode())
                urllib.request.urlopen(req, timeout=5).read()
            except Exception:
                pass
        threading.Thread(target=go, daemon=True).start()


class Output:
    """Wyjście audio silnika: odsłuch lokalny (StreamPlayer) i/lub Icecast. Bez odsłuchu lokalnego taktuje zegar ścienny.
    Przy włączonym Icecast w przerwach (pauza, oczekiwanie na render) wysyła ciszę, żeby serwer nie zerwał źródła."""

    def __init__(self):
        self.local = StreamPlayer(); self.ice = IcecastSink(); self.local_on = True; self.t0 = None; self.sent = 0; self.started = False

    def configure(self, ice_cfg, local_on):
        self.local_on = bool(local_on); self.ice.configure(ice_cfg)
        if self.started:                             # zmiana w trakcie pracy: dołącz/odłącz wyjścia
            if self.ice_on() and not self.ice.run:
                self.ice.start()
            if self.use_local() and self.local.name is None:
                self.local.start()
            elif not self.use_local():
                self.local.stop(); self.local.name = None

    def ice_on(self):
        return bool(self.ice.cfg and self.ice.cfg["enabled"])

    def use_local(self):
        return self.local_on or not self.ice_on()

    def start(self):
        ok = self.local.start() if self.use_local() else True
        self.ice.start(); self.t0 = time.time(); self.sent = 0; self.started = True
        return ok

    def stop(self):
        self.started = False; self.local.stop(); self.ice.stop()

    def restart_local(self):
        """Opróżnia bufory (skok na osi czasu jest natychmiastowy)."""
        self.ice.flush()
        if self.use_local():
            self.local.start()

    def _put(self, b):
        ok = True
        if self.use_local():
            ok = self.local.write(b)
            if not ok:
                self.local.start()
        else:
            ahead = self.t0 + self.sent / SR - time.time()
            if ahead > 0.4:
                time.sleep(ahead - 0.4)
        self.ice.write(b); self.sent += len(b) // 4
        return ok

    def write(self, b):
        due = self.t0 + self.sent / SR
        if time.time() - due > 0.5:                 # był przestój bez ciszy (np. tylko lokalnie) — zsynchronizuj zegar
            self.t0 = time.time() - self.sent / SR
        return self._put(b)

    def fill_silence(self):
        if not (self.started and self.ice_on()):
            time.sleep(0.02); return
        need = time.time() + 0.25 - (self.t0 + self.sent / SR)
        n = int(need * SR) if need > 0.05 else 0
        while n > 0:
            k = min(n, CHUNK); self._put(bytes(k * 4)); n -= k
        if n <= 0:
            time.sleep(0.02)

    def status(self):
        return dict(local=("odsłuch lokalny: " + (self.local.name or "—")) if self.use_local() else "odsłuch lokalny: wyłączony", icecast=self.ice.status if self.ice_on() else "Icecast: wyłączony")

# ------------------------------------------------------------------ silnik
class LiveEngine:
    """on_event(kind, **kw): "planning" | "added" | "playing" | "evicted" | "error" | "status" — wołane z wątków roboczych."""

    def __init__(self, on_event=None):
        self.on_event = on_event or (lambda *a, **k: None)
        self.cv = threading.Condition(threading.RLock())
        self.cfg = copy.deepcopy(DEFAULT_CFG); self.base = None
        self.arrs: list[Arr] = []; self.cursor = 0; self.resume = 0; self.auditing = False; self.gen = 0
        self.running = False; self.paused = False; self.playing = False
        self.playing_idx = None; self.frames = 0; self.t_play0 = None
        self.session = None; self.threads = []; self.out = Output(); self.rendering = False; self.out_err = None

    # --- ustawienia (wołane z GUI; zmiany działają od następnej planowanej aranżacji)
    def set_cfg(self, cfg):
        with self.cv:
            self.cfg = copy.deepcopy(cfg); self.cv.notify_all()

    def set_output(self, ice_cfg, local_on=True):
        """Konfiguracja wyjścia (Icecast + odsłuch lokalny); zmiana połączenia restartuje tylko nadawanie."""
        with self.cv:
            self.out.configure(copy.deepcopy(ice_cfg), local_on)

    def out_status(self):
        return self.out.status()

    def set_base(self, base):
        with self.cv:
            self.base = copy.deepcopy(base); self.cv.notify_all()

    # --- sterowanie
    def start(self):
        if self.running:
            return
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.session = core.lib_dir().parent / "live" / stamp
        self.session.mkdir(parents=True, exist_ok=True)
        self.arrs, self.cursor, self.resume, self.auditing, self.gen = [], 0, 0, False, 0
        self.paused = False; self.running = True
        self.threads = [threading.Thread(target=self._producer, daemon=True), threading.Thread(target=self._player, daemon=True)]
        for t in self.threads:
            t.start()

    def stop(self):
        with self.cv:
            self.running = False; self.cv.notify_all()
        self.out.stop()
        for t in self.threads:
            t.join(timeout=3)
        self.threads = []; self.playing = False

    def set_paused(self, v):
        with self.cv:
            self.paused = bool(v); self.cv.notify_all()

    def jump(self, idx):
        """Odsłuch od punktu startowego aranżacji idx (z osi czasu)."""
        with self.cv:
            if not (0 <= idx < len(self.arrs)) or self.arrs[idx].evicted:
                return False
            if not self.auditing:
                self.resume = self.cursor + 1 if self.playing else self.cursor      # tu wracamy „na żywo"
            self.auditing = idx < self.resume
            self.cursor = idx; self.gen += 1; self.paused = False; self.cv.notify_all()
        return True

    def skip(self):
        with self.cv:
            n = self.cursor + 1
        return self.jump(n)

    def back_to_live(self):
        with self.cv:
            n = max(self.resume, len(self.arrs) - 1) if self.auditing else None
        return self.jump(n) if n is not None else False

    def set_pinned(self, idxs, v):
        with self.cv:
            for i in idxs:
                if 0 <= i < len(self.arrs):
                    self.arrs[i].pinned = bool(v)

    def clear_store(self):
        """Usuwa z magazynu wszystko poza przypiętymi i aktualnie odtwarzanym/oczekującym."""
        with self.cv:
            for a in self.arrs:
                if not a.pinned and not a.evicted and a.idx not in (self.cursor, self.playing_idx):
                    self._evict(a)

    def position(self):
        """-> (indeks grającej aranżacji, sekunda od jej początku) albo None."""
        if not (self.playing and self.playing_idx is not None):
            return None
        return self.playing_idx, max(0.0, self.frames / SR - LATENCY)

    def _emit(self, kind, **kw):
        try:
            self.on_event(kind, **kw)
        except Exception:
            pass

    # --- producent
    def _need_more(self):
        return self.base is not None and len(self.arrs) < self.cursor + 1 + int(self.cfg["lookahead"])

    def _producer(self):
        while self.running:
            with self.cv:
                while self.running and not self._need_more():
                    self.cv.wait(0.4)
                if not self.running:
                    break
                cfg, base = copy.deepcopy(self.cfg), copy.deepcopy(self.base)
                idx = len(self.arrs)
            try:
                self._make_one(idx, cfg, base)
            except Exception:
                self._emit("error", msg=traceback.format_exc()); time.sleep(2.0)

    def _make_one(self, idx, cfg, base):
        rng = random.Random()
        plan = plan_next(cfg, base, rng, core.available_types())
        kw = plan["kw"]; kw["seed"] = rng.randrange(1000000)
        kw["name"] = f"Live-{idx + 1:04d}-{G.short_name(kw['style'])}"
        self._emit("planning", idx=idx, plan=plan)
        self.rendering = True
        try:
            proj = G.generate(**kw)
            mix = core.mix_stems(proj, core.render_stems(proj, None, {}))
        finally:
            self.rendering = False
        wav = self.session / f"arr_{idx + 1:04d}.wav"
        core.write_wav(wav, mix)
        proj["id"] = f"live-{idx + 1:04d}"; proj["live"] = dict(slot=plan["slot"], factor=plan["factor"], mode=cfg["mode"])
        core.save_project(proj, self.session / f"arr_{idx + 1:04d}.dsproj")
        main = int(round(proj["bars"] * 4 * 60.0 / proj["bpm"] * SR))
        with self.cv:
            start = self.arrs[-1].start_sec + self.arrs[-1].dur if self.arrs else 0.0
            a = Arr(idx, proj, plan, wav, min(main, len(mix)), start)
            self.arrs.append(a)
            self._evict_old()
            self.cv.notify_all()
        self._emit("added", arr=a)

    def _evict(self, a):
        a.evicted = True
        try:
            a.wav.unlink()
        except Exception:
            pass
        self._emit("evicted", idx=a.idx)

    def _evict_old(self):
        keep = int(self.cfg["max_store"])
        alive = [a for a in self.arrs if not a.evicted]
        for a in alive:
            if len(alive) <= keep:
                break
            if not a.pinned and a.idx < self.cursor - 1 and a.idx != self.playing_idx:
                self._evict(a); alive.remove(a)

    # --- odtwarzacz
    def _player(self):
        carry = None
        if not self.out.start() and self.out.use_local():
            self._emit("error", msg="Brak odtwarzacza strumieniowego (pw-cat/paplay/aplay/ffplay/mpv). Zainstaluj jeden z nich albo wyłącz odsłuch lokalny (local_playback = no) i nadawaj tylko do Icecast.")
            self.running = False
        while self.running:
            with self.cv:
                ready = not self.paused and self.cursor < len(self.arrs)
                if ready:
                    idx = self.cursor; a = self.arrs[idx]; gen = self.gen
                else:
                    self.playing = False; self.cv.wait(0.05)
            if not ready:
                self.out.fill_silence(); continue          # Icecast: cisza w przerwie, serwer nie zrywa źródła
            if a.evicted:
                with self.cv:
                    if self.gen == gen:
                        self.cursor = idx + 1
                carry = None; continue
            data = a.load().copy(); mf = a.main_frames
            if carry is not None:
                h = min(len(carry), len(data))
                data[:h] = np.clip(data[:h].astype(np.int32) + carry[:h], -32768, 32767).astype(np.int16)
            carry = None
            self.playing_idx, self.frames, self.playing = idx, 0, True
            self.out.ice.set_title(f"{a.style} {a.proj['bpm']} BPM {core.key_name(a.proj)} [DS Live #{idx + 1}]")
            self._emit("playing", idx=idx)
            pos, aborted = 0, False
            while pos < mf and self.running:
                if self.gen != gen:
                    aborted = True; break
                if self.paused:
                    self.out.fill_silence(); continue
                chunk = data[pos: min(pos + CHUNK, mf)]
                self.out.write(chunk.tobytes())
                pos += len(chunk); self.frames = pos
            if aborted or not self.running:
                carry = None
                if aborted:
                    self.out.restart_local()
                continue
            with self.cv:
                nxt = idx + 1
                if self.auditing and self.cfg["return_live"]:
                    nxt = self.resume
                contiguous = nxt == idx + 1 and nxt < len(self.arrs) and not self.arrs[nxt].evicted
                if contiguous:
                    carry = data[mf:].astype(np.int32)
                if self.gen == gen:
                    self.cursor = nxt
                    if self.auditing and nxt >= self.resume:
                        self.auditing = False
            if not contiguous:                   # brak następnej (jeszcze) albo wracamy z odsłuchu: dograj ogon
                tail = data[mf:]
                for k in range(0, len(tail), CHUNK):
                    if self.gen != gen or not self.running:
                        break
                    self.out.write(tail[k: k + CHUNK].tobytes()); self.frames = mf + k
                carry = None
        self.playing = False


# ------------------------------------------------------------------ zrzut / eksport
def concat(arrs):
    """Skleja aranżacje na osi czasu z nałożeniem ogonów -> float32 (n,2). Pomija wyrzucone z magazynu."""
    arrs = [a for a in arrs if not a.evicted]
    if not arrs:
        raise RuntimeError("Brak dostępnych aranżacji (zostały usunięte z magazynu).")
    parts, pos = [], 0
    total = 0
    for a in arrs:
        d = a.load(); parts.append((pos, d)); total = max(total, pos + len(d)); pos += a.main_frames
    out = np.zeros((total, 2), dtype=np.float32)
    for p, d in parts:
        out[p: p + len(d)] += d.astype(np.float32) / 32768.0
    pk = float(np.max(np.abs(out))) or 1.0
    return out * (0.95 / pk) if pk > 0.95 else out


def pick_auto(arrs, n, rng=None):
    """Tryb auto zrzutu: losowe n aranżacji z magazynu, w kolejności chronologicznej."""
    rng = rng or random.Random()
    pool = [a for a in arrs if not a.evicted]
    return sorted(rng.sample(pool, min(n, len(pool))), key=lambda a: a.idx)


def dump_mp3(arrs, out_path, progress=None):
    """-> ścieżka pliku (MP3; WAV jeśli brak ffmpeg/lame)."""
    out_path = Path(out_path)
    mix = concat(arrs)
    if progress:
        progress(0.5)
    wav = out_path.with_suffix(".wav"); core.write_wav(wav, mix)
    if core.export_mp3(wav, out_path.with_suffix(".mp3")):
        wav.unlink(); res = out_path.with_suffix(".mp3")
    else:
        res = wav
    if progress:
        progress(1.0)
    return res


def save_arr_to_library(a):
    """Zapisuje aranżację z magazynu do biblioteki (project.dsproj + track.mid + track.mp3) bez ponownego renderu."""
    if a.evicted:
        raise RuntimeError("Ta aranżacja została usunięta z magazynu.")
    proj = copy.deepcopy(a.proj)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    slug = re.sub(r"[^A-Za-z0-9]+", "-", proj["name"]).strip("-") or "live"
    d = core.lib_dir() / f"{stamp}_{slug}"; d.mkdir(parents=True, exist_ok=True)
    proj["created"] = stamp; proj["id"] = d.name
    core.save_project(proj, d / "project.dsproj"); core.write_midi(proj, d / "track.mid")
    shutil.copy(a.wav, d / "track.wav")
    if core.export_mp3(d / "track.wav", d / "track.mp3"):
        (d / "track.wav").unlink()
    return d
