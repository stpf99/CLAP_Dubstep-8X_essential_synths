"""gui.py — DS Dubstep Studio (PyQt6): generator, ścieżki/parametry, linki, biblioteka, auto-remix."""
from __future__ import annotations

import copy
import os
import random
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import core, generator as G, noteops as N, presets as PR, remix as R, styles as ST
from .board_gui import BoardTab
from .live_gui import LiveTab

GROUP_COL = {"Perkusja": "#e5484d", "Bas": "#2dd4bf", "Synth / lead": "#c4b5fd", "FX": "#f5a524", "Mowa": "#60a5fa", "Akustyczne": "#34d399"}


def tcolor(ttype):
    for g, ts in core.GROUPS.items():
        if ttype in ts:
            c = QtGui.QColor(GROUP_COL[g])
            i = ts.index(ttype)
            return c.lighter(100 + min(8, i) * 5) if i % 2 else c.darker(100 + min(8, i) * 4)
    return QtGui.QColor("#9ca3af")
SECCOL = {"intro": "#1f2937", "build": "#3b2f12", "drop": "#3a1217", "break": "#12303a", "outro": "#1f2937"}


class Worker(QtCore.QThread):
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(str)
    prog = QtCore.pyqtSignal(float)

    def __init__(self, fn):
        super().__init__(); self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(self.prog.emit))
        except Exception:
            self.fail.emit(traceback.format_exc())


class Player:
    def __init__(self):
        self.proc = None; self.t0 = 0.0

    def play(self, path):
        self.stop()
        ext = str(path).lower().rsplit(".", 1)[-1]
        order = (["ffplay", "mpv", "pw-play", "paplay", "aplay"] if ext == "mp3" else ["pw-play", "paplay", "aplay", "ffplay", "mpv"])
        args = {"ffplay": ["-nodisp", "-autoexit", "-loglevel", "quiet"], "mpv": ["--no-video", "--really-quiet"], "aplay": ["-q"]}
        for c in order:
            exe = shutil.which(c)
            if exe:
                self.proc = subprocess.Popen([exe] + args.get(c, []) + [str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.t0 = time.time()
                return True
        return False

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
        self.proc = None

    def elapsed(self):
        return time.time() - self.t0 if self.proc and self.proc.poll() is None else None


class Overview(W.QWidget):
    """Podgląd aranżacji: pasy z nutami + sekcje + playhead. Przeciągnięcie myszą zaznacza okno taktów (do edycji grupy nut)."""
    selChanged = QtCore.pyqtSignal(int, int)

    def __init__(self):
        super().__init__(); self.proj = None; self.head = None; self.sel = None; self._drag = None; self.setMinimumHeight(230)

    def _bar_at(self, x):
        p = self.proj
        if not p or not p["bars"]:
            return 0
        return max(0, min(p["bars"] - 1, int((x - 66) / max(1, self.width() - 70) * p["bars"])))

    def mousePressEvent(self, e):
        self._drag = self._bar_at(e.position().x()); self.sel = (self._drag, self._drag + 1)
        self.selChanged.emit(*self.sel); self.update()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            b = self._bar_at(e.position().x()); self.sel = (min(self._drag, b), max(self._drag, b) + 1)
            self.selChanged.emit(*self.sel); self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def set_project(self, p):
        self.proj = p; self.setMinimumHeight(max(230, 16 * len(p["tracks"]) + 30) if p else 230); self.update()

    def paintEvent(self, ev):
        qp = QtGui.QPainter(self); qp.fillRect(self.rect(), QtGui.QColor("#0f1115"))
        p = self.proj
        if not p or not p["bars"]:
            return
        w, h, top = self.width() - 70, self.height() - 22, 18
        beats = p["bars"] * 4; lane = h / max(1, len(p["tracks"]))
        for s in p["sections"]:
            x0 = 66 + s["start"] * 4 / beats * w; x1 = 66 + (s["start"] + s["bars"]) * 4 / beats * w
            qp.fillRect(QtCore.QRectF(x0, top, x1 - x0, h), QtGui.QColor(SECCOL[s["type"]]))
            qp.setPen(QtGui.QColor("#9ca3af")); qp.drawText(QtCore.QPointF(x0 + 3, 12), s["name"])
        for i, t in enumerate(p["tracks"]):
            y0 = top + i * lane
            qp.setPen(tcolor(t["type"])); qp.drawText(QtCore.QPointF(4, y0 + min(lane * 0.8, 12)), t["name"])
            qp.setPen(QtGui.QColor("#1b1f27")); qp.drawLine(66, int(y0 + lane), 66 + int(w), int(y0 + lane))
            if not t["notes"]:
                continue
            ks = [n[2] for n in t["notes"]]; lo, hi = min(ks), max(ks); rng = max(1, hi - lo)
            nh = max(1.5, min(6.0, (lane - 3) / (rng + 1)))
            col = QtGui.QColor(tcolor(t["type"])); col.setAlpha(120 if t["mute"] else 230)
            for on, dur, key, vel in t["notes"]:
                x = 66 + on / beats * w
                y = y0 + 2 + (lane - 4 - nh) * (1 - (key - lo) / rng)
                qp.fillRect(QtCore.QRectF(x, y, max(1.2, dur / beats * w), nh), col)
        if self.sel:
            x0 = 66 + self.sel[0] * 4 / beats * w; x1 = 66 + self.sel[1] * 4 / beats * w
            qp.fillRect(QtCore.QRectF(x0, top, max(2.0, x1 - x0), h), QtGui.QColor(255, 255, 255, 45))
            qp.setPen(QtGui.QColor("#ffffff")); qp.drawRect(QtCore.QRectF(x0, top, max(2.0, x1 - x0), h))
        if self.head is not None:
            x = 66 + min(1.0, self.head / beats) * w
            qp.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 1)); qp.drawLine(int(x), top, int(x), top + int(h))


class MainWindow(W.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DS Dubstep Studio")
        self.resize(1180, 820)
        self.meta = core.meta()
        self.proj = None; self.cache = {}; self.player = Player(); self.worker = None
        self.style_override = None   # nazwa hybrydy (z pola szachowego / projektu) zamiast stylu z listy
        self.remix_entries = []   # [(path, proj)]
        tabs = W.QTabWidget(); self.setCentralWidget(tabs)
        tabs.addTab(self._build_gen(), "Generator")
        self.board = BoardTab(self); tabs.addTab(self.board, "Pole stylów (hybrydy)")
        tabs.addTab(self._build_tracks(), "Ścieżki / parametry")
        tabs.addTab(self._build_links(), "Linki (przekazywanie)")
        tabs.addTab(self._build_lib(), "Biblioteka")
        tabs.addTab(self._build_remix(), "Auto-remix")
        self.live = LiveTab(self)
        tabs.addTab(self.live, "Live / Endless")
        self.tabs = tabs
        self.undo = {}
        self.ov.selChanged.connect(self._ov_sel)
        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(40)
        self.refresh_library()
        self.on_style(self.cur_style())
        self.live.apply_conf(self.live.conf)      # config.txt wygrywa z domyślnymi stylu
        self.refresh_presets()

    # ------------------------------------------------------------------ Generator
    def _build_gen(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        pb = W.QHBoxLayout(); pb.addWidget(W.QLabel("Preset:"))
        self.preset_cb = W.QComboBox(); self.preset_cb.setMinimumWidth(220); pb.addWidget(self.preset_cb, 1)
        for txt, fn in (("Wczytaj", self.preset_load), ("Zapisz jako…", self.preset_save), ("Usuń", self.preset_delete), ("Eksportuj…", self.preset_export), ("Importuj…", self.preset_import)):
            b = W.QPushButton(txt); b.clicked.connect(fn); pb.addWidget(b)
        v.addLayout(pb)
        f = W.QFormLayout()
        self.style = W.QComboBox(); self.style.addItems(ST.ORDER + [s_ for s_ in G.STYLES if s_ not in ST.ORDER]); self.style.currentTextChanged.connect(self._combo_style)
        self.style_lbl = W.QLabel(""); self.style_lbl.setWordWrap(True)
        self.bpm = W.QSpinBox(); self.bpm.setRange(60, 200)
        self.keyc = W.QComboBox(); self.keyc.addItems(["losowa"] + core.NOTE_NAMES)
        self.scale = W.QComboBox(); self.scale.addItems(core.SCALES.keys())
        self.bars = W.QSpinBox(); self.bars.setRange(32, 256); self.bars.setSingleStep(8); self.bars.setValue(144)
        self.energy = self._slider(70); self.density = self._slider(60); self.swing = self._slider(0)
        self.seed = W.QSpinBox(); self.seed.setRange(0, 999999); self.rndseed = W.QCheckBox("losuj seed"); self.rndseed.setChecked(True)
        sr = W.QHBoxLayout(); sr.addWidget(self.seed); sr.addWidget(self.rndseed)
        self.name = W.QLineEdit(); self.name.setPlaceholderText("(opcjonalnie) nazwa utworu")
        sw = W.QVBoxLayout(); sw.addWidget(self.style); sw.addWidget(self.style_lbl); stw = W.QWidget(); stw.setLayout(sw); sw.setContentsMargins(0, 0, 0, 0)
        for lbl, wd in [("Styl", stw), ("BPM", self.bpm), ("Tonacja", self.keyc), ("Skala", self.scale), ("Długość (takty)", self.bars),
                        ("Energia", self.energy), ("Gęstość / złożoność", self.density), ("Swing", self.swing), ("Seed", sr), ("Nazwa", self.name)]:
            f.addRow(lbl, wd if isinstance(wd, W.QWidget) else wd)
        top = W.QHBoxLayout(); top.addLayout(f, 1)
        box = W.QVBoxLayout(); box.addWidget(W.QLabel("Instrumenty (wtyczki CLAP; DS Speak opcjonalnie)"))
        avail = set(core.available_types())
        self.itree = W.QTreeWidget(); self.itree.setHeaderHidden(True); self.itree.setMinimumWidth(230); self.itree.setMaximumHeight(330)
        for g, ts in core.GROUPS.items():
            ts = [t for t in ts if t in avail]
            if not ts:
                continue
            gi = W.QTreeWidgetItem(self.itree, [g]); gi.setFlags(gi.flags() | Qt.ItemFlag.ItemIsUserTristate | Qt.ItemFlag.ItemIsUserCheckable)
            for t in ts:
                ci = W.QTreeWidgetItem(gi, [t]); ci.setFlags(ci.flags() | Qt.ItemFlag.ItemIsUserCheckable); ci.setCheckState(0, Qt.CheckState.Unchecked)
                ci.setForeground(0, QtGui.QBrush(tcolor(t)))
        self.itree.expandAll(); box.addWidget(self.itree)
        ib = W.QHBoxLayout()
        for txt, fn in (("Styl", lambda: self.set_instruments(G.default_instruments(self.cur_style()))),
                        ("Podstawowe 8", lambda: self.set_instruments(core.CORE8)), ("Wszystkie", lambda: self.set_instruments(core.available_types()))):
            b = W.QPushButton(txt); b.clicked.connect(fn); ib.addWidget(b)
        box.addLayout(ib)
        # --- DS Speak: aktywne tylko gdy zaznaczono instrument "speak" (domyślnie wyłączony)
        self.sp_box = W.QGroupBox("Mowa (DS Speak) — tekst"); sl = W.QVBoxLayout(self.sp_box)
        self.sp_auto = W.QRadioButton("Auto — generator układa tekst"); self.sp_man = W.QRadioButton("Ręczny — własny tekst (ENG)")
        self.sp_auto.setChecked(True)
        self.sp_theme = W.QComboBox(); self.sp_theme.addItems(["wg stylu"] + list(G.SPEAK_THEMES))
        self.sp_text = W.QPlainTextEdit(); self.sp_text.setMaximumHeight(64)
        self.sp_text.setPlaceholderText("np. Drop the bass! Wobble. Hands up?  — każda nuta = kolejne słowo; ! akcent, ? pytanie, WIELKIE = okrzyk")
        for x in (self.sp_auto, self.sp_theme, self.sp_man, self.sp_text):
            sl.addWidget(x)
        box.addWidget(self.sp_box)
        self.itree.itemChanged.connect(lambda *_: self._sync_speak())
        self._sync_speak()
        top.addLayout(box); v.addLayout(top)
        r = W.QHBoxLayout()
        self.b_gen = W.QPushButton("Generuj"); self.b_gen.clicked.connect(self.generate)
        self.b_play = W.QPushButton("▶ Podgląd"); self.b_play.clicked.connect(self.preview)
        self.b_stop = W.QPushButton("■ Stop"); self.b_stop.clicked.connect(self.player.stop)
        self.b_save = W.QPushButton("Zapisz do biblioteki (MIDI+MP3+projekt)"); self.b_save.clicked.connect(self.save_lib)
        self.stems_chk = W.QCheckBox("+ stemy WAV")
        for b in (self.b_gen, self.b_play, self.b_stop, self.b_save, self.stems_chk):
            r.addWidget(b)
        v.addLayout(r)
        self.pb = W.QProgressBar(); self.pb.setRange(0, 100); self.status = W.QLabel("Gotowe.")
        v.addWidget(self.pb); v.addWidget(self.status)
        self.ov = Overview(); v.addWidget(self.ov, 1)
        return w

    @staticmethod
    def _slider(val):
        s = W.QSlider(Qt.Orientation.Horizontal); s.setRange(0, 100); s.setValue(val); return s

    # --- styl: lista albo hybryda z pola szachowego
    def cur_style(self):
        return self.style_override or self.style.currentText()

    def _show_style(self):
        o = self.style_override
        self.style_lbl.setText(f"<b>Hybryda:</b> <span style='color:{ST.color_of(o)}'>■</span> {o}" if o else "")
        self.style_lbl.setTextFormat(Qt.TextFormat.RichText)

    def _combo_style(self, st):
        self.style_override = None; self._show_style(); self.on_style(st)

    def use_style(self, name):
        """Ustaw styl Generatora: czysty (z listy) albo hybrydę „A 60% + B 40%”."""
        if dict.__contains__(G.STYLES, name):
            if self.style.currentText() == name:
                self._combo_style(name)
            else:
                self.style.setCurrentText(name)
        else:
            self.style_override = name; self._show_style(); self.on_style(name)

    # --- presety (globalne, domyślnie puste)
    def refresh_presets(self, select=None):
        names = PR.names(); self.preset_cb.clear()
        self.preset_cb.addItems(names if names else ["(brak presetów — „Zapisz jako…”)"]); self.preset_cb.setEnabled(bool(names))
        if select in names:
            self.preset_cb.setCurrentText(select)

    def collect_preset(self):
        lv = self.live.collect_cfg()
        key = None if self.keyc.currentIndex() == 0 else self.keyc.currentIndex() - 1
        return dict(generator=dict(style=self.cur_style(), style_base=self.style.currentText(), bpm=self.bpm.value(), key=key, scale=self.scale.currentText(),
                                   bars=self.bars.value(), energy=self.energy.value() / 100, density=self.density.value() / 100, swing=self.swing.value() / 100,
                                   instruments=self.selected_instruments(), speak_manual=self.sp_man.isChecked(), speak_text=self.sp_text.toPlainText().strip(),
                                   speak_theme=None if self.sp_theme.currentIndex() == 0 else self.sp_theme.currentText()),
                    board=dict(cells=self.board.cells_list(), strength=self.board.get_strength()),
                    live={k: lv[k] for k in ("mode", "locks", "tod_on", "tod_force", "tod_factors", "arr_bars", "lookahead", "max_store", "return_live", "mutate_p", "use_board")})

    def apply_preset(self, d):
        g, b, lv = d.get("generator", {}), d.get("board", {}), d.get("live", {})
        self.board.set_cells(b.get("cells", [])); self.board.set_strength(b.get("strength", 0.4))
        base = g.get("style_base") or g.get("style")
        if base and dict.__contains__(G.STYLES, base):
            self.style.blockSignals(True); self.style.setCurrentText(base); self.style.blockSignals(False)
        st = g.get("style")
        self.style_override = st if st and "%" in st and st in G.STYLES else None; self._show_style()
        if g.get("bpm"):
            self.bpm.setValue(int(g["bpm"]))
        self.keyc.setCurrentIndex(0 if g.get("key") is None else int(g["key"]) + 1)
        if g.get("scale") in core.SCALES:
            self.scale.setCurrentText(g["scale"])
        if g.get("bars"):
            self.bars.setValue(int(g["bars"]))
        for wd, k in ((self.energy, "energy"), (self.density, "density"), (self.swing, "swing")):
            if k in g:
                wd.setValue(int(round(float(g[k]) * 100)))
        if g.get("instruments"):
            self.set_instruments(g["instruments"])
        (self.sp_man if g.get("speak_manual") else self.sp_auto).setChecked(True); self.sp_text.setPlainText(g.get("speak_text") or "")
        self.sp_theme.setCurrentIndex(max(0, self.sp_theme.findText(g.get("speak_theme") or "")))
        self.live.set_cfg_widgets(lv)

    def preset_load(self):
        n = self.preset_cb.currentText(); d = PR.get(n) if self.preset_cb.isEnabled() else None
        if d is None:
            self.status.setText("Brak wybranego presetu."); return
        self.apply_preset(d); self.status.setText(f"Wczytano preset „{n}” (ustawienia Icecast bez zmian)")

    def preset_save(self):
        cur = self.preset_cb.currentText() if self.preset_cb.isEnabled() else ""
        n, ok = W.QInputDialog.getText(self, "Zapisz preset", "Nazwa presetu (istniejąca zostanie nadpisana):", text=cur)
        n = n.strip()
        if not ok or not n:
            return
        PR.put(n, self.collect_preset()); self.refresh_presets(n); self.status.setText(f"Zapisano preset „{n}” → {PR.path()}")

    def preset_delete(self):
        n = self.preset_cb.currentText()
        if self.preset_cb.isEnabled() and W.QMessageBox.question(self, "Usuń preset", f"Usunąć „{n}”?") == W.QMessageBox.StandardButton.Yes:
            PR.delete(n); self.refresh_presets(); self.status.setText(f"Usunięto „{n}”")

    def preset_export(self):
        n = self.preset_cb.currentText()
        if not self.preset_cb.isEnabled():
            return
        path, _ = W.QFileDialog.getSaveFileName(self, "Eksport presetu", str(Path.home() / f"{n}.json"), "JSON (*.json)")
        if path:
            PR.export_file(n, path); self.status.setText(f"Wyeksportowano „{n}” → {path}")

    def preset_import(self):
        path, _ = W.QFileDialog.getOpenFileName(self, "Import presetów", str(Path.home()), "JSON (*.json)")
        if path:
            try:
                ns = PR.import_file(path)
            except (OSError, ValueError) as ex:
                W.QMessageBox.critical(self, "Import", str(ex)); return
            self.refresh_presets(ns[0] if ns else None); self.status.setText(f"Zaimportowano: {', '.join(ns) or '—'}")

    def on_style(self, st):
        self.bpm.setValue(G.STYLES[st]["bpm"]); self.swing.setValue(int(G.STYLES[st]["swing"] * 100))
        self.set_instruments(G.default_instruments(st))

    def set_instruments(self, types):
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                g.child(k).setCheckState(0, Qt.CheckState.Checked if g.child(k).text(0) in types else Qt.CheckState.Unchecked)

    def _sync_speak(self):
        self.sp_box.setEnabled("speak" in self.selected_instruments())

    def selected_instruments(self):
        out = []
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            out += [g.child(k).text(0) for k in range(g.childCount()) if g.child(k).checkState(0) == Qt.CheckState.Checked]
        return out

    def busy(self, msg):
        self.status.setText(msg); self.pb.setValue(0)

    def run_bg(self, fn, done, msg):
        if self.worker and self.worker.isRunning():
            return
        self.busy(msg)
        self.worker = Worker(fn)
        self.worker.prog.connect(lambda x: self.pb.setValue(int(x * 100)))
        self.worker.done.connect(lambda r: (self.pb.setValue(100), done(r)))
        self.worker.fail.connect(lambda e: (self.status.setText("Błąd — szczegóły w oknie"), W.QMessageBox.critical(self, "Błąd", e)))
        self.worker.start()

    def generate(self):
        seed = random.randrange(1000000) if self.rndseed.isChecked() else self.seed.value()
        self.seed.setValue(seed)
        key = None if self.keyc.currentIndex() == 0 else self.keyc.currentIndex() - 1
        inst = self.selected_instruments()
        if not inst:
            W.QMessageBox.information(self, "DS Studio", "Zaznacz przynajmniej jeden instrument."); return
        p = G.generate(self.cur_style(), bpm=self.bpm.value(), key=key, scale=self.scale.currentText(), bars=self.bars.value(),
                       energy=self.energy.value() / 100, density=self.density.value() / 100, swing=self.swing.value() / 100,
                       seed=seed, name=self.name.text() or None, instruments=inst,
                       speak_text=self.sp_text.toPlainText().strip() if self.sp_man.isChecked() else None,
                       speak_theme=None if self.sp_theme.currentIndex() == 0 else self.sp_theme.currentText())
        self.set_project(p)
        self.status.setText(f"Wygenerowano: {p['name']} — {core.key_name(p)}, {p['bpm']} BPM, {p['bars']} taktów ({p['bars'] * 240 / p['bpm']:.0f} s), {len(p['tracks'])} ścieżek")

    def set_project(self, p):
        self.proj = core.ensure_types(p); self.cache = {}; self.undo = {}
        self.ne_a.setMaximum(max(1, p["bars"])); self.ne_b.setMaximum(max(1, p["bars"]))
        self.ne_a.setValue(1); self.ne_b.setValue(max(1, p["bars"])); self.ov.sel = None
        self.ov.set_project(p); self.fill_track_list(); self.fill_links()
        self.bpm.setValue(int(p["bpm"])); self.style.blockSignals(True)
        if dict.__contains__(G.STYLES, p["style"]):
            self.style.setCurrentText(p["style"]); self.style_override = None
        else:
            self.style_override = p["style"] if p["style"] in G.STYLES else None
        self.style.blockSignals(False); self._show_style()

    def need_proj(self):
        if not self.proj:
            W.QMessageBox.information(self, "DS Studio", "Najpierw wygeneruj lub wczytaj projekt."); return False
        return True

    def preview(self):
        if not self.need_proj():
            return
        if self.live.eng.running:
            self.live.stop()          # podgląd offline i strumień Live nie grają naraz
        proj = self.proj

        def job(prog):
            stems = core.render_stems(proj, prog, self.cache)
            mix = core.mix_stems(proj, stems)
            path = Path(tempfile.gettempdir()) / "ds_studio_preview.wav"
            core.write_wav(path, mix)
            return path
        self.run_bg(job, self._play_path, "Renderuję 8 ścieżek przez wtyczki CLAP…")

    def _play_path(self, path):
        ok = self.player.play(path)
        self.status.setText("Odtwarzanie…" if ok else "Brak odtwarzacza (pw-play/paplay/aplay/ffplay/mpv) — plik: " + str(path))

    def save_lib(self):
        if not self.need_proj():
            return
        proj, ws = self.proj, self.stems_chk.isChecked()
        self.run_bg(lambda prog: core.save_to_library(proj, core.render_stems(proj, prog, self.cache), None, ws),
                    lambda d: (self.status.setText(f"Zapisano: {d}"), self.refresh_library()), "Renderuję i zapisuję do biblioteki…")

    def _tick(self):
        e = self.player.elapsed()
        if self.proj and e is not None and self.player.proc is not None and str(self.player.proc.args[-1]).endswith("preview.wav"):
            self.ov.head = e * self.proj["bpm"] / 60.0
        else:
            self.ov.head = None
        self.ov.update()

    # ------------------------------------------------------------------ Ścieżki
    def _build_tracks(self):
        w = W.QWidget(); h = W.QHBoxLayout(w)
        self.tlist = W.QListWidget(); self.tlist.setFixedWidth(170); self.tlist.currentRowChanged.connect(self.show_track)
        h.addWidget(self.tlist)
        right = W.QVBoxLayout(); h.addLayout(right, 1)
        top = W.QHBoxLayout()
        self.t_mute = W.QCheckBox("Mute"); self.t_solo = W.QCheckBox("Solo")
        self.t_gain = W.QSlider(Qt.Orientation.Horizontal); self.t_gain.setRange(0, 150); self.t_gain.setFixedWidth(160)
        self.t_mute.toggled.connect(lambda x: self._tset("mute", x)); self.t_solo.toggled.connect(lambda x: self._tset("solo", x))
        self.t_gain.valueChanged.connect(lambda x: self._tset("gain", x / 100))
        b1 = W.QPushButton("Losuj brzmienie"); b1.clicked.connect(lambda: self.reroll(True, False))
        b2 = W.QPushButton("Losuj wzór nut"); b2.clicked.connect(lambda: self.reroll(False, True))
        b3 = W.QPushButton("Oba"); b3.clicked.connect(lambda: self.reroll(True, True))
        for x in (self.t_mute, self.t_solo, W.QLabel("Gain"), self.t_gain, b1, b2, b3):
            top.addWidget(x)
        top.addStretch(1); right.addLayout(top)
        inst = W.QHBoxLayout()
        self.add_type = W.QComboBox(); self.add_type.addItems(core.available_types())
        ba = W.QPushButton("＋ Dodaj instancję"); ba.clicked.connect(self.add_inst)
        bd = W.QPushButton("－ Usuń ścieżkę"); bd.clicked.connect(self.del_inst)
        for x in (W.QLabel("Wtyczka:"), self.add_type, ba, bd):
            inst.addWidget(x)
        inst.addStretch(1); right.addLayout(inst)
        # --- routing: pre (nuty z innej ścieżki) i post (audio innej ścieżki jako wejście = instrument jako filtr)
        rg = W.QGroupBox("Routing: pre (nuty) / post (audio → ten instrument jako filtr)"); rl = W.QHBoxLayout(rg)
        self.rt_notes = W.QComboBox(); self.rt_tr = W.QSpinBox(); self.rt_tr.setRange(-36, 36); self.rt_tr.setSuffix(" st")
        self.rt_in = W.QComboBox(); self.rt_mix = W.QSlider(Qt.Orientation.Horizontal); self.rt_mix.setRange(0, 100); self.rt_mix.setFixedWidth(90)
        self.rt_hide = W.QCheckBox("ukryj źródło w miksie"); self.rt_hide.setChecked(True)
        for lbl, wd in (("Nuty z:", self.rt_notes), ("transp.", self.rt_tr), ("Wejście audio z:", self.rt_in), ("mix", self.rt_mix), ("", self.rt_hide)):
            if lbl:
                rl.addWidget(W.QLabel(lbl))
            rl.addWidget(wd)
        rl.addStretch(1); right.addWidget(rg)
        self.rt_notes.currentTextChanged.connect(self._route_changed); self.rt_in.currentTextChanged.connect(self._route_changed)
        self.rt_tr.valueChanged.connect(self._route_changed); self.rt_mix.valueChanged.connect(self._route_changed); self.rt_hide.toggled.connect(self._route_changed)
        # --- grupa nut: okno taktów (też zaznaczane myszą na przeglądzie w zakładce Generator) + operacja
        ng = W.QGroupBox("Edycja grupy nut (okno taktów)"); nl = W.QHBoxLayout(ng)
        self.ne_a = W.QSpinBox(); self.ne_b = W.QSpinBox(); self.ne_a.setMinimum(1); self.ne_b.setMinimum(1); self.ne_a.setMaximum(256); self.ne_b.setMaximum(256)
        self.ne_op = W.QComboBox(); self.ne_op.addItems([o[1] for o in N.OPS])
        self.ne_amt = W.QDoubleSpinBox(); self.ne_amt.setRange(-96, 100); self.ne_amt.setDecimals(2)
        self.ne_scale = W.QComboBox(); self.ne_scale.addItems(list(N.NOTE_SCALES))
        bap = W.QPushButton("Zastosuj"); bun = W.QPushButton("Cofnij"); ball = W.QPushButton("Całość")
        bap.clicked.connect(self.notes_apply); bun.clicked.connect(self.notes_undo); ball.clicked.connect(lambda: (self.ne_a.setValue(1), self.ne_b.setValue(self.ne_b.maximum())))
        self.ne_op.currentIndexChanged.connect(self._op_changed)
        for lbl, wd in (("takty od", self.ne_a), ("do", self.ne_b), ("operacja", self.ne_op), ("parametr", self.ne_amt), ("skala", self.ne_scale)):
            nl.addWidget(W.QLabel(lbl)); nl.addWidget(wd)
        for b_ in (ball, bap, bun):
            nl.addWidget(b_)
        nl.addStretch(1); right.addWidget(ng); self._op_changed(0)
        self.t_scroll = W.QScrollArea(); self.t_scroll.setWidgetResizable(True); right.addWidget(self.t_scroll, 1)
        return w

    def fill_track_list(self):
        cur = max(0, self.tlist.currentRow())
        self.tlist.blockSignals(True); self.tlist.clear()
        for i, t in enumerate(self.proj["tracks"]):
            it = W.QListWidgetItem(f"{t['name']}  ({len(t['notes'])})"); it.setForeground(tcolor(t["type"])); self.tlist.addItem(it)
        self.tlist.blockSignals(False); self.tlist.setCurrentRow(cur); self.show_track(cur)

    def _ov_sel(self, a, b):
        self.ne_a.setValue(a + 1); self.ne_b.setValue(b)
        self.status.setText(f"Zaznaczono takty {a + 1}–{b} (edycja w zakładce Ścieżki → Edycja grupy nut)")

    def _op_changed(self, i):
        key, _, plab, dflt = N.OPS[max(0, i)]
        self.ne_amt.setEnabled(plab is not None); self.ne_amt.setValue(dflt); self.ne_amt.setPrefix((plab + ": ") if plab else "")
        self.ne_scale.setEnabled(key in ("snap", "scale_up", "scale_down", "random_scale"))

    def notes_apply(self):
        if not self.need_proj() or self.tlist.currentRow() < 0:
            return
        t = self.proj["tracks"][self.tlist.currentRow()]
        a, b = min(self.ne_a.value(), self.ne_b.value()) - 1, max(self.ne_a.value(), self.ne_b.value())
        key = N.OPS[self.ne_op.currentIndex()][0]
        old = copy.deepcopy(t["notes"])
        new = N.apply_op(self.proj, t["notes"], key, a, b, self.ne_amt.value() if self.ne_amt.isEnabled() else None, self.ne_scale.currentText())
        self.undo.setdefault(t["name"], []).append(old)
        t["notes"] = new
        self.ov.set_project(self.proj); self.fill_track_list()
        self.status.setText(f"{t['name']}: {N.OPS[self.ne_op.currentIndex()][1]} — takty {a + 1}–{b} ({len(old)} → {len(new)} nut)")

    def notes_undo(self):
        if not self.proj or self.tlist.currentRow() < 0:
            return
        t = self.proj["tracks"][self.tlist.currentRow()]; st = self.undo.get(t["name"])
        if st:
            t["notes"] = st.pop(); self.ov.set_project(self.proj); self.fill_track_list(); self.status.setText(f"{t['name']}: cofnięto")

    def _route_changed(self, *_):
        if not self.proj or self.tlist.currentRow() < 0 or getattr(self, "_rt_lock", False):
            return
        t = self.proj["tracks"][self.tlist.currentRow()]
        nf, inf = self.rt_notes.currentText(), self.rt_in.currentText()
        t["notes_from"] = None if nf.startswith("—") else nf
        t["input_from"] = None if inf.startswith("—") else inf
        t["notes_transpose"] = self.rt_tr.value(); t["input_mix"] = self.rt_mix.value() / 100.0; t["input_hide_source"] = self.rt_hide.isChecked()
        self.ov.set_project(self.proj)

    def _fill_route(self, t):
        self._rt_lock = True
        others = ["— brak —"] + [x["name"] for x in self.proj["tracks"] if x is not t]
        for cb, key in ((self.rt_notes, "notes_from"), (self.rt_in, "input_from")):
            cb.clear(); cb.addItems(others); cb.setCurrentText(t.get(key) or others[0])
        self.rt_tr.setValue(int(t.get("notes_transpose", 0))); self.rt_mix.setValue(int(t.get("input_mix", 1.0) * 100))
        self.rt_hide.setChecked(t.get("input_hide_source", True))
        self._rt_lock = False

    def _tset(self, key, val):
        if self.proj and self.tlist.currentRow() >= 0:
            self.proj["tracks"][self.tlist.currentRow()][key] = val

    def show_track(self, row):
        if row < 0 or not self.proj:
            return
        t = self.proj["tracks"][row]
        self._fill_route(t)
        for wd, v in ((self.t_mute, t["mute"]), (self.t_solo, t["solo"])):
            wd.blockSignals(True); wd.setChecked(v); wd.blockSignals(False)
        self.t_gain.blockSignals(True); self.t_gain.setValue(int(t["gain"] * 100)); self.t_gain.blockSignals(False)
        box = W.QWidget(); lay = W.QVBoxLayout(box)
        if t["type"] == "speak":
            gb = W.QGroupBox("Tekst DS Speak — 1 nuta = 1 słowo (! akcent, ? pytanie, WIELKIE = okrzyk)"); gl = W.QVBoxLayout(gb)
            ed = W.QPlainTextEdit(t.get("text", "")); ed.setMaximumHeight(90)
            ml = W.QLabel("tryb: " + t.get("text_mode", "auto"))
            bapply = W.QPushButton("Zastosuj (ręczny)"); bauto = W.QPushButton("Auto-tekst z motywu")

            def apply_text(_=False, tt=t, e=ed, l=ml):
                tt["text"] = e.toPlainText().strip(); tt["text_mode"] = "manual"; l.setText("tryb: manual")

            def auto_text(_=False, tt=t, e=ed, l=ml):
                rng = random.Random(random.randrange(10 ** 6))
                tt["text"] = G.auto_text(tt.get("text_theme"), self.proj["style"], len(tt["notes"]) or 8, rng)
                tt["text_mode"] = "auto"; e.setPlainText(tt["text"]); l.setText("tryb: auto")
            bapply.clicked.connect(apply_text); bauto.clicked.connect(auto_text)
            rr = W.QHBoxLayout(); rr.addWidget(bapply); rr.addWidget(bauto); rr.addWidget(ml); rr.addStretch(1)
            gl.addWidget(ed); gl.addLayout(rr); lay.addWidget(gb)
        pl = self.meta.plugins[t["plugin"]]; groups = {}
        for name, p in pl["params"].items():
            g = groups.get(p["module"])
            if g is None:
                gb = W.QGroupBox(p["module"]); g = groups[p["module"]] = W.QFormLayout(gb); lay.addWidget(gb)
            frac = t["params"].get(name, self.meta.def_frac(t["type"], name))
            s = W.QSlider(Qt.Orientation.Horizontal); s.setRange(0, 1000); s.setValue(int(frac * 1000))
            lab = W.QLabel(self.meta.fmt(t["type"], name, frac)); lab.setMinimumWidth(90)
            s.valueChanged.connect(lambda val, n=name, l=lab, tt=t: self._param(tt, n, val / 1000, l))
            row_w = W.QWidget(); rl = W.QHBoxLayout(row_w); rl.setContentsMargins(0, 0, 0, 0); rl.addWidget(s, 1); rl.addWidget(lab)
            g.addRow(name, row_w)
        lay.addStretch(1); self.t_scroll.setWidget(box)

    def _param(self, t, name, frac, lab):
        t["params"][name] = frac; lab.setText(self.meta.fmt(t["type"], name, frac))

    def add_inst(self):
        if not self.need_proj():
            return
        tr = G.add_instance(self.proj, self.add_type.currentText())
        self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()
        self.tlist.setCurrentRow([t["name"] for t in self.proj["tracks"]].index(tr["name"]))
        self.status.setText(f"Dodano instancję: {tr['name']} ({len(self.proj['tracks'])} ścieżek)")

    def del_inst(self):
        if not self.need_proj() or self.tlist.currentRow() < 0 or len(self.proj["tracks"]) < 2:
            return
        G.remove_track(self.proj, self.proj["tracks"][self.tlist.currentRow()]["name"])
        self.tlist.setCurrentRow(0); self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()

    def reroll(self, sound, notes):
        if not self.need_proj():
            return
        tr = self.proj["tracks"][self.tlist.currentRow()]
        if notes:
            G.reroll_track(self.proj, tr["name"], sound=sound)
        else:
            G.randomize_sound(self.proj, tr, random.Random(random.randrange(10 ** 6)))
        self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()

    # ------------------------------------------------------------------ Linki
    def _build_links(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel("Źródła (akcent kick/snare/hat, energia sekcji, build, faza taktu, wysokość basu) sterują parametrami dowolnej ścieżki.\n"
                             "Np. kick → Level basów = sidechain; build → Cutoff screecha; bass_note → Vowel growla."))
        self.ltab = W.QTableWidget(0, 5); self.ltab.setHorizontalHeaderLabels(["Źródło", "Ścieżka docelowa", "Parametr", "Ilość (−1…1)", "Release (beaty)"])
        self.ltab.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        v.addWidget(self.ltab, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Dodaj link", self.link_add), ("Usuń zaznaczony", self.link_del), ("Przywróć domyślne dla stylu", self.link_reset)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        r.addStretch(1); v.addLayout(r)
        return w

    def _names(self):
        return [t["name"] for t in self.proj["tracks"]] if self.proj else []

    def _params_for(self, track):
        t = core.find_track(self.proj, track) if self.proj else None
        if t is None:
            return []
        return [n for n, p in self.meta.plugins[t["plugin"]]["params"].items() if p["kind"] != "int"]

    def fill_links(self):
        self.ltab.setRowCount(0)
        for L in (self.proj["links"] if self.proj else []):
            self._link_row(L)

    def _link_row(self, L):
        r = self.ltab.rowCount(); self.ltab.insertRow(r)
        src = W.QComboBox(); src.addItems(core.LINK_SOURCES); src.setCurrentText(L["src"])
        dst = W.QComboBox(); dst.addItems(self._names()); dst.setCurrentText(L["dst"])
        par = W.QComboBox(); par.addItems(self._params_for(L["dst"])); par.setCurrentText(L["param"])
        amt = W.QDoubleSpinBox(); amt.setRange(-1, 1); amt.setSingleStep(0.05); amt.setValue(L["amount"])
        rel = W.QDoubleSpinBox(); rel.setRange(0.05, 8); rel.setSingleStep(0.05); rel.setValue(L.get("rel", 0.5))

        def sync(*_):
            L["src"], L["dst"], L["param"], L["amount"], L["rel"] = src.currentText(), dst.currentText(), par.currentText(), amt.value(), rel.value()

        def dst_changed(tn):
            par.blockSignals(True); par.clear(); par.addItems(self._params_for(tn)); par.blockSignals(False); sync()
        dst.currentTextChanged.connect(dst_changed)
        for wd in (src, par):
            wd.currentTextChanged.connect(sync)
        for wd in (amt, rel):
            wd.valueChanged.connect(sync)
        for c, wd in enumerate((src, dst, par, amt, rel)):
            self.ltab.setCellWidget(r, c, wd)

    def link_add(self):
        if self.need_proj():
            names = self._names()
            L = {"src": "kick", "dst": "sub" if "sub" in names else names[0], "param": "Level", "amount": -0.3, "rel": 0.5}
            self.proj["links"].append(L); self._link_row(L)

    def link_del(self):
        r = self.ltab.currentRow()
        if self.proj and r >= 0:
            del self.proj["links"][r]; self.fill_links()

    def link_reset(self):
        if self.need_proj():
            self.proj["links"] = G.default_links(self.proj["style"], self.proj["tracks"]); self.fill_links()

    # ------------------------------------------------------------------ Biblioteka
    def _build_lib(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        self.lib = W.QTableWidget(0, 7)
        self.lib.setHorizontalHeaderLabels(["Nazwa", "Styl", "BPM", "Tonacja", "Takty", "Utworzono", "Rodzice"])
        self.lib.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        self.lib.setSelectionBehavior(W.QAbstractItemView.SelectionBehavior.SelectRows)
        self.lib.setSelectionMode(W.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.lib.setEditTriggers(W.QAbstractItemView.EditTrigger.NoEditTriggers)
        v.addWidget(W.QLabel(f"Biblioteka: {core.lib_dir()}"))
        v.addWidget(self.lib, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Odśwież", self.refresh_library), ("▶ Odtwórz", self.lib_play), ("■ Stop", lambda: self.player.stop()),
                        ("Wczytaj do edytora", self.lib_load), ("Usuń", self.lib_delete), ("Otwórz folder", self.lib_open),
                        ("→ Do auto-remixu", self.lib_to_remix)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)
        return w

    def refresh_library(self):
        self.entries = core.list_library(); self.lib.setRowCount(len(self.entries))
        for i, e in enumerate(self.entries):
            for c, val in enumerate([e["name"], e["style"], e["bpm"], e["key"], e["bars"], e["created"], ", ".join(e["parents"])]):
                self.lib.setItem(i, c, W.QTableWidgetItem(str(val)))

    def _sel(self):
        return [self.entries[i.row()] for i in self.lib.selectionModel().selectedRows()]

    def lib_play(self):
        s = self._sel()
        if s and s[0]["audio"]:
            self.player.play(s[0]["audio"])

    def lib_load(self):
        s = self._sel()
        if s:
            self.set_project(core.load_project(s[0]["path"])); self.tabs.setCurrentIndex(0)
            self.status.setText(f"Wczytano {s[0]['name']}")

    def lib_delete(self):
        s = self._sel()
        if s and W.QMessageBox.question(self, "Usuń", f"Usunąć {len(s)} pozycji z dysku?") == W.QMessageBox.StandardButton.Yes:
            for e in s:
                core.delete_library_entry(e["path"])
            self.refresh_library()

    def lib_open(self):
        s = self._sel()
        subprocess.Popen(["xdg-open", str(s[0]["path"] if s else core.lib_dir())])

    def lib_to_remix(self):
        s = self._sel()
        if len(s) < 1:
            return
        self.remix_entries = [(e["path"], core.load_project(e["path"])) for e in s]
        for p, pr in self.remix_entries:
            pr["id"] = Path(p).name
        self.fill_remix(); self.tabs.setCurrentIndex(4)

    # ------------------------------------------------------------------ Remix
    def _build_remix(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel("Wybierz utwory w Bibliotece → „Do auto-remixu”. W tabeli zaznacz, z którego utworu ma pochodzić każda ścieżka.\n"
                             "Wiersze = wszystkie instrumenty z wybranych utworów (24 typy, także kilka instancji). Struktura, progresja i linki z mastera; nuty/brzmienie ze źródeł."))
        f = W.QHBoxLayout()
        self.r_master = W.QComboBox(); self.r_bpm = W.QSpinBox(); self.r_bpm.setRange(0, 220); self.r_bpm.setSpecialValueText("z mastera")
        self.r_key = W.QComboBox(); self.r_key.addItems(["z mastera"] + core.NOTE_NAMES)
        self.r_harm = W.QCheckBox("Przeharmonizuj ścieżki melodyczne do progresji mastera"); self.r_harm.setChecked(True)
        self.r_name = W.QLineEdit(); self.r_name.setPlaceholderText("nazwa remixu")
        for lbl, wd in (("Master:", self.r_master), ("BPM:", self.r_bpm), ("Tonacja:", self.r_key)):
            f.addWidget(W.QLabel(lbl)); f.addWidget(wd)
        v.addLayout(f); v.addWidget(self.r_harm); v.addWidget(self.r_name)
        self.rtab = W.QTableWidget(0, 0); v.addWidget(self.rtab, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Auto-remix (losowe przypisanie)", self.remix_auto), ("Zbuduj i podglądaj", lambda: self.remix_build(False)),
                        ("Zbuduj i zapisz do biblioteki", lambda: self.remix_build(True))):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)
        self.rgroups = {}; self.rnames = []
        return w

    def fill_remix(self):
        projs = [p for _, p in self.remix_entries]; n = len(projs)
        self.rnames = R.track_names(projs)
        self.r_master.clear(); self.r_master.addItems([p["name"] for p in projs])
        self.rtab.setColumnCount(n + 1); self.rtab.setRowCount(len(self.rnames))
        self.rtab.setHorizontalHeaderLabels(["— wył. —"] + [f"{p['name']}\n{p['style']} {p['bpm']}bpm {core.key_name(p)}" for p in projs])
        self.rtab.setVerticalHeaderLabels(self.rnames)
        self.rtab.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        self.rgroups = {}
        for r, name in enumerate(self.rnames):
            grp = W.QButtonGroup(self); self.rgroups[name] = grp
            off = W.QRadioButton("—"); grp.addButton(off, 0); self.rtab.setCellWidget(r, 0, off)
            first = True
            for c, p in enumerate(projs):
                t = core.find_track(p, name); cnt = len(t["notes"]) if t else 0
                rb = W.QRadioButton(f"{cnt} nut"); grp.addButton(rb, c + 1); rb.setEnabled(cnt > 0)
                if cnt and first:
                    rb.setChecked(True); first = False
                self.rtab.setCellWidget(r, c + 1, rb)
            if first:
                off.setChecked(True)

    def remix_auto(self):
        if not self.remix_entries:
            return
        rng = random.Random(random.randrange(10 ** 6))
        projs = [p for _, p in self.remix_entries]
        master, assign = R.auto_assign(projs, rng)
        ids = [p["id"] for p in projs]
        self.r_master.setCurrentIndex(ids.index(master["id"]))
        for name in self.rnames:
            p = assign.get(name)
            self.rgroups[name].button(0 if p is None else ids.index(p["id"]) + 1).setChecked(True)

    def remix_build(self, save):
        if not self.remix_entries:
            return
        projs = [p for _, p in self.remix_entries]
        master = projs[self.r_master.currentIndex()]
        assign = {n: (None if self.rgroups[n].checkedId() <= 0 else projs[self.rgroups[n].checkedId() - 1]) for n in self.rnames}
        if not any(assign.values()):
            W.QMessageBox.information(self, "DS Studio", "Wybierz źródło dla przynajmniej jednej ścieżki."); return
        key = None if self.r_key.currentIndex() == 0 else self.r_key.currentIndex() - 1
        p = R.remix(assign, master, bpm=self.r_bpm.value() or None, key=key, harmony=self.r_harm.isChecked(),
                    name=self.r_name.text() or None, seed=random.randrange(10 ** 6))
        self.set_project(p)
        self.status.setText(f"Remix: {p['name']} ({core.key_name(p)}, {p['bpm']} BPM, {len(p['tracks'])} ścieżek)")
        if save:
            self.save_lib()
        else:
            self.tabs.setCurrentIndex(0); self.preview()

    def closeEvent(self, e):
        self.live.shutdown(); self.player.stop(); super().closeEvent(e)


def main():
    app = W.QApplication(sys.argv)
    app.setStyle("Fusion")
    pal = QtGui.QPalette()
    for role, col in ((QtGui.QPalette.ColorRole.Window, "#14161b"), (QtGui.QPalette.ColorRole.WindowText, "#e5e7eb"),
                      (QtGui.QPalette.ColorRole.Base, "#0f1115"), (QtGui.QPalette.ColorRole.AlternateBase, "#14161b"),
                      (QtGui.QPalette.ColorRole.Text, "#e5e7eb"), (QtGui.QPalette.ColorRole.Button, "#1f232b"),
                      (QtGui.QPalette.ColorRole.ButtonText, "#e5e7eb"), (QtGui.QPalette.ColorRole.Highlight, "#e5484d"),
                      (QtGui.QPalette.ColorRole.HighlightedText, "#ffffff")):
        pal.setColor(role, QtGui.QColor(col))
    app.setPalette(pal)
    try:
        win = MainWindow()
    except Exception as ex:
        W.QMessageBox.critical(None, "DS Dubstep Studio", str(ex)); return 1
    win.show()
    return app.exec()
