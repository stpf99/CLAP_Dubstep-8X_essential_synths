// ds_speech.h — moduł mowy dla "DS Speak": angielski G2P (litery -> fonemy), analiza słowa
// (akcent, redukcja samogłosek, kontur intonacji) i budowa listy segmentów artykulacji.
//
// Idea: każda litera/fonem to punkt w przestrzeni (formanty F1-F3, głos, szum, wysokość na skali).
// Po analizie całego słowa każdy segment dostaje już "dopasowane" wartości (akcent, kontur, długość),
// a silnik tylko morfuje płynnie z segmentu do segmentu (koartykulacja) i gra to na oscylatorach.
#pragma once
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>

namespace ds {
namespace sp {

// ---------------------------------------------------------------- segment artykulacji
struct Seg {
  float f1 = 500, f2 = 1500, f3 = 2500;  // formanty (Hz)
  float av = 0, af = 0, ah = 0;          // amplituda głosu / frykacji / aspiracji (0..1)
  float nc = 4000, nq = 1;               // środek i dobroć pasma szumu frykacyjnego
  float dur = 80;                        // ms przy Speed = 1
  float slot = 0;                        // pozycja litery na skali wysokości (-1..1)
  float contour = 0;                     // kontur intonacji w półtonach (przy Intonation = 1)
  float ramp = -1;                       // ms przejścia do segmentu (-1 = parametr Morph Time)
  bool nucleus = false, stressed = false, takeNext = false, asp = false;
};
struct Word {
  std::string txt;
  std::vector<Seg> segs;
  int hold = -1;      // segment, na którym można "trzymać" samogłoskę (-1 = brak)
  float gain = 1.f;   // akcent/okrzyk
};
struct Script { std::vector<Word> words, units; };  // words: tryb słowny, units: tryb literowy (1 fonem = 1 nuta)

// ---------------------------------------------------------------- tablica fonemów
enum Cls { VOW, NAS, LIQ, FRI, STP, AFF, ASP };
struct Ph { const char* s; Cls c; float f1, f2, f3, dur, av, af, nc, nq, slot; bool voiced; };

inline const Ph PH[] = {
  // samogłoski: formanty (Peterson&Barney, męski głos), czas, slot = naturalna wysokość samogłoski (wysokie = wyżej)
  {"IY", VOW, 270, 2290, 3010, 120, 1, 0, 0, 0, 0.90f, true},
  {"IH", VOW, 390, 1990, 2550, 85, 1, 0, 0, 0, 0.55f, true},
  {"EH", VOW, 530, 1840, 2480, 95, 1, 0, 0, 0, 0.20f, true},
  {"AE", VOW, 660, 1720, 2410, 110, 1, 0, 0, 0, -0.15f, true},
  {"AA", VOW, 730, 1090, 2440, 120, 1, 0, 0, 0, -0.70f, true},
  {"AO", VOW, 570, 840, 2410, 120, 1, 0, 0, 0, -0.60f, true},
  {"AH", VOW, 640, 1190, 2390, 85, 1, 0, 0, 0, -0.30f, true},
  {"UH", VOW, 440, 1020, 2240, 85, 1, 0, 0, 0, 0.10f, true},
  {"UW", VOW, 300, 870, 2240, 120, 1, 0, 0, 0, 0.70f, true},
  {"ER", VOW, 490, 1350, 1690, 115, 1, 0, 0, 0, 0.00f, true},
  {"AX", VOW, 500, 1500, 2500, 55, 1, 0, 0, 0, 0.00f, true},
  {"OH", VOW, 450, 880, 2500, 100, 1, 0, 0, 0, -0.40f, true},
  // nosowe
  {"M", NAS, 250, 1100, 2200, 80, 0.55f, 0, 0, 0, -0.40f, true},
  {"N", NAS, 250, 1500, 2500, 70, 0.55f, 0, 0, 0, 0.00f, true},
  {"NG", NAS, 250, 2000, 2700, 85, 0.55f, 0, 0, 0, 0.30f, true},
  // płynne i półsamogłoski
  {"L", LIQ, 360, 1100, 2700, 70, 0.85f, 0, 0, 0, 0.20f, true},
  {"R", LIQ, 330, 1050, 1400, 80, 0.85f, 0, 0, 0, -0.20f, true},
  {"W", LIQ, 290, 610, 2150, 65, 0.80f, 0, 0, 0, 0.50f, true},
  {"Y", LIQ, 260, 2070, 3020, 60, 0.80f, 0, 0, 0, 0.80f, true},
  // szczelinowe (nc/nq = środek i dobroć szumu)
  {"F", FRI, 400, 1400, 2500, 85, 0.00f, 0.30f, 6500, 0.35f, 0, false},
  {"V", FRI, 400, 1400, 2500, 65, 0.45f, 0.18f, 6000, 0.35f, -0.30f, true},
  {"TH", FRI, 400, 1400, 2500, 85, 0.00f, 0.22f, 6800, 0.35f, 0, false},
  {"DH", FRI, 400, 1400, 2500, 55, 0.45f, 0.12f, 6500, 0.35f, -0.30f, true},
  {"S", FRI, 400, 1400, 2500, 100, 0.00f, 0.85f, 7200, 1.00f, 0, false},
  {"Z", FRI, 400, 1400, 2500, 80, 0.40f, 0.50f, 6800, 1.00f, -0.25f, true},
  {"SH", FRI, 400, 1400, 2500, 105, 0.00f, 0.85f, 3400, 0.80f, 0, false},
  {"ZH", FRI, 400, 1400, 2500, 80, 0.40f, 0.50f, 3000, 0.80f, -0.25f, true},
  // zwarte (nc/nq = szum wybuchu wg miejsca artykulacji)
  {"P", STP, 400, 1400, 2500, 55, 0, 0.80f, 1100, 0.50f, 0, false},
  {"T", STP, 400, 1400, 2500, 55, 0, 0.80f, 4800, 0.90f, 0, false},
  {"K", STP, 400, 1400, 2500, 55, 0, 0.80f, 2300, 0.80f, 0, false},
  {"B", STP, 400, 1400, 2500, 45, 0, 0.70f, 900, 0.50f, -0.30f, true},
  {"D", STP, 400, 1400, 2500, 45, 0, 0.70f, 3800, 0.80f, -0.20f, true},
  {"G", STP, 400, 1400, 2500, 45, 0, 0.70f, 2000, 0.70f, -0.20f, true},
  // zwarto-szczelinowe
  {"CH", AFF, 400, 1400, 2500, 40, 0, 0.85f, 3400, 0.80f, 0, false},
  {"JH", AFF, 400, 1400, 2500, 35, 0, 0.55f, 3200, 0.80f, -0.20f, true},
  // aspiracja
  {"HH", ASP, 500, 1500, 2500, 65, 0, 0, 0, 0, 0, false},
};
inline const Ph* findPh(const std::string& s) {
  for (const Ph& p : PH) if (s == p.s) return &p;
  return nullptr;
}
struct Dip { const char* s; const char* a; const char* b; };
inline const Dip DIP[] = {{"EY", "EH", "IY"}, {"AY", "AA", "IH"}, {"OY", "AO", "IH"}, {"AW", "AA", "UH"}, {"OW", "OH", "UH"}};
inline bool isVowelSym(const std::string& s) {
  const Ph* p = findPh(s);
  if (p) return p->c == VOW;
  for (const Dip& d : DIP) if (s == d.s) return true;
  return false;
}

struct Unit { std::string s; int stress = 0; };  // stress: 1 = akcent główny (tylko samogłoski)

// ---------------------------------------------------------------- rozwinięcie fonemu w segmenty
inline Seg vowSeg(const Ph& p, int stress, float durScale) {
  Seg s; s.f1 = p.f1; s.f2 = p.f2; s.f3 = p.f3; s.av = 1.f;
  float d = p.dur;
  if (std::strcmp(p.s, "AX")) d *= (stress == 1 ? 1.2f : 0.8f);
  s.dur = d * durScale; s.slot = p.slot; s.nucleus = true; s.stressed = stress == 1;
  return s;
}
inline void expandUnit(const Unit& u, std::vector<Seg>& out) {
  for (const Dip& d : DIP) {
    if (u.s != d.s) continue;
    Seg a = vowSeg(*findPh(d.a), u.stress, 0.78f), b = vowSeg(*findPh(d.b), u.stress, 0.62f);
    b.nucleus = false; b.stressed = false;
    out.push_back(a); out.push_back(b);
    return;
  }
  const Ph* p = findPh(u.s);
  if (!p) return;
  switch (p->c) {
    case VOW: out.push_back(vowSeg(*p, u.stress, 1.f)); break;
    case NAS: case LIQ: {
      Seg s; s.f1 = p->f1; s.f2 = p->f2; s.f3 = p->f3; s.av = p->av; s.dur = p->dur; s.slot = p->slot;
      out.push_back(s);
    } break;
    case FRI: {
      Seg s; s.f1 = p->f1; s.f2 = p->f2; s.f3 = p->f3; s.av = p->av; s.af = p->af; s.nc = p->nc; s.nq = p->nq;
      s.dur = p->dur; s.slot = p->slot; s.takeNext = p->av > 0.f;
      out.push_back(s);
    } break;
    case STP: {
      Seg c; c.av = p->voiced ? 0.25f : 0.f; c.dur = p->voiced ? 45.f : 55.f; c.ramp = 4.f; c.takeNext = true; c.slot = p->slot;
      Seg b; b.af = p->af; b.nc = p->nc; b.nq = p->nq; b.av = p->voiced ? 0.3f : 0.f; b.dur = 12.f; b.ramp = 2.f; b.takeNext = true; b.slot = p->slot;
      out.push_back(c); out.push_back(b);
      if (!p->voiced) { Seg a; a.ah = 0.7f; a.dur = 40.f; a.ramp = 6.f; a.takeNext = true; a.asp = true; out.push_back(a); }
    } break;
    case AFF: {
      Seg c; c.av = p->voiced ? 0.25f : 0.f; c.dur = 38.f; c.ramp = 4.f; c.takeNext = true; c.slot = p->slot;
      Seg f; f.af = p->af; f.nc = p->nc; f.nq = p->nq; f.av = p->voiced ? 0.35f : 0.f; f.dur = p->voiced ? 60.f : 75.f;
      f.ramp = 4.f; f.takeNext = true; f.slot = p->slot;
      out.push_back(c); out.push_back(f);
    } break;
    case ASP: {
      Seg a; a.ah = 0.8f; a.dur = p->dur; a.ramp = 8.f; a.takeNext = true; a.asp = true;
      out.push_back(a);
    } break;
  }
}

// ---------------------------------------------------------------- leksykon wyjątków (słownictwo dubstepowe + słowa funkcyjne)
struct Lex { const char* w; const char* ph; };
inline const Lex LEX[] = {
  {"the", "DH AX"}, {"a", "AX"}, {"an", "AX N"}, {"and", "AX N D"}, {"of", "AX V"}, {"to", "T UW"}, {"is", "IH Z"},
  {"are", "AA R"}, {"was", "W AH Z"}, {"be", "B IY"}, {"been", "B IH N"}, {"you", "Y UW"}, {"your", "Y AO R"},
  {"i", "AY"}, {"me", "M IY"}, {"my", "M AY"}, {"we", "W IY"}, {"he", "HH IY"}, {"she", "SH IY"}, {"it", "IH T"},
  {"they", "DH EY"}, {"them", "DH EH M"}, {"this", "DH IH S"}, {"that", "DH AE T"}, {"these", "DH IY Z"},
  {"those", "DH OW Z"}, {"then", "DH EH N"}, {"there", "DH EH R"}, {"with", "W IH TH"}, {"from", "F R AH M"},
  {"have", "HH AE V"}, {"has", "HH AE Z"}, {"had", "HH AE D"}, {"do", "D UW"}, {"does", "D AH Z"}, {"done", "D AH N"},
  {"one", "W AH N"}, {"two", "T UW"}, {"three", "TH R IY"}, {"four", "F AO R"}, {"five", "F AY V"}, {"six", "S IH K S"},
  {"seven", "S EH V AX N"}, {"eight", "EY T"}, {"nine", "N AY N"}, {"ten", "T EH N"}, {"zero", "Z IY R OW"},
  {"come", "K AH M"}, {"some", "S AH M"}, {"love", "L AH V"}, {"give", "G IH V"}, {"get", "G EH T"}, {"girl", "G ER L"},
  {"gift", "G IH F T"}, {"oh", "OW"}, {"ah", "AA"}, {"uh", "AH"}, {"yeah", "Y AE"}, {"yes", "Y EH S"}, {"no", "N OW"},
  {"go", "G OW"}, {"so", "S OW"}, {"hey", "HH EY"}, {"hi", "HH AY"}, {"bass", "B EY S"}, {"drop", "D R AA P"},
  {"wobble", "W AA B AX L"}, {"dubstep", "D AH B S T EH P"}, {"dub", "D AH B"}, {"wub", "W AH B"}, {"step", "S T EH P"},
  {"beat", "B IY T"}, {"hands", "HH AE N D Z"}, {"up", "AH P"}, {"feel", "F IY L"}, {"sub", "S AH B"},
  {"sound", "S AW N D"}, {"system", "S IH S T AX M"}, {"hear", "HH IH R"}, {"turn", "T ER N"}, {"louder", "L AW D ER"},
  {"fire", "F AY ER"}, {"night", "N AY T"}, {"rave", "R EY V"}, {"party", "P AA R T IY"}, {"music", "M Y UW Z IH K"},
  {"ready", "R EH D IY"}, {"rewind", "R IY W 'AY N D"}, {"pull", "P UH L"}, {"lets", "L EH T S"}, {"wait", "W EY T"},
  {"what", "W AH T"}, {"where", "W EH R"}, {"who", "HH UW"}, {"why", "W AY"}, {"how", "HH AW"}, {"now", "N AW"},
  {"wow", "W AW"}, {"great", "G R EY T"}, {"people", "P IY P AX L"}, {"growl", "G R AW L"}, {"bassline", "B EY S L AY N"},
  {"good", "G UH D"}, {"look", "L UH K"}, {"book", "B UH K"}, {"hour", "AW ER"}, {"our", "AW ER"}, {"head", "HH EH D"},
  {"dead", "D EH D"}, {"bread", "B R EH D"}, {"heavy", "HH EH V IY"}, {"again", "AX G EH N"}, {"about", "AX B AW T"},
  {"loud", "L AW D"}, {"noise", "N OY Z"}, {"make", "M EY K"}, {"world", "W ER L D"}, {"more", "M AO R"},
  {"down", "D AW N"}, {"jump", "JH AH M P"}, {"bounce", "B AW N S"}, {"crazy", "K R EY Z IY"}, {"brother", "B R AH DH ER"},
  {"begin", "B IH G IH N"}, {"cow", "K AW"}, {"vow", "V AW"}, {"allow", "AX L AW"}, {"machine", "M AX SH IY N"},
  {"wicked", "W IH K IH D"}, {"sick", "S IH K"}, {"yo", "Y OW"}, {"everybody", "EH V R IY B AA D IY"}, {"scream", "S K R IY M"}, {"shake", "SH EY K"}, {"break", "B R EY K"},
};

inline std::vector<Unit> parsePh(const char* ph) {
  std::vector<Unit> out; std::string tok;
  for (const char* c = ph;; c++) {
    if (*c == ' ' || !*c) {
      if (!tok.empty()) {
        Unit u;
        if (tok[0] == '\'') { u.stress = 1; u.s = tok.substr(1); } else u.s = tok;
        out.push_back(u); tok.clear();
      }
      if (!*c) break;
    } else tok += *c;
  }
  return out;
}

// ---------------------------------------------------------------- reguły G2P (angielski, uproszczone)
inline std::vector<Unit> g2pRules(const std::string& w, bool& prefixCase) {
  std::vector<Unit> out; const int n = (int)w.size();
  prefixCase = false;
  auto at = [&](int i) -> char { return (i >= 0 && i < n) ? w[i] : '\0'; };
  auto isV = [](char c) { return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'; };
  auto isC = [&](char c) { return c >= 'a' && c <= 'z' && !isV(c); };
  auto starts = [&](int i, const char* s) { size_t L = std::strlen(s); return i >= 0 && (size_t)i + L <= (size_t)n && w.compare(i, L, s) == 0; };
  auto E = [&](const char* s) { Unit u; u.s = s; out.push_back(u); };
  int vowelLetters = 0;
  for (char c : w) if (isV(c)) vowelLetters++;
  const bool finalE = n >= 2 && w[n - 1] == 'e' && isC(at(n - 2)) && vowelLetters >= 2;
  auto magic = [&](int i) {  // V C e#  albo  V C le#
    if (i + 2 == n - 1 && at(n - 1) == 'e' && isC(at(i + 1)) && vowelLetters >= 2) return true;
    if (i + 3 == n - 1 && at(i + 2) == 'l' && at(n - 1) == 'e' && isC(at(i + 1)) && at(i + 1) != 'l') return true;
    return false;
  };
  auto voicedBefore = [&](char c) { return isV(c) || std::strchr("bdgjlmnrvwyz", c) != nullptr; };

  if ((starts(0, "be") || starts(0, "de") || starts(0, "re")) && vowelLetters >= 2 && isC(at(2))) prefixCase = true;
  else if (isV(at(0)) && at(0) == 'a' && isC(at(1)) && vowelLetters >= 2 && !starts(0, "al") ) prefixCase = true;
  else if (starts(0, "ex") && vowelLetters >= 2 && isC(at(2))) prefixCase = true;

  int i = 0;
  while (i < n) {
    const char c = w[i];
    // ---------- samogłoski
    if (c == 'a') {
      if (starts(i, "ai") || starts(i, "ay")) { E("EY"); i += 2; }
      else if (starts(i, "au") || starts(i, "aw")) { E("AO"); i += 2; }
      else if (starts(i, "all")) { E("AO"); E("L"); i += 3; }
      else if (starts(i, "are") && i + 3 == n) { E("EH"); E("R"); i += 3; }
      else if (starts(i, "air")) { E("EH"); E("R"); i += 3; }
      else if (starts(i, "ar")) { E("AA"); E("R"); i += 2; }
      else if (magic(i)) { E("EY"); i++; }
      else if (i == n - 1) { E(vowelLetters == 1 ? "AA" : "AX"); i++; }
      else if (at(i - 1) == 'w') { E("AA"); i++; }
      else { E("AE"); i++; }
    } else if (c == 'e') {
      if (i == n - 1 && finalE) { i++; }                                           // ciche końcowe e
      else if (i == n - 2 && at(n - 1) == 'd' && isC(at(i - 1)) && vowelLetters >= 2) {  // -ed
        char p = at(i - 1);
        if (p == 't' || p == 'd') { E("IH"); E("D"); }
        else if (std::strchr("pkfsxh", p)) E("T");
        else E("D");
        i += 2;
      }
      else if (starts(i, "ee")) { if (starts(i, "eer")) { E("IH"); E("R"); i += 3; } else { E("IY"); i += 2; } }
      else if (starts(i, "ear")) { E("IH"); E("R"); i += 3; }
      else if (starts(i, "ea")) { E("IY"); i += 2; }
      else if (starts(i, "eigh")) { E("EY"); i += 4; }
      else if (starts(i, "ei")) { E("EY"); i += 2; }
      else if (starts(i, "ey")) { E(i + 2 == n ? "IY" : "EY"); i += 2; }
      else if (starts(i, "ew") || starts(i, "eu")) { E("UW"); i += 2; }
      else if (starts(i, "er")) { E("ER"); i += 2; }
      else if (magic(i)) { E("IY"); i++; }
      else if (i == n - 1) { E(vowelLetters == 1 ? "IY" : "IY"); i++; }
      else { E("EH"); i++; }
    } else if (c == 'i') {
      if (starts(i, "igh")) { E("AY"); i += 3; }
      else if (starts(i, "ire") && i + 3 == n) { E("AY"); E("ER"); i += 3; }
      else if (starts(i, "ie")) { if (i + 2 == n) E("AY"); else E("IY"); i += 2; }
      else if (starts(i, "ir")) { E("ER"); i += 2; }
      else if (starts(i, "ind") || starts(i, "ild")) { E("AY"); i++; }
      else if (magic(i)) { E("AY"); i++; }
      else if (i == n - 1) { E(vowelLetters == 1 ? "AY" : "IY"); i++; }
      else { E("IH"); i++; }
    } else if (c == 'o') {
      if (starts(i, "oo")) { if (starts(i, "oor")) { E("AO"); E("R"); i += 3; } else { E(starts(i, "ook") ? "UH" : "UW"); i += 2; } }
      else if (starts(i, "oa")) { if (starts(i, "oar")) { E("AO"); E("R"); i += 3; } else { E("OW"); i += 2; } }
      else if (starts(i, "oi") || starts(i, "oy")) { E("OY"); i += 2; }
      else if (starts(i, "our")) { E("AW"); E("ER"); i += 3; }
      else if (starts(i, "ou")) { E("AW"); i += 2; }
      else if (starts(i, "ow")) {
        bool fin = i + 2 == n;
        if (!fin && (at(i + 2) == 'n' || at(i + 2) == 'l' || at(i + 2) == 'd' || starts(i + 2, "er"))) E("AW"); else E("OW");
        i += 2;
      }
      else if (starts(i, "ore") && i + 3 == n) { E("AO"); E("R"); i += 3; }
      else if (starts(i, "or")) { if (i + 2 == n && i > 0) { E("ER"); } else { E("AO"); E("R"); } i += 2; }
      else if (starts(i, "old") || starts(i, "olt") || starts(i, "olk")) { E("OW"); i++; }
      else if (magic(i)) { E("OW"); i++; }
      else if (i == n - 1) { E(vowelLetters == 1 ? "OW" : "OW"); i++; }
      else { E("AA"); i++; }
    } else if (c == 'u') {
      if (starts(i, "ui")) { E("UW"); i += 2; }
      else if (starts(i, "ur")) { E("ER"); i += 2; }
      else if (starts(i, "ue") && i + 2 == n) { E("UW"); i += 2; }
      else if (magic(i)) { E("UW"); i++; }
      else if (i == n - 1) { E(vowelLetters == 1 ? "UW" : "UW"); i++; }
      else { E("AH"); i++; }
    } else if (c == 'y') {
      if (i == 0 || isV(at(i - 1))) { E("Y"); i++; }
      else if (i == n - 1) { E(vowelLetters == 0 ? "AY" : (vowelLetters == 1 && n <= 3 ? "AY" : "IY")); i++; }
      else { E("IH"); i++; }
    }
    // ---------- spółgłoski
    else if (c == 'c') {
      if (starts(i, "ch")) { E("CH"); i += 2; }
      else if (starts(i, "ck")) { E("K"); i += 2; }
      else if (starts(i, "cc") && (at(i + 2) == 'e' || at(i + 2) == 'i')) { E("K"); E("S"); i += 2; }
      else if (starts(i, "cc")) { E("K"); i += 2; }
      else if (at(i + 1) == 'e' || at(i + 1) == 'i' || at(i + 1) == 'y') { E("S"); i++; }
      else { E("K"); i++; }
    } else if (c == 'g') {
      if (starts(i, "ght")) { i += 2; }                                // night, light: gh ciche
      else if (starts(i, "gh")) { if (i == 0) { E("G"); } i += 2; }
      else if (starts(i, "gn") && (i == 0 || i + 2 == n)) { if (i == 0) { E("N"); } else { E("N"); } i += 2; }
      else if (starts(i, "gg")) { E("G"); i += 2; }
      else if (at(i + 1) == 'e' || at(i + 1) == 'i' || at(i + 1) == 'y') { E("JH"); i++; }
      else { E("G"); i++; }
    } else if (c == 'd') {
      if (starts(i, "dge")) { E("JH"); i += 3; }
      else if (starts(i, "dd")) { E("D"); i += 2; }
      else { E("D"); i++; }
    } else if (c == 'h') {
      if (i == 0) E("HH");
      else if (isV(at(i - 1)) && !isV(at(i + 1))) { /* ah, oh, uh: ciche h */ }
      else E("HH");
      i++;
    } else if (c == 'k') {
      if (starts(i, "kn") && i == 0) { i++; } else { E("K"); i++; }
    } else if (c == 'l') {
      if (i == n - 2 && at(n - 1) == 'e' && isC(at(i - 1))) { E("AX"); E("L"); i += 2; }
      else if (starts(i, "ll")) { E("L"); i += 2; }
      else { E("L"); i++; }
    } else if (c == 'n') {
      if (starts(i, "nge") && i + 3 == n) { E("N"); E("JH"); i += 3; }
      else if (starts(i, "ng")) { E("NG"); i += 2; }
      else if (starts(i, "nk")) { E("NG"); E("K"); i += 2; }
      else if (starts(i, "nn")) { E("N"); i += 2; }
      else { E("N"); i++; }
    } else if (c == 'm') {
      if (starts(i, "mb") && i + 2 == n) { E("M"); i += 2; }
      else if (starts(i, "mm")) { E("M"); i += 2; }
      else { E("M"); i++; }
    } else if (c == 'p') {
      if (starts(i, "ph")) { E("F"); i += 2; } else if (starts(i, "pp")) { E("P"); i += 2; } else { E("P"); i++; }
    } else if (c == 'q') {
      E("K"); E("W"); i += (starts(i, "qu") ? 2 : 1);
    } else if (c == 'r') {
      if (starts(i, "rr")) { E("R"); i += 2; } else { E("R"); i++; }
    } else if (c == 's') {
      if (starts(i, "sh")) { E("SH"); i += 2; }
      else if (starts(i, "sion")) { E(isV(at(i - 1)) ? "ZH" : "SH"); E("AX"); E("N"); i += 4; }
      else if (starts(i, "ss")) { E("S"); i += 2; }
      else if (i == n - 1 && i > 0 && voicedBefore(at(i - 1))) { E("Z"); i++; }
      else if (i > 0 && isV(at(i - 1)) && isV(at(i + 1))) { E("Z"); i++; }
      else { E("S"); i++; }
    } else if (c == 't') {
      if (starts(i, "tion")) { E("SH"); E("AX"); E("N"); i += 4; }
      else if (starts(i, "tch")) { E("CH"); i += 3; }
      else if (starts(i, "th")) { E("TH"); i += 2; }
      else if (starts(i, "ture") && i + 4 == n) { E("CH"); E("ER"); i += 4; }
      else if (starts(i, "tt")) { E("T"); i += 2; }
      else { E("T"); i++; }
    } else if (c == 'w') {
      if (starts(i, "wr") && i == 0) { i++; }
      else if (starts(i, "wh")) { E("W"); i += 2; }
      else { E("W"); i++; }
    } else if (c == 'x') {
      if (i == 0) E("Z"); else { E("K"); E("S"); }
      i++;
    } else if (c == 'b') { E("B"); i += starts(i, "bb") ? 2 : 1; }
    else if (c == 'f') { E("F"); i += starts(i, "ff") ? 2 : 1; }
    else if (c == 'j') { E("JH"); i++; }
    else if (c == 'v') { E("V"); i++; }
    else if (c == 'z') { E("Z"); i += starts(i, "zz") ? 2 : 1; }
    else { i++; }
  }
  return out;
}

// ---------------------------------------------------------------- analiza słowa -> segmenty
// emph: >0 = okrzyk (!, WIELKIE LITERY), question: intonacja pytająca (?)
inline Word buildWord(const std::string& raw, float emph, bool question) {
  Word W; W.txt = raw;
  std::string w;
  for (char c : raw) if (std::isalpha((unsigned char)c)) w += (char)std::tolower((unsigned char)c);
  if (w.empty()) return W;
  std::vector<Unit> units; bool prefix = false, fromLex = false;
  for (const Lex& L : LEX) if (w == L.w) { units = parsePh(L.ph); fromLex = true; break; }
  if (!fromLex) units = g2pRules(w, prefix);

  // --- analiza: akcent + redukcja samogłosek niepodkreślonych
  std::vector<int> nuc;
  for (size_t k = 0; k < units.size(); k++) if (isVowelSym(units[k].s)) nuc.push_back((int)k);
  int marked = -1;
  for (int k : nuc) if (units[k].stress == 1) marked = k;
  if (marked < 0 && !nuc.empty()) {
    int pick = (prefix && nuc.size() >= 2) ? 1 : 0;
    if (!fromLex || nuc.size() == 1 || true) {
      // pierwsza nie-schwa samogłoska od wybranej pozycji
      for (size_t q = (size_t)pick; q < nuc.size(); q++) if (units[nuc[q]].s != "AX") { marked = nuc[q]; break; }
      if (marked < 0) marked = nuc[0];
    }
    units[marked].stress = 1;
  }
  for (size_t q = 0; q + 1 < nuc.size() && !fromLex; q++) {            // redukcja: niepodkreślone nie-końcowe
    Unit& u = units[nuc[q]];
    if (u.stress == 1) continue;
    if (u.s == "AE" || u.s == "AA" || u.s == "AH" || u.s == "EH" || u.s == "AO" || u.s == "UH" || u.s == "OH") {
      bool bdr = q == 0 && prefix && (w[0] == 'b' || w[0] == 'd' || w[0] == 'r');
      u.s = bdr ? "IH" : "AX";
    }
  }

  // --- rozwinięcie w segmenty
  int holdCand = -1, lastNucleus = -1;
  for (const Unit& u : units) {
    size_t before = W.segs.size();
    expandUnit(u, W.segs);
    for (size_t k = before; k < W.segs.size(); k++) if (W.segs[k].nucleus) {
      lastNucleus = (int)k;
      if (W.segs[k].stressed) holdCand = (int)k;
    }
  }
  const int N = (int)W.segs.size();
  if (!N) return W;
  auto& S = W.segs;
  // koartykulacja: zwarcia/aspiracja przejmują formanty następnej samogłoski
  for (int i = 0; i < N; i++) if (S[i].takeNext) {
    int j = i + 1; while (j < N && S[j].av < 0.5f) j++;
    int k = j < N ? j : -1;
    if (k < 0) { k = i - 1; while (k >= 0 && S[k].av < 0.5f) k--; }
    if (k >= 0) { S[i].f1 = S[k].f1; S[i].f2 = S[k].f2; S[i].f3 = S[k].f3; }
  }
  // kontur intonacji: deklinacja + garb na sylabie akcentowanej + okrzyk/pytanie
  for (int i = 0; i < N; i++) S[i].contour = -2.5f * (float)i / (float)std::max(1, N - 1);
  if (holdCand >= 0) {
    S[holdCand].contour += 2.f + emph;
    if (holdCand > 0) S[holdCand - 1].contour += 1.f;
    if (holdCand + 1 < N) S[holdCand + 1].contour += 1.f;
  }
  for (int i = 0; i < N; i++) S[i].contour += 0.6f * emph;
  if (question) {
    int a = (int)(N * 0.55f);
    for (int i = a; i < N; i++) S[i].contour += 5.f * (float)(i - a + 1) / (float)std::max(1, N - a);
  }
  W.hold = holdCand >= 0 ? holdCand : lastNucleus;
  W.gain = 1.f + 0.06f * emph;
  // spójność: ostatnia sylaba wydłużona, wyraz krótki (1 sylaba) minimalnie dłuższy
  if (lastNucleus >= 0) S[lastNucleus].dur *= 1.15f;
  // "units" do trybu literowego buduje buildScript (osobno)
  W.txt = w;
  return W;
}

// pojedynczy fonem jako osobne "słowo" (tryb literowy); zwarcia/afrykaty dostają schwa, by było je słychać
inline Word buildUnitWord(const Unit& u0) {
  Word W; Unit u = u0; u.stress = isVowelSym(u.s) ? 1 : 0;
  W.txt = u.s;
  expandUnit(u, W.segs);
  const Ph* p = findPh(u.s);
  if (p && (p->c == STP || p->c == AFF)) { Unit a; a.s = "AX"; a.stress = 1; expandUnit(a, W.segs); }
  const int N = (int)W.segs.size();
  auto& S = W.segs;
  int hold = -1;
  for (int i = 0; i < N; i++) if (S[i].nucleus) hold = i;
  for (int i = 0; i < N; i++) if (S[i].takeNext) {
    int j = i + 1; while (j < N && S[j].av < 0.5f) j++;
    if (j < N) { S[i].f1 = S[j].f1; S[i].f2 = S[j].f2; S[i].f3 = S[j].f3; }
  }
  for (int i = 0; i < N; i++) S[i].contour = 0.f;
  W.hold = hold;
  return W;
}

// ---------------------------------------------------------------- tekst -> skrypt
inline Script* buildScript(const std::string& text) {
  Script* sc = new Script();
  static const char* DIG[10] = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
  struct Tok { std::string w; char punct; bool caps; };
  std::vector<Tok> toks;
  std::string cur; bool allUpper = true; int letters = 0;
  auto flush = [&](char punct) {
    if (!cur.empty()) { toks.push_back({cur, punct, allUpper && letters >= 2}); }
    else if (punct && !toks.empty()) toks.back().punct = punct;
    cur.clear(); allUpper = true; letters = 0;
  };
  for (size_t i = 0; i < text.size(); i++) {
    unsigned char c = (unsigned char)text[i];
    if (std::isalpha(c)) { cur += (char)c; letters++; if (!std::isupper(c)) allUpper = false; }
    else if (c == '\'' ) { /* apostrof: pomijamy */ }
    else if (std::isdigit(c)) {
      flush(0); toks.push_back({DIG[c - '0'], 0, false});
    } else if (c == '!' || c == '?' || c == '.' || c == ',' || c == ';' || c == ':') flush((char)c);
    else flush(0);
  }
  flush(0);
  for (const Tok& t : toks) {
    float emph = (t.punct == '!' ? 1.5f : 0.f) + (t.caps ? 1.5f : 0.f);
    Word w = buildWord(t.w, emph, t.punct == '?');
    if (w.segs.empty()) continue;
    sc->words.push_back(w);
    // fonemy do trybu literowego
    std::string lw; for (char c : t.w) if (std::isalpha((unsigned char)c)) lw += (char)std::tolower((unsigned char)c);
    std::vector<Unit> units; bool pf = false, fl = false;
    for (const Lex& L : LEX) if (lw == L.w) { units = parsePh(L.ph); fl = true; break; }
    if (!fl) units = g2pRules(lw, pf);
    for (const Unit& u : units) { Word uw = buildUnitWord(u); if (!uw.segs.empty()) sc->units.push_back(uw); }
  }
  return sc;
}

inline const char* bankText(int b) {
  switch (b) {
    case 1: return "drop the bass. wobble! feel the sub. yeah! dubstep. hands up! bass drop. turn it up!";
    case 2: return "hey! go! let's go! yeah! come on! rewind! fire! pull up! make some noise! hands up!";
    case 3: return "ten nine eight seven six five four three two one. drop!";
    default: return "drop the bass";
  }
}

}  // namespace sp
}  // namespace ds
