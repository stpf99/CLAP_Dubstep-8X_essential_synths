"""generator.py — losowa aranżacja dubstepu (8 ścieżek) + losowy sound design + domyślne linki między ścieżkami."""
from __future__ import annotations

import random
import time

from .core import CORE8, MELODIC, SCALES, TYPES, DRUM_SRC, find_track, first_of_type, meta, new_project, new_track, track_of, unique_name

T = lambda *a: list(a)

STYLES = {
    "Brostep": dict(extras=["clap","crash","riser","boom","zap","stab","tom","fmbass"], bpm=140, kick=[[0, 10], [0, 7, 10], [0, 6, 10, 14], [0, 10, 13]], hat="16", wob="brostep", growl="brostep",
                    wob_div=[8, 9, 5, 10], growl_div=[8, 9, 10], reese="late", lead="accent", chord_len=1, swing=0.0,
                    template=[("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]),
    "Riddim": dict(extras=["clap","crash","riser","boom","hollow","rim"], bpm=140, kick=[[0], [0, 10]], hat="8", wob="riddim", growl="riddim", wob_div=[5, 9, 9, 8], growl_div=[8, 9],
                   reese="none", lead="rare", chord_len=2, swing=0.0,
                   template=[("intro", 8), ("build", 4), ("drop", 32), ("break", 8), ("build", 4), ("drop", 32), ("drop", 16), ("outro", 8)]),
    "Tearout": dict(extras=["clap","crash","riser","boom","zap","neuro","tom","fmbass","rim","stab"], bpm=150, kick=[[0, 6, 10], [0, 3, 6, 10, 13], [0, 7, 10, 14]], hat="16", wob="tearout", growl="tearout",
                    wob_div=[10, 11, 12], growl_div=[10, 11], reese="all", lead="accent", chord_len=1, swing=0.0,
                    template=[("intro", 8), ("build", 8), ("drop", 24), ("break", 8), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 8)]),
    "Melodic": dict(extras=["clap","crash","riser","boom","supersaw","pluck","pad","vox","shaker","stab"], bpm=140, kick=[[0, 10]], hat="8", wob="melodic", growl="melodic", wob_div=[3, 4, 5], growl_div=[5, 8],
                    reese="all", lead="melodic", chord_len=2, swing=0.05,
                    template=[("intro", 16), ("build", 8), ("drop", 24), ("break", 24), ("build", 8), ("drop", 32), ("drop", 16), ("outro", 16)]),
    "Deep": dict(extras=["rim","shaker","pad","pluck","boom","crash","riser"], bpm=140, kick=[[0, 10], [0, 10, 14]], hat="off", wob="deep", growl="deep", wob_div=[2, 3, 4], growl_div=[5],
                 reese="all", lead="none", chord_len=2, swing=0.08,
                 template=[("intro", 16), ("drop", 32), ("break", 8), ("drop", 32), ("outro", 16)]),
    # ---- v3: nowe style
    "Dubstep": dict(extras=["clap","crash","riser","boom","zap","stab","tom","fmbass","rim"], bpm=140, kick=[[0, 10], [0, 7, 10], [0, 10, 13]], hat="8", wob="dubstep", growl="brostep",
                    wob_div=[8, 5, 9], growl_div=[8, 9], reese="late", lead="rare", chord_len=2, swing=0.0,
                    template=[("intro", 16), ("build", 8), ("drop", 32), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]),
    "Drumstep": dict(extras=["clap","crash","riser","boom","supersaw","pluck","pad","vox","rim","stab","shaker"], bpm=174, kick=[[0, 10], [0, 6, 10, 14], [0, 10, 13]], hat="16",
                     snare=[4, 12], wob="drumstep", growl="brostep", wob_div=[9, 10, 8], growl_div=[9, 10], reese="all", lead="melodic", chord_len=2, swing=0.03,
                     template=[("intro", 16), ("build", 8), ("drop", 24), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]),
    "Trap": dict(extras=["clap","rim","crash","riser","boom","zap","pluck","pad","tom"], bpm=140, kick=[[0, 7, 10], [0, 6, 11], [0, 10, 14]], hat="trap", wob="trap", growl="deep",
                 wob_div=[5, 8], growl_div=[5], reese="none", lead="rare", chord_len=2, swing=0.0,
                 template=[("intro", 8), ("build", 4), ("drop", 16), ("break", 8), ("build", 4), ("drop", 32), ("outro", 8)]),
    "EDM": dict(extras=["clap","crash","riser","boom","supersaw","pluck","pad","stab","shaker","vox"], bpm=128, kick=[[0, 4, 8, 12]], hat="off", snare=[4, 12], fourfloor=True,
                wob="edm", growl="melodic", wob_div=[8, 9], growl_div=[5], reese="all", lead="melodic", chord_len=1, swing=0.0,
                template=[("intro", 16), ("build", 8), ("drop", 16), ("break", 16), ("build", 8), ("drop", 32), ("outro", 16)]),
}

WOB = {
    "brostep": [[(0, "r", 8)], [(0, "r", 4), (4, "o", 4)], [(0, "r", 6), (6, "t", 2)], [(0, "r", 3), (3, "r", 1), (4, "o", 4)], [(0, "r", 2), (2, "o", 2), (4, "r", 4)]],
    "riddim": [[(0, "r", 3), (4, "r", 3), (8, "r", 3)], [(0, "r", 6), (8, "r", 6)], [(0, "r", 2), (2, "r", 2), (4, "r", 4), (10, "r", 6)],
               [(0, "r", 3), (3, "o", 1), (4, "r", 3), (8, "f", 2), (10, "r", 3)]],
    "tearout": [[(0, "r", 2), (2, "o", 2), (4, "r", 2), (6, "t", 2), (8, "r", 2), (10, "f", 2), (12, "r", 4)], [(0, "r", 4), (4, "o", 4), (8, "r", 4), (12, "b", 4)]],
    "melodic": [[(0, "r", 16)], [(0, "r", 8), (8, "f", 8)], [(0, "r", 12), (12, "o", 4)]],
    "deep": [[(0, "r", 16)], [(0, "r", 12)], [(0, "r", 8), (8, "r", 6)]],
    "dubstep": [[(0, "r", 8), (8, "r", 8)], [(0, "r", 6), (6, "t", 2), (8, "r", 6), (14, "o", 2)], [(0, "r", 4), (4, "o", 4), (8, "r", 4), (12, "f", 4)],
                [(0, "r", 3), (4, "r", 3), (8, "f", 4), (12, "o", 4)]],
    "drumstep": [[(0, "r", 4), (4, "o", 2), (6, "r", 2), (8, "t", 4), (12, "f", 4)], [(0, "r", 2), (2, "r", 2), (4, "f", 4), (8, "r", 4), (12, "o", 4)]],
    "trap": [[(0, "r", 2), (6, "t", 2)], [(0, "r", 3), (10, "f", 3)], [(0, "r", 2), (4, "r", 2), (10, "o", 2)]],
    "edm": [[(0, "r", 2), (4, "r", 2), (8, "r", 2), (12, "r", 2)], [(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "r", 2)]],
}
GROWL = {
    "brostep": [[(8, "r", 2), (10, "o", 2), (12, "r", 1), (13, "t", 1), (14, "o", 2)], [(8, "r", 3), (11, "t", 1), (12, "f", 2), (14, "r", 2)],
                [(8, "o", 2), (10, "r", 2), (12, "f", 2), (14, "t", 2)]],
    "riddim": [[(12, "r", 1), (13, "o", 1), (14, "r", 2)]],
    "tearout": [[(8, "r", 1), (9, "r", 1), (10, "o", 1), (11, "r", 1), (12, "t", 1), (13, "r", 1), (14, "o", 2)],
                [(8, "r", 2), (10, "o", 1), (11, "o", 1), (12, "f", 2), (14, "r", 1), (15, "t", 1)]],
    "melodic": [[(8, "r", 4), (12, "t", 4)]],
    "deep": [],
}
LEAD_RHYTHM = [[(0, 6), (6, 2), (8, 6), (14, 2)], [(0, 4), (4, 4), (8, 4), (12, 4)], [(0, 2), (2, 2), (4, 4), (8, 8)], [(0, 3), (3, 3), (6, 2), (8, 8)]]
PROGS = [[0, 5, 2, 6], [0, 6, 5, 6], [0, 3, 6, 5], [0, 0, 5, 6], [0, 2, 5, 6], [0, 4, 5, 3]]

# --- sound design: (parametr, 'r', lo, hi) | (parametr, 'c', [wybór])   (wartości w jednostkach silnika)
SOUND = {
    "kick": [("Decay", "r", 180, 380), ("Tune", "r", -3, 3), ("Pitch Env Amt", "r", 24, 44), ("Pitch Env Decay", "r", 18, 45),
             ("Noise", "r", 0.05, 0.3), ("Noise Decay", "r", 2, 8), ("Drive", "r", 0.15, 0.6)],
    "snare": [("Tune", "r", -4, 4), ("Decay", "r", 90, 200), ("Pitch Env Amt", "r", 6, 14), ("Noise", "r", 0.6, 1.0), ("Noise Decay", "r", 120, 260),
              ("Noise Highpass", "r", 800, 2500), ("Noise Bursts", "c", [1, 1, 2, 3]), ("Drive", "r", 0.2, 0.6), ("Cutoff", "r", 8000, 16000)],
    "hat": [("Decay", "r", 25, 90), ("Noise", "r", 0.3, 0.7), ("Noise Decay", "r", 25, 70), ("Noise Highpass", "r", 5000, 9000),
            ("Cutoff", "r", 5000, 9000), ("Drive", "r", 0.0, 0.2)],
    "sub": [("Waveform", "c", [0, 0, 1]), ("Glide", "r", 20, 90), ("Drive", "r", 0.05, 0.3), ("Cutoff", "r", 500, 1400), ("Sub Osc", "r", 0.0, 0.3)],
    "wobble": [("Waveform", "c", [2, 2, 3]), ("Wave Morph", "r", 0, 0.5), ("Unison Voices", "c", [1, 2, 3]), ("Unison Detune", "r", 8, 25),
               ("Cutoff", "r", 300, 900), ("Resonance", "r", 0.3, 0.65), ("LFO Shape", "c", [0, 0, 1, 2, 3]), ("LFO > Cutoff", "r", 2.5, 4.5),
               ("Drive", "r", 0.3, 0.6), ("Sub Osc", "r", 0.2, 0.4), ("Glide", "r", 10, 50)],
    "reese": [("Unison Voices", "c", [2, 3, 4, 5]), ("Unison Detune", "r", 14, 40), ("Cutoff", "r", 1200, 3500), ("Resonance", "r", 0.1, 0.35),
              ("LFO Rate", "r", 0.1, 0.5), ("LFO > Cutoff", "r", 1.0, 2.5), ("Drive", "r", 0.35, 0.7), ("Glide", "r", 40, 120),
              ("Sub Osc", "r", 0.2, 0.4), ("LFO Shape", "c", [0, 1])],
    "growl": [("Wave Morph", "r", 0.1, 0.6), ("FM Amount", "r", 0.3, 0.7), ("FM Ratio", "c", [1, 1.5, 2, 3, 3.01, 4, 5]), ("Formant Mix", "r", 0.6, 1.0),
              ("Vowel A-E-I-O-U", "r", 0, 3), ("LFO > Vowel", "r", 1, 3), ("Cutoff", "r", 3000, 9000), ("Resonance", "r", 0.2, 0.5),
              ("LFO Shape", "c", [1, 0, 2]), ("LFO > FM", "r", 0.1, 0.5), ("Drive", "r", 0.5, 0.85), ("Glide", "r", 15, 60)],
    "screech": [("Unison Voices", "c", [3, 5, 7]), ("Unison Detune", "r", 15, 40), ("FM Amount", "r", 0.35, 0.7), ("FM Ratio", "c", [2, 3.01, 3.5, 5, 7.01]),
                ("Cutoff", "r", 5000, 12000), ("Filter Env Amt", "r", 1, 3), ("Pitch Env Amt", "r", 3, 8), ("Pitch Env Decay", "r", 40, 120),
                ("Glide", "r", 50, 140), ("LFO > Pitch", "r", 0.1, 0.4), ("LFO Rate", "r", 4.5, 6.5), ("Drive", "r", 0.3, 0.6)],
}
SOUND.update({
    "clap": [("Noise Decay", "r", 150, 300), ("Noise Highpass", "r", 600, 1400), ("Noise Lowpass", "r", 3500, 7000), ("Noise Bursts", "c", [3, 4, 5]), ("Drive", "r", 0.2, 0.5)],
    "rim": [("Waveform", "c", [0, 1]), ("Decay", "r", 25, 70), ("Pitch Env Amt", "r", 4, 12), ("Noise", "r", 0.1, 0.4), ("Noise Highpass", "r", 2000, 5000), ("Tune", "r", -4, 6)],
    "tom": [("Decay", "r", 250, 500), ("Pitch Env Amt", "r", 8, 18), ("Pitch Env Decay", "r", 40, 90), ("Drive", "r", 0.1, 0.35)],
    "crash": [("Decay", "r", 1200, 2600), ("Noise Decay", "r", 1000, 2200), ("Noise Highpass", "r", 3000, 6000), ("Cutoff", "r", 2000, 5000), ("Tone Level", "r", 0.3, 0.8)],
    "shaker": [("Noise Decay", "r", 40, 110), ("Noise Highpass", "r", 4000, 7000), ("Noise Lowpass", "r", 9000, 15000), ("Noise Bursts", "c", [1, 2, 3])],
    "fmbass": [("FM Amount", "r", 0.3, 0.7), ("FM Ratio", "c", [0.5, 1, 1, 2, 3]), ("LFO Shape", "c", [0, 1, 2]), ("LFO > FM", "r", 0.15, 0.5), ("Drive", "r", 0.35, 0.7),
               ("Cutoff", "r", 2500, 7000), ("Glide", "r", 0, 50), ("Sub Osc", "r", 0.1, 0.3)],
    "neuro": [("Unison Voices", "c", [2, 3, 4]), ("Unison Detune", "r", 10, 30), ("FM Amount", "r", 0.15, 0.5), ("FM Ratio", "c", [1, 2, 3, 3.01]), ("Formant Mix", "r", 0.4, 0.85),
              ("Vowel A-E-I-O-U", "r", 0, 3), ("Cutoff", "r", 1800, 4000), ("Resonance", "r", 0.3, 0.6), ("LFO Shape", "c", [0, 1, 2]), ("LFO > Cutoff", "r", 1.5, 3.5),
              ("LFO > Vowel", "r", 1, 3), ("Drive", "r", 0.65, 0.95)],
    "hollow": [("Pulse Width", "r", 0.15, 0.4), ("Unison Voices", "c", [1, 2, 3]), ("Unison Detune", "r", 5, 14), ("Cutoff", "r", 450, 1100), ("Resonance", "r", 0.25, 0.55),
               ("LFO Shape", "c", [0, 1, 3]), ("LFO > Cutoff", "r", 1.5, 3.0), ("Drive", "r", 0.3, 0.6), ("Sub Osc", "r", 0.2, 0.45)],
    "supersaw": [("Unison Detune", "r", 20, 50), ("Cutoff", "r", 5000, 12000), ("Attack", "r", 5, 80), ("Release", "r", 200, 800), ("Drive", "r", 0.05, 0.3), ("Filter Env Amt", "r", 0.5, 2.5)],
    "pluck": [("Waveform", "c", [2, 3]), ("Wave Morph", "r", 0, 0.6), ("Decay", "r", 120, 400), ("Cutoff", "r", 900, 2500), ("Filter Env Amt", "r", 2, 4), ("Filter Env Decay", "r", 90, 260), ("Resonance", "r", 0.15, 0.4)],
    "pad": [("Wave Morph", "r", 0.2, 0.7), ("Attack", "r", 500, 1800), ("Release", "r", 900, 3000), ("Unison Detune", "r", 12, 32), ("Cutoff", "r", 1500, 3500), ("LFO Rate", "r", 0.1, 0.35), ("Sub Osc", "r", 0.1, 0.35)],
    "stab": [("Waveform", "c", [2, 3]), ("Unison Detune", "r", 10, 28), ("FM Amount", "r", 0.05, 0.4), ("Decay", "r", 100, 250), ("Cutoff", "r", 2000, 5000), ("Filter Env Amt", "r", 1.5, 3.5), ("Drive", "r", 0.2, 0.55)],
    "riser": [("Unison Voices", "c", [3, 5, 7]), ("Unison Detune", "r", 20, 45), ("Cutoff", "r", 250, 700), ("Resonance", "r", 0.25, 0.55), ("Ramp > Cutoff", "r", 3.5, 6), ("Ramp > Pitch", "r", 12, 36),
              ("Noise", "r", 0.3, 0.7), ("Noise Highpass", "r", 400, 1500)],
    "boom": [("Decay", "r", 1800, 3500), ("Pitch Env Amt", "r", 20, 40), ("Pitch Env Decay", "r", 300, 700), ("Noise", "r", 0.1, 0.4), ("Drive", "r", 0.15, 0.45)],
    "zap": [("Waveform", "c", [2, 3]), ("Pitch Env Amt", "r", 36, 60), ("Pitch Env Decay", "r", 150, 450), ("FM Amount", "r", 0.2, 0.6), ("FM Ratio", "c", [1, 2, 3, 3.01, 5]), ("Decay", "r", 250, 600)],
    "vox": [("Vowel A-E-I-O-U", "r", 0, 3), ("Formant Mix", "r", 0.8, 1.0), ("Unison Detune", "r", 5, 18), ("Decay", "r", 120, 300), ("Cutoff", "r", 5000, 11000), ("Drive", "r", 0.1, 0.4), ("Glide", "r", 10, 70)],
})
SOUND["speak"] = [("Dialect", "c", [0, 0, 1, 2, 3]), ("Speech Speed", "r", 0.85, 1.2), ("Morph Time", "r", 22, 60), ("Formant Shift", "r", -3, 3),
                  ("Letter Pitch Range", "r", 2, 8), ("Intonation", "r", 0.3, 0.9), ("Breath", "r", 0.0, 0.25), ("Unison Voices", "c", [1, 2, 3]),
                  ("Unison Detune", "r", 4, 14), ("Drive", "r", 0.05, 0.3), ("Cutoff", "r", 6000, 12000), ("Waveform", "c", [2, 2, 3])]
SOUND.update({
    "theremin": [("LFO > Pitch", "r", 0.2, 0.6), ("LFO Rate", "r", 4.8, 6.6), ("Glide", "r", 90, 220), ("Formant Mix", "r", 0.1, 0.35),
                 ("Vowel A-E-I-O-U", "r", 2.5, 4), ("Cutoff", "r", 3500, 6000), ("Wave Morph", "r", 0.05, 0.3)],
    "panflute": [("Noise", "r", 0.15, 0.32), ("Wave Morph", "r", 0.15, 0.5), ("Attack", "r", 40, 110), ("LFO > Pitch", "r", 0.05, 0.2), ("Cutoff", "r", 5000, 8000)],
    "handpan": [("Ring Time", "r", 1200, 2600), ("Strike Brightness", "r", 0.4, 0.75), ("Pitch Env Amt", "r", 0, 3), ("Noise", "r", 0.03, 0.1)],
    "tongue": [("Ring Time", "r", 600, 1300), ("Strike Brightness", "r", 0.35, 0.7), ("Noise", "r", 0.08, 0.18)],
})
SOUND_STYLE = {
    "EDM": {"kick": [("Decay", "r", 200, 320), ("Noise", "r", 0.05, 0.15)], "hat": [("Decay", "r", 40, 90)], "sub": [("Glide", "r", 0, 20)]},
    "Trap": {"sub": [("Glide", "r", 60, 160), ("Sub Osc", "r", 0.0, 0.1), ("Drive", "r", 0.1, 0.3)], "hat": [("Decay", "r", 18, 45)], "kick": [("Decay", "r", 120, 220)]},
    "Drumstep": {"kick": [("Decay", "r", 120, 220)], "hat": [("Decay", "r", 20, 55)]},
    "Tearout": {"hat": [("Decay", "r", 20, 50)], "kick": [("Decay", "r", 140, 260)], "growl": [("Drive", "r", 0.7, 0.95)]},
    "Riddim": {"sub": [("Glide", "r", 0, 20)], "wobble": [("Glide", "r", 0, 12), ("Drive", "r", 0.45, 0.75)]},
    "Deep": {"sub": [("Sub Osc", "r", 0.0, 0.1)], "hat": [("Noise", "r", 0.15, 0.4)], "reese": [("Cutoff", "r", 800, 2000)]},
    "Melodic": {"screech": [("Cutoff", "r", 4000, 9000), ("Drive", "r", 0.15, 0.4)], "wobble": [("Drive", "r", 0.15, 0.4)]},
}

# --- style expansion: new styles, hybrids (StyleDict), WOB/GROWL/SOUND_STYLE/themes from styles.py
from . import styles as _S
WOB.update(_S.WOB_NEW)
GROWL.update(_S.GROWL_NEW)
SOUND_STYLE.update(_S.SOUND_STYLE_NEW)
STYLES = _S.StyleDict({**STYLES, **_S.NEW_STYLES})


def randomize_sound(proj, tr, rng):
    m = meta(); style = proj["style"]; tt = tr["type"]
    spec = {p[0]: p for p in SOUND.get(tt, [])}
    pure = style
    if hasattr(STYLES, "parts"):
        parts = STYLES.parts(style)
        pure = max(parts, key=parts.get) if parts else style
    for p in SOUND_STYLE.get(style, SOUND_STYLE.get(pure, {})).get(tt, []):
        spec[p[0]] = p
    for name, sp in spec.items():
        if not m.has(tt, name):
            continue
        e = rng.uniform(sp[2], sp[3]) if sp[1] == "r" else rng.choice(sp[2])
        tr["params"][name] = m.eng2frac(tt, name, e)
    if tt in ("wobble", "growl", "neuro", "fmbass", "hollow"):
        cfg = STYLES[style]
        div = (cfg["growl_div"] if tt in ("growl", "neuro") else cfg["wob_div"])[0]
        tr["params"]["LFO Division"] = m.eng2frac(tt, "LFO Division", div)


DUCK = {"sub": 1.0, "wobble": 0.9, "reese": 0.9, "growl": 0.7, "screech": 0.5, "fmbass": 0.8, "neuro": 0.7, "hollow": 0.9,
        "supersaw": 0.45, "pad": 0.5, "pluck": 0.35, "stab": 0.35, "vox": 0.3, "speak": 0.3, "theremin": 0.3, "panflute": 0.3, "handpan": 0.2, "tongue": 0.2}


def duck_link(tr, style, rel=0.5):
    base = {"Deep": 0.35, "Melodic": 0.45, "EDM": 0.75, "Drumstep": 0.5, "Trap": 0.4}.get(style, 0.55)
    return {"src": "kick", "dst": tr["name"], "param": "Level", "amount": -round(base * DUCK[tr["type"]], 3),
            "rel": 0.4 if tr["type"] in ("screech", "pluck", "stab", "vox") else rel}


def default_links(style, tracks):
    """Linki domyślne dla istniejących ścieżek (tracks = lista słowników)."""
    m = meta(); links = []
    L = lambda s, d, p, a, r=0.5: {"src": s, "dst": d, "param": p, "amount": a, "rel": r}
    has = lambda n, p: m.has(n["type"], p)
    for tr in tracks:
        if tr["type"] in DUCK and any(t["type"] == "kick" for t in tracks):
            links.append(duck_link(tr, style))
    rules = [("energy", "reese", "Cutoff", 0.20), ("energy", "growl", "Drive", 0.15), ("energy", "neuro", "Cutoff", 0.15), ("energy", "hat", "Level", 0.12),
             ("build", "screech", "Cutoff", 0.35), ("build", "snare", "Drive", 0.25), ("build", "supersaw", "Cutoff", 0.3), ("build", "speak", "Cutoff", 0.3),
             ("snare", "screech", "FM Amount", 0.15, 0.3), ("bass_note", "growl", "Vowel A-E-I-O-U", 0.30), ("bass_note", "vox", "Vowel A-E-I-O-U", 0.35),
             ("bar_phase", "reese", "Cutoff", 0.08), ("bar_phase", "pad", "Cutoff", 0.15), ("kick", "hollow", "Cutoff", 0.12, 0.3)]
    if style == "Tearout":
        rules.append(("snare", "growl", "Drive", 0.10, 0.3))
    for r in rules:
        for tr in tracks:
            if tr["type"] == r[1] and has(tr, r[2]) and (r[0] not in DRUM_SRC or any(t["type"] == r[0] for t in tracks)):
                links.append(L(r[0], tr["name"], r[2], r[3], r[4] if len(r) > 4 else 0.5))
    return links


# ------------------------------------------------------------------ pomocnicze
def fit_template(template, bars, rng):
    tot = sum(b for _, b in template)
    out = [[n, max(4, round(b * bars / tot / 4) * 4)] for n, b in template]
    diff = bars - sum(b for _, b in out)
    big = [i for i, (n, _) in enumerate(out) if n == "drop"] or [0]
    k = 0
    while diff:
        step = 4 if diff > 0 else -4
        i = big[k % len(big)]
        if out[i][1] + step >= 4:
            out[i][1] += step; diff -= step
        k += 1
        if k > 200:
            break
    return out


def reg(pc, lo):
    return lo + ((pc - lo) % 12)


class Ctx:
    def __init__(self, proj, cfg):
        self.p, self.cfg = proj, cfg
        self.B = []
        for s in proj["sections"]:
            for i in range(s["bars"]):
                self.B.append({"sec": s, "i": i, "L": s["bars"], "type": s["type"], "k": s["k"], "e": s["e0"] + (s["e1"] - s["e0"]) * i / s["bars"],
                               "root": proj["chords"][s["start"] + i][0], "third": proj["chords"][s["start"] + i][1]})

    def rng(self, tname, salt=0):
        return random.Random(f"{self.p['seed']}-{tname}-{salt}")


def tok(b):
    th = b["third"]
    return {"r": 0, "o": 12, "f": 7, "t": th, "b": 10, "p": th + 12, "u": 14}


class Writer:
    def __init__(self, proj, tr):
        self.t = tr; self.name = tr["type"]; self.sw = proj["swing"]; self.t["notes"] = []

    def add(self, bar, step, key, ln, vel, drum=False):
        beat = bar * 4 + step * 0.25
        if step % 2 == 1 and self.name not in ("sub", "reese", "pad", "supersaw", "riser", "boom", "crash"):
            beat += self.sw * 0.1
        dur = 0.1 if drum else max(0.05, ln * 0.25 - 0.03)
        self.t["notes"].append([round(beat, 4), round(dur, 4), int(key), max(1, min(127, int(vel)))])


# ------------------------------------------------------------------ generatory ścieżek
def gen_kick(c, tr):
    w, r, cfg = Writer(c.p, tr), c.rng(tr["name"]), c.cfg
    pools, pick = cfg["kick"], {}
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            pat = pick.setdefault(B["sec"]["name"], r.choice(pools))
            steps = list(pat)
            if cfg.get("fourfloor"):
                pass
            else:
                if i % 4 == 3 and r.random() < c.p["density"] * 0.7:
                    steps.append(r.choice([13, 14, 15]))
                if i % 8 == 7:
                    steps = [0, 6, 10, 12]
        elif (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            steps = pools[0][:2]
        elif t == "build" and i >= L // 2:
            steps = [0]
        else:
            continue
        for s in sorted(set(steps)):
            w.add(b, s, 36, 0, (118 if s == 0 else 104) + r.randint(-5, 5), drum=True)


def gen_snare(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            snares = c.cfg.get("snare", [8])
            if snares is None:
                snares = [8]
            for s_ in snares:
                w.add(b, s_, 38, 0, 118 + r.randint(-4, 4), drum=True)
            for s_, vel in c.cfg.get("ghost", []) or []:
                w.add(b, s_, 38, 0, int(vel) + r.randint(-4, 4), drum=True)
            if c.cfg["wob"] == "tearout" and i % 8 == 7:
                for s in (12, 13, 14, 15):
                    w.add(b, s, 38, 0, 80 + s * 2, drum=True)
            elif i % 8 == 7 and r.random() < c.p["density"]:
                w.add(b, 14, 38, 0, 92, drum=True)
        elif t == "build":
            p = (i + 0.5) / L
            steps = [0, 8] if p < 0.25 else [0, 4, 8, 12] if p < 0.5 else list(range(0, 16, 2)) if p < 0.75 else list(range(16))
            if i == L - 1:
                steps = [s for s in steps if s < 12]
            for s in steps:
                w.add(b, s, 38, 0, min(127, 55 + int(65 * (i + s / 16) / L)) + r.randint(-3, 3), drum=True)


def gen_hat(c, tr):
    w, r, mode = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["hat"]
    d = c.p["density"]
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop":
            if mode == "16":
                for s in range(16):
                    if s % 2 == 1 and r.random() > 0.55 + 0.45 * d:
                        continue
                    w.add(b, s, 42, 0, (95 if s % 4 == 2 else 70 if s % 2 == 0 else 52) + r.randint(-5, 5), drum=True)
            elif mode == "8":
                for s in range(0, 16, 2):
                    w.add(b, s, 42, 0, (95 if s % 4 == 2 else 68) + r.randint(-4, 4), drum=True)
            elif mode == "trap":                         # 8-ki + rolle 1/32 pod koniec taktu
                for s in range(0, 16, 2):
                    w.add(b, s, 42, 0, (92 if s % 4 == 2 else 66) + r.randint(-4, 4), drum=True)
                if r.random() < 0.25 + 0.6 * d:
                    s0 = r.choice([10, 12, 14])
                    for q in range(4 if s0 < 14 else 3):
                        w.add(b, s0 + 0.5 * (q + 1), 42, 0, 60 + q * 12 + r.randint(-3, 3), drum=True)
            elif mode in ("none", "off"):
                pass
            elif mode == "ride":
                for s in range(0, 16, 2):
                    w.add(b, s, 42, 0, (88 if s % 4 == 0 else 62) + r.randint(-4, 4), drum=True)
            else:  # offbeat / default
                for s in (2, 6, 10, 14):
                    w.add(b, s, 42, 0, 78 + r.randint(-4, 4), drum=True)
        elif t in ("intro", "outro"):
            if mode in ("none", "off"):
                continue
            fade = 1.0 if t == "intro" else 1 - i / L
            for s in range(0, 16, 2):
                w.add(b, s, 42, 0, int((78 if s % 4 == 2 else 58) * fade) + 10, drum=True)
        elif t == "build" and i >= 2:
            for s in range(0, 16, 2):
                w.add(b, s, 42, 0, 55 + int(40 * i / L), drum=True)
        elif t == "break" and mode == "off":
            for s in (2, 10):
                w.add(b, s, 42, 0, 50, drum=True)


def _phrase_pick(c, tname, library, b, phrase=4):
    r = c.rng(tname, b // phrase)
    return r.choice(library) if library else []


def gen_wobble(c, tr):
    w = Writer(c.p, tr); style = c.cfg["wob"]; r = c.rng(tr["name"]); lib = WOB[style]
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        pat = _phrase_pick(c, tr["name"], lib, b, 4 if style != "riddim" else 2)
        if style == "brostep" and B["k"] > 1 and B["i"] % 2:
            pat = _phrase_pick(c, tr["name"], lib, b + 100, 4)
        for s, tkn, ln in pat:
            w.add(b, s, base + k[tkn], ln, 108 + r.randint(-4, 4))
    # zmiany podziału LFO (stepped) per sekcja drop
    ro, auto = c.rng(tr["name"] + "div"), tr["auto"]
    m = meta(); pts = []
    for s in c.p["sections"]:
        if s["type"] != "drop":
            continue
        for off in range(0, s["bars"], 8):
            if off == 0 or ro.random() < 0.5:
                pts.append([(s["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["wob_div"]))])
    auto["LFO Division"] = pts


def gen_sub(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    riddim = c.cfg["wob"] == "riddim"
    if c.cfg["wob"] == "trap":                       # 808: długie nuty na uderzeniach stopy (glide robi zjazdy)
        kk = first_of_type(c.p, "kick"); hits = sorted(n[0] for n in (kk["notes"] if kk else []))
        for j, on in enumerate(hits):
            B = c.B[min(len(c.B) - 1, int(on // 4))]
            if B["type"] != "drop":
                continue
            nxt = hits[j + 1] if j + 1 < len(hits) else on + 2
            ln = max(1, min(12, int(round((nxt - on) * 4)) - 0))
            base = reg(B["root"], 24) + (12 if r.random() < 0.15 else 0)
            w.t["notes"].append([round(on, 4), round(max(0.2, ln * 0.25 - 0.03), 4), base, 112 + r.randint(-4, 4)])
        return
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        base = reg(B["root"], 24)
        if t == "drop":
            if riddim:
                continue
            ln = 16 if not (i % 8 == 7 and r.random() < c.p["density"]) else 14
            w.add(b, 0, base, ln, 110 + r.randint(-4, 4))
        elif (t == "intro" and i >= L // 2) or t == "break" or (t == "outro" and i < L * 3 // 4):
            w.add(b, 0, base, 16, 96)
    if riddim:  # sub powiela rytm wobble o oktawę niżej
        wb = first_of_type(c.p, "wobble")
        for on, dur, key, vel in (wb["notes"] if wb else []):
            w.t["notes"].append([on, dur, key - 12, vel])


def gen_reese(c, tr):
    w, r, mode = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["reese"]
    for b, B in enumerate(c.B):
        t, i, L, k = B["type"], B["i"], B["L"], B["k"]
        base = reg(B["root"], 24) + 24
        if t == "drop" and mode != "none" and (mode == "all" or k >= 2 and i >= L // 2 or k >= 3):
            w.add(b, 0, base, 16, 100 + r.randint(-4, 4))
        elif t in ("intro", "break") and mode != "none" and b % 2 == 0:
            w.add(b, 0, base, 32, 70)
        elif t == "outro" and i < L * 3 // 4 and b % 2 == 0 and mode != "none":
            w.add(b, 0, base, 32, max(30, 70 - i * 4))


def gen_growl(c, tr):
    w, r, style = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["growl"]
    lib = GROWL[style]
    if not lib:
        return
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        if style == "brostep" and B["k"] == 1 and B["i"] < 8:
            continue
        if style == "riddim" and B["i"] % 4 != 3:
            continue
        if style == "melodic" and B["i"] % 2 == 0:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        pat = _phrase_pick(c, tr["name"], lib, b, 2)
        for s, tkn, ln in pat:
            w.add(b, s, base + k[tkn], ln, 104 + r.randint(-5, 5))
    ro, auto, m, pts = c.rng(tr["name"] + "div"), tr["auto"], meta(), []
    for s in c.p["sections"]:
        if s["type"] == "drop":
            for off in range(0, s["bars"], 8):
                pts.append([(s["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["growl_div"]))])
    auto["LFO Division"] = pts


def gen_screech(c, tr):
    w, r, mode = Writer(c.p, tr), c.rng(tr["name"]), c.cfg["lead"]
    walk = 2
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        th = B["third"]; base = reg(B["root"], 72)
        if t == "build":
            w.add(b, 0, 53 + int(24 * (i + 0.5) / L), 16, 70 + int(50 * i / L))
        elif t == "break" and mode != "none" and i >= 4:
            tones = [0, th, 7, 12, th + 12, 14]
            for s, ln in r.choice(LEAD_RHYTHM):
                walk = max(0, min(len(tones) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
                w.add(b, s, base + tones[walk], ln, 100 + r.randint(-5, 5))
        elif t == "drop":
            if mode == "melodic" and i >= 4:
                tones = [0, th, 7, 12, th + 12]
                for s, ln in r.choice(LEAD_RHYTHM):
                    walk = max(0, min(len(tones) - 1, walk + r.choice([-1, 0, 1, 2])))
                    w.add(b, s, base + tones[walk], ln, 96 + r.randint(-4, 4))
            elif mode == "accent" and (i % 4 == 3 or (B["k"] >= 3)):
                w.add(b, 8, base, 8, 98)
                if B["k"] >= 3:
                    w.add(b, 0, base + 12, 2, 92); w.add(b, 2, base + 7, 2, 92); w.add(b, 4, base, 4, 92)
            elif mode == "rare" and i % 8 == 7:
                w.add(b, 8, base, 8, 98)



# ------------------------------------------------------------------ nowe instrumenty (v2)
def gen_clap(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        if B["type"] == "drop":
            for s_ in c.cfg.get("snare", [8]):
                w.add(b, s_, 39, 0, 96 + r.randint(-5, 5), drum=True)
            if B["i"] % 8 == 7 and r.random() < c.p["density"]:
                w.add(b, 14, 39, 0, 80, drum=True)


def gen_rim(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); pick = {}
    pool = [[3, 11], [6, 14], [3, 7, 11], [2, 10], [5, 13]]
    for b, B in enumerate(c.B):
        if B["type"] in ("drop", "intro", "outro") and not (B["type"] != "drop" and B["i"] < B["L"] // 2):
            pat = pick.setdefault(B["sec"]["name"], r.choice(pool))
            for s_ in pat:
                if r.random() < 0.55 + 0.45 * c.p["density"]:
                    w.add(b, s_, 37, 0, 62 + r.randint(-8, 10), drum=True)


def gen_tom(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop" and i % 8 == 7:
            for s_, k in zip((12, 13, 14, 15), (47, 45, 43, 41)):
                w.add(b, s_, k, 0, 95 + r.randint(-4, 4), drum=True)
        elif t == "build" and i == L - 1:
            for s_, k in zip((4, 6, 8, 10, 12, 14), (50, 48, 47, 45, 43, 41)):
                w.add(b, s_, k, 0, 80 + s_ * 2, drum=True)


def gen_crash(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        if (t == "drop" and (i == 0 or i % 16 == 0)) or (t in ("break", "outro") and i == 0):
            w.add(b, 0, 49, 0, 108 if t == "drop" else 85, drum=True)


def gen_shaker(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "drop" or (t == "intro" and i >= L // 2) or (t == "outro" and i < L // 2):
            for s_ in range(16):
                if s_ % 2 == 1 or (s_ % 4 == 0 and t == "drop"):
                    w.add(b, s_, 70, 0, (58 if s_ % 4 == 3 else 42) + r.randint(-5, 5), drum=True)


def gen_fmbass(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [[(0, "r", 2), (3, "r", 1), (6, "f", 2), (10, "r", 2), (13, "t", 1)], [(0, "r", 3), (4, "o", 2), (8, "r", 2), (12, "f", 2)],
           [(2, "r", 2), (6, "r", 2), (9, "b", 2), (12, "r", 4)]]
    for b, B in enumerate(c.B):
        if B["type"] != "drop" or B["k"] < 2 and B["i"] < 16:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 4):
            w.add(b, s_, base + k[tkn], ln, 100 + r.randint(-4, 4))
    ro, m, pts = c.rng(tr["name"] + "div"), meta(), []
    for s_ in c.p["sections"]:
        if s_["type"] == "drop":
            pts.append([s_["start"] * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["wob_div"]))])
    tr["auto"]["LFO Division"] = pts


def gen_neuro(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [[(0, "r", 4), (4, "o", 2), (6, "r", 2), (8, "t", 4), (12, "f", 4)], [(0, "r", 2), (2, "r", 2), (4, "f", 4), (8, "r", 4), (12, "b", 4)],
           [(0, "r", 6), (6, "t", 2), (8, "r", 2), (10, "o", 2), (12, "f", 4)]]
    for b, B in enumerate(c.B):
        if B["type"] != "drop" or B["i"] % 8 < 4:
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 4):
            w.add(b, s_, base + k[tkn], ln, 106 + r.randint(-4, 4))
    ro, m, pts = c.rng(tr["name"] + "div"), meta(), []
    for s_ in c.p["sections"]:
        if s_["type"] == "drop":
            for off in range(0, s_["bars"], 8):
                pts.append([(s_["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice(c.cfg["growl_div"] + [9, 10]))])
    tr["auto"]["LFO Division"] = pts


def gen_hollow(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); lib = WOB["riddim"]
    for b, B in enumerate(c.B):
        if B["type"] != "drop" or (c.cfg["wob"] != "deep" and B["i"] % 2 == 0 and c.cfg["wob"] != "riddim"):
            continue
        k = tok(B); base = reg(B["root"], 24) + 12
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 2):
            w.add(b, s_, base + k[tkn], ln, 104 + r.randint(-4, 4))
    ro, m, pts = c.rng(tr["name"] + "div"), meta(), []
    for s_ in c.p["sections"]:
        if s_["type"] == "drop":
            for off in range(0, s_["bars"], 8):
                pts.append([(s_["start"] + off) * 4, m.eng2frac(tr["type"], "LFO Division", ro.choice([5, 8, 9]))])
    tr["auto"]["LFO Division"] = pts


def gen_supersaw(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        if t == "break" or (t == "drop" and c.cfg["lead"] == "melodic") or (t == "intro" and i >= B["L"] - 4):
            tone = r.choice([B["third"], 7, 12 + B["third"]])
            if b % 2 == 0:
                w.add(b, 0, reg(B["root"], 60) + tone, 32, 88 + r.randint(-4, 4))


def gen_pluck(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        if t == "break" or (t == "drop" and c.cfg["lead"] == "melodic" and i % 2 == 1) or (t == "intro" and i >= B["L"] // 2):
            k = tok(B); seq = [0, B["third"], 7, 12, 7, B["third"]]; base = reg(B["root"], 60)
            for n_, s_ in enumerate(range(0, 16, 2)):
                if r.random() < 0.4 + 0.6 * c.p["density"]:
                    w.add(b, s_, base + seq[n_ % len(seq)], 1, 82 + (8 if s_ % 4 == 0 else 0) + r.randint(-4, 4))


def gen_pad(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t in ("intro", "break", "outro") and b % 2 == 0:
            w.add(b, 0, reg(B["root"], 48) + (7 if (b // 2) % 2 else 0), 32, 80 if t != "outro" else max(30, 80 - i * 4))


def gen_stab(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    lib = [[(3, "t", 1), (7, "f", 1)], [(6, "t", 1), (10, "f", 1), (14, "t", 1)], [(2, "f", 1), (10, "t", 1)]]
    for b, B in enumerate(c.B):
        if B["type"] != "drop":
            continue
        if c.cfg["lead"] == "melodic" and B["i"] % 2 == 0 or c.cfg["lead"] != "melodic" and B["i"] % 4 < 2:
            continue
        k = tok(B); base = reg(B["root"], 60)
        for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 4):
            w.add(b, s_, base + k[tkn], ln, 96 + r.randint(-4, 4))


def gen_riser(c, tr):
    w, m = Writer(c.p, tr), meta(); pts = []
    for s_ in c.p["sections"]:
        if s_["type"] == "build":
            B = c.B[s_["start"]]
            w.add(s_["start"], 0, reg(B["root"], 48), s_["bars"] * 16, 100)
            ms = s_["bars"] * 4 * 60000.0 / c.p["bpm"]
            pts.append([s_["start"] * 4, m.eng2frac(tr["type"], "Ramp Time", min(ms, 16000))])
    tr["auto"]["Ramp Time"] = pts


def gen_boom(c, tr):
    w = Writer(c.p, tr)
    for b, B in enumerate(c.B):
        if B["type"] in ("drop", "break") and B["i"] == 0:
            w.add(b, 0, 36, 0, 112 if B["type"] == "drop" else 80, drum=True)


def gen_zap(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t == "build" and i == L - 1:
            w.add(b, 12, 55, 0, 100, drum=True)
        elif t == "drop" and i % 8 == 7 and r.random() < 0.7:
            w.add(b, 14, 60, 0, 90, drum=True)


def gen_vox(c, tr):
    w, r, m = Writer(c.p, tr), c.rng(tr["name"]), meta(); pts = []
    lib = [[(2, "t", 2), (6, "f", 2), (10, "o", 2)], [(0, "r", 3), (6, "t", 2), (10, "f", 3)], [(4, "o", 2), (8, "t", 2), (12, "r", 3)]]
    for b, B in enumerate(c.B):
        t, i = B["type"], B["i"]
        if (t == "drop" and c.cfg["lead"] in ("melodic", "accent") and i % 4 >= 2) or (t == "break" and i >= 4):
            k = tok(B); base = reg(B["root"], 60)
            for s_, tkn, ln in _phrase_pick(c, tr["name"], lib, b, 2):
                w.add(b, s_, base + k[tkn], ln, 94 + r.randint(-4, 4))
            pts.append([b * 4, m.eng2frac(tr["type"], "Vowel A-E-I-O-U", r.choice([0, 0.5, 1, 2, 3]))])
    tr["auto"]["Vowel A-E-I-O-U"] = pts


# ------------------------------------------------------------------ DS Speak (mowa) — opcjonalny instrument
SPEAK_THEMES = {
    "Dubstep": ["drop the bass", "wobble", "feel the sub", "dubstep", "bass drop", "sub bass", "heavy bass", "wub wub", "low end",
                "sound system", "shake the ground", "turn the bass up", "bass line"],
    "Hype": ["hands up", "let's go", "come on", "yeah", "hey", "make some noise", "pull up", "rewind", "fire", "jump",
             "everybody scream", "turn it up", "one more time", "go go go"],
    "Dark": ["no escape", "feel the fear", "run", "dark night", "scream", "break the system", "kill the lights", "wake up", "down we go"],
    "Countdown": ["ten nine eight seven six five four three two one drop"],
}
STYLE_THEME = {"Brostep": "Dubstep", "Riddim": "Dubstep", "Tearout": "Hype", "Melodic": "Hype", "Deep": "Dark",
               "Dubstep": "Dubstep", "Drumstep": "Hype", "Trap": "Dark", "EDM": "Hype"}
STYLE_THEME.update(_S.STYLE_THEME_NEW)


def auto_text(theme, style, n, rng):
    """Układa tekst na n słów (n = liczba nut mowy; każda nuta czyta kolejne słowo). Zdania z motywu, losowe ! i ?."""
    th = theme if theme in SPEAK_THEMES else STYLE_THEME.get(style, "Dubstep")
    pool, words = SPEAK_THEMES[th], []
    while len(words) < max(1, n):
        ph = rng.choice(pool).split()
        r = rng.random()
        end = "!" if r < 0.45 else ("?" if r < 0.52 else ".")
        words += ph[:-1] + [ph[-1] + end]
    return " ".join(words[:max(1, n)])


def gen_speak(c, tr):
    """Wokal-chopy: pickupy w buildach, okrzyk na początku dropa, melodyczne frazy w breakach (trzymane samogłoski)."""
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        th = B["third"]; base = reg(B["root"], 46)
        tones = [0, th, 7, 12]
        if t == "build" and i >= L // 2:
            steps = [0, 4, 8, 12] if i == L - 1 else [0, 8]
            for s_ in steps:
                w.add(b, s_, base + r.choice(tones), 3, 80 + int(40 * (i + s_ / 16) / L) + r.randint(-3, 3))
        elif t == "drop":
            if i % 8 == 0:
                w.add(b, 0, base + 12, 6, 108 + r.randint(-3, 3))
            elif i % 8 == 7 and r.random() < c.p["density"]:
                w.add(b, 12, base, 3, 96)
        elif t == "break" and i >= 2:
            for s_ in (0, 8) if i % 2 == 0 else (0, 6, 10):
                w.add(b, s_, base + r.choice(tones), 5, 90 + r.randint(-4, 4))
        elif t == "intro" and i >= L - 4 and i % 2 == 0:
            w.add(b, 8, base + r.choice(tones), 4, 80 + r.randint(-3, 3))
        elif t == "outro" and i < 2:
            w.add(b, 8, base, 4, 70)
    if tr.get("text_mode", "auto") == "auto":     # auto: tekst na tyle słów, ile nut; manual: zostaje wpisany (czytany cyklicznie)
        tr["text"] = auto_text(tr.get("text_theme"), c.p["style"], len(tr["notes"]), c.rng(tr["name"], 99))


# ------------------------------------------------------------------ instrumenty akustyczne (opcjonalne, nie w paletach domyślnych)
def _penta(root, lo):
    """Pentatonika moll od toniki `root` w rejestrze od `lo` (3 oktawy)."""
    base = reg(root, lo)
    return [base + 12 * o + d for o in range(3) for d in (0, 3, 5, 7, 10)]


def gen_theremin(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); walk = 2
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        th = B["third"]; base = reg(B["root"], 60); tones = [0, th, 7, 12, th + 12, 14]
        if t == "break" or (t == "intro" and i >= L - 4) or (t == "outro" and i < 2) or (t == "build" and i >= L // 2):
            for s_, ln in ((0, 8), (8, 8)) if r.random() < 0.7 else ((0, 16),):
                walk = max(0, min(len(tones) - 1, walk + r.choice([-2, -1, 1, 2])))
                w.add(b, s_, base + tones[walk], ln, 88 + r.randint(-5, 5))


def gen_panflute(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"]); walk = 4
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t in ("break", "intro", "outro") and b % 2 == 0 or (t == "drop" and c.cfg["lead"] == "melodic" and i % 4 == 2):
            pool = _penta(B["root"], 64)
            for s_, ln in r.choice([[(0, 6), (6, 4), (10, 6)], [(0, 4), (4, 4), (8, 8)], [(2, 5), (8, 3), (12, 4)]]):
                walk = max(0, min(len(pool) - 1, walk + r.choice([-2, -1, 0, 1, 2])))
                w.add(b, s_, pool[walk], ln, 84 + r.randint(-5, 5))


def gen_handpan(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t, i, L = B["type"], B["i"], B["L"]
        if t in ("break", "intro", "outro") or (t == "drop" and c.cfg["lead"] in ("melodic",) and i % 2 == 1):
            th = B["third"]; base = reg(B["root"], 52)
            arp = r.choice([[0, th, 7, 12, 7, th, 0, th], [0, 7, 12, th + 12, 12, 7, th, 7], [0, 0, th, 7, 12, 7, th, 0]])
            for n_, s_ in enumerate(range(0, 16, 2)):
                if r.random() < 0.55 + 0.45 * c.p["density"]:
                    w.add(b, s_, base + arp[n_ % len(arp)], 1, (96 if s_ % 8 == 0 else 74) + r.randint(-6, 6), drum=True)


def gen_tongue(c, tr):
    w, r = Writer(c.p, tr), c.rng(tr["name"])
    for b, B in enumerate(c.B):
        t = B["type"]
        if t in ("break", "intro", "outro") and (b % 2 == 1 or t == "break"):
            pool = _penta(B["root"], 60)
            for s_ in sorted(r.sample([0, 3, 6, 8, 10, 12, 14], r.choice([3, 4, 5]))):
                w.add(b, s_, r.choice(pool), 1, 78 + r.randint(-8, 10), drum=True)


GEN = {"kick": gen_kick, "snare": gen_snare, "hat": gen_hat, "wobble": gen_wobble, "sub": gen_sub, "reese": gen_reese,
       "growl": gen_growl, "screech": gen_screech, "clap": gen_clap, "rim": gen_rim, "tom": gen_tom, "crash": gen_crash,
       "shaker": gen_shaker, "fmbass": gen_fmbass, "neuro": gen_neuro, "hollow": gen_hollow, "supersaw": gen_supersaw,
       "pluck": gen_pluck, "pad": gen_pad, "stab": gen_stab, "riser": gen_riser, "boom": gen_boom, "zap": gen_zap, "vox": gen_vox,
       "speak": gen_speak, "theremin": gen_theremin, "panflute": gen_panflute, "handpan": gen_handpan, "tongue": gen_tongue}
# kolejność generowania (wobble przed sub: riddim powiela rytm)
ORDER = ["kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "wobble", "sub", "reese", "growl", "neuro", "fmbass", "hollow",
         "screech", "supersaw", "pluck", "pad", "stab", "vox", "riser", "boom", "zap", "speak", "theremin", "panflute", "handpan", "tongue"]


def default_instruments(style):
    cfg = STYLES[style]
    if "core" in cfg:
        core = list(cfg["core"])
        return core + [t for t in cfg.get("extras", []) if t not in core]
    return CORE8 + cfg.get("extras", [])


def _order_tracks(tracks):
    return sorted(tracks, key=lambda t: (TYPES.index(t["type"]), t["name"]))


def generate(style="Brostep", bpm=None, key=None, scale="minor", bars=144, energy=0.7, swing=None, density=0.6, seed=None,
             name=None, instruments=None, speak_text=None, speak_theme=None):
    cfg = STYLES[style]
    seed = int(seed if seed is not None else time.time() * 1000) % 1000000
    rng = random.Random(seed)
    key = rng.randrange(12) if key is None else key
    swing = cfg["swing"] if swing is None else swing
    proj = new_project(name=name or f"{style}-{seed}", bpm=bpm or cfg["bpm"], style=style, key=key, scale=scale, seed=seed,
                       swing=swing, energy=energy, density=density)
    es = 0.6 + 0.4 * energy
    start, ord_ = 0, {}
    for sname, n in fit_template(cfg["template"], bars, rng):
        ord_[sname] = ord_.get(sname, 0) + 1
        e0, e1 = {"intro": (0.3, 0.4), "build": (0.5, 0.95), "drop": (1.0, 1.0), "break": (0.35, 0.35), "outro": (0.3, 0.1)}[sname]
        proj["sections"].append({"name": f"{sname}{ord_[sname]}", "type": sname, "k": ord_[sname], "start": start, "bars": n,
                                 "e0": round(e0 * es, 3), "e1": round(e1 * es, 3)})
        start += n
    proj["bars"] = start
    sc = SCALES[scale]; prog = rng.choice(cfg.get("progs") or PROGS)
    for b in range(proj["bars"]):
        d = prog[(b // cfg["chord_len"]) % len(prog)]
        proj["chords"].append([(key + sc[d]) % 12, (sc[(d + 2) % 7] - sc[d]) % 12])
    for t in (instruments or default_instruments(style)):
        proj["tracks"].append(new_track(unique_name(proj, t), t))
    for tr in proj["tracks"]:                    # DS Speak: tekst ręczny (jeśli podany) albo auto z motywu
        if tr["type"] == "speak":
            manual = bool(speak_text and speak_text.strip())
            tr["text_mode"] = "manual" if manual else "auto"
            tr["text"] = speak_text.strip() if manual else ""
            tr["text_theme"] = speak_theme
    proj["tracks"] = _order_tracks(proj["tracks"])
    c = Ctx(proj, cfg)
    for tr in sorted(proj["tracks"], key=lambda t: ORDER.index(t["type"])):
        randomize_sound(proj, tr, random.Random(f"{seed}-snd-{tr['name']}"))
        GEN[tr["type"]](c, tr)
    proj["links"] = default_links(style, proj["tracks"])
    return proj


def reroll_track(proj, tname, new_seed=None, sound=False):
    """Przelosowuje wzór jednej ścieżki (harmonia/sekcje zostają)."""
    cfg = STYLES[proj["style"]]
    proj["seed"] = int(new_seed if new_seed is not None else random.randrange(1000000))
    c = Ctx(proj, cfg); tr = track_of(proj, tname)
    GEN[tr["type"]](c, tr)
    if sound:
        randomize_sound(proj, tr, random.Random(proj["seed"] + 1))
    if tr["type"] == "wobble" and cfg["wob"] == "riddim":
        sub = first_of_type(proj, "sub")
        if sub:
            GEN["sub"](c, sub)
    return proj


def add_instance(proj, ttype):
    """Dodaje kolejną instancję wtyczki do projektu (losowe brzmienie + wzór + linki ducking)."""
    tr = new_track(unique_name(proj, ttype), ttype)
    proj["tracks"].append(tr); proj["tracks"] = _order_tracks(proj["tracks"])
    c = Ctx(proj, STYLES[proj["style"]])
    randomize_sound(proj, tr, random.Random(f"{proj['seed']}-snd-{tr['name']}"))
    GEN[ttype](c, tr)
    if ttype in DUCK and first_of_type(proj, "kick"):
        proj["links"].append(duck_link(tr, proj["style"]))
    return tr


def remove_track(proj, name):
    proj["tracks"] = [t for t in proj["tracks"] if t["name"] != name]
    proj["links"] = [l for l in proj["links"] if l["dst"] != name]
