"""drum_rules.py — rozbudowane reguły perkusji: narastanie (build), przejścia (fille), stopa / hat / crash w buildach.

Jedno pokrętło: `predict` (0…1, projekt: proj["predict"]).
  1.0  = zachowanie dawne (generator.py używa starych gałęzi — wynik bit-w-bit jak przed zmianą)
  ~0.6 = domyślnie: regularne, ale każdy build/fill może być inny
  0.0  = najmniej przewidywalnie (nadal w „sensownych" ramach — patrz strażnicy niżej)

Strażnicy sensowności (działają przy każdym `predict`):
  * każdy build narasta MONOTONICZNIE (odstępy między uderzeniami nigdy nie rosną — poza celowym oddechem/ciszą),
  * głośność narasta z postępem buildu, bez względu na regułę,
  * wszystko jest kwantyzowane do siatki: 1/16, 1/32 albo triole,
  * fille dobierane są tylko z instrumentów, które faktycznie są w projekcie,
  * jeden wspólny plan na takt — werbel, tomy, hat, stopa i crash NIE robią równocześnie tego samego fillu
    (np. gdy werbel kończy rolkę na kroku 8, tomy biorą resztę taktu; przy „stop" cichną stopa i hat, a crash wpada na następnym takcie).

Wynik jest deterministyczny (seed projektu + nazwa sekcji; przy section_motif_reuse klimatu: typ sekcji).
"""
from __future__ import annotations

import math
import random

LEVELS = [8, 4, 2, 1, 0.5]            # odstępy w krokach 1/16: ½, ¼, ⅛, 1/16, 1/32 (krok 4 = ćwierćnuta)
TRIP = [4, 8 / 3, 4 / 3, 2 / 3]       # ćwierćnuta, ćwierćnutowa triola, ósemkowa triola, szesnastkowa triola

# nazwa reguły -> jak „przewidywalna" (1 = równe stopnie, 0 = zaskakująca)
RULE_PRED = {"classic": 1.0, "halving": 0.85, "backbeat": 0.7, "dosed": 0.6, "plateau": 0.5,
             "smooth": 0.45, "triplet": 0.4, "late": 0.3}


def _closeness(pred, p, width=0.30):
    return math.exp(-((pred - p) / width) ** 2) + 0.02


def _bounds(total, weights):
    """Granice segmentów w CAŁYCH ćwierćnutach (suma = total), każdy segment ≥ 1 ćwierćnuta, o ile się mieści."""
    s = float(sum(weights)); cs = 0.0; b = [0]
    for w in weights:
        cs += w
        b.append(int(round(total * cs / s)))
    b[-1] = total
    for j in range(1, len(b)):
        if b[j] <= b[j - 1]:
            b[j] = min(total, b[j - 1] + 1)
    return b


def _segments(beats, gaps, weights, offs=None, start_beat=0):
    b = _bounds(beats - start_beat, weights)
    out = []
    for j, g in enumerate(gaps):
        t0, t1 = (start_beat + b[j]) * 4, (start_beat + b[j + 1]) * 4
        if t1 > t0:
            out.append((t0, t1, g, (offs[j] if offs else 0)))
    return out


def _seg_onsets(segs):
    out = []
    for t0, t1, g, off in segs:
        t = t0 + off
        while t < t1 - 1e-6:
            out.append(round(t, 4))
            t += g
    return sorted(set(out))


# ------------------------------------------------------------------ plan narastania (build)
class BuildPlan:
    """Plan jednego buildu: onsety werbla (rolka), stopa, hat, tomy w ostatnim takcie. Indeks i = takt w sekcji."""

    def __init__(self, plan, sec, rng):
        p, L = plan.p, int(sec["bars"])
        self.L, self.T = L, 16 * L
        beats = 4 * L
        self.rule = rule = plan.pick_rule(rng)
        if rule == "classic":
            segs = _segments(beats, [8, 4, 2, 1], [1, 1, 1, 1])
        elif rule == "halving":
            segs = _segments(beats, [4, 2, 1, 0.5], [1, 1, 1, 1])
        elif rule == "dosed":                          # te same poziomy, ale „dozowane" nierówno
            gaps = rng.choice([[8, 4, 2, 1], [4, 2, 1, 0.5], [8, 4, 2, 1, 0.5]])
            shape = rng.choice(["front", "even", "back"])
            base = {"front": [3.0, 2.2, 1.5, 1.0, 0.8], "even": [1.0] * 5, "back": [0.8, 1.0, 1.5, 2.2, 3.0]}[shape][:len(gaps)]
            segs = _segments(beats, gaps, [w * rng.uniform(0.75, 1.3) for w in base])
        elif rule == "plateau":                        # pomija poziomy, długo trzyma jeden
            k = rng.choice([2, 3])
            gaps = sorted(rng.sample(LEVELS, k), reverse=True)
            if gaps[-1] > 2:
                gaps[-1] = rng.choice([2, 1, 0.5])
            gaps = sorted(set(gaps), reverse=True)
            hold = rng.randrange(len(gaps))
            segs = _segments(beats, gaps, [3.0 if j == hold else 1.0 for j in range(len(gaps))])
        elif rule == "triplet":
            segs = _segments(beats, TRIP, [rng.uniform(0.8, 1.4) for _ in TRIP])
        elif rule == "late":                           # długo tylko podkład, potem szybkie przyspieszenie
            sb = max(1, int(L * rng.uniform(0.35, 0.6)))
            segs = _segments(beats, [4, 2, 1, 0.5], [1, 1, 1, 1], start_beat=min(sb * 4, beats - 4))
        elif rule == "backbeat":                       # backbeat 4/12 prawie do końca, roll dopiero na ostatnich taktach
            segs = _segments(beats, [8, 4, 2, 1], [0.55, 0.2, 0.15, 0.1], offs=[4, 0, 0, 0])
        else:                                          # smooth: accelerando z krzywej; granice poziomów przyciągane do ćwierćnut (siatka zostaje czysta)
            g0, g1 = rng.choice([8, 4]), rng.choice([1, 0.5])
            gam = rng.choice([0.8, 1.0, 1.3])
            lv = [g for g in LEVELS if g1 <= g <= g0]
            bounds = [0.0]
            for a, bb in zip(lv, lv[1:]):
                gm = math.sqrt(a * bb)                 # tu ciągły odstęp przechodzi z poziomu a do bb
                u = (math.log(gm / g0) / math.log(g1 / g0)) ** (1.0 / gam)
                bounds.append(max(0.0, min(1.0, u)))
            bounds.append(1.0)
            wts = [max(0.02, bounds[j + 1] - bounds[j]) for j in range(len(lv))]
            segs = _segments(beats, lv, wts)
        onsets = _seg_onsets(segs)

        # oddech / losowe wypadnięcia — tylko przy niskiej przewidywalności; nigdy nie ruszają ćwierćnut
        if p < 0.9:
            breath = rng.random() < (1 - p) * 0.55
            drop_p = (1 - p) * 0.12
            keep = []
            for t in onsets:
                bar, st = int(t // 16), t % 16
                if breath and bar % 4 == 3 and bar != L - 1 and st >= 12:
                    continue
                if st % 4 != 0 and rng.random() < drop_p:
                    continue
                keep.append(t)
            onsets = keep

        # tomy w ostatnim takcie (wspólny plan z werblem: werbel kończy się tam, gdzie tomy zaczynają)
        self.tom_run = None
        if "tom" in plan.present and rng.random() < (0.35 + 0.65 * p):
            self.tom_run = rng.choice(plan.tom_runs(p))
        # koniec rolki w ostatnim takcie przed dropem (ciche miejsce = napięcie)
        cut = 12 if rng.random() < p ** 1.5 else rng.choice([8, 12, 14, 16])
        if self.tom_run:
            cut = min(cut, min(s for s, _, _ in self.tom_run))
        self.cut = cut
        curve = 1.0 if rng.random() < p else rng.choice([0.7, 1.5])
        self.snare_hits = {}
        for t in onsets:
            bar, st = int(t // 16), t % 16
            if bar == L - 1 and st >= cut:
                continue
            v = min(127, 55 + int(65 * (t / self.T) ** curve)) + (4 if st % 4 == 0 else 0) + rng.randint(-3, 3)
            self.snare_hits.setdefault(bar, []).append((st, max(1, min(127, v))))

        # hat w buildzie
        mode = "eighths" if p > 0.85 else rng.choice(["eighths", "offbeat_dense", "sixteenth_tail", "silent_last"])
        h_start = 2 if (p > 0.6 or rng.random() < 0.5) else max(2, L // 2)
        self.hat_hits = {}
        for i in range(h_start, L):
            ns = len(self.snare_hits.get(i, []))
            v0 = 55 + int(40 * i / L)
            if mode == "silent_last" and i == L - 1:
                continue
            if mode == "offbeat_dense" and ns >= 8:
                steps = [2, 6, 10, 14]
            elif mode == "sixteenth_tail" and i >= L - 2:
                steps = list(range(16))
            else:
                steps = list(range(0, 16, 2))
            self.hat_hits[i] = [(s, max(1, min(127, v0 + rng.randint(-3, 3)))) for s in steps]

        # stopa w buildzie
        kmode = "legacy" if p > 0.85 else rng.choice(["legacy", "quarter_ramp", "half_pulse", "drop_last"])
        if kmode == "quarter_ramp" and not plan.fourfloor and rng.random() < 0.5:
            kmode = "half_pulse"
        self.kick_hits = {}
        for i in range(L // 2, L):
            if kmode == "drop_last" and i == L - 1:
                continue
            if kmode == "quarter_ramp" and i >= L - max(2, L // 4):
                n = i - (L - max(2, L // 4))
                self.kick_hits[i] = [(s, 92 + 5 * n + (10 if s == 0 else 0) + rng.randint(-4, 4)) for s in (0, 4, 8, 12)]
            elif kmode == "half_pulse":
                self.kick_hits[i] = [(0, 118 + rng.randint(-5, 5)), (8, 100 + rng.randint(-5, 5))]
            else:
                self.kick_hits[i] = [(0, 118 + rng.randint(-5, 5))]
        self.kmode, self.hmode = kmode, mode

    def snare(self, i):
        return self.snare_hits.get(i, [])

    def hat(self, i):
        return self.hat_hits.get(i, [])

    def kick(self, i):
        return self.kick_hits.get(i, [])

    def tom(self, i):
        return self.tom_run if (self.tom_run and i == self.L - 1) else []


# ------------------------------------------------------------------ biblioteka fillów (takty frazowe w dropie)
def _f_ghost(r, c):      return {"snare": [(14, 70 + r.randint(-4, 6))]} if r.random() < 0.6 else {"snare": [(11, 50), (14, 72)]}
def _f_drag(r, c):       return {"snare": [(14, 60), (14.5, 76), (15, 96)]}
def _f_hat_roll(r, c):   return {"hat_extra": [(14 + 0.5 * q, 58 + 11 * q) for q in range(4)], "hat_mute": 14}
def _f_snare16(r, c):    return {"snare": [(s, 80 + 2 * s) for s in (12, 13, 14, 15)], "hat_mute": 12}
def _f_syncop(r, c):     return {"snare": [(10, 85), (13, 80), (14, 95)]}
def _f_snare_half(r, c): return {"snare": [(s, 60 + int(52 * (s - 8) / 7)) for s in range(8, 16)], "hat_mute": 8}
def _f_snare32(r, c):    return {"snare": [(12 + 0.5 * q, 70 + 3 * q) for q in range(8)], "hat_mute": 12}
def _f_tom_desc(r, c):   return {"tom": [(s, k, 95 + r.randint(-4, 4)) for s, k in zip((12, 13, 14, 15), (47, 45, 43, 41))]}
def _f_tom_asc(r, c):    return {"tom": [(s, k, 90 + 2 * q + r.randint(-3, 3)) for q, (s, k) in enumerate(zip((12, 13, 14, 15), (41, 43, 45, 47)))]}
def _f_tom_trip(r, c):   return {"tom": [(round(8 + q * 4 / 3, 4), k, 82 + 3 * q) for q, k in enumerate((50, 48, 47, 45, 43, 41))], "hat_mute": 8}
def _f_dialog(r, c):     return {"snare": [(s, 78 + 3 * q) for q, s in enumerate((8, 9, 10, 11))],
                                 "tom": [(s, k, 96) for s, k in zip((12, 13, 14, 15), (47, 45, 43, 41))], "hat_mute": 8}
def _f_stop(r, c):       return {"kick_mute": 12, "hat_mute": 12, "crash_next": 100 + r.randint(0, 8)}


# nazwa: (poziomy, wymagane instrumenty, przewidywalność, waga bazowa, budowniczy)
FILLS = {
    "ghost":      ((1,),        {"snare"}, 0.9, 1.0, _f_ghost),
    "drag":       ((1,),        {"snare"}, 0.5, 0.6, _f_drag),
    "hat_roll":   ((1, 2),      {"hat"},   0.6, 0.7, _f_hat_roll),
    "snare16":    ((1, 2),      {"snare"}, 0.9, 1.0, _f_snare16),
    "syncop":     ((2,),        {"snare"}, 0.5, 0.8, _f_syncop),
    "tom_desc":   ((2, 3),      {"tom"},   0.95, 1.0, _f_tom_desc),
    "tom_asc":    ((2, 3),      {"tom"},   0.6, 0.7, _f_tom_asc),
    "snare_half": ((2, 3),      {"snare"}, 0.7, 0.9, _f_snare_half),
    "tom_trip":   ((2, 3),      {"tom"},   0.35, 0.6, _f_tom_trip),
    "dialog":     ((2, 3),      {"snare", "tom"}, 0.4, 0.6, _f_dialog),
    "snare32":    ((3,),        {"snare"}, 0.4, 0.8, _f_snare32),
    "stop":       ((2, 3),      set(),     0.2, 0.22, _f_stop),
}


class DrumPlan:
    """Wspólny plan perkusji dla całego projektu (budowany leniwie przy pierwszym użyciu przez Ctx.drums)."""

    def __init__(self, c):
        self.c, self.p = c, max(0.0, min(1.0, float(c.predict)))
        cfg = c.cfg
        self.present = {t["type"] for t in c.p["tracks"]}
        self.fourfloor = bool(cfg.get("fourfloor"))
        hat, wob = cfg.get("hat"), cfg.get("wob")
        self.hat_mode, self.wob = hat, wob
        # ile fillów lubi styl
        self.amt = 1.0
        if hat in ("ride", "none") or cfg.get("snare") == []:
            self.amt = 0.45
        elif hat == "trap" or wob == "tearout":
            self.amt = 1.25
        self.builds, self.fills, self.summary = {}, {}, {"builds": {}, "fills": {}}
        self._last_kind, self._sticky = None, {}
        self._prep()

    # --- losowanie
    def _rng(self, sec, tag):
        reuse = self.c.climate.get("section_motif_reuse") and self.c.climate.get("motif_seed")
        return self.c.rng("drumplan-" + tag, sec["type"] if reuse else sec["name"])

    def pick_rule(self, rng):
        cfg, p = self.c.cfg, self.p
        sw = {k: 1.0 for k in RULE_PRED}
        if self.hat_mode == "trap":
            sw["triplet"] *= 2.5; sw["smooth"] *= 1.5
        if self.fourfloor:
            sw["classic"] *= 1.4; sw["halving"] *= 1.4; sw["late"] *= 0.8
        if self.hat_mode in ("ride", "none") or cfg.get("snare") == []:
            sw["backbeat"] *= 2.5; sw["triplet"] *= 0.4; sw["late"] *= 0.5
        if self.wob == "dnb" or cfg.get("reese") == "all":
            sw["backbeat"] *= 1.3; sw["plateau"] *= 1.3
        names = list(RULE_PRED)
        w = [sw[n] * _closeness(RULE_PRED[n], p) for n in names]
        return rng.choices(names, w)[0]

    def tom_runs(self, p):
        runs = [[(s, k, 80 + 2 * s) for s, k in zip((4, 6, 8, 10, 12, 14), (50, 48, 47, 45, 43, 41))]]            # dawny (6 uderzeń)
        if p < 0.9:
            runs += [[(s, k, 88 + 2 * q) for q, (s, k) in enumerate(zip((12, 13, 14, 15), (41, 43, 45, 47)))],     # w górę
                     [(round(8 + q * 4 / 3, 4), k, 80 + 3 * q) for q, k in enumerate((50, 48, 47, 45, 43, 41))],  # triola
                     [(s, k, 92) for s, k in zip((12, 13, 14, 15), (47, 45, 43, 41))]]
        return runs

    # --- przygotowanie planu
    def _prep(self):
        c, p = self.c, self.p
        for b, B in enumerate(c.B):
            sec, t, i, L = B["sec"], B["type"], B["i"], B["L"]
            if t == "build" and sec["name"] not in self.builds:
                bp = BuildPlan(self, sec, self._rng(sec, "build"))
                self.builds[sec["name"]] = bp
                self.summary["builds"][sec["name"]] = {"rule": bp.rule, "hat": bp.hmode, "kick": bp.kmode,
                                                       "cut": bp.cut, "toms": bool(bp.tom_run)}
            if t == "drop":
                lvl = 3 if i == L - 1 else 2 if i % 8 == 7 else 1 if i % 4 == 3 else 0
                d = c.dens(B)
                prob = {0: 0.06 * (1 - p) ** 2 * self.amt,
                        1: min(1.0, (0.12 + 0.3 * (1 - p)) * self.amt * (0.5 + d)),
                        2: min(1.0, (0.8 + 0.2 * p) * max(0.6, self.amt)),
                        3: 1.0}[lvl]
                r = self._rng(sec, f"fill{i}")
                if r.random() < prob:
                    f = self._pick_fill(lvl, r, sec["name"])
                    if f:
                        self.fills[b] = f
                        self.summary["fills"][b] = f["kind"]
                        if f.get("crash_next") and b + 1 < len(c.B):
                            self.fills.setdefault(b + 1, {})["crash_hit"] = f["crash_next"]

    def _pick_fill(self, lvl, r, secname):
        p = self.p
        cands = [(n, s) for n, s in FILLS.items() if lvl in s[0] and s[1] <= self.present]
        if not cands:
            return None
        key = (secname, lvl)
        if key in self._sticky and r.random() < p ** 1.5:             # przy wysokiej przewidywalności fraza wraca tym samym fillem
            kind = self._sticky[key]
        else:
            w = []
            for n, (_, _, pred, base, _) in cands:
                x = base * _closeness(pred, p, 0.35)
                if n == self._last_kind:
                    x *= 0.35
                if n == "snare16" and self.wob == "tearout":
                    x *= 3
                if n == "hat_roll" and self.hat_mode == "trap":
                    x *= 3
                w.append(x)
            kind = r.choices([n for n, _ in cands], w)[0]
        self._sticky[key] = self._last_kind = kind
        out = dict(FILLS[kind][4](r, self.c)); out["kind"] = kind
        return out

    # --- API dla generatorów
    def fill(self, b):
        return self.fills.get(b)

    def build(self, B):
        return self.builds.get(B["sec"]["name"])

    def crash_extra(self, b, B, r):
        """Dodatkowe crashe w dropie (poza startem sekcji): -> (krok, vel) lub None."""
        f = self.fills.get(b) or {}
        if f.get("crash_hit"):
            return (0, f["crash_hit"])
        i, p = B["i"], self.p
        if i > 0 and i % 16 == 0 and r.random() < 0.4 + 0.6 * p:
            return (0, 108)
        if i > 0 and i % 8 == 0 and i % 16 and r.random() < (1 - p) * 0.4:
            return (0, 88)
        return None
