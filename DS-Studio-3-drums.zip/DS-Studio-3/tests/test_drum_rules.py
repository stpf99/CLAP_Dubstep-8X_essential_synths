"""Testy rozbudowanych reguł perkusji (drum_rules.py): sensowność, determinizm, zgodność wstecz (predict=1.0).

Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_drum_rules -v
Wymaga zbudowanych wtyczek (`make`); bez nich testy są pomijane.
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dubstep_studio import core  # noqa: E402

try:
    core.meta()
    from dubstep_studio import generator as G  # noqa: E402
    OK = True
except Exception:
    OK = False

STYLES = ["Brostep", "Techno", "DnB", "Trance", "House", "Trap", "Electro", "Jazz"]


def gen(style, seed, p, bars=96):
    return G.generate(style=style, seed=seed, bars=bars, predict=p)


def notes_of(pr, typ):
    return sorted(next((t for t in pr["tracks"] if t["type"] == typ), {"notes": []})["notes"])


@unittest.skipUnless(OK, "brak zbudowanych wtyczek CLAP")
class DrumRules(unittest.TestCase):
    def test_legacy_mode_has_no_plan(self):
        pr = gen("Techno", 1, 1.0)
        self.assertNotIn("drum_plan", pr)
        self.assertEqual(pr["predict"], 1.0)

    def test_deterministic(self):
        a, b = gen("Brostep", 3, 0.4), gen("Brostep", 3, 0.4)
        for t in ("snare", "hat", "kick", "crash"):
            self.assertEqual(notes_of(a, t), notes_of(b, t), t)

    def test_build_ramps_monotone_and_louder(self):
        for st in STYLES:
            for sd in (1, 2, 3):
                for p in (0.0, 0.3, 0.6, 0.9):
                    pr = gen(st, sd, p)
                    sn = notes_of(pr, "snare")
                    for s in (x for x in pr["sections"] if x["type"] == "build"):
                        prev = None
                        for i in range(s["bars"]):
                            b0 = (s["start"] + i) * 4
                            hits = [n[0] for n in sn if b0 <= n[0] < b0 + 4]
                            if len(hits) >= 3:
                                g = min(y - x for x, y in zip(hits, hits[1:]))
                                if prev is not None:
                                    self.assertLessEqual(g, prev + 1e-3, f"{st}/{sd}/{p} takt {i}: odstęp rośnie")
                                prev = g
                        vs = [n[3] for n in sn if s["start"] * 4 <= n[0] < (s["start"] + s["bars"]) * 4]
                        if len(vs) > 8:
                            q = len(vs) // 4
                            self.assertGreater(sum(vs[-q:]) / q, sum(vs[:q]) / q, f"{st}/{sd}/{p}: głośność nie narasta")

    def test_everything_on_grid(self):
        # bez swingu: każde uderzenie na siatce 1/32 (0.5 kroku) albo trioli (2/3 kroku)
        for st in ("Techno", "Trap", "DnB", "Brostep"):
            if G.STYLES[st].get("swing8"):
                continue
            pr = G.generate(style=st, seed=2, bars=96, predict=0.2, swing=0.0)
            for typ in ("snare", "hat", "tom", "kick", "crash"):
                for beat, _, _, _ in notes_of(pr, typ):
                    st16 = (beat % 4) * 4
                    d = min(abs(st16 - round(st16 * 2) / 2), abs(st16 - round(st16 * 1.5) / 1.5))
                    self.assertLess(d, 0.01, f"{st}/{typ} beat={beat}")

    def test_variety_grows_when_predictability_drops(self):
        def rules(p):
            out = set()
            for st in ("Techno", "Brostep", "DnB", "House"):
                for sd in range(1, 6):
                    out |= {v["rule"] for v in gen(st, sd, p).get("drum_plan", {}).get("builds", {}).values()}
            return out
        self.assertGreaterEqual(len(rules(0.3)), 3)
        self.assertLessEqual(len(rules(0.95)), len(rules(0.3)) + 2)

    def test_fills_use_only_present_instruments(self):
        from dubstep_studio import drum_rules as DR
        for st in STYLES:
            pr = gen(st, 4, 0.5)
            present = {t["type"] for t in pr["tracks"]}
            for kind in pr.get("drum_plan", {}).get("fills", {}).values():
                self.assertLessEqual(DR.FILLS[kind][1], present, f"{st}: fill {kind}")

    def test_stop_fill_is_coordinated(self):
        for st in STYLES:
            for sd in range(1, 9):
                pr = gen(st, sd, 0.0)
                bars = [int(b) for b, k in pr.get("drum_plan", {}).get("fills", {}).items() if k == "stop"]
                for b in bars:
                    for typ in ("kick", "hat", "openhat"):
                        late = [n for n in notes_of(pr, typ) if b * 4 + 3 <= n[0] < b * 4 + 4]
                        self.assertEqual(late, [], f"{st}/{sd}/{typ}: coś gra w ciszy „stop”")
                    if "crash" in {t["type"] for t in pr["tracks"]} and b + 1 < pr["bars"]:
                        self.assertTrue([n for n in notes_of(pr, "crash") if (b + 1) * 4 <= n[0] < (b + 1) * 4 + 0.2],
                                        f"{st}/{sd}: brak crasha po stopie")


if __name__ == "__main__":
    unittest.main()
