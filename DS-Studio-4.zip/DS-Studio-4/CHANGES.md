# Reguły perkusji: narastanie, fille i „przewidywalność"

Dotąd każdy build narastał tak samo (werbel: 2 → 4 → 8 → 16 uderzeń, cztery równe stopnie), hat grał stałe ósemki, a fille przychodziły zawsze co 8 taktów w jednej postaci.
Teraz jest jedno pokrętło **Przewidywalność perkusji** (Generator, suwak 0–100 %, domyślnie 60 %; `generate(predict=…)`, `proj["predict"]`; w Live bierze się z Generatora).

- **100 %** = dawne reguły, wynik identyczny co do nuty (sprawdzone na 30 projektach × wszystkie ścieżki). Stare projekty bez klucza `predict` też działają jak dawniej.
- **niżej** = nowy moduł `drum_rules.py`. Reguła dobierana jest do suwaka (im niższy, tym bardziej „zaskakujące" reguły), z wagami stylu (trap → triole i rolki 1/32, techno/trance → równe stopnie, jazz/ride → prawie bez fillów, DnB → backbeat + plateau).

**Narastanie (build)** — 8 reguł: `classic` (dawna), `halving` (ćwierć→ósemki→16→32), `dosed` (te same poziomy, ale dozowane nierówno: długo wolno albo szybki finisz),
`plateau` (pomija poziomy, długo trzyma jeden), `smooth` (accelerando z krzywej, granice poziomów na ćwierćnutach), `triplet` (triole), `late` (długo tylko podkład, potem szybki finisz),
`backbeat` (4/12 prawie do końca, rolka dopiero na ostatnich taktach). Do tego: oddech co 4 takty, losowe wypadnięcia słabych uderzeń, krzywa głośności (liniowa / szybki start / późny skok),
miejsce końca rolki w ostatnim takcie (8 / 12 / 14 / 16), **hat** (ósemki / offbeat gdy werbel gęsty / 16 na ostatnich 2 taktach / cisza w ostatnim takcie / późne wejście),
**stopa** (jak dawniej / ćwierćnuty z narastaniem / pół-takt / cisza w ostatnim takcie), **tomy** w ostatnim takcie (6 uderzeń / w górę / triola / 4 uderzenia) — werbel kończy rolkę tam, gdzie zaczynają tomy.

**Fille w dropie** — 12 rodzajów (ghost, drag, rolka hatu 1/32, werbel 1/16 w ostatniej ćwiartce / połowie taktu, werbel 1/32, synkopa, tomy w dół / w górę / triolowe,
dialog werbel→tomy, „stop" = cichną stopa i hat, crash wpada w następnym takcie). Poziomy: co 4 takty (mały), co 8 (średni), koniec sekcji (duży, zawsze).
Wysoka przewidywalność = fraza wraca tym samym fillem; niska = fille wypadają także poza regularnymi miejscami. Crash: start dropu zawsze, dalsze akcenty co 8/16 taktów z prawdopodobieństwem.

**Strażnicy (przy każdej wartości suwaka):** odstępy w buildzie nigdy nie rosną, głośność narasta, siatka 1/16–1/32 albo triole, fill tylko z instrumentów obecnych w projekcie,
wspólny plan na takt (werbel / tomy / hat / stopa / crash nie robią tego samego jednocześnie). Wynik deterministyczny (seed + sekcja; przy `section_motif_reuse` — typ sekcji).
Podgląd wylosowanych reguł: `proj["drum_plan"]` (build → reguła, takt → fill).

Testy: `python3 -m unittest tests.test_drum_rules -v` (7). Znane ograniczenie: ride / shaker / rim / clap nie reagują na „stop" (grają dalej).

---

# Style specjalne (artysta / album) zamiast mieszanek gatunków

`build_pack.py` składał presety artystów jako hybrydy gatunków („House 50% + Acid Techno 32% + …”) — czyli uśredniał gotowe wzory. Teraz każdy z 33 presetów
ma **własny styl** w `dubstep_studio/special_styles.py`: własne wzory stopy / werbla / ghost-nut / hatu, swing, tryb suba, **własne wzory basu**
(WOB pod kluczem `sp:<nazwa>`), progresje, skale, szablon formy, paletę instrumentów (core/extras/głosy) i **nastawy brzmień per instrument** (SOUND_STYLE),
a także epokę, motyw mowy, klasę ostrości, ducking i scenę. Preset wskazuje ten styl (`style == style_base`).

- Style są rejestrowane jako czyste (`generator.py`, po `DUCK_BASE`): działają w presetach, Live, remiksie i jako składnik hybryd („Kraftwerk - Autobahn (1974) 60% + Techno 40%”).
  Nie trafiają do `ST.ORDER` — pole szachowe i losowanie Live są bez zmian; w liście stylów Generatora są na końcu. Wyłączenie: `DS_NO_SPECIAL=1`.
- Nowy zapis wzorów tekstem: `"0r2 3r1 6o1"` (krok + znacznik r/o/f/t/b/p/u + długość) i brzmień: `"Decay: 170 250; Drive: .3 .55; Waveform = 2 3"`.
- `era_profiles.BIAS_EXEMPT`: dla stylu specjalnego bias epoki nie rusza parametrów, które styl ma jawnie w SOUND_STYLE. Bez tego bias (w ułamku skali parametru)
  wypychał ok. 15 % wartości poza okna — np. `Glide` 0–10 ms kończył jako ok. 150 ms. Style wbudowane i hybrydy działają jak dawniej.
- `build_pack.py` waliduje każdy styl: czysty (nie hybryda), era „auto” = zamierzona, limit ścieżek epoki, typy w `core.TYPES`, **istnienie każdego parametru we wtyczce**
  (nieznany byłby po cichu pomijany), poprawność wzorów, determinizm `generate()`, stopa i wobble w dropach faktycznie z pul stylu. Błąd = nic się nie zapisuje.
- Zachowane do porównania: `presets_artists_hybrid.json` (poprzedni pakiet hybryd).
- Znane ograniczenie: parametry mowy `Intonation` / `Letter Pitch Range` / `Formant Shift` są losowo nadpisywane przez efekt theremin na głosie (generator.py), więc
  styl ustawia tylko `Dialect`.

Testy: `python3 -m unittest tests.test_special_styles -v` (9). Przebudowa paczki: `python3 build_pack.py`.

---

# Dynamics w GUI: limiter / normalizer 3-pasmowy z presetami

Zakładka **Ścieżki / parametry** → panel **Dynamics** na górze parametrów każdej ścieżki:
- **Tryb**: Wyłączony / Limiter 3-pasmowy / Normalizer 3-pasmowy. **Domyślnie włączony: Limiter 3-pasmowy.**
- **Preset**: Transparent, Bass Tight, Punchy, Loud, Bright Lead, Warm Pad, Sub Focus, **Less Bass** (domyślny: pasmo < ok. 150 Hz stale przycięte o ok. 5 dB + niższy sufit dołu; ściszane suwakiem Siła). Opis w podpowiedzi i pod listą.
- **Siła** 0–100%.
- **Zastosuj do wszystkich ścieżek** / **Wyłącz na wszystkich**.

To opcja instrumentu: działa w samej wtyczce (końcówka toru instrumentu), a nie w renderze/masteringu miksu. Parametry zapisują się w projekcie jak każde inne (`Dynamics`, `Dyn Preset`, `Dyn Amount`, ID 61–63), działają też w Bitwigu i w presetach.
Domyślne wartości siedzą w silniku (`PI` w `src/ds_engine.h`), więc dotyczą każdej nowej ścieżki i każdego projektu, który nie ma tych parametrów zapisanych jawnie — stare projekty zagrają z mniejszą ilością basu; żeby wrócić do poprzedniego brzmienia ustaw Tryb = Wyłączony („Wyłącz na wszystkich”).
Procesor nie liczy się w ciszy (po ogonie ostatniej nuty jest pomijany), więc domyślne włączenie prawie nie zwiększa czasu renderu.
Silnik: `src/ds_engine.h` (`DYN_PRE`, `dynProcess`), podział Linkwitz-Riley 4. rzędu, detektor sprzężony L/R, miękki sufit ok. −0,3 dBFS. Test: `tests/test_dynamics.py`. Po aktualizacji przebuduj wtyczki (`make`).

---

# Autolevels bez dodatkowego gainu

`autolevel_heuristic` (generator, Director, krytyczna autokorekta) i `autolevel` (pomiar RMS, przycisk Autolevels) nie podbijają już żadnej ścieżki powyżej 1.0 (`core.GAIN_MAX_AUTO`).
Wcześniej heurystyka sięgała 1.6, a pomiar RMS 1.8, więc ścieżki dostawały dodatkowy gain (np. kick 1.16, riser 1.27). Teraz proporcje między torami zostają, a całość jest skalowana tak, żeby najgłośniejszy tor miał 1.0.
Suwak Gain ścieżki nadal sięga 1.5 ręcznie; zapisane projekty się nie zmieniają.

---

# Autokorekta krytyczna (profile płynności)

Nowy tryb przy **Reżyserze**: checkbox **Autokorekta krytyczna** + profil (Auto / Ambient / Minimal / Soft / Aggressive) + suwak intensywności + przycisk **Zastosuj na projekcie**.

- Trigger: preset (profil) **lub** suwak **lub** oba; działa przy generacji (gdy włączone) i osobno na gotowym projekcie.
- Zakres: **cały utwór** — instrumenty (avoid→prefer), zakresy nut na sztywno, okna parametrów, automacje wielu parametrów w czasie sekcji (Cutoff, Wave Morph, Glide, LFO>Cutoff…), forma (dłuższe intro/break, łagodniejsze dropy), autolevel.
- Cel: płynniejsze brzmienia (długie Attack/Release, glide, wolne LFO, krzywe automacji), nie tylko pozycje nut + jeden oscylator.
- Profile `ambient` / `minimal` / `soft` / `aggressive` w `critical_correct.py`; mapowanie stylów (Space Electronica → ambient, Brostep → aggressive, …).
- Szanuje `lock_notes` / `lock_sound` / `locked_params`.
- Raport w `proj["critical_correct_report"]` (stats + log); status GUI po generacji / zastosowaniu.

Pliki: `dubstep_studio/critical_correct.py` (nowy), `director.py` (DEFAULT + normalize), `generator.py` (post-pass), `gui.py` (UI + `apply_critical_correct_now`).

---

# Karta „Modelowanie CLAP” (instrumenty użytkownika bez wychodzenia z GUI)

Nowa zakładka **Modelowanie CLAP**: projektowanie własnych wtyczek na silniku DS (te same 61 parametrów co wbudowane typy):
- szablon z dowolnego istniejącego typu, tabela parametrów (— / jawny / ukryty, wartość, zakres losowania generatora), flagi one-shot/retrigger, częstotliwość odniesienia,
  banki modalne (Handpan/Tongue/Vibes/Marimba/Bell lub **własny** — do 6 składowych: stosunek f, amplituda, zanik);
- klasyfikacja dla generatora: grupa, wzór nut (`GEN`), rola, ducking, gain, agresja, pasma, **dodanie do `extras` wybranych stylów** (hybrydy dziedziczą) i do `prefer` epok;
- **Odsłuch**: kompiluje tymczasową wtyczkę (`build/preview/`, bez zmian w bibliotece), renderuje frazę testową i odtwarza ją;
- **Zatwierdź do biblioteki**: zapis `user_instruments/<id>.json` → generowanie `src/user/<id>.inc`, `src/ds_user_types.inc`, `user_types.mk` (dopisuje nazwę do `NAMES` w Makefile) →
  `make` kompiluje **tylko nową wtyczkę** (typy użytkownika są dopisywane na końcu, indeksy dotychczasowych się nie zmieniają) + paczkę DubstepKit.clap →
  typ jest rejestrowany w aplikacji bez restartu (core.TYPES/GROUPS, tabele generatora, dyrektora, niuansów, aranżera, instrument_replace, epok, Live; drzewo instrumentów i listy wyboru w GUI);
- przy starcie wszystkie zatwierdzone specyfikacje są rozpoznawane automatycznie (typ jest dostępny, gdy znaleziono jego .clap); „Skanuj ponownie” rozpoznaje nowe pliki .json w locie;
- edycja zatwierdzonego instrumentu = „Zatwierdź zmiany” (przebudowa wtyczki); „Wyłącz / włącz” ukrywa typ, zostawiając definicję C++ (stałe indeksy).

Pliki: `dubstep_studio/userinst.py` (backend), `dubstep_studio/modeling_gui.py` (karta), `host/dstypes.cpp` (zrzut tabeli parametrów/typów z silnika → JSON),
hooki w `ds_engine.h` (`DS_USER_TYPES_INC`, `DS_USER_MODAL_INC`), `Makefile` (`-include user_types.mk`, cel `build/dstypes`), testy: `tests/test_userinst.py`.

---

# Rozszerzona baza instrumentów CLAP (v6): 32 → 51 typów

Nowe wtyczki (ten sam silnik `ds_engine.h`, nowe `TypeDef` + 3 nowe banki modalne; `make` buduje `DS-<Nazwa>.clap`, wszystkie opcjonalne):
- klawisze/organy: **Organ, E-Piano, Harpsichord**; dęte/smyczki/głosy: **Flute, Brass, Cello, Choir**; perkusyjne melodyczne (modalne): **Vibes, Marimba, Bell**
- synth/bas: **Hoover, 808 Bass, Upright, Drone**; perkusja: **Open Hat, Ride, Cowbell, Conga**; fx: **Glitch**

Integracja ze stylami i hybrydami:
- `styles.py` / `generator.py`: charakterystyczne typy trafiają do `extras` stylów (Jazz: epiano/upright/ride/vibes, Baroque: harpsichord/organ/flute/cello,
  Trance: choir/bell, Electro/Trap: 808, Techno: hoover/openhat, Space/Berlin: drone/choir/bell…); hybrydy dziedziczą sumę `extras` składników.
- `era_profiles.py`: nowe typy w listach `prefer` epok; hybryda dostaje epokę o największym limicie ścieżek spośród składników (wcześniej tylko pierwszego).
- `generator.py`: wzory (`GEN`), kolejność, role (`NATIVE_ROLE`), ducking, zakresy brzmień (`SOUND`), agresja/pasma (`INST_AGG`, `INST_BANDS`), grupy losowania; nowe generatory perkusyjne `gen_openhat/ride/perc`.
- `core.py` (typy, grupy, gain, poziomy), `director.py`, `niuanse.py`, `arranger.py`, `instrument_replace.py`, `live.py` (Live losuje też nowe typy).

---

# Live: „Losuj nowe hybrydy”

Nowa opcja w zakładce Live (tryb losowy; `config.txt`: `[live] new_hybrids = yes`; w presetach `live.new_hybrids`). Każda aranżacja dostaje świeżą hybrydę
2–3 stylów z dowolnych grup (losowe proporcje, min. 12 %, bez powtórek z ostatnich 20). Składnikiem zostaje styl wylosowany kaskadą nastroju/pory dnia.
Ma pierwszeństwo przed „Mutacjami” i polem szachowym; nie działa przy zablokowanym stylu. W logu Live hybryda oznaczona ★.

---

# Aranżer (barwy · extras · kreator · nowe ad hoc · efekty WYSIWYG)

Nowy moduł `dubstep_studio/arranger.py`, włączany: GUI (Generator → „Aranżer”), `config.txt` (`arranger = yes`, `arranger_*`),
CLI (`gen --arranger [--arranger-amount X --arranger-adhoc X --arranger-persist]`), Live (bierze flagę z Generatora/configu).
Przy aranżacji sam nakłada barwy z banku, dokłada extras FX wg struktury (riser w buildzie, uderzenie na dropie, tekstury w
break/intro/outro), korzysta z `scenario_creator.auto_choice`, a gdy trzeba tworzy nowe barwy/extras ad hoc (zapis w projekcie
`proj["adhoc"]`, opcjonalnie `~/DubstepStudio/adhoc_bank.json`, nadpisanie: `DS_ADHOC_BANK`). Efekty ustala figurami WYSIWYG
(`proj["geometry_doc"]`, widoczne i edytowalne w zakładce „Edytor WYSIWYG”). Ten sam seed → ten sam projekt.

## Poprawki znalezione przy okazji
- `extras_fx`: 15 przepisów miało nazwy parametrów nieistniejące we wtyczce (host je pomijał) — `fix_params` + `PARAM_ALIASES`.
  Cztery (`fx_room_tone`, `fx_static`, `fx_wind`, `fx_whisper_pad`) nie mają odpowiednika `Noise` na pad/zap.
- `geometry_editor`: intensywność oceniana na y=0.5 i jedną liczbą na tor (przycisk „Auto” nic nie zmieniał) — teraz na wysokości
  figury, jako przebieg w czasie (velocity + automatyzacja Cutoff/Drive/Resonance); ponowne „Zastosuj” nie kumuluje (`geo_vel0`).
- `timbre_bank.spawn_timbre`: `Fine` zapisywany na typach, które go nie mają → rozstrojenie przez `Tune`.
- `timbre_bank.apply_timbre_to_track`: ADSR tylko dla parametrów, które wtyczka ma.
- `list_timbres` / `weighted_extras_for_style` pomijają wpisy ad hoc (losowania wbudowane nie zależą od historii).

Testy: `python3 -m unittest tests.test_arranger tests.test_fixes -v` (35, w tym fuzz 60 projektów).

# DS Dubstep Studio AV — poprawki 1–9 z przeglądu kodu (już naniesione)

To jest pełna paczka projektu z poprawkami naniesionymi. Zmienione pliki: `dubstep_studio/{arp_engine,core,director,eco,generator,gui,live,niuanse,remix}.py`;
nowy plik: `tests/test_fixes.py`. Pozostałe pliki, w tym `build/` (kod C++ nie był ruszany), są identyczne jak w wersji wyjściowej;
pominięto tylko katalogi `__pycache__` (Python odtworzy je przy pierwszym uruchomieniu).

Testy (czysta logika działa bez hosta; reszta wymaga `make`, test GUI także PyQt6):

    python3 -m unittest tests.test_fixes -v

## Co zmieniono

1. **gui.py `_preview_extra_or_timbre`** — `render_stems` zwraca słownik tablic numpy, a funkcja traktowała je jak ścieżki plików
   (`ValueError`, podsłuch extras/barw nigdy nie grał). Teraz: `mix_stems` → `ds_studio_sample.wav` → `player.play`.
2. **Klucze MIDI poza 0..127** — przyczyna: `niuanse._snap` przy przejściu B→C przesuwał nutę o −11 zamiast +1 (trzy kroki = −36,
   stąd nuta −12 i `ValueError` w `write_midi`). Poprawiony `_snap`; dodatkowo `core.fold_key/clamp_vel/sanitize_notes`
   (zawijanie o oktawy, velocity 1..127) w `_write_job`, `write_midi` oraz na końcu `generate`, `reroll_track`, `remix`.
3. **arp_engine.structural_inject** — `hash(nazwa)` zastąpione `zlib.crc32`; ten sam seed daje teraz ten sam projekt
   niezależnie od `PYTHONHASHSEED` (przed: 25 z 90 projektów różniło się między uruchomieniami).
4. **live.plan_next** — `randint(2, 1)` przy dokładnie jednym dostępnym extra → `min(len(ex), …)`.
5. **director.apply_roles / _retune** — ścieżki z `lock_notes` nie biorą udziału w zamianach ról, a `lock_sound` / `locked_params["Cutoff"]`
   blokuje retuning barwy (tak jak w `generator.apply_role_swaps`). Usunięte puste wywołania `_put(…, bn_[:0], …)`.
6. **live._gen_extras_from_base** — pakiet złożoności może tylko podnieść siłę niuansów/uniq ustawioną w Generatorze (`max`),
   nie nadpisuje jej; `autolevels` bez klucza w base domyślnie `False` (jak w config.txt i `generate`).
7. **eco.py** — `_next_no`: `flock` + zapis atomowy (8 procesów × 300 wywołań: 70 → 2400 unikalnych numerów);
   `_encode`: brak osieroconych `.part` i czytelny błąd przy zerwanym potoku do ffmpeg; `preroll`: jedna instancja na katalog
   (drugi proces kończy z wynikiem 0) i sprzątanie starych `.part`. W katalogu preroll pojawiają się pliki `.counter.lock` i `.preroll.lock`.
8. **core.cleanup_stale_work** — usuwa wyłącznie katalogi o nazwie z `mkdtemp` (`dsr<pid>_xxxxxxxx`, `dsr_xxxxxxxx`);
   cudze, np. `dsrender-build`, zostają. Dowiązania symboliczne są pomijane.
9. **core.render_stems** — po renderze cache przycinany do kluczy bieżącego stanu (przed: +~100 MB na każdą edycję przy 144 taktach);
   niezmienione ścieżki nadal nie są renderowane ponownie.

## Zmiany zachowania, o których warto wiedzieć

- Projekty z włączonymi niuansami lub arp-inject będą dla tego samego seeda inne niż przed poprawką (naprawione źródła błędów); zapisane projekty bez zmian.
- `--preset` (Live/ECO) nie włącza już domyślnie autolevels — preset ich nie przechowuje (pozycja 10 z przeglądu, poza tą paczką).
- Po edycji ścieżki powrót do jej wcześniejszego stanu (undo) renderuje ją ponownie.

## Weryfikacja

16 testów: na kodzie oryginalnym 15 pada, po poprawkach wszystkie przechodzą. Fuzzing 150 + 240 projektów (30 stylów, losowe opcje):
0 wyjątków, 0 naruszeń zakresu MIDI. Podsłuch GUI sprawdzony na prawdziwym `MainWindow` (offscreen). Przebieg `preroll` end-to-end (2 pliki WAV) działa.

## Poza tą paczką (pozycje 10–17 z przeglądu)

Kompletność presetów / `GenOptions`, SIGHUP + `--preset`, utwardzenie config/Icecast, diagnostyka `Meta`, rozbicie `generate()`,
martwy kod w generator.py, `timeout` dla dsrender, aktualizacja README (32 wtyczki).

## Rytmy taneczne (dance_rhythm.py) — opcjonalne

`generate(dance=True, dance_strength=0.7)` (domyślnie wyłączone).

Dwa etapy, w tej kolejności:
1. **Kroki** (klimat, liczone raz na projekt, zapis w `proj["climate"]["dance"]`):
   siatka wag 16 kroków (albo 2 takty × 16 — clave) wyprowadzona z tego, co styl już gra w perkusji
   (pule stopy, werbel, ghost, tryb hatu), zmieszana z nazwanymi krokami tanecznymi pasującymi do stylu
   (offbeat house, 3-3-2 / tresillo, son clave, dembow, 2-step DnB, half-time, shuffle, bossa, funk 16, trance gate…).
   Dzięki temu melodia „tańczy” w tej samej siatce, w której gra stopa i werbel.
2. **Ekspresja** (vibe): z siatki wag + vibe (rodzina klimatu, mood, energia, gęstość, przewidywalność)
   liczone są: akcenty, długość nut (staccato ↔ legato), synkopa, antycypacje („pchnięcie” o 1/16 przed mocną dobą),
   cichy ghost, rzadkość (pauzy), lekki laid-back.

Stosowane tylko tam gdzie ma sens: partie melodyczne rytmiczne (pluck/stab/piano/… — nie pady/drony/sustained/mowa),
tylko w sekcjach gdzie rytm jest istotny (drop 100 %, intro/outro 70 %, break 50 %, build nie),
tylko w taktach z nutami krótszymi niż 2 ćwierćnuty i tylko gdy projekt ma perkusję.
Nigdy nie opróżnia taktu (≥ połowa nut), nie nakłada nut tej samej ścieżki, nie zmienia wysokości
(poza cichymi ghostami powtarzającymi poprzednią). Deterministyczne (seed projektu).

Raport: `proj["dance"] = {"on", "strength", "cells", "vibe", "stats"}`.
