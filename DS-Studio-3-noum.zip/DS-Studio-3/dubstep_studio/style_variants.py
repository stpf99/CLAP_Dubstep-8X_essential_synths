"""style_variants.py — „gramatyka gatunku": nieprzewidywalność w granicach stylu.

Podstawowe style (nie albumy „sp:") miały po jednym–kilku wzorach, wybieranych raz na sekcję: po dwóch utworach było wiadomo, co zagra stopa, werbel i hat.
Tu każdy styl dostaje:
  • NIEZMIENNIKI (inv) — to, bez czego gatunek przestaje być sobą (four-on-the-floor, werbel na 4 i 12 w DnB, half-time na 8 w dubstepie…). Nigdy nie są łamane.
  • DOZWOLONE WARIANTY — dodatkowe wzory stopy, alternatywne układy werbla, tryby hatu, wzory basu, progresje, komping, zakres tempa,
  • EMBELISHMENTY — małe, prawdopodobieństwowe dodatki w taktach (pickupy stopy, ghost-snare, nuty hatu) w miejscach, gdzie gatunek je dopuszcza (koniec frazy).

Siła: parametr `variety` 0…1 (projekt["variety"]). 0 = dokładnie dawne zachowanie (żadnej zmiany wyniku). Wszystkie losowania używają własnych, niezależnych strumieni
(seed projektu „vseed" + tag), więc nie przesuwają strumienia głównego generatora, a przelosowanie jednej ścieżki (reroll) nie zmienia „osobowości" projektu.
Hybrydy używają gramatyki składnika dominującego, a elementy niezgodne z ich rytmem (np. wzory stopy przy four-on-the-floor) lub z użytą biblioteką basu są pomijane. Albumy — bez zmian.
"""
from __future__ import annotations

import copy
import random

# ---------------------------------------------------------------- pomocnicze
def _g(**k):
    return k


def _where(where, B):
    i = B["i"]
    return (where == "any" or (where == "end2" and i % 2 == 1) or (where == "end4" and i % 4 == 3)
            or (where == "end8" and i % 8 == 7) or (where == "even" and i % 2 == 0))


def _wpick(r, items):
    """items = [(wartość, waga)] → wartość."""
    tot = sum(w for _, w in items)
    x = r.random() * tot
    for v, w in items:
        x -= w
        if x <= 0:
            return v
    return items[-1][0]


# ---------------------------------------------------------------- gramatyki
# kick_alts: dodatkowe wzory stopy (dodawane do puli; pierwszy wzór puli zostaje, bo korzysta z niego intro/outro). Pomijane przy four-on-the-floor.
# kick_emb / snare_emb / hat_emb: [(krok, [vel,] prawdopodobieństwo, gdzie)]  gdzie: any | even | end2 | end4 | end8
# snare_alts: [(lista kroków, waga)] — alternatywne układy werbla wybierane per sekcja (domyślny ma wagę 1).
# hat_modes: [(tryb, waga)] — dozwolone tryby hatu w dropie (per sekcja). wob_extra / growl_extra: dodatkowe wzory (jak w WOB / GROWL).
# progs_extra / comp_extra / div_extra: progresje (stopnie 0–6), komping, podziały LFO. bpm: dozwolony zakres tempa.
# inv: niezmienniki sprawdzane w testach: kick = kroki obecne w każdym takcie dropu, snare = jw.
GRAMMAR = {
    "Brostep": _g(kick_alts=[[0, 3, 10], [0, 6, 10], [0, 10, 12], [0, 7, 10, 13], [0, 10, 14]],
                  kick_emb=[(15, .10, "end4"), (13, .10, "end8"), (6, .08, "end4")],
                  snare_emb=[(15, 70, .12, "end4"), (7, 62, .08, "end8")],
                  hat_modes=[("16", 1.0), ("8", .6)],
                  wob_extra=[[(0, "r", 4), (4, "r", 2), (6, "o", 2), (8, "r", 8)],
                             [(0, "r", 2), (2, "o", 2), (4, "r", 2), (6, "f", 2), (8, "r", 6), (14, "t", 2)],
                             [(0, "r", 8), (8, "o", 4), (12, "t", 2), (14, "r", 2)],
                             [(0, "r", 3), (3, "o", 1), (4, "r", 4), (8, "f", 4), (12, "r", 4)]],
                  growl_extra=[[(8, "r", 2), (10, "f", 2), (12, "o", 2), (14, "t", 2)]],
                  div_extra=[6], bpm=(138, 144), inv=dict(kick=[0], snare=[8])),
    "Riddim": _g(kick_alts=[[0, 7], [0, 6], [0, 11]],
                 kick_emb=[(10, .20, "end4")], snare_emb=[(14, 60, .10, "end4")],
                 hat_modes=[("8", 1.0), ("off", .5)],
                 wob_extra=[[(0, "r", 2), (4, "r", 2), (8, "r", 2), (12, "r", 2)],
                            [(0, "r", 3), (3, "r", 1), (6, "r", 3), (9, "o", 1), (10, "r", 3)],
                            [(0, "r", 2), (2, "r", 1), (4, "r", 2), (8, "f", 2), (12, "r", 3)]],
                 growl_extra=[[(12, "r", 1), (13, "r", 1), (14, "o", 2)]],
                 div_extra=[4, 6], bpm=(138, 142), inv=dict(kick=[0], snare=[8])),
    "Tearout": _g(kick_alts=[[0, 6, 10, 14], [0, 3, 10, 13], [0, 7, 13]],
                  kick_emb=[(15, .15, "end4"), (3, .10, "end2")],
                  snare_emb=[(14, 70, .20, "end4"), (15, 80, .20, "end4")],
                  hat_modes=[("16", 1.0), ("8", .25)],
                  wob_extra=[[(0, "r", 2), (2, "o", 2), (4, "r", 2), (6, "t", 2), (8, "r", 4), (12, "f", 2), (14, "b", 2)],
                             [(0, "r", 1), (1, "r", 1), (2, "o", 2), (4, "r", 2), (6, "f", 2), (8, "r", 2), (10, "t", 2), (12, "r", 4)],
                             [(0, "r", 4), (4, "f", 2), (6, "o", 2), (8, "r", 2), (10, "b", 2), (12, "r", 2), (14, "o", 2)]],
                  growl_extra=[[(8, "r", 2), (10, "o", 2), (12, "f", 2), (14, "b", 2)]],
                  bpm=(148, 152), inv=dict(snare=[8])),
    "Melodic": _g(kick_alts=[[0, 10, 14], [0, 6, 10], [0, 10, 13]],
                  kick_emb=[(14, .15, "end4")], snare_emb=[(15, 60, .10, "end4")],
                  hat_modes=[("8", 1.0), ("off", .5), ("16", .2)],
                  wob_extra=[[(0, "r", 8), (8, "f", 4), (12, "o", 4)], [(0, "r", 6), (6, "t", 2), (8, "r", 8)], [(0, "r", 16)]],
                  progs_extra=[[5, 3, 0, 4], [0, 4, 5, 3], [0, 2, 5, 4], [3, 0, 4, 5]],
                  bpm=(138, 142), inv=dict(snare=[8])),
    "Deep": _g(kick_alts=[[0, 6, 10], [0, 10, 13], [0, 7, 10]],
               kick_emb=[(14, .20, "end4")], snare_emb=[(7, 50, .10, "end2"), (15, 55, .10, "end4")],
               hat_modes=[("off", 1.0), ("8", .25)],
               wob_extra=[[(0, "r", 8), (8, "r", 4), (12, "f", 4)], [(0, "r", 12), (12, "o", 4)], [(0, "r", 6), (6, "o", 2), (8, "r", 8)]],
               bpm=(138, 142), inv=dict(snare=[8])),
    "Dubstep": _g(kick_alts=[[0, 10, 15], [0, 6, 10], [0, 3, 10]],
                  kick_emb=[(14, .12, "end4"), (13, .10, "end8")], snare_emb=[(15, 70, .10, "end4")],
                  hat_modes=[("8", 1.0), ("16", .5)],
                  wob_extra=[[(0, "r", 8), (8, "o", 4), (12, "f", 4)], [(0, "r", 4), (4, "r", 2), (6, "t", 2), (8, "r", 8)],
                             [(0, "r", 2), (2, "o", 2), (4, "f", 4), (8, "r", 4), (12, "t", 4)]],
                  growl_extra=[[(8, "r", 3), (11, "o", 1), (12, "f", 2), (14, "r", 2)]],
                  bpm=(138, 142), inv=dict(kick=[0], snare=[8])),
    "Drumstep": _g(kick_alts=[[0, 10, 11], [0, 2, 10], [0, 7, 10], [0, 6, 10]],
                   kick_emb=[(15, .10, "end4"), (7, .10, "end2")],
                   snare_emb=[(7, 48, .20, "any"), (15, 52, .20, "end2"), (9, 46, .10, "any")],
                   hat_modes=[("16", 1.0), ("8", .4)],
                   wob_extra=[[(0, "r", 4), (4, "o", 4), (8, "f", 4), (12, "r", 4)],
                              [(0, "r", 2), (2, "o", 2), (4, "r", 4), (8, "t", 4), (12, "o", 4)]],
                   bpm=(172, 176), inv=dict(snare=[4, 12])),
    "Trap": _g(kick_alts=[[0, 3, 10], [0, 7, 11], [0, 10, 15], [0, 6, 14]],
               kick_emb=[(13, .12, "end4"), (15, .10, "end4")], snare_emb=[(14, 70, .15, "end4"), (15, 75, .15, "end4")],
               hat_modes=[("trap", 1.0), ("8", .35)],
               wob_extra=[[(0, "r", 2), (4, "r", 2), (10, "o", 2)], [(0, "r", 3), (6, "f", 2), (12, "r", 2)],
                          [(0, "r", 2), (3, "r", 1), (8, "r", 2), (11, "t", 2)]],
               bpm=(136, 148), inv=dict(snare=[8])),
    "EDM": _g(snare_emb=[(15, 70, .20, "end4"), (14, 64, .15, "end8")],
              hat_modes=[("off", 1.0), ("16", .25), ("8", .20)], hat_emb=[(15, 60, .15, "end2")],
              wob_extra=[[(0, "r", 2), (4, "r", 2), (8, "r", 2), (12, "r", 2), (14, "o", 2)], [(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "f", 2)],
                         [(0, "r", 2), (2, "o", 2), (4, "r", 2), (6, "o", 2), (8, "r", 2), (10, "o", 2), (12, "r", 2), (14, "o", 2)]],
              progs_extra=[[5, 3, 0, 4], [0, 4, 5, 3], [3, 4, 0, 5]],
              bpm=(126, 130), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Techno": _g(snare_emb=[(7, 56, .10, "any"), (15, 60, .10, "end4")],
                 hat_modes=[("offbeat", 1.0), ("16", .35), ("8", .20)], hat_emb=[(15, 50, .20, "end2"), (7, 48, .10, "any")],
                 wob_extra=[[(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "o", 2)], [(2, "r", 1), (3, "r", 1), (6, "r", 2), (10, "r", 2), (14, "r", 2)],
                            [(2, "r", 2), (6, "r", 2), (10, "r", 2), (11, "b", 1), (14, "r", 2)]],
                 progs_extra=[[0, 0, 3, 0], [0, 0, 6, 5], [0, 5]], div_extra=[10],
                 bpm=(126, 136), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Acid Techno": _g(snare_emb=[(15, 60, .15, "end4")],
                      hat_modes=[("16", 1.0), ("offbeat", .4)], hat_emb=[(7, 46, .10, "any")],
                      wob_extra=[[(0, "r", 1), (2, "r", 1), (3, "o", 1), (4, "r", 1), (6, "b", 1), (7, "r", 1), (8, "r", 1), (10, "f", 1), (12, "r", 1), (13, "o", 1), (14, "t", 1), (15, "r", 1)],
                                 [(0, "r", 2), (2, "o", 1), (3, "r", 1), (5, "b", 1), (6, "r", 1), (8, "f", 2), (11, "o", 1), (12, "r", 1), (14, "b", 1)]],
                      progs_extra=[[0, 0, 3, 0], [0, 0, 6, 5]], bpm=(130, 140), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Hard Techno": _g(snare_emb=[(15, 70, .20, "end4")],
                      hat_modes=[("16", 1.0), ("offbeat", .3)],
                      wob_extra=[[(2, "r", 1), (3, "r", 1), (6, "r", 1), (7, "r", 1), (10, "r", 2), (14, "r", 1), (15, "o", 1)],
                                 [(2, "r", 2), (6, "r", 1), (7, "r", 1), (10, "r", 2), (14, "r", 2)]],
                      progs_extra=[[0, 0, 0, 6], [0, 5, 0, 6]], bpm=(145, 155), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "House": _g(snare_emb=[(15, 50, .12, "end2"), (7, 44, .08, "any")],
                hat_modes=[("offbeat", 1.0), ("16", .40), ("8", .25)], hat_emb=[(15, 52, .20, "end2"), (7, 46, .10, "any")],
                wob_extra=[[(0, "r", 2), (4, "o", 2), (6, "r", 2), (10, "f", 2), (12, "r", 2)], [(2, "r", 2), (5, "r", 1), (8, "r", 2), (10, "t", 2), (14, "f", 2)],
                           [(0, "r", 1), (3, "o", 1), (6, "r", 2), (8, "f", 2), (11, "r", 1), (14, "o", 2)]],
                progs_extra=[[0, 3, 4, 3], [5, 3, 0, 4], [1, 4, 0, 0]], comp_extra=[[4, 10, 14], [2, 5, 10, 13], [0, 3, 8, 11]],
                bpm=(120, 128), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Electro": _g(kick_alts=[[0, 6, 11], [0, 3, 8, 11], [0, 10, 14]],
                  snare_emb=[(7, 40, .20, "any"), (15, 44, .20, "end2"), (10, 40, .10, "any")],
                  hat_modes=[("16", 1.0), ("8", .30)],
                  wob_extra=[[(0, "r", 1), (2, "r", 1), (4, "o", 1), (7, "r", 1), (8, "r", 1), (11, "f", 1), (14, "o", 1)],
                             [(0, "r", 2), (3, "r", 1), (6, "o", 1), (8, "t", 1), (10, "r", 1), (13, "f", 1), (15, "r", 1)]],
                  progs_extra=[[0, 5, 3, 0], [0, 0, 6, 5]], bpm=(124, 132), inv=dict(kick=[0], snare=[4, 12])),
    "Techno Trax": _g(snare_emb=[(15, 60, .15, "end4")],
                      hat_modes=[("offbeat", 1.0), ("16", .30)], hat_emb=[(15, 50, .15, "end2")],
                      wob_extra=[[(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "o", 2)], [(2, "r", 2), (6, "r", 2), (10, "r", 1), (11, "o", 1), (14, "f", 2)]],
                      progs_extra=[[0, 5, 6, 2], [0, 2, 6, 5]], bpm=(134, 142), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Tunnel Trance": _g(snare_emb=[(15, 60, .20, "end4"), (14, 56, .15, "end4")],
                        hat_modes=[("offbeat", 1.0), ("16", .30)],
                        wob_extra=[[(1, "r", 1), (2, "r", 1), (3, "o", 1), (5, "r", 1), (6, "r", 1), (7, "o", 1), (9, "r", 1), (10, "r", 1), (11, "o", 1), (13, "r", 1), (14, "f", 1), (15, "o", 1)]],
                        progs_extra=[[5, 3, 0, 4], [0, 4, 5, 3]], bpm=(138, 146), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Trance": _g(snare_emb=[(15, 60, .20, "end4"), (14, 56, .15, "end4")],
                 hat_modes=[("offbeat", 1.0), ("16", .30)],
                 wob_extra=[[(2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "o", 2)], [(0, "r", 2), (2, "r", 2), (6, "r", 2), (10, "r", 2), (14, "f", 2)]],
                 progs_extra=[[5, 3, 0, 4], [0, 4, 5, 3], [5, 0, 3, 4]], bpm=(134, 142), inv=dict(kick=[0, 4, 8, 12], snare=[4, 12])),
    "Psytrance": _g(hat_modes=[("offbeat", 1.0), ("16", .30), ("8", .15)], hat_emb=[(15, 50, .20, "end2")],
                    wob_extra=[[(1, "r", 1), (2, "r", 1), (3, "o", 1), (5, "r", 1), (6, "r", 1), (7, "o", 1), (9, "r", 1), (10, "r", 1), (11, "o", 1), (13, "r", 1), (14, "o", 1), (15, "o", 1)]],
                    progs_extra=[[0, 0, 0, 1], [0, 6, 0, 1], [0, 0, 6, 5]], bpm=(142, 148), inv=dict(kick=[0, 4, 8, 12])),
    "DnB": _g(kick_alts=[[0, 10, 11], [0, 2, 10], [0, 6, 10, 14], [0, 7, 10]],
              kick_emb=[(2, .10, "end2"), (11, .12, "end2"), (15, .08, "end4")],
              snare_emb=[(9, 40, .12, "any"), (3, 36, .08, "any")],
              hat_modes=[("16", 1.0), ("8", .35)],
              wob_extra=[[(0, "r", 4), (4, "f", 4), (8, "r", 2), (10, "o", 2), (12, "t", 4)], [(0, "r", 6), (6, "o", 2), (8, "r", 3), (11, "b", 1), (12, "f", 4)],
                         [(0, "r", 2), (2, "r", 2), (4, "r", 4), (8, "o", 4), (12, "r", 4)]],
              progs_extra=[[0, 5, 3, 4], [0, 0, 5, 6]], bpm=(170, 176), inv=dict(kick=[0], snare=[4, 12])),
    "Liquid DnB": _g(kick_alts=[[0, 10, 14], [0, 6, 10], [0, 7, 10]],
                     snare_emb=[(9, 34, .10, "any"), (14, 40, .10, "end2")],
                     hat_modes=[("16", 1.0), ("8", .50)],
                     wob_extra=[[(0, "r", 6), (6, "f", 2), (8, "o", 4), (12, "t", 4)], [(0, "r", 4), (4, "t", 4), (8, "f", 4), (12, "o", 4)]],
                     progs_extra=[[0, 2, 3, 5], [5, 3, 0, 4], [0, 4, 5, 3]], bpm=(172, 176), inv=dict(kick=[0], snare=[4, 12])),
    "Neurofunk": _g(kick_alts=[[0, 10, 13], [0, 7, 10], [0, 6, 10]],
                    snare_emb=[(7, 46, .12, "any"), (15, 50, .15, "end2")],
                    hat_modes=[("16", 1.0), ("8", .30)],
                    wob_extra=[[(0, "r", 2), (2, "r", 2), (4, "b", 2), (6, "r", 2), (8, "o", 2), (10, "r", 2), (12, "f", 2), (14, "t", 2)],
                               [(0, "r", 3), (3, "r", 1), (4, "o", 4), (8, "r", 2), (10, "b", 2), (12, "r", 4)]],
                    growl_extra=[[(8, "r", 2), (10, "b", 2), (12, "o", 2), (14, "r", 2)]],
                    bpm=(172, 176), inv=dict(kick=[0], snare=[4, 12])),
    "Space Electronica": _g(kick_alts=[[0], [0, 6, 10]], hat_modes=[("offbeat", 1.0), ("8", .25), ("none", .30)],
                            wob_extra=[[(0, "r", 8), (8, "f", 8)], [(0, "r", 4), (4, "t", 4), (8, "f", 4), (12, "o", 4)], [(0, "r", 16)]],
                            progs_extra=[[0, 2, 5, 3], [0, 4, 3, 5]], bpm=(100, 114)),
    "Berlin School": _g(kick_alts=[[0], [0, 6, 10]], hat_modes=[("offbeat", 1.0), ("8", .25), ("none", .30)],
                        wob_extra=[[(0, "r", 2), (2, "f", 2), (4, "o", 2), (6, "f", 2), (8, "r", 2), (10, "t", 2), (12, "f", 2), (14, "o", 2)],
                                   [(0, "r", 1), (1, "f", 1), (2, "o", 1), (3, "f", 1), (4, "r", 1), (5, "f", 1), (6, "o", 1), (7, "f", 1),
                                    (8, "r", 1), (9, "t", 1), (10, "f", 1), (11, "t", 1), (12, "r", 1), (13, "f", 1), (14, "o", 1), (15, "f", 1)]],
                        progs_extra=[[0, 3, 5, 4], [0, 2, 3, 5]], bpm=(112, 124)),
    "Baroque": _g(progs_extra=[[0, 5, 1, 4], [0, 2, 3, 4], [1, 4, 0, 5]], bpm=(100, 116)),
    "Romantic": _g(progs_extra=[[0, 2, 3, 4], [5, 1, 4, 0], [0, 3, 5, 4]], bpm=(66, 80)),
    "Minimal Classical": _g(progs_extra=[[0, 5, 3, 0], [0, 2, 3, 5]], bpm=(108, 124)),
    "Jazz": _g(kick_alts=[[0, 10, 14], [0, 8, 14]],
               wob_extra=[[(0, "r", 2), (3, "r", 1), (6, "o", 1), (8, "f", 2), (11, "t", 1), (14, "r", 2)], [(0, "r", 1), (2, "t", 1), (4, "f", 1), (6, "b", 1), (8, "r", 2), (12, "f", 2)]],
               progs_extra=[[1, 4, 0, 3], [0, 2, 1, 4], [3, 4, 2, 5]], comp_extra=[[0, 8], [3, 6, 10], [2, 12]], bpm=(116, 132)),
    "Jazz Rock": _g(kick_alts=[[0, 10, 14], [0, 6, 11]],
                    snare_emb=[(7, 46, .15, "any"), (15, 52, .15, "end2")],
                    hat_modes=[("16", 1.0), ("8", .40)],
                    wob_extra=[[(0, "r", 2), (3, "r", 1), (6, "o", 1), (8, "f", 2), (11, "t", 1), (14, "r", 2)], [(0, "r", 1), (2, "t", 1), (4, "f", 1), (6, "b", 1), (8, "r", 2), (12, "f", 2)]],
                    progs_extra=[[0, 2, 3, 4], [0, 3, 5, 4]], comp_extra=[[0, 6], [2, 8, 12]], bpm=(104, 120), inv=dict(snare=[4, 12])),
    "Experimental": _g(kick_alts=[[0, 3, 8, 12], [2, 7, 13], [0, 9, 11]],
                       snare_alts=[([5, 12], .6), ([7, 14], .6), ([4, 11], .5)],
                       snare_emb=[(3, 40, .15, "any"), (10, 44, .15, "any")],
                       hat_modes=[("16", 1.0), ("8", .5), ("trap", .3), ("off", .2)],
                       progs_extra=[[0, 3, 1, 6], [0, 4, 1, 5], [0, 2, 6, 3]], bpm=(100, 134)),
    "Raw Synthesis": _g(kick_alts=[[0, 10], [0, 3, 8]],
                        snare_alts=[([4], .4), ([4, 12], .4)],
                        hat_modes=[("16", 1.0), ("8", .5), ("offbeat", .4)],
                        wob_extra=[[(0, "r", 2), (4, "r", 2), (8, "o", 2), (12, "f", 2)]],
                        progs_extra=[[0, 5], [0, 3, 4, 0]], bpm=(118, 134)),
}


# ---------------------------------------------------------------- dobór gramatyki
def dominant_style(style, cfg):
    """Nazwa stylu, którego gramatyka obowiązuje: sam styl albo składnik dominujący hybrydy (tylko podstawowe style z GRAMMAR; albumy i nieznane → None)."""
    name = str(style)
    if name in GRAMMAR:
        return name
    parts = (cfg or {}).get("parts")
    if parts:
        dom = max(parts, key=lambda n: parts[n])
        if dom in GRAMMAR:
            return dom
    return None


def grammar_for(style, cfg):
    dom = dominant_style(style, cfg)
    return GRAMMAR[dom] if dom else None


def varied(style, cfg, variety, vseed):
    """Zwraca KOPIĘ cfg z rozszerzonymi pulami (albo cfg bez zmian przy variety = 0 / braku gramatyki). Czysta funkcja (style, variety, vseed)."""
    v = max(0.0, min(1.0, float(variety or 0.0)))
    if v <= 0.0 or cfg.get("_var") is not None:
        return cfg
    g = grammar_for(style, cfg)
    if not g:
        return cfg
    from . import generator as G
    r = random.Random(f"var:{style}:{vseed}")
    out = dict(cfg)
    out["_var"], out["_vseed"], out["_g"] = v, vseed, g
    ff = bool(cfg.get("fourfloor"))
    is_hyb = bool(cfg.get("parts"))

    def sample(lst):
        n = max(1, int(round(len(lst) * (0.3 + 0.7 * v)))) if lst else 0
        return r.sample(lst, min(n, len(lst)))

    if g.get("kick_alts") and not ff:
        out["kick"] = [list(p) for p in cfg["kick"]] + [list(p) for p in sample(g["kick_alts"]) if list(p) not in cfg["kick"]]
    own = G.STYLES[dominant_style(style, cfg)]                      # biblioteki basu rozszerzamy tylko, gdy cfg faktycznie używa bibliotek stylu dominującego
    if g.get("wob_extra") and cfg.get("wob") == own.get("wob"):
        out["wob_lib"] = list(G.WOB.get(cfg["wob"], [])) + sample(g["wob_extra"])
    if g.get("growl_extra") and cfg.get("growl") == own.get("growl") and G.GROWL.get(cfg.get("growl")):
        out["growl_lib"] = list(G.GROWL[cfg["growl"]]) + sample(g["growl_extra"])
    if g.get("div_extra"):
        out["wob_div"] = list(cfg.get("wob_div") or []) + list(g["div_extra"])
    if g.get("progs_extra"):
        out["progs"] = [list(p) for p in (cfg.get("progs") or G.PROGS)] + [list(p) for p in sample(g["progs_extra"])]
    if g.get("comp_extra") and cfg.get("comp"):
        out["comp"] = [list(p) for p in cfg["comp"]] + [list(p) for p in sample(g["comp_extra"])]
    return out


def bpm_for(style, cfg, variety, vseed):
    """Tempo z dozwolonego zakresu gatunku (tylko gdy użytkownik nie podał BPM). None = bez zmian."""
    v = max(0.0, min(1.0, float(variety or 0.0)))
    g = grammar_for(style, cfg)
    if v <= 0.0 or not g or not g.get("bpm"):
        return None
    lo, hi = g["bpm"]
    mid = (lo + hi) / 2.0
    x = random.Random(f"var-bpm:{style}:{vseed}").uniform(-1.0, 1.0) * v
    return int(round(mid + x * (hi - lo) / 2.0))


# ---------------------------------------------------------------- hooki generatorów (czyste względem strumienia głównego)
def _on(c):
    return c.cfg.get("_var") is not None


def _rng(c, tag, k):
    return random.Random(f"{c.cfg['_vseed']}-v{tag}-{k}")


def kick_steps(c, B, b, steps):
    if not _on(c):
        return steps
    g, v = c.cfg["_g"], c.cfg["_var"]
    emb = g.get("kick_emb")
    if not emb:
        return steps
    r, steps = _rng(c, "k", b), list(steps)
    for st, p, where in emb:
        if st not in steps and _where(where, B) and r.random() < p * v * (0.5 + c.dens(B)):
            steps.append(st)
    return steps


def kick_phrase_key(c, B):
    """Klucz wyboru wzoru stopy: dawniej per sekcja, przy variety > 0 per fraza 8 taktów (drop nie gra przez 32 takty jednego i tego samego)."""
    return B["sec"]["name"] if not _on(c) else (B["sec"]["name"], B["i"] // 8)


def snare_steps(c, B, default):
    if not _on(c):
        return default
    g, v = c.cfg["_g"], c.cfg["_var"]
    alts = g.get("snare_alts")
    if not alts:
        return default
    r = random.Random(f"{c.cfg['_vseed']}-vs-{B['sec']['name']}")
    if r.random() >= v:
        return default
    return list(_wpick(r, [(tuple(default), 1.0)] + [(tuple(s), w) for s, w in alts]))


def snare_extra(c, B, b):
    if not _on(c):
        return []
    g, v = c.cfg["_g"], c.cfg["_var"]
    r, out = _rng(c, "s", b), []
    for st, vel, p, where in g.get("snare_emb", []):
        if _where(where, B) and r.random() < p * v * (0.5 + c.dens(B)):
            out.append((st, vel + r.randint(-4, 4)))
    return out


def hat_mode(c, B, default):
    if not _on(c):
        return default
    g, v = c.cfg["_g"], c.cfg["_var"]
    modes = g.get("hat_modes")
    if not modes:
        return default
    r = random.Random(f"{c.cfg['_vseed']}-vh-{B['sec']['name']}-{B['i'] // 16}")
    if r.random() >= v:
        return default
    return _wpick(r, [(m, w if m != default else max(w, 1.0)) for m, w in modes])


def hat_extra(c, B, b):
    if not _on(c):
        return []
    g, v = c.cfg["_g"], c.cfg["_var"]
    r, out = _rng(c, "h", b), []
    for st, vel, p, where in g.get("hat_emb", []):
        if _where(where, B) and r.random() < p * v * (0.5 + c.dens(B)):
            out.append((st, vel + r.randint(-4, 4)))
    return out


# ---------------------------------------------------------------- walidacja (testy)
def check_invariants(proj, style=None):
    """Zwraca listę naruszeń niezmienników gatunku w taktach dropu (predict = 1.0; fille wyciszają stopę przy predict < 1)."""
    style = style or proj["style"]
    g = GRAMMAR.get(style)
    if not g or not g.get("inv"):
        return []
    inv, bad = g["inv"], []
    for key, label in (("kick", 36), ("snare", 38)):
        need = inv.get(key)
        if not need:
            continue
        tr = next((t for t in proj["tracks"] if t["type"] == key), None)
        if not tr:
            continue
        for s in proj["sections"]:
            if s["type"] != "drop":
                continue
            for i in range(s["bars"]):
                b = s["start"] + i
                got = {int(round((n[0] - b * 4) / 0.25)) for n in tr["notes"] if b * 4 - 0.01 <= n[0] < b * 4 + 3.99 and n[2] == label}
                missing = [x for x in need if x not in got]
                if missing:
                    bad.append((key, b, missing))
    return bad
