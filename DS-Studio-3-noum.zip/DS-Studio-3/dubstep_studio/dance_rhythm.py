"""dance_rhythm.py — rytmy taneczne dla melodii („kroki stylu → ekspresja pod vibe"). Opcjonalne (generate(dance=True)).

Dwa etapy, w tej kolejności:
  1. KROKI (klimat, liczone raz na projekt, zapis w proj["climate"]["dance"]):
     siatka wag 16 kroków (albo 2 takty × 16 — clave) wyprowadzona z TEGO, co styl już gra w perkusji (pule stopy, werbel, ghost, tryb hatu),
     zmieszana z nazwanymi krokami tanecznymi pasującymi do stylu (offbeat house, 3-3-2 / tresillo, son clave, dembow, 2-step DnB, half-time, shuffle, bossa, funk 16, trance gate…).
     Dzięki temu melodia „tańczy" w tej samej siatce, w której gra stopa i werbel.
  2. EKSPRESJA (vibe): z siatki wag + vibe (rodzina klimatu, mood, energia, gęstość, przewidywalność perkusji) liczone są: akcenty, długość nut (staccato ↔ legato),
     synkopa (zostaw / przesuń słabe nuty), antycypacje („pchnięcie" o 1/16 przed mocną doby), cichy ghost, rzadkość (pauzy), lekki laid-back.

„Tam gdzie ma sens": ruszane są tylko partie melodyczne grające rytmicznie (nie pady / drony / sustained / mowa), tylko w sekcjach, gdzie rytm jest istotny
(drop 100 %, intro/outro 70 %, break 50 %, build nie), tylko w taktach z nutami krótszymi niż 2 ćwierćnuty i tylko gdy projekt ma perkusję (stopa / werbel / hat).
Nigdy nie opróżnia taktu (zostaje ≥ połowa nut), nie nakłada nut tej samej ścieżki, nie zmienia wysokości (poza cichymi ghostami powtarzającymi poprzednią).
Deterministyczne (seed projektu).
"""
from __future__ import annotations

import re

# ------------------------------------------------------------------ nazwane kroki taneczne (waga 1 = mocny akcent kroku; brak = 0)
# lista słowników = wzór 2-taktowy (clave); pojedynczy słownik = 1 takt
CELLS = {
    "offbeat":   {2: 1, 6: 1, 10: 1, 14: 1, 0: .6, 8: .5, 4: .4, 12: .4},                        # house / techno: akcent na „i"
    "pulse4":    {0: 1, 4: .85, 8: .95, 12: .85, 2: .4, 6: .4, 10: .4, 14: .4},                  # techno / hard: równe ćwierćnuty
    "gate":      {0: 1, 2: .7, 3: .6, 5: .6, 6: .8, 8: .9, 10: .7, 11: .6, 13: .6, 14: .8},      # trance
    "tresillo":  {0: 1, 6: .95, 12: .9, 3: .4, 8: .5, 10: .4, 14: .45},                          # 3-3-2 (electro, hip-hop, reggaeton)
    "dembow":    {0: 1, 3: .9, 6: .6, 8: .95, 11: .9, 14: .6, 4: .3, 12: .3},
    "twostep":   {0: 1, 6: .7, 10: .95, 3: .5, 14: .6, 4: .55, 12: .5},                          # DnB 2-step
    "halftime":  {0: 1, 8: 1, 6: .6, 10: .6, 14: .5, 3: .4, 12: .45},                            # dubstep / trap
    "shuffle":   {0: 1, 4: .8, 8: .9, 12: .8, 6: .6, 14: .6, 10: .5},                            # swing / jazz
    "funk16":    {0: 1, 3: .7, 6: .8, 7: .5, 10: .7, 12: .9, 15: .6, 8: .5},
    "son32":     [{0: 1, 6: .95, 12: .9, 3: .35, 8: .4, 10: .35}, {4: .9, 8: 1, 2: .4, 12: .4, 14: .35}],      # son clave 3-2
    "bossa":     [{0: 1, 3: .8, 6: .9, 10: .85, 13: .7}, {2: .8, 6: .9, 9: .7, 12: 1, 4: .35}],
}

# słowo kluczowe w nazwie stylu -> [(krok, waga)]
KEYWORDS = [
    ("psytrance", [("offbeat", .7), ("gate", .3)]), ("trance", [("gate", .6), ("offbeat", .4)]),
    ("hard techno", [("pulse4", .8), ("offbeat", .2)]), ("acid", [("pulse4", .5), ("funk16", .5)]), ("techno", [("pulse4", .5), ("offbeat", .5)]),
    ("house", [("offbeat", .6), ("funk16", .4)]), ("disco", [("funk16", .6), ("offbeat", .4)]), ("justice", [("funk16", .6), ("pulse4", .4)]),
    ("electro", [("tresillo", .7), ("funk16", .3)]), ("kraftwerk", [("pulse4", .6), ("tresillo", .4)]),
    ("dnb", [("twostep", .8), ("halftime", .2)]), ("neuro", [("twostep", .7), ("halftime", .3)]), ("breakbeat", [("twostep", .6), ("funk16", .4)]),
    ("jazz", [("shuffle", .5), ("bossa", .5)]), ("bossa", [("bossa", 1.0)]),
    ("reggaeton", [("dembow", 1.0)]), ("latin", [("son32", 1.0)]), ("salsa", [("son32", 1.0)]),
    ("trap", [("halftime", .6), ("tresillo", .4)]), ("drill", [("halftime", .6), ("tresillo", .4)]),
    ("dubstep", [("halftime", .7), ("tresillo", .3)]), ("brostep", [("halftime", .7), ("tresillo", .3)]), ("riddim", [("halftime", .8), ("tresillo", .2)]),
    ("tearout", [("halftime", .7), ("tresillo", .3)]), ("drumstep", [("twostep", .5), ("halftime", .5)]), ("funk", [("funk16", 1.0)]),
]

# melodie rytmiczne (reszta: pady / sustained / basy / mowa — nietykane)
DANCE_T = frozenset({"pluck", "stab", "piano", "epiano", "harpsichord", "panflute", "theremin", "handpan", "tongue", "marimba", "vibes", "bell",
                     "flute", "brass", "hoover", "screech", "acid", "zap"})
GHOST_T = frozenset({"pluck", "stab", "piano", "epiano", "harpsichord", "handpan", "marimba", "vibes", "acid"})
SEC_MUL = {"drop": 1.0, "intro": 0.7, "outro": 0.7, "break": 0.5}

# vibe wg rodziny klimatu: accent (kontrast głośności), len (mnożnik długości), ghost, sync (zostaw synkopy), sparse (pauzy), anticip (pchnięcie 1/16), lay (laid-back, 1/16·0.x)
VIBE = {
    "hard":    dict(accent=.90, len=.55, ghost=.05, sync=.30, sparse=.20, anticip=.20, lay=0.0),
    "dark":    dict(accent=.70, len=.80, ghost=.10, sync=.30, sparse=.35, anticip=.15, lay=0.0),
    "bright":  dict(accent=.60, len=.90, ghost=.15, sync=.60, sparse=.10, anticip=.35, lay=0.0),
    "organic": dict(accent=.50, len=1.00, ghost=.30, sync=.55, sparse=.15, anticip=.30, lay=.15),
    "acid":    dict(accent=.80, len=.60, ghost=.25, sync=.70, sparse=.10, anticip=.30, lay=0.0),
    "space":   dict(accent=.30, len=1.40, ghost=.00, sync=.20, sparse=.25, anticip=.10, lay=.05),
}


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


# ------------------------------------------------------------------ 1. KROKI
def _cells_for(style: str):
    """-> [(nazwa kroku, waga)] — hybryda „A 60% + B 40%" miesza kroki składników."""
    parts = []
    for chunk in str(style or "").split("+"):
        m = re.search(r"(\d+(?:\.\d+)?)\s*%", chunk)
        parts.append((chunk.lower(), float(m.group(1)) / 100.0 if m else 1.0))
    out = {}
    for chunk, pw in parts:
        for kw, cells in KEYWORDS:
            if kw in chunk:
                for n, w in cells:
                    out[n] = out.get(n, 0.0) + w * pw
                break
    return sorted(out.items(), key=lambda kv: -kv[1])


def _drum_grid(cfg):
    """Siatka z tego, co styl faktycznie gra: stopa (pule), werbel, ghost, hat."""
    g = {}
    pools = cfg.get("kick") or [[0, 4, 8, 12]]
    n = max(1, len(pools))
    for pool in pools:
        for s in pool:
            g[int(s)] = g.get(int(s), 0.0) + 1.0 / n            # krok obecny w każdej puli = 1.0
    for s in (cfg.get("snare") if cfg.get("snare") is not None else [8]):
        g[int(s)] = max(g.get(int(s), 0.0), 0.8)
    for s, _v in (cfg.get("ghost") or []):
        g[int(s)] = max(g.get(int(s), 0.0), 0.4)
    if cfg.get("hat") in ("offbeat", "8", "trap"):
        for s in (2, 6, 10, 14):
            g[s] = max(g.get(s, 0.0), 0.5)
    elif cfg.get("hat") == "16":
        for s in range(0, 16, 2):
            g[s] = max(g.get(s, 0.0), 0.3)
    return {k: min(1.0, v) for k, v in g.items()}


def build_steps(style, cfg, rng, bpm=130):
    """Kroki stylu: -> {"cells": [(nazwa, waga)], "grid": [dict(step→waga) na każdy takt wzoru], "swing": bool}."""
    cells = _cells_for(style)
    if not cells:                                               # style artystów / eksperymentalne: wyprowadź z perkusji
        if cfg.get("fourfloor"):
            cells = [("offbeat", .6), ("pulse4", .4)]
        elif cfg.get("hat") == "trap":
            cells = [("halftime", .6), ("tresillo", .4)]
        else:
            cells = [("halftime", .5), ("funk16", .5)] if bpm <= 150 else [("twostep", .6), ("funk16", .4)]
    drum = _drum_grid(cfg)
    bars = 1
    named = [(CELLS[n], w) for n, w in cells if n in CELLS]
    if any(isinstance(c, list) for c, _ in named):
        bars = 2
    grid = []
    tot = sum(w for _, w in named) or 1.0
    for b in range(bars):
        g = {}
        for c, w in named:
            cb = c[b % len(c)] if isinstance(c, list) else c
            for s, v in cb.items():
                g[s] = g.get(s, 0.0) + v * w / tot
        for s in set(g) | set(drum):
            g[s] = round(_clamp(0.45 * drum.get(s, 0.0) + 0.55 * g.get(s, 0.0)), 3)   # perkusja stylu + taniec
        grid.append({s: v for s, v in g.items() if v > 0.05})
    return {"cells": [(n, round(w / tot, 2)) for n, w in cells[:3]], "grid": grid,
            "swing": any(n in ("shuffle", "bossa") for n, _ in cells)}


# ------------------------------------------------------------------ 2. EKSPRESJA
def vibe_of(proj, climate):
    fam = (climate or {}).get("family") or "bright"
    v = dict(VIBE.get(fam, VIBE["bright"]))
    mood = float(proj.get("mood") or 0.0)                       # −1 mroczny … +1 optymistyczny
    en, de = float(proj.get("energy") or 0.7), float(proj.get("density") or 0.6)
    pr = float(proj.get("predict", 1.0))
    v["sync"] = _clamp(v["sync"] + 0.25 * mood + 0.2 * (de - 0.6))
    v["anticip"] = _clamp(v["anticip"] + 0.2 * mood + 0.15 * (1 - pr))
    v["accent"] = _clamp(v["accent"] + 0.2 * (en - 0.6) - 0.1 * mood)
    v["sparse"] = _clamp(v["sparse"] - 0.25 * (de - 0.6) - 0.1 * mood)
    v["len"] = max(0.4, v["len"] * (1 + 0.2 * mood))
    v["family"] = fam
    return {k: (round(x, 3) if isinstance(x, float) else x) for k, x in v.items()}


def _w(grid, bar_in_sec, step):
    return grid[bar_in_sec % len(grid)].get(step, 0.0)


def apply(proj, strength, rng):
    """Przetwarza partie melodyczne wg kroków stylu i vibe. Zwraca raport (też w proj["dance"])."""
    from .generator import STYLES, SUSTAINED                    # import leniwy (cykl)
    style = proj.get("style") or "Brostep"
    cfg = STYLES[style]
    S = _clamp(float(strength))
    types = {t["type"] for t in proj["tracks"]}
    if not isinstance(proj.get("climate"), dict):
        proj["climate"] = {}
    cl = proj["climate"]
    if not (types & {"kick", "snare", "hat", "clap"}):          # brak perkusji → nie ma do czego tańczyć
        proj["dance"] = {"on": False, "reason": "brak perkusji"}
        return proj["dance"]
    steps = cl.get("dance") or build_steps(style, cfg, rng, bpm=proj.get("bpm") or 130)   # klimat: raz, zamrożone
    cl["dance"] = steps
    vibe = vibe_of(proj, cl)
    grid = steps["grid"]
    stats = {"moved": 0, "dropped": 0, "pushed": 0, "ghosts": 0, "tracks": 0}

    bar_sec = {}
    for s in proj["sections"]:
        for i in range(s["bars"]):
            bar_sec[s["start"] + i] = (s["type"], i)

    for tr in proj["tracks"]:
        tt = tr["type"]
        if tt not in DANCE_T or tt in SUSTAINED or not tr.get("notes"):
            continue
        notes = sorted([list(n) for n in tr["notes"]], key=lambda n: n[0])
        if len({round(n[0], 3) for n in notes}) < 0.9 * len(notes):    # akordy w jednej ścieżce — przesuwanie pojedynczych nut rozbiłoby harmonię
            continue
        bars = {}
        for n in notes:
            bars.setdefault(int(n[0] // 4), []).append(n)
        out, touched = [], False
        for b, ns in sorted(bars.items()):
            sec = bar_sec.get(b)
            mul = SEC_MUL.get(sec[0], 0.0) if sec else 0.0
            durs = sorted(n[1] for n in ns)
            if mul == 0.0 or durs[len(durs) // 2] >= 2.0:       # build / pady-w-melodii (długie nuty) — bez zmian
                out += ns
                continue
            s_ = S * mul
            bi = sec[1]
            occ = {int(round((n[0] - 4 * b) * 4)) for n in ns}
            keep, dropped = [], 0
            minkeep = max(1, -(-3 * len(ns) // 4))          # pauzy: najwyżej ~25 % nut taktu
            for n in ns:
                st = int(round((n[0] - 4 * b) * 4))
                w = _w(grid, bi, st)
                if n[1] >= 2.0 or w >= 0.5:                      # mocny krok lub długa nuta: zostaje
                    keep.append(n); continue
                if rng.random() < s_ * (1 - 0.4 * vibe["sync"]) * (0.4 + 0.6 * (1 - w)):          # słaba nuta → najbliższy mocny krok
                    cand = [c for c in (st - 2, st - 1, st + 1, st + 2) if 0 <= c < 16 and c not in occ and _w(grid, bi, c) >= 0.5]
                    if cand:
                        c = min(cand, key=lambda x: (abs(x - st), x > st))
                        occ.discard(st); occ.add(c)
                        n[0] = round(4 * b + c * 0.25 + (n[0] - (4 * b + st * 0.25)), 4)
                        stats["moved"] += 1; keep.append(n); continue
                if rng.random() < s_ * vibe["sparse"] * (1 - w) * 0.5 and len(ns) - dropped > minkeep:   # pauza
                    occ.discard(st); stats["dropped"] += 1; dropped += 1; continue
                keep.append(n)
            for n in keep:                                       # antycypacja: pchnięcie mocnej doby o 1/16 do tyłu
                st = int(round((n[0] - 4 * b) * 4))
                if st % 4 == 0 and st > 0 and (st - 1) not in occ and n[1] < 2.0 and rng.random() < s_ * vibe["anticip"] * 0.5:
                    occ.discard(st); occ.add(st - 1); n[0] = round(n[0] - 0.25, 4); stats["pushed"] += 1
            if tt in GHOST_T and len(keep) <= 6 and keep:        # ghosty: ta sama wysokość co poprzednia nuta, cicho, na słabych krokach siatki
                kk = sorted(keep, key=lambda x: x[0])
                for st in range(16):
                    w = _w(grid, bi, st)
                    if 0.25 <= w < 0.6 and st not in occ and rng.random() < s_ * vibe["ghost"] * 0.35:
                        t0 = round(4 * b + st * 0.25, 4)
                        prev = [x for x in kk if x[0] < t0]
                        if prev:
                            keep.append([t0, 0.1, prev[-1][2], 38 + rng.randint(0, 14)]); occ.add(st); stats["ghosts"] += 1
            # akcent głośności z wagi kroku + lekkie laid-back na słabych
            for n in keep:
                st = int(round((n[0] - 4 * b) * 4))
                w = _w(grid, bi, st)
                f = 0.7 + 0.45 * w
                n[3] = int(max(1, min(127, n[3] * (1 + s_ * vibe["accent"] * (f - 1)))))
                if vibe["lay"] and st % 2 == 1:
                    n[0] = round(n[0] + s_ * vibe["lay"] * 0.08, 4)
            touched = True
            out += keep
        if not touched:
            continue
        out.sort(key=lambda n: (n[0], n[2]))
        # jednogłos: bez nakładania, długość wg vibe (staccato ↔ legato) tylko dla krótkich nut
        for i, n in enumerate(out):
            nxt = out[i + 1][0] if i + 1 < len(out) else None
            if n[1] < 2.0:
                sec = bar_sec.get(int(n[0] // 4))
                mul = SEC_MUL.get(sec[0], 0.0) if sec else 0.0
                n[1] = round(max(0.05, n[1] * (1 + S * mul * (vibe["len"] - 1))), 4)
            if nxt is not None and n[0] + n[1] > nxt - 0.02:
                n[1] = round(max(0.05, nxt - n[0] - 0.02), 4)
        final = out
        tr["notes"] = final
        stats["tracks"] += 1
    rep = {"on": True, "strength": round(S, 2), "cells": steps["cells"], "vibe": vibe, "stats": stats}
    proj["dance"] = rep
    return rep
