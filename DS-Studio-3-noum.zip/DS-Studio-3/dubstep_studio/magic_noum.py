"""magic_noum.py — tryb „poszukiwania świętego Graala”.

Filozofia: generacja jak wyprawa po złoto / grzyby — nie jedna losowa mapa,
tylko kilka prób, wybór tego co odstaje na plus, przetasowanie reszty
aż wszystko spina się ze założeniami gatunku / presetu / klimatu.

Przepływ (domyślnie do 4 przebiegów domknięcia):

  1) PASS UKŁADU
     N kandydatów (różne seed) z tym samym stylem, energią, klimatem.
  2) OCENA SYMBOLICZNA (bez renderu)
     score całości + score per ścieżka (zakresy, parametry, rola, gęstość).
  3) ZŁOTO
     bazą zostaje najlepszy kandydat; ścieżki które u innych kandydatów
     wypadły wyraźnie lepiej mogą zostać „przeszczepione” (typ+params+notes
     przy tej samej roli), reszta słabych — reroll pod klimat.
  4) DOMKNIĘCIE (1…max_passes)
     structure_affinity → critical_correct → musicality_reviewer (symbolic)
     aż stabilizacja albo limit przebiegów.

Bez raportu rozbudowanego w GUI — tylko proj["magic_noum"] z krótkim śladem
(ile kandydatów, który wygrał, ile przeszczepów, ile przebiegów).
"""
from __future__ import annotations

import copy
import random
from typing import Any, Callable

from . import core
from .core import fold_key, DEFAULT_GAIN, TARGET_REL

# role zgrubne do porównań między kandydatami
_BASS = {"sub", "wobble", "reese", "neuro", "fmbass", "hollow", "growl", "bass808", "upright"}
_DRUM = {"kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker", "openhat", "ride", "cowbell", "conga"}
_LEAD = {"screech", "supersaw", "pluck", "stab", "theremin", "panflute", "vox", "handpan", "tongue",
         "zap", "hoover", "acid", "epiano", "harpsichord", "flute", "brass", "bell", "vibes", "marimba", "piano"}
_PAD = {"pad", "drone", "choir", "strings", "cello", "organ"}
_FX = {"riser", "boom", "glitch", "speak"}


def _role(tt: str) -> str:
    if tt in _BASS:
        return "bass"
    if tt in _DRUM:
        return "drums"
    if tt in _LEAD:
        return "lead"
    if tt in _PAD:
        return "pad"
    if tt in _FX:
        return "fx"
    return "other"


# ---------------------------------------------------------------------------
# Scoring symboliczny (bez audio) — wyższe = lepiej
# ---------------------------------------------------------------------------
def _param_fit(tr: dict) -> float:
    """0..1 — ile parametrów leży w bezpiecznych oknach musicality_reviewer."""
    try:
        from .musicality_reviewer import PARAM_WINDOWS
    except Exception:
        return 0.7
    params = tr.get("params") or {}
    if not params:
        return 0.55
    ok = n = 0
    for name, (lo, hi) in PARAM_WINDOWS.items():
        if name not in params:
            continue
        n += 1
        try:
            v = float(params[name])
        except (TypeError, ValueError):
            continue
        if lo <= v <= hi:
            ok += 1
        else:
            # odległość od okna
            mid = 0.5 * (lo + hi)
            dist = abs(v - mid) / max(0.15, hi - lo + 0.2)
            ok += max(0.0, 1.0 - dist)
    return ok / n if n else 0.6


def _range_fit(tr: dict) -> float:
    try:
        from .musicality_reviewer import NOTE_RANGES
    except Exception:
        NOTE_RANGES = {}
    notes = tr.get("notes") or []
    if not notes:
        return 0.5
    tt = tr.get("type") or ""
    lo, hi = NOTE_RANGES.get(tt, (36, 84))
    good = 0
    for n in notes:
        k = fold_key(int(n[2]))
        if lo <= k <= hi:
            good += 1
        elif lo - 12 <= k <= hi + 12:
            good += 0.45
    return good / len(notes)


def _gain_fit(tr: dict) -> float:
    tt = tr.get("type") or ""
    tgt = TARGET_REL.get(tt, DEFAULT_GAIN.get(tt, 0.7))
    g = float(tr.get("gain", tgt))
    if tgt <= 0:
        return 0.5
    ratio = g / tgt
    if 0.7 <= ratio <= 1.25:
        return 1.0
    if 0.5 <= ratio <= 1.5:
        return 0.65
    return 0.3


def score_track(tr: dict) -> float:
    """Lokalny score ścieżki 0..1."""
    if tr.get("mute"):
        return 0.2
    r = _range_fit(tr)
    p = _param_fit(tr)
    g = _gain_fit(tr)
    notes = tr.get("notes") or []
    density = min(1.0, len(notes) / 48.0) if notes else 0.0
    # puste ścieżki nie-drum karane
    tt = tr.get("type") or ""
    empty_pen = 0.0
    if not notes and tt not in ("riser", "boom"):
        empty_pen = 0.35
    return max(0.0, min(1.0, 0.35 * r + 0.35 * p + 0.15 * g + 0.15 * min(1.0, 0.3 + density) - empty_pen))


def score_project(proj: dict) -> float:
    """Całościowy score 0..1 (symbolic)."""
    tracks = [t for t in (proj.get("tracks") or []) if not t.get("mute")]
    if not tracks:
        return 0.0
    ts = [score_track(t) for t in tracks]
    mean = sum(ts) / len(ts)
    # kara za brak ról kluczowych
    roles = {_role(t.get("type") or "") for t in tracks}
    role_bonus = 0.0
    if "drums" in roles:
        role_bonus += 0.06
    if "bass" in roles:
        role_bonus += 0.08
    if "lead" in roles or "pad" in roles:
        role_bonus += 0.05
    # density/energy vs klimat
    fam = ((proj.get("climate") or {}).get("family") or "default").lower()
    dens = float(proj.get("density") or 0.5)
    ener = float(proj.get("energy") or 0.5)
    caps = {
        "dark": (0.62, 0.65), "space": (0.55, 0.55), "organic": (0.58, 0.60),
        "bright": (0.72, 0.75), "acid": (0.70, 0.78), "hard": (0.85, 0.92),
    }.get(fam, (0.70, 0.75))
    cap_pen = 0.0
    if dens > caps[0] + 0.08:
        cap_pen += 0.08
    if ener > caps[1] + 0.08:
        cap_pen += 0.06
    # wariancja — zbyt nierówne ścieżki = mniej spójne
    if len(ts) > 1:
        var = sum((x - mean) ** 2 for x in ts) / len(ts)
        var_pen = min(0.12, var * 0.5)
    else:
        var_pen = 0.0
    return max(0.0, min(1.0, mean + role_bonus - cap_pen - var_pen))


# ---------------------------------------------------------------------------
# Przeszczepy i przetasowania
# ---------------------------------------------------------------------------
def _best_track_by_role(candidates: list[tuple[float, dict]], role: str) -> dict | None:
    """Ścieżka o danym role z najwyższym lokalnym score wśród wszystkich kandydatów."""
    best_s, best_tr = -1.0, None
    for _, proj in candidates:
        for tr in proj.get("tracks") or []:
            if _role(tr.get("type") or "") != role:
                continue
            if tr.get("lock_notes") or tr.get("lock_sound"):
                continue
            s = score_track(tr)
            if s > best_s:
                best_s, best_tr = s, tr
    return copy.deepcopy(best_tr) if best_tr is not None else None


def _graft_standouts(base: dict, candidates: list[tuple[float, dict]],
                     margin: float = 0.12, rng: random.Random | None = None) -> int:
    """Jeśli u innego kandydata ścieżka tej samej roli ma score wyraźnie wyższy — przeszczep.

    Zwraca liczbę przeszczepów.
    """
    rng = rng or random.Random(0)
    grafts = 0
    by_role: dict[str, list[dict]] = {}
    for tr in base.get("tracks") or []:
        r = _role(tr.get("type") or "")
        by_role.setdefault(r, []).append(tr)

    for role, tracks in by_role.items():
        if role in ("other",):
            continue
        donor = _best_track_by_role(candidates, role)
        if donor is None:
            continue
        donor_s = score_track(donor)
        # znajdź najsłabszą w bazie w tej roli
        weak = min(tracks, key=score_track)
        if weak.get("lock_notes") or weak.get("lock_sound"):
            continue
        weak_s = score_track(weak)
        if donor_s < weak_s + margin:
            continue
        # nie przeszczepiaj identycznego typu+seed-ish bez sensu
        if donor.get("type") == weak.get("type") and abs(donor_s - weak_s) < margin * 0.5:
            continue
        # przeszczep: notes + params + type (plugin)
        old_name = weak.get("name")
        weak["type"] = donor["type"]
        if hasattr(core, "PLUGIN_ID") and donor["type"] in getattr(core, "PLUGIN_ID", {}):
            weak["plugin"] = core.PLUGIN_ID[donor["type"]]
        if not weak.get("lock_notes"):
            weak["notes"] = copy.deepcopy(donor.get("notes") or [])
        if not weak.get("lock_sound"):
            weak["params"] = copy.deepcopy(donor.get("params") or {})
            weak["auto"] = copy.deepcopy(donor.get("auto") or {})
        if not weak.get("lock_gain"):
            weak["gain"] = float(donor.get("gain", weak.get("gain", 0.7)))
        weak["name"] = old_name  # zachowaj slot w projekcie
        grafts += 1
    return grafts


def _reroll_weak(base: dict, threshold: float = 0.45, rng: random.Random | None = None) -> int:
    """Słabe ścieżki (score < threshold): przelosuj wzór + brzmienie pod styl projektu."""
    from . import generator as G
    rng = rng or random.Random(int(base.get("seed") or 0) + 333)
    style = base.get("style") or "Brostep"
    cfg = G.STYLES.get(style) or next(iter(G.STYLES.values()))
    n = 0
    for tr in base.get("tracks") or []:
        if tr.get("lock_notes") and tr.get("lock_sound"):
            continue
        if score_track(tr) >= threshold:
            continue
        try:
            if not tr.get("lock_notes"):
                c = G.Ctx(base, cfg)
                gen = G.GEN.get(tr.get("type"))
                if gen:
                    tr["notes"] = []
                    gen(c, tr)
                    G.mutate_track(base, cfg, tr, random.Random(rng.random()))
            if not tr.get("lock_sound"):
                G.randomize_sound(base, tr, random.Random(rng.random()), use_windows=True)
            n += 1
        except Exception:
            continue
    return n


# ---------------------------------------------------------------------------
# Domknięcie wieloprzebiegowe
# ---------------------------------------------------------------------------
def _closure_pass(proj: dict, rng: random.Random, pass_i: int,
                  do_critical: bool = True) -> None:
    """Jeden przebieg: affinity → critical → musicality (symbolic)."""
    try:
        from . import generator as G
        G.apply_structure_affinity(
            proj,
            passes=1,
            rng=random.Random(rng.random()),
            rebuild_links=True,
        )
    except Exception:
        pass
    if do_critical:
        try:
            from . import critical_correct as CC
            cc = proj.get("critical_correct")
            if not isinstance(cc, dict):
                cc = {"on": True, "intensity": 0.55 + 0.1 * (pass_i % 2), "passes": 1}
            else:
                cc = dict(cc)
                cc["on"] = True
                cc.setdefault("intensity", 0.55)
                cc["passes"] = 1
            CC.apply_critical_correct(proj, cc, rng=random.Random(rng.random()))
        except Exception:
            pass
    try:
        from . import musicality_reviewer as MR
        MR.apply_symbolic(
            proj,
            cfg={"on": True, "mode": "symbolic", "intensity": 0.55 + 0.08 * pass_i, "max_passes": 1},
            rng=random.Random(rng.random()),
        )
    except Exception:
        pass
    try:
        from . import user_rules as UR
        UR.finalize(proj)
    except Exception:
        pass
    try:
        from . import generator as G
        G.sanitize_notes(proj)
    except Exception:
        pass


def _stable(prev: float, cur: float, eps: float = 0.012) -> bool:
    return abs(cur - prev) < eps and cur >= prev - 1e-9


# ---------------------------------------------------------------------------
# Publiczne API
# ---------------------------------------------------------------------------
DEFAULT_MAGIC = {
    "on": True,
    "candidates": 4,       # ile układów w 1. passie
    "max_passes": 4,       # domknięcie spójności
    "graft_margin": 0.12,  # o ile donor musi być lepszy
    "weak_threshold": 0.45,
    "do_critical": True,
}


def run_magic_noum(gen_fn: Callable[..., dict], gen_kw: dict,
                   cfg: dict | None = None,
                   rng: random.Random | None = None) -> dict:
    """Uruchom poszukiwanie Graala.

    gen_fn  — zwykle generator.generate
    gen_kw  — kwargs do generate (style, bpm, …); seed będzie nadpisywany per kandydat
    cfg     — DEFAULT_MAGIC + nadpisania

    Zwraca najlepszy, domknięty projekt.
    """
    c = dict(DEFAULT_MAGIC)
    if isinstance(cfg, dict):
        c.update({k: v for k, v in cfg.items() if k in DEFAULT_MAGIC or k in ("on",)})
    if not c.get("on", True):
        return gen_fn(**gen_kw)

    base_seed = int(gen_kw.get("seed") or random.randrange(1_000_000))
    rng = rng or random.Random(base_seed ^ 0x61A1C)
    n_cand = max(2, min(8, int(c.get("candidates") or 4)))
    max_passes = max(1, min(6, int(c.get("max_passes") or 4)))

    # --- 1) kandydaci ---
    candidates: list[tuple[float, dict]] = []
    kw0 = dict(gen_kw)
    # affinity w kandydatach lekki — pełne domknięcie na końcu
    kw0["structure_affinity"] = bool(kw0.get("structure_affinity", True))
    kw0["affinity_passes"] = min(2, int(kw0.get("affinity_passes") or 2))

    for i in range(n_cand):
        kw = dict(kw0)
        kw["seed"] = base_seed + i * 9973 + i
        try:
            proj = gen_fn(**kw)
        except Exception:
            continue
        s = score_project(proj)
        candidates.append((s, proj))

    if not candidates:
        # awaria — jedna zwykła generacja
        kw = dict(gen_kw)
        kw["seed"] = base_seed
        return gen_fn(**kw)

    candidates.sort(key=lambda x: x[0], reverse=True)
    best_score, base = candidates[0]
    base = copy.deepcopy(base)

    # --- 2) przeszczepy tego co odstaje na plus ---
    grafts = _graft_standouts(
        base, candidates,
        margin=float(c.get("graft_margin") or 0.12),
        rng=rng,
    )

    # --- 3) przetasowanie słabych ---
    rerolls = _reroll_weak(
        base,
        threshold=float(c.get("weak_threshold") or 0.45),
        rng=rng,
    )

    # --- 4) domknięcie wieloprzebiegowe ---
    scores = [score_project(base)]
    used = 0
    for p in range(max_passes):
        _closure_pass(base, rng, p, do_critical=bool(c.get("do_critical", True)))
        used = p + 1
        sc = score_project(base)
        scores.append(sc)
        if p > 0 and _stable(scores[-2], sc):
            break

    base["seed"] = base_seed  # kanoniczny seed sesji
    base["magic_noum"] = {
        "on": True,
        "candidates": n_cand,
        "best_initial": round(best_score, 4),
        "final_score": round(scores[-1], 4),
        "grafts": grafts,
        "rerolls": rerolls,
        "passes": used,
        "score_curve": [round(x, 4) for x in scores],
    }
    return base


def generate_magic(style="Brostep", **kw) -> dict:
    """Wygodna nakładka: generator.generate + magic_noum."""
    from . import generator as G
    cfg = kw.pop("magic", None) or kw.pop("magic_noum", None)
    # wyłącz wewnętrzne ciężkie rzeczy w kandydatach jeśli magic je domknie
    gen_kw = dict(kw)
    gen_kw.setdefault("style", style)
    return run_magic_noum(G.generate, gen_kw, cfg=cfg)
