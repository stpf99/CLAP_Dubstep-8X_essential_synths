"""Reguły użytkownika nadrzędne nad generatorem (Generator / Live / CLI — wszędzie ten sam stan).

1. MOWA (grupa speak / vox / growl) — 4 poziomy: 0 wcale · 1 min · 2 średnio · 3 max (jak przewiduje generator).
   0  = grupa pomijana w całości (też gdy dołożyłby ją aranżer, zamiana instrumentów albo tekst Speak),
   1  = najwyżej 1 ścieżka z grupy, gain ×0,55;   2 = najwyżej 2 ścieżki, gain ×0,8;   3 = bez zmian.
   Przy 1–2 zostają ścieżki wg priorytetu growl → vox → speak (growl bywa basem rdzenia stylu, speak najłatwiej wychodzi „komicznie").
2. GRUPY WTYCZEK — własne przypisanie typ → grupa (drums / bass / lead / pad / fx / acoustic).
   Zawsze: dobór instrumentów (smart, reżyser, aranżer, drzewo w GUI, role) korzysta z Twoich grup zamiast wbudowanych.
   Z checkboxem „bezwzględnie” dodatkowo PO całej generacji (role, aranżer, niuanse, zamiany…) ścieżka typu przeniesionego do bass/lead/pad
   jest składana do rejestru swojej grupy (mediana oktawami + zawinięcie skrajnych nut) i dostaje retune barwy — nic tego nie cofa.

Stan: ~/DubstepStudio/user_rules.json (albo obok ds-studio, albo $DS_USER_RULES). Zmienne: DS_VOICE_LEVEL=0..3, DS_GROUPS_ABSOLUTE=0/1.
"""
import copy
import json
import os
import random
from pathlib import Path

VOICE_TYPES = ("growl", "vox", "speak")                  # kolejność = priorytet przy poziomach 1–2
VOICE_LEVELS = {0: "Wcale", 1: "Min", 2: "Średnio", 3: "Max (jak przewiduje generator)"}
VOICE_CAP = {0: 0, 1: 1, 2: 2, 3: 10 ** 6}
VOICE_GAIN = {0: 0.0, 1: 0.55, 2: 0.8, 3: 1.0}
GROUPS = ("drums", "bass", "lead", "pad", "fx", "acoustic")
GROUP_PL = {"drums": "Perkusja", "bass": "Bas", "lead": "Lead", "pad": "Pad / tło", "fx": "FX", "acoustic": "Akustyczne"}
_GUI_GROUP = {"drums": "Perkusja", "bass": "Bas", "lead": "Synth / lead", "pad": "Synth / lead", "fx": "FX", "acoustic": "Akustyczne"}
_INST_GROUP = {"drums": "drums", "bass": "bass", "lead": "lead", "pad": "lead", "fx": "fx", "acoustic": "acoustic"}
DYN_PROFILE = {"mode": 1, "preset": 7, "amount": 1.0, "curve": 1, "detect": 0, "knee": 6.0}      # = domyślne wtyczki (Limiter 3-Band, Less Bass)
DYN_RANGE = {"mode": (0, 2), "preset": (0, 7), "amount": (0.0, 1.0), "curve": (0, 3), "detect": (0, 1), "knee": (0.0, 12.0)}
DYN_PARAM = {"mode": "Dynamics", "preset": "Dyn Preset", "amount": "Dyn Amount", "curve": "Dyn Curve", "detect": "Dyn Detect", "knee": "Dyn Knee"}
DEFAULT = {"voice_level": 3, "groups_absolute": False, "group_map": {}, "clarity": 0.6,
           "dyn": {"on": False, "default": dict(DYN_PROFILE), "groups": {}, "types": {}},
           "musicality": {
               "on": True,
               "mode": "both",          # symbolic | audio | both  (symbolic = bez renderu)
               "intensity": 0.60,
               "interval": 5.0,         # s między self-listen w tle
               "max_passes": 2,
               "audio_on_generate": False,  # True = po generate też jeden przebieg audio (wolniejszy)
               "self_listen": False,    # True = wątek tła miesza miks i koryguje na bieżąco
           }}

_state = None
_base = None
_applied_sig = None


# ------------------------------------------------------------------ stan (plik JSON + zmienne środowiskowe)
def path() -> Path:
    if os.environ.get("DS_USER_RULES"):
        return Path(os.environ["DS_USER_RULES"])
    app = Path(__file__).resolve().parent.parent / "user_rules.json"
    return app if app.exists() else Path.home() / "DubstepStudio" / "user_rules.json"


def _sanitize(d):
    out = copy.deepcopy(DEFAULT)
    try:
        out["voice_level"] = max(0, min(3, int(d.get("voice_level", 3))))
    except (TypeError, ValueError):
        pass
    out["groups_absolute"] = bool(d.get("groups_absolute", False))
    try:
        out["clarity"] = max(0.0, min(1.0, float(d.get("clarity", 0.6))))
    except (TypeError, ValueError):
        pass
    gm = d.get("group_map") or {}
    out["group_map"] = {str(t): g for t, g in gm.items() if g in GROUPS} if isinstance(gm, dict) else {}
    out["dyn"] = _sanitize_dyn(d.get("dyn"))
    out["musicality"] = _sanitize_musicality(d.get("musicality"))
    return out


def _sanitize_musicality(d):
    base = copy.deepcopy(DEFAULT["musicality"])
    if not isinstance(d, dict):
        return base
    base["on"] = bool(d.get("on", base["on"]))
    mode = str(d.get("mode", base["mode"])).lower()
    if mode not in ("symbolic", "audio", "both"):
        mode = base["mode"]
    base["mode"] = mode
    try:
        base["intensity"] = max(0.0, min(1.0, float(d.get("intensity", base["intensity"]))))
    except (TypeError, ValueError):
        pass
    try:
        base["interval"] = max(1.5, float(d.get("interval", base["interval"])))
    except (TypeError, ValueError):
        pass
    try:
        base["max_passes"] = max(1, min(4, int(d.get("max_passes", base["max_passes"]))))
    except (TypeError, ValueError):
        pass
    base["audio_on_generate"] = bool(d.get("audio_on_generate", base["audio_on_generate"]))
    base["self_listen"] = bool(d.get("self_listen", base["self_listen"]))
    return base


def _sanitize_prof(p):
    out = {}
    for k, (lo, hi) in DYN_RANGE.items():
        try:
            v = float((p or {}).get(k, DYN_PROFILE[k]))
        except (TypeError, ValueError):
            v = DYN_PROFILE[k]
        v = max(lo, min(hi, v))
        out[k] = v if k in ("amount", "knee") else int(round(v))
    return out


def _sanitize_dyn(d):
    d = d if isinstance(d, dict) else {}
    return {"on": bool(d.get("on", False)), "default": _sanitize_prof(d.get("default")),
            "groups": {g: _sanitize_prof(p) for g, p in (d.get("groups") or {}).items() if g in GROUPS and isinstance(p, dict)},
            "types": {str(t): _sanitize_prof(p) for t, p in (d.get("types") or {}).items() if isinstance(p, dict)}}


def load():
    global _state
    d = {}
    p = path()
    if p.exists():
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            d = {}
    _state = _sanitize(d)
    return _state


def get():
    """Aktualny stan (kopia) z nałożonymi zmiennymi środowiskowymi."""
    if _state is None:
        load()
    s = copy.deepcopy(_state)
    if os.environ.get("DS_VOICE_LEVEL", "").strip() in ("0", "1", "2", "3"):
        s["voice_level"] = int(os.environ["DS_VOICE_LEVEL"])
    if os.environ.get("DS_GROUPS_ABSOLUTE", "").strip() in ("0", "1"):
        s["groups_absolute"] = os.environ["DS_GROUPS_ABSOLUTE"] == "1"
    return s


def update(save=True, **kw):
    """update(voice_level=0, groups_absolute=True, group_map={...}) — zmiany działają od następnej generacji."""
    global _state
    if _state is None:
        load()
    cur = copy.deepcopy(_state)
    cur.update({k: v for k, v in kw.items() if k in DEFAULT})
    _state = _sanitize(cur)
    if save:
        try:
            p = path(); p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(_state, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
    ensure_applied()
    return get()


# ------------------------------------------------------------------ własne grupy wtyczek (nadpisanie tabel generatora / reżysera / aranżera / niuansów)
def _mods():
    from . import generator as G, core as C, director as D, arranger as A, niuanse as N, uniq as U
    return G, C, D, A, N, U


def _snapshot():
    global _base
    if _base is None:
        G, C, D, A, N, U = _mods()
        _base = dict(
            inst={k: list(v) for k, v in G.INST_GROUPS.items()}, gui={k: list(v) for k, v in C.GROUPS.items()},
            native=dict(G.NATIVE_ROLE), a_drums=set(A.DRUMS), a_bass=set(A.BASS), a_lead=set(A.LEAD), a_pad=set(A.PAD),
            d_bass=tuple(D.BASS_T), d_lead=tuple(D.LEAD_T), d_lr=dict(D.LEAD_RANGE), d_br=dict(D.BASS_RANGE),
            n_bass=frozenset(N.BASS_T), n_lead=frozenset(N.LEAD_T))
    return _base


def base_group_of(ttype):
    """Wbudowana grupa typu (przed Twoimi zmianami): drums/bass/lead/pad/fx/acoustic albo None."""
    b = _snapshot()
    for g, lst in b["inst"].items():
        if ttype in lst:
            if g == "lead" and b["native"].get(ttype) == "pad":
                return "pad"
            return g
    return None


def ensure_applied():
    """Idempotentnie nakłada group_map na tabele modułów (przywraca wbudowane, potem nakłada zmiany)."""
    global _applied_sig
    gm = get()["group_map"]
    sig = json.dumps(gm, sort_keys=True)
    if sig == _applied_sig:
        return
    b = _snapshot()
    G, C, D, A, N, U = _mods()
    G.INST_GROUPS.clear(); G.INST_GROUPS.update({k: list(v) for k, v in b["inst"].items()})
    C.GROUPS.clear(); C.GROUPS.update({k: list(v) for k, v in b["gui"].items()})
    G.NATIVE_ROLE.clear(); G.NATIVE_ROLE.update(b["native"])
    for S, base in ((A.DRUMS, b["a_drums"]), (A.BASS, b["a_bass"]), (A.LEAD, b["a_lead"]), (A.PAD, b["a_pad"])):
        S.clear(); S.update(base)
    bass_t, lead_t = list(b["d_bass"]), list(b["d_lead"])
    n_bass, n_lead = set(b["n_bass"]), set(b["n_lead"])
    D.LEAD_RANGE.clear(); D.LEAD_RANGE.update(b["d_lr"]); D.BASS_RANGE.clear(); D.BASS_RANGE.update(b["d_br"])
    amap = {"drums": A.DRUMS, "bass": A.BASS, "lead": A.LEAD, "pad": A.PAD}
    for t, g in gm.items():
        for lst in G.INST_GROUPS.values():
            while t in lst:
                lst.remove(t)
        G.INST_GROUPS.setdefault(_INST_GROUP[g], []).append(t)
        for lst in C.GROUPS.values():
            while t in lst:
                lst.remove(t)
        C.GROUPS.setdefault(_GUI_GROUP[g], []).append(t)
        if g in ("bass", "lead", "pad"):
            G.NATIVE_ROLE[t] = g
        else:
            G.NATIVE_ROLE.pop(t, None)
        for S in (A.DRUMS, A.BASS, A.LEAD, A.PAD):
            S.discard(t)
        if g in amap:
            amap[g].add(t)
        bass_t = [x for x in bass_t if x != t]; lead_t = [x for x in lead_t if x != t]
        n_bass.discard(t); n_lead.discard(t)
        if g == "bass":
            bass_t.append(t); n_bass.add(t); D.BASS_RANGE.setdefault(t, (28, 55))
        elif g == "lead":
            lead_t.append(t); n_lead.add(t); D.LEAD_RANGE.setdefault(t, (55, 80))
    D.BASS_T, D.LEAD_T = tuple(bass_t), tuple(lead_t)
    N.BASS_T, N.LEAD_T = frozenset(n_bass), frozenset(n_lead)
    U.BASS_T, U.LEAD_T = N.BASS_T, N.LEAD_T
    _applied_sig = sig


# ------------------------------------------------------------------ 1) mowa
def voice_level():
    return get()["voice_level"]


def filter_voice_types(types, level=None):
    """Lista typów (z powtórzeniami = instancje) → bez/ograniczona grupa mowy. Zachowuje kolejność reszty."""
    lv = voice_level() if level is None else level
    if lv >= 3:
        return list(types)
    cap = VOICE_CAP[lv]
    voice = [t for t in types if t in VOICE_TYPES]
    keep = sorted(voice, key=lambda t: VOICE_TYPES.index(t))[:cap]
    out = []
    for t in types:
        if t in VOICE_TYPES:
            if t in keep:
                keep.remove(t)
            else:
                continue
        out.append(t)
    return out


def _drop_tracks(proj, names):
    names = set(names)
    if not names:
        return
    proj["tracks"] = [t for t in proj["tracks"] if t["name"] not in names]
    proj["links"] = [l for l in proj.get("links", []) if l.get("dst") not in names and l.get("src") not in names]
    for t in proj["tracks"]:
        if t.get("notes_from") in names:
            t["notes_from"] = None
        if t.get("input_from") in names:
            t["input_from"] = None


def enforce_voice(proj, level=None):
    lv = voice_level() if level is None else level
    if lv >= 3:
        return {"level": lv, "removed": []}
    vt = [t for t in proj["tracks"] if t["type"] in VOICE_TYPES]
    order = sorted(vt, key=lambda t: (VOICE_TYPES.index(t["type"]), t["name"]))
    keep = {t["name"] for t in order[:VOICE_CAP[lv]]}
    drop = [t["name"] for t in vt if t["name"] not in keep]
    _drop_tracks(proj, drop)
    for t in proj["tracks"]:
        if t["name"] in keep and not t.get("_voice_gain") and not t.get("lock_gain"):
            t["gain"] = round(float(t["gain"]) * VOICE_GAIN[lv], 4); t["_voice_gain"] = True
    return {"level": lv, "removed": drop, "kept": sorted(keep)}


# ------------------------------------------------------------------ 2) grupy bezwzględnie
def _fold(notes, lo, hi, tol=7):
    out = []
    for on, dur, k, v in notes:
        while k < lo - tol:
            k += 12
        while k > hi + tol:
            k -= 12
        out.append([on, dur, max(24, min(108, int(k))), v])
    return out


def enforce_groups(proj, rng=None):
    s = get()
    gm = s["group_map"]
    if not s["groups_absolute"] or not gm:
        return []
    from . import generator as G
    rng = rng or random.Random(int(proj.get("seed", 0)) + 4242)
    rep = []
    for tr in proj["tracks"]:
        g = gm.get(tr["type"])
        if not g:
            continue
        tr["group"] = g
        if g not in ("bass", "lead", "pad") or tr.get("lock_notes") or not tr.get("notes"):
            continue
        lo, hi = G.ROLE_REG[g]
        notes, sh = G._shift_to_reg(list(tr["notes"]), lo, hi, rng)
        tr["notes"] = sorted(_fold(notes, lo, hi), key=lambda n: (n[0], n[2]))
        base = base_group_of(tr["type"])
        if base != g and not tr.get("_grp_retuned"):
            G._retune_params_for_role(tr, g, strength=0.5); tr["_grp_retuned"] = True
        tr.pop("role_plan", None)                          # zamiany ról sekcji nie obowiązują — grupa jest nadrzędna
        rep.append({"track": tr["name"], "group": g, "shift": sh})
    return rep


# ------------------------------------------------------------------ normalizacja / Dynamics: profile stosowane ZAWSZE
def dyn_on():
    return bool(get()["dyn"]["on"])


def current_group(ttype):
    """Grupa typu: Twoja (group_map) albo wbudowana; nieznane → lead."""
    return get()["group_map"].get(ttype) or base_group_of(ttype) or "lead"


def dyn_profile_for(ttype):
    """Profil dla typu: osobny dla typu > profil grupy > domyślny. None gdy profile wyłączone."""
    d = get()["dyn"]
    if not d["on"]:
        return None
    return d["types"].get(ttype) or d["groups"].get(current_group(ttype)) or d["default"]


def dyn_overlay(ttype, params, meta):
    """Nakłada profil na parametry ścieżki (ułamki 0..1 jak w t['params']). Wołane przy każdym renderze i w kluczu cache."""
    prof = dyn_profile_for(ttype)
    if prof is None:
        return params
    out = dict(params)
    for k, name in DYN_PARAM.items():
        try:
            if meta.has(ttype, name):
                out[name] = meta.eng2frac(ttype, name, prof[k])
        except Exception:
            continue
    return out


# ------------------------------------------------------------------ wejścia dla generatora
def finalize(proj):
    """Wywoływane na końcu generate() (i po reroll): mowa → grupy bezwzględnie. Zapisuje raport w proj['user_rules']."""
    ensure_applied()
    s = get()
    rep = {"voice_level": s["voice_level"], "groups_absolute": s["groups_absolute"]}
    v = enforce_voice(proj)
    if v.get("removed"):
        rep["voice_removed"] = v["removed"]
    g = enforce_groups(proj)
    if g:
        rep["groups"] = g
    proj["user_rules"] = rep
    return rep


def enforce_track(proj, tr):
    """Po rerollu jednej ścieżki: ponownie złóż ją do grupy (gdy bezwzględnie)."""
    s = get()
    g = s["group_map"].get(tr["type"])
    if not (s["groups_absolute"] and g in ("bass", "lead", "pad")) or tr.get("lock_notes") or not tr.get("notes"):
        return
    from . import generator as G
    lo, hi = G.ROLE_REG[g]
    notes, _ = G._shift_to_reg(list(tr["notes"]), lo, hi, random.Random(int(proj.get("seed", 0)) + 4243))
    tr["notes"] = sorted(_fold(notes, lo, hi), key=lambda n: (n[0], n[2]))
