"""musicality_reviewer.py — wewnętrzny recenzent / dyskryminator / aplikator.

Bez raportu w projekcie. Dwa tryby:

  symbolic  — bez renderu do WAV/MP3, wyłącznie analiza nut + parametrów + klimatu
              i cicha korekta zakresów / okien parametrów / gainów / gęstości.

  audio     — w tle miesza miks w pamięci (core.render_mix, bez zapisu pliku),
              analizuje cechami z listen.analyze_audio i miękko koryguje parametry
              oraz gainy ścieżek, żeby spektrum / dynamika / klarowność były
              muzykalne na bieżąco.

  both      — najpierw symbolic, potem (opcjonalnie) audio w tle.

Cel: każdy parametr i zakres jest wewnętrznie dyskryminowany tak, by muzykalność
była spełniona na poziomie nut, barwy, spektrum i miksu — bez subiektywnego
„pół na pół” na końcu.
"""
from __future__ import annotations

import copy
import math
import random
import threading
import time
from typing import Any, Callable

import numpy as np

from . import core
from .core import fold_key, clamp_vel, DEFAULT_GAIN, TARGET_REL

# ---------------------------------------------------------------------------
# Domyślne zakresy nut (dyskryminator) — uzupełnienie director + critical_correct
# ---------------------------------------------------------------------------
NOTE_RANGES: dict[str, tuple[int, int]] = {
    "sub": (26, 43), "wobble": (28, 52), "reese": (28, 52), "neuro": (30, 55),
    "fmbass": (30, 55), "hollow": (32, 55), "growl": (30, 58), "bass808": (24, 42),
    "upright": (28, 52), "kick": (24, 48), "snare": (36, 60), "hat": (60, 96),
    "clap": (48, 72), "rim": (48, 72), "tom": (36, 60), "crash": (48, 84),
    "shaker": (60, 96), "openhat": (60, 96), "ride": (60, 96), "cowbell": (60, 84),
    "conga": (48, 72), "pad": (48, 76), "drone": (28, 52), "choir": (48, 72),
    "strings": (48, 76), "cello": (36, 60), "vox": (52, 76), "screech": (48, 80),
    "supersaw": (52, 84), "pluck": (55, 88), "stab": (52, 80), "theremin": (55, 84),
    "panflute": (60, 88), "handpan": (48, 72), "tongue": (52, 76), "zap": (48, 84),
    "riser": (36, 84), "boom": (24, 48), "glitch": (36, 84), "hoover": (40, 72),
    "organ": (36, 72), "epiano": (48, 76), "harpsichord": (48, 84), "flute": (60, 88),
    "brass": (48, 76), "vibes": (55, 88), "marimba": (55, 88), "bell": (60, 96),
    "piano": (36, 84), "acid": (40, 72), "speak": (48, 72),
}

# Okna parametrów (0..1) — bezpieczne muzykalnie; aplikator przyciąga do środka okna
PARAM_WINDOWS: dict[str, tuple[float, float]] = {
    "Attack": (0.05, 0.70),
    "Release": (0.12, 0.85),
    "Decay": (0.10, 0.75),
    "Sustain": (0.15, 0.90),
    "Glide": (0.00, 0.45),
    "Drive": (0.00, 0.40),
    "Resonance": (0.05, 0.55),
    "Cutoff": (0.18, 0.72),
    "LFO Rate": (0.04, 0.55),
    "LFO > Cutoff": (0.00, 0.60),
    "LFO > Pitch": (0.00, 0.30),
    "LFO > FM": (0.00, 0.35),
    "FM Amount": (0.00, 0.45),
    "Unison Detune": (0.00, 0.55),
    "Wave Morph": (0.00, 0.70),
    "Filter Env Amt": (0.00, 0.55),
    "Noise": (0.00, 0.35),
    "Formant Mix": (0.10, 0.85),
    "Tone Level": (0.20, 0.90),
    "Pulse Width": (0.15, 0.85),
}

# Cele spektralne (względne energie pasm) dla rodzin klimatu
BAND_TARGETS: dict[str, dict[str, float]] = {
    "dark":    {"sub": 0.28, "bass": 0.30, "lowmid": 0.18, "mid": 0.12, "himid": 0.08, "high": 0.04},
    "hard":    {"sub": 0.22, "bass": 0.28, "lowmid": 0.20, "mid": 0.15, "himid": 0.10, "high": 0.05},
    "acid":    {"sub": 0.18, "bass": 0.25, "lowmid": 0.22, "mid": 0.18, "himid": 0.12, "high": 0.05},
    "organic": {"sub": 0.15, "bass": 0.22, "lowmid": 0.22, "mid": 0.20, "himid": 0.13, "high": 0.08},
    "bright":  {"sub": 0.12, "bass": 0.18, "lowmid": 0.20, "mid": 0.22, "himid": 0.18, "high": 0.10},
    "space":   {"sub": 0.20, "bass": 0.20, "lowmid": 0.18, "mid": 0.18, "himid": 0.14, "high": 0.10},
    "default": {"sub": 0.18, "bass": 0.25, "lowmid": 0.20, "mid": 0.18, "himid": 0.12, "high": 0.07},
}

# Globalny stan tła (self-listen)
_listener_lock = threading.Lock()
_listener: "SelfListener | None" = None


# ---------------------------------------------------------------------------
# Konfiguracja (może pochodzić z user_rules / proj / wywołania)
# ---------------------------------------------------------------------------
DEFAULT_CFG = {
    "on": True,
    "mode": "both",          # symbolic | audio | both
    "intensity": 0.60,       # 0..1 siła korekt
    "interval": 5.0,         # s między analizami audio w tle
    "max_passes": 2,         # przebiegi symbolic
    "audio_on_generate": False,  # po generate od razu jeden przebieg audio (wolniejszy)
}


def _cfg(raw=None) -> dict:
    c = dict(DEFAULT_CFG)
    if isinstance(raw, dict):
        for k, v in raw.items():
            if k in c:
                c[k] = v
    c["intensity"] = max(0.0, min(1.0, float(c["intensity"])))
    c["interval"] = max(1.5, float(c["interval"]))
    c["max_passes"] = max(1, min(4, int(c["max_passes"])))
    mode = str(c["mode"]).lower()
    if mode not in ("symbolic", "audio", "both"):
        mode = "both"
    c["mode"] = mode
    c["on"] = bool(c["on"])
    return c


# ---------------------------------------------------------------------------
# Dyskryminator symboliczny (bez audio)
# ---------------------------------------------------------------------------
def _climate_family(proj: dict) -> str:
    cl = proj.get("climate") or {}
    fam = (cl.get("family") or "").lower()
    if fam in BAND_TARGETS:
        return fam
    return "default"


def _note_range_for(tt: str, profile_ranges: dict | None = None) -> tuple[int, int]:
    if profile_ranges and tt in profile_ranges:
        return tuple(profile_ranges[tt])  # type: ignore
    return NOTE_RANGES.get(tt, (36, 84))


def _clamp_notes(tr: dict, lo: int, hi: int, intensity: float, rng: random.Random) -> int:
    """Przesuwa nuty oktawami w zakres; zwraca liczbę zmienionych nut."""
    if tr.get("lock_notes") or not tr.get("notes"):
        return 0
    changed = 0
    new_notes = []
    for n in tr["notes"]:
        on, dur, key, vel = n[0], n[1], int(n[2]), n[3]
        k = fold_key(key)
        if lo <= k <= hi:
            new_notes.append((on, dur, k, clamp_vel(vel)))
            continue
        # oktawy w kierunku środka
        mid = (lo + hi) / 2
        while k < lo:
            k += 12
        while k > hi:
            k -= 12
        if k < lo:
            k += 12
        if k > hi:
            k = max(lo, min(hi, int(round(mid))))
        # mieszamy ze starą wartością wg intensity
        if rng.random() < intensity:
            new_notes.append((on, dur, fold_key(k), clamp_vel(vel)))
            changed += 1
        else:
            new_notes.append((on, dur, fold_key(key), clamp_vel(vel)))
    tr["notes"] = new_notes
    return changed


def _pull_param(tr: dict, name: str, lo: float, hi: float, intensity: float, rng: random.Random) -> bool:
    """Przyciąga parametr do okna. Szanuje locked_params / lock_sound."""
    if tr.get("lock_sound"):
        return False
    locked = tr.get("locked_params") or {}
    if name in locked:
        return False
    params = tr.setdefault("params", {})
    if name not in params:
        # losuj w oknie jeśli brak — tylko przy wyższej intensity
        if intensity > 0.35 and rng.random() < intensity * 0.6:
            params[name] = lo + (hi - lo) * (0.35 + 0.3 * rng.random())
            return True
        return False
    try:
        v = float(params[name])
    except (TypeError, ValueError):
        return False
    if lo <= v <= hi:
        return False
    # przyciągnij
    target = lo if v < lo else hi
    # lekko do środka okna przy silnej intensity
    mid = (lo + hi) * 0.5
    blend = 0.45 + 0.45 * intensity
    new_v = v + (target - v) * blend
    if intensity > 0.7:
        new_v = new_v + (mid - new_v) * 0.15 * intensity
    params[name] = max(0.0, min(1.0, new_v))
    return True


def _balance_gains(proj: dict, intensity: float) -> None:
    """Miękkie dociągnięcie gainów do TARGET_REL (bez pomiaru RMS)."""
    for tr in proj.get("tracks") or []:
        if tr.get("lock_gain") or tr.get("mute"):
            continue
        tt = tr.get("type") or ""
        tgt = TARGET_REL.get(tt, DEFAULT_GAIN.get(tt, 0.7))
        cur = float(tr.get("gain", tgt))
        if abs(cur - tgt) < 0.04:
            continue
        tr["gain"] = cur + (tgt - cur) * (0.35 + 0.45 * intensity)


def _density_energy_caps(proj: dict, intensity: float) -> None:
    """Ogranicza skrajną gęstość/energię wg klimatu (symbolic)."""
    fam = _climate_family(proj)
    # soft caps zależne od rodziny
    dens_cap = {"dark": 0.62, "space": 0.55, "organic": 0.58, "bright": 0.72,
                "acid": 0.70, "hard": 0.85}.get(fam, 0.70)
    ener_cap = {"dark": 0.65, "space": 0.55, "organic": 0.60, "bright": 0.75,
                "acid": 0.78, "hard": 0.92}.get(fam, 0.75)
    if intensity < 0.25:
        return
    d0 = float(proj.get("density") or 0.5)
    e0 = float(proj.get("energy") or 0.5)
    if d0 > dens_cap:
        proj["density"] = d0 + (dens_cap - d0) * intensity * 0.7
    if e0 > ener_cap:
        proj["energy"] = e0 + (ener_cap - e0) * intensity * 0.7


def apply_symbolic(proj: dict, cfg=None, rng: random.Random | None = None,
                   profile_ranges: dict | None = None,
                   profile_windows: dict | None = None) -> dict:
    """Cicha korekta symboliczna (bez renderu, bez raportu w proj).

    Zwraca proj (in-place). Nie zapisuje żadnego musicality_report.
    """
    c = _cfg(cfg if cfg is not None else (proj.get("musicality") if isinstance(proj.get("musicality"), dict) else None))
    if not c["on"] or c["intensity"] <= 0.0 or c["mode"] == "audio":
        return proj

    rng = rng or random.Random(int(proj.get("seed") or 0) ^ 0xA11CE)
    intensity = c["intensity"]
    windows = dict(PARAM_WINDOWS)
    if profile_windows:
        windows.update(profile_windows)

    for _ in range(c["max_passes"]):
        _density_energy_caps(proj, intensity)
        for tr in proj.get("tracks") or []:
            tt = tr.get("type")
            if not tt:
                continue
            lo, hi = _note_range_for(tt, profile_ranges)
            _clamp_notes(tr, lo, hi, intensity, rng)
            for pname, (plo, phi) in windows.items():
                _pull_param(tr, pname, plo, phi, intensity, rng)
        _balance_gains(proj, intensity)
        intensity *= 0.72  # kolejne przebiegi słabsze

    # bez raportu — tylko flaga że przeszło
    proj["musicality"] = {
        "on": c["on"],
        "mode": c["mode"],
        "intensity": c["intensity"],
        "last": "symbolic",
        "ts": time.time(),
    }
    return proj


# ---------------------------------------------------------------------------
# Analiza audio → korekty (self-listen)
# ---------------------------------------------------------------------------
def _features_to_corrections(proj: dict, feats: dict, intensity: float, rng: random.Random) -> None:
    """Na podstawie cech z listen.analyze_audio miękko koryguje gainy i wybrane parametry."""
    if not feats:
        return
    bands = feats.get("bands") or feats.get("band") or {}
    # normalizacja energii pasm
    if isinstance(bands, dict) and bands:
        total = sum(float(v) for v in bands.values()) or 1.0
        cur = {k: float(v) / total for k, v in bands.items()}
    else:
        cur = {}

    fam = _climate_family(proj)
    target = BAND_TARGETS.get(fam, BAND_TARGETS["default"])

    # imbalance: nadmiar high / niedobór sub itp.
    excess_high = max(0.0, cur.get("high", 0) - target.get("high", 0.07)) + \
                  max(0.0, cur.get("himid", 0) - target.get("himid", 0.12))
    deficit_sub = max(0.0, target.get("sub", 0.18) - cur.get("sub", 0)) + \
                  max(0.0, target.get("bass", 0.25) - cur.get("bass", 0))
    excess_mid = max(0.0, cur.get("mid", 0) - target.get("mid", 0.18) * 1.35)

    brightness = float(feats.get("brightness") or feats.get("bright") or 0.5)
    level = float(feats.get("level") or feats.get("rms") or 0.2)

    for tr in proj.get("tracks") or []:
        if tr.get("lock_sound") or tr.get("lock_gain") or tr.get("mute"):
            continue
        tt = tr.get("type") or ""
        params = tr.setdefault("params", {})
        locked = tr.get("locked_params") or {}

        # zbyt jasno → obniż Cutoff / Noise na leadach i hat
        if excess_high > 0.04 and tt in (
            "hat", "openhat", "shaker", "crash", "screech", "supersaw", "pluck",
            "stab", "zap", "bell", "ride",
        ):
            if "Cutoff" not in locked and "Cutoff" in params:
                try:
                    v = float(params["Cutoff"])
                    params["Cutoff"] = max(0.05, v - excess_high * 1.8 * intensity)
                except (TypeError, ValueError):
                    pass
            if "Noise" not in locked and "Noise" in params:
                try:
                    v = float(params["Noise"])
                    params["Noise"] = max(0.0, v - excess_high * 1.2 * intensity)
                except (TypeError, ValueError):
                    pass
            g = float(tr.get("gain", 0.6))
            tr["gain"] = max(0.15, g * (1.0 - 0.25 * excess_high * intensity))

        # niedobór sub/bass → podnieś gain sub/wobble/reese / lekko Drive
        if deficit_sub > 0.04 and tt in ("sub", "wobble", "reese", "neuro", "bass808", "fmbass", "hollow", "kick"):
            g = float(tr.get("gain", 0.8))
            tr["gain"] = min(1.15, g * (1.0 + 0.35 * deficit_sub * intensity))
            if "Drive" not in locked and "Drive" in params:
                try:
                    v = float(params["Drive"])
                    params["Drive"] = min(0.55, v + deficit_sub * 0.4 * intensity)
                except (TypeError, ValueError):
                    pass

        # bałagan w mid → zmiękcz Resonance / Filter Env na growlach i neuro
        if excess_mid > 0.05 and tt in ("growl", "neuro", "screech", "hoover", "acid"):
            if "Resonance" not in locked and "Resonance" in params:
                try:
                    v = float(params["Resonance"])
                    params["Resonance"] = max(0.05, v - excess_mid * 1.5 * intensity)
                except (TypeError, ValueError):
                    pass

        # ogólna jasność za wysoka → Attack trochę dłuższy na padach
        if brightness > 0.72 and tt in ("pad", "drone", "choir", "strings", "cello"):
            if "Attack" not in locked and "Attack" in params:
                try:
                    v = float(params["Attack"])
                    params["Attack"] = min(0.92, v + 0.12 * intensity)
                except (TypeError, ValueError):
                    pass

    # globalny poziom — jeśli miks cichy, lekko podnieś energię projektu (tylko meta)
    if level < 0.08 and intensity > 0.4:
        e0 = float(proj.get("energy") or 0.5)
        proj["energy"] = min(0.95, e0 + 0.06 * intensity)


def review_audio_once(proj: dict, cfg=None, rng: random.Random | None = None,
                      max_sec: float = 12.0) -> bool:
    """Jeden przebieg: render_mix w pamięci → analyze_audio → korekty. Bez pliku, bez raportu.

    Zwraca True jeśli udało się przeanalizować.
    """
    c = _cfg(cfg if cfg is not None else (proj.get("musicality") if isinstance(proj.get("musicality"), dict) else None))
    if not c["on"] or c["intensity"] <= 0.0 or c["mode"] == "symbolic":
        return False

    rng = rng or random.Random(int(proj.get("seed") or 0) ^ 0xBEEF)
    try:
        mix = core.render_mix(proj, workers=1)
    except Exception:
        return False
    if mix is None or len(mix) < 1024:
        return False

    # skróć do max_sec od środka (typowy drop)
    sr = core.SR
    max_n = int(max_sec * sr)
    if len(mix) > max_n:
        start = max(0, (len(mix) - max_n) // 2)
        mix = mix[start: start + max_n]

    try:
        from . import listen as L
        feats = L.analyze_audio(mix, rate=sr)
    except Exception:
        return False

    _features_to_corrections(proj, feats, c["intensity"], rng)
    proj["musicality"] = {
        "on": c["on"],
        "mode": c["mode"],
        "intensity": c["intensity"],
        "last": "audio",
        "ts": time.time(),
    }
    return True


# ---------------------------------------------------------------------------
# Publiczny punkt wejścia po generacji
# ---------------------------------------------------------------------------
def review_and_apply(proj: dict, cfg=None, rng: random.Random | None = None,
                     profile_ranges: dict | None = None,
                     profile_windows: dict | None = None) -> dict:
    """Główne wywołanie: symbolic zawsze (gdy mode pozwala), audio opcjonalnie raz.

    Bez raportu szczegółowego. Bez zapisu wav/mp3.
    """
    c = _cfg(cfg if cfg is not None else (proj.get("musicality") if isinstance(proj.get("musicality"), dict) else None))
    if not c["on"]:
        return proj

    rng = rng or random.Random(int(proj.get("seed") or 0) ^ 0xA11CE)

    if c["mode"] in ("symbolic", "both"):
        # spróbuj wciągnąć okna z critical_correct jeśli aktywny profil
        pr = profile_ranges
        pw = profile_windows
        if pr is None or pw is None:
            try:
                from . import critical_correct as CC
                cc = proj.get("critical_correct") or {}
                if isinstance(cc, dict) and cc.get("on"):
                    pid = CC.resolve_profile(cc.get("profile"), proj.get("style") or "")
                    prof = CC.FLUID_PROFILES.get(pid) or {}
                    if pr is None:
                        pr = prof.get("note_ranges")
                    if pw is None:
                        pw = prof.get("param_windows")
            except Exception:
                pass
        apply_symbolic(proj, c, rng=rng, profile_ranges=pr, profile_windows=pw)

    if c["mode"] in ("audio", "both") and c.get("audio_on_generate"):
        review_audio_once(proj, c, rng=rng)

    return proj


# ---------------------------------------------------------------------------
# Tło: sam siebie słucha, mieszając na bieżąco
# ---------------------------------------------------------------------------
class SelfListener:
    """Wątek tła: okresowo renderuje miks w pamięci (bez pliku), analizuje i koryguje.

    Użycie:
        start_self_listen(get_proj_callable, cfg)
        ...
        stop_self_listen()
    """

    def __init__(self, get_proj: Callable[[], dict | None], cfg: dict | None = None):
        self.get_proj = get_proj
        self.cfg = _cfg(cfg)
        self._stop = threading.Event()
        self._th: threading.Thread | None = None
        self._last_ts = 0.0
        self._busy = False

    def start(self) -> None:
        if self._th and self._th.is_alive():
            return
        self._stop.clear()
        self._th = threading.Thread(target=self._loop, name="ds-self-listen", daemon=True)
        self._th.start()

    def stop(self, wait: float = 2.0) -> None:
        self._stop.set()
        th = self._th
        if th and th is not threading.current_thread():
            th.join(timeout=wait)
        self._th = None

    def _loop(self) -> None:
        while not self._stop.is_set():
            interval = max(1.5, float(self.cfg.get("interval") or 5.0))
            if self._stop.wait(interval):
                break
            if self._busy:
                continue
            self._busy = True
            try:
                proj = self.get_proj()
                if not proj or not isinstance(proj, dict):
                    continue
                if not (proj.get("tracks")):
                    continue
                # nie blokuj odtwarzania — jeden worker, krótki fragment
                c = dict(self.cfg)
                c["mode"] = "audio"  # w tle tylko ścieżka audio
                review_audio_once(proj, c, max_sec=8.0)
                self._last_ts = time.time()
            except Exception:
                pass
            finally:
                self._busy = False


def start_self_listen(get_proj: Callable[[], dict | None], cfg=None) -> SelfListener:
    """Uruchamia (lub restartuje) globalny wątek self-listen."""
    global _listener
    with _listener_lock:
        if _listener is not None:
            try:
                _listener.stop(wait=1.0)
            except Exception:
                pass
        _listener = SelfListener(get_proj, cfg)
        _listener.start()
        return _listener


def stop_self_listen() -> None:
    global _listener
    with _listener_lock:
        if _listener is not None:
            try:
                _listener.stop()
            except Exception:
                pass
            _listener = None


def self_listen_running() -> bool:
    with _listener_lock:
        return _listener is not None and _listener._th is not None and _listener._th.is_alive()
