"""Testy rytmów tanecznych melodii (dance_rhythm.py). Uruchomienie: python3 -m unittest tests.test_dance_rhythm -v"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dubstep_studio import core  # noqa: E402

try:
    core.meta()
    from dubstep_studio import generator as G, dance_rhythm as D  # noqa: E402
    OK = True
except Exception:
    OK = False

STY = ["Techno", "Trance", "Trap", "DnB", "Jazz", "Daft Punk - Discovery (2001)", "Techno 60% + DnB 40%"]


def gen(st, sd, **kw):
    return G.generate(style=st, seed=sd, bars=96, **kw)


def pairs(notes, key):
    n = sorted(notes)
    return sum(1 for x, y in zip(n, n[1:]) if key(x, y))


@unittest.skipUnless(OK, "brak zbudowanych wtyczek CLAP")
class Dance(unittest.TestCase):
    def test_off_by_default(self):
        p = gen("Techno", 1)
        self.assertNotIn("dance", p)
        q = gen("Techno", 1, dance=False)
        self.assertEqual([t["notes"] for t in p["tracks"]], [t["notes"] for t in q["tracks"]])

    def test_deterministic(self):
        a, b = gen("Trance", 2, dance=True), gen("Trance", 2, dance=True)
        self.assertEqual([t["notes"] for t in a["tracks"]], [t["notes"] for t in b["tracks"]])

    def test_only_rhythmic_melodies_touched_and_nothing_broken(self):
        for st in STY:
            for sd in (1, 2):
                a, b = gen(st, sd), gen(st, sd, dance=True, dance_strength=0.8)
                self.assertTrue(b["dance"]["on"], st)
                for ta, tb in zip(a["tracks"], b["tracks"]):
                    if ta["type"] not in D.DANCE_T:
                        self.assertEqual(ta["notes"], tb["notes"], f"{st}: ruszono {ta['type']}")
                        continue
                    if ta["notes"] == tb["notes"]:
                        continue
                    self.assertGreaterEqual(len(tb["notes"]), 0.7 * len(ta["notes"]), f"{st}/{ta['type']}: za dużo pauz")
                    for n in tb["notes"]:
                        self.assertTrue(n[0] >= 0 and n[1] > 0 and 1 <= n[3] <= 127)
                    self.assertLessEqual(pairs(tb["notes"], lambda x, y: x[0] + x[1] > y[0] + 1e-6),
                                         pairs(ta["notes"], lambda x, y: x[0] + x[1] > y[0] + 1e-6))
                    self.assertLessEqual(pairs(tb["notes"], lambda x, y: abs(x[0] - y[0]) < 1e-6),
                                         pairs(ta["notes"], lambda x, y: abs(x[0] - y[0]) < 1e-6))

    def test_notes_move_toward_strong_steps(self):
        def share(p, grid):
            if len(grid) != 1:
                return None
            hit = tot = 0
            drops = {b for s in p["sections"] if s["type"] == "drop" for b in range(s["start"], s["start"] + s["bars"])}
            for t in p["tracks"]:
                if t["type"] not in D.DANCE_T:
                    continue
                for n in t["notes"]:
                    b = int(n[0] // 4)
                    if b in drops and n[1] < 2:
                        tot += 1
                        hit += grid[0].get(int(round((n[0] - 4 * b) * 4)), 0) >= 0.5
            return hit / tot if tot else None
        gains = []
        for st in ("Techno", "Trance", "Trap", "DnB"):
            a, b = gen(st, 3), gen(st, 3, dance=True, dance_strength=1.0)
            g = b["climate"]["dance"]["grid"]
            sa, sb = share(a, g), share(b, g)
            if sa is not None and sb is not None:
                gains.append(sb - sa)
        self.assertTrue(gains and sum(gains) / len(gains) > 0, gains)

    def test_steps_come_from_style_first(self):
        p = gen("Techno", 1, dance=True)
        self.assertIn("dance", p["climate"])                       # kroki zamrożone w klimacie, nie w ekspresji
        self.assertTrue(p["climate"]["dance"]["grid"][0].get(0, 0) >= 0.5)   # stopa na „1" = mocny krok


if __name__ == "__main__":
    unittest.main()
