"""Zmienność stylu (style_variants.py): nieprzewidywalność w granicach gatunku."""
import copy
import random
import unittest

from dubstep_studio import generator as G, styles as ST, style_variants as SV

TOK = set("rotfbpu")


class TestGrammarData(unittest.TestCase):
    def test_grammar_covers_only_known_base_styles(self):
        self.assertTrue(set(SV.GRAMMAR) <= set(ST.ORDER))
        self.assertEqual(set(ST.ORDER) - set(SV.GRAMMAR), set(), "każdy podstawowy styl ma mieć gramatykę")

    def test_patterns_are_well_formed(self):
        for name, g in SV.GRAMMAR.items():
            for pat in list(g.get("wob_extra", [])) + list(g.get("growl_extra", [])):
                for st, tk, ln in pat:
                    self.assertTrue(0 <= st <= 15 and tk in TOK and ln >= 1 and st + ln <= 16, (name, pat))
            for pat in g.get("kick_alts", []):
                self.assertTrue(all(0 <= s <= 15 for s in pat) and pat == sorted(set(pat)), (name, pat))
            for e in g.get("kick_emb", []):
                self.assertTrue(0 <= e[0] <= 15 and 0 < e[1] <= 1, (name, e))
            for e in list(g.get("snare_emb", [])) + list(g.get("hat_emb", [])):
                self.assertTrue(0 <= e[0] <= 15 and 1 <= e[1] <= 127 and 0 < e[2] <= 1, (name, e))
            for pr in g.get("progs_extra", []):
                self.assertTrue(all(0 <= d <= 6 for d in pr), (name, pr))
            lo, hi = g.get("bpm", (0, 1))
            self.assertLessEqual(lo, hi)

    def test_alternatives_never_break_their_own_invariants(self):
        for name, g in SV.GRAMMAR.items():
            inv = g.get("inv", {})
            base = G.STYLES[name]
            for st in inv.get("kick", []):
                for pat in list(base["kick"]) + list(g.get("kick_alts", [])):
                    if not base.get("fourfloor"):
                        self.assertIn(st, pat, (name, pat, "wzór stopy łamie niezmiennik"))
            for st in inv.get("snare", []):
                self.assertIn(st, base.get("snare", [8]), name)
                for alt, _ in g.get("snare_alts", []):
                    self.assertIn(st, alt, (name, alt))
            for st in g.get("kick_emb", []):
                self.assertNotIn(st[0], base.get("snare", [8]) if inv.get("snare") else [], (name, "pickup stopy na werblu"))


class TestVariety(unittest.TestCase):
    def test_zero_is_identity(self):
        cfg = G.STYLES["Brostep"]
        self.assertIs(SV.varied("Brostep", cfg, 0.0, 5), cfg)
        self.assertIsNone(SV.bpm_for("Brostep", cfg, 0.0, 5))

    def test_albums_and_unknown_untouched(self):
        albums = [n for n in G.STYLES if n not in ST.ORDER]
        self.assertTrue(albums)
        for sp in albums:
            cfg = G.STYLES[sp]
            self.assertIs(SV.varied(sp, cfg, 1.0, 5), cfg, sp)
            self.assertIsNone(SV.bpm_for(sp, cfg, 1.0, 5), sp)

    def test_invariants_hold_for_every_style(self):
        for style in ST.ORDER:
            for seed in (2, 19, 303):
                p = G.generate(style=style, seed=seed, bars=64, predict=1.0, variety=1.0)
                self.assertEqual(SV.check_invariants(p), [], (style, seed))

    def test_more_variety_gives_more_kick_patterns(self):
        def patterns(style, v):
            seen = set()
            for seed in range(1, 13):
                p = G.generate(style=style, seed=seed, bars=64, predict=1.0, variety=v)
                tr = next(t for t in p["tracks"] if t["type"] == "kick")
                for s in p["sections"]:
                    if s["type"] == "drop":
                        for i in range(s["bars"]):
                            b = s["start"] + i
                            seen.add(tuple(sorted({int(round((n[0] - b * 4) / .25)) for n in tr["notes"] if b * 4 - .01 <= n[0] < b * 4 + 3.99})))
            return len(seen)
        for style in ("Brostep", "DnB", "Trap", "Drumstep"):
            self.assertGreater(patterns(style, 1.0), patterns(style, 0.0) * 1.5, style)

    def test_four_on_the_floor_kick_is_never_changed(self):
        for style in ("House", "Techno", "Trance", "EDM", "Psytrance"):
            cfg = SV.varied(style, G.STYLES[style], 1.0, 3)
            self.assertEqual(cfg["kick"], G.STYLES[style]["kick"], style)

    def test_bpm_stays_in_genre_range(self):
        for style, g in SV.GRAMMAR.items():
            if "bpm" not in g:
                continue
            for seed in range(30):
                b = SV.bpm_for(style, G.STYLES[style], 1.0, seed)
                self.assertTrue(g["bpm"][0] <= b <= g["bpm"][1], (style, b))
        p = G.generate(style="Brostep", seed=4, bars=48, bpm=150, variety=1.0)
        self.assertEqual(p["bpm"], 150)                     # BPM podany przez użytkownika wygrywa

    def test_hybrid_with_album_keeps_album_bass(self):
        album = next(n for n in G.STYLES if n not in ST.ORDER and G.STYLES[n].get("wob", "").startswith("sp:"))
        name = ST.hybrid_name({"Brostep": 0.7, album: 0.3})
        cfg = SV.varied(name, G.STYLES[name], 1.0, 4)
        if G.STYLES[name]["wob"] != G.STYLES["Brostep"]["wob"]:
            self.assertNotIn("wob_lib", cfg)                # bas z albumu: bez rozszerzeń z gramatyki Brostep
        self.assertTrue(G.generate(style=name, seed=4, bars=48, variety=1.0)["tracks"])

    def test_deterministic_and_reroll_keeps_personality(self):
        a = G.generate(style="DnB", seed=11, bars=64, variety=0.8)
        b = G.generate(style="DnB", seed=11, bars=64, variety=0.8)
        self.assertEqual([t["notes"] for t in a["tracks"]], [t["notes"] for t in b["tracks"]])
        cfg0 = G.Ctx(a, G.STYLES["DnB"]).cfg
        G.reroll_track(a, "kick", new_seed=999)
        cfg1 = G.Ctx(a, G.STYLES["DnB"]).cfg
        self.assertEqual(cfg0["kick"], cfg1["kick"])        # pule wzorów zależą od vseed, nie od seeda rerolla
        self.assertEqual(a["variety"], 0.8)

    def test_hybrids_work_and_respect_rhythm(self):
        name = ST.hybrid_name({"House": 0.6, "Brostep": 0.4})
        p = G.generate(style=name, seed=8, bars=64, variety=1.0)
        self.assertTrue(p["tracks"])
        ff = G.STYLES[name].get("fourfloor")
        cfg = SV.varied(name, G.STYLES[name], 1.0, 8)
        if ff:
            self.assertEqual(cfg["kick"], G.STYLES[name]["kick"])

    def test_embellishments_do_not_shift_main_random_stream(self):
        """Hat/snare/kick dostają dodatki, ale melodia i reszta ścieżek (inne strumienie) są takie same jak przy variety = 0 dla tej samej puli wzorów."""
        a = G.generate(style="Techno", seed=21, bars=64, variety=0.0, predict=1.0)
        b = G.generate(style="Techno", seed=21, bars=64, variety=1.0, predict=1.0)
        for typ in ("kick",):                               # four-on-the-floor: pula stopy bez zmian → identyczna stopa
            ta = next(t for t in a["tracks"] if t["type"] == typ)["notes"]
            tb = next(t for t in b["tracks"] if t["type"] == typ)["notes"]
            self.assertEqual(ta, tb)


if __name__ == "__main__":
    unittest.main()
