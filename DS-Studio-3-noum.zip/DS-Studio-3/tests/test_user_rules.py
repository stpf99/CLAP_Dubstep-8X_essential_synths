"""Reguły użytkownika (user_rules.py): poziom mowy, własne grupy wtyczek, tryb bezwzględny.
Uruchomienie z katalogu projektu:   python3 -m unittest tests.test_user_rules -v   (wymaga zbudowanych wtyczek: make)"""
import os
import statistics
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ["DS_USER_RULES"] = os.path.join(tempfile.mkdtemp(), "user_rules.json")

from dubstep_studio import core, generator as G, styles as ST, user_rules as UR  # noqa: E402

INST = ["kick", "snare", "hat", "sub", "growl", "vox", "vox", "speak", "pad", "screech"]


def voice(p):
    return [t for t in p["tracks"] if t["type"] in UR.VOICE_TYPES]


class Base(unittest.TestCase):
    def setUp(self):
        UR.update(voice_level=3, groups_absolute=False, group_map={}, dyn={"on": False}, save=False)

    tearDown = setUp


class TestVoice(Base):
    def test_level0_removes_whole_group_even_with_speak_text(self):
        UR.update(voice_level=0, save=False)
        for st in ST.ORDER:
            p = G.generate(style=st, seed=5, bars=32, speak_text="drop the bass", smart_instruments=True, arranger=dict(on=True, amount=.6))
            self.assertEqual(voice(p), [], st)
            names = {t["name"] for t in p["tracks"]}
            self.assertTrue(all(l["dst"] in names for l in p["links"]), st)

    def test_levels_cap_count_and_gain(self):
        base = {t["type"]: t["gain"] for t in G.generate(style="Brostep", seed=7, bars=32, instruments=INST)["tracks"]}
        for lv, cap in ((1, 1), (2, 2)):
            UR.update(voice_level=lv, save=False)
            p = G.generate(style="Brostep", seed=7, bars=32, instruments=INST)
            vt = voice(p)
            self.assertLessEqual(len(vt), cap)
            for t in vt:
                self.assertAlmostEqual(t["gain"], base[t["type"]] * UR.VOICE_GAIN[lv], places=3)
        UR.update(voice_level=1, save=False)
        self.assertEqual([t["type"] for t in voice(G.generate(style="Brostep", seed=7, bars=32, instruments=INST))], ["growl"])   # priorytet growl

    def test_level3_changes_nothing(self):
        a = G.generate(style="Riddim", seed=3, bars=32, instruments=INST)
        UR.update(voice_level=3, save=False)
        b = G.generate(style="Riddim", seed=3, bars=32, instruments=INST)
        self.assertEqual([t["notes"] for t in a["tracks"]], [t["notes"] for t in b["tracks"]])


class TestGroups(Base):
    def test_map_changes_tables_and_reset_restores(self):
        orig = list(G.INST_GROUPS["bass"])
        UR.update(group_map={"reese": "lead"}, save=False)
        self.assertIn("reese", G.INST_GROUPS["lead"]); self.assertNotIn("reese", G.INST_GROUPS["bass"])
        self.assertEqual(G.NATIVE_ROLE["reese"], "lead")
        UR.update(group_map={}, save=False)
        self.assertEqual(G.INST_GROUPS["bass"], orig); self.assertEqual(G.NATIVE_ROLE["reese"], "bass")

    def test_smart_pick_uses_user_groups(self):
        UR.update(group_map={t: "lead" for t in ("wobble", "reese", "growl", "neuro", "fmbass", "hollow", "acid", "bass808", "upright")}, save=False)
        seen_bass_as_lead = False
        for seed in range(12):
            ch = G.pick_smart_instruments("Brostep", 0.7, 0.9, seed=seed)
            seen_bass_as_lead |= any(t in ch for t in ("wobble", "reese", "growl"))
        self.assertTrue(seen_bass_as_lead)

    def test_absolute_folds_into_group_register(self):
        med = lambda t: statistics.median(n[2] for n in t["notes"])
        kw = dict(style="Riddim", seed=4, bars=32, instruments=["kick", "snare", "hat", "sub", "wobble", "pad"], role_swap=True)
        UR.update(group_map={"sub": "lead", "wobble": "lead"}, groups_absolute=False, save=False)
        soft = {t["type"]: med(t) for t in G.generate(**kw)["tracks"] if t["type"] in ("sub", "wobble")}
        UR.update(groups_absolute=True, save=False)
        p = G.generate(**kw)
        hard = {t["type"]: med(t) for t in p["tracks"] if t["type"] in ("sub", "wobble")}
        lo, hi = G.ROLE_REG["lead"]
        for t, m in hard.items():
            self.assertTrue(lo <= m <= hi, (t, m))
        self.assertGreater(hard["sub"], soft["sub"])
        self.assertEqual({r["track"] for r in p["user_rules"]["groups"]}, {"sub", "wobble"})

    def test_reroll_keeps_group_register(self):
        UR.update(group_map={"sub": "lead"}, groups_absolute=True, save=False)
        p = G.generate(style="Riddim", seed=4, bars=32, instruments=["kick", "snare", "sub", "wobble"])
        tr = next(t for t in p["tracks"] if t["type"] == "sub")
        G.reroll_track(p, tr["name"], new_seed=9)
        lo, hi = G.ROLE_REG["lead"]
        self.assertTrue(lo <= statistics.median(n[2] for n in tr["notes"]) <= hi)

    def test_bad_values_are_sanitized(self):
        UR.update(voice_level=9, group_map={"sub": "nonsense", "reese": "lead"}, save=False)
        s = UR.get()
        self.assertEqual(s["voice_level"], 3); self.assertEqual(s["group_map"], {"reese": "lead"})


class TestDynProfiles(Base):
    def test_off_changes_nothing(self):
        self.assertEqual(UR.dyn_overlay("kick", {"Level": 0.5}, core.meta()), {"Level": 0.5})

    def test_priority_type_over_group_over_default(self):
        m = core.meta()
        UR.update(dyn={"on": True, "default": {"mode": 2, "preset": 3}, "groups": {"bass": {"mode": 1, "preset": 6}},
                       "types": {"kick": {"mode": 1, "preset": 1, "curve": 3}}}, save=False)
        pr = lambda t: UR.dyn_profile_for(t)["preset"]
        self.assertEqual((pr("kick"), pr("sub"), pr("pad")), (1, 6, 3))
        o = UR.dyn_overlay("kick", {}, m)
        self.assertAlmostEqual(o["Dyn Preset"], 1 / 7, places=3); self.assertEqual(o["Dyn Curve"], 1.0)

    def test_user_group_map_drives_profile_group(self):
        UR.update(dyn={"on": True, "default": {"preset": 0}, "groups": {"lead": {"preset": 4}}}, group_map={"sub": "lead"}, save=False)
        self.assertEqual(UR.dyn_profile_for("sub")["preset"], 4)

    def test_profile_reaches_render_job_and_cache_key(self):
        p = G.generate(style="Riddim", seed=3, bars=8, instruments=["kick", "sub"])
        m = core.meta(); t = p["tracks"][0]
        def job():
            f = Path(tempfile.mkdtemp()) / "j.txt"; core._write_job(f, "/tmp/o.f32", p, t, {}, m); return f.read_text()
        before = job()
        UR.update(dyn={"on": True, "default": {"mode": 2, "preset": 3}}, save=False)
        after = job()
        self.assertNotEqual(before, after)
        pid = m.plugins[t["plugin"]]["params"]["Dyn Preset"]["id"]
        self.assertIn(f"p {pid} 3", after)

    def test_sanitize_clamps(self):
        UR.update(dyn={"on": 1, "default": {"mode": 9, "preset": -4, "amount": 7}, "groups": {"zzz": {}}}, save=False)
        d = UR.get()["dyn"]
        self.assertEqual((d["default"]["mode"], d["default"]["preset"], d["default"]["amount"]), (2, 0, 1.0)); self.assertEqual(d["groups"], {})


if __name__ == "__main__":
    unittest.main()
