# DS Dubstep Kit — 29 wtyczek CLAP (Bitwig, bez GUI)

Jeden silnik (`src/ds_engine.h`, mowa: `src/ds_speech.h`), wtyczki w `src/ds_plugin.cpp`. Bitwig rysuje generyczne suwaki z parametrów.

| # | Wtyczka | Rola | Cecha charakterystyczna |
|---|---------|------|-------------------------|
| 1 | DS Sub     | sub bas (sinus, mono)        | glide, warstwa sub -1 oct, miękki drive |
| 2 | DS Wobble  | wobble bas                   | LFO filtra zsynchronizowane do tempa (2/1 … 1/32, trioly, kropkowane), 5 kształtów LFO |
| 3 | DS Reese   | reese / bas rozstrojony      | unison do 7 pił, detune do 100 ct, wolny ruch filtra |
| 4 | DS Growl   | growl / yoi                  | FM + filtr formantowy A-E-I-O-U modulowany LFO |
| 5 | DS Screech | lead / screech               | FM + unison + scoop pitch + obwiednia filtra |
| 6 | DS Kick    | stopa                        | pitch envelope, klik szumowy, drive |
| 7 | DS Snare   | werbel / clap                | korpus + szum HP, 1–5 burstów (clap) |
| 8 | DS Hat     | hat / perkusjonalia          | 6 oscylatorów "metal" (808) + szum, HP, choke (mono) |

**v2: 16 dodatkowych instrumentów (łącznie 24, ten sam silnik):**
Perkusja: DS Clap (szum z burstami HP+LP), DS Rim, DS Tom (keytrack, do fillów), DS Crash (metal + długi szum), DS Shaker.
Bas: DS Neuro (rozstrojone piły + formanty + FM, szybkie LFO), DS FM Bass (LFO na indeksie FM), DS Hollow (pulse-width + wobble).
Synth/lead: DS Supersaw (7 pił, szeroki), DS Pluck, DS Pad, DS Stab, DS Vox (formanty samogłosek, „chop” bez sampli).
FX: DS Riser (rampa pitch/cutoff/level), DS Boom (impact), DS Zap (laserowy zjazd).
Nowe parametry silnika (dopisane na końcu, ID starych bez zmian): Tone Level, Noise Lowpass, Ramp Time/Cutoff/Pitch/Level, Pulse Width.
Pluck/Stab/Vox zawsze retriggerują obwiednię (bez legato).

Wspólne: 6 kształtów fali (Sine, Triangle, Saw, Square, Noise, Metal) z płynnym morphem do kolejnego kształtu,
ADSR (czasy logarytmiczne), glide, tune/fine, unison, wygładzanie wszystkich parametrów (5 ms, bez „zipper noise"),
zapis stanu w projekcie Bitwiga. Wszystkie wtyczki są jednogłosowe (mono, legato dla basów; perkusja zawsze retrigger/choke).
Perkusja ma Key Track = 0 (nuta nie zmienia wysokości; podnieś Key Track, żeby grać nią melodycznie).
Poza zakresem (jak chciałeś): EQ, kompresja, reverb, delay — zewnętrznymi wtyczkami. Filtr w silniku jest tylko
„charakterystyczny" (wobble/growl/reese/screech/hat).

## Budowa (Linux)
    make            # build/DS-*.clap (8 osobnych) + build/DubstepKit.clap (wszystkie 8 w jednym pliku)
    make test       # mini-host: ładuje, gra nuty, sprawdza NaN/peak, zapisuje demo/*.wav
    make install    # kopiuje DS-*.clap do ~/.clap/
Bitwig: Settings → Locations → Plug-in locations → dodaj ~/.clap (jeśli nie ma), przeskanuj.
Nie instaluj naraz DubstepKit.clap i DS-*.clap (duplikaty ID).

## Dodanie nowego brzmienia
Dopisz wpis w `types()` w `ds_engine.h` (lista `ex` = parametry widoczne + defaulty, `hid` = stałe ukryte)
i podnieś `COUNT` w `ds_plugin.cpp`.

---

# DS Dubstep Studio (generator + host + biblioteka + auto-remix)

Aplikacja w Pythonie (PyQt6), która sama układa dubstep na 8 ścieżkach i renderuje go **przez te 8 wtyczek CLAP**
(hostowanie robi `build/dsrender` — mały offline-host w C++ z automatyzacją parametrów, próbkowo dokładnymi nutami i tempem hosta dla LFO sync).

## Start
    make                      # wtyczki + host (build/dsrender)
    pip install PyQt6 numpy   # + ffmpeg w systemie (MP3) i dowolny odtwarzacz: pw-play/paplay/aplay/ffplay/mpv
    ./ds-studio               # GUI
CLI: `./ds-studio gen --style Riddim --bars 96 --seed 7 --save`, `./ds-studio list`, `./ds-studio remix ID_MASTER ID_B ID_C --bpm 142 --key 3`.
Biblioteka: `~/DubstepStudio/library/` (zmień przez `DS_LIBRARY`); CLI: `gen --instruments all|core8|style|kick,sub,pad`. Wtyczki szukane w `build/`, `~/.clap`, `$DS_PLUGIN_DIR`.

## Zakładki
* **Generator** — wybór instrumentów (drzewo 24 wtyczek; domyślnie paleta stylu: 8 podstawowych + 6–10 dodatkowych; „Wszystkie 24”), styl (Brostep 140 / Riddim 140 / Tearout 150 / Melodic 140 / Deep 140), BPM, tonacja + skala (minor/phrygian/harmonic minor),
  długość w taktach, energia, gęstość, swing, seed. Generuje strukturę (intro/build/drop/break/outro), progresję akordów, wzory 8 ścieżek
  i losowe brzmienia. Podgląd renderuje ścieżki równolegle (cache: zmiana jednej ścieżki = render tylko jej). „Zapisz” → folder w bibliotece:
  `project.dsproj` (JSON, wszystko edytowalne), `track.mid` (8 ścieżek/kanałów), `track.mp3` (lub wav bez ffmpeg), opcjonalnie `stems/`.
* **Ścieżki / parametry** — „＋ Dodaj instancję” (dowolna z 24 wtyczek, także kilka kopii tej samej, np. wobble2) i „－ Usuń ścieżkę”; mute/solo/gain, suwaki wszystkich parametrów danej wtyczki, „losuj brzmienie / wzór nut” per ścieżka.
* **Linki** — przekazywanie parametrów między ścieżkami: źródło (`kick`/`snare`/`hat` = akcent z obwiednią release, `energy`, `build`, `bar_phase`,
  `bass_note`) → dowolny parametr dowolnej ścieżki z ilością −1…1. Domyślnie m.in. kick→Level basów (sidechain), build→Cutoff screecha,
  snare→FM screecha, bass_note→Vowel growla, energy→Cutoff reese. Dodatkowo zmiany LFO Division (stepped) są automatyzowane per sekcja.
* **Biblioteka** — lista, odtwarzanie, wczytanie do edytora, usuwanie, „→ Do auto-remixu”.
* **Auto-remix** — wiersze = wszystkie instrumenty/instancje z zaznaczonych utworów; dla każdego wskazujesz źródło albo „wył.” (albo „Auto-remix” losuje). Master daje strukturę,
  progresję i linki; nuty/brzmienie biorę ze źródeł **sekcja po sekcji** (drop z dropem, build z buildem; zapętlane/przycinane do długości mastera),
  a ścieżki melodyczne są przesuwane takt po takcie do akordów mastera (opcja). Można nadpisać BPM i tonację. Wynik trafia do biblioteki z listą rodziców.

## Ograniczenia
* Harmonia w remiksie: przesunięcie jest po prymie akordu, więc przy innej jakości akordu (moll↔dur) możliwy półton kolizji.
* Podgląd/render offline (nie live); 144 takty renderują się w kilkanaście sekund.
* GUI testowane w trybie offscreen; odtwarzanie przez zewnętrzny odtwarzacz.


---

# DS Speak — angielska synteza mowy (wtyczka #25, opcjonalna)

Litery → fonemy → formanty F1–F3 na oscylatorach (te same przebiegi/unison/filtr co w reszcie kitu). **Nie jest w żadnej palecie domyślnej** —
zaznaczasz ją ręcznie (drzewo instrumentów, „Wszystkie”, `--instruments ...,speak` albo „Dodaj instancję”).

**Jak to działa**
1. *Analiza słowa* (`ds_speech.h`): leksykon wyjątków (słownictwo dubstepowe) + reguły G2P (dwuznaki, ciche e, długie/krótkie samogłoski, -ed, -tion…),
   akcent sylaby, redukcja samogłosek niepodkreślonych, kontur intonacji słowa (`!`/WIELKIE = okrzyk, `?` = pytanie). Wynik to lista segmentów z już „dopasowanymi” formantami, czasem i wysokością.
2. *Skala liter*: każda litera/fonem ma pozycję −1…1 na skali wysokości (naturalna wysokość samogłoski: i/u wyżej, a/o niżej). **Letter Pitch Range** rozkłada je w zakresie
   półtonów wokół wysokości nuty, **Pitch Scale** kwantyzuje do skali (moll/dur/frygijska/pentatonika), **Intonation** dodaje kontur słowa.
3. *Morphing*: między segmentami formanty, głos, szum i wysokość płynnie przechodzą (**Morph Time** = koartykulacja). Zwarcia/aspiracja przejmują formanty następnej samogłoski.
4. **Hold Vowel**: przy dłuższej nucie samogłoska akcentowana jest trzymana do note-off, potem słowo dośpiewuje końcówkę.

**Parametry (grupa Speech):** Text Advance (Sequence = nuta czyta kolejne słowo · Key Select = klawisz wybiera słowo · Letters = nuta = kolejny fonem, „litery jako oscylator”), Text Bank, Speech Speed,
Morph Time, Dialect (Neutral / Bright / Dark / Tonal / Robot — profil formantów, zakresu liter, intonacji, tempa i skali), Letter Pitch Range, Intonation, Pitch Scale, Formant Shift, Hold Vowel, Breath (szept).

**Skąd tekst:** stan projektu (zapisywany razem z wtyczką) → plik `$DS_SPEAK_TEXT_FILE`, `~/.config/ds-speak.txt` lub `~/DubstepStudio/speak.txt` (Bitwig nie ma GUI wtyczki; plik wczytywany przy aktywacji) → domyślnie „drop the bass”.
Parametr **Text Bank** przełącza też wbudowane teksty (Dubstep / Hype / Countdown) bez pliku.

**W generatorze:** panel „Mowa (DS Speak)” aktywny tylko po zaznaczeniu `speak`. *Auto* — generator układa frazy z motywu (Dubstep/Hype/Dark/Countdown, domyślnie wg stylu) na tyle słów, ile nut;
*Ręczny* — własny tekst czytany cyklicznie. Nuty: pickupy w buildach, okrzyk na początku dropa, melodyczne frazy w breakach. W zakładce „Ścieżki” ścieżka speak ma edytor tekstu (Zastosuj / Auto-tekst).
CLI: `./ds-studio gen --style Riddim --speak-text "Drop the bass! Hands up?"` (podanie tekstu/motywu dodaje speak) lub `--instruments kick,sub,speak --speak-theme Hype`.
Tekst jest częścią projektu (`text`, `text_mode`) i wędruje do remiksów; zmiana tekstu unieważnia cache renderu tej ścieżki.

**Ograniczenia:** tylko angielski; G2P regułowy (nieregularne słowa dopisz do `LEX` w `ds_speech.h`); głos syntetyczny/„robotyczny” — to formantowy syntezator, nie TTS neuronowy.


---

# v4: instrumenty akustyczne, routing, edycja grup nut, nowe style

**Nowe wtyczki (opcjonalne, nigdy w paletach domyślnych):** DS Theremin (sinus/trójkąt, długi glide, vibrato, formant „oo”), DS Pan Flute (ton + szum oddechu śledzący wysokość: *Noise Key Track*),
DS Handpan (synteza modalna, tony własne 1 : 2 : 3, *Ring Time*, *Strike Brightness*), DS Tongue Drum (tony 1 : 2,76 : 5,4 : 8,9, krótszy ring). Handpan i tongue to perkusjonalia (ignorują note-off, brzmią do końca).

**Instrument jako filtr (wejście audio):** każda wtyczka ma opcjonalny port audio „In” i parametr **Input Mix**. Gdy > 0, zewnętrzny dźwięk zastępuje/miesza źródło i przechodzi przez
filtr, formanty i obwiednię nut tego instrumentu (np. DS Speak „mówi” basem wobble; DS Theremin/Pan Flute formują wejście swoim filtrem). Nuty bramkują dźwięk. Uwaga: w DAW port wejściowy jest nieobowiązkowy.

**Routing w Studio (zakładka Ścieżki):**
* **pre — „Nuty z”**: ścieżka gra nuty innej ścieżki (+ transpozycja), np. speak czyta melodię theremina, więc inaczej brzmi niż z własnym wzorem. Łańcuchy są dozwolone.
* **post — „Wejście audio z”** + mix + „ukryj źródło w miksie”: render idzie poziomami (źródła przed odbiorcami, równolegle w poziomie), cykle są rozcinane. Cache uwzględnia cały łańcuch.
* Routing zapisuje się w projekcie (`notes_from`, `notes_transpose`, `input_from`, `input_mix`, `input_hide_source`) i wędruje do remiksów, jeśli źródło jest w remiksie. MIDI eksportuje nuty po routingu.

**Edycja grupy nut:** przeciągnij myszą po przeglądzie aranżacji (zakładka Generator), by zaznaczyć okno taktów, albo wpisz takty „od–do” w zakładce Ścieżki. Operacje (`noteops.py`):
transpozycja, oktawa góra/dół, w górę/dół po stopniach skali, przyciągnij do skali (projektu, moll, dur, frygijska, dorycka, pentatoniki, blues, chromatyczna), losowe wysokości w skali,
odwrócenie w czasie (backward), lustro wysokości, wysokości rosnąco/malejąco (up/down), przetasowanie wysokości / rytmu / wszystkiego, rotacja, rozciągnięcie, humanizacja, przerzedzenie, powtórzenie okna. Jest „Cofnij”.

**Nowe style:** Dubstep (140, klasyczny halftime), Drumstep (174, werbel na 2 i 4, szybkie frazy), Trap (140, hi-haty z rollami 1/32, 808 podążający za stopą z glide), EDM (128, kick four-on-the-floor, clap na 2 i 4, mocny pumping sidechain).
Generatory partii dla nowych instrumentów: theremin (długie frazy w breakach/buildach), flet (pentatoniczne frazy), handpan (arpeggia 1/8), tongue drum (rzadkie pentatoniczne uderzenia).
