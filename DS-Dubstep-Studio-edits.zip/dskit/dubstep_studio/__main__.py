"""python3 -m dubstep_studio            -> GUI
   python3 -m dubstep_studio gen ...   -> generuj z CLI (--style --bpm --bars --seed --key --save)
   python3 -m dubstep_studio list      -> lista biblioteki
   python3 -m dubstep_studio remix A B C [--bpm N] [--key 0-11]  (ID folderów z biblioteki; pierwszy = master)"""
import argparse
import random
import sys

from . import core, generator as G, remix as R


def main():
    if len(sys.argv) < 2 or sys.argv[1] == "gui":
        from .gui import main as gui_main
        return gui_main()
    ap = argparse.ArgumentParser(prog="dubstep_studio")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("gen"); g.add_argument("--style", default="Brostep", choices=list(G.STYLES)); g.add_argument("--bpm", type=int)
    g.add_argument("--bars", type=int, default=144); g.add_argument("--seed", type=int); g.add_argument("--key", type=int)
    g.add_argument("--instruments", default="style", help="style | core8 | all | lista,po,przecinku"); g.add_argument("--scale", default="minor", choices=list(core.SCALES)); g.add_argument("--save", action="store_true")
    g.add_argument("--speak-text", default=None, help="ręczny tekst DS Speak (włącz instrument: --instruments style,speak lub ...,speak)")
    g.add_argument("--speak-theme", default=None, choices=list(G.SPEAK_THEMES), help="motyw tekstu auto")
    sub.add_parser("list")
    r = sub.add_parser("remix"); r.add_argument("ids", nargs="+"); r.add_argument("--bpm", type=int); r.add_argument("--key", type=int)
    r.add_argument("--seed", type=int)
    a = ap.parse_args(sys.argv[1:])
    if a.cmd == "gen":
        inst = {"style": None, "core8": core.CORE8, "all": core.available_types()}.get(a.instruments) or a.instruments.split(",")
        if a.instruments == "style" and (a.speak_text or a.speak_theme):
            inst = G.default_instruments(a.style) + ["speak"]       # podanie tekstu włącza mowę
        p = G.generate(a.style, bpm=a.bpm, key=a.key, scale=a.scale, bars=a.bars, seed=a.seed, instruments=inst,
                       speak_text=a.speak_text, speak_theme=a.speak_theme)
        print(f"{p['name']}: {core.key_name(p)} {p['bpm']} BPM {p['bars']} taktów")
        if a.save:
            print(core.save_to_library(p))
    elif a.cmd == "list":
        for e in core.list_library():
            print(f"{e['path'].name}\t{e['style']}\t{e['bpm']}\t{e['key']}\t{e['bars']}")
    elif a.cmd == "remix":
        projs = []
        for i in a.ids:
            p = core.load_project(core.lib_dir() / i); p["id"] = i; projs.append(p)
        master = projs[0]
        if len(projs) > 1:
            _, assign = R.auto_assign(projs, random.Random(a.seed))
        else:
            assign = {t["name"]: master for t in master["tracks"]}
        out = R.remix(assign, master, bpm=a.bpm, key=a.key, seed=a.seed or 0)
        print({t: (x["id"] if x else None) for t, x in assign.items()}); print(core.save_to_library(out))


if __name__ == "__main__":
    sys.exit(main() or 0)
