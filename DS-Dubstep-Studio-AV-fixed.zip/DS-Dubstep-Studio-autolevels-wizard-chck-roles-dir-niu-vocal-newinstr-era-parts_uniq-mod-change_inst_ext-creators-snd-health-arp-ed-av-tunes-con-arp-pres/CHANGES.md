# DS Dubstep Studio AV — poprawki 1–9 z przeglądu kodu (już naniesione)

To jest pełna paczka projektu z poprawkami naniesionymi. Zmienione pliki: `dubstep_studio/{arp_engine,core,director,eco,generator,gui,live,niuanse,remix}.py`;
nowy plik: `tests/test_fixes.py`. Pozostałe pliki, w tym `build/` (kod C++ nie był ruszany), są identyczne jak w wersji wyjściowej;
pominięto tylko katalogi `__pycache__` (Python odtworzy je przy pierwszym uruchomieniu).

Testy (czysta logika działa bez hosta; reszta wymaga `make`, test GUI także PyQt6):

    python3 -m unittest tests.test_fixes -v

## Co zmieniono

1. **gui.py `_preview_extra_or_timbre`** — `render_stems` zwraca słownik tablic numpy, a funkcja traktowała je jak ścieżki plików
   (`ValueError`, podsłuch extras/barw nigdy nie grał). Teraz: `mix_stems` → `ds_studio_sample.wav` → `player.play`.
2. **Klucze MIDI poza 0..127** — przyczyna: `niuanse._snap` przy przejściu B→C przesuwał nutę o −11 zamiast +1 (trzy kroki = −36,
   stąd nuta −12 i `ValueError` w `write_midi`). Poprawiony `_snap`; dodatkowo `core.fold_key/clamp_vel/sanitize_notes`
   (zawijanie o oktawy, velocity 1..127) w `_write_job`, `write_midi` oraz na końcu `generate`, `reroll_track`, `remix`.
3. **arp_engine.structural_inject** — `hash(nazwa)` zastąpione `zlib.crc32`; ten sam seed daje teraz ten sam projekt
   niezależnie od `PYTHONHASHSEED` (przed: 25 z 90 projektów różniło się między uruchomieniami).
4. **live.plan_next** — `randint(2, 1)` przy dokładnie jednym dostępnym extra → `min(len(ex), …)`.
5. **director.apply_roles / _retune** — ścieżki z `lock_notes` nie biorą udziału w zamianach ról, a `lock_sound` / `locked_params["Cutoff"]`
   blokuje retuning barwy (tak jak w `generator.apply_role_swaps`). Usunięte puste wywołania `_put(…, bn_[:0], …)`.
6. **live._gen_extras_from_base** — pakiet złożoności może tylko podnieść siłę niuansów/uniq ustawioną w Generatorze (`max`),
   nie nadpisuje jej; `autolevels` bez klucza w base domyślnie `False` (jak w config.txt i `generate`).
7. **eco.py** — `_next_no`: `flock` + zapis atomowy (8 procesów × 300 wywołań: 70 → 2400 unikalnych numerów);
   `_encode`: brak osieroconych `.part` i czytelny błąd przy zerwanym potoku do ffmpeg; `preroll`: jedna instancja na katalog
   (drugi proces kończy z wynikiem 0) i sprzątanie starych `.part`. W katalogu preroll pojawiają się pliki `.counter.lock` i `.preroll.lock`.
8. **core.cleanup_stale_work** — usuwa wyłącznie katalogi o nazwie z `mkdtemp` (`dsr<pid>_xxxxxxxx`, `dsr_xxxxxxxx`);
   cudze, np. `dsrender-build`, zostają. Dowiązania symboliczne są pomijane.
9. **core.render_stems** — po renderze cache przycinany do kluczy bieżącego stanu (przed: +~100 MB na każdą edycję przy 144 taktach);
   niezmienione ścieżki nadal nie są renderowane ponownie.

## Zmiany zachowania, o których warto wiedzieć

- Projekty z włączonymi niuansami lub arp-inject będą dla tego samego seeda inne niż przed poprawką (naprawione źródła błędów); zapisane projekty bez zmian.
- `--preset` (Live/ECO) nie włącza już domyślnie autolevels — preset ich nie przechowuje (pozycja 10 z przeglądu, poza tą paczką).
- Po edycji ścieżki powrót do jej wcześniejszego stanu (undo) renderuje ją ponownie.

## Weryfikacja

16 testów: na kodzie oryginalnym 15 pada, po poprawkach wszystkie przechodzą. Fuzzing 150 + 240 projektów (30 stylów, losowe opcje):
0 wyjątków, 0 naruszeń zakresu MIDI. Podsłuch GUI sprawdzony na prawdziwym `MainWindow` (offscreen). Przebieg `preroll` end-to-end (2 pliki WAV) działa.

## Poza tą paczką (pozycje 10–17 z przeglądu)

Kompletność presetów / `GenOptions`, SIGHUP + `--preset`, utwardzenie config/Icecast, diagnostyka `Meta`, rozbicie `generate()`,
martwy kod w generator.py, `timeout` dla dsrender, aktualizacja README (32 wtyczki).
