"""gui.py — DS Dubstep Studio (PyQt6): generator, ścieżki/parametry, linki, biblioteka, auto-remix."""
from __future__ import annotations

import copy
import os
import random
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets as W
from PyQt6.QtCore import Qt

from . import core, generator as G, live as L, noteops as N, presets as PR, remix as R, styles as ST
from .board_gui import BoardTab
from .live_gui import LiveTab

GROUP_COL = {"Perkusja": "#e5484d", "Bas": "#2dd4bf", "Synth / lead": "#c4b5fd", "FX": "#f5a524", "Mowa": "#60a5fa", "Akustyczne": "#34d399"}


def tcolor(ttype):
    for g, ts in core.GROUPS.items():
        if ttype in ts:
            c = QtGui.QColor(GROUP_COL[g])
            i = ts.index(ttype)
            return c.lighter(100 + min(8, i) * 5) if i % 2 else c.darker(100 + min(8, i) * 4)
    return QtGui.QColor("#9ca3af")
SECCOL = {"intro": "#1f2937", "build": "#3b2f12", "drop": "#3a1217", "break": "#12303a", "outro": "#1f2937"}


class Worker(QtCore.QThread):
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(str)
    prog = QtCore.pyqtSignal(float)

    def __init__(self, fn):
        super().__init__(); self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(self.prog.emit))
        except Exception:
            self.fail.emit(traceback.format_exc())


class Player:
    def __init__(self):
        self.proc = None; self.t0 = 0.0

    def play(self, path):
        self.stop()
        ext = str(path).lower().rsplit(".", 1)[-1]
        order = (["ffplay", "mpv", "pw-play", "paplay", "aplay"] if ext == "mp3" else ["pw-play", "paplay", "aplay", "ffplay", "mpv"])
        dev = os.environ.get("DS_AUDIO_DEVICE", "").strip()      # to samo urządzenie co w Live ([live] audio_device)
        args = {"ffplay": ["-nodisp", "-autoexit", "-loglevel", "quiet"], "mpv": ["--no-video", "--really-quiet"] + ([f"--audio-device={dev}"] if dev else []),
                "aplay": ["-q"] + (["-D", dev] if dev else []), "pw-play": ["--target", dev] if dev else [], "paplay": [f"--device={dev}"] if dev else []}
        for c in order:
            exe = shutil.which(c)
            if exe and (c not in ("pw-play", "paplay") or L.StreamPlayer.usable("pw-cat" if c == "pw-play" else "paplay")):
                self.proc = subprocess.Popen([exe] + args.get(c, []) + [str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.t0 = time.time()
                return True
        return False

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
        self.proc = None

    def elapsed(self):
        return time.time() - self.t0 if self.proc and self.proc.poll() is None else None


class Overview(W.QWidget):
    """Podgląd aranżacji: pasy z nutami + sekcje + playhead. Przeciągnięcie myszą zaznacza okno taktów (do edycji grupy nut)."""
    selChanged = QtCore.pyqtSignal(int, int)

    def __init__(self):
        super().__init__(); self.proj = None; self.head = None; self.sel = None; self._drag = None; self.setMinimumHeight(230)

    def _bar_at(self, x):
        p = self.proj
        if not p or not p["bars"]:
            return 0
        return max(0, min(p["bars"] - 1, int((x - 66) / max(1, self.width() - 70) * p["bars"])))

    def mousePressEvent(self, e):
        self._drag = self._bar_at(e.position().x()); self.sel = (self._drag, self._drag + 1)
        self.selChanged.emit(*self.sel); self.update()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            b = self._bar_at(e.position().x()); self.sel = (min(self._drag, b), max(self._drag, b) + 1)
            self.selChanged.emit(*self.sel); self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def set_project(self, p):
        self.proj = p; self.setMinimumHeight(max(230, 16 * len(p["tracks"]) + 30) if p else 230); self.update()

    def paintEvent(self, ev):
        qp = QtGui.QPainter(self); qp.fillRect(self.rect(), QtGui.QColor("#0f1115"))
        p = self.proj
        if not p or not p["bars"]:
            return
        w, h, top = self.width() - 70, self.height() - 22, 18
        beats = p["bars"] * 4; lane = h / max(1, len(p["tracks"]))
        for s in p["sections"]:
            x0 = 66 + s["start"] * 4 / beats * w; x1 = 66 + (s["start"] + s["bars"]) * 4 / beats * w
            qp.fillRect(QtCore.QRectF(x0, top, x1 - x0, h), QtGui.QColor(SECCOL[s["type"]]))
            qp.setPen(QtGui.QColor("#9ca3af")); qp.drawText(QtCore.QPointF(x0 + 3, 12), s["name"])
        for i, t in enumerate(p["tracks"]):
            y0 = top + i * lane
            qp.setPen(tcolor(t["type"])); qp.drawText(QtCore.QPointF(4, y0 + min(lane * 0.8, 12)), t["name"])
            qp.setPen(QtGui.QColor("#1b1f27")); qp.drawLine(66, int(y0 + lane), 66 + int(w), int(y0 + lane))
            if not t["notes"]:
                continue
            ks = [n[2] for n in t["notes"]]; lo, hi = min(ks), max(ks); rng = max(1, hi - lo)
            nh = max(1.5, min(6.0, (lane - 3) / (rng + 1)))
            col = QtGui.QColor(tcolor(t["type"])); col.setAlpha(120 if t["mute"] else 230)
            for on, dur, key, vel in t["notes"]:
                x = 66 + on / beats * w
                y = y0 + 2 + (lane - 4 - nh) * (1 - (key - lo) / rng)
                qp.fillRect(QtCore.QRectF(x, y, max(1.2, dur / beats * w), nh), col)
        if self.sel:
            x0 = 66 + self.sel[0] * 4 / beats * w; x1 = 66 + self.sel[1] * 4 / beats * w
            qp.fillRect(QtCore.QRectF(x0, top, max(2.0, x1 - x0), h), QtGui.QColor(255, 255, 255, 45))
            qp.setPen(QtGui.QColor("#ffffff")); qp.drawRect(QtCore.QRectF(x0, top, max(2.0, x1 - x0), h))
        if self.head is not None:
            x = 66 + min(1.0, self.head / beats) * w
            qp.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 1)); qp.drawLine(int(x), top, int(x), top + int(h))



class StyleCreatorDialog(W.QDialog):
    """Kreator stylu: baza predefiniowana → korekta / randomizacja → zapis własnego stylu."""

    HATS = ["16", "8", "trap", "offbeat", "off", "ride", "none"]
    WOBS = ["brostep", "riddim", "tearout", "melodic", "deep", "techno", "hard", "acid", "roll", "ambient", "seq", "classic", "baroque"]
    GROWLS = ["brostep", "riddim", "tearout", "melodic", "deep", "neurof"]
    REESE = ["none", "late", "all"]
    LEADS = ["none", "rare", "accent", "melodic"]
    SUBS = ["hold", "offbeat", "roll", "pulse8", "funk", "walk", "off"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Kreator stylu")
        self.setMinimumSize(640, 560)
        self._knobs = {}
        self._base_name = "Brostep"
        lay = W.QVBoxLayout(self)
        row = W.QHBoxLayout()
        row.addWidget(W.QLabel("Baza:"))
        self.base = W.QComboBox(); self.base.addItems(list(ST.ORDER))
        self.base.currentTextChanged.connect(self.load_base)
        row.addWidget(self.base, 1)
        b_load = W.QPushButton("Wczytaj bazę"); b_load.clicked.connect(lambda: self.load_base(self.base.currentText()))
        b_rnd = W.QPushButton("Randomizuj"); b_rnd.setToolTip("Losuje pokrętła wokół aktualnej bazy")
        b_rnd.clicked.connect(self.randomize)
        row.addWidget(b_load); row.addWidget(b_rnd)
        lay.addLayout(row)
        form = W.QFormLayout()
        self.name = W.QLineEdit(); self.name.setPlaceholderText("Nazwa nowego stylu (np. MyTear)")
        self.bpm = W.QSpinBox(); self.bpm.setRange(60, 200)
        self.swing = W.QDoubleSpinBox(); self.swing.setRange(0, 0.2); self.swing.setSingleStep(0.01)
        self.hat = W.QComboBox(); self.hat.addItems(self.HATS)
        self.wob = W.QComboBox(); self.wob.addItems(self.WOBS)
        self.growl = W.QComboBox(); self.growl.addItems(self.GROWLS)
        self.reese = W.QComboBox(); self.reese.addItems(self.REESE)
        self.lead = W.QComboBox(); self.lead.addItems(self.LEADS)
        self.sub_mode = W.QComboBox(); self.sub_mode.addItems(self.SUBS)
        self.chord_len = W.QSpinBox(); self.chord_len.setRange(1, 8)
        self.cls = W.QDoubleSpinBox(); self.cls.setRange(0, 5); self.cls.setSingleStep(0.5)
        self.cls.setToolTip("Klasa ostrości 0 (łagodny) … 5 (agresywny) — STYLE_CLASS")
        for lbl, w in (("Nazwa stylu", self.name), ("BPM", self.bpm), ("Swing", self.swing), ("Hat", self.hat),
                       ("Wobble", self.wob), ("Growl", self.growl), ("Reese", self.reese), ("Lead", self.lead),
                       ("Sub mode", self.sub_mode), ("Chord len", self.chord_len), ("Ostrość (0–5)", self.cls)):
            form.addRow(lbl, w)
        lay.addLayout(form)
        # instrumenty
        ig = W.QGroupBox("Core / Extras (zaznacz)"); il = W.QHBoxLayout(ig)
        self.core_list = W.QListWidget(); self.core_list.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        self.ex_list = W.QListWidget(); self.ex_list.setSelectionMode(W.QAbstractItemView.SelectionMode.MultiSelection)
        for t_ in core.TYPES:
            if t_ in core.OPTIONAL:
                continue
            self.core_list.addItem(t_); self.ex_list.addItem(t_)
        il.addWidget(W.QLabel("Core:")); il.addWidget(self.core_list, 1)
        il.addWidget(W.QLabel("Extras:")); il.addWidget(self.ex_list, 1)
        lay.addWidget(ig)
        self.preview = W.QPlainTextEdit(); self.preview.setReadOnly(True); self.preview.setMaximumHeight(100)
        lay.addWidget(self.preview)
        btns = W.QHBoxLayout()
        b_apply = W.QPushButton("Zastosuj w Generatorze (bez zapisu)")
        b_save = W.QPushButton("Zapisz styl")
        b_del = W.QPushButton("Usuń zapisany")
        b_close = W.QPushButton("Zamknij")
        b_apply.clicked.connect(self.apply_to_gen)
        b_save.clicked.connect(self.save_style)
        b_del.clicked.connect(self.delete_style)
        b_close.clicked.connect(self.reject)
        for b in (b_apply, b_save, b_del, b_close):
            btns.addWidget(b)
        lay.addLayout(btns)
        self.load_base(self.base.currentText())

    def _selected(self, lw):
        return [it.text() for it in lw.selectedItems()]

    def _select(self, lw, names):
        names = set(names)
        for i in range(lw.count()):
            it = lw.item(i)
            it.setSelected(it.text() in names)

    def load_base(self, name=None):
        name = name or self.base.currentText()
        self._base_name = name
        try:
            cfg = G.STYLES[name]
        except KeyError:
            return
        k = ST.style_knobs_from(cfg)
        self._set_knobs(k)
        if not self.name.text().strip():
            self.name.setText(f"{name} Custom")
        self._refresh_preview()

    def _set_knobs(self, k):
        self.bpm.setValue(int(k.get("bpm", 140)))
        self.swing.setValue(float(k.get("swing", 0.0)))
        for cb, key, pool in ((self.hat, "hat", self.HATS), (self.wob, "wob", self.WOBS), (self.growl, "growl", self.GROWLS),
                              (self.reese, "reese", self.REESE), (self.lead, "lead", self.LEADS), (self.sub_mode, "sub_mode", self.SUBS)):
            v = k.get(key, pool[0])
            if v in pool:
                cb.setCurrentText(v)
        self.chord_len.setValue(int(k.get("chord_len", 2)))
        self.cls.setValue(float(k.get("_class", 2.5)))
        self._select(self.core_list, k.get("core") or [])
        self._select(self.ex_list, k.get("extras") or [])
        self._knobs = k

    def _gather(self):
        k = dict(self._knobs)
        k.update(bpm=self.bpm.value(), swing=self.swing.value(), hat=self.hat.currentText(), wob=self.wob.currentText(),
                 growl=self.growl.currentText(), reese=self.reese.currentText(), lead=self.lead.currentText(),
                 sub_mode=self.sub_mode.currentText(), chord_len=self.chord_len.value(),
                 core=self._selected(self.core_list), extras=self._selected(self.ex_list),
                 _class=self.cls.value())
        return k

    def _refresh_preview(self):
        k = self._gather()
        self.preview.setPlainText(
            f"BPM {k['bpm']}  swing {k['swing']}  hat={k['hat']} wob={k['wob']} growl={k['growl']}\n"
            f"reese={k['reese']} lead={k['lead']} sub={k['sub_mode']} chord_len={k['chord_len']} ostrość={k['_class']}\n"
            f"core: {', '.join(k['core'])}\nextras: {', '.join(k['extras'])}"
        )

    def randomize(self):
        k = ST.randomize_style_knobs(self._base_name, G.STYLES, random.Random())
        self._set_knobs(k)
        self._refresh_preview()

    def apply_to_gen(self):
        k = self._gather()
        name = self.name.text().strip() or f"{self._base_name} Custom"
        try:
            base_cfg = dict(G.STYLES[self._base_name])
        except KeyError:
            base_cfg = None
        cfg = ST.build_style_cfg(k, base_cfg)
        G.STYLES[name] = cfg
        ST.STYLE_CLASS[name] = float(k.get("_class", 2.5))
        ST.STYLE_COL.setdefault(name, k.get("_color", "#a78bfa"))
        if name not in ST.ORDER:
            ST.ORDER.append(name)
        mw = self.parent()
        if mw and hasattr(mw, "style"):
            if mw.style.findText(name) < 0:
                mw.style.addItem(name)
            mw.use_style(name)
            # ustaw instrumenty z core+extras
            mw.set_instruments(list(cfg.get("core", [])) + list(cfg.get("extras", [])))
            if hasattr(mw, "bpm"):
                mw.bpm.setValue(int(cfg.get("bpm", 140)))
            mw.status.setText(f"Kreator: zastosowano styl „{name}” w Generatorze (niezapisany na dysk, dopóki nie Zapisz)")
        self._refresh_preview()

    def save_style(self):
        k = self._gather()
        name = self.name.text().strip()
        if not name:
            W.QMessageBox.information(self, "Kreator", "Podaj nazwę stylu."); return
        try:
            base_cfg = dict(G.STYLES[self._base_name])
        except KeyError:
            base_cfg = None
        cfg = ST.build_style_cfg(k, base_cfg)
        ST.save_custom_style(name, cfg)
        G.STYLES[name] = cfg
        ST.STYLE_CLASS[name] = float(k.get("_class", 2.5))
        ST.STYLE_COL.setdefault(name, "#a78bfa")
        if name not in ST.ORDER:
            ST.ORDER.append(name)
        mw = self.parent()
        if mw and hasattr(mw, "style") and mw.style.findText(name) < 0:
            mw.style.addItem(name)
        W.QMessageBox.information(self, "Kreator", f"Zapisano styl „{name}”\n{ST.custom_styles_path()}")
        self._refresh_preview()

    def delete_style(self):
        name = self.name.text().strip()
        if not name:
            return
        ST.delete_custom_style(name)
        W.QMessageBox.information(self, "Kreator", f"Usunięto „{name}” z pliku użytkownika (wbudowane style zostają).")


class MainWindow(W.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DS Dubstep Studio")
        self.resize(1180, 820)
        self.meta = core.meta()
        self.proj = None; self.cache = {}; self.player = Player(); self.worker = None
        self.style_override = None   # nazwa hybrydy (z pola szachowego / projektu) zamiast stylu z listy
        self.remix_entries = []   # [(path, proj)]
        tabs = W.QTabWidget(); self.setCentralWidget(tabs)
        tabs.addTab(self._build_gen(), "Generator")
        self.board = BoardTab(self); tabs.addTab(self.board, "Pole stylów (hybrydy)")
        tabs.addTab(self._build_tracks(), "Ścieżki / parametry")
        tabs.addTab(self._build_links(), "Linki (przekazywanie)")
        tabs.addTab(self._build_lib(), "Biblioteka")
        tabs.addTab(self._build_remix(), "Auto-remix")
        self.live = LiveTab(self)
        tabs.addTab(self.live, "Live / Endless")
        self.tabs = tabs
        self.undo = {}
        self.ov.selChanged.connect(self._ov_sel)
        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(40)
        self.refresh_library()
        self.on_style(self.cur_style())
        self.live.apply_conf(self.live.conf)      # config.txt wygrywa z domyślnymi stylu
        self.refresh_presets()

    # ------------------------------------------------------------------ Generator
    def _build_gen(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        pb = W.QHBoxLayout(); pb.addWidget(W.QLabel("Preset:"))
        self.preset_cb = W.QComboBox(); self.preset_cb.setMinimumWidth(220); pb.addWidget(self.preset_cb, 1)
        for txt, fn in (("Wczytaj", self.preset_load), ("Zapisz jako…", self.preset_save), ("Usuń", self.preset_delete), ("Eksportuj…", self.preset_export), ("Importuj…", self.preset_import)):
            b = W.QPushButton(txt); b.clicked.connect(fn); pb.addWidget(b)
        v.addLayout(pb)
        f = W.QFormLayout()
        self.style = W.QComboBox(); self.style.addItems(ST.ORDER + [s_ for s_ in G.STYLES if s_ not in ST.ORDER]); self.style.currentTextChanged.connect(self._combo_style)
        self.style_lbl = W.QLabel(""); self.style_lbl.setWordWrap(True)
        self.b_style_creator = W.QPushButton("Kreator stylu…")
        self.b_style_creator.setToolTip("Konstruktor: baza predefiniowana → korekta / randomizacja → zapis własnego stylu")
        self.b_style_creator.clicked.connect(self.open_style_creator)
        self.bpm = W.QSpinBox(); self.bpm.setRange(60, 200)
        self.keyc = W.QComboBox(); self.keyc.addItems(["losowa"] + core.NOTE_NAMES)
        self.scale = W.QComboBox(); self.scale.addItems(core.SCALES.keys())
        self.bars = W.QSpinBox(); self.bars.setRange(32, 256); self.bars.setSingleStep(8); self.bars.setValue(144)
        self.energy = self._slider(70); self.density = self._slider(60); self.swing = self._slider(0)
        self.seed = W.QSpinBox(); self.seed.setRange(0, 999999); self.rndseed = W.QCheckBox("losuj seed"); self.rndseed.setChecked(True)
        self.name = W.QLineEdit(); self.name.setPlaceholderText("(opcjonalnie) nazwa utworu")
        stw = W.QWidget()
        sw = W.QVBoxLayout(stw); sw.setContentsMargins(0, 0, 0, 0)
        sw.addWidget(self.style); sw.addWidget(self.style_lbl); sw.addWidget(self.b_style_creator)
        seed_w = W.QWidget(); seed_l = W.QHBoxLayout(seed_w); seed_l.setContentsMargins(0, 0, 0, 0)
        seed_l.addWidget(self.seed); seed_l.addWidget(self.rndseed)
        # niuanse + spektakularność (poniżej swing)
        self.niu_on = W.QCheckBox("Niuanse artykulacji")
        self.niu_on.setToolTip(
            "Po generacji wzorów: reguły na partiach nut —\n"
            "przesunięcia skali (początek/środek/koniec), arp trigger,\n"
            "duo interwałowe, monotone seq, zaniki/wzmocnienia velocity,\n"
            "ghost notes, stutter… Siła −1…+1 (ujemna = uproszczenie)."
        )
        self.niu_str = W.QSlider(Qt.Orientation.Horizontal)
        self.niu_str.setRange(-100, 100); self.niu_str.setValue(0)
        self.niu_str_lbl = W.QLabel("0.00")
        self.niu_str.valueChanged.connect(lambda v: self.niu_str_lbl.setText(f"{v/100:+.2f}"))
        niu_w = W.QWidget(); niu_l = W.QHBoxLayout(niu_w); niu_l.setContentsMargins(0, 0, 0, 0)
        niu_l.addWidget(self.niu_on); niu_l.addWidget(self.niu_str, 1); niu_l.addWidget(self.niu_str_lbl)
        self.uniq_on = W.QCheckBox("Niepowtarzalność segmentów")
        self.uniq_on.setToolTip(
            "Po niuansach: receptury per intro/build/break/outro (rolki, cisze, echo…),\n"
            "mikro-wariacje w powtarzających się taktach, korekta podobieństwa\n"
            "między segmentami tego samego typu (build2 ≠ build1)."
        )
        self.uniq_str = W.QSlider(Qt.Orientation.Horizontal)
        self.uniq_str.setRange(0, 100); self.uniq_str.setValue(60)
        self.uniq_str_lbl = W.QLabel("0.60")
        self.uniq_str.valueChanged.connect(lambda v: self.uniq_str_lbl.setText(f"{v/100:.2f}"))
        self.uniq_drops = W.QCheckBox("także dropy")
        self.uniq_drops.setToolTip("Lekkie mikro-wariacje także w sekcjach drop (ghost/accent/flam).")
        uniq_w = W.QWidget(); uniq_l = W.QHBoxLayout(uniq_w); uniq_l.setContentsMargins(0, 0, 0, 0)
        uniq_l.addWidget(self.uniq_on); uniq_l.addWidget(self.uniq_str, 1); uniq_l.addWidget(self.uniq_str_lbl); uniq_l.addWidget(self.uniq_drops)
        self.spectacle = W.QComboBox()
        from . import niuanse as NIU
        from . import era_profiles as ERA
        for key in ("monotone", "plain", "balanced", "vivid", "anthem"):
            self.spectacle.addItem(NIU.SPECTACLE_LABELS[key], key)
        self.spectacle.setCurrentIndex(2)
        self.spectacle.setToolTip(
            "Spektakularność aranżacji: od monotonicznej (mało warstw)\n"
            "do anthem (wiele instancji lead/bas/pad, bogatsze niuanse)."
        )
        self.era = W.QComboBox()
        for key in ERA.ERA_ORDER:
            self.era.addItem(ERA.ERA_LABELS[key], key)
        self.era.setCurrentIndex(0)
        self.era.setToolTip(
            "Zasób epoki (nie marki syntezatorów):\n"
            "Minimal 70s ≈ mało torów, proste sekwencje (Kraftwerk-ish)\n"
            "… aż do Maximal now = gęsty DAW (wiele warstw, współczesne typy).\n"
            "Auto = mapowanie ze stylu."
        )
        for lbl, wd in [("Styl", stw), ("BPM", self.bpm), ("Tonacja", self.keyc), ("Skala", self.scale), ("Długość (takty)", self.bars),
                        ("Energia", self.energy), ("Gęstość / złożoność", self.density), ("Swing", self.swing),
                        ("Niuanse", niu_w), ("Niepowtarzalność", uniq_w),
                        ("Spektakularność", self.spectacle), ("Zasób epoki", self.era),
                        ("Seed", seed_w), ("Nazwa", self.name)]:
            f.addRow(lbl, wd)
        form_host = W.QWidget(); form_host.setLayout(f)
        top = W.QHBoxLayout(); top.addWidget(form_host, 1)
        box_host = W.QWidget(); box = W.QVBoxLayout(box_host)
        box.addWidget(W.QLabel("Instrumenty (wtyczki CLAP; DS Speak opcjonalnie)"))
        avail = set(core.available_types())
        self.itree = W.QTreeWidget(); self.itree.setHeaderHidden(True); self.itree.setMinimumWidth(230); self.itree.setMaximumHeight(330)
        for g, ts in core.GROUPS.items():
            ts = [t for t in ts if t in avail]
            if not ts:
                continue
            gi = W.QTreeWidgetItem(self.itree, [g]); gi.setFlags(gi.flags() | Qt.ItemFlag.ItemIsUserTristate | Qt.ItemFlag.ItemIsUserCheckable)
            for t in ts:
                ci = W.QTreeWidgetItem(gi, [t]); ci.setFlags(ci.flags() | Qt.ItemFlag.ItemIsUserCheckable); ci.setCheckState(0, Qt.CheckState.Unchecked)
                ci.setForeground(0, QtGui.QBrush(tcolor(t)))
                ci.setData(0, Qt.ItemDataRole.UserRole + 1, False)  # True = 🔒 zablokowany typ
        self.itree.expandAll()
        self.itree.itemDoubleClicked.connect(self._toggle_inst_lock)
        box.addWidget(self.itree)
        box.addWidget(W.QLabel("2× klik instrument = 🔒 (smart/Styl nie zmienia zaznaczenia)"))
        ib = W.QHBoxLayout()
        for txt, fn in (("Styl", lambda: self.set_instruments(G.default_instruments(self.cur_style()))),
                        ("Podstawowe 8", lambda: self.set_instruments(core.CORE8)), ("Wszystkie", lambda: self.set_instruments(core.available_types()))):
            b = W.QPushButton(txt); b.clicked.connect(fn); ib.addWidget(b)
        box.addLayout(ib)
        # --- REŻYSER (nadrzędny tryb) ---
        dg = W.QGroupBox("Reżyser (nadrzędny tryb generacji)"); dl = W.QVBoxLayout(dg)
        self.dir_on = W.QCheckBox("Włącz reżysera")
        self.dir_on.setToolTip("Gdy włączony: mood→agresja/optymizm, scenariusz, dobór instrumentów,\nokna parametrów, zamiany ról, autolevel — nadrzędnie nad resztą.")
        dl.addWidget(self.dir_on)
        row_m = W.QHBoxLayout()
        row_m.addWidget(W.QLabel("Nastrój (mood):"))
        self.dir_mood = W.QSlider(Qt.Orientation.Horizontal); self.dir_mood.setRange(-100, 100); self.dir_mood.setValue(0)
        self.dir_mood_lbl = W.QLabel("wyważony (0.00)")
        self.dir_mood.valueChanged.connect(self._mood_lbl)
        row_m.addWidget(self.dir_mood, 1); row_m.addWidget(self.dir_mood_lbl)
        dl.addLayout(row_m)
        row_f = W.QHBoxLayout()
        self.dir_scenario = W.QCheckBox("Scenariusze"); self.dir_scenario.setChecked(True)
        self.dir_pick = W.QCheckBox("Dobór instrumentów"); self.dir_pick.setChecked(True)
        self.dir_windows = W.QCheckBox("Okna parametrów"); self.dir_windows.setChecked(True)
        self.dir_roles = W.QCheckBox("Zamiany ról"); self.dir_roles.setChecked(True)
        self.dir_autolevel = W.QCheckBox("Autolevels"); self.dir_autolevel.setChecked(True)
        for chk in (self.dir_scenario, self.dir_pick, self.dir_windows, self.dir_roles, self.dir_autolevel):
            row_f.addWidget(chk)
        dl.addLayout(row_f)
        row_v = W.QHBoxLayout()
        row_v.addWidget(W.QLabel("Variety:"))
        self.dir_variety = W.QSlider(Qt.Orientation.Horizontal); self.dir_variety.setRange(0, 100); self.dir_variety.setValue(60)
        row_v.addWidget(self.dir_variety, 1)
        row_v.addWidget(W.QLabel("Siła scenariusza:"))
        self.dir_scen_str = W.QSlider(Qt.Orientation.Horizontal); self.dir_scen_str.setRange(0, 100); self.dir_scen_str.setValue(50)
        row_v.addWidget(self.dir_scen_str, 1)
        row_v.addWidget(W.QLabel("Role:"))
        self.dir_role_amt = W.QSlider(Qt.Orientation.Horizontal); self.dir_role_amt.setRange(0, 100); self.dir_role_amt.setValue(50)
        row_v.addWidget(self.dir_role_amt, 1)
        dl.addLayout(row_v)
        box.addWidget(dg)
        # legacy (gdy reżyser wyłączony)
        self.smart_inst = W.QCheckBox("Dobór wagowy (legacy)")
        self.auto_lvl = W.QCheckBox("Autolevels (legacy)")
        self.role_swap = W.QCheckBox("Zamiana ról (legacy)")
        self.scenarios = W.QCheckBox("Scenariusze (legacy)")
        self.character = W.QComboBox()
        self.character.addItems(["very_optimistic", "optimistic", "balanced", "restrained", "dark"])
        self.character.setCurrentText("balanced")
        leg = W.QHBoxLayout()
        for leg_w in (self.smart_inst, self.auto_lvl, self.role_swap, self.scenarios):
            leg.addWidget(leg_w)
        leg.addWidget(W.QLabel("char:")); leg.addWidget(self.character)
        box.addLayout(leg)
        # --- DS Speak: aktywne tylko gdy zaznaczono instrument "speak" (domyślnie wyłączony)
        self.sp_box = W.QGroupBox("Mowa (DS Speak) — tekst"); sl = W.QVBoxLayout(self.sp_box)
        self.sp_auto = W.QRadioButton("Auto — generator układa tekst"); self.sp_man = W.QRadioButton("Ręczny — własny tekst (ENG)")
        self.sp_auto.setChecked(True)
        self.sp_theme = W.QComboBox(); self.sp_theme.addItems(["wg stylu"] + list(G.SPEAK_THEMES))
        self.sp_text = W.QPlainTextEdit(); self.sp_text.setMaximumHeight(64)
        self.sp_text.setPlaceholderText("np. Drop the bass! Wobble. Hands up?  — każda nuta = kolejne słowo; ! akcent, ? pytanie, WIELKIE = okrzyk")
        for x in (self.sp_auto, self.sp_theme, self.sp_man, self.sp_text):
            sl.addWidget(x)
        box.addWidget(self.sp_box)
        self.itree.itemChanged.connect(lambda *_: self._sync_speak())
        self._sync_speak()
        top.addWidget(box_host); v.addLayout(top)
        r = W.QHBoxLayout()
        self.b_gen = W.QPushButton("Generuj"); self.b_gen.clicked.connect(self.generate)
        self.b_play = W.QPushButton("▶ Podgląd"); self.b_play.clicked.connect(self.preview)
        self.b_stop = W.QPushButton("■ Stop"); self.b_stop.clicked.connect(self.player.stop)
        self.b_save = W.QPushButton("Zapisz do biblioteki (MIDI+MP3+projekt)"); self.b_save.clicked.connect(self.save_lib)
        self.stems_chk = W.QCheckBox("+ stemy WAV")
        for b in (self.b_gen, self.b_play, self.b_stop, self.b_save, self.stems_chk):
            r.addWidget(b)
        v.addLayout(r)
        self.pb = W.QProgressBar(); self.pb.setRange(0, 100); self.status = W.QLabel("Gotowe.")
        v.addWidget(self.pb); v.addWidget(self.status)
        self.ov = Overview(); v.addWidget(self.ov, 1)
        return w

    @staticmethod
    def _slider(val):
        s = W.QSlider(Qt.Orientation.Horizontal); s.setRange(0, 100); s.setValue(val); return s

    # --- styl: lista albo hybryda z pola szachowego
    def open_style_creator(self):
        dlg = StyleCreatorDialog(self)
        dlg.exec()

    def _mood_lbl(self, v=None):
        m = (self.dir_mood.value() if v is None else v) / 100.0
        from . import director as DIR
        self.dir_mood_lbl.setText(f"{DIR.mood_name(m)} ({m:+.2f})")

    def director_cfg(self):
        from . import director as DIR
        d = DIR.normalize(None)
        d["on"] = self.dir_on.isChecked()
        d["mood"] = self.dir_mood.value() / 100.0
        d["scenario"] = self.dir_scenario.isChecked()
        d["pick_instruments"] = self.dir_pick.isChecked()
        d["windows"] = self.dir_windows.isChecked()
        d["roles"] = self.dir_roles.isChecked()
        d["autolevel"] = self.dir_autolevel.isChecked()
        d["variety"] = self.dir_variety.value() / 100.0
        d["scenario_strength"] = self.dir_scen_str.value() / 100.0
        d["role_amount"] = self.dir_role_amt.value() / 100.0
        locks = self.locked_instruments()
        d["skip"] = [typ for typ, on in locks.items() if not on]
        return d

    def cur_style(self):
        return self.style_override or self.style.currentText()

    def _show_style(self):
        o = self.style_override
        self.style_lbl.setText(f"<b>Hybryda:</b> <span style='color:{ST.color_of(o)}'>■</span> {o}" if o else "")
        self.style_lbl.setTextFormat(Qt.TextFormat.RichText)

    def _combo_style(self, st):
        self.style_override = None; self._show_style(); self.on_style(st)

    def use_style(self, name):
        """Ustaw styl Generatora: czysty (z listy) albo hybrydę „A 60% + B 40%”."""
        if dict.__contains__(G.STYLES, name):
            if self.style.currentText() == name:
                self._combo_style(name)
            else:
                self.style.setCurrentText(name)
        else:
            self.style_override = name; self._show_style(); self.on_style(name)

    # --- presety (globalne, domyślnie puste)
    def refresh_presets(self, select=None):
        names = PR.names(); self.preset_cb.clear()
        self.preset_cb.addItems(names if names else ["(brak presetów — „Zapisz jako…”)"]); self.preset_cb.setEnabled(bool(names))
        if select in names:
            self.preset_cb.setCurrentText(select)

    def collect_preset(self):
        lv = self.live.collect_cfg()
        key = None if self.keyc.currentIndex() == 0 else self.keyc.currentIndex() - 1
        return dict(generator=dict(style=self.cur_style(), style_base=self.style.currentText(), bpm=self.bpm.value(), key=key, scale=self.scale.currentText(),
                                   bars=self.bars.value(), energy=self.energy.value() / 100, density=self.density.value() / 100, swing=self.swing.value() / 100,
                                   instruments=self.selected_instruments(), speak_manual=self.sp_man.isChecked(), speak_text=self.sp_text.toPlainText().strip(),
                                   speak_theme=None if self.sp_theme.currentIndex() == 0 else self.sp_theme.currentText()),
                    board=dict(cells=self.board.cells_list(), strength=self.board.get_strength()),
                    live={k: lv[k] for k in ("mode", "locks", "tod_on", "tod_force", "tod_factors", "arr_bars", "lookahead", "max_store", "return_live", "mutate_p", "use_board")})

    def apply_preset(self, d):
        g, b, lv = d.get("generator", {}), d.get("board", {}), d.get("live", {})
        self.board.set_cells(b.get("cells", [])); self.board.set_strength(b.get("strength", 0.4))
        base = g.get("style_base") or g.get("style")
        if base and dict.__contains__(G.STYLES, base):
            self.style.blockSignals(True); self.style.setCurrentText(base); self.style.blockSignals(False)
        st = g.get("style")
        self.style_override = st if st and "%" in st and st in G.STYLES else None; self._show_style()
        if g.get("bpm"):
            self.bpm.setValue(int(g["bpm"]))
        self.keyc.setCurrentIndex(0 if g.get("key") is None else int(g["key"]) + 1)
        if g.get("scale") in core.SCALES:
            self.scale.setCurrentText(g["scale"])
        if g.get("bars"):
            self.bars.setValue(int(g["bars"]))
        for wd, k in ((self.energy, "energy"), (self.density, "density"), (self.swing, "swing")):
            if k in g:
                wd.setValue(int(round(float(g[k]) * 100)))
        if g.get("instruments"):
            self.set_instruments(g["instruments"])
        (self.sp_man if g.get("speak_manual") else self.sp_auto).setChecked(True); self.sp_text.setPlainText(g.get("speak_text") or "")
        self.sp_theme.setCurrentIndex(max(0, self.sp_theme.findText(g.get("speak_theme") or "")))
        self.live.set_cfg_widgets(lv)

    def preset_load(self):
        n = self.preset_cb.currentText(); d = PR.get(n) if self.preset_cb.isEnabled() else None
        if d is None:
            self.status.setText("Brak wybranego presetu."); return
        self.apply_preset(d); self.status.setText(f"Wczytano preset „{n}” (ustawienia Icecast bez zmian)")

    def preset_save(self):
        cur = self.preset_cb.currentText() if self.preset_cb.isEnabled() else ""
        n, ok = W.QInputDialog.getText(self, "Zapisz preset", "Nazwa presetu (istniejąca zostanie nadpisana):", text=cur)
        n = n.strip()
        if not ok or not n:
            return
        PR.put(n, self.collect_preset()); self.refresh_presets(n); self.status.setText(f"Zapisano preset „{n}” → {PR.path()}")

    def preset_delete(self):
        n = self.preset_cb.currentText()
        if self.preset_cb.isEnabled() and W.QMessageBox.question(self, "Usuń preset", f"Usunąć „{n}”?") == W.QMessageBox.StandardButton.Yes:
            PR.delete(n); self.refresh_presets(); self.status.setText(f"Usunięto „{n}”")

    def preset_export(self):
        n = self.preset_cb.currentText()
        if not self.preset_cb.isEnabled():
            return
        path, _ = W.QFileDialog.getSaveFileName(self, "Eksport presetu", str(Path.home() / f"{n}.json"), "JSON (*.json)")
        if path:
            PR.export_file(n, path); self.status.setText(f"Wyeksportowano „{n}” → {path}")

    def preset_import(self):
        path, _ = W.QFileDialog.getOpenFileName(self, "Import presetów", str(Path.home()), "JSON (*.json)")
        if path:
            try:
                ns = PR.import_file(path)
            except (OSError, ValueError) as ex:
                W.QMessageBox.critical(self, "Import", str(ex)); return
            self.refresh_presets(ns[0] if ns else None); self.status.setText(f"Zaimportowano: {', '.join(ns) or '—'}")

    def on_style(self, st):
        self.bpm.setValue(G.STYLES[st]["bpm"]); self.swing.setValue(int(G.STYLES[st]["swing"] * 100))
        self.set_instruments(G.default_instruments(st))

    def set_instruments(self, types):
        """Ustawia zaznaczenie typów; pozycje z 🔒 (lock) pozostają bez zmian."""
        want = set(types)
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                c = g.child(k)
                if c.data(0, Qt.ItemDataRole.UserRole + 1):
                    continue
                name = c.text(0).lstrip("🔒 ").strip()
                c.setCheckState(0, Qt.CheckState.Checked if name in want else Qt.CheckState.Unchecked)

    def _toggle_inst_lock(self, item, _col):
        if item is None or item.childCount() > 0:
            return
        locked = not bool(item.data(0, Qt.ItemDataRole.UserRole + 1))
        item.setData(0, Qt.ItemDataRole.UserRole + 1, locked)
        name = item.text(0).lstrip("🔒 ").strip()
        item.setText(0, ("🔒 " + name) if locked else name)
        item.setForeground(0, QtGui.QBrush(tcolor(name)))
        self.status.setText(f"{'Zablokowano' if locked else 'Odblokowano'} instrument: {name}")

    def locked_instruments(self):
        """typ -> True=force include, False=skip przy generacji."""
        out = {}
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                c = g.child(k)
                if c.data(0, Qt.ItemDataRole.UserRole + 1):
                    name = c.text(0).lstrip("🔒 ").strip()
                    out[name] = c.checkState(0) == Qt.CheckState.Checked
        return out

    def _sync_speak(self):
        self.sp_box.setEnabled("speak" in self.selected_instruments())

    def selected_instruments(self):
        out = []
        for gi in range(self.itree.topLevelItemCount()):
            g = self.itree.topLevelItem(gi)
            for k in range(g.childCount()):
                c = g.child(k)
                if c.checkState(0) == Qt.CheckState.Checked:
                    out.append(c.text(0).lstrip("🔒 ").strip())
        return out

    def busy(self, msg):
        self.status.setText(msg); self.pb.setValue(0)

    def run_bg(self, fn, done, msg):
        if self.worker and self.worker.isRunning():
            return
        self.busy(msg)
        self.worker = Worker(fn)
        self.worker.prog.connect(lambda x: self.pb.setValue(int(x * 100)))
        self.worker.done.connect(lambda r: (self.pb.setValue(100), done(r)))
        self.worker.fail.connect(lambda e: (self.status.setText("Błąd — szczegóły w oknie"), W.QMessageBox.critical(self, "Błąd", e)))
        self.worker.start()

    def generate(self):
        seed = random.randrange(1000000) if self.rndseed.isChecked() else self.seed.value()
        self.seed.setValue(seed)
        key = None if self.keyc.currentIndex() == 0 else self.keyc.currentIndex() - 1
        dirc = self.director_cfg()
        smart = self.smart_inst.isChecked()
        alvl = self.auto_lvl.isChecked()
        rswap = self.role_swap.isChecked()
        inst = self.selected_instruments()
        locks = self.locked_instruments()  # typ -> True=force, False=skip
        if not dirc["on"] and not smart and not inst:
            W.QMessageBox.information(self, "DS Studio", "Zaznacz instrumenty, włącz dobór wagowy albo reżysera."); return
        p = G.generate(self.cur_style(), bpm=self.bpm.value(), key=key, scale=self.scale.currentText(), bars=self.bars.value(),
                       energy=self.energy.value() / 100, density=self.density.value() / 100, swing=self.swing.value() / 100,
                       seed=seed, name=self.name.text() or None, instruments=None if (dirc["on"] or smart) else inst,
                       speak_text=self.sp_text.toPlainText().strip() if self.sp_man.isChecked() else None,
                       speak_theme=None if self.sp_theme.currentIndex() == 0 else self.sp_theme.currentText(),
                       smart_instruments=smart, autolevels=alvl, role_swap=rswap,
                       scenarios=self.scenarios.isChecked(),
                       character=self.character.currentText(),
                       director=dirc,
                       niuanse=self.niu_on.isChecked(),
                       niuanse_strength=self.niu_str.value() / 100.0,
                       spectacle=self.spectacle.currentData() or "balanced",
                       era=self.era.currentData() or "auto",
                       uniq=self.uniq_on.isChecked(),
                       uniq_strength=self.uniq_str.value() / 100.0,
                       uniq_drops=self.uniq_drops.isChecked())
        if locks:
            p["tracks"] = [tr for tr in p["tracks"] if locks.get(tr["type"]) is not False]
            have = {tr["type"] for tr in p["tracks"]}
            for typ, force in locks.items():
                if force and typ not in have:
                    G.add_instance(p, typ)
            p["tracks"] = G._order_tracks(p["tracks"])
            p["links"] = G.default_links(p["style"], p["tracks"])
        self.set_project(p)
        extra = []
        if smart:
            types = ", ".join(t["type"] for t in p["tracks"])
            extra.append(f"dobór wagowy (agg={p.get('aggression', 0):.1f}): {types}")
            self.set_instruments([t["type"] for t in p["tracks"]])
        if p.get("role_swaps"):
            nswap = sum(len(x.get("swaps") or []) for x in p["role_swaps"])
            extra.append(f"zamiana ról: {nswap} w {len(p['role_swaps'])} torach")
        if p.get("scenarios") and p.get("scenario_report"):
            sr = p["scenario_report"]
            arc = " → ".join(f"{s['type']}{s['bars']}" for s in p["sections"][:8])
            if "passes" in sr:
                extra.append(f"scenariusz (korekty×{sr.get('passes', 0)}): {arc}")
            else:
                extra.append(f"scenariusz {p.get('character')}: {arc}")
        if p.get("director") and p["director"].get("on"):
            extra.append(f"reżyser mood={p.get('mood', 0):+.2f} A={p.get('A', 0):.2f} o={p.get('o', 0):.2f}")
        if p.get("role_events"):
            extra.append(f"role: {len(p['role_events'])} okien")
        if p.get("niuanse_report"):
            n = sum(len(v) for v in p["niuanse_report"].values())
            extra.append(f"niuanse×{n} na {len(p['niuanse_report'])} torach")
        if p.get("spectacle") is not None:
            extra.append(f"spektakl={p['spectacle']:.2f}")
        if p.get("era"):
            extra.append(f"era={p.get('era_label') or p['era']}")
        if p.get("uniq_report"):
            ur = p["uniq_report"]
            ns = len(ur.get("sections") or {})
            extra.append(f"uniq×{ns} seg (s={p.get('uniq_strength', 0):.2f})")
        base = f"Wygenerowano: {p['name']} — {core.key_name(p)}, {p['bpm']} BPM, {p['bars']} taktów ({p['bars'] * 240 / p['bpm']:.0f} s), {len(p['tracks'])} ścieżek"
        self.status.setText(base + ((" | " + " | ".join(extra)) if extra else ""))

    def set_project(self, p):
        self.proj = core.ensure_types(p); self.cache = {}; self.undo = {}
        self.ne_a.setMaximum(max(1, p["bars"])); self.ne_b.setMaximum(max(1, p["bars"]))
        self.ne_a.setValue(1); self.ne_b.setValue(max(1, p["bars"])); self.ov.sel = None
        self.ov.set_project(p); self.fill_track_list(); self.fill_links()
        self.bpm.setValue(int(p["bpm"])); self.style.blockSignals(True)
        if dict.__contains__(G.STYLES, p["style"]):
            self.style.setCurrentText(p["style"]); self.style_override = None
        else:
            self.style_override = p["style"] if p["style"] in G.STYLES else None
        self.style.blockSignals(False); self._show_style()

    def need_proj(self):
        if not self.proj:
            W.QMessageBox.information(self, "DS Studio", "Najpierw wygeneruj lub wczytaj projekt."); return False
        return True

    def preview(self):
        if not self.need_proj():
            return
        if self.live.eng.running:
            self.live.stop()          # podgląd offline i strumień Live nie grają naraz
        proj = self.proj

        def job(prog):
            stems = core.render_stems(proj, prog, self.cache)
            mix = core.mix_stems(proj, stems)
            path = Path(tempfile.gettempdir()) / "ds_studio_preview.wav"
            core.write_wav(path, mix)
            return path
        self.run_bg(job, self._play_path, "Renderuję 8 ścieżek przez wtyczki CLAP…")

    def _play_path(self, path):
        ok = self.player.play(path)
        self.status.setText("Odtwarzanie…" if ok else "Brak odtwarzacza (pw-play/paplay/aplay/ffplay/mpv) — plik: " + str(path))

    def run_autolevel(self):
        """Pełny autolevel: render stemów (cache) → RMS → gainy."""
        if not self.need_proj():
            return
        proj = self.proj

        def job(prog):
            return core.autolevel(proj, progress=prog, cache=self.cache)

        def done(report):
            self.show_track(self.tlist.currentRow())
            if not report:
                self.status.setText("Autolevels: brak słyszalnych ścieżek."); return
            parts = [f"{n}: {a:.2f}→{b:.2f}" for n, (a, b, _) in list(report.items())[:8]]
            more = f" (+{len(report)-8})" if len(report) > 8 else ""
            self.status.setText("Autolevels: " + ", ".join(parts) + more)

        self.run_bg(job, done, "Autolevels — renderuję stemy i mierzę RMS…")

    def save_lib(self):
        if not self.need_proj():
            return
        proj, ws = self.proj, self.stems_chk.isChecked()
        self.run_bg(lambda prog: core.save_to_library(proj, core.render_stems(proj, prog, self.cache), None, ws),
                    lambda d: (self.status.setText(f"Zapisano: {d}"), self.refresh_library()), "Renderuję i zapisuję do biblioteki…")

    def _tick(self):
        e = self.player.elapsed()
        if self.proj and e is not None and self.player.proc is not None and str(self.player.proc.args[-1]).endswith("preview.wav"):
            self.ov.head = e * self.proj["bpm"] / 60.0
        else:
            self.ov.head = None
        self.ov.update()

    # ------------------------------------------------------------------ Ścieżki
    def _build_tracks(self):
        w = W.QWidget(); h = W.QHBoxLayout(w)
        self.tlist = W.QListWidget(); self.tlist.setFixedWidth(170); self.tlist.currentRowChanged.connect(self.show_track)
        h.addWidget(self.tlist)
        right = W.QVBoxLayout(); h.addLayout(right, 1)
        top = W.QHBoxLayout()
        self.t_mute = W.QCheckBox("Mute"); self.t_solo = W.QCheckBox("Solo")
        self.t_lock_snd = W.QCheckBox("🔒 Sound"); self.t_lock_snd.setToolTip("Nie losuj parametrów brzmienia tej ścieżki")
        self.t_lock_notes = W.QCheckBox("🔒 Nuty"); self.t_lock_notes.setToolTip("Nie przelosowuj wzoru nut / zamiany ról")
        self.t_lock_gain = W.QCheckBox("🔒 Gain"); self.t_lock_gain.setToolTip("Autolevels nie zmienia gainu tej ścieżki")
        self.t_gain = W.QSlider(Qt.Orientation.Horizontal); self.t_gain.setRange(0, 150); self.t_gain.setFixedWidth(160)
        self.t_mute.toggled.connect(lambda x: self._tset("mute", x)); self.t_solo.toggled.connect(lambda x: self._tset("solo", x))
        self.t_lock_snd.toggled.connect(lambda x: self._tset("lock_sound", x))
        self.t_lock_notes.toggled.connect(lambda x: self._tset("lock_notes", x))
        self.t_lock_gain.toggled.connect(lambda x: self._tset("lock_gain", x))
        self.t_gain.valueChanged.connect(lambda x: self._tset("gain", x / 100))
        b1 = W.QPushButton("Losuj brzmienie"); b1.clicked.connect(lambda: self.reroll(True, False))
        b2 = W.QPushButton("Losuj wzór nut"); b2.clicked.connect(lambda: self.reroll(False, True))
        b3 = W.QPushButton("Oba"); b3.clicked.connect(lambda: self.reroll(True, True))
        bal = W.QPushButton("Autolevels"); bal.setToolTip("Pomiar RMS stemów → gainy pod TARGET_REL (używa cache renderu)")
        bal.clicked.connect(self.run_autolevel)
        for x in (self.t_mute, self.t_solo, self.t_lock_snd, self.t_lock_notes, self.t_lock_gain, W.QLabel("Gain"), self.t_gain, bal, b1, b2, b3):
            top.addWidget(x)
        top.addStretch(1); right.addLayout(top)
        inst = W.QHBoxLayout()
        self.add_type = W.QComboBox(); self.add_type.addItems(core.available_types())
        ba = W.QPushButton("＋ Dodaj instancję"); ba.clicked.connect(self.add_inst)
        bd = W.QPushButton("－ Usuń ścieżkę"); bd.clicked.connect(self.del_inst)
        for x in (W.QLabel("Wtyczka:"), self.add_type, ba, bd):
            inst.addWidget(x)
        inst.addStretch(1); right.addLayout(inst)
        # --- routing: pre (nuty z innej ścieżki) i post (audio innej ścieżki jako wejście = instrument jako filtr)
        rg = W.QGroupBox("Routing: pre (nuty) / post (audio → ten instrument jako filtr)"); rl = W.QHBoxLayout(rg)
        self.rt_notes = W.QComboBox(); self.rt_tr = W.QSpinBox(); self.rt_tr.setRange(-36, 36); self.rt_tr.setSuffix(" st")
        self.rt_in = W.QComboBox(); self.rt_mix = W.QSlider(Qt.Orientation.Horizontal); self.rt_mix.setRange(0, 100); self.rt_mix.setFixedWidth(90)
        self.rt_hide = W.QCheckBox("ukryj źródło w miksie"); self.rt_hide.setChecked(True)
        for lbl, wd in (("Nuty z:", self.rt_notes), ("transp.", self.rt_tr), ("Wejście audio z:", self.rt_in), ("mix", self.rt_mix), ("", self.rt_hide)):
            if lbl:
                rl.addWidget(W.QLabel(lbl))
            rl.addWidget(wd)
        rl.addStretch(1); right.addWidget(rg)
        self.rt_notes.currentTextChanged.connect(self._route_changed); self.rt_in.currentTextChanged.connect(self._route_changed)
        self.rt_tr.valueChanged.connect(self._route_changed); self.rt_mix.valueChanged.connect(self._route_changed); self.rt_hide.toggled.connect(self._route_changed)
        # --- grupa nut: okno taktów (też zaznaczane myszą na przeglądzie w zakładce Generator) + operacja
        ng = W.QGroupBox("Edycja grupy nut (okno taktów)"); nl = W.QHBoxLayout(ng)
        self.ne_a = W.QSpinBox(); self.ne_b = W.QSpinBox(); self.ne_a.setMinimum(1); self.ne_b.setMinimum(1); self.ne_a.setMaximum(256); self.ne_b.setMaximum(256)
        self.ne_op = W.QComboBox(); self.ne_op.addItems([o[1] for o in N.OPS])
        self.ne_amt = W.QDoubleSpinBox(); self.ne_amt.setRange(-96, 100); self.ne_amt.setDecimals(2)
        self.ne_scale = W.QComboBox(); self.ne_scale.addItems(list(N.NOTE_SCALES))
        bap = W.QPushButton("Zastosuj"); bun = W.QPushButton("Cofnij"); ball = W.QPushButton("Całość")
        bap.clicked.connect(self.notes_apply); bun.clicked.connect(self.notes_undo); ball.clicked.connect(lambda: (self.ne_a.setValue(1), self.ne_b.setValue(self.ne_b.maximum())))
        self.ne_op.currentIndexChanged.connect(self._op_changed)
        for lbl, wd in (("takty od", self.ne_a), ("do", self.ne_b), ("operacja", self.ne_op), ("parametr", self.ne_amt), ("skala", self.ne_scale)):
            nl.addWidget(W.QLabel(lbl)); nl.addWidget(wd)
        for b_ in (ball, bap, bun):
            nl.addWidget(b_)
        nl.addStretch(1); right.addWidget(ng); self._op_changed(0)
        self.t_scroll = W.QScrollArea(); self.t_scroll.setWidgetResizable(True)
        self.t_params = W.QWidget()
        self.t_params_lay = W.QVBoxLayout(self.t_params)
        self.t_params_lay.setContentsMargins(4, 4, 4, 4)
        self.t_scroll.setWidget(self.t_params)
        right.addWidget(self.t_scroll, 1)
        return w

    def fill_track_list(self):
        cur = max(0, self.tlist.currentRow())
        self.tlist.blockSignals(True)
        self.tlist.clear()
        for tr in (self.proj or {}).get("tracks") or []:
            n = len(tr.get("notes") or [])
            locks = []
            if tr.get("lock_sound"):
                locks.append("S")
            if tr.get("lock_notes"):
                locks.append("N")
            if tr.get("lock_gain"):
                locks.append("G")
            tag = f" 🔒{''.join(locks)}" if locks else ""
            self.tlist.addItem(f"{tr['name']}  ({n}n){tag}")
        self.tlist.blockSignals(False)
        if self.tlist.count() == 0:
            if hasattr(self, "t_params_lay"):
                self._clear_layout(self.t_params_lay)
            return
        cur = min(cur, self.tlist.count() - 1)
        self.tlist.setCurrentRow(cur)
        self.show_track(cur)


    def _ov_sel(self, a, b):
        self.ne_a.setValue(a + 1); self.ne_b.setValue(b)
        self.status.setText(f"Zaznaczono takty {a + 1}–{b} (edycja w zakładce Ścieżki → Edycja grupy nut)")

    def _op_changed(self, i):
        key, _, plab, dflt = N.OPS[max(0, i)]
        self.ne_amt.setEnabled(plab is not None); self.ne_amt.setValue(dflt); self.ne_amt.setPrefix((plab + ": ") if plab else "")
        self.ne_scale.setEnabled(key in ("snap", "scale_up", "scale_down", "random_scale"))

    def notes_apply(self):
        if not self.need_proj() or self.tlist.currentRow() < 0:
            return
        t = self.proj["tracks"][self.tlist.currentRow()]
        a, b = min(self.ne_a.value(), self.ne_b.value()) - 1, max(self.ne_a.value(), self.ne_b.value())
        key = N.OPS[self.ne_op.currentIndex()][0]
        old = copy.deepcopy(t["notes"])
        new = N.apply_op(self.proj, t["notes"], key, a, b, self.ne_amt.value() if self.ne_amt.isEnabled() else None, self.ne_scale.currentText())
        self.undo.setdefault(t["name"], []).append(old)
        t["notes"] = new
        self.ov.set_project(self.proj); self.fill_track_list()
        self.status.setText(f"{t['name']}: {N.OPS[self.ne_op.currentIndex()][1]} — takty {a + 1}–{b} ({len(old)} → {len(new)} nut)")

    def notes_undo(self):
        if not self.proj or self.tlist.currentRow() < 0:
            return
        t = self.proj["tracks"][self.tlist.currentRow()]; st = self.undo.get(t["name"])
        if st:
            t["notes"] = st.pop(); self.ov.set_project(self.proj); self.fill_track_list(); self.status.setText(f"{t['name']}: cofnięto")

    def _route_changed(self, *_):
        if not self.proj or self.tlist.currentRow() < 0 or getattr(self, "_rt_lock", False):
            return
        t = self.proj["tracks"][self.tlist.currentRow()]
        nf, inf = self.rt_notes.currentText(), self.rt_in.currentText()
        t["notes_from"] = None if nf.startswith("—") else nf
        t["input_from"] = None if inf.startswith("—") else inf
        t["notes_transpose"] = self.rt_tr.value(); t["input_mix"] = self.rt_mix.value() / 100.0; t["input_hide_source"] = self.rt_hide.isChecked()
        self.ov.set_project(self.proj)

    def _fill_route(self, t):
        self._rt_lock = True
        others = ["— brak —"] + [x["name"] for x in self.proj["tracks"] if x is not t]
        for cb, key in ((self.rt_notes, "notes_from"), (self.rt_in, "input_from")):
            cb.clear(); cb.addItems(others); cb.setCurrentText(t.get(key) or others[0])
        self.rt_tr.setValue(int(t.get("notes_transpose", 0))); self.rt_mix.setValue(int(t.get("input_mix", 1.0) * 100))
        self.rt_hide.setChecked(t.get("input_hide_source", True))
        self._rt_lock = False

    def _tset(self, key, val):
        if self.proj and self.tlist.currentRow() >= 0:
            self.proj["tracks"][self.tlist.currentRow()][key] = val

    @staticmethod
    def _clear_layout(layout):
        """Usuwa dzieci layoutu bez niszczenia samego layoutu (unika RuntimeError QVBoxLayout deleted)."""
        if layout is None:
            return
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
                continue
            sub = item.layout()
            if sub is not None:
                MainWindow._clear_layout(sub)

    def show_track(self, row):
        if row < 0 or not self.proj:
            return
        if row >= len(self.proj["tracks"]):
            return
        if not hasattr(self, "t_params_lay"):
            return
        t = self.proj["tracks"][row]
        self._fill_route(t)
        for wd, key in ((self.t_mute, "mute"), (self.t_solo, "solo"),
                         (self.t_lock_snd, "lock_sound"), (self.t_lock_notes, "lock_notes"), (self.t_lock_gain, "lock_gain")):
            wd.blockSignals(True); wd.setChecked(bool(t.get(key, False))); wd.blockSignals(False)
        self.t_gain.blockSignals(True); self.t_gain.setValue(int(t["gain"] * 100)); self.t_gain.blockSignals(False)
        self._clear_layout(self.t_params_lay)
        lay = self.t_params_lay
        if t["type"] == "speak":
            gb = W.QGroupBox("Tekst DS Speak — 1 nuta = 1 słowo (! akcent, ? pytanie, WIELKIE = okrzyk)"); gl = W.QVBoxLayout(gb)
            ed = W.QPlainTextEdit(t.get("text", "")); ed.setMaximumHeight(90)
            ml = W.QLabel("tryb: " + t.get("text_mode", "auto"))
            bapply = W.QPushButton("Zastosuj (ręczny)"); bauto = W.QPushButton("Auto-tekst z motywu")

            def apply_text(_=False, tt=t, e=ed, l=ml):
                tt["text"] = e.toPlainText().strip(); tt["text_mode"] = "manual"; l.setText("tryb: manual")

            def auto_text(_=False, tt=t, e=ed, l=ml):
                rng = random.Random(random.randrange(10 ** 6))
                tt["text"] = G.auto_text(tt.get("text_theme"), self.proj["style"], len(tt["notes"]) or 8, rng)
                tt["text_mode"] = "auto"; e.setPlainText(tt["text"]); l.setText("tryb: auto")
            bapply.clicked.connect(apply_text); bauto.clicked.connect(auto_text)
            rr_w = W.QWidget(); rr = W.QHBoxLayout(rr_w); rr.setContentsMargins(0, 0, 0, 0)
            rr.addWidget(bapply); rr.addWidget(bauto); rr.addWidget(ml); rr.addStretch(1)
            gl.addWidget(ed); gl.addWidget(rr_w); lay.addWidget(gb)
        pl = self.meta.plugins[t["plugin"]]; groups = {}
        for name, p in pl["params"].items():
            g = groups.get(p["module"])
            if g is None:
                gb = W.QGroupBox(p["module"]); g = groups[p["module"]] = W.QFormLayout(gb); lay.addWidget(gb)
            frac = t["params"].get(name, self.meta.def_frac(t["type"], name))
            s = W.QSlider(Qt.Orientation.Horizontal); s.setRange(0, 1000); s.setValue(int(frac * 1000))
            lab = W.QLabel(self.meta.fmt(t["type"], name, frac)); lab.setMinimumWidth(90)
            s.valueChanged.connect(lambda val, n=name, l=lab, tt=t: self._param(tt, n, val / 1000, l))
            lk = W.QCheckBox("🔒"); lk.setToolTip("Zablokuj parametr — losowanie brzmienia go nie zmienia")
            locked = name in (t.get("locked_params") or [])
            lk.blockSignals(True); lk.setChecked(locked); lk.blockSignals(False)
            def _toggle_plock(on, n=name, tt=t):
                lp = list(tt.get("locked_params") or [])
                if on and n not in lp:
                    lp.append(n)
                elif not on and n in lp:
                    lp.remove(n)
                tt["locked_params"] = lp
            lk.toggled.connect(_toggle_plock)
            row_w = W.QWidget(); rl = W.QHBoxLayout(row_w); rl.setContentsMargins(0, 0, 0, 0)
            rl.addWidget(s, 1); rl.addWidget(lab); rl.addWidget(lk)
            g.addRow(name, row_w)
        lay.addStretch(1)

    def _param(self, t, name, frac, lab):
        t["params"][name] = frac; lab.setText(self.meta.fmt(t["type"], name, frac))

    def add_inst(self):
        if not self.need_proj():
            return
        tr = G.add_instance(self.proj, self.add_type.currentText())
        self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()
        self.tlist.setCurrentRow([t["name"] for t in self.proj["tracks"]].index(tr["name"]))
        self.status.setText(f"Dodano instancję: {tr['name']} ({len(self.proj['tracks'])} ścieżek)")

    def del_inst(self):
        if not self.need_proj() or self.tlist.currentRow() < 0 or len(self.proj["tracks"]) < 2:
            return
        G.remove_track(self.proj, self.proj["tracks"][self.tlist.currentRow()]["name"])
        self.tlist.setCurrentRow(0); self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()

    def reroll(self, sound, notes):
        if not self.need_proj():
            return
        tr = self.proj["tracks"][self.tlist.currentRow()]
        msgs = []
        if notes and tr.get("lock_notes"):
            msgs.append("nuty 🔒")
        if (sound or not notes) and tr.get("lock_sound"):
            msgs.append("sound 🔒")
        if notes:
            G.reroll_track(self.proj, tr["name"], sound=sound)
        else:
            G.randomize_sound(self.proj, tr, random.Random(random.randrange(10 ** 6)))
        self.ov.set_project(self.proj); self.fill_track_list(); self.fill_links()
        self.show_track(self.tlist.currentRow())
        self.status.setText(f"{tr['name']}: " + (f"pominięto ({', '.join(msgs)})" if msgs else "przelosowano"))

    # ------------------------------------------------------------------ Linki
    def _build_links(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel("Źródła (akcent kick/snare/hat, energia sekcji, build, faza taktu, wysokość basu) sterują parametrami dowolnej ścieżki.\n"
                             "Np. kick → Level basów = sidechain; build → Cutoff screecha; bass_note → Vowel growla."))
        self.ltab = W.QTableWidget(0, 5); self.ltab.setHorizontalHeaderLabels(["Źródło", "Ścieżka docelowa", "Parametr", "Ilość (−1…1)", "Release (beaty)"])
        self.ltab.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        v.addWidget(self.ltab, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Dodaj link", self.link_add), ("Usuń zaznaczony", self.link_del), ("Przywróć domyślne dla stylu", self.link_reset)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        r.addStretch(1); v.addLayout(r)
        return w

    def _names(self):
        return [t["name"] for t in self.proj["tracks"]] if self.proj else []

    def _params_for(self, track):
        t = core.find_track(self.proj, track) if self.proj else None
        if t is None:
            return []
        return [n for n, p in self.meta.plugins[t["plugin"]]["params"].items() if p["kind"] != "int"]

    def fill_links(self):
        self.ltab.setRowCount(0)
        for L in (self.proj["links"] if self.proj else []):
            self._link_row(L)

    def _link_row(self, L):
        r = self.ltab.rowCount(); self.ltab.insertRow(r)
        src = W.QComboBox(); src.addItems(core.LINK_SOURCES); src.setCurrentText(L["src"])
        dst = W.QComboBox(); dst.addItems(self._names()); dst.setCurrentText(L["dst"])
        par = W.QComboBox(); par.addItems(self._params_for(L["dst"])); par.setCurrentText(L["param"])
        amt = W.QDoubleSpinBox(); amt.setRange(-1, 1); amt.setSingleStep(0.05); amt.setValue(L["amount"])
        rel = W.QDoubleSpinBox(); rel.setRange(0.05, 8); rel.setSingleStep(0.05); rel.setValue(L.get("rel", 0.5))

        def sync(*_):
            L["src"], L["dst"], L["param"], L["amount"], L["rel"] = src.currentText(), dst.currentText(), par.currentText(), amt.value(), rel.value()

        def dst_changed(tn):
            par.blockSignals(True); par.clear(); par.addItems(self._params_for(tn)); par.blockSignals(False); sync()
        dst.currentTextChanged.connect(dst_changed)
        for wd in (src, par):
            wd.currentTextChanged.connect(sync)
        for wd in (amt, rel):
            wd.valueChanged.connect(sync)
        for c, wd in enumerate((src, dst, par, amt, rel)):
            self.ltab.setCellWidget(r, c, wd)

    def link_add(self):
        if self.need_proj():
            names = self._names()
            L = {"src": "kick", "dst": "sub" if "sub" in names else names[0], "param": "Level", "amount": -0.3, "rel": 0.5}
            self.proj["links"].append(L); self._link_row(L)

    def link_del(self):
        r = self.ltab.currentRow()
        if self.proj and r >= 0:
            del self.proj["links"][r]; self.fill_links()

    def link_reset(self):
        if self.need_proj():
            self.proj["links"] = G.default_links(self.proj["style"], self.proj["tracks"]); self.fill_links()

    # ------------------------------------------------------------------ Biblioteka
    def _build_lib(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        self.lib = W.QTableWidget(0, 7)
        self.lib.setHorizontalHeaderLabels(["Nazwa", "Styl", "BPM", "Tonacja", "Takty", "Utworzono", "Rodzice"])
        self.lib.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        self.lib.setSelectionBehavior(W.QAbstractItemView.SelectionBehavior.SelectRows)
        self.lib.setSelectionMode(W.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.lib.setEditTriggers(W.QAbstractItemView.EditTrigger.NoEditTriggers)
        v.addWidget(W.QLabel(f"Biblioteka: {core.lib_dir()}"))
        v.addWidget(self.lib, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Odśwież", self.refresh_library), ("▶ Odtwórz", self.lib_play), ("■ Stop", lambda: self.player.stop()),
                        ("Wczytaj do edytora", self.lib_load), ("Usuń", self.lib_delete), ("Otwórz folder", self.lib_open),
                        ("→ Do auto-remixu", self.lib_to_remix)):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)
        return w

    def refresh_library(self):
        self.entries = core.list_library(); self.lib.setRowCount(len(self.entries))
        for i, e in enumerate(self.entries):
            for c, val in enumerate([e["name"], e["style"], e["bpm"], e["key"], e["bars"], e["created"], ", ".join(e["parents"])]):
                self.lib.setItem(i, c, W.QTableWidgetItem(str(val)))

    def _sel(self):
        return [self.entries[i.row()] for i in self.lib.selectionModel().selectedRows()]

    def lib_play(self):
        s = self._sel()
        if s and s[0]["audio"]:
            self.player.play(s[0]["audio"])

    def lib_load(self):
        s = self._sel()
        if s:
            self.set_project(core.load_project(s[0]["path"])); self.tabs.setCurrentIndex(0)
            self.status.setText(f"Wczytano {s[0]['name']}")

    def lib_delete(self):
        s = self._sel()
        if s and W.QMessageBox.question(self, "Usuń", f"Usunąć {len(s)} pozycji z dysku?") == W.QMessageBox.StandardButton.Yes:
            for e in s:
                core.delete_library_entry(e["path"])
            self.refresh_library()

    def lib_open(self):
        s = self._sel()
        subprocess.Popen(["xdg-open", str(s[0]["path"] if s else core.lib_dir())])

    def lib_to_remix(self):
        s = self._sel()
        if len(s) < 1:
            return
        self.remix_entries = [(e["path"], core.load_project(e["path"])) for e in s]
        for p, pr in self.remix_entries:
            pr["id"] = Path(p).name
        self.fill_remix(); self.tabs.setCurrentIndex(4)

    # ------------------------------------------------------------------ Remix
    def _build_remix(self):
        w = W.QWidget(); v = W.QVBoxLayout(w)
        v.addWidget(W.QLabel("Wybierz utwory w Bibliotece → „Do auto-remixu”. W tabeli zaznacz, z którego utworu ma pochodzić każda ścieżka.\n"
                             "Wiersze = wszystkie instrumenty z wybranych utworów (24 typy, także kilka instancji). Struktura, progresja i linki z mastera; nuty/brzmienie ze źródeł."))
        f = W.QHBoxLayout()
        self.r_master = W.QComboBox(); self.r_bpm = W.QSpinBox(); self.r_bpm.setRange(0, 220); self.r_bpm.setSpecialValueText("z mastera")
        self.r_key = W.QComboBox(); self.r_key.addItems(["z mastera"] + core.NOTE_NAMES)
        self.r_harm = W.QCheckBox("Przeharmonizuj ścieżki melodyczne do progresji mastera"); self.r_harm.setChecked(True)
        self.r_name = W.QLineEdit(); self.r_name.setPlaceholderText("nazwa remixu")
        for lbl, wd in (("Master:", self.r_master), ("BPM:", self.r_bpm), ("Tonacja:", self.r_key)):
            f.addWidget(W.QLabel(lbl)); f.addWidget(wd)
        v.addLayout(f); v.addWidget(self.r_harm); v.addWidget(self.r_name)
        self.rtab = W.QTableWidget(0, 0); v.addWidget(self.rtab, 1)
        r = W.QHBoxLayout()
        for txt, fn in (("Auto-remix (losowe przypisanie)", self.remix_auto), ("Zbuduj i podglądaj", lambda: self.remix_build(False)),
                        ("Zbuduj i zapisz do biblioteki", lambda: self.remix_build(True))):
            b = W.QPushButton(txt); b.clicked.connect(fn); r.addWidget(b)
        v.addLayout(r)
        self.rgroups = {}; self.rnames = []
        return w

    def fill_remix(self):
        projs = [p for _, p in self.remix_entries]; n = len(projs)
        self.rnames = R.track_names(projs)
        self.r_master.clear(); self.r_master.addItems([p["name"] for p in projs])
        self.rtab.setColumnCount(n + 1); self.rtab.setRowCount(len(self.rnames))
        self.rtab.setHorizontalHeaderLabels(["— wył. —"] + [f"{p['name']}\n{p['style']} {p['bpm']}bpm {core.key_name(p)}" for p in projs])
        self.rtab.setVerticalHeaderLabels(self.rnames)
        self.rtab.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch)
        self.rgroups = {}
        for r, name in enumerate(self.rnames):
            grp = W.QButtonGroup(self); self.rgroups[name] = grp
            off = W.QRadioButton("—"); grp.addButton(off, 0); self.rtab.setCellWidget(r, 0, off)
            first = True
            for c, p in enumerate(projs):
                t = core.find_track(p, name); cnt = len(t["notes"]) if t else 0
                rb = W.QRadioButton(f"{cnt} nut"); grp.addButton(rb, c + 1); rb.setEnabled(cnt > 0)
                if cnt and first:
                    rb.setChecked(True); first = False
                self.rtab.setCellWidget(r, c + 1, rb)
            if first:
                off.setChecked(True)

    def remix_auto(self):
        if not self.remix_entries:
            return
        rng = random.Random(random.randrange(10 ** 6))
        projs = [p for _, p in self.remix_entries]
        master, assign = R.auto_assign(projs, rng)
        ids = [p["id"] for p in projs]
        self.r_master.setCurrentIndex(ids.index(master["id"]))
        for name in self.rnames:
            p = assign.get(name)
            self.rgroups[name].button(0 if p is None else ids.index(p["id"]) + 1).setChecked(True)

    def remix_build(self, save):
        if not self.remix_entries:
            return
        projs = [p for _, p in self.remix_entries]
        master = projs[self.r_master.currentIndex()]
        assign = {n: (None if self.rgroups[n].checkedId() <= 0 else projs[self.rgroups[n].checkedId() - 1]) for n in self.rnames}
        if not any(assign.values()):
            W.QMessageBox.information(self, "DS Studio", "Wybierz źródło dla przynajmniej jednej ścieżki."); return
        key = None if self.r_key.currentIndex() == 0 else self.r_key.currentIndex() - 1
        p = R.remix(assign, master, bpm=self.r_bpm.value() or None, key=key, harmony=self.r_harm.isChecked(),
                    name=self.r_name.text() or None, seed=random.randrange(10 ** 6))
        self.set_project(p)
        self.status.setText(f"Remix: {p['name']} ({core.key_name(p)}, {p['bpm']} BPM, {len(p['tracks'])} ścieżek)")
        if save:
            self.save_lib()
        else:
            self.tabs.setCurrentIndex(0); self.preview()

    def closeEvent(self, e):
        self.live.shutdown(); self.player.stop(); super().closeEvent(e)


def main():
    app = W.QApplication(sys.argv)
    app.setStyle("Fusion")
    pal = QtGui.QPalette()
    for role, col in ((QtGui.QPalette.ColorRole.Window, "#14161b"), (QtGui.QPalette.ColorRole.WindowText, "#e5e7eb"),
                      (QtGui.QPalette.ColorRole.Base, "#0f1115"), (QtGui.QPalette.ColorRole.AlternateBase, "#14161b"),
                      (QtGui.QPalette.ColorRole.Text, "#e5e7eb"), (QtGui.QPalette.ColorRole.Button, "#1f232b"),
                      (QtGui.QPalette.ColorRole.ButtonText, "#e5e7eb"), (QtGui.QPalette.ColorRole.Highlight, "#e5484d"),
                      (QtGui.QPalette.ColorRole.HighlightedText, "#ffffff")):
        pal.setColor(role, QtGui.QColor(col))
    app.setPalette(pal)
    try:
        win = MainWindow()
    except Exception as ex:
        W.QMessageBox.critical(None, "DS Dubstep Studio", str(ex)); return 1
    win.show()
    return app.exec()
