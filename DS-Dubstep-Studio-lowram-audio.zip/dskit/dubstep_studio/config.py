"""config.py — config.txt (format INI: [sekcje], `klucz = wartość`, komentarze # lub ; tylko w osobnej linii).

Szukany w kolejności: $DS_CONFIG, ./config.txt (katalog projektu, obok ds-studio), ~/DubstepStudio/config.txt.
Jeśli żadnego nie ma, zostaje utworzony domyślny (z komentarzami) w katalogu projektu (chmod 600 — zawiera hasła).
Zapis z GUI podmienia tylko wartości, komentarze i kolejność zostają.
"""
from __future__ import annotations

import configparser
import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent

DEFAULT_TEXT = """\
# DS Dubstep Studio — config.txt
# Format: [sekcja] i `klucz = wartość`. Komentarze: linia zaczynająca się od # lub ;  (nie dopisuj komentarzy w tej samej linii co wartość —
# hasło może zawierać znak #). Tak/nie: yes/no, true/false, 1/0.
# Plik zawiera hasła: ma uprawnienia 600. Zmiany z GUI (Live → „Zapisz config.txt") podmieniają tylko wartości.

[icecast]
# Nadawanie strumienia Live do serwera Icecast2 (przez ffmpeg: PCM -> MP3/Ogg -> icecast://).
enabled = no
host = localhost
port = 8000
# punkt montowania; rozszerzenie dla wygody: .mp3 (format mp3) / .ogg (ogg, opus)
mount = /dubstep.mp3
source_user = source
# hasło źródła (<source-password> w icecast.xml)
password = hackme
# tls = yes dla https/icecast za proxy TLS (ffmpeg: -tls 1)
tls = no
# legacy = yes tylko dla Icecast < 2.4 (metoda SOURCE)
legacy = no
# format: mp3 | ogg (Vorbis) | opus
format = mp3
# bitrate w kbps
bitrate = 192
name = DS Dubstep Studio Live
description = Endless generative dubstep
genre = Dubstep
url =
# public = yes ogłasza stream w katalogu serwera (jeśli serwer ma <directory> włączone)
public = no
# Aktualizacja tytułu utworu (styl / BPM / tonacja) przez /admin/metadata — wymaga konta admina z icecast.xml.
metadata = yes
admin_user = admin
admin_password =
# grać też lokalnie na głośnikach (no = tylko nadawanie, np. na serwerze bez audio)
local_playback = yes
# po zerwaniu połączenia (restart serwera) ponów próbę co tyle sekund
reconnect_sec = 5

[live]
# current = styl i ustawienia z [generator] / zakładki Generator;  random = losowanie kaskadowe
mode = current
# takty na aranżację (min. 4 x liczba sekcji szablonu stylu)
arr_bars = 32
# --- wyjście audio i pamięć (SBC z 512 MB RAM) ---
# player: auto | aplay | pw-cat | paplay | mpv | ffplay. auto pomija pw-cat/paplay, gdy nie działa serwer dźwięku (wtedy gra przez ALSA: aplay)
player = auto
# urządzenie wyjściowe (puste = domyślne). aplay: plughw:1,0 albo plughw:CARD=Device,DEV=0 (lista: python3 -m dubstep_studio devices);
# paplay/pw-cat: nazwa sinka z `pactl list short sinks`; mpv: alsa/plughw:1,0
audio_device =
# równoległe procesy renderu (0 = auto z wolnego RAM; na 512 MB użyj 1)
render_workers = 0
# mutacje (tylko mode = random): % aranżacji, w których wylosowany styl jest mutowany w hybrydę (0 = wył.)
mutate = 0
# ile aranżacji generować z wyprzedzeniem
lookahead = 1
# maks. aranżacji w magazynie (przypięte nie są usuwane)
max_store = 60
# po odsłuchu z osi czasu wróć na żywo
return_live = yes
# tempo/energia wg pory dnia (tylko mode = random)
tod_on = yes
# auto = zegar systemowy, albo: Rano | Popołudnie | Wieczór | Noc
tod_force = auto
# mnożniki BPM stylu w procentach (60-130)
tod_rano = 88
tod_popoludnie = 100
tod_wieczor = 106
tod_noc = 90
# „na sztywno" (nie losowane, wartość z [generator]): lista po przecinku z: style,bpm,key,scale,energy,density,swing,bars,instruments
lock =
# GUI: rozpocznij strumień od razu po uruchomieniu
auto_start = no

[generator]
# Ustawienia bazowe (tryb bez GUI: ./ds-studio live). W GUI baza to zakładka Generator.
style = Brostep
# 0 = BPM stylu
bpm = 0
# auto | 0-11 | C C# D D# E F F# G G# A A# B
key = auto
# minor | phrygian | "harmonic minor"
scale = minor
energy = 0.7
density = 0.6
# -1 = swing stylu
swing = -1
# style | core8 | all | lista po przecinku, np. kick,snare,hat,sub,wobble
instruments = style
# tekst DS Speak (puste = auto), działa gdy w instruments jest speak
speak_text =

[paths]
# puste = domyślne. Biblioteka i magazyn Live (library/../live), katalog wtyczek .clap.
library =
plugin_dir =
# plik presetów (puste = ~/DubstepStudio/presets.json; domyślnie nie istnieje, dopóki nie zapiszesz presetu)
presets =
"""

SECTIONS_ORDER = ["icecast", "live", "generator", "paths"]
NOTE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def find_path(create=True) -> Path:
    cands = ([Path(os.environ["DS_CONFIG"])] if os.environ.get("DS_CONFIG") else []) + [APP_DIR / "config.txt", Path.home() / "DubstepStudio" / "config.txt"]
    for c in cands:
        if c.exists():
            return c
    p = cands[0] if os.environ.get("DS_CONFIG") else APP_DIR / "config.txt"
    if create:
        try:
            p.parent.mkdir(parents=True, exist_ok=True); p.write_text(DEFAULT_TEXT, encoding="utf-8"); os.chmod(p, 0o600)
        except OSError:
            p = Path.home() / "DubstepStudio" / "config.txt"; p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(DEFAULT_TEXT, encoding="utf-8"); os.chmod(p, 0o600)
    return p


def _parser(text=None):
    cp = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=None, comment_prefixes=("#", ";"), empty_lines_in_values=False)
    cp.optionxform = str.lower
    cp.read_string(DEFAULT_TEXT)                       # defaulty
    if text is not None:
        cp.read_string(text)
    return cp


def _b(v):
    return str(v).strip().lower() in ("1", "yes", "true", "tak", "on", "y")


def _int(v, d):
    try:
        return int(float(str(v).strip()))
    except ValueError:
        return d


def _float(v, d):
    try:
        return float(str(v).strip().replace(",", "."))
    except ValueError:
        return d


def load(path=None) -> dict:
    """-> {"path", "icecast": {...}, "live": {...}, "generator": {...}, "paths": {...}} z typami Pythona i walidacją."""
    path = Path(path) if path else find_path()
    cp = _parser(path.read_text(encoding="utf-8", errors="replace"))
    ic, lv, ge, pa = (cp[s] for s in SECTIONS_ORDER)
    fmt = ic["format"].strip().lower()
    icecast = dict(enabled=_b(ic["enabled"]), host=ic["host"].strip() or "localhost", port=_int(ic["port"], 8000), mount=ic["mount"].strip() or "/stream",
                   source_user=ic["source_user"].strip() or "source", password=ic["password"].strip(), tls=_b(ic["tls"]), legacy=_b(ic["legacy"]),
                   format=fmt if fmt in ("mp3", "ogg", "opus") else "mp3", bitrate=max(32, min(320, _int(ic["bitrate"], 192))), name=ic["name"].strip(),
                   description=ic["description"].strip(), genre=ic["genre"].strip(), url=ic["url"].strip(), public=_b(ic["public"]), metadata=_b(ic["metadata"]),
                   admin_user=ic["admin_user"].strip() or "admin", admin_password=ic["admin_password"].strip(), local_playback=_b(ic["local_playback"]),
                   reconnect_sec=max(1, _int(ic["reconnect_sec"], 5)))
    if not icecast["mount"].startswith("/"):
        icecast["mount"] = "/" + icecast["mount"]
    tf = lv["tod_force"].strip()
    locks = [x.strip() for x in lv["lock"].split(",") if x.strip()]
    live = dict(mode="random" if lv["mode"].strip().lower() == "random" else "current", arr_bars=max(16, _int(lv["arr_bars"], 32)),
                lookahead=max(1, min(4, _int(lv["lookahead"], 1))), max_store=max(5, _int(lv["max_store"], 60)), return_live=_b(lv["return_live"]),
                tod_on=_b(lv["tod_on"]), tod_force=None if tf.lower() in ("", "auto") else tf,
                tod_factors={"Rano": _int(lv["tod_rano"], 88) / 100, "Popołudnie": _int(lv["tod_popoludnie"], 100) / 100,
                             "Wieczór": _int(lv["tod_wieczor"], 106) / 100, "Noc": _int(lv["tod_noc"], 90) / 100},
                locks=locks, auto_start=_b(lv["auto_start"]), player=lv["player"].strip().lower() or "auto", audio_device=lv["audio_device"].strip(),
                workers=max(0, _int(lv["render_workers"], 0)), mutate_p=max(0, min(100, _int(lv["mutate"], 0))) / 100)
    k = ge["key"].strip()
    key = None if k.lower() in ("", "auto") else (NOTE.index(k.upper()) if k.upper() in NOTE else _int(k, 0) % 12)
    gen = dict(style=ge["style"].strip() or "Brostep", bpm=_int(ge["bpm"], 0), key=key, scale=ge["scale"].strip().strip('"') or "minor",
               energy=_float(ge["energy"], 0.7), density=_float(ge["density"], 0.6), swing=_float(ge["swing"], -1), instruments=ge["instruments"].strip() or "style",
               speak_text=ge["speak_text"].strip() or None)
    paths = dict(library=pa["library"].strip(), plugin_dir=pa["plugin_dir"].strip(), presets=pa["presets"].strip())
    return dict(path=path, icecast=icecast, live=live, generator=gen, paths=paths)


def apply_env(conf):
    """[paths] -> zmienne środowiskowe (jeśli nie ustawione przez użytkownika w powłoce)."""
    if conf["paths"]["library"]:
        os.environ.setdefault("DS_LIBRARY", os.path.expanduser(conf["paths"]["library"]))
    if conf["paths"]["presets"]:
        os.environ.setdefault("DS_PRESETS", os.path.expanduser(conf["paths"]["presets"]))
    lv = conf["live"]
    if lv["player"] not in ("", "auto"):
        os.environ.setdefault("DS_LIVE_PLAYER", lv["player"])
    if lv["audio_device"]:
        os.environ.setdefault("DS_AUDIO_DEVICE", lv["audio_device"])
    if lv["workers"]:
        os.environ.setdefault("DS_WORKERS", str(lv["workers"]))
    if conf["paths"]["plugin_dir"]:
        os.environ.setdefault("DS_PLUGIN_DIR", os.path.expanduser(conf["paths"]["plugin_dir"]))


def save_values(path, updates: dict):
    """updates = {("icecast","host"): "x", ...}. Podmienia wartości w miejscu (komentarze zostają), brakujące klucze dopisuje na końcu sekcji."""
    path = Path(path)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else DEFAULT_TEXT.splitlines()
    for (sec, key), val in updates.items():
        val = str(val).replace("\n", " ")
        cur, done, last = None, False, None
        for i, ln in enumerate(lines):
            s = ln.strip()
            if s.startswith("[") and s.endswith("]"):
                if cur == sec and not done:
                    break
                cur = s[1:-1].strip().lower(); last = i if cur == sec else last; continue
            if cur == sec:
                last = i
                if s and not s.startswith(("#", ";")) and "=" in s and s.split("=", 1)[0].strip().lower() == key:
                    lines[i] = f"{key} = {val}"; done = True; break
        if done:
            continue
        if last is None:                                   # brak sekcji
            lines += ["", f"[{sec}]", f"{key} = {val}"]
        else:
            lines.insert(last + 1, f"{key} = {val}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def to_live_cfg(conf, base_cfg):
    """Nakłada [live] na DEFAULT_CFG-podobny słownik silnika."""
    import copy
    from . import live as L
    c = copy.deepcopy(base_cfg); lv = conf["live"]
    c.update(mode=lv["mode"], arr_bars=lv["arr_bars"], lookahead=lv["lookahead"], max_store=lv["max_store"], return_live=lv["return_live"],
             tod_on=lv["tod_on"], tod_force=lv["tod_force"], tod_factors=dict(lv["tod_factors"]), mutate_p=lv["mutate_p"])
    c["locks"] = {k: (k in lv["locks"]) for k in L.LOCK_KEYS}
    return c


def to_base(conf):
    """Baza generatora z [generator] (tryb bez GUI)."""
    from . import core, generator as G
    g = conf["generator"]; style = g["style"] if g["style"] in G.STYLES else "Brostep"
    ins = g["instruments"]
    if ins == "style":
        inst = G.default_instruments(style)
    elif ins == "core8":
        inst = list(core.CORE8)
    elif ins == "all":
        inst = core.available_types()
    else:
        inst = [t.strip() for t in ins.split(",") if t.strip() in core.TYPES]
    return dict(style=style, bpm=g["bpm"] or G.STYLES[style]["bpm"], key=g["key"], scale=g["scale"] if g["scale"] in core.SCALES else "minor",
                energy=g["energy"], density=g["density"], swing=G.STYLES[style]["swing"] if g["swing"] < 0 else g["swing"],
                instruments=inst or G.default_instruments(style), speak_text=g["speak_text"], speak_theme=None)
