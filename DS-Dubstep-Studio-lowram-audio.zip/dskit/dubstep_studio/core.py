"""core.py — model projektu, hostowanie wtyczek CLAP (przez dsrender), automatyzacja z linków,
render/mix, eksport MIDI/MP3 i biblioteka."""
from __future__ import annotations

import concurrent.futures as cf
import datetime
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np

APP_DIR = Path(__file__).resolve().parent.parent
TYPES = ["kick", "snare", "hat", "clap", "rim", "tom", "crash", "shaker",
         "sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow",
         "screech", "supersaw", "pluck", "pad", "stab", "vox",
         "riser", "boom", "zap", "speak", "theremin", "panflute", "handpan", "tongue"]
OPTIONAL = {"speak", "theremin", "panflute", "handpan", "tongue"}  # wtyczki opcjonalne: brak pliku .clap nie blokuje aplikacji; nigdy nie są w paletach domyślnych
CORE8 = ["kick", "snare", "hat", "sub", "wobble", "reese", "growl", "screech"]
GROUPS = {"Perkusja": TYPES[0:8], "Bas": TYPES[8:15], "Synth / lead": TYPES[15:21], "FX": TYPES[21:24], "Mowa": TYPES[24:25], "Akustyczne": TYPES[25:29]}
MELODIC = {"sub", "wobble", "reese", "growl", "neuro", "fmbass", "hollow", "screech", "supersaw", "pluck", "pad", "stab", "vox", "riser", "speak", "theremin", "panflute", "handpan", "tongue"}
PLUGIN_ID = {t: f"stpf99.dubstep.{t}" for t in TYPES}
DEFAULT_GAIN = dict(kick=1.0, snare=0.9, hat=0.65, clap=0.7, rim=0.5, tom=0.8, crash=0.5, shaker=0.4, sub=1.0, wobble=0.9,
                    reese=0.7, growl=0.8, neuro=0.75, fmbass=0.75, hollow=0.85, screech=0.7, supersaw=0.55, pluck=0.6,
                    pad=0.5, stab=0.6, vox=0.6, riser=0.6, boom=0.9, zap=0.6, speak=0.7, theremin=0.6, panflute=0.6, handpan=0.8, tongue=0.8)
SR = 48000
RES = 0.125  # rozdzielczość automatyzacji (beaty) = 1/32 nuty
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
SCALES = {"minor": [0, 2, 3, 5, 7, 8, 10], "phrygian": [0, 1, 3, 5, 7, 8, 10], "harmonic minor": [0, 2, 3, 5, 7, 8, 11],
          "major": [0, 2, 4, 5, 7, 9, 11], "dorian": [0, 2, 3, 5, 7, 9, 10], "mixolydian": [0, 2, 4, 5, 7, 9, 10], "lydian": [0, 2, 4, 6, 7, 9, 11]}
LINK_SOURCES = ["kick", "snare", "hat", "clap", "tom", "crash", "energy", "build", "bar_phase", "bass_note"]
DRUM_SRC = {"kick", "snare", "hat", "clap", "tom", "crash"}


# ------------------------------------------------------------------ meta wtyczek
def _num(txt):
    m = re.match(r"\s*(-?\d+(?:\.\d+)?)\s*(.*)$", txt)
    return (float(m.group(1)), m.group(2).strip()) if m else (None, "")


class Meta:
    """Odkrywa pliki .clap, wywołuje `dsrender --dump`, wylicza typy parametrów."""

    def __init__(self):
        self.render = self._find_render()
        self.plugins = {}
        for f in self._clap_files():
            try:
                out = subprocess.run([self.render, "--dump", str(f)], capture_output=True, text=True, timeout=30)
                for pl in json.loads(out.stdout):
                    if pl["id"] in self.plugins:
                        continue
                    pl["file"] = str(f)
                    pl["params"] = {p["name"]: self._mk(p) for p in pl["params"]}
                    self.plugins[pl["id"]] = pl
            except Exception:
                continue
        missing = [t for t in TYPES if t not in OPTIONAL and PLUGIN_ID[t] not in self.plugins]
        if missing:
            raise RuntimeError(f"Brak wtyczek CLAP: {missing}. Zbuduj je (make) lub ustaw DS_PLUGIN_DIR.")

    @staticmethod
    def _find_render():
        for c in [APP_DIR / "build" / "dsrender", shutil.which("dsrender")]:
            if c and Path(c).exists():
                return str(c)
        raise RuntimeError("Nie znaleziono build/dsrender — uruchom `make` w katalogu projektu.")

    @staticmethod
    def _clap_files():
        dirs = [Path(os.environ["DS_PLUGIN_DIR"])] if os.environ.get("DS_PLUGIN_DIR") else []
        dirs += [APP_DIR / "build", Path.home() / ".clap"]
        out = []
        for d in dirs:
            if (d / "DubstepKit.clap").exists():
                out.append(d / "DubstepKit.clap")
            out += sorted(d.glob("DS-*.clap"))
        return out

    @staticmethod
    def _mk(p):
        lo_t, unit = _num(p["tmin"]); hi_t, unit2 = _num(p["tmax"])
        unit = unit2 or unit
        if p["stepped"]:
            kind, lo, hi = "int", p["min"], p["max"]
        elif p["min"] == 0 and p["max"] == 1 and unit:
            kind, lo, hi = "log", lo_t, hi_t
        else:
            kind, lo, hi = "lin", p["min"], p["max"]
        p.update(kind=kind, lo=lo, hi=hi, unit=unit)
        return p

    def has(self, track, name):
        return name in self.plugins[PLUGIN_ID[track]]["params"]

    def param(self, track, name):
        return self.plugins[PLUGIN_ID[track]]["params"][name]

    # eng <-> frac(0..1 zakresu CLAP) <-> clap
    def eng2frac(self, track, name, e):
        p = self.param(track, name)
        if p["kind"] == "log":
            c = math.log(max(p["lo"], min(p["hi"], e)) / p["lo"]) / math.log(p["hi"] / p["lo"])
        else:
            c = max(p["min"], min(p["max"], e))
        return (c - p["min"]) / (p["max"] - p["min"])

    def frac2clap(self, track, name, f):
        p = self.param(track, name)
        v = p["min"] + max(0.0, min(1.0, f)) * (p["max"] - p["min"])
        return round(v) if p["stepped"] else v

    def frac2eng(self, track, name, f):
        p = self.param(track, name)
        if p["kind"] == "log":
            return p["lo"] * (p["hi"] / p["lo"]) ** f
        v = p["min"] + f * (p["max"] - p["min"])
        return round(v) if p["kind"] == "int" else v

    def def_frac(self, track, name):
        p = self.param(track, name)
        return (p["def"] - p["min"]) / (p["max"] - p["min"])

    def fmt(self, track, name, f):
        p = self.param(track, name)
        e = self.frac2eng(track, name, f)
        if p["texts"]:
            return p["texts"][int(round(e - p["min"]))]
        if p["kind"] == "int":
            return str(int(e))
        s = f"{e:.2f}" if abs(e) < 10 else (f"{e:.1f}" if abs(e) < 1000 else f"{e:.0f}")
        return f"{s} {p['unit']}".strip()


_META = None


def meta() -> Meta:
    global _META
    if _META is None:
        _META = Meta()
    return _META


def available_types():
    """Typy, dla których znaleziono wtyczkę CLAP (opcjonalne, np. speak, mogą nie być zbudowane)."""
    m = meta()
    return [t for t in TYPES if PLUGIN_ID[t] in m.plugins]


# ------------------------------------------------------------------ projekt
def type_of_name(name):
    t = name.rstrip("0123456789")
    return t if t in PLUGIN_ID else name


def new_track(name, ttype=None):
    ttype = ttype or type_of_name(name)
    tr = {"name": name, "type": ttype, "plugin": PLUGIN_ID[ttype], "params": {}, "notes": [], "auto": {},
          "gain": DEFAULT_GAIN[ttype], "mute": False, "solo": False}
    # routing: "pre" = nuty z innej ścieżki (+transpozycja), "post/filtr" = audio innej ścieżki jako wejście tego instrumentu
    tr.update(notes_from=None, notes_transpose=0, input_from=None, input_mix=1.0, input_hide_source=True)
    if ttype == "speak":   # tekst czytany przez DS Speak: auto (generator układa) albo manual (wpisany)
        tr.update(text="", text_mode="auto", text_theme=None)
    return tr


def new_project(**kw):
    p = {"version": 2, "name": "untitled", "bpm": 140, "style": "Brostep", "key": 5, "scale": "minor",
         "bars": 0, "seed": 0, "swing": 0.0, "energy": 0.7, "density": 0.6, "sections": [], "chords": [],
         "tracks": [], "links": [], "parents": [], "created": ""}
    p.update(kw)
    return p


def ensure_types(proj):
    for t in proj["tracks"]:
        t.setdefault("type", type_of_name(t["name"]))
    return proj


def track_of(proj, name):
    return next(t for t in proj["tracks"] if t["name"] == name)


def find_track(proj, name):
    return next((t for t in proj["tracks"] if t["name"] == name), None)


def first_of_type(proj, ttype):
    return next((t for t in proj["tracks"] if t["type"] == ttype), None)


def unique_name(proj, ttype):
    names = {t["name"] for t in proj["tracks"]}
    if ttype not in names:
        return ttype
    k = 2
    while f"{ttype}{k}" in names:
        k += 1
    return f"{ttype}{k}"


def key_name(proj):
    return f"{NOTE_NAMES[proj['key'] % 12]} {proj['scale']}"


def section_at_bar(proj, bar):
    for s in proj["sections"]:
        if s["start"] <= bar < s["start"] + s["bars"]:
            return s
    return proj["sections"][-1]


# ------------------------------------------------------------------ sygnały i automatyzacja z linków
def _hits(proj, ttype, n):
    h = np.zeros(n)
    tr = first_of_type(proj, ttype)
    for on, dur, key, vel in (tr["notes"] if tr else []):
        i = int(round(on / RES))
        if 0 <= i < n:
            h[i] = max(h[i], vel / 127.0)
    return h


def _follow(h, rel):
    out = np.zeros_like(h); k = math.exp(-RES / max(rel, 1e-3)); v = 0.0
    for i, x in enumerate(h):
        v = max(x, v * k)
        out[i] = v
    return out


def signal(proj, src, n, rel=0.5):
    if src in DRUM_SRC:
        return _follow(_hits(proj, src, n), rel)
    t = np.arange(n) * RES
    if src == "bar_phase":
        return (t / 4.0) % 1.0
    out = np.zeros(n)
    if src in ("energy", "build"):
        for s in proj["sections"]:
            a, b = int(s["start"] * 4 / RES), int((s["start"] + s["bars"]) * 4 / RES)
            if src == "energy":
                ramp = np.linspace(s["e0"], s["e1"], b - a, endpoint=False)
            else:
                ramp = np.linspace(0, 1, b - a, endpoint=False) if s["type"] == "build" else np.zeros(b - a)
            b2 = min(b, n)
            out[a:b2] = ramp[: b2 - a]
        return out
    if src == "bass_note":
        bt = first_of_type(proj, "sub") or first_of_type(proj, "wobble") or first_of_type(proj, "hollow")
        cur, notes, j = 0.5, sorted(bt["notes"] if bt else []), 0
        for i in range(n):
            while j < len(notes) and notes[j][0] <= i * RES + 1e-6:
                cur = min(1.0, max(0.0, (notes[j][2] - 24) / 12.0)); j += 1
            out[i] = cur
        return out
    return out


def build_automation(proj, m: Meta):
    """-> {track_index: {param_name: [(beat, frac), ...]}} (kolejne wartości stałe)."""
    n = int(proj["bars"] * 4 / RES) + 1
    lanes = {}
    for i, t in enumerate(proj["tracks"]):
        pm = m.plugins[t["plugin"]]["params"]
        lanes[i] = {}
        for name, pts in t["auto"].items():
            if name in pm:
                lanes[i][name] = [(b, f) for b, f in sorted(pts)]
    # kontrybucje linków
    contrib = {}
    for L in proj["links"]:
        dt = find_track(proj, L["dst"])
        if dt is None or not m.has(dt["type"], L["param"]) or m.param(dt["type"], L["param"])["kind"] == "int":
            continue
        sig = signal(proj, L["src"], n, L.get("rel", 0.5)) * L["amount"]
        contrib.setdefault((L["dst"], L["param"]), np.zeros(n))
        contrib[(L["dst"], L["param"])] += sig
    for (dst, name), arr in contrib.items():
        i = next(k for k, t in enumerate(proj["tracks"]) if t["name"] == dst)
        t = proj["tracks"][i]
        base = np.full(n, t["params"].get(name, m.def_frac(t["type"], name)))
        if name in lanes[i]:  # jawna automatyzacja jako baza (krokowa)
            pts, k, cur = lanes[i][name], 0, base[0]
            for j in range(n):
                while k < len(pts) and pts[k][0] <= j * RES + 1e-6:
                    cur = pts[k][1]; k += 1
                base[j] = cur
        val = np.clip(base + arr, 0.0, 1.0)
        out, last = [], None
        for j in range(n):
            if last is None or abs(val[j] - last) > 0.003:
                out.append((j * RES, float(val[j]))); last = val[j]
        lanes[i][name] = out
    return lanes


# ------------------------------------------------------------------ routing (pre: nuty, post: audio)
def eff_notes(proj, t, _depth=0):
    """Nuty ścieżki po routingu 'pre': jeśli notes_from wskazuje inną ścieżkę, grają jej nuty (+ transpozycja)."""
    src = find_track(proj, t.get("notes_from")) if t.get("notes_from") else None
    if src is None or src is t or _depth > 8:
        return t["notes"]
    tr = int(t.get("notes_transpose", 0))
    return [[on, dur, int(k) + tr, vel] for on, dur, k, vel in eff_notes(proj, src, _depth + 1)]


def input_source(proj, t):
    n = t.get("input_from")
    s = find_track(proj, n) if n else None
    return s if s is not None and s is not t else None


def _levels(proj):
    """Poziomy renderu: ścieżki bez wejścia audio = 0, zależne od nich = 1, ... (cykle są rozcinane)."""
    lv = {}

    def f(t, seen):
        if t["name"] in lv:
            return lv[t["name"]]
        s = input_source(proj, t)
        r = 0 if s is None or s["name"] in seen else f(s, seen | {t["name"]}) + 1
        lv[t["name"]] = r
        return r
    for t in proj["tracks"]:
        f(t, frozenset())
    return lv


def consumed_sources(proj):
    """Ścieżki ukryte w miksie, bo zasilają wejście audio innej ścieżki (input_hide_source)."""
    return {t["input_from"] for t in proj["tracks"] if input_source(proj, t) is not None and t.get("input_hide_source", True)}


# ------------------------------------------------------------------ render
def _write_job(path, outp, proj, t, lanes, m, notes=None, in_path=None):
    pl = m.plugins[t["plugin"]]; pm = pl["params"]; bpm = proj["bpm"]
    sec = lambda b: b * 60.0 / bpm
    L = [f"sr {SR}", f"bpm {bpm}", f"len {sec(proj['bars'] * 4):.4f}", "tail 3.0", f"plugin {pl['file']} {pl['id']}", f"out {outp}"]
    params = dict(t["params"])
    if in_path:
        params["Input Mix"] = max(0.0, min(1.0, float(t.get("input_mix", 1.0))))
        L.append(f"in {in_path}")
    for name, f in params.items():
        if name in pm:
            L.append(f"p {pm[name]['id']} {m.frac2clap(t['type'], name, f):.8g}")
    for name, pts in lanes.items():
        for b, f in pts:
            L.append(f"a {sec(b):.5f} {pm[name]['id']} {m.frac2clap(t['type'], name, f):.8g}")
    if t.get("text"):
        L.append("text " + t["text"].replace("\\", "\\\\").replace("\r", "").replace("\n", "\\n"))
    for on, dur, key, vel in (notes if notes is not None else t["notes"]):
        L.append(f"n {sec(on):.5f} {max(0.001, sec(dur)):.5f} {int(key)} {vel / 127.0:.4f}")
    Path(path).write_text("\n".join(L) + "\n")


def default_workers():
    """Liczba równoległych procesów dsrender. DS_WORKERS wymusza; inaczej min(rdzenie, 8, wolny RAM / 150 MB) — na SBC z 512 MB wychodzi 1–2."""
    env = os.environ.get("DS_WORKERS", "").strip()
    if env.isdigit() and int(env) > 0:
        return int(env)
    try:
        mem = int([l for l in open("/proc/meminfo") if l.startswith("MemAvailable")][0].split()[1]) // 1024
    except Exception:
        mem = 4096
    return max(1, min(8, os.cpu_count() or 4, mem // 150))


def render_stems(proj, progress=None, cache=None, sink=None, workers=None):
    """-> {track_name: np.ndarray (n,2) float32}. cache: dict klucz->tablica (pomija niezmienione ścieżki).
    Ścieżki z wejściem audio (input_from) renderowane są po swoich źródłach (poziomami, równolegle w obrębie poziomu).
    sink(name, arr): tryb oszczędny — każdy stem trafia do sink od razu i nie jest trzymany w pamięci (poza źródłami dla input_from); bez cache."""
    import hashlib
    m = meta(); lanes = build_automation(proj, m)
    cache = cache if cache is not None else {}
    work = Path(tempfile.mkdtemp(prefix="dsr_")); res = {}; keys = {}
    lv = _levels(proj); idx = {t["name"]: i for i, t in enumerate(proj["tracks"])}
    done = [0]; srcs = {s_["name"] for s_ in (input_source(proj, t) for t in proj["tracks"]) if s_ is not None}
    try:
        def key_of(i):
            t = proj["tracks"][i]
            if t["name"] in keys:
                return keys[t["name"]]
            src = input_source(proj, t)
            sk = key_of(idx[src["name"]]) if src is not None and lv[src["name"]] < lv[t["name"]] else ""
            ck = hashlib.md5(json.dumps([t["plugin"], t["params"], eff_notes(proj, t), lanes[i], proj["bpm"], proj["bars"],
                                         t.get("text", ""), sk, t.get("input_mix", 1.0) if sk else 0]).encode()).hexdigest()
            keys[t["name"]] = ck
            return ck

        def one(i):
            t = proj["tracks"][i]; ck = key_of(i)
            if ck in cache:
                return t["name"], cache[ck]
            job, outp = work / f"{t['name']}.job", work / f"{t['name']}.f32"
            src = input_source(proj, t); in_path = None
            if src is not None and src["name"] in res:
                in_path = work / f"{t['name']}.in.f32"
                res[src["name"]].astype("<f4").tofile(in_path)
            _write_job(job, outp, proj, t, lanes[i], m, notes=eff_notes(proj, t), in_path=in_path)
            r = subprocess.run([m.render, str(job)], capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"dsrender {t['name']}: {r.stderr[-300:]}")
            arr = np.fromfile(outp, dtype="<f4").reshape(-1, 2)
            if sink is None:
                cache[ck] = arr
            try:
                outp.unlink(); job.unlink()
            except OSError:
                pass
            return t["name"], arr
        with cf.ThreadPoolExecutor(max_workers=workers or default_workers()) as ex:
            for level in range(max(lv.values()) + 1 if lv else 0):
                batch = [i for i, t in enumerate(proj["tracks"]) if lv[t["name"]] == level]
                for name, arr in ex.map(one, batch):
                    if sink is None or name in srcs:
                        res[name] = arr
                    if sink is not None:
                        sink(name, arr)
                    del arr; done[0] += 1
                    if progress:
                        progress(done[0] / len(proj["tracks"]))
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return res


def _finalize_mix(x):
    """Normalizacja + soft-clip w miejscu (bez kopii całego miksu)."""
    pk = float(np.percentile(np.abs(x[::4]), 99.9)) or 1.0
    x *= np.float32(1.1 * 0.8 / pk); np.tanh(x, out=x); x *= np.float32(0.95)
    return x


def mix_stems(proj, stems):
    solo = any(t["solo"] for t in proj["tracks"])
    hidden = consumed_sources(proj)
    n = max(len(a) for a in stems.values())
    x = np.zeros((n, 2), dtype=np.float32)
    for t in proj["tracks"]:
        if t["mute"] or (solo and not t["solo"]) or (t["name"] in hidden and not t["solo"]):
            continue
        a = stems[t["name"]]; x[: len(a)] += a * t["gain"]
    return _finalize_mix(x)


def render_mix(proj, progress=None, workers=None):
    """Jak mix_stems(render_stems(...)), ale w pamięci jest tylko miks + stemy aktualnie renderowane (ważne na SBC z 512 MB RAM)."""
    solo = any(t["solo"] for t in proj["tracks"]); hidden = consumed_sources(proj); by = {t["name"]: t for t in proj["tracks"]}
    box = {"x": None}

    def add(name, a):
        t = by[name]
        if t["mute"] or (solo and not t["solo"]) or (name in hidden and not t["solo"]):
            return
        if box["x"] is None:
            box["x"] = np.zeros((len(a), 2), dtype=np.float32)
        elif len(a) > len(box["x"]):
            box["x"] = np.pad(box["x"], ((0, len(a) - len(box["x"])), (0, 0)))
        box["x"][: len(a)] += a * t["gain"]
    render_stems(proj, progress, None, sink=add, workers=workers)
    if box["x"] is None:
        raise RuntimeError("Brak słyszalnych ścieżek do zmiksowania.")
    return _finalize_mix(box["x"])


def write_wav(path, arr):
    with wave.open(str(path), "wb") as w:                      # porcjami: bez pełnej kopii int16 w pamięci
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        for a in range(0, len(arr), 1 << 18):
            w.writeframes((np.clip(arr[a: a + (1 << 18)], -1, 1) * 32767).astype("<i2").tobytes())


def export_mp3(wav_path, mp3_path):
    ff = shutil.which("ffmpeg")
    if ff:
        r = subprocess.run([ff, "-y", "-loglevel", "error", "-i", str(wav_path), "-b:a", "256k", str(mp3_path)])
        return r.returncode == 0
    lame = shutil.which("lame")
    if lame:
        return subprocess.run([lame, "--quiet", "-b", "256", str(wav_path), str(mp3_path)]).returncode == 0
    return False


# ------------------------------------------------------------------ MIDI
def _vlq(n):
    out = [n & 0x7F]; n >>= 7
    while n:
        out.append((n & 0x7F) | 0x80); n >>= 7
    return bytes(reversed(out))


def write_midi(proj, path, ppq=480):
    import struct
    chunks = []
    total = int(proj["bars"] * 4 * ppq)
    for ch, t in enumerate(proj["tracks"]):
        ev = []
        chn = ch % 16
        for on, dur, key, vel in eff_notes(proj, t):
            a = int(round(on * ppq)); b = max(a + 1, int(round((on + dur) * ppq)))
            ev.append((a, 1, bytes([0x90 | chn, int(key), int(vel)]))); ev.append((b, 0, bytes([0x80 | chn, int(key), 0])))
        ev.sort(key=lambda e: (e[0], e[1]))
        nm = ("DS " + t["name"].capitalize()).encode()
        d = _vlq(0) + b"\xff\x03" + _vlq(len(nm)) + nm
        if ch == 0:
            d += _vlq(0) + b"\xff\x51\x03" + struct.pack(">I", int(60000000 / proj["bpm"]))[1:]
            d += _vlq(0) + b"\xff\x58\x04\x04\x02\x18\x08"
        cur = 0
        for tick, _, b in ev:
            d += _vlq(tick - cur) + b; cur = tick
        d += _vlq(max(0, total - cur)) + b"\xff\x2f\x00"
        chunks.append(b"MTrk" + struct.pack(">I", len(d)) + d)
    Path(path).write_bytes(b"MThd" + struct.pack(">IHHH", 6, 1, len(chunks), ppq) + b"".join(chunks))


# ------------------------------------------------------------------ biblioteka
def lib_dir() -> Path:
    d = Path(os.environ.get("DS_LIBRARY", Path.home() / "DubstepStudio" / "library"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_project(proj, path):
    Path(path).write_text(json.dumps(proj, separators=(",", ":")))


def load_project(path):
    p = Path(path)
    if p.is_dir():
        p = p / "project.dsproj"
    return ensure_types(json.loads(p.read_text()))


def save_to_library(proj, stems=None, progress=None, with_stems=False):
    """Renderuje (jeśli trzeba) i zapisuje: project.dsproj + track.mid + track.mp3 (lub .wav) [+ stems/]."""
    stems = stems or render_stems(proj, progress)
    mix = mix_stems(proj, stems)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    proj["created"] = stamp
    slug = re.sub(r"[^A-Za-z0-9]+", "-", proj["name"]).strip("-") or "track"
    d = lib_dir() / f"{stamp}_{slug}"
    d.mkdir(parents=True, exist_ok=True)
    proj["id"] = d.name
    save_project(proj, d / "project.dsproj")
    write_midi(proj, d / "track.mid")
    wav_p = d / "track.wav"; write_wav(wav_p, mix)
    if export_mp3(wav_p, d / "track.mp3"):
        wav_p.unlink()
    if with_stems:
        (d / "stems").mkdir(exist_ok=True)
        for n, a in stems.items():
            write_wav(d / "stems" / f"{n}.wav", np.clip(a, -1, 1))
    return d


def list_library():
    out = []
    for d in sorted(lib_dir().iterdir(), reverse=True):
        f = d / "project.dsproj"
        if f.exists():
            try:
                p = json.loads(f.read_text())
                audio = next((d / x for x in ("track.mp3", "track.wav") if (d / x).exists()), None)
                out.append({"path": d, "name": p["name"], "style": p["style"], "bpm": p["bpm"], "key": key_name(p),
                            "bars": p["bars"], "seed": p["seed"], "created": p.get("created", ""),
                            "audio": audio, "parents": p.get("parents", [])})
            except Exception:
                pass
    return out


def delete_library_entry(path):
    shutil.rmtree(path, ignore_errors=True)
