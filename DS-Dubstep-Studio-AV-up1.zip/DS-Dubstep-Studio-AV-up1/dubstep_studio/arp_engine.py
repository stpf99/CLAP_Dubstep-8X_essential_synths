"""arp_engine.py — uniwersalny arpeggiator (kroki 1–24, tryby, gate, wysokości).

Podobny do DAW: pattern/mode, liczba kroków, rate, gate na krokach, oktawy.
Schemat może być stały (z GUI) albo wylosowany pod wagi generatora (density/energy/style).
Stosowany opcjonalnie — gdy cfg/project ma arp.enabled.
"""
from __future__ import annotations

import random
import zlib

MODES = (
    "up", "down", "updown", "downup",
    "converge", "diverge", "random", "chord", "as_played",
)
MODE_LABELS = {
    "up": "Up", "down": "Down", "updown": "Up-Down", "downup": "Down-Up",
    "converge": "Converge", "diverge": "Diverge", "random": "Random order",
    "chord": "Chord (all together)", "as_played": "As played (chord order)",
}

# rate: co ile 16-tek wypada krok (1 = 1/16, 2 = 1/8, 4 = 1/4 …)
RATES = (1, 2, 3, 4, 6, 8)

DEFAULT = dict(
    enabled=False,
    mode="up",
    steps=8,           # 1..24
    rate=2,            # 16th subdivisions between steps
    gate=0.85,         # global gate 0..1 (długość nuty względem slotu)
    gate_steps=None,   # lista 0..1 per step albo None = global
    octaves=1,         # 0..3 dodatkowe oktawy w górę
    octave_low=0,      # 0..2 oktawy w dół
    prob=1.0,          # prawdopodobieństwo wystąpienia kroku
    swing=0.0,         # 0..0.5 opóźnienie parzystych
    velocity=0.75,     # baza velocity 0..1 → 1..127
    vel_accent=0.15,   # akcent co rate*2
    chord_extra=False, # w trybie nie-chord: czasem pełny akord na 1
    sections=("drop", "break", "intro"),  # gdzie gra
)


def normalize(cfg):
    if not cfg:
        return dict(DEFAULT)
    out = dict(DEFAULT)
    out.update({k: cfg[k] for k in DEFAULT if k in cfg})
    out["enabled"] = bool(cfg.get("enabled", out["enabled"]))
    out["mode"] = str(cfg.get("mode") or "up")
    if out["mode"] not in MODES:
        out["mode"] = "up"
    out["steps"] = max(1, min(24, int(cfg.get("steps") or 8)))
    out["rate"] = int(cfg.get("rate") or 2)
    if out["rate"] not in RATES:
        out["rate"] = 2
    out["gate"] = max(0.05, min(1.0, float(cfg.get("gate") or 0.85)))
    gs = cfg.get("gate_steps")
    if gs and isinstance(gs, (list, tuple)):
        out["gate_steps"] = [max(0.0, min(1.0, float(x))) for x in gs][:24]
        while len(out["gate_steps"]) < out["steps"]:
            out["gate_steps"].append(out["gate"])
    else:
        out["gate_steps"] = None
    out["octaves"] = max(0, min(3, int(cfg.get("octaves") or 1)))
    out["octave_low"] = max(0, min(2, int(cfg.get("octave_low") or 0)))
    out["prob"] = max(0.0, min(1.0, float(cfg.get("prob") or 1.0)))
    out["swing"] = max(0.0, min(0.5, float(cfg.get("swing") or 0.0)))
    out["velocity"] = max(0.05, min(1.0, float(cfg.get("velocity") or 0.75)))
    out["vel_accent"] = max(0.0, min(0.5, float(cfg.get("vel_accent") or 0.15)))
    secs = cfg.get("sections")
    if secs:
        out["sections"] = tuple(secs)
    return out


def design_from_weights(density=0.6, energy=0.7, style_class=2.5, rng=None, base=None):
    """Unikalny schemat arp pod wagi generatora (nie zawsze ten sam)."""
    rng = rng or random.Random()
    cfg = normalize(base)
    cfg["enabled"] = True
    # kroki: gęstość → więcej kroków
    cfg["steps"] = int(max(3, min(24, round(4 + density * 16 + rng.randint(-2, 2)))))
    # rate: energia wysoka → szybciej (mniejszy rate)
    if energy > 0.75:
        cfg["rate"] = rng.choice([1, 1, 2])
    elif energy < 0.4:
        cfg["rate"] = rng.choice([2, 4, 4, 6])
    else:
        cfg["rate"] = rng.choice([1, 2, 2, 3, 4])
    # tryb
    if style_class < 1.5:
        cfg["mode"] = rng.choice(["up", "updown", "as_played", "chord"])
    elif style_class > 3.5:
        cfg["mode"] = rng.choice(["up", "down", "random", "diverge", "updown"])
    else:
        cfg["mode"] = rng.choice(list(MODES))
    cfg["octaves"] = 0 if density < 0.35 else (1 if density < 0.7 else rng.choice([1, 2]))
    cfg["octave_low"] = 1 if energy < 0.45 and rng.random() < 0.4 else 0
    cfg["gate"] = max(0.2, min(0.95, 0.5 + density * 0.4 + rng.uniform(-0.1, 0.1)))
    # gate per step — czasem dziurawy
    if rng.random() < 0.45 + density * 0.2:
        cfg["gate_steps"] = [
            0.0 if rng.random() < (0.25 * (1 - density)) else
            max(0.15, min(1.0, cfg["gate"] + rng.uniform(-0.25, 0.15)))
            for _ in range(cfg["steps"])
        ]
    cfg["prob"] = max(0.55, min(1.0, 0.7 + density * 0.3))
    cfg["swing"] = rng.choice([0.0, 0.0, 0.08, 0.12, 0.18]) if energy < 0.7 else 0.0
    cfg["velocity"] = 0.55 + energy * 0.35
    cfg["vel_accent"] = 0.1 + energy * 0.15
    if style_class < 1.2:
        cfg["sections"] = ("intro", "break", "outro", "drop")
    elif style_class > 3.5:
        cfg["sections"] = ("drop", "build", "break")
    else:
        cfg["sections"] = ("drop", "break", "intro")
    return cfg


def _tone_pool(chord_tones, octaves, octave_low):
    """Lista interwałów (półtony od root w bazowej oktawie) z oktawami."""
    base = list(chord_tones) if chord_tones else [0, 3, 7]
    pool = []
    for o in range(-octave_low, octaves + 1):
        for t in base:
            pool.append(t + 12 * o)
    return pool or [0]


def _order_indices(n, mode, rng):
    """Kolejność indeksów w puli tonów dla danego trybu (dla length steps — cyklicznie)."""
    if n <= 0:
        return [0]
    idx = list(range(n))
    if mode == "up" or mode == "as_played":
        seq = idx
    elif mode == "down":
        seq = idx[::-1]
    elif mode == "updown":
        seq = idx + idx[-2:0:-1] if n > 1 else idx
    elif mode == "downup":
        seq = idx[::-1] + idx[1:-1] if n > 1 else idx
    elif mode == "converge":
        seq = []
        lo, hi = 0, n - 1
        while lo <= hi:
            seq.append(lo)
            if lo != hi:
                seq.append(hi)
            lo += 1; hi -= 1
    elif mode == "diverge":
        mid = n // 2
        seq = []
        for i in range(n):
            if i % 2 == 0:
                seq.append(min(n - 1, mid + i // 2))
            else:
                seq.append(max(0, mid - (i // 2 + 1)))
    elif mode == "random":
        seq = list(idx)
        rng.shuffle(seq)
    else:
        seq = idx
    return seq


def expand_pattern(cfg, chord_tones, rng=None):
    """Zwraca listę długości steps: (interval_semitones | None jeśli cisza, gate)."""
    cfg = normalize(cfg)
    rng = rng or random.Random(0)
    pool = _tone_pool(chord_tones, cfg["octaves"], cfg["octave_low"])
    order = _order_indices(len(pool), cfg["mode"], rng)
    steps = []
    for i in range(cfg["steps"]):
        g = cfg["gate"]
        if cfg["gate_steps"]:
            g = cfg["gate_steps"][i % len(cfg["gate_steps"])]
        if g <= 0.01 or rng.random() > cfg["prob"]:
            steps.append((None, 0.0))
            continue
        if cfg["mode"] == "chord":
            # marker: wszystkie tony — handled in notes_for_bar
            steps.append(("chord", g))
        else:
            steps.append((pool[order[i % len(order)]], g))
    return steps


def notes_for_bar(cfg, bar_index, root_midi, chord_tones, phase_k, rng=None):
    """Generuje nuty jednego taktu: lista [on_16th, dur_16th, midi, vel].

    phase_k — licznik ciągły między taktami (mutowany, zwracany).
    """
    cfg = normalize(cfg)
    rng = rng or random.Random(bar_index * 17 + phase_k)
    pool = _tone_pool(chord_tones, cfg["octaves"], cfg["octave_low"])
    order = _order_indices(len(pool), cfg["mode"], rng)
    rate = cfg["rate"]
    notes = []
    k = phase_k
    # sloty 0, rate, 2*rate, … < 16
    slots = list(range(0, 16, rate))
    n_slots = len(slots)
    for si, s16 in enumerate(slots):
        step_i = k % cfg["steps"]
        g = cfg["gate"]
        if cfg["gate_steps"]:
            g = cfg["gate_steps"][step_i % len(cfg["gate_steps"])]
        k += 1
        if g <= 0.01 or rng.random() > cfg["prob"]:
            continue
        # swing
        on = float(s16)
        if cfg["swing"] and (si % 2 == 1):
            on += rate * cfg["swing"]
        dur = max(0.15, rate * g)
        vel_base = int(1 + 126 * cfg["velocity"])
        if si % 2 == 0:
            vel_base = min(127, int(vel_base * (1.0 + cfg["vel_accent"])))
        vel = max(1, min(127, vel_base + rng.randint(-6, 6)))
        if cfg["mode"] == "chord":
            for t in (chord_tones or [0, 3, 7]):
                notes.append([on, dur, int(root_midi + t), vel])
        else:
            iv = pool[order[step_i % len(order)]]
            notes.append([on, dur, int(root_midi + iv), vel])
        # opcjonalny chord hit na początku
        if cfg.get("chord_extra") and si == 0 and cfg["mode"] != "chord" and rng.random() < 0.35:
            for t in (chord_tones or [0, 7])[:2]:
                notes.append([on, dur * 0.8, int(root_midi + t), max(1, vel - 15)])
    return notes, k


def should_play_section(cfg, sec_type):
    cfg = normalize(cfg)
    return sec_type in (cfg.get("sections") or DEFAULT["sections"])


def resolve_arp(proj=None, style_cfg=None, gui_arp=None, density=0.6, energy=0.7, style_class=2.5, rng=None, auto_chance=0.35):
    """Decyduje czy i jaki arp użyć: GUI > style cfg > losowy design (auto_chance)."""
    rng = rng or random.Random()
    if gui_arp and gui_arp.get("enabled"):
        return normalize(gui_arp)
    if style_cfg and style_cfg.get("arp"):
        a = style_cfg["arp"]
        if isinstance(a, dict):
            return normalize(dict(a, enabled=True))
        # legacy: arp = {pattern, step, prob}
        return normalize(dict(
            enabled=True,
            mode=str(a.get("pattern") or "up"),
            rate=int(a.get("step") or 2),
            prob=float(a.get("prob") or 1.0),
        ))
    if proj and proj.get("arp") and proj["arp"].get("enabled"):
        return normalize(proj["arp"])
    if rng.random() < auto_chance:
        return design_from_weights(density, energy, style_class, rng)
    return normalize({"enabled": False})


# ------------------------------------------------------------------ inject strukturalny
# Typy harmoniczne (długie nuty = „podkład” pod arp) i cele injectu
HARMONIC_HOSTS = ("pad", "keys", "piano", "strings", "atmosphere", "chord", "bass", "sub")
INJECT_TARGETS = ("pluck", "lead", "arp", "keys", "piano", "acid", "synth", "bell")

DEFAULT_INJECT = dict(
    enabled=True,           # gdy arp auto / structural
    min_dur=2.0,            # min. długość nuty-hosta w ćwierćnutach
    dens_mul=1.0,           # mnożnik gęstości injectu względem density projektu
    avoid_dense=0.55,       # nie injectuj, gdy tor już ma > tyle nut/takt
    tonal_follow=True,      # root/chord z nuty-hosta, nie tylko z sekcji
    balance_vel=True,       # velocity injectu ~ 0.7× host / energy
)


def _note_beats(n):
    """(on_beat, dur_beat, midi, vel) — nuty w projekcie bywają [on, dur, key, vel] w beatach."""
    if not n or len(n) < 3:
        return None
    on = float(n[0]); dur = float(n[1]); midi = int(n[2]); vel = float(n[3]) if len(n) > 3 else 0.8
    return on, dur, midi, vel


def find_long_tone_windows(proj, min_dur=2.0, hosts=None):
    """Okna (t0, t1, midi_pc, root_hint, section_type) z długich nut torów harmonicznych.

    Sortowane, scalone gdy nachodzą i ten sam pitch-class.
    """
    hosts = set(hosts or HARMONIC_HOSTS)
    wins = []
    for tr in proj.get("tracks") or []:
        if tr.get("mute") or tr.get("type") not in hosts:
            continue
        for n in tr.get("notes") or []:
            nb = _note_beats(n)
            if not nb:
                continue
            on, dur, midi, vel = nb
            if dur < min_dur:
                continue
            wins.append(dict(
                t0=on, t1=on + dur, midi=midi, pc=midi % 12,
                vel=vel, track=tr.get("name"), type=tr.get("type"),
            ))
    wins.sort(key=lambda w: (w["t0"], -w["t1"]))
    # merge overlapping same pc
    merged = []
    for w in wins:
        if merged and w["pc"] == merged[-1]["pc"] and w["t0"] <= merged[-1]["t1"] + 0.25:
            merged[-1]["t1"] = max(merged[-1]["t1"], w["t1"])
            merged[-1]["vel"] = max(merged[-1]["vel"], w["vel"])
        else:
            merged.append(dict(w))
    # section tag
    sections = proj.get("sections") or []
    for w in merged:
        w["sec"] = "drop"
        for s in sections:
            a = float(s.get("start") or 0) * 4.0
            b = a + float(s.get("bars") or 4) * 4.0
            mid = 0.5 * (w["t0"] + w["t1"])
            if a <= mid < b:
                w["sec"] = s.get("type") or "drop"
                break
    return merged


def _chord_from_pc(pc, scale_pcs, third=3):
    """Proste tony akordu od pitch-class względem skali projektu."""
    tones = [0]
    for iv in (third, 7, 10):
        t = (pc + iv) % 12
        # snap to scale if possible
        if scale_pcs:
            best = min(scale_pcs, key=lambda x: min((x - t) % 12, (t - x) % 12))
            tones.append((best - pc) % 12)
        else:
            tones.append(iv)
    # unique preserve order
    out, seen = [], set()
    for x in tones:
        if x not in seen:
            out.append(x); seen.add(x)
    return out or [0, 3, 7]


def structural_inject(proj, arp_cfg=None, inject=None, rng=None, density=None, energy=None):
    """Nakłada arp/seq na cele (pluck/lead/…) w oknach długich nut harmonicznych.

    - tonacja z nuty-hosta (pitch class) + skala projektu
    - gęstość injectu ~ density / unikaj torów już gęstych
    - velocity zrównoważona względem hosta i energy
    - sekcje z arp.sections nadal respektowane
    Zwraca raport {windows, injected_notes, tracks}.
    """
    arp = normalize(arp_cfg or proj.get("arp") or {"enabled": False})
    if not arp.get("enabled"):
        return {"windows": 0, "injected_notes": 0, "tracks": []}
    inj = dict(DEFAULT_INJECT)
    if isinstance(inject, dict):
        inj.update(inject)
    if not inj.get("enabled", True):
        return {"windows": 0, "injected_notes": 0, "tracks": []}

    rng = rng or random.Random(int(proj.get("seed") or 0) + 77)
    dens = float(density if density is not None else proj.get("density") or 0.6)
    ener = float(energy if energy is not None else proj.get("energy") or 0.7)
    min_dur = float(inj.get("min_dur", 2.0))
    windows = find_long_tone_windows(proj, min_dur=min_dur)
    if not windows:
        # fallback: całe dropy/buildy jako okna z root sekcji
        for s in proj.get("sections") or []:
            if s.get("type") not in (arp.get("sections") or DEFAULT["sections"]):
                continue
            t0 = float(s.get("start") or 0) * 4.0
            t1 = t0 + float(s.get("bars") or 4) * 4.0
            root = int(proj.get("key") or 0) + 60
            windows.append(dict(t0=t0, t1=t1, midi=root, pc=root % 12, vel=0.7, track="-", type="section", sec=s.get("type")))

    key = int(proj.get("key") or 0)
    try:
        from .core import SCALES
        scale_pcs = sorted((key + d) % 12 for d in SCALES.get(proj.get("scale") or "minor", SCALES.get("minor", (0, 2, 3, 5, 7, 8, 10))))
    except Exception:
        scale_pcs = [(key + d) % 12 for d in (0, 2, 3, 5, 7, 8, 10)]

    targets = [tr for tr in (proj.get("tracks") or [])
               if not tr.get("mute") and not tr.get("lock_notes")
               and tr.get("type") in INJECT_TARGETS]
    if not targets:
        return {"windows": len(windows), "injected_notes": 0, "tracks": []}

    # gęstość istniejąca per tor (nuty / takt)
    bars = max(1.0, float(proj.get("bars") or 16))
    existing = {}
    for tr in targets:
        existing[tr["name"]] = len(tr.get("notes") or []) / bars

    avoid = float(inj.get("avoid_dense", 0.55))
    dens_mul = float(inj.get("dens_mul", 1.0))
    # próg: przy density 0.6 ~ 4–8 nut/takt jest „gęsto”
    dense_lim = avoid * (6.0 + dens * 10.0)

    injected = 0
    touched = set()
    # lekko zwolnij rate gdy host jest bardzo długi (melodyjny łuk)
    base_rate = arp["rate"]

    for w in windows:
        if w.get("sec") and not should_play_section(arp, w["sec"]):
            continue
        span = max(0.5, w["t1"] - w["t0"])
        # ile taktów w oknie
        n_bars = max(1, int(round(span / 4.0)))
        # tonal
        if inj.get("tonal_follow", True):
            root_midi = int(w["midi"])
            # trzymaj w rejestrze melodycznym
            while root_midi < 55:
                root_midi += 12
            while root_midi > 76:
                root_midi -= 12
            tones = _chord_from_pc(w["pc"], scale_pcs)
        else:
            root_midi = 60 + (key % 12)
            tones = [0, 3, 7]

        # local arp cfg — dłuższe okno → trochę wolniejszy rate, wyższy gate
        local = dict(arp)
        if span >= 8:
            local["rate"] = min(8, base_rate + (2 if base_rate < 4 else 0))
            local["gate"] = min(0.95, local["gate"] * 1.1)
        elif span <= 3:
            local["rate"] = max(1, base_rate - 1)
        # balanced velocity
        if inj.get("balance_vel", True):
            local["velocity"] = max(0.35, min(0.9, 0.45 + 0.35 * ener + 0.2 * float(w.get("vel") or 0.7)))
            local["vel_accent"] = 0.08 + 0.12 * ener

        for tr in targets:
            if existing.get(tr["name"], 0) > dense_lim:
                continue
            # inject probability scales with density
            if rng.random() > min(0.95, 0.35 + dens * 0.55 * dens_mul):
                continue
            # generuj nuty takt po takcie w oknie
            t0, t1 = w["t0"], w["t1"]
            phase = zlib.crc32(tr["name"].encode("utf-8", "replace")) % 16
            bar0 = int(t0 // 4)
            bar1 = int((t1 - 0.01) // 4) + 1
            new_notes = []
            for bi in range(bar0, bar1):
                notes, phase = notes_for_bar(local, bi, root_midi, tones, phase, rng)
                for on16, dur16, midi, vel in notes:
                    on_beat = bi * 4.0 + on16 / 4.0
                    dur_beat = dur16 / 4.0
                    if on_beat < t0 - 0.05 or on_beat >= t1:
                        continue
                    # nie wystawiaj poza okno
                    if on_beat + dur_beat > t1:
                        dur_beat = max(0.1, t1 - on_beat)
                    new_notes.append([round(on_beat, 4), round(dur_beat, 4), int(midi), max(1, min(127, int(vel)))])
            if not new_notes:
                continue
            # dołącz, unikaj kolizji czasowej z istniejącymi (w obrębie 1/16)
            have = {(round(n[0] * 4), n[2] % 12) for n in (tr.get("notes") or [])}
            added = 0
            for n in new_notes:
                key_c = (round(n[0] * 4), n[2] % 12)
                if key_c in have:
                    continue
                tr.setdefault("notes", []).append(n)
                have.add(key_c)
                added += 1
            if added:
                tr["notes"].sort(key=lambda x: (x[0], x[2]))
                injected += added
                touched.add(tr["name"])
                existing[tr["name"]] = existing.get(tr["name"], 0) + added / bars

    report = dict(windows=len(windows), injected_notes=injected, tracks=sorted(touched))
    proj["arp_inject_report"] = report
    return report


def design_structural_arp(density, energy, style_class, rng, tod_slot=None, complexity=None):
    """Jak design_from_weights, ale sekcje/rate pod porę dnia i complexity (Live auto)."""
    cfg = design_from_weights(density, energy, style_class, rng)
    # pora dnia: noc/rano — wolniej, dłuższy gate; wieczór — gęściej
    if tod_slot in ("Noc", "Rano"):
        cfg["rate"] = max(cfg["rate"], 2)
        if rng.random() < 0.6:
            cfg["rate"] = min(6, cfg["rate"] + 1)
        cfg["gate"] = min(0.95, cfg["gate"] + 0.08)
        cfg["sections"] = ("intro", "break", "outro", "drop")
    elif tod_slot == "Wieczór":
        if energy > 0.55:
            cfg["rate"] = max(1, min(cfg["rate"], 2))
        cfg["sections"] = ("drop", "build", "break")
    if complexity in ("intense", "chaos", "energetic"):
        cfg["steps"] = min(24, cfg["steps"] + 4)
        cfg["prob"] = min(1.0, cfg["prob"] + 0.1)
    elif complexity in ("calm", "ambient", "minimal"):
        cfg["steps"] = max(3, cfg["steps"] // 2)
        cfg["rate"] = max(cfg["rate"], 4)
        cfg["sections"] = ("intro", "break", "outro")
    cfg["structural_inject"] = True
    return cfg
