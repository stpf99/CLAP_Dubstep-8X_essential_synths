"""presets.py — GLOBALNE presety (domyślnie puste): jeden plik JSON współdzielony przez GUI i tryb bez GUI.

Preset zapamiętuje: ustawienia zakładki Generator (styl — także hybrydę, BPM, tonacja, skala, takty, energia, gęstość, swing, instrumenty, Speak),
pole szachowe (komórki + siła mutacji) oraz tryb auto Live (tryb, blokady, pory dnia, takty, wyprzedzenie, mutacje).
Preset NIE zawiera ustawień Icecast (hasła zostają tylko w config.txt).

Plik: $DS_PRESETS albo [paths] presets z config.txt albo ~/DubstepStudio/presets.json. Nie istnieje, dopóki nie zapiszesz pierwszego presetu.
"""
from __future__ import annotations

import datetime
import json
import os
from pathlib import Path


def path() -> Path:
    return Path(os.environ["DS_PRESETS"]) if os.environ.get("DS_PRESETS") else Path.home() / "DubstepStudio" / "presets.json"


def load_all() -> dict:
    p = path()
    if not p.exists():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_all(d: dict):
    p = path(); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp"); tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8"); tmp.replace(p)


def names() -> list:
    return sorted(load_all(), key=str.lower)


def get(name):
    return load_all().get(name, {}).get("data")


def put(name, data):
    d = load_all(); d[name] = {"saved": datetime.datetime.now().isoformat(timespec="seconds"), "data": data}; save_all(d)


def delete(name):
    d = load_all()
    if d.pop(name, None) is not None:
        save_all(d)


def export_file(name, out):
    d = load_all()
    Path(out).write_text(json.dumps({name: d[name]}, ensure_ascii=False, indent=1), encoding="utf-8")


def import_file(src) -> list:
    """Dołącza presety z pliku (istniejące o tej samej nazwie są zastępowane). -> lista nazw."""
    inc = json.loads(Path(src).read_text(encoding="utf-8"))
    inc = {k: v for k, v in inc.items() if isinstance(v, dict) and isinstance(v.get("data"), dict)}
    d = load_all(); d.update(inc); save_all(d)
    return list(inc)


def to_engine(data):
    """Preset -> (baza generatora, nadpisania konfiguracji Live) dla trybu bez GUI.
    Przenosi pełny zestaw flag Generatora (jak live_gui.collect_base / config.to_base)."""
    g = data.get("generator", {}); live = dict(data.get("live", {}))
    board = data.get("board", {})
    live["board"] = board.get("cells", []); live["board_strength"] = board.get("strength", 0.4); live["use_board"] = bool(live.get("use_board"))
    if "mutate_p" in live:
        live["mutate_p"] = float(live["mutate_p"])
    base = dict(
        style=g.get("style", "Brostep"), bpm=g.get("bpm", 140), key=g.get("key"), scale=g.get("scale", "minor"),
        energy=g.get("energy", 0.7), density=g.get("density", 0.6), swing=g.get("swing", 0.0),
        instruments=g.get("instruments") or None,
        speak_text=g.get("speak_text") if g.get("speak_manual") else None, speak_theme=g.get("speak_theme"),
        smart_instruments=bool(g.get("smart_instruments")),
        autolevels=bool(g.get("autolevels")),
        role_swap=bool(g.get("role_swap")),
        scenarios=bool(g.get("scenarios")),
        character=g.get("character") or "balanced",
        director=g.get("director"),
        niuanse=bool(g.get("niuanse")),
        niuanse_strength=float(g.get("niuanse_strength") or 0.0),
        spectacle=g.get("spectacle") or "balanced",
        era=g.get("era") or "auto",
        uniq=bool(g.get("uniq")),
        uniq_strength=float(g.get("uniq_strength") or 0.6),
        uniq_drops=bool(g.get("uniq_drops")),
        health=g.get("health"),
        structure_affinity=bool(g.get("structure_affinity")),
        affinity_passes=int(g.get("affinity_passes") or 2),
        arp=g.get("arp") if isinstance(g.get("arp"), dict) else None,
        replace_on=bool(g.get("replace_on")),
        replace_rules=g.get("replace_rules"),
        replace_policy=g.get("replace_policy"),
    )
    return base, live
