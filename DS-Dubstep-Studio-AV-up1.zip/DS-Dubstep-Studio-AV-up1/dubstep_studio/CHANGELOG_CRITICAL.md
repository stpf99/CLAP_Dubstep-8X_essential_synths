# Krytyczne poprawki (testy)

## gui._preview_extra_or_timbre
- `render_stems` zwraca `dict[name → np.ndarray]`. Podsłuch extras/timbre miksuje stemy, zapisuje WAV i gra z pliku.

## Ujemne klucze MIDI
- Clamp 0..127 na końcu `generator.generate()` oraz w `core.write_midi`.

## arp_engine.structural_inject
- `hash(tr["name"]) % 16` → `zlib.crc32(...encode()) % 16` (stabilne przy PYTHONHASHSEED).

## live.plan_next
- `randint` przy 1 extra: `min(len(ex), max(1, len(ex)//2))` zamiast `max(2, …)` (brak ValueError: empty range).

## director.apply_roles
- Filtruje ścieżki z `lock_notes` (bass/lead/perc).
- `_retune` respektuje `lock_sound`.

## live._gen_extras_from_base
- Siła niuanse/uniq: `max(base, bundle)` — bundle nie obniża wartości z Generatora.
- `autolevels` domyślnie `False` gdy brak klucza (jak GUI/config).

## eco._next_no
- Licznik `.counter` pod `fcntl.flock` (LOCK_EX) + fsync.

## core.cleanup_stale_work
- Glob zawężony do `dsr[0-9]*_*` (nie usuwa dsrender-build / dsr_cache_backup).

## Cache stemów GUI
- Po `render_stems` cache przycinany do aktualnych kluczy MD5 ścieżek.
