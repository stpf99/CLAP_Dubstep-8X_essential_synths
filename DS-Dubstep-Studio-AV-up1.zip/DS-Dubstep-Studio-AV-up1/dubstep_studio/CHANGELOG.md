# Poprawki — rundy 1 + 2

## Runda 1 (błędy potwierdzone testem)
- gui preview extras/timbre: miks stemów → WAV
- clamp MIDI 0..127 (generate + write_midi)
- arp_engine: zlib.crc32 zamiast hash()
- live.plan_next: brak empty range przy 1 extra
- director.apply_roles: lock_notes / lock_sound
- live._gen_extras_from_base: max() siły, autolevels default False
- eco._next_no: flock
- cleanup_stale_work: glob dsr[0-9]*_*
- render_stems: eviction cache

## Runda 2 (niezgodne z założeniami + uporządkowanie)
- **Presety**: collect_preset / apply_preset / to_engine przenoszą smart_instruments, director, niuanse, uniq, era, spectacle, health, arp, structure_affinity, replace_*
- **SIGHUP reload**: zachowuje --preset; apply_env(force=True) dla player/audio_device/workers
- **config**: atomowy zapis + chmod 600 przed replace; key Bb/Db… aliasy; czytelny błąd przy zduplikowanym kluczu
- **Icecast log**: maskowanie hasła także URL-encoded
- **Meta**: błędy dsrender --dump w komunikacie „Brak wtyczek CLAP”
- **generator**: available_types() poprawnie importowane (NameError); role_swap nie gubi flagi z reżysera
- **render_stems**: timeout 120s na dsrender
- **README**: 32 wtyczki (było 29)

## Świadomie odłożone
- Pełny GenOptions dataclass (listy pól ujednolicone w presetach; pełny refactor generate 286 linii osobno)
- Usunięcie martwego scenario_* w generator.py (~235 linii; nie wołane, zostawione)
- 12× bare `except Exception` w live.py — tylko krytyczne ścieżki poprawione (timeout render, maskowanie); reszta do osobnego przeglądu
- Hasło Icecast nadal w argv ffmpeg (ograniczenie ffmpeg; ps widzi URL) — logi już maskują obie formy
- Prebuilt build/*.clap w paczce źródłowej — nie ruszane; komunikat Meta wskazuje powód (glibc itd.)
