"""host.py — HOST renderu wideo (odpowiednik hosta CLAP dla audio): składa warstwy z projvideo w klatki, eksportuje MP4 z dźwiękiem (ffmpeg),
nadaje RTMP (z ponawianiem połączenia) i zasila nadawanie na żywo (AvSink: audio z silnika Live + klatki zsynchronizowane z zegarem audio)."""
from __future__ import annotations

import copy
import math
import os
import queue
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

import numpy as np

from .. import core, rcore
from . import plugins as _plugins  # noqa: F401
from .canvas import Canvas
from .plugins import PALETTES, VREG
from .signals import Signals, audio_features

SR = core.SR
KIND_ORDER = ("room", "performer", "brush", "camera", "fx", "overlay")


class _Ctx:
    pass


# (warstwa szablonu, parametr, kanał planu) — to samo mapowanie co plan.apply_to_projvideo
PLAN_PARAMS = (
    ("beams", "intensity", "beams"), ("parts", "amount", "particles"), ("cam", "amount", "cam_amount"),
    ("bloom", "amount", "bloom"), ("glitch", "amount", "glitch"), ("strobe", "amount", "strobe"),
    ("scan", "amount", "scanlines"), ("mirror", "mix", "mirror"), ("robots", "glow", "robots_glow"),
)


class VideoJob:
    """Zadanie renderu klatek: projekt audio + projvideo (+ cechy audio) → klatki uint8 (h, w, 3)."""

    def __init__(self, proj, pv, feat=None, n=None):
        self.proj, self.pv = proj, pv
        self.w, self.h = int(pv["size"][0]) // 2 * 2, int(pv["size"][1]) // 2 * 2
        self.fps = int(pv["fps"])
        self.scale = 2 if float(pv.get("render_scale", 1.0)) <= 0.5 else 1          # render_scale 0.5: liczone w połowie rozdzielczości i powiększane (4× szybciej)
        self.rw, self.rh = self.w // self.scale, self.h // self.scale
        self.sig = Signals(proj, self.fps, feat, n)
        self.n = self.sig.n
        self.canvas = Canvas(self.rw, self.rh)
        self._buf = np.zeros((self.rh, self.rw, 3), np.float32)
        self.layers = []                                      # (layer_dict, plugin)
        for L in pv["layers"]:
            if L["plugin"] not in VREG:
                continue
            pl = VREG.make(L["plugin"], **(L.get("params") or {}))
            pl.layer = L
            self.layers.append((L, pl))
        self.base = {L["id"]: dict(pl.p) for L, pl in self.layers}
        self.specs = {L["id"]: pl.specs() for L, pl in self.layers}
        self.links = [l for l in pv.get("links", []) if l["dst"] in self.base]
        self.cues = {c["section"]: c for c in pv.get("cues", [])}
        self.ctx = _Ctx()
        c = self.ctx
        c.canvas, c.w, c.h, c.fps, c.sig = self.canvas, self.rw, self.rh, self.fps, self.sig
        c.pal = PALETTES.get(pv.get("palette"), PALETTES["kraftwerk"]); c.meta = pv.get("meta", {}); c.state = {}
        self.by_kind = {k: [(L, pl) for L, pl in self.layers if pl.kind == k] for k in KIND_ORDER}
        self.perf_x = [pl.p["x"] for L, pl in self.by_kind["performer"]]
        self.sec_start = [s["start"] * 4 * 60.0 / float(proj["bpm"]) for s in proj["sections"]]
        # warstwa pseudo-AI: kanały taktowe → klatkowe (cechy audio wchodzą do dekodera, gdy są)
        self._ft = None
        try:
            from . import plan as _VP, plan_grid as _PG
            plan = proj.get("video_plan") if isinstance(proj.get("video_plan"), dict) else None
            if plan is None and pv.get("cues"):
                plan = _VP.plan_project(proj)
            if plan and plan.get("grid"):
                if feat is not None:
                    _PG.attach_audio(plan, proj, feat)
                self._ft = _PG.FrameTrack(plan, float(proj["bpm"]), self.fps, self.n)
        except Exception:
            self._ft = None

    # ---- parametry w klatce: baza szablonu → cue sekcji (płynnie) → linki sygnał→parametr
    def params_at(self, i):
        sg = self.sig; k = int(sg.sec[i]); t = float(sg.t[i])
        base = {lid: dict(p) for lid, p in self.base.items()}
        cur = (self.cues.get(k) or {}).get("mods", {}); prev = (self.cues.get(k - 1) or {}).get("mods", cur) if k > 0 else cur
        w = rcore.smooth_step((t - self.sec_start[k]) / 0.9) if k < len(self.sec_start) else 1.0
        for lid, mods in cur.items():
            if lid not in base:
                continue
            for pn, v in mods.items():
                sp = self.specs[lid].get(pn)
                if sp is None or sp.kind in ("choice", "bool"):
                    continue
                pv_ = (prev.get(lid) or {}).get(pn, base[lid].get(pn, v))
                base[lid][pn] = sp.clamp(rcore.lerp(float(pv_), float(v), w))
        ft = self._ft
        if ft is not None and cur:
            # tylko parametry, które plan już steruje przez cue sekcji — teraz z rozdzielczością taktu zamiast skoku na sekcję
            ch = None
            for lid, pn, cn in PLAN_PARAMS:
                if lid in cur and pn in cur[lid] and lid in base:
                    sp = self.specs[lid].get(pn)
                    if sp is None or sp.kind in ("choice", "bool"):
                        continue
                    if ch is None:
                        ch = ft.at(i)
                    v = ch[cn] if cn != "robots_glow" else 0.3 + 0.5 * ch["fx"] / 3.0
                    base[lid][pn] = sp.clamp(float(v))
        return rcore.apply_links(self.links, lambda name: self.sig.value(name, i), base, lambda lid: self.specs[lid])

    def frame_f(self, i):
        """Klatka jako float32 (h, w, 3) 0..1."""
        i = min(max(0, int(i)), self.n - 1)
        st = self.params_at(i)
        for L, pl in self.layers:
            pl.p = st[L["id"]]
        c, ctx = self.canvas, self.ctx
        rooms = self.by_kind["room"]
        if not (rooms and getattr(rooms[0][1], "fills_canvas", False)):
            self._buf[:] = 0                                            # zerowanie tylko, gdy pierwsza warstwa nie zamalowuje całej klatki (inaczej to 11 MB zapisu na darmo)
        c.img = self._buf
        ctx.i = i; ctx.rng = np.random.default_rng((i * 2654435761) % (2 ** 32)); ctx.extras = {"perf_x": self.perf_x}
        for L, pl in self.by_kind["room"]:
            pl.render(ctx, i)
        for L, pl in self.by_kind["performer"]:
            pl.render(ctx, i)
        for L, pl in self.by_kind.get("brush", []):
            pl.render(ctx, i)
        img = c.img
        for L, pl in self.by_kind["camera"]:
            img = pl.apply(ctx, img, i)
        fade = None
        for L, pl in self.by_kind["fx"]:
            if pl.id == "fx_fade":
                fade = pl; continue
            img = pl.apply(ctx, img, i)
        c.img = img if img.flags.writeable else img.copy()
        for L, pl in self.by_kind["overlay"]:
            pl.render(ctx, i)
        img = c.img
        if fade is not None:
            img = fade.apply(ctx, img, i)
        return img

    def frame(self, i):
        f = self.frame_f(i)
        tmp = self.__dict__.get("_u8tmp")
        if tmp is None or tmp.shape != f.shape:
            tmp = self._u8tmp = np.empty(f.shape, np.float32)           # bufor roboczy używany ponownie (bez 3 nowych 11 MB-owych tablic na klatkę)
        np.clip(f, 0, 1, out=tmp); np.multiply(tmp, 255.0, out=tmp); np.add(tmp, 0.5, out=tmp)
        a = tmp.astype(np.uint8)
        if self.scale == 2:
            a = np.repeat(np.repeat(a, 2, 0), 2, 1)
        return a


# ------------------------------------------------------------------ ffmpeg
def ffmpeg_bin():
    return shutil.which("ffmpeg")


def encoder_args(cfg, stream=False):
    """Argumenty kodera wideo z konfiguracji (v_codec, v_preset, crf albo v_bitrate [kb/s], gop_sec, fps)."""
    codec = (cfg.get("v_codec") or "libx264").strip()
    fps = int(cfg.get("fps") or 25); gop = max(1, int(float(cfg.get("gop_sec", 2)) * fps))
    br = int(cfg.get("v_bitrate") or 0)
    a = ["-c:v", codec]
    if codec in ("libx264", "libx265"):
        lite = bool(cfg.get("lite")) and stream
        a += ["-preset", (cfg.get("v_preset") or "ultrafast") if lite else (cfg.get("v_preset") or "veryfast"), "-pix_fmt", "yuv420p"]
        if stream or not cfg.get("crf"):
            br = br or 2500
            a += ["-b:v", f"{br}k", "-maxrate", f"{int(br * 1.2)}k", "-bufsize", f"{br * 2}k"]
        else:
            a += ["-crf", str(int(cfg["crf"]))]
        if stream:
            a += ["-tune", "zerolatency"]
        if lite:                                              # tryb lekki: bez B-klatek, 1 ref, stałe GOP (YouTube), ograniczona liczba wątków
            a += ["-bf", "0", "-refs", "1", "-sc_threshold", "0"]
            if int(cfg.get("threads") or 0) > 0:
                a += ["-threads", str(int(cfg["threads"]))]
    else:                                                      # sprzętowe (h264_v4l2m2m, nvenc, qsv…): bitrate + yuv420p
        a += ["-pix_fmt", "yuv420p", "-b:v", f"{br or 2500}k"]
    return a + ["-g", str(gop), "-keyint_min", str(gop)]


def _fit_encoder_size(w, h):
    return (w // 2 * 2, h // 2 * 2)


def export_mp4(proj, pv, out, mix=None, audio_wav=None, enc=None, progress=None, feat=None):
    """Renderuje MP4 z dźwiękiem (jedno przejście ffmpeg: klatki rawvideo z pipe + audio WAV). -> ścieżka."""
    ff = ffmpeg_bin()
    if not ff:
        raise RuntimeError("Brak ffmpeg w PATH — zainstaluj ffmpeg do renderu wideo.")
    enc = dict(enc or {}); fps = int(pv["fps"]); w, h = _fit_encoder_size(*pv["size"]); pv = copy.deepcopy(pv); pv["size"] = [w, h]
    tmp_wav = None
    if audio_wav is None:
        if mix is None:
            mix = core.render_mix(proj, progress=None)
        fd, tmp_wav = tempfile.mkstemp(suffix=".wav"); os.close(fd); core.write_wav(tmp_wav, mix); audio_wav = tmp_wav
    if feat is None and mix is not None:
        feat = audio_features(mix, fps)
    n_audio = int(len(mix) / SR * fps) + 1 if mix is not None else None
    job = VideoJob(proj, pv, feat, n=max(n_audio or 0, int(math.ceil(proj["bars"] * 4 * 60.0 / float(proj["bpm"]) * fps)) + 1))
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [ff, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps), "-i", "-", "-i", str(audio_wav),
           "-map", "0:v:0", "-map", "1:a:0"] + encoder_args(dict(enc, fps=fps)) + ["-c:a", "aac", "-b:a", f"{int(enc.get('a_bitrate', 192))}k", "-shortest", "-movflags", "+faststart", str(out)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
    # render i zapis do ffmpeg w osobnych wątkach (kolejka 6 klatek): kodowanie x264 działa równolegle z liczeniem następnej klatki,
    # a klatka idzie do pipe jako widok pamięci — bez kopii .tobytes() (2,7 MB na klatkę)
    q = queue.Queue(maxsize=6); dead = threading.Event()

    def _writer():
        try:
            while True:
                a = q.get()
                if a is None:
                    return
                proc.stdin.write(memoryview(a).cast("B"))
        except (BrokenPipeError, OSError, ValueError):
            dead.set()
            while True:                                                 # ffmpeg padł: opróżniaj kolejkę, żeby render nie zawisł na put()
                try:
                    if q.get(timeout=0.2) is None:
                        return
                except queue.Empty:
                    if not th.is_alive():
                        return

    th = threading.Thread(target=_writer, daemon=True); th.start()
    try:
        for i in range(job.n):
            if dead.is_set():
                break
            a = np.ascontiguousarray(job.frame(i))
            while not dead.is_set():
                try:
                    q.put(a, timeout=0.2); break
                except queue.Full:
                    pass
            if progress and i % max(1, job.n // 50) == 0:
                progress(i / job.n)
    finally:
        while True:
            try:
                q.put(None, timeout=0.2); break
            except queue.Full:
                if dead.is_set() or not th.is_alive():
                    break
        th.join(timeout=30)
        try:
            proc.stdin.close()
        except OSError:
            pass
        err = proc.stderr.read().decode("utf-8", "replace") if proc.stderr else ""
        proc.wait()
        if tmp_wav:
            Path(tmp_wav).unlink(missing_ok=True)
    if proc.returncode != 0 or not out.exists() or out.stat().st_size < 1000:
        raise RuntimeError(f"ffmpeg: {err[-400:]}")
    if progress:
        progress(1.0)
    return str(out)


def frame_png(proj, pv, t_sec, out, feat=None):
    """Pojedyncza klatka do PNG (przez ffmpeg — bez PIL)."""
    job = VideoJob(proj, pv, feat)
    fr = job.frame(int(t_sec * job.fps))
    ff = ffmpeg_bin()
    if not ff:
        raise RuntimeError("Brak ffmpeg.")
    p = subprocess.run([ff, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{job.w}x{job.h}", "-i", "-", "-frames:v", "1", str(out)],
                       input=fr.tobytes(), capture_output=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.decode("utf-8", "replace")[-300:])
    return str(out)


# ------------------------------------------------------------------ RTMP
def rtmp_target(cfg):
    url = (cfg.get("url") or "").strip(); key = (cfg.get("key") or "").strip()
    return url.rstrip("/") + "/" + key if key else url


def mask_url(u, key=""):
    return u.replace(key, "***") if key else u


def rtmp_probe(url, timeout=1.0):
    """Szybki test TCP przed startem ffmpeg → (ok, komunikat).
    RTMP to model klient→serwer: ffmpeg niczego „nie otwiera” pod adresem, tylko ŁĄCZY SIĘ z serwerem, który musi już nasłuchiwać
    (nginx-rtmp, MediaMTX, SRS…). Bez niego dostajemy „Connection refused”."""
    u = urlparse(url if "://" in url else "rtmp://" + url)
    host = u.hostname or "localhost"; port = u.port or (443 if u.scheme == "rtmps" else 1935)
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True, ""
    except ConnectionRefusedError:
        return False, (f"brak serwera RTMP na {host}:{port} (połączenie odrzucone) — nic tam nie nasłuchuje. "
                       f"Uruchom serwer (nginx-rtmp / MediaMTX) albo włącz podgląd lokalny, który serwera nie potrzebuje")
    except OSError as e:
        return False, f"serwer RTMP {host}:{port} niedostępny ({e.__class__.__name__}: {e})"


def rtmp_explain(url, key, err):
    """Tłumaczy końcówkę stderr ffmpeg na czytelny powód (+ podpowiedź o URL bez nazwy strumienia)."""
    e = err or ""
    last = e.strip().splitlines()[-1] if e.strip() else ""
    u = urlparse(url if "://" in url else "rtmp://" + url)
    host = u.hostname or "localhost"; port = u.port or (443 if u.scheme == "rtmps" else 1935)
    low = e.lower()
    if "connection refused" in low:
        msg = (f"brak serwera RTMP na {host}:{port} (połączenie odrzucone) — nic tam nie nasłuchuje. "
               f"RTMP to klient→serwer: uruchom serwer (nginx-rtmp / MediaMTX) albo użyj podglądu lokalnego, który serwera nie potrzebuje")
    elif "name or service not known" in low or "name resolution" in low:
        msg = f"nie znaleziono hosta „{host}”"
    elif "timed out" in low or "timeout" in low:
        msg = f"serwer {host}:{port} nie odpowiada (przekroczono czas)"
    elif "network is unreachable" in low or "no route to host" in low:
        msg = f"brak trasy do {host}:{port}"
    else:
        msg = last
    hint = rtmp_url_hint(url, key)
    return msg + (f" · {hint}" if hint and msg else (hint or ""))


def rtmp_url_hint(url, key=""):
    """Podpowiedź, gdy URL nie ma nazwy strumienia (rtmp://host/aplikacja/strumień) i nie podano klucza."""
    u = urlparse(url if "://" in url else "rtmp://" + url)
    segs = [s for s in (u.path or "").split("/") if s]
    if not (key or "").strip() and len(segs) < 2:
        return f"URL „{url}” nie ma nazwy strumienia — użyj rtmp://host/{segs[0] if segs else 'aplikacja'}/nazwa albo wpisz klucz"
    return ""


class NullStreamer:
    """Streamer bez sieci i bez ffmpeg (API jak RtmpStreamer) — gdy chcemy tylko podgląd lokalny."""

    def __init__(self, *a, **k):
        self.status = "tylko podgląd lokalny"; self.frames = 0; self.dropped_v = 0; self.dropped_a = 0; self.last_error = ""; self.err_tail = ""
        self.stopped = False

    def start(self):
        self.stopped = False; return True

    def stop(self):
        self.stopped = True

    def alive(self):
        return True

    def maintain(self):
        pass

    def write_audio(self, b):
        return True

    def write_frame(self, b):
        self.frames += 1; return True


class LocalPreview:
    """Podgląd lokalny: ffplay czyta surowe klatki rgb24 ze stdin — bez serwera RTMP i bez sieci.
    Zapis w osobnym wątku, kolejka 3 klatek (przy wolnym oknie gubi najstarsze — render ani audio nie czekają)."""

    def __init__(self, size, fps, title="DS Studio — podgląd", display=None, log=None):
        self.size = (int(size[0]) // 2 * 2, int(size[1]) // 2 * 2); self.fps = int(fps); self.title = title; self.display = display
        self.log = log or (lambda m: None); self.proc = None; self.error = ""; self.frames = 0; self.dropped = 0
        self._q = queue.Queue(maxsize=3); self._gen = 0

    @staticmethod
    def available():
        return bool(shutil.which("ffplay"))

    def start(self):
        ff = shutil.which("ffplay")
        if not ff:
            self.error = "brak ffplay w PATH (pakiet ffmpeg) — użyj podglądu w oknie programu"; return False
        w, h = self.size
        cmd = [ff, "-loglevel", "error", "-fflags", "nobuffer", "-flags", "low_delay", "-framedrop", "-window_title", self.title,
               "-f", "rawvideo", "-pixel_format", "rgb24", "-video_size", f"{w}x{h}", "-framerate", str(self.fps)]
        if self.display:
            cmd += ["-x", str(int(self.display[0])), "-y", str(int(self.display[1]))]
        cmd += ["-i", "pipe:0"]
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as e:
            self.error = f"nie można uruchomić ffplay: {e}"; return False
        self._gen += 1; self.error = ""
        threading.Thread(target=self._writer, args=(self._gen, self.proc), daemon=True).start()
        threading.Thread(target=self._read_err, args=(self.proc,), daemon=True).start()
        return True

    def _read_err(self, proc):
        try:
            for ln in proc.stderr:
                s = ln.decode("utf-8", "replace").strip()
                if s:
                    self.error = (self.error + "\n" + s)[-300:]
        except Exception:
            pass

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def _writer(self, gen, proc):
        while gen == self._gen:
            try:
                b = self._q.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                proc.stdin.write(b); proc.stdin.flush(); self.frames += 1
            except (OSError, ValueError):
                return

    def write_frame(self, b):
        if not self.alive():
            return False
        try:
            self._q.put_nowait(b)
        except queue.Full:
            self.dropped += 1
            try:
                self._q.get_nowait(); self._q.put_nowait(b)
            except (queue.Empty, queue.Full):
                pass
        return True

    def stop(self):
        self._gen += 1
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.stdin.close()
            except OSError:
                pass
            try:
                p.terminate(); p.wait(timeout=2)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass


class RtmpStreamer:
    """Jedno trwałe połączenie ffmpeg → RTMP: wideo (rawvideo, stdin) + audio (s16le 48 kHz, pipe fd). Ponawia połączenie po awarii (reconnect/reconnect_sec/retries),
    nie blokuje wątku nadającego, gdy serwer jest niedostępny (w tym czasie dane są porzucane)."""

    def __init__(self, cfg, size, fps, log=None):
        self.cfg = dict(cfg); self.size = _fit_encoder_size(*size); self.fps = int(fps); self.log = log or (lambda m: None)
        self.proc = None; self.aw = None; self.status = "rozłączony"; self.retries = 0; self.retry_at = 0.0; self.err_tail = ""; self.frames = 0; self.up_since = None; self.last_error = ""
        self._lock = threading.Lock(); self.stopped = False; self.started_at = None
        self._aq = queue.Queue(maxsize=400); self._vq = queue.Queue(maxsize=10); self._gen = 0; self.dropped_a = 0; self.dropped_v = 0

    def _cmd(self, ra):
        c = self.cfg; ff = ffmpeg_bin(); w, h = self.size
        cmd = [ff, "-loglevel", "warning", "-fflags", "+genpts", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(self.fps), "-thread_queue_size", "512", "-i", "pipe:0",
               "-f", "s16le", "-ar", str(SR), "-ac", "2", "-thread_queue_size", "1024", "-i", f"pipe:{ra}"]
        ow, oh = int(c.get("out_w") or 0), int(c.get("out_h") or 0)
        if ow and oh and (ow // 2 * 2, oh // 2 * 2) != (w, h):          # render w małym rozmiarze, skalowanie robi ffmpeg (tanio)
            cmd += ["-vf", f"scale={ow // 2 * 2}:{oh // 2 * 2}:flags=bilinear"]
        cmd += encoder_args(dict(c, fps=self.fps), stream=True) + ["-c:a", "aac", "-b:a", f"{int(c.get('a_bitrate', 128))}k", "-ar", str(SR)]
        cmd += ["-f", "flv", "-flvflags", "no_duration_filesize"]
        if int(c.get("timeout_sec", 10)) > 0:
            cmd += ["-rw_timeout", str(int(c.get("timeout_sec", 10)) * 1000000)]
        if c.get("live", True):
            cmd += ["-rtmp_live", "live"]
        if int(c.get("buffer_ms", 0)) > 0:
            cmd += ["-rtmp_buffer", str(int(c["buffer_ms"]))]
        return cmd + [rtmp_target(c)]

    def start(self):
        self.stopped = False; self.started_at = time.time()
        return self._spawn()

    def _spawn(self):
        if not ffmpeg_bin():
            self.status = "brak ffmpeg"; return False
        self._close()
        ra, wa = os.pipe()
        try:
            cmd = self._cmd(ra)
            nv = int(self.cfg.get("nice") or 0)
            if nv > 0 and shutil.which("nice"):                    # koder z niższym priorytetem: audio i generator mają pierwszeństwo
                cmd = ["nice", "-n", str(nv)] + cmd
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, pass_fds=(ra,))
        except OSError as e:
            os.close(ra); os.close(wa); self.status = f"błąd uruchomienia: {e}"; return False
        os.close(ra); self.aw = wa; self._gen += 1
        for q in (self._aq, self._vq):                       # kolejki zapisu: audio i wideo nie blokują się nawzajem ani wątku nadającego (ffmpeg sonduje wejścia po kolei)
            while not q.empty():
                try:
                    q.get_nowait()
                except queue.Empty:
                    break
        threading.Thread(target=self._writer, args=(self._gen, self._aq, "a"), daemon=True).start()
        threading.Thread(target=self._writer, args=(self._gen, self._vq, "v"), daemon=True).start()
        threading.Thread(target=self._read_err, args=(self.proc,), daemon=True).start()
        self.status = "łączenie…"; self.up_since = time.time()
        return True

    def _read_err(self, proc):
        try:
            for ln in proc.stderr:
                s = ln.decode("utf-8", "replace").strip()
                if s:
                    self.err_tail = (self.err_tail + "\n" + s)[-600:]
        except Exception:
            pass

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    @staticmethod
    def _close_stdin(p):
        try:
            if p is not None and p.stdin:
                p.stdin.close()
        except (OSError, ValueError):
            pass

    def _close(self):
        p = self.proc
        if p is not None:
            # close() opróżnia bufor do ffmpeg — gdy ten jeszcze się łączy i nie czyta stdin, blokuje na zawsze (zawieszał stop() Live przy niedostępnym serwerze).
            t = threading.Thread(target=self._close_stdin, args=(p,), daemon=True); t.start(); t.join(1.0)
        if self.aw is not None:
            try:
                os.close(self.aw)
            except OSError:
                pass
            self.aw = None
        if self.proc is not None:
            try:
                self.proc.terminate(); self.proc.wait(timeout=3)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            self.proc = None

    def maintain(self):
        """Wywoływać okresowo: wykrywa zerwanie i ponawia połączenie wg [rtmp] reconnect*."""
        if self.stopped or self.alive():
            if self.alive() and self.up_since and time.time() - self.up_since > 3:
                self.status = "nadaje"; self.last_error = ""
            return
        if self.status not in ("rozłączony", "czekam na ponowienie"):
            self.last_error = rtmp_explain(self.cfg.get("url") or "", self.cfg.get("key") or "", self.err_tail)
            self.log(f"RTMP: połączenie nieudane/zerwane — {self.last_error}")
        c = self.cfg
        if not c.get("reconnect", True):
            self.status = "rozłączony"; return
        mx = int(c.get("retries", 0))
        if mx and self.retries >= mx:
            self.status = "porzucono (limit prób)"; return
        now = time.time()
        if self.retry_at == 0.0 or self.status != "czekam na ponowienie":
            self.retry_at = now + int(c.get("reconnect_sec", 5)); self.status = "czekam na ponowienie"; return
        if now >= self.retry_at:
            self.retries += 1; self.retry_at = 0.0; self.log(f"RTMP: ponawiam połączenie (próba {self.retries})")
            self._spawn()

    def _writer(self, gen, q, kind):
        while gen == self._gen and not self.stopped:
            try:
                b = q.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                if gen != self._gen or not self.alive():
                    continue
                if kind == "a":
                    mv = memoryview(b)
                    while mv and gen == self._gen:
                        n = os.write(self.aw, mv); mv = mv[n:]
                else:
                    self.proc.stdin.write(b); self.proc.stdin.flush(); self.frames += 1
            except (OSError, ValueError, TypeError):
                pass

    @staticmethod
    def _put(q, b):
        while True:
            try:
                q.put_nowait(b); return True
            except queue.Full:
                try:
                    q.get_nowait()                            # zachowaj czas rzeczywisty: porzuć najstarsze
                except queue.Empty:
                    pass

    def write_audio(self, b):
        if not self.alive():
            return False
        if self._aq.full():
            self.dropped_a += 1
        self._put(self._aq, bytes(b)); return True

    def write_frame(self, b):
        if not self.alive():
            return False
        if self._vq.full():
            self.dropped_v += 1
        self._put(self._vq, b); return True

    def stop(self):
        self.stopped = True; self._gen += 1; self._close(); self.status = "rozłączony"


def stream_project(proj, pv, rtmp_cfg, enc=None, mix=None, progress=None, stop=lambda: False, log=print):
    """Nadaje gotowy projekt (audio + wideo) na RTMP w czasie rzeczywistym. Klatki liczone tak szybko, jak się da; gdy render nie nadąża, powtarzana jest ostatnia klatka."""
    if mix is None:
        mix = core.render_mix(proj, progress=None)
    fps = int(pv["fps"]); feat = audio_features(mix, fps)
    job = VideoJob(proj, pv, feat, n=int(len(mix) / SR * fps) + 1)
    local_only = bool(rtmp_cfg.get("local_only"))
    st = NullStreamer() if local_only else RtmpStreamer(dict(rtmp_cfg, **(enc or {})), (job.w, job.h), fps, log)
    st.start()
    pv_win = None
    if local_only or rtmp_cfg.get("preview"):                  # podgląd lokalny: ffplay z tych samych klatek, bez serwera RTMP
        pv_win = LocalPreview((job.w, job.h), fps, display=rtmp_cfg.get("preview_size"), log=log)
        if not pv_win.start():
            log("Podgląd: " + pv_win.error); pv_win = None
            if local_only:
                return "podgląd niedostępny: " + (LocalPreview.available() and "błąd ffplay" or "brak ffplay")
    pcm = (np.clip(mix, -1, 1) * 32767).astype("<i2").tobytes()
    chunk = 2048 * 4; t0 = time.time(); sent_v = 0; sent_a = 0; last = None
    try:
        while sent_a < len(pcm) and not stop():
            st.maintain()
            target_a = min(len(pcm), int(((time.time() - t0) + 0.35) * SR) * 4)
            while sent_a < target_a:
                n = min(chunk, len(pcm) - sent_a); st.write_audio(pcm[sent_a: sent_a + n]); sent_a += n
            due = int((time.time() - t0) * fps) + 1
            while sent_v < due:
                late = (time.time() - t0) - sent_v / fps
                if last is not None and late > 0.25:
                    st.write_frame(last)                 # nie nadążamy — powtórz klatkę
                else:
                    last = job.frame(min(sent_v, job.n - 1)).tobytes(); st.write_frame(last)
                if pv_win is not None:
                    pv_win.write_frame(last)
                sent_v += 1
            if progress:
                progress(sent_a / max(1, len(pcm)))
            time.sleep(0.01)
        time.sleep(1.0)
    finally:
        st.stop()
        if pv_win is not None:
            pv_win.stop()
    return st.status + (f" ({st.last_error})" if getattr(st, "last_error", "") and st.status != "nadaje" else "")


# ------------------------------------------------------------------ nadawanie na żywo (silnik Live)
class AvSink:
    """Odbiera PCM z Output (audio silnika Live) i begin(proj, feat) przy starcie każdej aranżacji; wysyła do RTMP dźwięk i klatki zsynchronizowane z zegarem audio.
    Wątek własny: render wideo nigdy nie opóźnia dźwięku (gdy nie nadąża, powtarza klatkę)."""

    def __init__(self, av_cfg, rtmp_cfg, log=None):
        self.av, self.rt = dict(av_cfg), dict(rtmp_cfg)
        self.log = log or (lambda m: None)
        w = int(self.rt.get("width") or self.av.get("width") or 854); h = int(self.rt.get("height") or self.av.get("height") or 480)
        self.fps = int(self.rt.get("fps") or self.av.get("fps") or 25); self.size = (w, h)
        # RTMP wyłączony (albo brak URL) → sam render szablonu + podgląd lokalny, bez enkodera i sieci (tak samo jak LiveAV)
        self.net = bool((self.rt.get("url") or "").strip()) and bool(self.rt.get("enabled", True))
        self.st = RtmpStreamer(self.rt, self.size, self.fps, self.log) if self.net else NullStreamer()
        self.fsize = tuple(getattr(self.st, "size", None) or (w // 2 * 2, h // 2 * 2))       # rozmiar klatki: ten, który zna streamer
        self.preview_mode = str(self.av.get("preview") or "off").strip().lower()             # off | gui (okno programu) | window (ffplay)
        self.player = None; self.latest = None; self.preview_error = ""
        self.q = queue.Queue(maxsize=400); self.job = None; self.t_arr0 = 0.0; self.audio_clock = 0.0; self.sent_v = 0; self.last = None; self.wall0 = None
        self.th = None; self.run = False; self.idle = Canvas(*self.fsize); self.late_frames = 0

    def _preview_state(self):
        if self.preview_mode == "window":
            if self.player is None:
                return self.preview_error or "okno ffplay nie wystartowało"
            return "okno ffplay" if self.player.alive() else "okno zamknięte"
        return "w oknie programu" if self.preview_mode == "gui" else "wyłączony"

    @property
    def status(self):
        extra = f" ({self.st.frames} kl., powtórzone {self.late_frames})" if self.st.frames else ""
        if not self.net:
            return f"Podgląd lokalny: {self._preview_state()}{extra}"
        return f"RTMP: {self.st.status}{extra}"

    def latest_frame(self):
        """(bajty rgb24, szerokość, wysokość, nr klatki) ostatniej klatki albo None — podgląd w GUI (ten sam kontrakt co LiveAV.latest_frame)."""
        lf = self.latest
        return None if lf is None else (lf[0], self.fsize[0], self.fsize[1], lf[1])

    def _emit(self, fr):
        self.latest = (fr, self.sent_v)
        if self.player is not None:
            self.player.write_frame(fr)

    def start(self):
        self.run = True
        self.st.start()
        if self.preview_mode == "window":
            disp = self.fsize if self.fsize[0] <= 960 else (960, int(960 * self.fsize[1] / self.fsize[0]) // 2 * 2)
            p = LocalPreview(self.fsize, self.fps, display=disp, log=self.log)
            if p.start():
                self.player = p
            else:
                self.preview_error = p.error; self.log("Podgląd: " + p.error)
        self.th = threading.Thread(target=self._loop, daemon=True); self.th.start()

    def stop(self):
        self.run = False
        if self.th:
            self.th.join(timeout=3)
        self.st.stop()
        if self.player is not None:
            self.player.stop(); self.player = None

    def audio(self, b):
        try:
            self.q.put_nowait(("pcm", b))
        except queue.Full:
            try:
                self.q.get_nowait()                         # zachowaj czas rzeczywisty: porzuć najstarszy kawałek
            except queue.Empty:
                pass

    def hint_busy(self, flag):
        pass

    def begin(self, proj, feat=None, pv=None, title=None):
        try:
            self.q.put_nowait(("begin", proj, feat, pv))
        except queue.Full:
            pass

    def _idle_frame(self):
        c = self.idle; w, h = c.w, c.h
        c.gradient_v((0.02, 0.02, 0.05), (0.1, 0.02, 0.05)); t = time.time()
        c.text(w / 2, h * 0.42, "DS LIVE", max(2, h // 80), (0.9, 0.9, 0.95), 0.9, "center")
        c.text(w / 2, h * 0.55, "STAND BY" if int(t * 2) % 2 == 0 else "", max(1, h // 160), (0.9, 0.1, 0.12), 0.9, "center")
        return c.to_uint8().tobytes()

    def _build_job(self, proj, feat, pv):
        from . import templates as TP
        pv = copy.deepcopy(pv) if pv else TP.build_projvideo(proj, self.av.get("template", "kraftwerk_robots"), size=self.size, fps=self.fps, palette=self.av.get("palette") or None)
        pv["size"] = list(self.fsize); pv["fps"] = self.fps
        return VideoJob(proj, pv, feat)

    def _loop(self):
        while self.run:
            try:
                it = self.q.get(timeout=0.1)
            except queue.Empty:
                self.st.maintain(); continue
            try:
                if it[0] == "begin":
                    self.job = self._build_job(it[1], it[2], it[3]); self.t_arr0 = self.audio_clock
                    continue
                b = it[1]
                self.st.maintain()
                self.st.write_audio(b)
                if self.wall0 is None:
                    self.wall0 = time.time()
                self.audio_clock += len(b) / 4.0 / SR
                while self.sent_v < int(self.audio_clock * self.fps):
                    backlog = self.q.qsize() * len(b) / 4.0 / SR           # ile audio czeka w kolejce = jak bardzo nie nadążamy (niezależnie od przerw w dźwięku)
                    if self.job is None:
                        fr = self._idle_frame()
                    elif self.last is not None and backlog > 0.6:
                        fr = self.last; self.late_frames += 1
                    else:
                        i = int((self.sent_v / self.fps - self.t_arr0) * self.fps)
                        fr = self.job.frame(min(max(0, i), self.job.n - 1)).tobytes()
                    self.last = fr; self.st.write_frame(fr); self._emit(fr); self.sent_v += 1
            except Exception as e:                           # render wideo nie może zatrzymać nadawania audio
                self.log(f"wideo: {e}")
                self.job = None
