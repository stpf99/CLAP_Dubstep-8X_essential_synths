"""plugins.py — wtyczki wideo na rcore.Plugin (parametry jak CLAP: wartości w GUI/presetach/linkach to ułamki 0..1).

Rodzaje (kolejność w hoście: room → performer → brush → camera → fx → overlay):
  room       — pomieszczenie / scena (tło, geometria, światło)
  performer  — wykonawca (robot, wireframe, orb) reagujący na wybrane źródło sygnału
  brush      — pędzel: ślady, cząstki, wiązki, oscyloskop (rysują po scenie, mają pamięć między klatkami)
  camera     — kamera (zoom / pan / dryf / „punch” na kick)
  fx         — postprodukcja (bloom, scanlines, glitch, strobe, mirror, fade)
  overlay    — nakładki (widmo, fala, tytuł)
Wtyczka: render(ctx, i) rysuje na ctx.canvas; kamera i fx: apply(ctx, img, i) -> img."""
from __future__ import annotations

import math

import numpy as np

from ..rcore import Param, Plugin
from .registry import VREG

PALETTES = {
    "kraftwerk": dict(bg0=(0.015, 0.015, 0.02), bg1=(0.11, 0.0, 0.02), a=(0.92, 0.05, 0.09), b=(0.92, 0.92, 0.94), c=(0.1, 0.72, 0.95), hot=(1.0, 0.85, 0.25)),
    "neon": dict(bg0=(0.01, 0.0, 0.04), bg1=(0.08, 0.0, 0.14), a=(1.0, 0.1, 0.65), b=(0.2, 1.0, 0.9), c=(0.55, 0.3, 1.0), hot=(1.0, 0.95, 0.4)),
    "acid": dict(bg0=(0.0, 0.02, 0.0), bg1=(0.0, 0.1, 0.03), a=(0.55, 1.0, 0.05), b=(0.95, 1.0, 0.8), c=(0.0, 0.8, 0.45), hot=(1.0, 0.45, 0.0)),
    "sunset": dict(bg0=(0.04, 0.0, 0.08), bg1=(0.28, 0.04, 0.1), a=(1.0, 0.42, 0.1), b=(1.0, 0.85, 0.6), c=(0.8, 0.2, 0.6), hot=(1.0, 1.0, 0.7)),
    "mono": dict(bg0=(0.0, 0.0, 0.0), bg1=(0.08, 0.08, 0.08), a=(0.95, 0.95, 0.95), b=(0.6, 0.6, 0.6), c=(0.85, 0.85, 0.85), hot=(1.0, 1.0, 1.0)),
    "ice": dict(bg0=(0.0, 0.02, 0.06), bg1=(0.0, 0.1, 0.2), a=(0.3, 0.8, 1.0), b=(0.9, 0.97, 1.0), c=(0.3, 0.45, 1.0), hot=(0.8, 1.0, 1.0)),
}
COLOR_CH = ("a", "b", "c", "hot")
SRC_CH = ("kick", "snare", "hat", "clap", "perc", "bass", "lead", "pad", "vocal", "focus", "energy", "rms", "low", "mid", "high")


def _col(ctx, name, k=1.0):
    return np.asarray(ctx.pal.get(name, ctx.pal["a"]), np.float32) * k


def _src(ctx, pl, key="src"):
    return ctx.sig.value(pl.p[key], ctx.i)


def _cache(ctx, key, fn):
    d = ctx.state.setdefault("_c", {})
    if key not in d:
        d[key] = fn()
    return d[key]


class VPlugin(Plugin):
    def render(self, ctx, i):
        pass

    def apply(self, ctx, img, i):
        return img

    def st(self, ctx, i):
        """Stan pędzla między klatkami; reset przy skoku na osi czasu (podgląd/seek)."""
        s = self.__dict__.setdefault("_st", {"last": -10})
        if i != s["last"] + 1:
            s.clear(); s["last"] = i
        else:
            s["last"] = i
        return s


# =============================================================== ROOMS
@VREG.register
class RoomVoid(VPlugin):
    fills_canvas = True            # pierwsza instrukcja rysowania zamalowuje całą klatkę → host nie musi jej wcześniej zerować
    id, kind, title = "room_void", "room", "Void gradient"
    desc = "Gradient tła pulsujący z energią (pod teledysk)"
    PARAMS = [Param("pulse", 0, 1, 0.5, desc="siła pulsu od źródła"), Param("glow", 0, 1, 0.35, desc="poświata środka"),
              Param("noise", 0, 1, 0.05), Param("src", kind="choice", choices=SRC_CH, default="energy"), Param("color", kind="choice", choices=COLOR_CH, default="a")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; e = _src(ctx, self, "src")
        k = 1.0 + p["pulse"] * 1.2 * e
        c.gradient_v(_col(ctx, "bg0"), np.clip(_col(ctx, "bg1") * k, 0, 1))
        if p["glow"] > 0:
            c.glow(c.w / 2, c.h * 0.5, c.h * (0.5 + 0.3 * e), _col(ctx, p["color"]), p["glow"] * (0.2 + 0.8 * e))
        if p["noise"] > 0:
            c.img += (ctx.rng.random((c.h, c.w, 1), dtype=np.float32) - 0.5) * p["noise"] * 0.25


@VREG.register
class RoomGrid(VPlugin):
    fills_canvas = True            # pierwsza instrukcja rysowania zamalowuje całą klatkę → host nie musi jej wcześniej zerować
    id, kind, title = "room_grid", "room", "Neon grid hall"
    desc = "Hala z neonową siatką w perspektywie (estetyka retro-futurystyczna)"
    PARAMS = [Param("density", 0, 1, 0.5), Param("speed", 0, 1, 0.4), Param("pulse", 0, 1, 0.6), Param("horizon", 0.3, 0.6, 0.42),
              Param("src", kind="choice", choices=SRC_CH, default="kick"), Param("color", kind="choice", choices=COLOR_CH, default="c")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w, h = c.w, c.h; env = _src(ctx, self, "src")
        hz = h * p["horizon"]; c.gradient_v(_col(ctx, "bg0"), _col(ctx, "bg1"))
        c.rect(0, hz, w, h, (0, 0, 0), 0.45)
        col = _col(ctx, p["color"]); br = 0.35 + 0.65 * min(1.0, p["pulse"] * env + 0.25)
        c.glow(w / 2, hz, h * 0.55, _col(ctx, "a"), 0.15 + 0.45 * p["pulse"] * env)
        scroll = ctx.sig.t[ctx.i] * (0.2 + p["speed"] * 1.6) * ctx.sig.bpm / 140.0
        N = 16
        for k in range(N):
            u = ((k + scroll) / N) % 1.0; y = hz + (h - hz) * u ** 2.2
            c.line(0, y, w, y, col, max(1, int(h / 360 + u * 2)), br * (0.15 + 0.85 * u), True)
        bot = w * (0.06 + 0.14 * (1.0 - p["density"])); top = w * 0.012
        V = int(w / bot) + 2
        for j in range(-V, V + 1):
            c.line(w / 2 + j * top, hz, w / 2 + j * bot, h, col, max(1, h // 400), br * 0.55, True)
        c.line(0, hz, w, hz, _col(ctx, "b"), max(1, h // 300), 0.5 + 0.5 * env, True)


@VREG.register
class RoomStage(VPlugin):
    fills_canvas = True            # pierwsza instrukcja rysowania zamalowuje całą klatkę → host nie musi jej wcześniej zerować
    id, kind, title = "room_stage", "room", "Dark stage"
    desc = "Ciemna scena: kratownica z reflektorami, plamy światła na podłodze, mgła"
    PARAMS = [Param("spots", 2, 8, 4, "int"), Param("fog", 0, 1, 0.35), Param("intensity", 0, 1, 0.6), Param("ambient", 0, 1, 0.15),
              Param("src", kind="choice", choices=SRC_CH, default="kick")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w, h = c.w, c.h; env = _src(ctx, self, "src"); t = ctx.sig.t[ctx.i]
        c.gradient_v(_col(ctx, "bg0"), _col(ctx, "bg1", 0.5 + p["ambient"]))
        c.rect(0, h * 0.78, w, h, (0, 0, 0), 0.4)
        n = p["spots"]
        for k in range(n):
            x = w * (k + 0.5) / n; colr = _col(ctx, COLOR_CH[k % 3]); on = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(t * 1.7 + k * 1.9))
            c.glow(x + math.sin(t * 0.6 + k) * w * 0.03, h * 0.86, w * 0.1, colr, p["intensity"] * on * (0.3 + 0.7 * env))
            c.disc(x, h * 0.05, max(2, h // 70), colr, 0.6 + 0.4 * on, False)
        c.rect(0, h * 0.04, w, h * 0.04 + max(1, h // 200), _col(ctx, "b"), 0.5)
        if p["fog"] > 0:
            yy = _cache(ctx, ("fog_y", h), lambda: np.linspace(0, 1, h, dtype=np.float32)[:, None]); xx = _cache(ctx, ("fog_x", w), lambda: np.linspace(0, 1, w, dtype=np.float32)[None, :])
            # sin(A(x)+B(y)) = sin A·cos B + cos A·sin B → 4 funkcje 1-D i 2 iloczyny zewnętrzne zamiast sin na całej siatce h×w (wynik ten sam)
            A = xx * 6 + t * 0.4; B = np.sin(yy * 5 + t * 0.3) * 2
            f = (0.5 + 0.5 * (np.sin(A) * np.cos(B) + np.cos(A) * np.sin(B))) * (0.25 + 0.75 * yy)
            c.img += f[..., None] * (_col(ctx, "a", 0.18) * (p["fog"] * (0.4 + 0.6 * float(ctx.sig.energy[ctx.i]))))


@VREG.register
class RoomTunnel(VPlugin):
    fills_canvas = True            # pierwsza instrukcja rysowania zamalowuje całą klatkę → host nie musi jej wcześniej zerować
    id, kind, title = "room_tunnel", "room", "Tunnel"
    desc = "Tunel koncentrycznych ramek jadący w tempo"
    PARAMS = [Param("count", 6, 24, 12, "int"), Param("speed", 0, 1, 0.5), Param("sway", 0, 1, 0.3), Param("src", kind="choice", choices=SRC_CH, default="kick")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w, h = c.w, c.h; env = _src(ctx, self, "src"); t = ctx.sig.t[ctx.i]
        c.gradient_v(_col(ctx, "bg0"), _col(ctx, "bg1"))
        ph = t * (0.15 + p["speed"] * 1.2) * ctx.sig.bpm / 140.0 + env * 0.15
        cx = w / 2 + math.sin(t * 0.7) * w * 0.08 * p["sway"]; cy = h / 2 + math.cos(t * 0.5) * h * 0.06 * p["sway"]
        n = p["count"]
        for k in range(n):
            u = ((k + ph) / n) % 1.0; s = u ** 2.0
            hw, hh = w * 0.62 * s, h * 0.62 * s
            c.frame_rect(cx - hw, cy - hh, cx + hw, cy + hh, _col(ctx, COLOR_CH[k % 3]), max(1, int(1 + 3 * u * h / 480)), (0.15 + 0.85 * u) * (0.5 + 0.5 * env), True)


@VREG.register
class RoomLedWall(VPlugin):
    fills_canvas = True            # pierwsza instrukcja rysowania zamalowuje całą klatkę → host nie musi jej wcześniej zerować
    id, kind, title = "room_ledwall", "room", "LED wall"
    desc = "Ściana LED: widmo jako słupki pikseli"
    PARAMS = [Param("cols", 8, 64, 32, "int"), Param("gap", 0, 1, 0.25), Param("base", 0, 1, 0.12), Param("color", kind="choice", choices=("gradient", "a", "b", "c"), default="gradient")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w, h = c.w, c.h; cols = p["cols"]; rows = max(4, int(round(cols * h / w)))
        cw, ch = max(1, w // cols), max(1, h // rows)
        sp = ctx.sig.spec(ctx.i, cols); ht = sp * rows
        r = np.arange(rows)[::-1][:, None]
        lit = np.clip(ht[None, :] - r, 0, 1)                                         # (rows, cols), dół = 0
        if p["color"] == "gradient":
            u = np.linspace(0, 1, cols, dtype=np.float32)[None, :, None]
            base = _col(ctx, "c") * (1 - u) + _col(ctx, "a") * u
        else:
            base = np.broadcast_to(_col(ctx, p["color"]), (1, cols, 3))
        cells = (p["base"] * 0.5 + lit[..., None] * (1 - p["base"] * 0.5)) * base
        cells = cells * (0.4 + 0.6 * np.clip(lit[..., None] + p["base"], 0, 1))
        big = np.repeat(np.repeat(cells, ch, 0), cw, 1).astype(np.float32)
        gap = _cache(ctx, ("led", w, h, cols, round(p["gap"], 2)), lambda: self._mask(rows * ch, cols * cw, ch, cw, p["gap"]))
        big = big * gap
        c.img[:] = _col(ctx, "bg0")
        y0, x0 = (h - big.shape[0]) // 2, (w - big.shape[1]) // 2
        c.img[y0: y0 + big.shape[0], x0: x0 + big.shape[1]] = big[: h - y0, : w - x0]

    @staticmethod
    def _mask(H, W, ch, cw, gap):
        m = np.ones((H, W, 1), np.float32); g = int(round(min(ch, cw) * gap * 0.5))
        if g > 0:
            m[np.arange(H) % ch < g] = 0; m[:, np.arange(W) % cw < g] = 0
        return m


# =============================================================== PERFORMERS
@VREG.register
class PerfRobot(VPlugin):
    id, kind, title = "perf_robot", "performer", "Robot"
    desc = "Sztywny robot-muzyk: ramiona, wizjer i tors reagują na wybrane źródło (kick, bas, lead…)"
    PARAMS = [Param("x", 0.05, 0.95, 0.5), Param("y", 0.5, 0.95, 0.8), Param("scale", 0.3, 1.6, 1.0), Param("stiffness", 0, 1, 0.7),
              Param("glow", 0, 1, 0.5), Param("src", kind="choice", choices=SRC_CH, default="kick"), Param("color", kind="choice", choices=COLOR_CH, default="a"),
              Param("accent", kind="choice", choices=COLOR_CH, default="b")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w, h = c.w, c.h
        env = _src(ctx, self, "src"); sg = ctx.sig; t = sg.t[ctx.i]
        q = round(env * 4) / 4 if p["stiffness"] > 0.5 else env                      # sztywne „kroki” ramion
        u = h * 0.11 * p["scale"]; x = p["x"] * w; fy = p["y"] * h
        col = _col(ctx, p["color"]); acc = _col(ctx, p["accent"]); th = max(1, int(u * 0.1)); beat = float(sg.beat_phase[ctx.i])
        nod = 0.12 * u * env if p["src"] in ("bass", "kick") else 0.0
        step = 1 if (int(t / sg.spb) % 2 == 0) else -1
        hip = fy - 2.0 * u - (0.12 * u * env)
        top = hip - 2.2 * u + nod
        for s_ in (-1, 1):                                                         # nogi
            lift = 0.25 * u * (1 if s_ == step else 0) * (1 if q > 0.2 else 0)
            lx = x + s_ * 0.55 * u
            c.rect(lx - 0.22 * u, hip, lx + 0.22 * u, fy - lift, col * 0.35, 0.95)
            c.rect(lx - 0.22 * u, hip, lx - 0.22 * u + th, fy - lift, col, 0.9, True)
            c.rect(lx - 0.4 * u, fy - lift - 0.15 * u, lx + 0.4 * u, fy - lift, col * 0.5, 1.0)
        c.rect(x - 1.0 * u, top, x + 1.0 * u, hip, _col(ctx, "bg1", 1.6), 0.95)        # tors
        c.frame_rect(x - 1.0 * u, top, x + 1.0 * u, hip, col, th, 0.95, True)
        c.rect(x - 0.55 * u, top + 0.45 * u, x + 0.55 * u, top + 0.95 * u, acc * (0.25 + 0.75 * env), 1.0)           # panel piersi
        for k in range(3):
            lit = 1.0 if beat < 0.2 + k * 0.2 else 0.15
            c.rect(x - 0.55 * u + k * 0.4 * u, top + 1.25 * u, x - 0.55 * u + k * 0.4 * u + 0.25 * u, top + 1.45 * u, col * (0.25 + 0.75 * lit), 1.0)
        hx0, hx1, hy0, hy1 = x - 0.7 * u, x + 0.7 * u, top - 1.45 * u, top - 0.1 * u
        c.rect(hx0, hy0, hx1, hy1, _col(ctx, "bg1", 1.8), 0.95); c.frame_rect(hx0, hy0, hx1, hy1, col, th, 0.95, True)
        c.rect(hx0 + 0.12 * u, hy0 + 0.4 * u, hx1 - 0.12 * u, hy0 + 0.75 * u, acc * (0.35 + 0.65 * env), 1.0)          # wizjer
        c.line(x, hy0, x, hy0 - 0.5 * u, col, th, 0.9, True); c.disc(x, hy0 - 0.55 * u, max(1, 0.12 * u), acc, 0.4 + 0.6 * (1 - beat), True)
        for s_ in (-1, 1):                                                         # ramiona (kąt od pionu w dół)
            ph = q if s_ == -1 else q * (0.45 + 0.55 * abs(math.sin(t * math.pi / sg.spb / 2)))
            a = math.radians(15 + 120 * ph); fa = math.radians(15 + 155 * ph)
            sx, sy = x + s_ * 1.0 * u, top + 0.3 * u
            ex, ey = sx + s_ * 1.6 * u * math.sin(a), sy + 1.6 * u * math.cos(a)
            fx, fy2 = ex + s_ * 1.4 * u * math.sin(fa), ey + 1.4 * u * math.cos(fa) * (1 if ph < 0.6 else -0.4)
            c.line(sx, sy, ex, ey, col, th * 2, 0.95, True); c.line(ex, ey, fx, fy2, col, th * 2, 0.95, True); c.disc(fx, fy2, max(1, 0.18 * u), acc, 0.9, True)
        if p["glow"] > 0:
            c.glow(x, top + 0.7 * u, 2.6 * u, col, p["glow"] * (0.15 + 0.6 * env))
            c.glow(x, fy, 1.8 * u, col, p["glow"] * 0.25 * (0.3 + env))


_SHAPES = {
    "cube": ([(-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1), (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)],
             [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)]),
    "octa": ([(1.3, 0, 0), (-1.3, 0, 0), (0, 1.3, 0), (0, -1.3, 0), (0, 0, 1.3), (0, 0, -1.3)],
             [(a, b) for a in range(6) for b in range(a + 1, 6) if a // 2 != b // 2]),
    "tetra": ([(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)], [(a, b) for a in range(4) for b in range(a + 1, 4)]),
}


@VREG.register
class PerfWire(VPlugin):
    id, kind, title = "perf_wire", "performer", "Wireframe"
    desc = "Obracająca się bryła druciana (teledysk 1-track), skala pulsuje ze źródłem"
    PARAMS = [Param("x", 0.05, 0.95, 0.5), Param("y", 0.2, 0.8, 0.5), Param("scale", 0.2, 2.0, 1.0), Param("spin", 0, 1, 0.4), Param("thickness", 1, 6, 2, "int"),
              Param("shape", kind="choice", choices=tuple(_SHAPES), default="cube"), Param("src", kind="choice", choices=SRC_CH, default="focus"),
              Param("color", kind="choice", choices=COLOR_CH, default="c")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; env = _src(ctx, self, "src"); t = ctx.sig.t[ctx.i]
        V, E = _SHAPES[p["shape"]]; V = np.array(V, np.float32)
        ry = t * (0.2 + 1.4 * p["spin"]) + env * 0.5; rx = t * (0.1 + 0.8 * p["spin"]) * 0.7 + 0.3; rz = math.sin(t * 0.3) * 0.3
        cy_, sy_, cx_, sx_, cz, sz = math.cos(ry), math.sin(ry), math.cos(rx), math.sin(rx), math.cos(rz), math.sin(rz)
        R = np.array([[cy_, 0, sy_], [0, 1, 0], [-sy_, 0, cy_]], np.float32) @ np.array([[1, 0, 0], [0, cx_, -sx_], [0, sx_, cx_]], np.float32) @ np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]], np.float32)
        P = V @ R.T; k = min(c.w, c.h) * 0.2 * p["scale"] * (1 + 0.3 * env); f = 4.0 / (4.0 + P[:, 2])
        X = p["x"] * c.w + P[:, 0] * k * f; Y = p["y"] * c.h + P[:, 1] * k * f
        col = _col(ctx, p["color"]); th = int(p["thickness"] * max(1, c.h / 480))
        for a, b in E:
            c.line(X[a], Y[a], X[b], Y[b], col, th, 0.55 + 0.45 * env, True)
        for j in range(len(X)):
            c.disc(X[j], Y[j], th + 1, _col(ctx, "b"), 0.8, True)
        c.glow(p["x"] * c.w, p["y"] * c.h, k * 1.6, col, 0.15 + 0.5 * env)


@VREG.register
class PerfOrb(VPlugin):
    id, kind, title = "perf_orb", "performer", "Pulse orb"
    desc = "Pulsująca kula z rozchodzącymi się pierścieniami"
    PARAMS = [Param("x", 0.05, 0.95, 0.5), Param("y", 0.2, 0.8, 0.5), Param("scale", 0.2, 2.0, 1.0), Param("rings", 0, 1, 0.6),
              Param("src", kind="choice", choices=SRC_CH, default="kick"), Param("color", kind="choice", choices=COLOR_CH, default="a")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; env = _src(ctx, self, "src"); sg = ctx.sig
        r = min(c.w, c.h) * 0.12 * p["scale"] * (1 + 0.35 * env); x, y = p["x"] * c.w, p["y"] * c.h; col = _col(ctx, p["color"])
        c.glow(x, y, r * 2.4, col, 0.3 + 0.6 * env); c.disc(x, y, r, col * (0.5 + 0.5 * env), 0.9, False)
        c.ring(x, y, r * 1.05, _col(ctx, "b"), max(1, c.h // 240), 0.8, True)
        for k in range(3):
            u = (float(sg.beat_phase[ctx.i]) + k / 3.0) % 1.0
            c.ring(x, y, r * (1.1 + 2.0 * u), col, max(1, c.h // 240), p["rings"] * (1 - u) * (0.4 + 0.6 * env), True)


# =============================================================== BRUSHES
@VREG.register
class BrushTrail(VPlugin):
    id, kind, title = "brush_trail", "brush", "Neon trail"
    desc = "Neonowy ślad wysokości nut wybranej ścieżki/grupy (przesuwa się przez 2 takty)"
    PARAMS = [Param("width", 1, 8, 3, "int"), Param("length", 0.1, 1, 0.6), Param("glow", 0, 1, 0.5), Param("y", 0.3, 0.95, 0.8), Param("range", 0.2, 0.9, 0.55),
              Param("src", kind="choice", choices=("focus", "lead", "bass", "pad", "vocal"), default="focus"), Param("color", kind="choice", choices=COLOR_CH, default="c")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; sg = ctx.sig; s = self.st(ctx, i)
        pts = s.setdefault("pts", []); pitch, gate = sg.pitch(p["src"], i); span = 8 * sg.spb
        ph = (sg.t[i] % span) / span; x = ph * c.w
        if pts and pts[-1] is not None and x < pts[-1][0]:
            pts.clear()
        y = c.h * (p["y"] - p["range"] * pitch)
        pts.append((x, y, gate) if gate > 0.02 else None)
        mx = int(30 + 300 * p["length"])
        if len(pts) > mx:
            del pts[: len(pts) - mx]
        col = _col(ctx, p["color"]); hot = _col(ctx, "hot"); th = max(1, int(p["width"] * c.h / 480)); L = len(pts)
        for k in range(1, L):
            a, b = pts[k - 1], pts[k]
            if a is None or b is None:
                continue
            age = k / L
            c.line(a[0], a[1], b[0], b[1], col * (1 - age * 0.3) + hot * age * 0.3, th, 0.15 + 0.85 * age, True)
        if pts and pts[-1] is not None:
            c.glow(pts[-1][0], pts[-1][1], th * 9, hot, p["glow"] * (0.4 + 0.6 * pts[-1][2]))


@VREG.register
class BrushParticles(VPlugin):
    id, kind, title = "brush_particles", "brush", "Particle burst"
    desc = "Burza cząstek na akcentach wybranego źródła, z pozycji wykonawców"
    PARAMS = [Param("amount", 0, 1, 0.5), Param("life", 0.2, 2.0, 0.9), Param("gravity", 0, 1, 0.3), Param("speed", 0, 1, 0.5), Param("size", 1, 4, 2, "int"),
              Param("src", kind="choice", choices=SRC_CH, default="kick"), Param("color", kind="choice", choices=COLOR_CH, default="hot")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; s = self.st(ctx, i); env = _src(ctx, self, "src"); dt = 1.0 / ctx.fps
        P = s.get("P")
        if P is None:
            P = s["P"] = np.zeros((0, 6), np.float32); s["prev"] = 0.0
        if env > 0.35 and env > s["prev"] + 0.08 and p["amount"] > 0:
            n = int(4 + 90 * p["amount"] * env); xs = ctx.extras.get("perf_x") or [0.5]
            ex = np.array([xs[ctx.rng.integers(len(xs))] for _ in range(n)], np.float32) * c.w; ey = np.full(n, c.h * 0.55, np.float32)
            ang = ctx.rng.random(n).astype(np.float32) * np.pi * 2; sp = (0.15 + ctx.rng.random(n).astype(np.float32) * (0.2 + 0.6 * p["speed"])) * c.h
            lf = p["life"] * (0.5 + 0.5 * ctx.rng.random(n).astype(np.float32))
            P = s["P"] = np.vstack([P, np.stack([ex, ey, np.cos(ang) * sp, np.sin(ang) * sp - 0.3 * c.h, lf, lf], 1).astype(np.float32)])[-1500:]
        s["prev"] = env
        if len(P):
            P[:, 3] += p["gravity"] * 1.5 * c.h * dt; P[:, 0] += P[:, 2] * dt; P[:, 1] += P[:, 3] * dt; P[:, 4] -= dt
            P = s["P"] = P[(P[:, 4] > 0) & (P[:, 1] < c.h + 5)]
            if len(P):
                a = np.clip(P[:, 4] / P[:, 5], 0, 1)[:, None] * _col(ctx, p["color"])[None, :]
                sz = max(1, int(p["size"] * c.h / 480)); X = P[:, 0].astype(np.int32); Y = P[:, 1].astype(np.int32)
                for dy in range(sz):
                    for dx in range(sz):
                        yy, xx = Y + dy, X + dx; m = (yy >= 0) & (yy < c.h) & (xx >= 0) & (xx < c.w)
                        np.add.at(c.img, (yy[m], xx[m]), a[m])


@VREG.register
class BrushBeams(VPlugin):
    id, kind, title = "brush_beams", "brush", "Light beams"
    desc = "Wiązki światła z sufitu: kołysanie w rytm, jasność od źródła"
    PARAMS = [Param("count", 2, 10, 5, "int"), Param("width", 0.2, 2.0, 1.0), Param("intensity", 0, 1, 0.5), Param("sweep", 0, 1, 0.5),
              Param("src", kind="choice", choices=SRC_CH, default="kick"), Param("color", kind="choice", choices=COLOR_CH, default="b")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w, h = c.w, c.h; env = _src(ctx, self, "src"); t = ctx.sig.t[ctx.i]
        n = p["count"]; I = p["intensity"] * (0.2 + 0.8 * env)
        if I <= 0.01:
            return
        Y = _cache(ctx, ("y1", h), lambda: np.arange(h, dtype=np.float32))
        hw = w * 0.006 * p["width"] * (1 + Y * 4.0 / h) + 1                      # półszerokość wiązki w każdym wierszu
        fall = (1 - 0.6 * Y / h)
        # wiązka jest wąska u góry i szeroka u dołu: zamiast jednego okna kolumn o szerokości najszerszego wiersza (reszta to zera)
        # liczymy 4 pasy wierszy, każdy z własnym, ciasnym oknem — ten sam obraz, ~40% mniej komórek; indeks płaski zamiast pary (wiersz, kolumna)
        flat = c.img.reshape(-1, 3); nb = 4; edges = [h * j // nb for j in range(nb + 1)]
        bands = []
        for j in range(nb):
            r0, r1 = edges[j], edges[j + 1]
            if r1 <= r0:
                continue
            K = int(hw[r0:r1].max()) + 2
            bands.append((r0, r1, np.arange(-K, K + 1, dtype=np.int32)[None, :], np.arange(r0, r1, dtype=np.int64)[:, None] * w))
        for k in range(n):
            x0 = w * (k + 0.5) / n; ang = math.sin(t * (0.3 + p["sweep"]) + k * 1.7) * 0.5 * (0.3 + p["sweep"])
            xc = x0 + math.tan(ang) * Y
            col = _col(ctx, COLOR_CH[k % 3] if p["color"] == "b" else p["color"]) * (I * 0.6)
            for r0, r1, off, rowoff in bands:
                xcb = xc[r0:r1]
                cols = np.floor(xcb).astype(np.int32)[:, None] + off
                b = np.clip(1 - np.abs(cols - xcb[:, None]) / hw[r0:r1, None], 0, 1) ** 1.5 * fall[r0:r1, None]
                m = (cols >= 0) & (cols < w)
                flat[(rowoff + cols)[m]] += b[m][:, None] * col


@VREG.register
class BrushScope(VPlugin):
    id, kind, title = "brush_scope", "brush", "Oscilloscope"
    desc = "Linia oscyloskopu z przebiegu miksu (albo syntetyczna z eventów)"
    PARAMS = [Param("y", 0.1, 0.9, 0.5), Param("height", 0.05, 0.6, 0.25), Param("thickness", 1, 5, 2, "int"), Param("glow", 0, 1, 0.4),
              Param("color", kind="choice", choices=COLOR_CH, default="c")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w = c.w; wv = ctx.sig.wave(ctx.i, 256)
        wv = np.interp(np.arange(w), np.linspace(0, w - 1, len(wv)), wv)
        ys = (c.h * p["y"] - np.clip(wv, -1, 1) * c.h * p["height"] * 0.5).astype(np.int32); xs = np.arange(w, dtype=np.int32); th = max(1, int(p["thickness"] * c.h / 480))
        col = _col(ctx, p["color"])
        for d in range(-(th // 2), th // 2 + 1):
            c._blend(ys + d, xs, col, 0.9, True)
        if p["glow"] > 0:
            c._blend(ys - th - 1, xs, col, p["glow"] * 0.3, True); c._blend(ys + th + 1, xs, col, p["glow"] * 0.3, True)


# =============================================================== CAMERA
@VREG.register
class CamStatic(VPlugin):
    id, kind, title = "cam_static", "camera", "Static camera"
    desc = "Statyczny kadr (zoom / przesunięcie)"
    PARAMS = [Param("zoom", 1.0, 2.0, 1.0), Param("pan_x", 0, 1, 0.5), Param("pan_y", 0, 1, 0.5)]

    def apply(self, ctx, img, i):
        return ctx.canvas.zoom(img, self.p["zoom"], self.p["pan_x"], self.p["pan_y"])


@VREG.register
class CamDrift(VPlugin):
    id, kind, title = "cam_drift", "camera", "Slow drift"
    desc = "Powolny dryf i „oddech” kamery"
    PARAMS = [Param("amount", 0, 1, 0.3), Param("speed", 0, 1, 0.2), Param("breath", 0, 1, 0.3)]

    def apply(self, ctx, img, i):
        p = self.p; t = ctx.sig.t[ctx.i]; sp = 0.2 + p["speed"] * 1.5
        z = 1.0 + 0.12 * p["amount"] + 0.04 * p["breath"] * math.sin(t * sp * 1.3)
        return ctx.canvas.zoom(img, z, 0.5 + 0.06 * p["amount"] * math.sin(t * sp * 0.7), 0.5 + 0.04 * p["amount"] * math.cos(t * sp * 0.5))


@VREG.register
class CamPunch(VPlugin):
    id, kind, title = "cam_punch", "camera", "Punch zoom"
    desc = "Zoom „uderzenie” na akcencie źródła + opcjonalne drżenie"
    PARAMS = [Param("amount", 0, 1, 0.5), Param("shake", 0, 1, 0.15), Param("base", 1.0, 1.5, 1.05), Param("src", kind="choice", choices=SRC_CH, default="kick")]

    def apply(self, ctx, img, i):
        p = self.p; env = _src(ctx, self, "src"); z = p["base"] + 0.14 * p["amount"] * env
        j = p["shake"] * env * 0.02
        return ctx.canvas.zoom(img, z, 0.5 + j * (ctx.rng.random() - 0.5) * 2, 0.5 + j * (ctx.rng.random() - 0.5) * 2)


# =============================================================== FX (postprodukcja)
@VREG.register
class FxBloom(VPlugin):
    id, kind, title = "fx_bloom", "fx", "Bloom"
    desc = "Rozmyta poświata jasnych miejsc"
    PARAMS = [Param("amount", 0, 1, 0.5), Param("threshold", 0, 1, 0.5)]

    def apply(self, ctx, img, i):
        h, w = img.shape[:2]; f = 4; hh, ww = h // f * f, w // f * f
        if hh < 8 or ww < 8 or self.p["amount"] <= 0:
            return img
        fast = ww == w and img.flags.c_contiguous
        if fast:
            # sumy po 4 wierszach jako dodawania ciągłych pasów (bez .mean((1, 3)) po osiach nieciągłych — to był najwolniejszy krok blooma)
            r = img[:hh].reshape(hh // f, f, w * 3)
            s = r[:, 0] + r[:, 1]; s += r[:, 2]; s += r[:, 3]
            sm = s.reshape(hh // f, ww // f, f, 3).sum(2) * np.float32(1.0 / (f * f))
        else:
            sm = img[:hh, :ww].reshape(hh // f, f, ww // f, f, 3).mean((1, 3))
        br = np.maximum(sm - self.p["threshold"] * 0.8, 0)
        for _ in range(2):
            br = (br + np.roll(br, 1, 0) + np.roll(br, -1, 0) + np.roll(br, 1, 1) + np.roll(br, -1, 1)) / 5.0
        add = br * np.float32(self.p["amount"] * 2.2)
        if not add.any():
            return img                                           # ciemna klatka: poświata = 0, nic nie dodajemy (wynik identyczny)
        if fast and img.flags.writeable:
            # poziomo powielamy tylko małą tablicę (h/4 × w·3), a pionowo dodajemy ją do 4 pasów wprost w klatce: bez np.repeat×2 na pełnej klatce i bez jej kopii
            row = np.repeat(add, f, axis=1).reshape(hh // f, w * 3)
            for j in range(f):
                r[:, j] += row
            return img
        out = img.copy(); out[:hh, :ww] += np.repeat(np.repeat(add, f, 0), f, 1)
        return out


@VREG.register
class FxScanlines(VPlugin):
    id, kind, title = "fx_scanlines", "fx", "Scanlines CRT"
    desc = "Linie CRT, winieta, migotanie"
    PARAMS = [Param("amount", 0, 1, 0.45), Param("vignette", 0, 1, 0.35), Param("flicker", 0, 1, 0.15)]

    def apply(self, ctx, img, i):
        p = self.p; h, w = img.shape[:2]
        m = _cache(ctx, ("scan", w, h, round(p["amount"], 2), round(p["vignette"], 2)), lambda: self._mask(h, w, p["amount"], p["vignette"]))
        k = 1.0 - p["flicker"] * 0.15 * float(ctx.rng.random())
        mk = m * np.float32(k)                                   # (h,w,1) — mnożenie maski przez skalar jest 3× tańsze niż po (h,w,3)
        if img.flags.writeable and img.flags.c_contiguous:
            img *= mk; return img
        return img * mk

    @staticmethod
    def _mask(h, w, am, vg):
        y = np.arange(h)[:, None]; x = np.linspace(-1, 1, w)[None, :]; yy = np.linspace(-1, 1, h)[:, None]
        m = (1 - am * 0.4 * (y % 2))[..., None].astype(np.float32)
        v = (1 - vg * 0.7 * np.clip((x ** 2 + yy ** 2) / 2.0, 0, 1))[..., None].astype(np.float32)
        return m * v


@VREG.register
class FxGlitch(VPlugin):
    id, kind, title = "fx_glitch", "fx", "Glitch blocks"
    desc = "Przesunięte pasy, rozjazd RGB; częstość rośnie z akcentem źródła"
    PARAMS = [Param("amount", 0, 1, 0.3), Param("block", 0, 1, 0.4), Param("split", 0, 1, 0.25), Param("src", kind="choice", choices=SRC_CH, default="snare")]

    def apply(self, ctx, img, i):
        p = self.p; env = _src(ctx, self, "src"); h, w = img.shape[:2]
        if p["amount"] <= 0 or ctx.rng.random() > p["amount"] * (0.1 + 0.9 * env) * 1.5:
            return img
        out = img.copy()
        for _ in range(1 + int(p["amount"] * 4)):
            hh = max(1, int(h * (0.01 + 0.12 * p["block"]) * ctx.rng.random())); y0 = int(ctx.rng.random() * max(1, h - hh)); sh = int((ctx.rng.random() - 0.5) * w * 0.25 * p["amount"])
            out[y0: y0 + hh] = np.roll(out[y0: y0 + hh], sh, 1)
        s = int(p["split"] * w * 0.015 * (0.4 + env))
        if s:
            out[..., 0] = np.roll(out[..., 0], s, 1); out[..., 2] = np.roll(out[..., 2], -s, 1)
        return out


@VREG.register
class FxStrobe(VPlugin):
    id, kind, title = "fx_strobe", "fx", "Strobe"
    desc = "Błysk na akcent źródła (powyżej progu)"
    PARAMS = [Param("amount", 0, 1, 0.4), Param("threshold", 0, 0.95, 0.55), Param("src", kind="choice", choices=SRC_CH, default="kick"), Param("color", kind="choice", choices=COLOR_CH, default="b")]

    def apply(self, ctx, img, i):
        p = self.p; env = _src(ctx, self, "src"); fl = max(0.0, env - p["threshold"]) / max(1e-3, 1 - p["threshold"])
        if fl <= 0 or p["amount"] <= 0:
            return img
        return img + _col(ctx, p["color"]) * (p["amount"] * fl * 0.9)


@VREG.register
class FxMirror(VPlugin):
    id, kind, title = "fx_mirror", "fx", "Mirror"
    desc = "Lustro / kalejdoskop: lewo-prawo, góra-dół, ćwiartki"
    PARAMS = [Param("mode", kind="choice", choices=("lr", "tb", "quad"), default="lr"), Param("mix", 0, 1, 1.0)]

    def apply(self, ctx, img, i):
        h, w = img.shape[:2]; m = self.p["mode"]
        out = img if (self.p["mix"] >= 0.999 and img.flags.writeable) else img.copy()          # pełne lustro: w miejscu, bez kopii klatki
        if m in ("lr", "quad"):
            out[:, w // 2:] = out[:, : w - w // 2][:, ::-1]
        if m in ("tb", "quad"):
            out[h // 2:] = out[: h - h // 2][::-1]
        mx = self.p["mix"]
        return out if mx >= 0.999 else img * (1 - mx) + out * mx


@VREG.register
class FxFade(VPlugin):
    id, kind, title = "fx_fade", "fx", "Fade in/out"
    desc = "Wejście i wyjście z czerni (na początku i końcu utworu)"
    PARAMS = [Param("fade_in", 0, 6, 1.5), Param("fade_out", 0, 10, 3.0)]

    def apply(self, ctx, img, i):
        sg = ctx.sig; t = float(sg.t[ctx.i]); last = sg.sections[-1]; end = (last["start"] + last["bars"]) * 4 * sg.spb
        k = 1.0
        if self.p["fade_in"] > 0:
            k = min(k, t / self.p["fade_in"])
        if self.p["fade_out"] > 0:
            k = min(k, (end - t) / self.p["fade_out"])
        k = max(0.0, min(1.0, k))
        return img if k >= 0.999 else img * (k * k * (3 - 2 * k))


# =============================================================== OVERLAYS
@VREG.register
class OvSpectrum(VPlugin):
    id, kind, title = "ov_spectrum", "overlay", "Spectrum bars"
    desc = "Słupki widma na dole kadru"
    PARAMS = [Param("bars", 8, 64, 32, "int"), Param("opacity", 0, 1, 0.65), Param("height", 0.05, 0.5, 0.22), Param("mirror", kind="bool", default=False), Param("color", kind="choice", choices=COLOR_CH, default="c")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; n = p["bars"]; sp = ctx.sig.spec(ctx.i, n); bw = c.w / n; col = _col(ctx, p["color"])
        for k in range(n):
            bh = sp[k] * c.h * p["height"]
            c.rect(k * bw + 1, c.h - bh, (k + 1) * bw - 1, c.h, col, p["opacity"], True)
            if p["mirror"]:
                c.rect(k * bw + 1, 0, (k + 1) * bw - 1, bh, col, p["opacity"] * 0.7, True)


@VREG.register
class OvWave(VPlugin):
    id, kind, title = "ov_wave", "overlay", "Waveform"
    desc = "Falownik audio pod kadrem"
    PARAMS = [Param("y", 0.5, 0.97, 0.9), Param("height", 0.05, 0.4, 0.14), Param("opacity", 0, 1, 0.7), Param("thickness", 1, 4, 2, "int"), Param("color", kind="choice", choices=COLOR_CH, default="b")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; w = c.w; wv = ctx.sig.wave(ctx.i, 256); wv = np.interp(np.arange(w), np.linspace(0, w - 1, len(wv)), wv)
        ys = (c.h * p["y"] - np.clip(wv, -1, 1) * c.h * p["height"]).astype(np.int32); xs = np.arange(w, dtype=np.int32); col = _col(ctx, p["color"]); th = max(1, int(p["thickness"] * c.h / 480))
        for d in range(-(th // 2), th // 2 + 1):
            c._blend(ys + d, xs, col, p["opacity"], True)


@VREG.register
class OvTitle(VPlugin):
    id, kind, title = "ov_title", "overlay", "Title block"
    desc = "Tytuł, styl / BPM / tonacja, nazwa sekcji, znacznik LIVE"
    PARAMS = [Param("corner", kind="choice", choices=("bl", "tl", "br", "tr", "c"), default="bl"), Param("scale", 0.5, 3.0, 1.0), Param("opacity", 0, 1, 0.9),
              Param("section", kind="bool", default=True), Param("live", kind="bool", default=False), Param("color", kind="choice", choices=COLOR_CH, default="b")]

    def render(self, ctx, i):
        c = ctx.canvas; p = self.p; m = ctx.meta; sg = ctx.sig; sc = max(1, int(round(c.h / 240.0 * p["scale"]))); lh = 9 * sc
        sec = sg.section(ctx.i)
        lines = [str(m.get("title", "")).upper()[:28], f"{m.get('style', '')} {m.get('bpm', '')} BPM {m.get('key', '')}".upper().strip()]
        if p["section"]:
            lines.append(">> " + str(sec.get("type", "")).upper() + (f" {sec.get('k')}" if sec.get("k") else ""))
        lines = [x for x in lines if x.strip()]
        mx = int(c.w * 0.03); my = int(c.h * 0.04)
        al = {"bl": ("left", mx, c.h - my - lh * len(lines)), "tl": ("left", mx, my), "br": ("right", c.w - mx, c.h - my - lh * len(lines)),
              "tr": ("right", c.w - mx, my), "c": ("center", c.w / 2, c.h / 2 - lh * len(lines) / 2)}[p["corner"]]
        col = _col(ctx, p["color"])
        for k, ln in enumerate(lines):
            c.text(al[1], al[2] + k * lh, ln, sc, col if k == 0 else _col(ctx, "a"), p["opacity"], al[0])
        if p["live"] and int(ctx.sig.t[ctx.i] * 2) % 2 == 0:
            c.text(c.w - mx, my, "LIVE", sc, (1, 1, 1), 0.95, "right"); c.disc(c.w - mx - 4 * 6 * sc - 4 * sc, my + 3 * sc, 3 * sc, (1, 0.1, 0.1))
