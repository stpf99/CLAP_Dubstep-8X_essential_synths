"""era_profiles.py — zasób instrumentów i charakter brzmienia wg epoki.

Nie emuluje marek (Moog/Roland/…). Mapuje dekady na:
  - ile i które typy z kitu CLAP zostają w aranżu
  - bias parametrów (filtr, unison, FM, noise, glide)
  - domyślną spektakularność / gęstość warstw

Kraftwerk-ish (70s): mało torów, proste sekwencje, surowy osc.
Współcześnie (2010+): warstwy, supersaw, FM, vocal, wiele instancji.
"""
from __future__ import annotations

import random
import re

# id → etykieta GUI
ERA_ORDER = (
    "auto",
    "minimal_70s",
    "analog_80s",
    "digital_90s",
    "rave_00s",
    "modern_10s",
    "maximal_now",
)

ERA_LABELS = {
    "auto": "Auto (ze stylu)",
    "minimal_70s": "Minimal 70s (Kraftwerk-ish)",
    "analog_80s": "Analog / early digital 80s",
    "digital_90s": "Digital 90s",
    "rave_00s": "Rave / bass 2000s",
    "modern_10s": "Modern 2010s",
    "maximal_now": "Maximal now (DAW-dense)",
}

# preferowane typy (kolejność = priorytet przy limicie slotów)
# brak na liście = rzadziej / tylko przy wysokim density
ERA = {
    "minimal_70s": {
        "max_tracks": 6,
        "spectacle": "monotone",
        "prefer": ["kick", "snare", "hat", "sub", "wobble", "pluck", "pad", "theremin", "organ", "drone", "bell", "flute", "choir", "vibes", "harpsichord", "cello", "marimba"],
        "avoid": ["growl", "neuro", "screech", "supersaw", "vox", "speak", "riser", "boom", "zap",
                  "piano", "strings", "acid", "fmbass", "hollow", "handpan", "tongue", "stab", "clap"],
        "param_bias": {
            "Unison Voices": -0.35, "Unison Detune": -0.25, "Drive": -0.15,
            "FM Amount": -0.3, "Noise": -0.2, "Resonance": -0.1,
            "Glide": +0.1, "Cutoff": -0.1, "LFO > Pitch": +0.05,
        },
        "density_mul": 0.55,
        "niuanse_mul": 0.4,
    },
    "analog_80s": {
        "max_tracks": 9,
        "spectacle": "plain",
        "prefer": ["kick", "snare", "hat", "clap", "sub", "wobble", "reese", "pluck", "pad", "stab",
                   "acid", "theremin", "panflute", "tom",
                   "bass808", "openhat", "cowbell", "conga", "organ", "epiano", "brass", "bell", "choir", "flute", "vibes", "harpsichord", "cello", "upright", "ride", "marimba", "drone"],
        "avoid": ["neuro", "growl", "speak", "handpan", "tongue", "boom", "glitch", "hoover"],
        "param_bias": {
            "Unison Voices": -0.15, "Unison Detune": -0.05, "Drive": 0.0,
            "FM Amount": -0.1, "Resonance": +0.1, "Glide": +0.15,
            "Attack": +0.05, "Release": +0.08,
        },
        "density_mul": 0.7,
        "niuanse_mul": 0.55,
    },
    "digital_90s": {
        "max_tracks": 12,
        "spectacle": "balanced",
        "prefer": ["kick", "snare", "hat", "clap", "rim", "sub", "wobble", "reese", "fmbass", "acid",
                   "screech", "pluck", "pad", "stab", "supersaw", "riser", "zap", "piano",
                   "openhat", "hoover", "organ", "epiano", "brass", "choir", "bell", "cowbell", "conga", "ride", "flute", "bass808", "upright", "vibes", "drone", "cello", "marimba", "harpsichord"],
        "avoid": ["handpan", "tongue", "speak", "glitch"],
        "param_bias": {
            "Unison Voices": +0.1, "Unison Detune": +0.1, "FM Amount": +0.15,
            "Cutoff": +0.08, "Drive": +0.05, "Resonance": +0.12,
        },
        "density_mul": 0.85,
        "niuanse_mul": 0.75,
    },
    "rave_00s": {
        "max_tracks": 14,
        "spectacle": "vivid",
        "prefer": ["kick", "snare", "hat", "clap", "sub", "wobble", "reese", "growl", "neuro", "fmbass",
                   "hollow", "acid", "screech", "supersaw", "pluck", "stab", "vox", "riser", "boom", "zap",
                   "hoover", "openhat", "ride", "glitch", "bass808", "brass", "choir", "bell", "epiano", "organ", "cowbell", "conga", "upright", "drone"],
        "avoid": ["handpan", "tongue", "theremin", "harpsichord"],
        "param_bias": {
            "Drive": +0.18, "FM Amount": +0.2, "Resonance": +0.15,
            "Unison Detune": +0.15, "Noise": +0.1, "Cutoff": +0.05,
        },
        "density_mul": 1.0,
        "niuanse_mul": 0.9,
    },
    "modern_10s": {
        "max_tracks": 16,
        "spectacle": "vivid",
        "prefer": ["kick", "snare", "hat", "clap", "shaker", "sub", "wobble", "reese", "growl", "neuro",
                   "acid", "screech", "supersaw", "pluck", "pad", "stab", "vox", "piano", "strings",
                   "riser", "boom", "zap", "speak", "panflute",
                   "hoover", "openhat", "ride", "glitch", "bass808", "brass", "choir", "bell", "epiano", "organ", "cowbell", "conga", "upright", "drone",
                   "flute", "vibes", "marimba", "cello", "harpsichord"],
        "avoid": [],
        "param_bias": {
            "Unison Voices": +0.2, "Unison Detune": +0.18, "Drive": +0.1,
            "FM Amount": +0.12, "Formant Mix": +0.1, "Cutoff": +0.1,
        },
        "density_mul": 1.05,
        "niuanse_mul": 1.0,
    },
    "maximal_now": {
        "max_tracks": 22,
        "spectacle": "anthem",
        "prefer": None,  # wszystko dozwolone
        "avoid": [],
        "param_bias": {
            "Unison Voices": +0.28, "Unison Detune": +0.25, "Drive": +0.12,
            "FM Amount": +0.15, "Noise": +0.08, "Formant Mix": +0.12,
            "LFO > Cutoff": +0.1, "Resonance": +0.08,
        },
        "density_mul": 1.15,
        "niuanse_mul": 1.15,
    },
}

# luźne mapowanie stylów generatora → domyślna era (auto)
STYLE_ERA = {
    "Brostep": "rave_00s", "Riddim": "rave_00s", "Tearout": "rave_00s", "Dubstep": "rave_00s",
    "Melodic": "modern_10s", "Deep": "digital_90s", "Drumstep": "rave_00s", "Trap": "modern_10s", "EDM": "modern_10s",
    "Techno": "digital_90s", "Acid Techno": "analog_80s", "Hard Techno": "rave_00s", "Techno Trax": "digital_90s",
    "Tunnel Trance": "digital_90s", "Trance": "modern_10s", "Psytrance": "rave_00s",
    "House": "analog_80s", "Electro": "analog_80s",
    "DnB": "digital_90s", "Liquid DnB": "modern_10s", "Neurofunk": "rave_00s",
    "Space Electronica": "minimal_70s", "Berlin School": "minimal_70s",
    "Baroque": "analog_80s", "Romantic": "modern_10s", "Minimal Classical": "minimal_70s",
    "Jazz": "analog_80s", "Jazz Rock": "digital_90s",
    "Experimental": "maximal_now", "Raw Synthesis": "minimal_70s",
}


def resolve_era(era, style=None):
    e = (era or "auto").strip().lower()
    if e in ("", "auto", "none"):
        if style:
            # hybryda „A 60% + B 40%" — era o największym limicie ścieżek spośród składników (nic nie jest ucinane przez „węższy" składnik)
            parts = [re.sub(r"\s*\d+\s*%\s*$", "", p_).strip() for p_ in str(style).split("+")]
            cands = [STYLE_ERA.get(style)] if STYLE_ERA.get(style) else [STYLE_ERA.get(p_) for p_ in parts if STYLE_ERA.get(p_)]
            e = max(cands, key=lambda k: ERA[k]["max_tracks"]) if cands else "digital_90s"
        else:
            e = "digital_90s"
    if e not in ERA:
        e = "digital_90s"
    return e


def profile(era, style=None):
    return ERA[resolve_era(era, style)]


def filter_instruments(inst_list, era, style=None, rng=None, avail=None):
    """Ogranicza / porządkuje listę typów wg epoki. Zachowuje kolejność preferencji."""
    rng = rng or random.Random(0)
    e = resolve_era(era, style)
    cfg = ERA[e]
    prefer = cfg["prefer"]
    avoid = set(cfg.get("avoid") or [])
    max_t = int(cfg["max_tracks"])
    avail = set(avail) if avail is not None else None

    raw = list(inst_list)
    if prefer is None:
        # maximal: wszystko, ewentualnie przytnij tylko twardy limit
        out = [t for t in raw if avail is None or t in avail]
        return out[:max_t] if len(out) > max_t else out

    prefer_set = set(prefer)
    # 1) z listy wejściowej: preferowane najpierw, unikać avoid
    chosen, rest = [], []
    seen = set()
    for t in raw:
        if t in seen:
            continue
        if avail is not None and t not in avail:
            continue
        if t in avoid and t not in prefer_set:
            continue
        seen.add(t)
        (chosen if t in prefer_set else rest).append(t)

    # 2) uzupełnij z prefer, jeśli za mało
    for t in prefer:
        if len(chosen) + len(rest) >= max_t:
            break
        if t in seen:
            continue
        if avail is not None and t not in avail:
            continue
        seen.add(t)
        chosen.append(t)

    out = chosen + rest
    # 3) twardy limit: najpierw prefer, potem rest
    if len(out) > max_t:
        pref_part = [t for t in out if t in prefer_set][:max_t]
        if len(pref_part) < max_t:
            for t in out:
                if t not in pref_part:
                    pref_part.append(t)
                    if len(pref_part) >= max_t:
                        break
        out = pref_part
    return out


def apply_param_bias(tr, era, style=None, rng=None, strength=1.0):
    """Przesuwa tr['params'] (0..1) wg biasu epoki. Szanuje lock_sound / locked_params."""
    if tr.get("lock_sound"):
        return
    rng = rng or random.Random(0)
    e = resolve_era(era, style)
    bias = ERA[e].get("param_bias") or {}
    if not bias:
        return
    locked = set((tr.get("locked_params") or {}).keys()) if isinstance(tr.get("locked_params"), dict) else set(tr.get("locked_params") or [])
    params = tr.setdefault("params", {})
    s = max(0.0, min(1.5, float(strength)))
    for name, delta in bias.items():
        if name in locked or name not in params:
            continue
        try:
            v = float(params[name])
        except (TypeError, ValueError):
            continue
        # delta w „frakcji parametru”; lekki jitter
        v2 = v + delta * s + rng.uniform(-0.03, 0.03) * abs(delta)
        params[name] = max(0.0, min(1.0, v2))


def apply_to_project(proj, era, rng=None, strength=1.0):
    e = resolve_era(era, proj.get("style"))
    rng = rng or random.Random(proj.get("seed", 0) + 77)
    for tr in proj.get("tracks") or []:
        apply_param_bias(tr, e, proj.get("style"), random.Random(rng.random()), strength)
    proj["era"] = e
    proj["era_label"] = ERA_LABELS.get(e, e)
    return e


def spectacle_for_era(era, style=None, user_spectacle=None):
    """Jeśli user nie wymusił spektakularności — bierz z epoki."""
    cfg = profile(era, style)
    if user_spectacle and str(user_spectacle) not in ("", "auto", "none"):
        return user_spectacle
    return cfg.get("spectacle") or "balanced"


def density_mul(era, style=None):
    return float(profile(era, style).get("density_mul", 1.0))


def niuanse_mul(era, style=None):
    return float(profile(era, style).get("niuanse_mul", 1.0))

# --- instrumenty użytkownika (karta „Modelowanie CLAP”): dopisanie zatwierdzonych typów do tabel tego modułu
from . import userinst as _userinst  # noqa: E402
_userinst.apply_module("era_profiles")
