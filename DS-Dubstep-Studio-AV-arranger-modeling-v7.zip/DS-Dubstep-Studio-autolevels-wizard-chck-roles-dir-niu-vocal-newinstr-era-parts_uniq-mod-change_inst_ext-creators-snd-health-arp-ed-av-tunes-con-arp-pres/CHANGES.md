# Karta „Modelowanie CLAP” (instrumenty użytkownika bez wychodzenia z GUI)

Nowa zakładka **Modelowanie CLAP**: projektowanie własnych wtyczek na silniku DS (te same 61 parametrów co wbudowane typy):
- szablon z dowolnego istniejącego typu, tabela parametrów (— / jawny / ukryty, wartość, zakres losowania generatora), flagi one-shot/retrigger, częstotliwość odniesienia,
  banki modalne (Handpan/Tongue/Vibes/Marimba/Bell lub **własny** — do 6 składowych: stosunek f, amplituda, zanik);
- klasyfikacja dla generatora: grupa, wzór nut (`GEN`), rola, ducking, gain, agresja, pasma, **dodanie do `extras` wybranych stylów** (hybrydy dziedziczą) i do `prefer` epok;
- **Odsłuch**: kompiluje tymczasową wtyczkę (`build/preview/`, bez zmian w bibliotece), renderuje frazę testową i odtwarza ją;
- **Zatwierdź do biblioteki**: zapis `user_instruments/<id>.json` → generowanie `src/user/<id>.inc`, `src/ds_user_types.inc`, `user_types.mk` (dopisuje nazwę do `NAMES` w Makefile) →
  `make` kompiluje **tylko nową wtyczkę** (typy użytkownika są dopisywane na końcu, indeksy dotychczasowych się nie zmieniają) + paczkę DubstepKit.clap →
  typ jest rejestrowany w aplikacji bez restartu (core.TYPES/GROUPS, tabele generatora, dyrektora, niuansów, aranżera, instrument_replace, epok, Live; drzewo instrumentów i listy wyboru w GUI);
- przy starcie wszystkie zatwierdzone specyfikacje są rozpoznawane automatycznie (typ jest dostępny, gdy znaleziono jego .clap); „Skanuj ponownie” rozpoznaje nowe pliki .json w locie;
- edycja zatwierdzonego instrumentu = „Zatwierdź zmiany” (przebudowa wtyczki); „Wyłącz / włącz” ukrywa typ, zostawiając definicję C++ (stałe indeksy).

Pliki: `dubstep_studio/userinst.py` (backend), `dubstep_studio/modeling_gui.py` (karta), `host/dstypes.cpp` (zrzut tabeli parametrów/typów z silnika → JSON),
hooki w `ds_engine.h` (`DS_USER_TYPES_INC`, `DS_USER_MODAL_INC`), `Makefile` (`-include user_types.mk`, cel `build/dstypes`), testy: `tests/test_userinst.py`.

---

# Rozszerzona baza instrumentów CLAP (v6): 32 → 51 typów

Nowe wtyczki (ten sam silnik `ds_engine.h`, nowe `TypeDef` + 3 nowe banki modalne; `make` buduje `DS-<Nazwa>.clap`, wszystkie opcjonalne):
- klawisze/organy: **Organ, E-Piano, Harpsichord**; dęte/smyczki/głosy: **Flute, Brass, Cello, Choir**; perkusyjne melodyczne (modalne): **Vibes, Marimba, Bell**
- synth/bas: **Hoover, 808 Bass, Upright, Drone**; perkusja: **Open Hat, Ride, Cowbell, Conga**; fx: **Glitch**

Integracja ze stylami i hybrydami:
- `styles.py` / `generator.py`: charakterystyczne typy trafiają do `extras` stylów (Jazz: epiano/upright/ride/vibes, Baroque: harpsichord/organ/flute/cello,
  Trance: choir/bell, Electro/Trap: 808, Techno: hoover/openhat, Space/Berlin: drone/choir/bell…); hybrydy dziedziczą sumę `extras` składników.
- `era_profiles.py`: nowe typy w listach `prefer` epok; hybryda dostaje epokę o największym limicie ścieżek spośród składników (wcześniej tylko pierwszego).
- `generator.py`: wzory (`GEN`), kolejność, role (`NATIVE_ROLE`), ducking, zakresy brzmień (`SOUND`), agresja/pasma (`INST_AGG`, `INST_BANDS`), grupy losowania; nowe generatory perkusyjne `gen_openhat/ride/perc`.
- `core.py` (typy, grupy, gain, poziomy), `director.py`, `niuanse.py`, `arranger.py`, `instrument_replace.py`, `live.py` (Live losuje też nowe typy).

---

# Live: „Losuj nowe hybrydy”

Nowa opcja w zakładce Live (tryb losowy; `config.txt`: `[live] new_hybrids = yes`; w presetach `live.new_hybrids`). Każda aranżacja dostaje świeżą hybrydę
2–3 stylów z dowolnych grup (losowe proporcje, min. 12 %, bez powtórek z ostatnich 20). Składnikiem zostaje styl wylosowany kaskadą nastroju/pory dnia.
Ma pierwszeństwo przed „Mutacjami” i polem szachowym; nie działa przy zablokowanym stylu. W logu Live hybryda oznaczona ★.

---

# Aranżer (barwy · extras · kreator · nowe ad hoc · efekty WYSIWYG)

Nowy moduł `dubstep_studio/arranger.py`, włączany: GUI (Generator → „Aranżer”), `config.txt` (`arranger = yes`, `arranger_*`),
CLI (`gen --arranger [--arranger-amount X --arranger-adhoc X --arranger-persist]`), Live (bierze flagę z Generatora/configu).
Przy aranżacji sam nakłada barwy z banku, dokłada extras FX wg struktury (riser w buildzie, uderzenie na dropie, tekstury w
break/intro/outro), korzysta z `scenario_creator.auto_choice`, a gdy trzeba tworzy nowe barwy/extras ad hoc (zapis w projekcie
`proj["adhoc"]`, opcjonalnie `~/DubstepStudio/adhoc_bank.json`, nadpisanie: `DS_ADHOC_BANK`). Efekty ustala figurami WYSIWYG
(`proj["geometry_doc"]`, widoczne i edytowalne w zakładce „Edytor WYSIWYG”). Ten sam seed → ten sam projekt.

## Poprawki znalezione przy okazji
- `extras_fx`: 15 przepisów miało nazwy parametrów nieistniejące we wtyczce (host je pomijał) — `fix_params` + `PARAM_ALIASES`.
  Cztery (`fx_room_tone`, `fx_static`, `fx_wind`, `fx_whisper_pad`) nie mają odpowiednika `Noise` na pad/zap.
- `geometry_editor`: intensywność oceniana na y=0.5 i jedną liczbą na tor (przycisk „Auto” nic nie zmieniał) — teraz na wysokości
  figury, jako przebieg w czasie (velocity + automatyzacja Cutoff/Drive/Resonance); ponowne „Zastosuj” nie kumuluje (`geo_vel0`).
- `timbre_bank.spawn_timbre`: `Fine` zapisywany na typach, które go nie mają → rozstrojenie przez `Tune`.
- `timbre_bank.apply_timbre_to_track`: ADSR tylko dla parametrów, które wtyczka ma.
- `list_timbres` / `weighted_extras_for_style` pomijają wpisy ad hoc (losowania wbudowane nie zależą od historii).

Testy: `python3 -m unittest tests.test_arranger tests.test_fixes -v` (35, w tym fuzz 60 projektów).

# DS Dubstep Studio AV — poprawki 1–9 z przeglądu kodu (już naniesione)

To jest pełna paczka projektu z poprawkami naniesionymi. Zmienione pliki: `dubstep_studio/{arp_engine,core,director,eco,generator,gui,live,niuanse,remix}.py`;
nowy plik: `tests/test_fixes.py`. Pozostałe pliki, w tym `build/` (kod C++ nie był ruszany), są identyczne jak w wersji wyjściowej;
pominięto tylko katalogi `__pycache__` (Python odtworzy je przy pierwszym uruchomieniu).

Testy (czysta logika działa bez hosta; reszta wymaga `make`, test GUI także PyQt6):

    python3 -m unittest tests.test_fixes -v

## Co zmieniono

1. **gui.py `_preview_extra_or_timbre`** — `render_stems` zwraca słownik tablic numpy, a funkcja traktowała je jak ścieżki plików
   (`ValueError`, podsłuch extras/barw nigdy nie grał). Teraz: `mix_stems` → `ds_studio_sample.wav` → `player.play`.
2. **Klucze MIDI poza 0..127** — przyczyna: `niuanse._snap` przy przejściu B→C przesuwał nutę o −11 zamiast +1 (trzy kroki = −36,
   stąd nuta −12 i `ValueError` w `write_midi`). Poprawiony `_snap`; dodatkowo `core.fold_key/clamp_vel/sanitize_notes`
   (zawijanie o oktawy, velocity 1..127) w `_write_job`, `write_midi` oraz na końcu `generate`, `reroll_track`, `remix`.
3. **arp_engine.structural_inject** — `hash(nazwa)` zastąpione `zlib.crc32`; ten sam seed daje teraz ten sam projekt
   niezależnie od `PYTHONHASHSEED` (przed: 25 z 90 projektów różniło się między uruchomieniami).
4. **live.plan_next** — `randint(2, 1)` przy dokładnie jednym dostępnym extra → `min(len(ex), …)`.
5. **director.apply_roles / _retune** — ścieżki z `lock_notes` nie biorą udziału w zamianach ról, a `lock_sound` / `locked_params["Cutoff"]`
   blokuje retuning barwy (tak jak w `generator.apply_role_swaps`). Usunięte puste wywołania `_put(…, bn_[:0], …)`.
6. **live._gen_extras_from_base** — pakiet złożoności może tylko podnieść siłę niuansów/uniq ustawioną w Generatorze (`max`),
   nie nadpisuje jej; `autolevels` bez klucza w base domyślnie `False` (jak w config.txt i `generate`).
7. **eco.py** — `_next_no`: `flock` + zapis atomowy (8 procesów × 300 wywołań: 70 → 2400 unikalnych numerów);
   `_encode`: brak osieroconych `.part` i czytelny błąd przy zerwanym potoku do ffmpeg; `preroll`: jedna instancja na katalog
   (drugi proces kończy z wynikiem 0) i sprzątanie starych `.part`. W katalogu preroll pojawiają się pliki `.counter.lock` i `.preroll.lock`.
8. **core.cleanup_stale_work** — usuwa wyłącznie katalogi o nazwie z `mkdtemp` (`dsr<pid>_xxxxxxxx`, `dsr_xxxxxxxx`);
   cudze, np. `dsrender-build`, zostają. Dowiązania symboliczne są pomijane.
9. **core.render_stems** — po renderze cache przycinany do kluczy bieżącego stanu (przed: +~100 MB na każdą edycję przy 144 taktach);
   niezmienione ścieżki nadal nie są renderowane ponownie.

## Zmiany zachowania, o których warto wiedzieć

- Projekty z włączonymi niuansami lub arp-inject będą dla tego samego seeda inne niż przed poprawką (naprawione źródła błędów); zapisane projekty bez zmian.
- `--preset` (Live/ECO) nie włącza już domyślnie autolevels — preset ich nie przechowuje (pozycja 10 z przeglądu, poza tą paczką).
- Po edycji ścieżki powrót do jej wcześniejszego stanu (undo) renderuje ją ponownie.

## Weryfikacja

16 testów: na kodzie oryginalnym 15 pada, po poprawkach wszystkie przechodzą. Fuzzing 150 + 240 projektów (30 stylów, losowe opcje):
0 wyjątków, 0 naruszeń zakresu MIDI. Podsłuch GUI sprawdzony na prawdziwym `MainWindow` (offscreen). Przebieg `preroll` end-to-end (2 pliki WAV) działa.

## Poza tą paczką (pozycje 10–17 z przeglądu)

Kompletność presetów / `GenOptions`, SIGHUP + `--preset`, utwardzenie config/Icecast, diagnostyka `Meta`, rozbicie `generate()`,
martwy kod w generator.py, `timeout` dla dsrender, aktualizacja README (32 wtyczki).
